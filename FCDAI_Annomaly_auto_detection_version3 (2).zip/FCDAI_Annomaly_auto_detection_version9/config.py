"""
FCDAI Version 9 — Production Configuration
============================================
Centralized configuration for the 7-layer AML pipeline.
V9 Enhancements (VAT audit fixes):
  - PII masking enabled by default (FM-006)
  - Hash chain persistence across restarts (FM-007)
  - Risk tier ε-tolerance for float boundaries (FM-003)
  - CSV formula injection protection (FM-010)
  - Upload size validation (FM-009)
  - VAE KL divergence backprop fix (FM-020)
  - In-memory PII masking for data vault (FM-008)

V8 Enhancements:
  - Role-based column mapping (no hardcoded column names)
  - Type-aware preprocessing config
  - Parameterized thresholds (all tunable from here)
  - Memory-safe limits for 8GB CPU-only
  - Audit & data lineage config
  - Air-gapped / zero-telemetry enforcement

Author: Project Vanguard Team
"""

from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


# =============================================================================
# PATH CONFIGURATION
# =============================================================================
BASE_DIR = Path(__file__).parent

@dataclass
class PathConfig:
    """File system paths."""
    BASE: Path = BASE_DIR
    DATA: Path = BASE_DIR / "data"
    DATA_VAULT: Path = BASE_DIR / "data" / "vault"
    DATA_SOURCES: Path = BASE_DIR / "data" / "sources"
    EXPORTS: Path = BASE_DIR / "data" / "exports"
    MODELS: Path = BASE_DIR / "models"
    LOGS: Path = BASE_DIR / "logs"
    CACHE: Path = BASE_DIR / "cache"
    ASSETS: Path = BASE_DIR / "assets"
    RUN_HISTORY: Path = BASE_DIR / "data" / "vault" / "runs"

    def __post_init__(self):
        for path in [self.DATA_VAULT, self.DATA_SOURCES, self.EXPORTS,
                     self.MODELS, self.LOGS, self.CACHE, self.ASSETS,
                     self.RUN_HISTORY]:
            path.mkdir(parents=True, exist_ok=True)


# =============================================================================
# V8: ROLE-BASED COLUMN CONFIGURATION (No hardcoded column names!)
# =============================================================================
@dataclass
class ColumnRoleConfig:
    """
    Maps *semantic roles* to potential column names.
    The pipeline resolves columns by ROLE, never by hardcoded name.
    Users can override via the Data Sources config page.
    """
    ROLE_ALIASES: Dict[str, List[str]] = field(default_factory=lambda: {
        "primary_key":  ["cust_id", "customer_id", "party_id", "client_id", "entity_id"],
        "entity_name":  ["cust_name", "customer_name", "party_name", "client_name", "full_name", "name"],
        "amount":       ["amount", "txn_amount", "transaction_amount", "value", "amt"],
        "timestamp":    ["timestamp", "txn_date", "transaction_date", "date", "created_at", "event_date"],
        "account_key":  ["account_id", "acct_id", "account_number", "account"],
        "txn_key":      ["txn_id", "transaction_id", "trans_id"],
        "txn_type":     ["txn_type", "transaction_type", "type", "tx_type"],
        "currency":     ["currency", "ccy", "currency_code"],
        "country":      ["country", "country_code", "jurisdiction"],
        "channel":      ["channel", "txn_channel", "payment_method"],
    })

    ROLE_DTYPE_HINT: Dict[str, str] = field(default_factory=lambda: {
        "primary_key": "id", "entity_name": "text", "amount": "numeric",
        "timestamp": "datetime", "account_key": "id", "txn_key": "id",
        "txn_type": "categorical", "currency": "categorical",
        "country": "categorical", "channel": "categorical",
    })

    MANDATORY_ROLES: List[str] = field(default_factory=lambda: ["primary_key"])

    # Runtime overrides from UI (role -> actual column name)
    USER_OVERRIDES: Dict[str, str] = field(default_factory=dict)

    def resolve(self, df_columns: List[str], role: str) -> Optional[str]:
        """Resolve a role to an actual column name in the dataframe."""
        # 1. Check user overrides first
        if role in self.USER_OVERRIDES:
            override = self.USER_OVERRIDES[role]
            if override in df_columns:
                return override

        # 2. Check aliases (case-insensitive)
        aliases = self.ROLE_ALIASES.get(role, [])
        col_lower_map = {c.lower(): c for c in df_columns}
        for alias in aliases:
            if alias.lower() in col_lower_map:
                return col_lower_map[alias.lower()]

        # 3. Partial match
        for alias in aliases:
            for col_lower, col_orig in col_lower_map.items():
                if alias.lower() in col_lower:
                    return col_orig

        return None


# =============================================================================
# THEME CONFIGURATION
# =============================================================================
@dataclass
class ThemeConfig:
    """UI theme colors and styles."""
    PRIMARY: str = "#00D4FF"
    SECONDARY: str = "#9D4EDD"
    SUCCESS: str = "#00C853"
    WARNING: str = "#FFB300"
    DANGER: str = "#FF5252"
    INFO: str = "#2196F3"

    DARK_BG: str = "#0D1117"
    DARK_BG_PRIMARY: str = "#0a0a12"
    DARK_BG_SECONDARY: str = "#12121f"
    DARK_BG_PAPER: str = "#1a1a2e"
    DARK_BG_CARD: str = "#16213e"
    DARK_BORDER: str = "#30363D"

    RISK_GRADIENT: List[str] = field(default_factory=lambda: [
        "#00C853", "#4CAF50", "#FFC107", "#FF9800", "#FF5252",
    ])

    def get_mantine_theme(self) -> Dict[str, Any]:
        return {
            "colorScheme": "dark",
            "primaryColor": "cyan",
            "fontFamily": "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
            "colors": {
                "cyan": ["#e3fafc","#c5f6fa","#99e9f2","#66d9e8","#3bc9db",
                         "#22b8cf","#15aabf","#1098ad","#0c8599","#0b7285"],
                "grape": ["#f8f0fc","#f3d9fa","#eebefa","#e599f7","#da77f2",
                          "#cc5de8","#be4bdb","#ae3ec9","#9c36b5","#862e9c"],
            },
            "components": {
                "Paper": {"styles": {"root": {"backgroundColor": self.DARK_BG_PAPER}}},
                "Card": {"styles": {"root": {"backgroundColor": self.DARK_BG_CARD}}},
            },
        }


# =============================================================================
# PII MASKING CONFIGURATION
# =============================================================================
@dataclass
class PIIConfig:
    """Privacy mode configuration for PII data protection."""
    ENABLED_BY_DEFAULT: bool = True   # V9: FM-006 — enabled by default for production safety
    MASK_AT_STORAGE: bool = True      # V8: Mask before writing to vault
    MASK_IN_EXPORTS: bool = True      # V8: Mask when exporting
    MASK_PATTERN: str = "XXXX"
    VISIBLE_CHARS: int = 4

    MASKED_COLUMNS: List[str] = field(default_factory=lambda: [
        "customer_id", "account_number", "ssn", "name", "email", "phone",
        "cust_id", "cust_name", "party_name", "client_name",
    ])

    PATTERNS: Dict[str, str] = field(default_factory=lambda: {
        "customer_id": r"^(.{4}).*(.{4})$",
        "email": r"^(.{2}).*(@.*)$",
        "phone": r"^.*(.{4})$",
        "account": r"^.*(.{4})$",
    })


# =============================================================================
# V8: MEMORY & RESOURCE CONFIGURATION (8GB CPU-only)
# =============================================================================
@dataclass
class ResourceConfig:
    """Resource limits for 8GB RAM / CPU-only environment."""
    MAX_MEMORY_MB: int = 4096
    MAX_ROWS_FOR_HEAVY_METHODS: int = 5000
    MAX_ROWS_AG_GRID_PREVIEW: int = 500
    BATCH_SIZE_DETECTION: int = 2000
    LAZY_MATRIX_CREATION: bool = True
    MAX_CONCURRENT_METHODS: int = 1


# =============================================================================
# LAYER CONFIGURATION — fully parameterized
# =============================================================================
@dataclass
class LayerConfig:
    """7-Layer pipeline configuration."""

    # Layer 1-2: Ingestion & Data Quality
    DQ_THRESHOLDS: Dict[str, float] = field(default_factory=lambda: {
        "completeness": 0.95, "consistency": 0.90, "validity": 0.85,
    })

    # Layer 3: Feature Engineering — all thresholds configurable
    FEATURE_CATEGORIES: List[str] = field(default_factory=lambda: [
        "velocity", "aggregates", "ratios", "flags", "temporal", "behavioral",
    ])
    SKEW_THRESHOLD: float = 2.0
    ROUND_AMOUNT_DIVISOR: float = 100.0
    HIGH_AMOUNT_QUANTILE: float = 0.95
    LARGE_TXN_MULTIPLIER: float = 3.0
    CONTAMINATION_RATE: float = 0.05

    # Layer 4: Preprocessing
    MATRIX_VERSIONS: List[str] = field(default_factory=lambda: [
        "raw", "scaled", "pca", "encoded",
    ])
    PCA_COMPONENTS: int = 10
    MIN_FEATURES_FOR_DL: int = 10

    # Layer 5: Detection Methods (26 across 8 families)
    DETECTION_METHODS: Dict[str, List[str]] = field(default_factory=lambda: {
        "statistical":   ["zscore", "iqr", "grubbs", "dixon", "esd"],
        "distance":      ["knn", "mahalanobis", "lof"],
        "density":       ["dbscan", "optics", "hdbscan", "cblof"],
        "clustering":    ["kmeans_anomaly", "gmm", "spectral"],
        "trees":         ["isolation_forest", "extended_if"],
        "timeseries":    ["stl", "arima_residual", "prophet"],
        "graph":         ["pagerank", "hits", "community", "centrality"],
        "deep_learning": ["autoencoder", "vae"],
    })

    HEAVY_METHODS: List[str] = field(default_factory=lambda: [
        "knn", "lof", "dbscan", "optics", "hdbscan", "cblof",
        "spectral", "mahalanobis", "pagerank", "hits", "centrality",
    ])

    ENSEMBLE_FLAG_THRESHOLD: float = 0.5
    ENSEMBLE_METHOD: str = "tiered_consensus"

    RISK_TIERS: Dict[str, Dict] = field(default_factory=lambda: {
        "CRITICAL": {"score_min": 0.95, "vote_min": 23},
        "HIGH":     {"score_min": 0.85, "vote_min": 18},
        "MEDIUM":   {"score_min": 0.70, "vote_min": 12},
        "LOW":      {"score_min": 0.50, "vote_min": 8},
        "NORMAL":   {"score_min": 0.0,  "vote_min": 0},
    })

    METHOD_WEIGHTS: Dict[str, float] = field(default_factory=lambda: {
        "benford": 2.0, "zscore": 1.0, "mad": 1.0, "grubbs": 1.0,
        "isolation_forest": 1.5, "extended_if": 1.3, "lof": 1.5, "knn": 1.0,
        "hdbscan": 1.2, "dbscan": 1.0, "community": 1.2, "pagerank": 1.0,
        "autoencoder": 0.8, "vae": 0.8, "lstm_ae": 0.5,
    })

    SCORE_NORMALIZATION: str = "percentile_rank"
    INVESTIGATION_CAPACITY: int = 1000

    @property
    def MAX_ROWS_FOR_DISTANCE_METHODS(self) -> int:
        """Backward compat alias."""
        return RESOURCES.MAX_ROWS_FOR_HEAVY_METHODS


# =============================================================================
# V8: AUDIT & DATA LINEAGE CONFIGURATION
# =============================================================================
@dataclass
class AuditConfig:
    """Bank MRM audit-ready configuration."""
    ENABLE_DATA_LINEAGE: bool = True
    ENABLE_RUN_VERSIONING: bool = True
    ENABLE_HASH_CHAIN_LOGS: bool = True
    LOG_ROTATION_MAX_BYTES: int = 10_000_000   # 10MB
    LOG_ROTATION_BACKUP_COUNT: int = 10
    HASH_ALGORITHM: str = "sha256"
    CAPTURE_CONFIG_SNAPSHOT: bool = True
    PERSIST_HASH_CHAIN: bool = True       # V9: FM-007 — persist hash state across restarts
    MAX_UPLOAD_SIZE_MB: int = 100          # V9: FM-009 — upload size limit
    RISK_TIER_EPSILON: float = 1e-9        # V9: FM-003 — float boundary tolerance


# =============================================================================
# APPLICATION CONFIGURATION
# =============================================================================
@dataclass
class AppConfig:
    """Application settings."""
    TITLE: str = "FCDAI Anomaly Auto Detection — Version 9"
    VERSION: str = "9.0.0"
    HOST: str = "127.0.0.1"
    PORT: int = 8070
    DEBUG: bool = False
    SERVE_LOCALLY: bool = True
    CUSTOMER_LEVEL_PROCESSING: bool = True
    SYNC_INTERVAL_MS: int = 5000

    PLOTLY_CONFIG: Dict = field(default_factory=lambda: {
        "displaylogo": False,
        "modeBarButtonsToRemove": ["sendDataToCloud", "lasso2d", "select2d"],
        "toImageButtonOptions": {"format": "png", "scale": 2},
        "staticPlot": False,
    })


# =============================================================================
# DATA SOURCES CONFIGURATION — role-based
# =============================================================================
@dataclass
class DataSourceConfig:
    """Multi-source data configuration."""
    SOURCES: Dict[str, Dict] = field(default_factory=lambda: {
        "kyc":          {"key_role": "primary_key"},
        "transactions": {"key_role": "txn_key"},
        "alerts":       {"key_role": "primary_key"},
        "cases":        {"key_role": "primary_key"},
        "accounts":     {"key_role": "account_key"},
        "watchlist":    {"key_role": "primary_key"},
    })


# =============================================================================
# INSTANTIATE CONFIGS
# =============================================================================
PATHS = PathConfig()
THEME = ThemeConfig()
PII = PIIConfig()
RESOURCES = ResourceConfig()
LAYERS = LayerConfig()
AUDIT = AuditConfig()
APP = AppConfig()
DATA_SOURCES = DataSourceConfig()
COLUMNS = ColumnRoleConfig()
