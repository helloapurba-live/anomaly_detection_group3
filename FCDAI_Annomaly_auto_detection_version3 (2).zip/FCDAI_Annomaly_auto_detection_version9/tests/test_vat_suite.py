"""
Project Vanguard V9 — VAT Test Suite
======================================
Comprehensive pytest + dash.testing (dash_duo) template covering:
  1. Functional / UI / UX Validation
  2. Anomaly Detection Integrity (synthetic injection)
  3. Performance & Stress Tests
  4. Security & Compliance Audit

Prerequisites:
  pip install pytest dash[testing] selenium pandas numpy scipy scikit-learn

Run:
  pytest tests/test_vat_suite.py -v --timeout=120
"""

import pytest
import numpy as np
import pandas as pd
import json
import time
import os
import sys
import hashlib
from pathlib import Path
from unittest.mock import patch, MagicMock

# ── Project root ──
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))


# =============================================================================
# FIXTURES
# =============================================================================
@pytest.fixture(scope="session")
def project_root():
    return PROJECT_ROOT


@pytest.fixture(scope="session")
def config():
    """Load project config."""
    from config import (
        PATHS, LAYERS, PII, AUDIT, RESOURCES, APP, THEME,
        ColumnRoleConfig as ROLES
    )
    return {
        "PATHS": PATHS,
        "LAYERS": LAYERS,
        "PII": PII,
        "AUDIT": AUDIT,
        "RESOURCES": RESOURCES,
        "APP": APP,
        "THEME": THEME,
        "ROLES": ROLES,
    }


@pytest.fixture
def sample_df():
    """Create a realistic sample DataFrame for testing."""
    np.random.seed(42)
    n = 500
    df = pd.DataFrame({
        "cust_id": [f"CUST-{i:06d}" for i in range(n)],
        "amount": np.random.lognormal(mean=7, sigma=1.5, size=n),
        "transaction_count": np.random.poisson(lam=20, size=n),
        "avg_balance": np.random.normal(50000, 15000, size=n),
        "days_since_last_txn": np.random.exponential(scale=10, size=n),
        "num_countries": np.random.poisson(lam=2, size=n),
        "risk_rating": np.random.choice(["Low", "Medium", "High"], size=n),
        "is_pep": np.random.choice([0, 1], size=n, p=[0.95, 0.05]),
        "account_age_days": np.random.randint(30, 3650, size=n),
        "num_alerts_prior": np.random.poisson(lam=1, size=n),
        "avg_txn_amount": np.random.lognormal(mean=6, sigma=1, size=n),
        "max_txn_amount": np.random.lognormal(mean=8, sigma=1.5, size=n),
        "std_txn_amount": np.random.lognormal(mean=5, sigma=1, size=n),
        "unique_counterparties": np.random.poisson(lam=10, size=n),
        "cash_ratio": np.random.beta(2, 5, size=n),
    })
    return df


@pytest.fixture
def sample_df_with_outliers(sample_df):
    """Sample DataFrame with 5% known injected outliers."""
    df = sample_df.copy()
    n = len(df)
    n_outliers = max(1, int(n * 0.05))
    outlier_indices = np.random.choice(n, n_outliers, replace=False)

    # Inject extreme amounts (10x the mean)
    mean_amount = df["amount"].mean()
    df.loc[outlier_indices, "amount"] = mean_amount * 10

    # Inject extreme transaction counts
    df.loc[outlier_indices, "transaction_count"] = df["transaction_count"].max() * 5

    # Inject extreme cash ratio
    df.loc[outlier_indices, "cash_ratio"] = 0.99

    return df, outlier_indices


@pytest.fixture
def numeric_matrix(sample_df):
    """Extract numeric matrix from sample DataFrame."""
    numeric_cols = sample_df.select_dtypes(include=[np.number]).columns
    X = sample_df[numeric_cols].values.astype(np.float32)
    return X


# =============================================================================
# SECTION 1: FUNCTIONAL & UI/UX VALIDATION
# =============================================================================
class TestFunctionalValidation:
    """Section 1: Functional and UI/UX validation tests."""

    def test_no_match_pattern_in_callbacks(self, project_root):
        """1.1.1 — Verify NO MATCH pattern callbacks exist (Dash 3.4.0 bug)."""
        pages_dir = project_root / "pages"
        match_found = []
        for py_file in pages_dir.glob("*.py"):
            content = py_file.read_text(encoding="utf-8")
            if "MATCH" in content and "dash.dependencies" in content:
                match_found.append(py_file.name)
            if "from dash import" in content and "MATCH" in content.split("from dash import")[1].split("\n")[0]:
                match_found.append(py_file.name)
        assert not match_found, f"MATCH pattern found in: {match_found}"

    def test_all_pages_registered(self, project_root):
        """1.1.2 — Verify all 13 page files register correctly."""
        pages_dir = project_root / "pages"
        page_files = list(pages_dir.glob("*.py"))
        page_names = [f.stem for f in page_files if f.stem != "__init__"]
        expected_pages = [
            "admin", "audit_trail", "audit_vault", "config_panel",
            "dashboard", "data_sources", "explainability",
            "investigation_queue", "layer_view", "model_diagnostics",
            "narratives", "pipeline_run",
        ]
        for page in expected_pages:
            assert page in page_names, f"Missing page file: {page}.py"

    def test_page_register_call(self, project_root):
        """1.1.2b — Each page file calls dash.register_page."""
        pages_dir = project_root / "pages"
        for py_file in pages_dir.glob("*.py"):
            if py_file.stem.startswith("_"):
                continue
            content = py_file.read_text(encoding="utf-8")
            assert "register_page" in content, f"{py_file.name} missing register_page()"

    def test_page_has_layout(self, project_root):
        """1.1.3 — Each page defines a layout variable."""
        pages_dir = project_root / "pages"
        for py_file in pages_dir.glob("*.py"):
            if py_file.stem.startswith("_"):
                continue
            content = py_file.read_text(encoding="utf-8")
            assert "layout" in content, f"{py_file.name} missing layout definition"

    def test_suppress_callback_exceptions_flag(self, project_root):
        """1.3.2 — Document suppress_callback_exceptions usage."""
        app_py = project_root / "app.py"
        content = app_py.read_text(encoding="utf-8")
        assert "suppress_callback_exceptions=True" in content, \
            "suppress_callback_exceptions not set (expected True for multi-page)"

    def test_serve_locally(self, project_root):
        """4.4.1 — Verify air-gapped mode."""
        app_py = project_root / "app.py"
        content = app_py.read_text(encoding="utf-8")
        assert "serve_locally=True" in content or "serve_locally" in content, \
            "serve_locally not set — CDN calls may occur"

    def test_config_debug_false(self, config):
        """4.4.2 — Verify DEBUG=False in production config."""
        assert config["APP"].DEBUG is False, "DEBUG must be False for production"

    def test_config_port(self, config):
        """Verify port is configured."""
        assert config["APP"].PORT == 8070


# =============================================================================
# SECTION 2: ANOMALY DETECTION INTEGRITY
# =============================================================================
class TestAnomalyDetectionIntegrity:
    """Section 2: Anomaly detection integrity with synthetic injection."""

    # ── 2.1 Synthetic Injection ──

    def test_zscore_detects_injected_outliers(self, sample_df_with_outliers):
        """2.1.1 — Z-Score should detect ≥80% of injected 3σ+ outliers."""
        from layers.l5_detection import ZScoreDetector

        df, outlier_idx = sample_df_with_outliers
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        X = df[numeric_cols].values.astype(np.float32)

        detector = ZScoreDetector(threshold=3.0)
        scores = detector.fit_predict(X)
        labels = (scores > 0.5).astype(int)

        detected = labels[outlier_idx].sum()
        detection_rate = detected / len(outlier_idx)
        assert detection_rate >= 0.6, \
            f"Z-Score detection rate {detection_rate:.1%} < 60% on injected outliers"

    def test_iqr_detects_injected_outliers(self, sample_df_with_outliers):
        """2.1.1 — IQR should detect injected outliers."""
        from layers.l5_detection import IQRDetector

        df, outlier_idx = sample_df_with_outliers
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        X = df[numeric_cols].values.astype(np.float32)

        detector = IQRDetector(multiplier=1.5)
        scores = detector.fit_predict(X)
        labels = (scores > 0.5).astype(int)

        detected = labels[outlier_idx].sum()
        detection_rate = detected / len(outlier_idx)
        assert detection_rate >= 0.5, \
            f"IQR detection rate {detection_rate:.1%} < 50% on injected outliers"

    def test_isolation_forest_detects_outliers(self, sample_df_with_outliers):
        """2.1.2 — Isolation Forest should detect cluster outliers."""
        from layers.l5_detection import IsolationForestDetector

        df, outlier_idx = sample_df_with_outliers
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        X = df[numeric_cols].values.astype(np.float32)

        detector = IsolationForestDetector(n_estimators=100, contamination=0.05)
        scores = detector.fit_predict(X)
        labels = (scores > 0.5).astype(int)

        detected = labels[outlier_idx].sum()
        detection_rate = detected / len(outlier_idx)
        assert detection_rate >= 0.5, \
            f"IF detection rate {detection_rate:.1%} < 50% on injected outliers"

    def test_lof_detects_outliers(self, sample_df_with_outliers):
        """2.1.2 — LOF should detect isolated points."""
        from layers.l5_detection import LOFDetector

        df, outlier_idx = sample_df_with_outliers
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        X = df[numeric_cols].values.astype(np.float32)

        detector = LOFDetector(n_neighbors=20, contamination=0.05)
        scores = detector.fit_predict(X)
        labels = (scores > 0.5).astype(int)

        detected = labels[outlier_idx].sum()
        detection_rate = detected / len(outlier_idx)
        assert detection_rate >= 0.3, \
            f"LOF detection rate {detection_rate:.1%} < 30% on injected outliers"

    def test_no_false_positives_on_uniform_data(self):
        """2.1.6 — Uniform data should NOT produce >10% false anomalies."""
        from layers.l5_detection import ZScoreDetector

        np.random.seed(42)
        X = np.random.normal(0, 1, (500, 10)).astype(np.float32)

        detector = ZScoreDetector(threshold=3.0)
        scores = detector.fit_predict(X)
        labels = (scores > 0.5).astype(int)

        fp_rate = labels.sum() / len(labels)
        assert fp_rate < 0.10, \
            f"False positive rate {fp_rate:.1%} > 10% on normal data"

    # ── 2.2 Distribution Shift ──

    def test_single_feature_dataset(self):
        """2.2.5 — Pipeline should handle single-feature datasets gracefully."""
        from layers.l5_detection import MethodExecutionEngine, MethodConfig

        engine = MethodExecutionEngine()
        # KNN requires min_f=3, should fail for 1-feature data
        config = engine.build_method_configs()

        for mc in config:
            if mc.name == "knn":
                can_exec, reason = engine.check_requirements(
                    mc, n_features=1, n_samples=100,
                    has_temporal=False, has_graph=False
                )
                assert not can_exec, "KNN should skip for 1-feature data"
                assert "features" in reason.lower()
            if mc.name == "zscore":
                can_exec, _ = engine.check_requirements(
                    mc, n_features=1, n_samples=100,
                    has_temporal=False, has_graph=False
                )
                assert can_exec, "Z-Score should work with 1 feature"

    def test_temporal_method_skipped_without_temporal_data(self):
        """2.2.5 — Time-series methods skip when no temporal data."""
        from layers.l5_detection import MethodExecutionEngine

        engine = MethodExecutionEngine()
        configs = engine.build_method_configs()

        for mc in configs:
            if mc.name in ("stl", "arima_residual", "prophet"):
                can_exec, reason = engine.check_requirements(
                    mc, n_features=10, n_samples=500,
                    has_temporal=False, has_graph=False
                )
                assert not can_exec, f"{mc.name} should skip without temporal data"

    # ── 2.3 Model Stability & Reproducibility ──

    def test_reproducibility(self, numeric_matrix):
        """2.3.1 — Same data → same scores (deterministic)."""
        from layers.l5_detection import IsolationForestDetector

        detector1 = IsolationForestDetector(contamination=0.05)
        scores1 = detector1.fit_predict(numeric_matrix)

        detector2 = IsolationForestDetector(contamination=0.05)
        scores2 = detector2.fit_predict(numeric_matrix)

        np.testing.assert_array_almost_equal(
            scores1, scores2, decimal=10,
            err_msg="Isolation Forest not reproducible (check random_state)"
        )

    def test_ensemble_reproducibility(self, numeric_matrix):
        """2.3.3 — Ensemble weights are deterministic."""
        from layers.l6_ensemble import Layer6Ensemble

        n = len(numeric_matrix)
        method_names = ["m1", "m2", "m3"]
        fake_scores = np.random.RandomState(42).rand(n, 3)

        ens1 = Layer6Ensemble(method="tiered_consensus")
        result1 = ens1.fuse(fake_scores.copy(), method_names.copy())

        ens2 = Layer6Ensemble(method="tiered_consensus")
        result2 = ens2.fuse(fake_scores.copy(), method_names.copy())

        np.testing.assert_array_almost_equal(
            result1.final_scores, result2.final_scores, decimal=10,
            err_msg="Ensemble fusion not reproducible"
        )

    def test_risk_tier_boundary(self, config):
        """2.3.4 — Score at exact threshold gets correct tier."""
        from layers.l6_ensemble import Layer6Ensemble

        tiers = config["LAYERS"].RISK_TIERS
        if "CRITICAL" in tiers:
            critical_min = tiers["CRITICAL"]["score_min"]

            ens = Layer6Ensemble(method="tiered_consensus")
            scores = np.array([critical_min, critical_min - 0.01, 0.0])
            votes = np.array([0, 0, 0])
            n_methods = 5

            tier_labels = ens._assign_risk_tiers_v6(scores, votes, n_methods)
            assert tier_labels[0] == "CRITICAL", \
                f"Score exactly at CRITICAL threshold got: {tier_labels[0]}"

    def test_contamination_rate_monotonic(self, numeric_matrix):
        """2.3.2 — Higher contamination → more flags."""
        from layers.l5_detection import IsolationForestDetector

        rates = [0.01, 0.05, 0.10]
        flag_counts = []
        for rate in rates:
            det = IsolationForestDetector(contamination=rate)
            scores = det.fit_predict(numeric_matrix)
            flags = (scores > 0.5).sum()
            flag_counts.append(flags)

        # Should be monotonically non-decreasing
        for i in range(len(flag_counts) - 1):
            assert flag_counts[i] <= flag_counts[i + 1], \
                f"Contamination {rates[i]}→{rates[i+1]}: flags decreased {flag_counts[i]}→{flag_counts[i+1]}"


# =============================================================================
# SECTION 3: PERFORMANCE & STRESS TESTS
# =============================================================================
class TestPerformance:
    """Section 3: Performance and stress testing."""

    def test_detection_baseline_500_rows(self):
        """3.1.1 — 500 rows × 15 features: all detectors finish < 60s."""
        from layers.l5_detection import Layer5Detection

        np.random.seed(42)
        X = np.random.randn(500, 15).astype(np.float32)

        layer5 = Layer5Detection(contamination=0.05)
        basic_methods = ["zscore", "iqr", "grubbs", "knn", "lof",
                         "isolation_forest", "dbscan", "kmeans_anomaly"]

        start = time.time()
        results = layer5.detect_all(X, methods=basic_methods)
        elapsed = time.time() - start

        assert elapsed < 60, f"Detection took {elapsed:.1f}s > 60s for 500 rows"
        assert len(results) == len(basic_methods), \
            f"Expected {len(basic_methods)} results, got {len(results)}"

    def test_heavy_method_skip_5000_plus(self, config):
        """3.3.7 — HEAVY_METHODS are listed in config for smart selection."""
        heavy = config["LAYERS"].HEAVY_METHODS
        assert isinstance(heavy, list), "HEAVY_METHODS must be a list"
        assert len(heavy) > 0, "HEAVY_METHODS list is empty"

    def test_float32_downcast(self):
        """3.4.1 — L5 detection downcasts to float32."""
        from layers.l5_detection import Layer5Detection

        X = np.random.randn(100, 10).astype(np.float64)
        layer5 = Layer5Detection()
        results = layer5.detect_all(X, methods=["zscore"])
        # The detect_all method should downcast internally
        # Verify by checking it doesn't crash with float64 input
        assert len(results) > 0

    def test_ensemble_with_many_methods(self):
        """3.1 — Ensemble handles 20+ method score columns."""
        from layers.l6_ensemble import Layer6Ensemble

        np.random.seed(42)
        n, m = 1000, 20
        fake_scores = np.random.rand(n, m).astype(np.float32)
        method_names = [f"method_{i}" for i in range(m)]

        ens = Layer6Ensemble(method="tiered_consensus")
        start = time.time()
        result = ens.fuse(fake_scores, method_names)
        elapsed = time.time() - start

        assert elapsed < 5, f"Ensemble fusion took {elapsed:.1f}s for {m} methods"
        assert len(result.final_scores) == n
        assert len(result.risk_tiers) == n

    def test_autoencoder_convergence(self):
        """3.3.1 — Autoencoder early stopping converges in < 15s for small data."""
        from layers.l5_detection import AutoencoderDetector

        np.random.seed(42)
        X = np.random.randn(500, 15).astype(np.float32)

        det = AutoencoderDetector(encoding_dim=8, epochs=100, batch_size=256)
        start = time.time()
        scores = det.fit_predict(X)
        elapsed = time.time() - start

        assert elapsed < 15, f"Autoencoder took {elapsed:.1f}s > 15s"
        assert scores.shape == (500,)
        assert np.all((scores >= 0) & (scores <= 1))

    def test_knn_graph_builds(self):
        """3.3.3 — k-NN graph builds in reasonable time."""
        from layers.l5_detection import _build_knn_graph

        np.random.seed(42)
        X = np.random.randn(1000, 10).astype(np.float32)

        start = time.time()
        graph = _build_knn_graph(X, k=15)
        elapsed = time.time() - start

        assert elapsed < 10, f"k-NN graph build took {elapsed:.1f}s > 10s"
        assert graph.shape == (1000, 1000)


# =============================================================================
# SECTION 4: SECURITY & COMPLIANCE AUDIT
# =============================================================================
class TestSecurityCompliance:
    """Section 4: Security and compliance audit."""

    def test_pii_masking_email(self):
        """4.1.6 — Email masking keeps first 2 chars + domain."""
        from utils.pii_masking import mask_email

        result = mask_email("john.doe@company.com")
        assert result.endswith("@company.com")
        assert result.startswith("jo")
        assert "****" in result

    def test_pii_masking_phone(self):
        """4.1.6 — Phone masking keeps last 4 digits."""
        from utils.pii_masking import mask_phone

        result = mask_phone("+1-555-123-4567")
        assert result.endswith("4567")
        assert "***" in result

    def test_pii_masking_account(self):
        """4.1.6 — Account masking keeps last 4 digits."""
        from utils.pii_masking import mask_account

        result = mask_account("ACC-1234567890")
        assert result.endswith("7890")
        assert "******" in result

    def test_pii_detect_columns(self):
        """4.1.5 — Auto-detect PII columns."""
        from utils.pii_masking import detect_pii_columns

        df = pd.DataFrame({
            "customer_id": [1],
            "account_number": [2],
            "amount": [100],
            "score": [0.5],
            "email_address": ["a@b.com"],
            "phone_number": ["555"],
        })
        pii_cols = detect_pii_columns(df)
        assert "customer_id" in pii_cols
        assert "account_number" in pii_cols
        assert "email_address" in pii_cols
        assert "phone_number" in pii_cols
        assert "amount" not in pii_cols
        assert "score" not in pii_cols

    def test_pii_mask_dataframe(self):
        """4.1.6 — Full DataFrame masking."""
        from utils.pii_masking import mask_dataframe

        df = pd.DataFrame({
            "customer_id": ["CUST-000001", "CUST-000002"],
            "email": ["john@test.com", "jane@test.com"],
            "amount": [100.0, 200.0],
        })
        masked = mask_dataframe(df, columns=["customer_id", "email"], enabled=True)
        assert masked["customer_id"].iloc[0] != "CUST-000001"
        assert masked["email"].iloc[0] != "john@test.com"
        assert masked["amount"].iloc[0] == 100.0  # Not masked

    def test_pii_masking_disabled(self):
        """4.1 — Masking does nothing when disabled."""
        from utils.pii_masking import mask_dataframe

        df = pd.DataFrame({"customer_id": ["CUST-000001"]})
        result = mask_dataframe(df, columns=["customer_id"], enabled=False)
        assert result["customer_id"].iloc[0] == "CUST-000001"

    def test_pii_default_config(self, config):
        """4.1.1 — Document PII default state (CRITICAL finding)."""
        pii = config["PII"]
        # This documents the risk — ENABLED_BY_DEFAULT is False
        assert hasattr(pii, "ENABLED_BY_DEFAULT"), \
            "PIIConfig missing ENABLED_BY_DEFAULT"
        # If this fails, it means PII masking is already enabled (good!)
        # If this passes, PII is OFF by default (document risk)

    def test_hash_chain_logging(self, project_root):
        """4.3.1 — Hash chain creates chained hashes."""
        from utils.logger import AuditLogger

        logger = AuditLogger()
        # Reset chain for testing
        prev = AuditLogger._prev_hash
        AuditLogger._prev_hash = "TEST_GENESIS"

        logger.log_action("TEST_ACTION_1", metadata={"test": True})
        hash1 = AuditLogger._prev_hash

        logger.log_action("TEST_ACTION_2", metadata={"test": True})
        hash2 = AuditLogger._prev_hash

        assert hash1 != hash2, "Hash chain should produce different hashes"
        assert hash1 != "TEST_GENESIS", "Hash should change from genesis"

        # Restore
        AuditLogger._prev_hash = prev

    def test_data_validation_rejects_small_dataset(self):
        """4.2.2 — Import rejects datasets with < 10 rows."""
        from utils.data_io import DataVault

        vault = DataVault.__new__(DataVault)
        vault._current_data = None
        vault._scored_data = None
        vault._sources = {}
        vault._metadata = {}
        vault._pipeline_result = {}

        small_df = pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
        is_valid, issues = vault._validate_data(small_df)
        assert not is_valid, "Should reject < 10 rows"
        assert any("fewer than 10" in i for i in issues)

    def test_data_validation_rejects_no_numeric(self):
        """4.2.2 — Import rejects datasets with 0 numeric columns."""
        from utils.data_io import DataVault

        vault = DataVault.__new__(DataVault)
        vault._current_data = None
        vault._scored_data = None
        vault._sources = {}
        vault._metadata = {}
        vault._pipeline_result = {}

        text_df = pd.DataFrame({"name": [f"person_{i}" for i in range(20)]})
        is_valid, issues = vault._validate_data(text_df)
        assert not is_valid
        assert any("numeric" in i.lower() for i in issues)

    def test_no_hardcoded_secrets(self, project_root):
        """4.4.8 — No hardcoded passwords or API keys."""
        suspicious_patterns = ["password=", "api_key=", "secret=", "token="]
        findings = []

        for py_file in project_root.rglob("*.py"):
            if "__pycache__" in str(py_file) or "test_" in py_file.name:
                continue
            try:
                content = py_file.read_text(encoding="utf-8").lower()
                for pattern in suspicious_patterns:
                    if pattern in content:
                        # Exclude comments and docstrings (rough check)
                        for i, line in enumerate(content.split("\n"), 1):
                            stripped = line.strip()
                            if pattern in stripped and not stripped.startswith("#") \
                                    and not stripped.startswith('"""') \
                                    and not stripped.startswith("'''"):
                                findings.append(f"{py_file.name}:{i}: {stripped[:80]}")
            except Exception:
                pass

        assert not findings, f"Potential secrets found:\n" + "\n".join(findings)

    def test_air_gapped_compliance(self, project_root):
        """4.4.1 — No external CDN or network calls in app init."""
        app_py = project_root / "app.py"
        content = app_py.read_text(encoding="utf-8")
        assert "serve_locally" in content, "Missing serve_locally setting"

        # Check no http:// or https:// CDN references in main app
        lines = content.split("\n")
        cdn_refs = [
            (i, l) for i, l in enumerate(lines, 1)
            if ("http://" in l or "https://" in l)
            and not l.strip().startswith("#")
        ]
        assert not cdn_refs, f"External URLs found in app.py: {cdn_refs}"

    def test_forensic_export_masks_pii(self):
        """4.1.8 — ForensicExporter default is include_pii=False."""
        import inspect
        from utils.forensic_export import ForensicExporter

        sig = inspect.signature(ForensicExporter.export_scorecard)
        pii_param = sig.parameters.get("include_pii")
        assert pii_param is not None, "Missing include_pii parameter"
        assert pii_param.default is False, \
            f"include_pii default is {pii_param.default}, should be False"


# =============================================================================
# SECTION 5: DATA INTEGRITY TESTS
# =============================================================================
class TestDataIntegrity:
    """Additional data integrity checks across the pipeline."""

    def test_score_normalization_bounds(self):
        """All normalized scores must be in [0, 1]."""
        from layers.l5_detection import normalize_scores

        raw = np.array([-10, 0, 5, 100, 1000])
        normalized = normalize_scores(raw)
        assert np.all(normalized >= 0), "Normalized scores below 0"
        assert np.all(normalized <= 1), "Normalized scores above 1"

    def test_normalize_constant_input(self):
        """normalize_scores handles constant input (all same value)."""
        from layers.l5_detection import normalize_scores

        constant = np.ones(100) * 5.0
        normalized = normalize_scores(constant)
        assert np.all(np.isfinite(normalized)), "NaN/Inf in constant normalization"

    def test_ensemble_empty_input(self):
        """Ensemble handles empty results gracefully."""
        from layers.l6_ensemble import Layer6Ensemble

        ens = Layer6Ensemble(method="tiered_consensus")
        # Zero methods
        empty_scores = np.zeros((100, 0))
        # Should not crash — may return zeros
        try:
            result = ens.fuse(empty_scores, [])
            assert len(result.final_scores) == 100
        except (ValueError, IndexError):
            pass  # Acceptable to raise for truly empty input

    def test_investigation_queue_ordering(self):
        """Investigation queue returns alerts sorted by score (highest first)."""
        from layers.l7_output import InvestigationQueue

        queue = InvestigationQueue(capacity=100)
        # Simulate
        scores = np.array([0.3, 0.9, 0.1, 0.7, 0.5])
        tiers = np.array(["LOW", "CRITICAL", "NORMAL", "HIGH", "MEDIUM"])
        methods = ["m1", "m2"]
        score_matrix = np.random.rand(5, 2)
        df = pd.DataFrame({"id": range(5)})

        alerts = queue.generate_alerts(df, scores, tiers, score_matrix, methods)
        alert_scores = [a.risk_score for a in alerts]
        assert alert_scores == sorted(alert_scores, reverse=True), \
            "Alerts not sorted by score descending"

    def test_column_resolver(self):
        """Role-based column resolution works."""
        from utils.column_resolver import resolve

        df = pd.DataFrame({
            "cust_id": [1], "txn_amount": [100], "txn_date": ["2024-01-01"]
        })
        pk = resolve(df, "primary_key")
        assert pk == "cust_id", f"Expected cust_id, got {pk}"


# =============================================================================
# RUN CONFIGURATION
# =============================================================================
if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short", "-x"])
