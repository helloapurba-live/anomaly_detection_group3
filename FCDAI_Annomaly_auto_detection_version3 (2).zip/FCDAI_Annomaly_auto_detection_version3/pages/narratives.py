"""
Narratives Page
===============
SHAP-style explanations for alerts.
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME


dash.register_page(__name__, path="/narratives", name="Narratives", order=5)


layout = dmc.Container(
    [
        dmc.Group(
            [
                dmc.Title("Narrative System", order=2),
                dmc.Badge("SHAP Explanations", color="cyan", variant="light"),
            ],
            justify="space-between",
            mb="lg",
        ),
        
        dmc.TextInput(
            id="input-alert-id",
            label="Enter Alert ID",
            placeholder="ALT-000001",
            leftSection=DashIconify(icon="mdi:magnify"),
            mb="md",
        ),
        
        html.Div(id="narrative-content"),
    ],
    fluid=True,
)


@callback(
    Output("narrative-content", "children"),
    Input("input-alert-id", "value"),
)
def display_narrative(alert_id):
    if not alert_id:
        return dmc.Paper(
            [
                dmc.Center(
                    dmc.Stack(
                        [
                            DashIconify(icon="mdi:file-document-outline", width=48, color=THEME.PRIMARY),
                            dmc.Text("Enter an Alert ID to view the narrative", c="dimmed"),
                        ],
                        align="center",
                        gap="md",
                    ),
                    style={"height": "200px"}
                ),
            ],
            p="xl",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        )
    
    # Sample narrative
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.Badge("Critical", color="red", size="lg"),
                    dmc.Text(alert_id, fw=700, size="lg"),
                ],
                mb="md",
            ),
            
            dmc.Divider(mb="md"),
            
            dmc.Text("Risk Assessment", fw=600, mb="sm"),
            dmc.Text(
                "🚨 **CRITICAL ALERT**: This transaction shows extreme deviation from normal patterns.",
                c="dimmed", mb="lg"
            ),
            
            dmc.Text("**Risk Score:** 95%", mb="xs"),
            dmc.Progress(value=95, color="red", mb="lg"),
            
            dmc.Text("Detection Method Breakdown", fw=600, mb="sm"),
            dmc.SimpleGrid(
                cols=2,
                mb="lg",
                children=[
                    dmc.Group([dmc.Text("Isolation Forest", size="sm"), dmc.Text("92%", fw=600)], justify="space-between"),
                    dmc.Group([dmc.Text("Autoencoder", size="sm"), dmc.Text("88%", fw=600)], justify="space-between"),
                    dmc.Group([dmc.Text("Z-Score", size="sm"), dmc.Text("85%", fw=600)], justify="space-between"),
                    dmc.Group([dmc.Text("LOF", size="sm"), dmc.Text("78%", fw=600)], justify="space-between"),
                ],
            ),
            
            dmc.Text("Recommended Actions", fw=600, mb="sm"),
            dmc.List(
                [
                    dmc.ListItem("Immediate review required"),
                    dmc.ListItem("Escalate to senior analyst"),
                    dmc.ListItem("Consider SAR filing"),
                ],
                icon=DashIconify(icon="mdi:check-circle", color=THEME.SUCCESS),
            ),
        ],
        p="lg",
        radius="md",
        withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD}
    )
