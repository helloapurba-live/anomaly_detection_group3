# FCDAI Anomaly Auto Detection Tool

**Elite Air-Gapped AML Detection Platform (7-Layer Edition)**

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      END-TO-END DATA FLOW                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   ┌────────┐  ┌────────┐  ┌────────┐  ┌────────┐               │
│   │  KYC   │  │  TXN   │  │ ALERTS │  │ CASES  │               │
│   │ 100 r  │  │ 700 r  │  │  50 r  │  │  20 r  │               │
│   └───┬────┘  └───┬────┘  └───┬────┘  └───┬────┘               │
│       └───────────┴───────────┴───────────┘                     │
│                          │                                      │
│              ┌───────────▼───────────┐                          │
│              │   LAYER 1 & 2         │                          │
│              │   Ingest + DQ         │                          │
│              └───────────┬───────────┘                          │
│                          │                                      │
│              ┌───────────▼───────────┐                          │
│              │   LAYER 3             │                          │
│              │   Feature Engineering │                          │
│              │   50+ features        │                          │
│              └───────────┬───────────┘                          │
│                          │                                      │
│              ┌───────────▼───────────┐                          │
│              │   LAYER 4             │                          │
│              │   Preprocessing       │                          │
│              │   4 matrix versions   │                          │
│              └───────────┬───────────┘                          │
│                          │                                      │
│     ┌────────────────────┼────────────────────┐                 │
│     ▼         ▼          ▼          ▼         ▼                 │
│ ┌───────┐ ┌───────┐ ┌───────┐ ┌───────┐ ┌───────┐              │
│ │STAT 5 │ │DIST 3 │ │DENS 4 │ │CLUST 3│ │TREE 2 │              │
│ └───┬───┘ └───┬───┘ └───┬───┘ └───┬───┘ └───┬───┘              │
│     │    ┌────┴────┐ ┌──┴───┐ ┌───┴───┐     │                   │
│     │    │TS 3     │ │GRAPH4│ │DEEP 2 │     │                   │
│     │    └────┬────┘ └──┬───┘ └───┬───┘     │                   │
│     └─────────┴─────────┴─────────┴─────────┘                   │
│                          │                                      │
│              ┌───────────▼───────────┐                          │
│              │   LAYER 6             │                          │
│              │   Ensemble Fusion     │                          │
│              │   26 → 1 score        │                          │
│              └───────────┬───────────┘                          │
│                          │                                      │
│              ┌───────────▼───────────┐                          │
│              │   LAYER 7             │                          │
│              │   Output/Investigation│                          │
│              └───────────┬───────────┘                          │
│                          │                                      │
│     ┌────────────────────┼────────────────────┐                 │
│     ▼                    ▼                    ▼                 │
│ ┌────────────┐    ┌────────────┐    ┌────────────┐             │
│ │INVESTIGATION│    │ NARRATIVE  │    │ AUDIT TRAIL│             │
│ │   QUEUE     │    │  SYSTEM    │    │  DATABASE  │             │
│ └────────────┘    └────────────┘    └────────────┘             │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## 🚀 Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run the application
python app.py
```

Open: **http://127.0.0.1:8071**

## 📊 Detection Methods (26 Total)

| Category | Count | Methods |
|----------|-------|---------|
| Statistical | 5 | Z-Score, IQR, Grubbs, Dixon, ESD |
| Distance | 3 | KNN, Mahalanobis, LOF |
| Density | 4 | DBSCAN, OPTICS, HDBSCAN, CBLOF |
| Clustering | 3 | K-Means, GMM, Spectral |
| Trees | 2 | IsolationForest, ExtendedIF |
| Time-Series | 3 | STL, ARIMA-Residual, Prophet |
| Graph | 4 | PageRank, HITS, Community, Centrality |
| Deep Learning | 2 | Autoencoder, VAE |

## 📄 Pages

1. **Command Center** - Executive KPIs
2. **Data Sources** - Multi-source import
3. **Pipeline Run** - Execute 7-layer pipeline
4. **Layer View** - Per-layer statistics
5. **Investigation Queue** - Alert triage
6. **Narratives** - SHAP explanations
7. **Audit Trail** - Decision logging
8. **System Health** - Admin dashboard

## 🔒 Air-Gapped Mode

This platform runs completely offline with no external dependencies after initial install.

---

**FCDAI Team** | 2026
