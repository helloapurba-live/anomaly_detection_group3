"""
Diagnostic Script to Trace Customer Count Loss
Helps identify exactly where 25 customers are lost (100 → 75)
"""
import pandas as pd
import sys
from pathlib import Path

# Add project to path
sys.path.insert(0, str(Path(__file__).parent))

from config import PATHS
from layers.l1_l2_ingestion import IngestPipeline
from utils.customer_aggregation import CustomerAggregator

def trace_customer_loss():
    """Trace customer counts through pipeline stages."""
    
    print("=" * 80)
    print("CUSTOMER LOSS DIAGNOSTIC TRACE")
    print("=" * 80)
    
    # Read source data
    data_file = PATHS.DATA_VAULT / "current.parquet"
    if not data_file.exists():
        # Try test_data as fallback
        data_file = PATHS.DATA_VAULT / "test_data.parquet"
        if not data_file.exists():
            print(f"❌ Test data not found")
            print("\nSearching for alternative data files...")
            for f in PATHS.DATA_VAULT.glob("*.parquet"):
                print(f"   Found: {f.name}")
            return
    
    print(f"\n📂 Loading: {data_file}")
    df_original = pd.read_parquet(data_file)
    
    # Check for customer column
    customer_cols = ['customer_id', 'customerid', 'cust_id', 'cid']
    customer_col = None
    for col in customer_cols:
        if col in df_original.columns:
            customer_col = col
            break
    
    if not customer_col:
        print(f"❌ No customer ID column found. Available columns: {list(df_original.columns)}")
        return
    
    print(f"\n✅ Customer column: '{customer_col}'")
    
    # Stage 1: Original Data
    print("\n" + "─" * 80)
    print("STAGE 1: ORIGINAL DATA")
    print("─" * 80)
    n_records_original = len(df_original)
    n_customers_original = df_original[customer_col].nunique()
    print(f"  Total Records: {n_records_original:,}")
    print(f"  Unique Customers: {n_customers_original:,}")
    print(f"  Avg Transactions per Customer: {n_records_original / n_customers_original:.1f}")
    
    # Check for duplicates
    n_duplicates = df_original.duplicated().sum()
    if n_duplicates > 0:
        print(f"  ⚠️  Duplicate Rows: {n_duplicates:,}")
    
    # Check for missing customer IDs
    n_missing_cid = df_original[customer_col].isna().sum()
    if n_missing_cid > 0:
        print(f"  ⚠️  Missing Customer IDs: {n_missing_cid:,}")
    
    # Stage 2: After DQ Cleansing
    print("\n" + "─" * 80)
    print("STAGE 2: AFTER DATA QUALITY CLEANSING")
    print("─" * 80)
    
    ingest = IngestPipeline()
    dq_report = ingest.dq.assess(df_original)
    df_cleansed = ingest.dq.cleanse(df_original, strategy="moderate")
    
    n_records_cleansed = len(df_cleansed)
    n_customers_cleansed = df_cleansed[customer_col].nunique()
    
    print(f"  Total Records: {n_records_cleansed:,}")
    print(f"  Unique Customers: {n_customers_cleansed:,}")
    
    records_lost = n_records_original - n_records_cleansed
    customers_lost = n_customers_original - n_customers_cleansed
    
    if records_lost > 0:
        print(f"  ⚠️  Records Lost: {records_lost:,} ({records_lost/n_records_original*100:.1f}%)")
    if customers_lost > 0:
        print(f"  🚨 CUSTOMERS LOST: {customers_lost:,} ({customers_lost/n_customers_original*100:.1f}%)")
    
    # Stage 3: After Customer Aggregation
    print("\n" + "─" * 80)
    print("STAGE 3: AFTER CUSTOMER AGGREGATION")
    print("─" * 80)
    
    # Find amount and timestamp columns
    amount_col = None
    for col in ['amount', 'txn_amount', 'transaction_amount']:
        if col in df_cleansed.columns:
            amount_col = col
            break
    
    timestamp_col = None
    for col in ['timestamp', 'txn_date', 'transaction_date', 'date']:
        if col in df_cleansed.columns:
            timestamp_col = col
            break
    
    aggregator = CustomerAggregator(customer_col=customer_col)
    df_aggregated = aggregator.aggregate(
        df_transactions=df_cleansed,
        amount_col=amount_col,
        timestamp_col=timestamp_col
    )
    
    n_customers_agg = len(df_aggregated)
    n_features = len(aggregator.aggregation_features)
    
    print(f"  Customer Records: {n_customers_agg:,}")
    print(f"  Features Generated: {n_features:,}")
    
    customers_lost_in_agg = n_customers_cleansed - n_customers_agg
    if customers_lost_in_agg > 0:
        print(f"  🚨 CUSTOMERS LOST IN AGGREGATION: {customers_lost_in_agg:,}")
    
    # Stage 4: Find missing customers
    if customers_lost > 0:
        print("\n" + "─" * 80)
        print("STAGE 4: IDENTIFYING LOST CUSTOMERS")
        print("─" * 80)
        
        original_customers = set(df_original[customer_col].dropna().unique())
        cleansed_customers = set(df_cleansed[customer_col].dropna().unique())
        
        lost_customers = original_customers - cleansed_customers
        
        if lost_customers:
            print(f"  Lost during cleansing: {len(lost_customers)} customers")
            print(f"  Examples: {list(lost_customers)[:5]}")
            
            # Analyze why they were lost
            lost_df = df_original[df_original[customer_col].isin(lost_customers)]
            print(f"\n  Analysis of lost customer records:")
            print(f"    Total records: {len(lost_df)}")
            print(f"    Records with all NaN: {lost_df.isna().all(axis=1).sum()}")
            print(f"    Duplicate records: {lost_df.duplicated().sum()}")
    
    # Summary
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print(f"  Original: {n_customers_original:,} customers, {n_records_original:,} records")
    print(f"  After DQ: {n_customers_cleansed:,} customers, {n_records_cleansed:,} records")
    print(f"  After Aggregation: {n_customers_agg:,} customers, {n_features:,} features")
    print(f"  ")
    print(f"  Total Customer Loss: {n_customers_original - n_customers_agg:,} customers")
    print(f"  Expected: 100 → Actual: {n_customers_agg}")
    print("=" * 80)
    
    # Check score matrix and method names (for blank Risk table issue)
    print("\n" + "─" * 80)
    print("CHECKING DETECTION METHODS (for blank Risk table)")
    print("─" * 80)
    
    from config import LAYERS
    
    all_methods = []
    for cat, methods in LAYERS.DETECTION_METHODS.items():
        all_methods.extend(methods)
    
    print(f"  Total Detection Methods Configured: {len(all_methods)}")
    print(f"  Detection Families: {len(LAYERS.DETECTION_METHODS)}")
    
    # Check if heavy methods would be disabled
    if n_customers_agg > LAYERS.MAX_ROWS_FOR_DISTANCE_METHODS:
        heavy_count = len(LAYERS.HEAVY_METHODS)
        print(f"  ⚠️  Dataset too large ({n_customers_agg} > {LAYERS.MAX_ROWS_FOR_DISTANCE_METHODS})")
        print(f"  ⚠️  {heavy_count} heavy methods will be DISABLED")
        print(f"  Remaining methods: {len(all_methods) - heavy_count}")
    else:
        print(f"  ✅ All {len(all_methods)} methods will run")
    
    print("\n✅ Diagnostic trace complete\n")

if __name__ == "__main__":
    trace_customer_loss()
