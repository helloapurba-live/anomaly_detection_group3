"""
Customer-Level Aggregation Utility (V6)
========================================
Aggregates transaction-level data to customer level before pipeline execution.

This module transforms raw transaction data into customer-level features,
ensuring all downstream processing operates at the customer entity level.

Author: Project Vanguard V6 Team
"""

import pandas as pd
import numpy as np
from typing import Optional, Dict, List, Tuple
from datetime import datetime, timedelta


class CustomerAggregator:
    """
    Aggregates transaction-level data to customer level.
    
    Produces comprehensive customer profiles with:
    - Transaction volume metrics
    - Amount aggregations
    - Temporal patterns
    - Transaction type distributions
    - Behavioral indicators
    """
    
    def __init__(self, customer_col: str = "customer_id"):
        """Initialize aggregator with customer identifier column."""
        self.customer_col = customer_col
        self.aggregation_features: List[str] = []
    
    def aggregate(
        self,
        df_transactions: pd.DataFrame,
        amount_col: str = "amount",
        timestamp_col: Optional[str] = "timestamp",
        type_col: Optional[str] = "txn_type",
        lookback_days: int = 365
    ) -> pd.DataFrame:
        """
        Aggregate transactions to customer level.
        
        Args:
            df_transactions: Transaction-level data
            amount_col: Column containing transaction amounts
            timestamp_col: Column containing timestamps
            type_col: Column containing transaction types
            lookback_days: Lookback period for temporal features
            
        Returns:
            DataFrame with one row per customer
        """
        if self.customer_col not in df_transactions.columns:
            raise ValueError(f"Customer column '{self.customer_col}' not found")
        
        # Initialize aggregated dataframe with customer IDs
        customers = df_transactions[self.customer_col].unique()
        df_agg = pd.DataFrame({self.customer_col: customers})
        
        # 1. Volume Metrics
        df_agg = self._aggregate_volume(df_agg, df_transactions)
        
        # 2. Amount Metrics
        if amount_col in df_transactions.columns:
            df_agg = self._aggregate_amounts(df_agg, df_transactions, amount_col)
            df_agg = self._aggregate_structuring(df_agg, df_transactions, amount_col)
        
        # 3. Temporal Patterns
        if timestamp_col and timestamp_col in df_transactions.columns:
            df_agg = self._aggregate_temporal(df_agg, df_transactions, timestamp_col, lookback_days)
        
        # 4. Transaction Type Distribution
        if type_col and type_col in df_transactions.columns:
            df_agg = self._aggregate_types(df_agg, df_transactions, type_col)
        
        # 5. Behavioral Patterns
        if amount_col in df_transactions.columns:
            df_agg = self._aggregate_behavioral(df_agg, df_transactions, amount_col)
        
        # Track generated features
        self.aggregation_features = [c for c in df_agg.columns if c != self.customer_col]
        
        return df_agg
    
    def _aggregate_volume(
        self,
        df_agg: pd.DataFrame,
        df_txn: pd.DataFrame
    ) -> pd.DataFrame:
        """Aggregate transaction volume metrics."""
        volume_stats = df_txn.groupby(self.customer_col).agg({
            self.customer_col: 'count'
        }).rename(columns={self.customer_col: 'txn_count'})
        
        return df_agg.merge(volume_stats, on=self.customer_col, how='left')
    
    def _aggregate_amounts(
        self,
        df_agg: pd.DataFrame,
        df_txn: pd.DataFrame,
        amount_col: str
    ) -> pd.DataFrame:
        """Aggregate transaction amount metrics."""
        amount_stats = df_txn.groupby(self.customer_col)[amount_col].agg([
            ('amount_total', 'sum'),
            ('amount_mean', 'mean'),
            ('amount_median', 'median'),
            ('amount_std', 'std'),
            ('amount_min', 'min'),
            ('amount_max', 'max'),
            ('amount_range', lambda x: x.max() - x.min()),
            ('amount_cv', lambda x: x.std() / (x.mean() + 1e-8))  # Coefficient of variation
        ])
        
        return df_agg.merge(amount_stats, on=self.customer_col, how='left')
    
    def _aggregate_structuring(
        self,
        df_agg: pd.DataFrame,
        df_txn: pd.DataFrame,
        amount_col: str,
        threshold: float = 10000.0,
        margin: float = 1000.0
    ) -> pd.DataFrame:
        """Detect structuring patterns (transactions just below reporting threshold)."""
        
        # Transactions just below threshold (e.g., $9,000 - $9,999)
        df_txn_copy = df_txn.copy()
        df_txn_copy['just_below_threshold'] = (
            (df_txn_copy[amount_col] >= threshold - margin) &
            (df_txn_copy[amount_col] < threshold)
        ).astype(int)
        
        structuring_stats = df_txn_copy.groupby(self.customer_col).agg({
            'just_below_threshold': [
                ('count_just_below_10k', 'sum'),
                ('pct_just_below_10k', 'mean')
            ]
        })
        structuring_stats.columns = ['_'.join(col).strip() for col in structuring_stats.columns]
        
        return df_agg.merge(structuring_stats, on=self.customer_col, how='left')
    
    def _aggregate_temporal(
        self,
        df_agg: pd.DataFrame,
        df_txn: pd.DataFrame,
        timestamp_col: str,
        lookback_days: int
    ) -> pd.DataFrame:
        """Aggregate temporal patterns."""
        df_txn_copy = df_txn.copy()
        
        # Ensure timestamp is datetime
        if not pd.api.types.is_datetime64_any_dtype(df_txn_copy[timestamp_col]):
            df_txn_copy[timestamp_col] = pd.to_datetime(df_txn_copy[timestamp_col], errors='coerce')
        
        # Extract time features
        df_txn_copy['hour'] = df_txn_copy[timestamp_col].dt.hour
        df_txn_copy['day_of_week'] = df_txn_copy[timestamp_col].dt.dayofweek
        df_txn_copy['is_weekend'] = (df_txn_copy['day_of_week'] >= 5).astype(int)
        df_txn_copy['is_night'] = ((df_txn_copy['hour'] >= 22) | (df_txn_copy['hour'] <= 6)).astype(int)
        
        # Aggregate temporal patterns
        temporal_stats = df_txn_copy.groupby(self.customer_col).agg({
            'is_weekend': [('weekend_txn_count', 'sum'), ('weekend_txn_pct', 'mean')],
            'is_night': [('night_txn_count', 'sum'), ('night_txn_pct', 'mean')],
            'hour': [('hour_mean', 'mean'), ('hour_std', 'std')]
        })
        temporal_stats.columns = ['_'.join(col).strip() for col in temporal_stats.columns]
        
        # Account age (days since first transaction)
        first_txn = df_txn_copy.groupby(self.customer_col)[timestamp_col].min().rename('first_txn_date')
        last_txn = df_txn_copy.groupby(self.customer_col)[timestamp_col].max().rename('last_txn_date')
        
        temporal_range = pd.concat([first_txn, last_txn], axis=1)
        temporal_range['account_age_days'] = (temporal_range['last_txn_date'] - temporal_range['first_txn_date']).dt.days
        temporal_range['txn_frequency'] = 1.0  # Placeholder, will be calculated from txn_count
        
        df_agg = df_agg.merge(temporal_stats, on=self.customer_col, how='left')
        df_agg = df_agg.merge(temporal_range[['account_age_days']], on=self.customer_col, how='left')
        
        # Calculate transaction frequency (txns per day)
        if 'txn_count' in df_agg.columns and 'account_age_days' in df_agg.columns:
            df_agg['txn_frequency'] = df_agg['txn_count'] / (df_agg['account_age_days'] + 1)
        
        return df_agg
    
    def _aggregate_types(
        self,
        df_agg: pd.DataFrame,
        df_txn: pd.DataFrame,
        type_col: str
    ) -> pd.DataFrame:
        """Aggregate transaction type distributions."""
        # One-hot encode transaction types and sum per customer
        type_dummies = pd.get_dummies(df_txn[type_col], prefix='txn_type')
        type_dummies[self.customer_col] = df_txn[self.customer_col]
        
        type_counts = type_dummies.groupby(self.customer_col).sum()
        
        # Calculate percentages
        total_txns = type_counts.sum(axis=1)
        type_pcts = type_counts.div(total_txns, axis=0).add_suffix('_pct')
        
        # Merge both counts and percentages
        type_stats = pd.concat([type_counts, type_pcts], axis=1)
        
        return df_agg.merge(type_stats, on=self.customer_col, how='left')
    
    def _aggregate_behavioral(
        self,
        df_agg: pd.DataFrame,
        df_txn: pd.DataFrame,
        amount_col: str
    ) -> pd.DataFrame:
        """Aggregate behavioral indicators."""
        # Calculate concentration metrics
        df_txn_copy = df_txn.copy()
        
        # Gini coefficient (transaction amount concentration)
        def gini(x):
            """Calculate Gini coefficient."""
            if len(x) < 2:
                return 0.0
            x_sorted = np.sort(x)
            n = len(x)
            index = np.arange(1, n + 1)
            return (2 * np.sum(index * x_sorted)) / (n * np.sum(x_sorted)) - (n + 1) / n
        
        # Entropy (transaction amount diversity)
        def entropy(x):
            """Calculate Shannon entropy of amounts."""
            if len(x) < 2:
                return 0.0
            # Bin amounts into deciles
            bins = pd.qcut(x, q=min(10, len(x)), duplicates='drop', labels=False)
            value_counts = pd.Series(bins).value_counts()
            probs = value_counts / len(x)
            return -np.sum(probs * np.log2(probs + 1e-8))
        
        behavioral_stats = df_txn_copy.groupby(self.customer_col)[amount_col].agg([
            ('amount_gini', gini),
            ('amount_entropy', entropy),
            ('amount_skew', lambda x: pd.Series(x).skew()),
            ('amount_kurtosis', lambda x: pd.Series(x).kurtosis())
        ])
        
        return df_agg.merge(behavioral_stats, on=self.customer_col, how='left')
    
    def get_feature_categories(self) -> Dict[str, List[str]]:
        """Return aggregated features grouped by category."""
        categories = {
            "volume": [f for f in self.aggregation_features if 'count' in f or 'frequency' in f],
            "amount": [f for f in self.aggregation_features if 'amount_' in f],
            "structuring": [f for f in self.aggregation_features if 'just_below' in f or '10k' in f],
            "temporal": [f for f in self.aggregation_features if any(x in f for x in ['hour', 'day', 'weekend', 'night', 'age'])],
            "type": [f for f in self.aggregation_features if 'txn_type' in f],
            "behavioral": [f for f in self.aggregation_features if any(x in f for x in ['gini', 'entropy', 'skew', 'kurtosis'])]
        }
        return categories
