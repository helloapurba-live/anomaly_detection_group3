"""
Pipeline Run Page — Execution Engine
======================================
Execute and monitor the 7-layer pipeline.
• Data source selector: Sample or Actual
• Progress bar with per-layer status
• Per-layer timing table
• Risk by Detection Family table
• Risk by Ensemble Method table
• Customer-level roll-up
• Persistent results to vault
"""

import dash
from dash import html, dcc, callback, Input, Output, State, ctx
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import dash_ag_grid as dag
import pandas as pd
import numpy as np
import time
import json
import sys
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS, LAYERS, APP

dash.register_page(__name__, path="/pipeline", name="Pipeline Run", order=2)


# =============================================================================
# HELPER: Layer step card
# =============================================================================
def layer_step(number, name, desc):
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.Avatar(number, radius="xl", color="cyan", variant="filled"),
                    dmc.Stack([dmc.Text(name, fw=600), dmc.Text(desc, size="sm", c="dimmed")], gap=0),
                    dmc.ThemeIcon(
                        DashIconify(icon="mdi:clock-outline", width=20),
                        color="gray", variant="light",
                    ),
                ],
                justify="space-between",
            ),
        ],
        p="sm", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD, "marginBottom": "8px"},
    )


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Container(
    [
        dmc.Group(
            [
                dmc.Title("Execution Engine", order=2),
                dmc.Badge("7 Layers | 22 Methods", color="cyan", variant="light"),
            ],
            justify="space-between",
            mb="lg",
        ),

        dmc.SimpleGrid(
            cols={"base": 1, "lg": 2},
            spacing="lg",
            children=[
                # Left: Pipeline Layers
                dmc.Paper(
                    [
                        dmc.Text("Pipeline Layers", fw=600, mb="md"),
                        layer_step("1-2", "Ingest + Data Quality", "Load sources, validate, DQ scoring"),
                        layer_step("3", "Feature Engineering", "50+ features: velocity, aggregates, ratios"),
                        layer_step("4", "Preprocessing", "4 matrix versions: raw, scaled, PCA"),
                        layer_step("5", "Detection", "22 methods across 8 categories"),
                        layer_step("6", "Ensemble Fusion", "Score fusion → Risk tiers"),
                        layer_step("7", "Output", "Investigation queue, narratives, audit"),
                    ],
                    p="md", radius="md", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD},
                ),

                # Right: Controls
                dmc.Stack(
                    [
                        # ── DATA SOURCE SELECTOR ──
                        dmc.Paper(
                            [
                                dmc.Text("Data Source", fw=600, mb="md"),
                                dmc.RadioGroup(
                                    id="pipeline-data-source",
                                    children=dmc.Stack([
                                        dmc.Radio(
                                            label="Data Sources (loaded from Data Sources page)",
                                            value="actual",
                                        ),
                                        dmc.Radio(
                                            label="Quick Sample (generate if vault is empty)",
                                            value="sample",
                                        ),
                                    ], gap="xs"),
                                    value="actual",
                                    mb="md",
                                ),
                                html.Div(id="pipeline-data-status"),
                                dmc.Text(
                                    "Manage data on the Data Sources page →",
                                    size="xs", c="dimmed",
                                ),
                                dcc.Link(
                                    dmc.Button(
                                        "Go to Data Sources",
                                        leftSection=DashIconify(icon="mdi:database-import"),
                                        color="blue", variant="subtle", size="xs", mt="xs",
                                    ),
                                    href="/sources",
                                ),
                            ],
                            p="md", radius="md", withBorder=True,
                            style={"backgroundColor": THEME.DARK_BG_CARD},
                        ),

                        # ── EXECUTION SETTINGS ──
                        dmc.Paper(
                            [
                                dmc.Text("Execution Settings", fw=600, mb="md"),
                                dmc.Select(
                                    id="pipeline-ensemble",
                                    label="Ensemble Method",
                                    data=[
                                        {"value": "weighted_average", "label": "Weighted Average"},
                                        {"value": "max", "label": "Max Score"},
                                        {"value": "voting", "label": "Voting"},
                                        {"value": "stacking", "label": "Stacking"},
                                    ],
                                    value="weighted_average",
                                    mb="md",
                                ),
                                dmc.MultiSelect(
                                    id="pipeline-categories",
                                    label="Detection Categories",
                                    data=[
                                        {"value": "statistical", "label": "Statistical (5)"},
                                        {"value": "distance", "label": "Distance (3)"},
                                        {"value": "density", "label": "Density (4)"},
                                        {"value": "clustering", "label": "Clustering (3)"},
                                        {"value": "trees", "label": "Trees (2)"},
                                        {"value": "timeseries", "label": "Time-Series (3)"},
                                        {"value": "graph", "label": "Graph (4)"},
                                        {"value": "deep_learning", "label": "Deep Learning (2)"},
                                    ],
                                    value=["statistical", "distance", "density", "clustering",
                                           "trees", "timeseries", "graph", "deep_learning"],
                                    mb="lg",
                                ),
                                dmc.Group(
                                    [
                                        dmc.Button(
                                            "Run Pipeline",
                                            id="pipeline-btn-run",
                                            leftSection=DashIconify(icon="mdi:rocket-launch"),
                                            color="cyan", size="lg", style={"flex": 1},
                                        ),
                                        dmc.Button(
                                            "Stop",
                                            id="pipeline-btn-stop",
                                            leftSection=DashIconify(icon="mdi:stop"),
                                            color="orange", variant="outline", size="lg",
                                        ),
                                    ],
                                    grow=True,
                                ),
                                dmc.Button(
                                    "Reset Pipeline",
                                    id="pipeline-btn-reset",
                                    leftSection=DashIconify(icon="mdi:refresh"),
                                    color="red", variant="subtle", size="sm", mt="sm", fullWidth=True,
                                ),
                            ],
                            p="md", radius="md", withBorder=True,
                            style={"backgroundColor": THEME.DARK_BG_CARD},
                        ),
                    ],
                ),
            ],
        ),

        dmc.Space(h="lg"),

        # ── PROGRESS BAR ──────────────────────────────────────
        dmc.Paper(
            [
                dmc.Text("Pipeline Progress", fw=600, mb="sm"),
                dmc.Progress(
                    id="pipeline-progress-bar",
                    value=0, size="xl", radius="xl",
                    striped=True, animated=False,
                    color="cyan",
                ),
                dmc.Text(id="pipeline-progress-label", size="sm", c="dimmed", mt="xs"),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
            mb="lg",
        ),

        # ── RESULTS AREA ─────────────────────────────────────
        html.Div(id="pipeline-results-area"),

        # Hidden outputs
        html.Div(id="pipeline-stop-output", style={"display": "none"}),
        html.Div(id="pipeline-reset-output", style={"display": "none"}),

        # Store: flag to distinguish "new run" vs "page load"
        dcc.Store(id="pipeline-run-flag", data=0, storage_type="memory"),

        # Polling interval for progress
        dcc.Interval(id="pipeline-poll", interval=2000, n_intervals=0),

        # Page-load trigger (fires once on page mount)
        dcc.Interval(id="pipeline-load-trigger", interval=1000, max_intervals=1, n_intervals=0),
    ],
    fluid=True,
)


# =============================================================================
# DATA SOURCE STATUS
# =============================================================================
@callback(
    Output("pipeline-data-status", "children"),
    Input("pipeline-data-source", "value"),
)
def update_data_status(source_type):
    from utils.data_io import data_vault

    if source_type == "sample":
        return dmc.Alert(
            "Will auto-generate 100 customers with 8 tables.",
            color="blue", icon=DashIconify(icon="mdi:information"), mb="sm",
        )
    else:
        sources = data_vault.load_sources()
        df_merged = data_vault.get_data()
        if sources:
            total_rows = sum(len(df) for df in sources.values())
            merged_rows = len(df_merged) if df_merged is not None else 0
            # V6: Count unique customers
            customer_count = 0
            if df_merged is not None and not df_merged.empty:
                for col in ['customer_id', 'party_id', 'customer_name']:
                    if col in df_merged.columns:
                        customer_count = df_merged[col].nunique()
                        break
            return dmc.Alert(
                f"Actual data: {len(sources)} tables, {total_rows:,} total rows, "
                f"{merged_rows:,} merged records → **{customer_count:,} unique customers** ready for customer-level processing.",
                color="green", icon=DashIconify(icon="mdi:check-circle"), mb="sm",
            )
        else:
            return dmc.Alert(
                "No actual data found. Upload data on the Data Sources page first.",
                color="orange", icon=DashIconify(icon="mdi:alert"), mb="sm",
            )


# =============================================================================
# PROGRESS POLLING
# =============================================================================
@callback(
    Output("pipeline-progress-bar", "value"),
    Output("pipeline-progress-label", "children"),
    Output("pipeline-progress-bar", "animated"),
    Input("pipeline-poll", "n_intervals"),
)
def poll_progress(n):
    """Poll pipeline_status.json for progress updates."""
    status_file = PATHS.DATA_VAULT / "pipeline_status.json"
    if not status_file.exists():
        return 0, "Ready — select data source and click 'Run Pipeline'", False

    try:
        with open(status_file, "r") as f:
            status = json.load(f)

        progress = status.get("progress", 0)
        state = status.get("status", "unknown")
        stage = status.get("stage", "")

        if state == "running":
            return progress, f"⏳ {stage} ({progress}%)", True
        elif state == "completed":
            return 100, f"✅ {stage}", False
        elif state == "failed":
            return progress, f"❌ Failed: {status.get('error', 'Unknown')}", False
        else:
            return progress, stage, False
    except Exception:
        return dash.no_update, dash.no_update, dash.no_update


# =============================================================================
# STOP BUTTON
# =============================================================================
@callback(
    Output("pipeline-stop-output", "children"),
    Input("pipeline-btn-stop", "n_clicks"),
    prevent_initial_call=True,
)
def stop_pipeline(n):
    import os, signal
    pid_file = PATHS.DATA_VAULT / "pipeline.pid"
    if pid_file.exists():
        try:
            with open(pid_file, "r") as f:
                pid = int(f.read().strip())
            os.kill(pid, signal.SIGTERM)
            return f"Stopped PID {pid}"
        except Exception as e:
            return str(e)
    return "No active pipeline"


# =============================================================================
# RESET BUTTON
# =============================================================================
@callback(
    Output("pipeline-reset-output", "children"),
    Output("pipeline-results-area", "children", allow_duplicate=True),
    Output("pipeline-progress-bar", "value", allow_duplicate=True),
    Output("pipeline-progress-label", "children", allow_duplicate=True),
    Input("pipeline-btn-reset", "n_clicks"),
    prevent_initial_call=True,
)
def reset_pipeline(n):
    """Clear all pipeline results and scored data."""
    from utils.data_io import data_vault
    import shutil
    
    try:
        # Clear scored data
        scored_path = PATHS.DATA_VAULT / "scored.parquet"
        if scored_path.exists():
            scored_path.unlink()
        
        # Clear pipeline result
        result_path = PATHS.DATA_VAULT / "pipeline_result.json"
        if result_path.exists():
            result_path.unlink()
        
        # Clear status
        status_path = PATHS.DATA_VAULT / "pipeline_status.json"
        if status_path.exists():
            status_path.unlink()
        
        # Reload vault to clear memory
        data_vault._scored_data = None
        data_vault._pipeline_result = {}
        
        return (
            "Pipeline reset complete",
            dmc.Alert(
                "Pipeline reset successfully. All scored data and results cleared.",
                color="green",
                icon=DashIconify(icon="mdi:check-circle"),
                withCloseButton=True,
            ),
            0,
            "Ready — select data source and click 'Run Pipeline'"
        )
    except Exception as e:
        return str(e), dmc.Alert(f"Reset failed: {str(e)}", color="red"), dash.no_update, dash.no_update


# =============================================================================
# RUN PIPELINE (main callback)
# =============================================================================
@callback(
    Output("pipeline-results-area", "children"),
    Output("store-pipeline-complete", "data"),
    Input("pipeline-btn-run", "n_clicks"),
    State("pipeline-data-source", "value"),
    State("pipeline-ensemble", "value"),
    State("pipeline-categories", "value"),
    prevent_initial_call=True,
)
def run_pipeline(n_clicks, data_source, ensemble_method, categories):
    if not n_clicks:
        return "", dash.no_update

    try:
        from pipeline import VanguardPipeline
        from utils.data_io import data_vault
        from utils.data_gen import DataGenerator

        # ── 1. Load or generate data ──
        df_merged = None
        sources = {}

        if data_source == "actual":
            sources = data_vault.load_sources()
            df_merged = data_vault.get_data()

            if df_merged is None or df_merged.empty:
                if sources:
                    # Build merged view from sources
                    df_tx = sources.get("transactions", pd.DataFrame())
                    df_acc = sources.get("account", pd.DataFrame())
                    df_party = sources.get("party", pd.DataFrame())

                    if not df_tx.empty:
                        df_merged = df_tx.copy()
                        if not df_acc.empty and "account_id" in df_tx.columns and "account_id" in df_acc.columns:
                            df_merged = df_merged.merge(df_acc, on="account_id", how="left", suffixes=("", "_acc"))
                        if not df_party.empty and "party_id" in df_merged.columns and "party_id" in df_party.columns:
                            df_merged = df_merged.merge(df_party, on="party_id", how="left", suffixes=("", "_party"))
                        data_vault.set_current_data(df_merged, label="actual_merged")
                    else:
                        # No transactions — use largest table
                        biggest = max(sources.values(), key=len)
                        df_merged = biggest
                        data_vault.set_current_data(df_merged, label="actual_fallback")
                else:
                    return dmc.Alert(
                        "No actual data found. Go to Data Sources page to upload or generate data.",
                        color="orange", icon=DashIconify(icon="mdi:alert"),
                    )

        if data_source == "sample" or (df_merged is None or df_merged.empty):
            # Generate sample data
            dg = DataGenerator()
            schema = dg.generate_full_schema(100)
            data_vault.save_sources(schema)
            sources = schema

            # Build merged view
            df_tx = schema.get("transactions", pd.DataFrame())
            df_acc = schema.get("account", pd.DataFrame())
            df_party = schema.get("party", pd.DataFrame())
            df_merged = df_tx.copy()
            if not df_acc.empty and "account_id" in df_tx.columns and "account_id" in df_acc.columns:
                df_merged = df_merged.merge(df_acc, on="account_id", how="left", suffixes=("", "_acc"))
            if not df_party.empty and "party_id" in df_merged.columns and "party_id" in df_party.columns:
                df_merged = df_merged.merge(df_party, on="party_id", how="left", suffixes=("", "_party"))
            data_vault.set_current_data(df_merged, label="sample_100_cust")

        # ── 2. Determine which methods to run ──
        methods = []
        for cat in (categories or []):
            if cat in LAYERS.DETECTION_METHODS:
                methods.extend(LAYERS.DETECTION_METHODS[cat])

        # ── 3. Run pipeline with merged_df ──
        pipeline = VanguardPipeline()
        result = pipeline.run(
            sources if sources else {"merged": df_merged},
            detection_methods=methods if methods else None,
            ensemble_method=ensemble_method,
            merged_df=df_merged,
        )

        if result.success:
            # ── 4. Persist results ──
            pipeline.save_results()
            data_vault.set_scored_data(result.df_scored)

            # Build per-method score summary
            score_matrix, method_names = pipeline.detection.get_score_matrix()
            method_scores = []
            for i, m in enumerate(method_names):
                col_scores = score_matrix[:, i]
                cat = _get_category(m)
                method_scores.append({
                    "method": m,
                    "category": cat,
                    "mean_score": round(float(col_scores.mean()), 4),
                    "max_score": round(float(col_scores.max()), 4),
                    "anomalies": int((col_scores > 0.5).sum()),
                })

            # Build layer timings
            layer_timings = getattr(result, 'layer_timings', {})

            # ── 5. Build risk-by-family table ──
            risk_by_family = _build_risk_by_family(result.df_scored, method_names, score_matrix)

            # ── 6. Build risk-by-ensemble table ──
            risk_by_ensemble = _build_risk_by_ensemble(result.df_scored, score_matrix, method_names)

            # Save pipeline result JSON for dashboard
            result_json = {
                "success": True,
                "timestamp": result.timestamp,
                "records_processed": result.records_processed,
                "dq_score": result.dq_score,
                "features_generated": result.features_generated,
                "methods_run": result.methods_run,
                "alerts_generated": result.alerts_generated,
                "tier_distribution": result.tier_distribution,
                "execution_time_ms": result.execution_time_ms,
                "method_scores": method_scores,
                "layer_timings": layer_timings,
                "data_source": data_source,
                "risk_by_family": risk_by_family,
                "risk_by_ensemble": risk_by_ensemble,
            }
            data_vault.save_pipeline_result(result_json)

            return _build_results_ui(result, method_scores, layer_timings,
                                      risk_by_family, risk_by_ensemble, data_source), time.time()
        else:
            return dmc.Alert(
                f"Pipeline failed: {result.error}",
                color="red", icon=DashIconify(icon="mdi:alert"),
            ), dash.no_update

    except Exception as e:
        import traceback
        return dmc.Alert(
            f"Error: {e}\n{traceback.format_exc()[:500]}",
            color="red", icon=DashIconify(icon="mdi:alert"),
        ), dash.no_update


def _get_category(method_name):
    for cat, methods in LAYERS.DETECTION_METHODS.items():
        if method_name in methods:
            return cat.replace("_", " ").title()
    return "Unknown"


# =============================================================================
# RISK BY FAMILY (per detection category)
# =============================================================================
def _build_risk_by_family(df_scored, method_names, score_matrix):
    """Build risk counts per detection family (category)."""
    rows = []
    for cat_key, cat_methods in LAYERS.DETECTION_METHODS.items():
        cat_label = cat_key.replace("_", " ").title()
        # Indices of methods in this category
        cat_indices = [i for i, m in enumerate(method_names) if m in cat_methods]
        if not cat_indices:
            rows.append({
                "Family": cat_label, "Methods": 0,
                "Critical": 0, "High": 0, "Medium": 0, "Low": 0,
            })
            continue

        # V6: Average score across methods in this family for each CUSTOMER
        family_scores = score_matrix[:, cat_indices].mean(axis=1)

        # Apply risk tier thresholds to family-level scores (CUSTOMER level)
        critical = int((family_scores > 0.8).sum())
        high = int(((family_scores > 0.6) & (family_scores <= 0.8)).sum())
        medium = int(((family_scores > 0.4) & (family_scores <= 0.6)).sum())
        low = int((family_scores <= 0.4).sum())

        rows.append({
            "Family": cat_label,
            "Methods": len(cat_indices),
            "Critical": critical,
            "High": high,
            "Medium": medium,
            "Low": low,
        })

    return rows


# =============================================================================
# RISK BY ENSEMBLE METHOD — all 5 methods
# =============================================================================
def _build_risk_by_ensemble(df_scored, score_matrix=None, method_names=None):
    """Build risk counts for ALL 5 ensemble methods.

    Computes each method's fusion, assigns risk tiers, and returns a
    multi-row table so the user can compare ensemble strategies.
    """
    if "anomaly_score" not in df_scored.columns:
        return []

    score_cols = [c for c in df_scored.columns if c.startswith("score_")]
    if not score_cols:
        return []

    # Build score matrix from df if not provided
    if score_matrix is None:
        score_matrix = df_scored[score_cols].fillna(0).values
        method_names = [c.replace("score_", "") for c in score_cols]

    n = len(df_scored)
    thresholds = {"Critical": 0.8, "High": 0.6, "Medium": 0.4}

    def _tier_counts(scores):
        s = np.array(scores)
        c = int((s > 0.8).sum())
        h = int(((s > 0.6) & (s <= 0.8)).sum())
        m = int(((s > 0.4) & (s <= 0.6)).sum())
        l = int((s <= 0.4).sum())
        ar = f"{(s > 0.5).mean():.1%}"
        return c, h, m, l, ar

    rows = []

    # 1. Weighted Average (concordance-based — the default)
    wa_scores = df_scored["anomaly_score"].values
    c, h, m, l, ar = _tier_counts(wa_scores)
    # V6: Customer-level ensemble methods
    rows.append({"Ensemble Method": "Weighted Average (Concordance)", "Total Customers": n,
                 "Critical": c, "High": h, "Medium": m, "Low": l, "Anomaly Rate": ar})

    # 2. Max Score
    max_scores = np.clip(score_matrix.max(axis=1), 0, 1)
    c, h, m, l, ar = _tier_counts(max_scores)
    rows.append({"Ensemble Method": "Max Score", "Total Customers": n,
                 "Critical": c, "High": h, "Medium": m, "Low": l, "Anomaly Rate": ar})

    # 3. Voting (threshold 0.5)
    votes = (score_matrix > 0.5).sum(axis=1) / max(score_matrix.shape[1], 1)
    c, h, m, l, ar = _tier_counts(votes)
    rows.append({"Ensemble Method": "Majority Voting", "Total Customers": n,
                 "Critical": c, "High": h, "Medium": m, "Low": l, "Anomaly Rate": ar})

    # 4. Stacking (robust median + IQR)
    medians = np.median(score_matrix, axis=1)
    iqr = np.percentile(score_matrix, 75, axis=1) - np.percentile(score_matrix, 25, axis=1)
    stacking_scores = np.clip(0.6 * medians + 0.4 * iqr, 0, 1)
    c, h, m, l, ar = _tier_counts(stacking_scores)
    rows.append({"Ensemble Method": "Stacking (Median+IQR)", "Total Customers": n,
                 "Critical": c, "High": h, "Medium": m, "Low": l, "Anomaly Rate": ar})

    # 5. Rank Fusion
    from scipy.stats import rankdata
    rank_matrix = np.zeros_like(score_matrix)
    for j in range(score_matrix.shape[1]):
        rank_matrix[:, j] = rankdata(score_matrix[:, j]) / score_matrix.shape[0]
    rank_scores = np.clip(rank_matrix.mean(axis=1), 0, 1)
    c, h, m, l, ar = _tier_counts(rank_scores)
    rows.append({"Ensemble Method": "Rank Fusion", "Total Customers": n,
                 "Critical": c, "High": h, "Medium": m, "Low": l, "Anomaly Rate": ar})

    return rows


# =============================================================================
# RESULTS UI BUILDER
# =============================================================================
def _build_results_ui(result, method_scores, layer_timings,
                       risk_by_family, risk_by_ensemble, data_source):
    """Build the results section after successful pipeline run."""
    return dmc.Stack(
        [
            # ── Success Alert ──
            dmc.Alert(
                f"Pipeline completed in {result.execution_time_ms:.0f}ms "
                f"({'Sample' if data_source == 'sample' else 'Actual'} data)",
                color="green",
                icon=DashIconify(icon="mdi:check-circle"),
                withCloseButton=True,
            ),

            # ── KPI Summary ──
            dmc.SimpleGrid(
                cols={"base": 2, "md": 3, "lg": 6},
                spacing="sm",
                children=[
                    _kpi_badge("Records", f"{result.records_processed:,}", "mdi:database", "cyan"),
                    _kpi_badge("DQ Score", f"{result.dq_score:.0%}", "mdi:check-decagram", "green"),
                    _kpi_badge("Features", str(result.features_generated), "mdi:cog", "blue"),
                    _kpi_badge("Methods", str(result.methods_run), "mdi:magnify-scan", "indigo"),
                    _kpi_badge("Alerts", str(result.alerts_generated), "mdi:alert", "orange"),
                    _kpi_badge("Time", f"{result.execution_time_ms:.0f}ms", "mdi:timer", "teal"),
                ],
            ),

            # ── Risk Tier Distribution ──
            dmc.Paper(
                [
                    dmc.Text("Risk Tier Distribution", fw=600, mb="sm"),
                    dmc.Group(
                        [
                            dmc.Badge(f"Critical: {result.tier_distribution.get('Critical', 0)}", color="red", size="lg"),
                            dmc.Badge(f"High: {result.tier_distribution.get('High', 0)}", color="orange", size="lg"),
                            dmc.Badge(f"Medium: {result.tier_distribution.get('Medium', 0)}", color="yellow", size="lg"),
                            dmc.Badge(f"Low: {result.tier_distribution.get('Low', 0)}", color="green", size="lg"),
                        ],
                    ),
                ],
                p="md", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD},
            ),

            # ── Risk by Detection Family ──
            dmc.Paper(
                [
                    dmc.Text("Risk by Detection Family", fw=600, mb="sm"),
                    dmc.Text(
                        "Average score per family applied to risk thresholds (Critical >0.8, High >0.6, Medium >0.4, Low ≤0.4)",
                        size="xs", c="dimmed", mb="sm",
                    ),
                    dag.AgGrid(
                        id="pipeline-risk-by-family",
                        rowData=risk_by_family,
                        columnDefs=[
                            {"field": "Family", "headerName": "Detection Family", "sortable": True, "filter": True},
                            {"field": "Methods", "headerName": "Methods", "sortable": True},
                            {"field": "Critical", "headerName": "Critical", "sortable": True,
                             "cellStyle": {"color": "#FF5252", "fontWeight": 700}},
                            {"field": "High", "headerName": "High", "sortable": True,
                             "cellStyle": {"color": "#FF9800", "fontWeight": 600}},
                            {"field": "Medium", "headerName": "Medium", "sortable": True,
                             "cellStyle": {"color": "#FFC107"}},
                            {"field": "Low", "headerName": "Low", "sortable": True,
                             "cellStyle": {"color": "#4CAF50"}},
                        ],
                        defaultColDef={"flex": 1, "minWidth": 90, "resizable": True},
                        dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
                        style={"height": None, "width": "100%"},
                        className="ag-theme-alpine-dark",
                    ),
                ],
                p="md", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD},
            ),

            # ── Risk by Ensemble Method ──
            dmc.Paper(
                [
                    dmc.Text("Risk by Ensemble Method (Customer Level)", fw=600, mb="sm"),
                    dmc.Text(
                        "Final fused scores after ensemble aggregation at customer level, classified into risk tiers",
                        size="xs", c="dimmed", mb="sm",
                    ),
                    dag.AgGrid(
                        id="pipeline-risk-by-ensemble",
                        rowData=risk_by_ensemble,
                        columnDefs=[
                            {"field": "Ensemble Method", "headerName": "Ensemble Method", "sortable": True},
                            {"field": "Total Customers", "headerName": "Total Customers", "sortable": True},
                            {"field": "Critical", "headerName": "Critical", "sortable": True,
                             "cellStyle": {"color": "#FF5252", "fontWeight": 700}},
                            {"field": "High", "headerName": "High", "sortable": True,
                             "cellStyle": {"color": "#FF9800", "fontWeight": 600}},
                            {"field": "Medium", "headerName": "Medium", "sortable": True,
                             "cellStyle": {"color": "#FFC107"}},
                            {"field": "Low", "headerName": "Low", "sortable": True,
                             "cellStyle": {"color": "#4CAF50"}},
                            {"field": "Anomaly Rate", "headerName": "Anomaly Rate"},
                        ],
                        defaultColDef={"flex": 1, "minWidth": 100, "resizable": True},
                        dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
                        style={"height": None, "width": "100%"},
                        className="ag-theme-alpine-dark",
                    ),
                ],
                p="md", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD},
            ),

            # ── Per-Layer Timing ──
            _build_timing_section(layer_timings),

            # ── Per-Method Scores (AG Grid) ──
            dmc.Paper(
                [
                    dmc.Text("Per-Method Anomaly Scores", fw=600, mb="sm"),
                    dag.AgGrid(
                        id="pipeline-method-scores-grid",
                        rowData=method_scores,
                        columnDefs=[
                            {"field": "method", "headerName": "Method", "sortable": True, "filter": True},
                            {"field": "category", "headerName": "Category", "sortable": True, "filter": True},
                            {"field": "mean_score", "headerName": "Mean Score", "sortable": True,
                             "valueFormatter": {"function": "d3.format('.4f')(params.value)"}},
                            {"field": "max_score", "headerName": "Max Score", "sortable": True,
                             "valueFormatter": {"function": "d3.format('.4f')(params.value)"}},
                            {"field": "anomalies", "headerName": "Anomalies (>0.5)", "sortable": True},
                        ],
                        defaultColDef={"flex": 1, "minWidth": 120, "resizable": True},
                        dashGridOptions={"domLayout": "autoHeight", "animateRows": True, "pagination": True, "paginationPageSize": 10},
                        style={"height": None, "width": "100%"},
                        className="ag-theme-alpine-dark",
                    ),
                ],
                p="md", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD},
            ),

            # ── Scored Data Preview ──
            _build_scored_preview(result.df_scored),
        ],
        gap="md",
    )


def _kpi_badge(label, value, icon, color):
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.ThemeIcon(
                        DashIconify(icon=icon, width=20),
                        color=color, variant="light", size="lg",
                    ),
                    dmc.Stack(
                        [
                            dmc.Text(label, size="xs", c="dimmed"),
                            dmc.Text(value, size="lg", fw=700),
                        ],
                        gap=0,
                    ),
                ],
                gap="sm",
            ),
        ],
        p="sm", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD},
    )


def _build_timing_section(layer_timings):
    if not layer_timings:
        return dmc.Paper(
            [dmc.Text("Layer Timing", fw=600, mb="sm"),
             dmc.Text("Timing data not available for this run.", size="sm", c="dimmed")],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
        )

    rows = []
    for layer, elapsed in layer_timings.items():
        rows.append({"layer": layer, "time_s": round(elapsed, 3), "status": "✓"})

    return dmc.Paper(
        [
            dmc.Text("Layer Timing", fw=600, mb="sm"),
            dag.AgGrid(
                id="pipeline-timing-grid",
                rowData=rows,
                columnDefs=[
                    {"field": "layer", "headerName": "Layer", "flex": 2},
                    {"field": "time_s", "headerName": "Time (s)", "flex": 1},
                    {"field": "status", "headerName": "Status", "flex": 1},
                ],
                defaultColDef={"resizable": True},
                dashGridOptions={"domLayout": "autoHeight"},
                style={"height": None, "width": "100%"},
                className="ag-theme-alpine-dark",
            ),
        ],
        p="md", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD},
    )


def _build_scored_preview(df_scored):
    if df_scored is None or df_scored.empty:
        return None

    # Create a working copy
    preview = df_scored.copy()
    
    # Generate customer_name if it doesn't exist
    if "customer_name" not in preview.columns and "customer_id" in preview.columns:
        preview["customer_name"] = preview["customer_id"].apply(
            lambda x: f"Customer {str(x)}" if pd.notna(x) else "Unknown"
        )
    
    # Build display columns order: customer info + scores + risk tier
    display_cols = []
    
    # 1. Customer identification columns (always first)
    for col in ["customer_name", "customer_id", "party_id"]:
        if col in preview.columns:
            display_cols.append(col)
    
    # 2. Add anomaly score and risk tier
    if "anomaly_score" in preview.columns:
        display_cols.append("anomaly_score")
    if "risk_tier" in preview.columns:
        display_cols.append("risk_tier")
    
    # 3. Add ALL algorithm scores (all score_* columns)
    score_cols = sorted([c for c in preview.columns if c.startswith("score_")])
    display_cols.extend(score_cols)
    
    # If no display columns found, use all columns
    if not display_cols:
        display_cols = list(preview.columns)
    
    # Filter to only display columns
    preview = preview[display_cols].copy()
    
    # Mask sensitive IDs for privacy
    for col in ["party_id", "customer_id"]:
        if col in preview.columns:
            preview[col] = preview[col].apply(lambda x: f"****{str(x)[-4:]}" if pd.notna(x) else "")
    
    # Round numeric scores to 4 decimal places
    for col in preview.columns:
        if preview[col].dtype in [np.float64, np.float32]:
            preview[col] = preview[col].round(4)
    
    # Build column definitions with enhanced filtering
    col_defs = []
    for col in display_cols:
        col_def = {
            "field": col,
            "headerName": col.replace("_", " ").replace("score ", "").title(),
            "sortable": True,
            "filter": True,  # Enable column filter
            "floatingFilter": True,  # Show search box at top of each column
            "resizable": True,
            "minWidth": 120,
        }
        
        # Pin customer identification columns
        if col in ["customer_name", "customer_id", "party_id"]:
            col_def["pinned"] = "left"
            col_def["minWidth"] = 150
        
        # Highlight anomaly score and risk tier
        if col == "anomaly_score":
            col_def["cellStyle"] = {"fontWeight": 700, "color": "#FFD700"}
        elif col == "risk_tier":
            col_def["cellStyle"] = {"fontWeight": 700}
        
        col_defs.append(col_def)
    
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.Text("Scored Data Preview", fw=600),
                    dmc.Badge(f"{len(preview)} Customers", color="cyan", size="lg"),
                    dmc.Badge(f"{len(score_cols)} Algorithms", color="indigo", size="lg"),
                ],
                justify="space-between",
                mb="sm",
            ),
            dmc.Text(
                "All customers with calculated scores from all detection algorithms. Use column filters to search.",
                size="xs", c="dimmed", mb="sm",
            ),
            dag.AgGrid(
                id="pipeline-scored-preview",
                rowData=preview.to_dict("records"),
                columnDefs=col_defs,
                defaultColDef={
                    "flex": 1,
                    "minWidth": 120,
                    "filter": True,
                    "floatingFilter": True,  # Enable search box for all columns
                    "sortable": True,
                    "resizable": True,
                },
                dashGridOptions={
                    "pagination": True,
                    "paginationPageSize": 20,
                    "paginationPageSizeSelector": [10, 20, 50, 100],
                    "animateRows": True,
                    "enableCellTextSelection": True,
                    "suppressColumnVirtualisation": False,
                },
                style={"height": "600px", "width": "100%"},
                className="ag-theme-alpine-dark",
            ),
        ],
        p="md", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD},
    )


# =============================================================================
# LOAD SAVED RESULTS FROM VAULT ON PAGE LOAD
# =============================================================================
def _build_results_from_vault():
    """Rebuild the results UI from persisted vault data (JSON + scored parquet).

    This is the persistence layer — when the user navigates away and
    comes back, this function re-renders the last successful pipeline run.
    """
    from utils.data_io import data_vault

    result_json = data_vault.load_pipeline_result()
    if not result_json or not result_json.get("success"):
        return None

    df_scored = data_vault.get_scored_data()

    # Pull values from the JSON dict
    exec_time = result_json.get("execution_time_ms", 0)
    data_source = result_json.get("data_source", "unknown")
    records = result_json.get("records_processed", 0)
    dq_score = result_json.get("dq_score", 0)
    features = result_json.get("features_generated", 0)
    methods_run = result_json.get("methods_run", 0)
    alerts = result_json.get("alerts_generated", 0)
    tier_dist = result_json.get("tier_distribution", {})
    method_scores = result_json.get("method_scores", [])
    layer_timings = result_json.get("layer_timings", {})
    risk_by_family = result_json.get("risk_by_family", [])
    risk_by_ensemble = result_json.get("risk_by_ensemble", [])
    timestamp = result_json.get("timestamp", "")

    # Build the scored data preview if we have scored data
    preview_section = None
    if df_scored is not None and not df_scored.empty:
        preview_section = _build_scored_preview(df_scored)

    children = [
        # ── Persisted Alert ──
        dmc.Alert(
            f"Last pipeline run completed in {exec_time:.0f}ms "
            f"({'Sample' if data_source == 'sample' else 'Actual'} data) "
            f"— {str(timestamp)[:19] if timestamp else ''}",
            color="teal",
            icon=DashIconify(icon="mdi:history"),
            withCloseButton=True,
        ),

        # ── KPI Summary ──
        dmc.SimpleGrid(
            cols={"base": 2, "md": 3, "lg": 6},
            spacing="sm",
            children=[
                _kpi_badge("Records", f"{records:,}", "mdi:database", "cyan"),
                _kpi_badge("DQ Score", f"{dq_score:.0%}" if isinstance(dq_score, float) else str(dq_score), "mdi:check-decagram", "green"),
                _kpi_badge("Features", str(features), "mdi:cog", "blue"),
                _kpi_badge("Methods", str(methods_run), "mdi:magnify-scan", "indigo"),
                _kpi_badge("Alerts", str(alerts), "mdi:alert", "orange"),
                _kpi_badge("Time", f"{exec_time:.0f}ms", "mdi:timer", "teal"),
            ],
        ),

        # ── Risk Tier Distribution ──
        dmc.Paper(
            [
                dmc.Text("Risk Tier Distribution", fw=600, mb="sm"),
                dmc.Group(
                    [
                        dmc.Badge(f"Critical: {tier_dist.get('Critical', 0)}", color="red", size="lg"),
                        dmc.Badge(f"High: {tier_dist.get('High', 0)}", color="orange", size="lg"),
                        dmc.Badge(f"Medium: {tier_dist.get('Medium', 0)}", color="yellow", size="lg"),
                        dmc.Badge(f"Low: {tier_dist.get('Low', 0)}", color="green", size="lg"),
                    ],
                ),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
        ),

        # ── Risk by Detection Family ──
        dmc.Paper(
            [
                dmc.Text("Risk by Detection Family", fw=600, mb="sm"),
                dag.AgGrid(
                    rowData=risk_by_family,
                    columnDefs=[
                        {"field": "Family", "headerName": "Detection Family", "sortable": True, "filter": True},
                        {"field": "Methods", "headerName": "Methods", "sortable": True},
                        {"field": "Critical", "sortable": True, "cellStyle": {"color": "#FF5252", "fontWeight": 700}},
                        {"field": "High", "sortable": True, "cellStyle": {"color": "#FF9800", "fontWeight": 600}},
                        {"field": "Medium", "sortable": True, "cellStyle": {"color": "#FFC107"}},
                        {"field": "Low", "sortable": True, "cellStyle": {"color": "#4CAF50"}},
                    ],
                    defaultColDef={"flex": 1, "minWidth": 90, "resizable": True},
                    dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
                    style={"height": None, "width": "100%"},
                    className="ag-theme-alpine-dark",
                ),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
        ),

        # ── Risk by Ensemble Method ──
        dmc.Paper(
            [
                dmc.Text("Risk by Ensemble Method", fw=600, mb="sm"),
                dag.AgGrid(
                    rowData=risk_by_ensemble,
                    columnDefs=[
                        {"field": "Ensemble Method", "sortable": True},
                        {"field": "Total Records", "sortable": True},
                        {"field": "Critical", "sortable": True, "cellStyle": {"color": "#FF5252", "fontWeight": 700}},
                        {"field": "High", "sortable": True, "cellStyle": {"color": "#FF9800", "fontWeight": 600}},
                        {"field": "Medium", "sortable": True, "cellStyle": {"color": "#FFC107"}},
                        {"field": "Low", "sortable": True, "cellStyle": {"color": "#4CAF50"}},
                        {"field": "Anomaly Rate"},
                    ],
                    defaultColDef={"flex": 1, "minWidth": 100, "resizable": True},
                    dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
                    style={"height": None, "width": "100%"},
                    className="ag-theme-alpine-dark",
                ),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
        ),

        # ── Per-Layer Timing ──
        _build_timing_section(layer_timings),

        # ── Per-Method Scores ──
        dmc.Paper(
            [
                dmc.Text("Per-Method Anomaly Scores", fw=600, mb="sm"),
                dag.AgGrid(
                    rowData=method_scores,
                    columnDefs=[
                        {"field": "method", "headerName": "Method", "sortable": True, "filter": True},
                        {"field": "category", "headerName": "Category", "sortable": True, "filter": True},
                        {"field": "mean_score", "headerName": "Mean Score", "sortable": True,
                         "valueFormatter": {"function": "d3.format('.4f')(params.value)"}},
                        {"field": "max_score", "headerName": "Max Score", "sortable": True,
                         "valueFormatter": {"function": "d3.format('.4f')(params.value)"}},
                        {"field": "anomalies", "headerName": "Anomalies (>0.5)", "sortable": True},
                    ],
                    defaultColDef={"flex": 1, "minWidth": 120, "resizable": True},
                    dashGridOptions={"domLayout": "autoHeight", "animateRows": True,
                                     "pagination": True, "paginationPageSize": 10},
                    style={"height": None, "width": "100%"},
                    className="ag-theme-alpine-dark",
                ),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
        ),
    ]

    # ── Scored Data Preview ──
    if preview_section is not None:
        children.append(preview_section)

    return dmc.Stack(children, gap="md")


# =============================================================================
# CALLBACK: Load saved results on page load
# =============================================================================
@callback(
    Output("pipeline-results-area", "children", allow_duplicate=True),
    Input("pipeline-load-trigger", "n_intervals"),
    prevent_initial_call=True,
)
def load_saved_results(n):
    """On page load, render last pipeline results from vault so they persist."""
    if n is None or n < 1:
        return dash.no_update
    try:
        saved_ui = _build_results_from_vault()
        if saved_ui is not None:
            return saved_ui
    except Exception:
        pass
    return dash.no_update
