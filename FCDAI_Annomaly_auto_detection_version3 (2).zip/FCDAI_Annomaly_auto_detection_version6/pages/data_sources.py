"""
Data Sources Page
=================
Data entry point — generate sample data OR upload real CSVs/Excel
for each of the 6 source tables (Transactions, Party, Account, Alert,
Case, KYC).  Shows preview grids and source statistics.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, ctx, ALL
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import dash_ag_grid as dag
import pandas as pd
import numpy as np
import io, base64, sys, json
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS, APP

dash.register_page(__name__, path="/sources", name="Data Sources", order=1)


# =============================================================================
# TABLE CONFIG
# =============================================================================
TABLE_CONFIG = {
    "transactions": {"icon": "mdi:swap-horizontal",    "color": "cyan",   "label": "Transactions",    "order": 1},
    "party":        {"icon": "mdi:account-group",      "color": "blue",   "label": "Customer / Party", "order": 2},
    "account":      {"icon": "mdi:bank",               "color": "indigo", "label": "Accounts",        "order": 3},
    "alert":        {"icon": "mdi:alert",              "color": "orange", "label": "Alerts",          "order": 4},
    "case":         {"icon": "mdi:briefcase",          "color": "red",    "label": "Cases",           "order": 5},
    "kyc":          {"icon": "mdi:shield-check",       "color": "green",  "label": "KYC",             "order": 6},
    "watchlist":    {"icon": "mdi:shield-search",      "color": "pink",   "label": "Watchlist",       "order": 7},
    "relationships":{"icon": "mdi:graph-outline",      "color": "violet", "label": "Relationships",   "order": 8},
    "others1":      {"icon": "mdi:folder-outline",     "color": "grape",  "label": "Others1",         "order": 9},
    "others2":      {"icon": "mdi:folder-multiple",    "color": "lime",   "label": "Others2",         "order": 10},
    "exclude":      {"icon": "mdi:filter-remove",      "color": "yellow", "label": "Exclude Features","order": 11},
}

MASK_COLUMNS = {"party_id", "customer_id", "account_id"}


def mask_id(val):
    s = str(val)
    return f"****{s[-4:]}" if len(s) > 4 else s


def build_ag_grid(df, table_name, max_rows=50):
    """Build AG Grid preview."""
    preview = df.head(max_rows).copy()
    for col in preview.columns:
        if col in MASK_COLUMNS:
            preview[col] = preview[col].apply(mask_id)
    cols = [{"field": c, "sortable": True, "filter": True, "resizable": True} for c in preview.columns]
    return dag.AgGrid(
        id={"type": "source-grid", "table": table_name},
        rowData=preview.to_dict("records"),
        columnDefs=cols,
        defaultColDef={"flex": 1, "minWidth": 100},
        dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
        style={"height": None, "width": "100%"},
        className="ag-theme-alpine-dark",
    )


def _upload_card(table_name, conf):
    """Mini upload zone per table - compact design."""
    return dmc.Paper(
        [
            dmc.Stack(
                [
                    dmc.Group([
                        dmc.ThemeIcon(
                            DashIconify(icon=conf["icon"], width=16),
                            color=conf["color"], variant="light", size="sm",
                        ),
                        dmc.Text(conf["label"], fw=500, size="xs"),
                    ], gap="xs", justify="flex-start"),
                    dcc.Upload(
                        id={"type": "upload-table", "table": table_name},
                        children=dmc.Stack([
                            DashIconify(icon="mdi:cloud-upload", width=20, color="#888"),
                            dmc.Text("Drop file", size="xs", c="dimmed", ta="center"),
                        ], gap=2, align="center"),
                        style={
                            "border": f"1px dashed {THEME.DARK_BORDER}",
                            "borderRadius": "6px",
                            "padding": "8px",
                            "textAlign": "center",
                            "cursor": "pointer",
                            "minHeight": "60px",
                        },
                        multiple=False,
                    ),
                    html.Div(
                        id={"type": "upload-status", "table": table_name},
                        style={"minHeight": "20px"}
                    ),
                ],
                gap="xs",
            ),
        ],
        p="xs", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD, "height": "100%"},
    )


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Container(
    [
        # Header
        dmc.Group(
            [
                dmc.Title("Data Sources", order=2),
                dmc.Badge("7 Tables • Customer-Level", color="cyan", variant="light"),
            ],
            justify="space-between",
            mb="lg",
        ),

        # ── SECTION 1: QUICK START (TWO MINI BOXES) ──────────────────
        dmc.Text("Quick Start", fw=700, size="lg", mb="sm"),
        dmc.SimpleGrid(
            cols={"base": 1, "sm": 1, "md": 2},
            spacing="md",
            mb="lg",
            children=[
                # BOX 1: Generate Sample Data
                dmc.Paper(
                    [
                        dmc.Group([
                            DashIconify(icon="mdi:database-plus", width=22, color="#22b8cf"),
                            dmc.Text("1. Sample Data", fw=600, size="sm"),
                        ], gap="xs", mb="xs"),
                        dmc.Text(
                            "Generate test data",
                            size="xs", c="dimmed", mb="sm",
                        ),
                        dmc.NumberInput(
                            id="ds-customer-count",
                            label="Customers",
                            value=100, min=10, max=100000, step=10,
                            size="xs",
                            style={"width": "100%"},
                            mb="xs",
                        ),
                        dmc.Button(
                            "Generate",
                            id="ds-btn-generate",
                            leftSection=DashIconify(icon="mdi:play", width=14),
                            color="cyan", size="xs", fullWidth=True, mb="xs",
                        ),
                        dmc.Button(
                            "Reset All",
                            id="ds-btn-reset",
                            leftSection=DashIconify(icon="mdi:trash-can", width=14),
                            color="red", variant="subtle", size="xs", fullWidth=True,
                        ),
                    ],
                    p="sm", radius="md", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD, "height": "100%"},
                ),
                
                # BOX 2: Select for Execution
                dmc.Paper(
                    [
                        dmc.Group([
                            DashIconify(icon="mdi:check-decagram", width=22, color="#51cf66"),
                            dmc.Text("2. Use for Execution", fw=600, size="sm"),
                        ], gap="xs", mb="xs"),
                        dmc.Text(
                            "Select data source",
                            size="xs", c="dimmed", mb="sm",
                        ),
                        dmc.SegmentedControl(
                            id="ds-execution-choice",
                            data=[
                                {"label": "Sample", "value": "sample"},
                                {"label": "Actual", "value": "actual"},
                            ],
                            value="sample",
                            color="green",
                            fullWidth=True,
                            size="xs",
                            mb="sm",
                        ),
                        html.Div(id="ds-execution-info", children=[
                            dmc.Alert(
                                "No data available",
                                color="gray",
                                variant="light",
                                styles={"message": {"fontSize": "11px"}},
                            )
                        ]),
                        dmc.Button(
                            "Confirm",
                            id="ds-btn-confirm-final",
                            leftSection=DashIconify(icon="mdi:check-bold", width=14),
                            color="green", size="xs", fullWidth=True, mt="xs",
                            disabled=True,
                        ),
                    ],
                    p="sm", radius="md", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD, "height": "100%"},
                ),
            ],
        ),
        
        # Status messages
        html.Div(id="ds-status-output", style={"marginBottom": "1rem"}),

        # ── SECTION 2: UPLOAD ACTUAL DATA ─────────────────────
        dmc.Paper(
            [
                dmc.Group([
                    dmc.Text("Upload Actual Data", fw=600),
                    dmc.Badge(f"{len(TABLE_CONFIG)} Data Types", color="cyan", variant="light"),
                ], justify="space-between", mb="sm"),
                dmc.Text(
                    "Upload CSV or Excel files for individual data sources. Each upload replaces the corresponding data in the vault.",
                    size="sm", c="dimmed", mb="md",
                ),
                dmc.SimpleGrid(
                    cols={"base": 2, "sm": 3, "md": 4, "lg": 6},
                    spacing="sm",
                    children=[_upload_card(name, conf) for name, conf in sorted(TABLE_CONFIG.items(), key=lambda x: x[1]["order"])],
                ),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
            mb="lg",
        ),

        # ── SECTION 3: DATA SOURCE SUMMARY TABLE ──────────────
        dmc.Paper(
            [
                dmc.Text("Data Source Summary", fw=600, mb="sm"),
                dmc.Text(
                    "Overview of all uploaded data sources with record counts and status.",
                    size="sm", c="dimmed", mb="md",
                ),
                html.Div(id="ds-summary-table"),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
            mb="lg",
        ),

        # ── SECTION 4: SOURCE STATS ──────────────────────────
        html.Div(id="ds-source-stats"),
        dmc.Space(h="lg"),

        # ── SECTION 5: TABLE PREVIEWS ────────────────────────
        html.Div(id="ds-table-previews"),

        # Stores for cross-page communication and triggers
        dcc.Store(id="ds-upload-trigger", data=0),
        dcc.Store(id="ds-final-data-store", data=None),  # Stores selected final data for execution engine
    ],
    fluid=True,
)


# =============================================================================
# CALLBACKS
# =============================================================================

# ── Generate / Reset ─────────────────────────────────────
@callback(
    Output("ds-status-output", "children"),
    Output("ds-summary-table", "children"),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input("ds-btn-generate", "n_clicks"),
    Input("ds-btn-reset", "n_clicks"),
    State("ds-customer-count", "value"),
    State("ds-execution-choice", "value"),
    prevent_initial_call=True,
)
def handle_gen_reset(n_gen, n_reset, num_customers, execution_choice):
    from utils.data_gen import DataGenerator
    from utils.data_io import data_vault

    triggered = ctx.triggered_id
    status_msg = None
    execution_info = dash.no_update
    confirm_disabled = dash.no_update

    if triggered == "ds-btn-reset":
        data_vault.clear_data()
        for f in PATHS.DATA_SOURCES.glob("*.csv"):
            f.unlink()
        status_msg = dmc.Alert(
            "All data cleared.", color="orange",
            icon=DashIconify(icon="mdi:check"), withCloseButton=True,
        )
        # Update execution info after reset
        execution_info = dmc.Stack([
            dmc.Group([
                DashIconify(icon="mdi:alert-circle", width=16, color="#ffd43b"),
                dmc.Text("No Data Available", size="xs", fw=600, c="yellow"),
            ], gap=4),
            dmc.Text("Generate sample data or upload actual data", size="xs", c="dimmed", mt=2),
        ], gap=0)
        confirm_disabled = True

    if triggered == "ds-btn-generate":
        try:
            num_customers = num_customers or 100
            dg = DataGenerator()
            schema = dg.generate_full_schema(num_customers)

            # Mark as sample data
            data_vault.save_sources(schema)
            meta = data_vault.get_metadata()
            meta["data_type"] = "sample"
            meta["sample_tables"] = list(schema.keys())
            data_vault._metadata = meta
            data_vault.save_metadata()

            PATHS.DATA_SOURCES.mkdir(parents=True, exist_ok=True)
            for name, df in schema.items():
                df.to_csv(PATHS.DATA_SOURCES / f"{name}.csv", index=False)

            # Merged analytical view
            df_tx = schema.get("transactions", pd.DataFrame())
            df_acc = schema.get("account", pd.DataFrame())
            df_party = schema.get("party", pd.DataFrame())
            df_merged = df_tx.copy()
            if not df_acc.empty and "account_id" in df_tx.columns and "account_id" in df_acc.columns:
                df_merged = df_merged.merge(df_acc, on="account_id", how="left", suffixes=("", "_acc"))
            if not df_party.empty and "party_id" in df_merged.columns and "party_id" in df_party.columns:
                df_merged = df_merged.merge(df_party, on="party_id", how="left", suffixes=("", "_party"))
            data_vault.set_current_data(df_merged, label=f"generated_{num_customers}_cust")

            total_rows = sum(len(v) for v in schema.values())
            status_msg = dmc.Alert(
                f"Generated {num_customers} customers → {total_rows:,} total rows across {len(schema)} tables.",
                color="green", icon=DashIconify(icon="mdi:check-circle"), withCloseButton=True,
            )
            
            # Update execution info if sample data is selected
            if execution_choice == "sample":
                sample_count = len([t for t in schema.keys() if t != "exclude"])
                loaded_names = [TABLE_CONFIG.get(t, {"label": t.title()})["label"] 
                              for t in schema.keys() if t != "exclude"]
                table_preview = ", ".join(loaded_names[:4])
                if len(loaded_names) > 4:
                    table_preview += f" +{len(loaded_names)-4} more"
                
                execution_info = dmc.Stack([
                    dmc.Group([
                        DashIconify(icon="mdi:check-circle", width=16, color="#51cf66"),
                        dmc.Text(f"Sample Data Ready — {sample_count} tables", size="xs", fw=600, c="cyan"),
                    ], gap=4),
                    dmc.Text(table_preview, size="xs", c="dimmed", mt=2),
                ], gap=0)
                confirm_disabled = False
                
        except Exception as e:
            status_msg = dmc.Alert(f"Generation error: {e}", color="red", icon=DashIconify(icon="mdi:alert"))

    sources = data_vault.load_sources()
    
    return status_msg, _build_summary_table(sources, data_vault), _build_stats(sources, data_vault), _build_preview_tabs(sources), execution_info, confirm_disabled


# ── Execution Choice Info Display ─────────────────────────────────────
@callback(
    Output("ds-execution-info", "children"),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input("ds-execution-choice", "value"),
    prevent_initial_call='initial_duplicate',
)
def update_execution_info(choice):
    from utils.data_io import data_vault
    
    sources = data_vault.load_sources()
    meta = data_vault.get_metadata()
    
    if choice == "sample":
        sample_tables = meta.get("sample_tables", [])
        sample_count = len([t for t in sample_tables if t in sources and t != "exclude"])
        
        if sample_count > 0:
            # Get sample table names for display
            loaded_names = [TABLE_CONFIG.get(t, {"label": t.title()})["label"] 
                          for t in sample_tables if t in sources and t != "exclude"]
            table_preview = ", ".join(loaded_names[:4])
            if len(loaded_names) > 4:
                table_preview += f" +{len(loaded_names)-4} more"
            
            return dmc.Stack([
                dmc.Group([
                    DashIconify(icon="mdi:check-circle", width=16, color="#51cf66"),
                    dmc.Text(f"Sample Data Ready — {sample_count} tables", size="xs", fw=600, c="cyan"),
                ], gap=4),
                dmc.Text(table_preview, size="xs", c="dimmed", mt=2),
            ], gap=0), False
        else:
            return dmc.Stack([
                dmc.Group([
                    DashIconify(icon="mdi:alert-circle", width=16, color="#ffd43b"),
                    dmc.Text("No Sample Data", size="xs", fw=600, c="yellow"),
                ], gap=4),
                dmc.Text("Click 'Generate' in Box 1 to create sample data", size="xs", c="dimmed", mt=2),
            ], gap=0), True
    
    elif choice == "actual":
        actual_tables = meta.get("actual_tables", [])
        actual_count = len([t for t in actual_tables if t in sources and t != "exclude"])
        
        if actual_count > 0:
            # Get actual table names for display
            loaded_names = [TABLE_CONFIG.get(t, {"label": t.title()})["label"] 
                          for t in actual_tables if t in sources and t != "exclude"]
            table_preview = ", ".join(loaded_names[:4])
            if len(loaded_names) > 4:
                table_preview += f" +{len(loaded_names)-4} more"
            
            return dmc.Stack([
                dmc.Group([
                    DashIconify(icon="mdi:check-circle", width=16, color="#51cf66"),
                    dmc.Text(f"Actual Data Ready — {actual_count} tables", size="xs", fw=600, c="green"),
                ], gap=4),
                dmc.Text(table_preview, size="xs", c="dimmed", mt=2),
            ], gap=0), False
        else:
            return dmc.Stack([
                dmc.Group([
                    DashIconify(icon="mdi:alert-circle", width=16, color="#ffd43b"),
                    dmc.Text("No Actual Data", size="xs", fw=600, c="yellow"),
                ], gap=4),
                dmc.Text("Upload CSV/Excel files in sections below", size="xs", c="dimmed", mt=2),
            ], gap=0), True
    
    return dmc.Alert(
        "Select data source above",
        color="gray",
        variant="light",
        styles={"message": {"fontSize": "11px"}},
    ), True


# ── Confirm Final Data Selection ─────────────────────────────────────
@callback(
    Output("ds-status-output", "children", allow_duplicate=True),
    Output("ds-final-data-store", "data"),
    Input("ds-btn-confirm-final", "n_clicks"),
    State("ds-execution-choice", "value"),
    prevent_initial_call=True,
)
def confirm_final_data(n_clicks, choice):
    from utils.data_io import data_vault
    
    if not choice:
        return dmc.Alert(
            "Please select Sample or Actual data.",
            color="orange",
            icon=DashIconify(icon="mdi:alert"),
            withCloseButton=True,
        ), None
    
    meta = data_vault.get_metadata()
    meta["final_data_choice"] = choice
    data_vault._metadata = meta
    data_vault.save_metadata()
    
    # Store final data selection for use in execution engine
    final_data_info = {
        "choice": choice,
        "label": "Sample Data" if choice == "sample" else "Actual Data",
        "timestamp": pd.Timestamp.now().isoformat(),
    }
    
    choice_label = "Sample Data" if choice == "sample" else "Actual Data"
    return dmc.Alert(
        f"✓ Execution Engine will use: {choice_label}",
        color="green",
        icon=DashIconify(icon="mdi:check-circle"),
        withCloseButton=True,
    ), final_data_info


# ── Per-table Upload ─────────────────────────────────────
@callback(
    Output({"type": "upload-status", "table": ALL}, "children"),
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input({"type": "upload-table", "table": ALL}, "contents"),
    State({"type": "upload-table", "table": ALL}, "filename"),
    State("ds-execution-choice", "value"),
    prevent_initial_call='initial_duplicate',
)
def handle_uploads(contents_list, filenames_list, execution_choice):
    from utils.data_io import data_vault

    table_names = list(k for k, v in sorted(TABLE_CONFIG.items(), key=lambda x: x[1]["order"]))
    status_outputs = [None] * len(table_names)
    execution_info = dash.no_update
    confirm_disabled = dash.no_update

    any_upload = False
    uploaded_tables = []
    for i, (contents, filename) in enumerate(zip(contents_list, filenames_list)):
        if contents is None:
            continue
        tbl = table_names[i]
        try:
            content_string = contents.split(",")[1]
            decoded = base64.b64decode(content_string)

            if filename.endswith(".csv"):
                df = pd.read_csv(io.StringIO(decoded.decode("utf-8")))
            elif filename.endswith((".xlsx", ".xls")):
                df = pd.read_excel(io.BytesIO(decoded))
            elif filename.endswith(".parquet"):
                df = pd.read_parquet(io.BytesIO(decoded))
            else:
                status_outputs[i] = dmc.Text(f"Unsupported: {filename}", size="xs", c="red")
                continue

            # Special handling for exclude features
            if tbl == "exclude":
                if "variable" in df.columns:
                    var_list = df["variable"].dropna().astype(str).tolist()
                else:
                    var_list = df.iloc[:, 0].dropna().astype(str).tolist()
                
                exclude_path = PATHS.DATA_VAULT / "exclude_vars.json"
                with open(exclude_path, "w") as f:
                    json.dump(var_list, f)
                
                status_outputs[i] = dmc.Text(
                    f"✓ {len(var_list)} vars", size="xs", c="green", mt="xs",
                )
                continue

            # Save single table into vault
            sources_dir = PATHS.DATA_VAULT / "sources"
            sources_dir.mkdir(parents=True, exist_ok=True)
            df.to_parquet(sources_dir / f"{tbl}.parquet", index=False)
            data_vault._sources[tbl] = df
            uploaded_tables.append(tbl)

            status_outputs[i] = dmc.Text(
                f"✓ {len(df):,} rows", size="xs", c="green", mt="xs",
            )
            any_upload = True
        except Exception as e:
            status_outputs[i] = dmc.Text(f"✗ {str(e)[:30]}", size="xs", c="red", mt="xs")

    # Track actual tables in metadata
    if any_upload:
        meta = data_vault.get_metadata()
        actual_tables = set(meta.get("actual_tables", []))
        actual_tables.update(uploaded_tables)
        meta["actual_tables"] = list(actual_tables)
        data_vault._metadata = meta
        data_vault.save_metadata()
        _rebuild_merged(data_vault)
        
        # Update execution info if actual data is selected
        if execution_choice == "actual":
            sources = data_vault.load_sources()
            actual_count = len([t for t in actual_tables if t in sources and t != "exclude"])
            
            if actual_count > 0:
                loaded_names = [TABLE_CONFIG.get(t, {"label": t.title()})["label"] 
                              for t in actual_tables if t in sources and t != "exclude"]
                table_preview = ", ".join(loaded_names[:4])
                if len(loaded_names) > 4:
                    table_preview += f" +{len(loaded_names)-4} more"
                
                execution_info = dmc.Stack([
                    dmc.Group([
                        DashIconify(icon="mdi:check-circle", width=16, color="#51cf66"),
                        dmc.Text(f"Actual Data Ready — {actual_count} tables", size="xs", fw=600, c="green"),
                    ], gap=4),
                    dmc.Text(table_preview, size="xs", c="dimmed", mt=2),
                ], gap=0)
                confirm_disabled = False

    sources = data_vault.load_sources()
    
    return status_outputs, _build_summary_table(sources, data_vault), _build_stats(sources, data_vault), _build_preview_tabs(sources), execution_info, confirm_disabled


def _rebuild_merged(data_vault):
    """Rebuild the analytical merged view from current sources."""
    sources = data_vault.load_sources()
    df_tx = sources.get("transactions", pd.DataFrame())
    df_acc = sources.get("account", pd.DataFrame())
    df_party = sources.get("party", pd.DataFrame())

    if df_tx.empty:
        # Use the largest available table as base
        if sources:
            biggest = max(sources.values(), key=len)
            data_vault.set_current_data(biggest, label="manual_upload")
        return

    df_merged = df_tx.copy()
    if not df_acc.empty and "account_id" in df_tx.columns and "account_id" in df_acc.columns:
        df_merged = df_merged.merge(df_acc, on="account_id", how="left", suffixes=("", "_acc"))
    if not df_party.empty and "party_id" in df_merged.columns and "party_id" in df_party.columns:
        df_merged = df_merged.merge(df_party, on="party_id", how="left", suffixes=("", "_party"))
    data_vault.set_current_data(df_merged, label="manual_upload")


# =============================================================================
# HELPER BUILDERS
# =============================================================================
def _build_summary_table(sources, data_vault):
    """Build AG Grid summary table for all data sources."""
    rows = []
    
    for name, conf in sorted(TABLE_CONFIG.items(), key=lambda x: x[1]["order"]):
        # Special handling for exclude features
        if name == "exclude":
            exclude_path = PATHS.DATA_VAULT / "exclude_vars.json"
            if exclude_path.exists():
                try:
                    with open(exclude_path, "r") as f:
                        var_list = json.load(f)
                    status = "✓ Loaded"
                    records = len(var_list)
                    columns = 1
                except:
                    status = "⚬ Not Loaded"
                    records = 0
                    columns = 0
            else:
                status = "⚬ Not Loaded"
                records = 0
                columns = 0
        else:
            df = sources.get(name)
            if df is not None and not df.empty:
                status = "✓ Loaded"
                records = len(df)
                columns = len(df.columns)
            else:
                status = "⚬ Not Loaded"
                records = 0
                columns = 0
        
        rows.append({
            "Data Type": conf["label"],
            "Status": status,
            "Records": f"{records:,}" if records > 0 else "-",
            "Columns": columns if columns > 0 else "-",
        })
    
    col_defs = [
        {
            "field": "Data Type",
            "headerName": "Data Type",
            "flex": 2,
            "sortable": True,
            "filter": True,
            "floatingFilter": True,
            "pinned": "left",
        },
        {
            "field": "Status",
            "headerName": "Status",
            "flex": 1,
            "sortable": True,
            "filter": True,
        },
        {
            "field": "Records",
            "headerName": "Records",
            "flex": 1,
            "sortable": True,
            "filter": True,
            "type": "rightAligned",
        },
        {
            "field": "Columns",
            "headerName": "Columns",
            "flex": 1,
            "sortable": True,
            "filter": True,
            "type": "rightAligned",
        },
    ]
    
    return dag.AgGrid(
        id="ds-summary-grid",
        rowData=rows,
        columnDefs=col_defs,
        defaultColDef={
            "resizable": True,
            "sortable": True,
            "filter": True,
        },
        dashGridOptions={
            "domLayout": "autoHeight",
            "animateRows": True,
            "rowHeight": 45,
        },
        style={"height": None, "width": "100%"},
        className="ag-theme-alpine-dark",
    )


def _build_stats(sources, data_vault):
    """Build stats showing ALL 11 data types, even if not loaded."""
    meta = data_vault.get_metadata()
    last_gen = meta.get("import_time", "N/A")

    # Check exclude features separately
    exclude_path = PATHS.DATA_VAULT / "exclude_vars.json"
    exclude_count = 0
    if exclude_path.exists():
        try:
            with open(exclude_path, "r") as f:
                var_list = json.load(f)
            exclude_count = len(var_list)
        except:
            pass

    # Count actual data tables (excluding 'exclude')
    data_tables = {k: v for k, v in sources.items() if k != "exclude"}
    table_count = len(data_tables)
    total_rows = sum(len(df) for df in data_tables.values())

    cards = []
    loaded_count = 0
    # Show ALL data types from TABLE_CONFIG
    for name, conf in sorted(TABLE_CONFIG.items(), key=lambda x: x[1]["order"]):
        if name == "exclude":
            # Special card for exclude features - ALWAYS show
            if exclude_count > 0:
                loaded_count += 1
                cards.append(
                    dmc.Paper(
                        dmc.Group([
                            dmc.ThemeIcon(
                                DashIconify(icon=conf["icon"], width=20),
                                color=conf["color"], variant="light", size="lg",
                            ),
                            dmc.Stack([
                                dmc.Text(conf["label"], size="sm", fw=600),
                                dmc.Text(f"{exclude_count} variables to exclude", size="xs", c="dimmed"),
                            ], gap=0),
                        ], gap="sm"),
                        p="sm", radius="md", withBorder=True,
                        style={"backgroundColor": THEME.DARK_BG_CARD},
                    )
                )
            else:
                # Not loaded - show placeholder
                cards.append(
                    dmc.Paper(
                        dmc.Group([
                            dmc.ThemeIcon(
                                DashIconify(icon=conf["icon"], width=20),
                                color="gray", variant="light", size="lg",
                            ),
                            dmc.Stack([
                                dmc.Text(conf["label"], size="sm", fw=600, c="dimmed"),
                                dmc.Text("Not loaded", size="xs", c="dimmed"),
                            ], gap=0),
                        ], gap="sm"),
                        p="sm", radius="md", withBorder=True,
                        style={"backgroundColor": THEME.DARK_BG_CARD, "opacity": 0.5},
                    )
                )
        else:
            df = sources.get(name)
            if df is not None and not df.empty:
                # Data loaded
                loaded_count += 1
                cards.append(
                    dmc.Paper(
                        dmc.Group([
                            dmc.ThemeIcon(
                                DashIconify(icon=conf["icon"], width=20),
                                color=conf["color"], variant="light", size="lg",
                            ),
                            dmc.Stack([
                                dmc.Text(conf["label"], size="sm", fw=600),
                                dmc.Text(f"{len(df):,} rows • {len(df.columns)} cols", size="xs", c="dimmed"),
                            ], gap=0),
                        ], gap="sm"),
                        p="sm", radius="md", withBorder=True,
                        style={"backgroundColor": THEME.DARK_BG_CARD},
                    )
                )
            else:
                # Not loaded - show placeholder
                cards.append(
                    dmc.Paper(
                        dmc.Group([
                            dmc.ThemeIcon(
                                DashIconify(icon=conf["icon"], width=20),
                                color="gray", variant="light", size="lg",
                            ),
                            dmc.Stack([
                                dmc.Text(conf["label"], size="sm", fw=600, c="dimmed"),
                                dmc.Text("Not loaded", size="xs", c="dimmed"),
                            ], gap=0),
                        ], gap="sm"),
                        p="sm", radius="md", withBorder=True,
                        style={"backgroundColor": THEME.DARK_BG_CARD, "opacity": 0.5},
                    )
                )

    return dmc.Stack([
        dmc.Group([
            dmc.Badge(f"{loaded_count} of 11 Data Sources Loaded", color="cyan", variant="light", size="lg"),
            dmc.Badge(f"{total_rows:,} Total Rows", color="blue", variant="light", size="lg") if total_rows > 0 else None,
            dmc.Text(
                f"Last updated: {last_gen[:19] if last_gen != 'N/A' else 'N/A'}",
                size="xs", c="dimmed",
            ),
        ], gap="md"),
        dmc.SimpleGrid(
            cols={"base": 2, "md": 3, "lg": 6}, spacing="sm", children=cards,
        ),
    ], gap="md")


def _build_preview_tabs(sources):
    if not sources:
        return None

    tabs = []
    panels = []
    for name, df in sources.items():
        # Skip exclude features - it's not a data table
        if name == "exclude":
            continue
        
        conf = TABLE_CONFIG.get(name, {"icon": "mdi:table", "color": "gray", "label": name.title()})
        tabs.append(
            dmc.TabsTab(
                conf["label"], value=name,
                leftSection=DashIconify(icon=conf["icon"], width=16),
            )
        )
        panels.append(
            dmc.TabsPanel(
                dmc.Paper([
                    dmc.Group([
                        dmc.Text(f"Preview: first 50 of {len(df):,} rows", size="sm", c="dimmed"),
                        dmc.Badge(f"{len(df.columns)} columns", color="gray", variant="light", size="sm"),
                    ], justify="space-between", mb="sm"),
                    build_ag_grid(df, name),
                ], p="md", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}),
                value=name,
            )
        )

    first = list(sources.keys())[0]
    return dmc.Tabs(
        [dmc.TabsList(tabs)] + panels,
        value=first, color="cyan", variant="pills",
    )


# =============================================================================
# CALLBACK: Handle exclude-variable file upload
# =============================================================================
@callback(
    Output("ds-exclude-status", "children"),
    Input("ds-upload-exclude", "contents"),
    State("ds-upload-exclude", "filename"),
    prevent_initial_call=True,
)
def handle_exclude_upload(contents, filename):
    if contents is None:
        return ""

    try:
        from utils.data_io import data_vault

        content_type, content_string = contents.split(",")
        decoded = base64.b64decode(content_string)

        if filename.endswith((".xlsx", ".xls")):
            df = pd.read_excel(io.BytesIO(decoded))
        elif filename.endswith(".csv"):
            df = pd.read_csv(io.StringIO(decoded.decode("utf-8")))
        else:
            return dmc.Alert("Unsupported file type. Use CSV or Excel.", color="red")

        # Extract variable names from the first column or 'variable' column
        if "variable" in df.columns:
            var_list = df["variable"].dropna().astype(str).tolist()
        else:
            var_list = df.iloc[:, 0].dropna().astype(str).tolist()

        # Save to vault
        exclude_path = PATHS.DATA_VAULT / "exclude_vars.json"
        with open(exclude_path, "w") as f:
            json.dump(var_list, f)

        return dmc.Alert(
            f"✓ {len(var_list)} variables loaded for exclusion from '{filename}'",
            color="green",
            icon=DashIconify(icon="mdi:check-circle"),
        )

    except Exception as e:
        return dmc.Alert(f"Error parsing exclude file: {e}", color="red")


# =============================================================================
# CALLBACK: Initialize page on load
# =============================================================================
@callback(
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-execution-choice", "value", allow_duplicate=True),
    Input("ds-upload-trigger", "data"),
    prevent_initial_call='initial_duplicate',
)
def init_page_load(trigger):
    """Load existing data sources on page load."""
    from utils.data_io import data_vault
    sources = data_vault.load_sources()
    meta = data_vault.get_metadata()
    
    # Restore last execution choice
    final_choice = meta.get("final_data_choice", "sample")
    
    return _build_summary_table(sources, data_vault), _build_stats(sources, data_vault), _build_preview_tabs(sources), final_choice
