"""
Project Vanguard Apex - Model Diagnostics Page
===============================================
Visualizations of latent space (PCA/t-SNE),
scoring histograms, and feature importance.

Author: Project Vanguard Team
"""

import dash
from dash import html, dcc, callback, Input, Output, State
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import THEME, APP


dash.register_page(__name__, path="/diagnostics", name="Model Diagnostics", order=2)


# =============================================================================
# PAGE LAYOUT
# =============================================================================
layout = dmc.Container(
    [
        # Header
        dmc.Group(
            [
                dmc.Title("Model Diagnostics", order=2),
                dmc.Badge("Analysis Tools", color="grape", variant="light"),
            ],
            justify="space-between",
            mb="lg",
        ),
        
        # V6: Filters for Algo Family and Methods
        dmc.Paper(
            [
                dmc.Text("Filter Diagnostic Reports", fw=600, mb="md"),
                dmc.SimpleGrid(
                    cols={"base": 1, "md": 3},
                    spacing="md",
                    children=[
                        dmc.Select(
                            id="filter-algo-family",
                            label="Algorithm Family",
                            data=[
                                {"value": "all", "label": "All Families"},
                                {"value": "statistical", "label": "Statistical"},
                                {"value": "distance", "label": "Distance-Based"},
                                {"value": "density", "label": "Density-Based"},
                                {"value": "clustering", "label": "Clustering"},
                                {"value": "trees", "label": "Tree-Based"},
                                {"value": "timeseries", "label": "Time-Series"},
                                {"value": "graph", "label": "Graph-Based"},
                                {"value": "deep_learning", "label": "Deep Learning"},
                            ],
                            value="all",
                            clearable=False,
                        ),
                        dmc.MultiSelect(
                            id="filter-specific-algos",
                            label="Specific Algorithms",
                            data=[],  # Will be populated dynamically
                            placeholder="Select algorithms...",
                            searchable=True,
                            clearable=True,
                        ),
                        dmc.Button(
                            "Apply Filters",
                            id="btn-apply-filters",
                            leftSection=DashIconify(icon="mdi:filter", width=18),
                            color="cyan",
                            mt="xl",
                        ),
                    ],
                ),
            ],
            p="md",
            mb="lg",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),
        
        # Model Status Card
        html.Div(id="model-status-card"),
        
        dmc.Space(h="lg"),
        
        # Charts Row 1: Latent Space & Score Distribution
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2},
            spacing="lg",
            children=[
                dmc.Paper(
                    [
                        dmc.Group(
                            [
                                dmc.Text("Latent Space Visualization", fw=600),
                                dmc.SegmentedControl(
                                    id="latent-method",
                                    data=[
                                        {"value": "pca", "label": "PCA"},
                                        {"value": "tsne", "label": "t-SNE"},
                                    ],
                                    value="pca",
                                    size="xs",
                                ),
                            ],
                            justify="space-between",
                            mb="sm",
                        ),
                        html.Div(
                            dcc.Graph(
                                id="chart-latent-space",
                                config=APP.PLOTLY_CONFIG,
                                style={"height": "350px"},
                            ),
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Text("Score Distribution", fw=600, mb="sm"),
                        dcc.Graph(
                            id="chart-score-histogram",
                            config=APP.PLOTLY_CONFIG,
                            style={"height": "350px"},
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
            ],
        ),
        
        dmc.Space(h="lg"),
        
        # Charts Row 2: Feature Importance & Algorithm Comparison
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2},
            spacing="lg",
            children=[
                dmc.Paper(
                    [
                        dmc.Text("Feature Importance", fw=600, mb="sm"),
                        dcc.Graph(
                            id="chart-feature-importance",
                            config=APP.PLOTLY_CONFIG,
                            style={"height": "350px"},
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Text("Algorithm Agreement Matrix", fw=600, mb="sm"),
                        dcc.Graph(
                            id="chart-algo-agreement",
                            config=APP.PLOTLY_CONFIG,
                            style={"height": "350px"},
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
            ],
        ),
        
        dmc.Space(h="lg"),
        
        # Configuration Table
        dmc.Paper(
            [
                dmc.Text("Model Configuration", fw=600, mb="md"),
                html.Div(id="model-config-table"),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),
        
        # Refresh interval
        dcc.Interval(id="diag-refresh", interval=60000, n_intervals=0),
    ],
    fluid=True,
)


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("filter-specific-algos", "data"),
    Input("filter-algo-family", "value"),
)
def update_algo_dropdown(family):
    """Populate specific algorithms dropdown based on selected family."""
    from config import LAYERS
    
    if family == "all":
        # Show all algorithms from all families
        all_algos = []
        for methods in LAYERS.DETECTION_METHODS.values():
            all_algos.extend(methods)
        return [{"value": algo, "label": algo.replace("_", " ").title()} for algo in sorted(all_algos)]
    else:
        # Show only algorithms from selected family
        algos = LAYERS.DETECTION_METHODS.get(family, [])
        return [{"value": algo, "label": algo.replace("_", " ").title()} for algo in algos]


@callback(
    Output("model-status-card", "children"),
    Input("diag-refresh", "n_intervals"),
)
def update_model_status(n):
    """Update model status display."""
    try:
        from config import LAYERS, THEME
        
        # Count total methods across all categories
        active_methods = sum(len(methods) for methods in LAYERS.DETECTION_METHODS.values())
        available_categories = len(LAYERS.DETECTION_METHODS)
        
        model_path = Path(__file__).parent.parent / "models" / "trained" / "engine.pkl"
        is_trained = model_path.exists()
        
        return dmc.Paper(
            [
                dmc.SimpleGrid(
                    cols={"base": 2, "md": 4},
                    spacing="md",
                    children=[
                        dmc.Group([
                            DashIconify(icon="mdi:brain", width=24, color=THEME.PRIMARY),
                            dmc.Stack([
                                dmc.Text("Method Categories", size="xs", c="dimmed"),
                                dmc.Text(str(available_categories), fw=700),
                            ], gap=0),
                        ]),
                        dmc.Group([
                            DashIconify(icon="mdi:checkbox-multiple-marked", width=24, color=THEME.SUCCESS),
                            dmc.Stack([
                                dmc.Text("Active Algorithms", size="xs", c="dimmed"),
                                dmc.Text(str(active_methods), fw=700),
                            ], gap=0),
                        ]),
                        dmc.Group([
                            DashIconify(
                                icon="mdi:check-circle" if is_trained else "mdi:alert-circle", 
                                width=24, 
                                color=THEME.SUCCESS if is_trained else THEME.WARNING
                            ),
                            dmc.Stack([
                                dmc.Text("Model Status", size="xs", c="dimmed"),
                                dmc.Text("Trained" if is_trained else "Not Trained", fw=700),
                            ], gap=0),
                        ]),
                        dmc.Group([
                            DashIconify(icon="mdi:cog", width=24, color=THEME.SECONDARY),
                            dmc.Stack([
                                dmc.Text("Ensemble Method", size="xs", c="dimmed"),
                                dmc.Text(LAYERS.ENSEMBLE_METHOD.replace('_', ' ').title(), fw=700),
                            ], gap=0),
                        ]),
                    ],
                ),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        )
        
    except Exception as e:
        return dmc.Alert(f"Error loading model status: {str(e)}", color="red")


@callback(
    Output("chart-latent-space", "figure"),
    Input("latent-method", "value"),
    Input("diag-refresh", "n_intervals"),
    Input("btn-apply-filters", "n_clicks"),
    State("filter-algo-family", "value"),
    State("filter-specific-algos", "value"),
)
def update_latent_space(method, n, btn_clicks, family_filter, algo_filter):
    """Update latent space visualization with filters."""
    try:
        from utils.data_io import data_vault
        from config import LAYERS
        
        df = data_vault.get_scored_data()
        
        if df is None or 'anomaly_score' not in df.columns:
            return go.Figure().add_annotation(
                text="Run pipeline to visualize latent space",
                showarrow=False,
            )
        
        # Get numeric columns
        numeric_df = df.select_dtypes(include=[np.number]).dropna(axis=1)
        
        if len(numeric_df.columns) < 2:
            return go.Figure()
        
        # Reduce to 2D
        if method == "pca":
            reducer = PCA(n_components=2)
            coords = reducer.fit_transform(numeric_df.values[:1000])
        else:
            reducer = TSNE(n_components=2, random_state=42, perplexity=30)
            # TSNE needs smaller sample
            sample = numeric_df.head(500)
            coords = reducer.fit_transform(sample.values)
            df = df.head(500)
        
        # Create scatter plot
        plot_df = pd.DataFrame(coords, columns=['Component 1', 'Component 2'])
        plot_df['Score'] = df['anomaly_score'].head(len(plot_df)).values
        plot_df['Risk'] = df['risk_level'].head(len(plot_df)).values if 'risk_level' in df.columns else 'Unknown'
        
        fig = px.scatter(
            plot_df,
            x='Component 1',
            y='Component 2',
            color='Score',
            color_continuous_scale=[
                [0, THEME.SUCCESS],
                [0.5, THEME.WARNING],
                [1, THEME.DANGER]
            ],
            template="plotly_dark",
        )
        
        fig.update_layout(
            margin=dict(l=20, r=20, t=20, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
        )
        
        return fig
        
    except Exception as e:
        return go.Figure()


@callback(
    Output("chart-score-histogram", "figure"),
    Input("diag-refresh", "n_intervals"),
    Input("btn-apply-filters", "n_clicks"),
    State("filter-algo-family", "value"),
    State("filter-specific-algos", "value"),
)
def update_score_histogram(n, btn_clicks, family_filter, algo_filter):
    """Update score distribution histogram with filters."""
    try:
        from utils.data_io import data_vault
        from config import LAYERS
        
        df = data_vault.get_scored_data()
        
        if df is None:
            return go.Figure()
        
        # Get score columns
        score_cols = [c for c in df.columns if c.startswith('score_')]
        
        # Apply filters
        if algo_filter and len(algo_filter) > 0:
            filtered_cols = [f"score_{algo}" for algo in algo_filter if f"score_{algo}" in score_cols]
        elif family_filter != "all":
            family_algos = LAYERS.DETECTION_METHODS.get(family_filter, [])
            filtered_cols = [f"score_{algo}" for algo in family_algos if f"score_{algo}" in score_cols]
        else:
            filtered_cols = score_cols
        
        if len(filtered_cols) == 0:
            return go.Figure().add_annotation(text="No methods selected", showarrow=False)
        
        fig = go.Figure()
        
        # Plot histogram for each filtered method
        for col in filtered_cols:
            method_name = col.replace('score_', '').replace('_', ' ').title()
            fig.add_trace(go.Histogram(
                x=df[col],
                nbinsx=30,
                opacity=0.6,
                name=method_name
            ))
        
        # Add threshold line
        fig.add_vline(
            x=0.5, 
            line_dash="dash", 
            line_color=THEME.WARNING,
            annotation_text="Threshold"
        )
        
        fig.update_layout(
            template="plotly_dark",
            barmode='overlay',
            margin=dict(l=20, r=20, t=40, b=40),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            xaxis_title="Anomaly Score",
            yaxis_title="Count",
            title={"text": f"Score Distribution ({len(filtered_cols)} methods)", "font": {"size": 14}},
            showlegend=True,
            legend=dict(orientation="v", yanchor="top", y=0.99, xanchor="right", x=0.99),
        )
        
        return fig
        
    except Exception as e:
        return go.Figure().add_annotation(text=f"Error: {str(e)}", showarrow=False)


@callback(
    Output("chart-feature-importance", "figure"),
    Input("diag-refresh", "n_intervals"),
    Input("btn-apply-filters", "n_clicks"),
    State("filter-algo-family", "value"),
    State("filter-specific-algos", "value"),
)
def update_feature_importance(n, btn_clicks, family_filter, algo_filter):
    """Update feature importance bar chart using correlation with filters."""
    try:
        from utils.data_io import data_vault
        from config import LAYERS
        
        df = data_vault.get_scored_data()
        
        if df is None:
            return go.Figure().add_annotation(
                text="Run pipeline to see feature importance",
                showarrow=False,
            )
        
        # Get score columns
        score_cols = [c for c in df.columns if c.startswith('score_')]
        
        # Apply filters
        if algo_filter and len(algo_filter) > 0:
            filtered_cols = [f"score_{algo}" for algo in algo_filter if f"score_{algo}" in score_cols]
        elif family_filter != "all":
            family_algos = LAYERS.DETECTION_METHODS.get(family_filter, [])
            filtered_cols = [f"score_{algo}" for algo in family_algos if f"score_{algo}" in score_cols]
        else:
            filtered_cols = score_cols
        
        if len(filtered_cols) == 0:
            return go.Figure().add_annotation(text="No methods selected", showarrow=False)
        
        # Get numeric columns (excluding scores and metadata)
        exclude_cols = ['anomaly_score', 'risk_tier', 'customer_id'] + score_cols
        numeric_df = df.select_dtypes(include=[np.number]).drop(columns=exclude_cols, errors='ignore')
        
        if len(numeric_df.columns) == 0:
             return go.Figure().add_annotation(
                text="No numeric features found",
                showarrow=False,
            )
            
        # Calculate average correlation with filtered score columns
        correlations = {}
        
        for col in numeric_df.columns:
            corrs = []
            for score_col in filtered_cols:
                try:
                    corr = np.corrcoef(numeric_df[col].fillna(0), df[score_col].fillna(0))[0, 1]
                    if not np.isnan(corr):
                        corrs.append(abs(corr))
                except:
                    continue
            if corrs:
                correlations[col] = np.mean(corrs)
        
        # Sort and create chart
        sorted_imp = sorted(correlations.items(), key=lambda x: x[1], reverse=True)[:15]
        names = [x[0] for x in sorted_imp]
        values = [x[1] for x in sorted_imp]
        
        fig = go.Figure(go.Bar(
            x=values,
            y=names,
            orientation='h',
            marker_color=THEME.SECONDARY,
        ))
        
        fig.update_layout(
            template="plotly_dark",
            margin=dict(l=150, r=20, t=40, b=40),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            yaxis=dict(autorange="reversed"),
            xaxis_title=f"Avg |Correlation| ({len(filtered_cols)} methods)",
            title={"text": f"Top {len(values)} Features", "font": {"size": 14}},
        )
        
        return fig
        
    except Exception as e:
        return go.Figure().add_annotation(text=f"Error: {str(e)}", showarrow=False)


@callback(
    Output("chart-algo-agreement", "figure"),
    Input("diag-refresh", "n_intervals"),
    Input("btn-apply-filters", "n_clicks"),
    State("filter-algo-family", "value"),
    State("filter-specific-algos", "value"),
)
def update_algo_agreement(n, btn_clicks, family_filter, algo_filter):
    """Update algorithm agreement heatmap with filters."""
    try:
        from utils.data_io import data_vault
        from config import LAYERS
        
        df = data_vault.get_scored_data()
        
        if df is None:
            return go.Figure()
        
        # Find score columns
        score_cols = [c for c in df.columns if c.startswith('score_')]
        
        if len(score_cols) < 2:
            return go.Figure().add_annotation(
                text="Run multiple algorithms to see agreement",
                showarrow=False,
            )
        
        # Apply filters
        if algo_filter and len(algo_filter) > 0:
            # Filter to specific algorithms
            filtered_cols = [f"score_{algo}" for algo in algo_filter if f"score_{algo}" in score_cols]
        elif family_filter != "all":
            # Filter by family
            family_algos = LAYERS.DETECTION_METHODS.get(family_filter, [])
            filtered_cols = [f"score_{algo}" for algo in family_algos if f"score_{algo}" in score_cols]
        else:
            filtered_cols = score_cols
        
        if len(filtered_cols) < 2:
            return go.Figure().add_annotation(
                text="Select at least 2 algorithms to compare",
                showarrow=False,
            )
        
        # Calculate correlation matrix
        score_df = df[filtered_cols]
        corr = score_df.corr()
        
        # Clean up names
        clean_names = [c.replace('score_', '').replace('_', ' ').title() for c in corr.columns]
        
        fig = go.Figure(data=go.Heatmap(
            z=corr.values,
            x=clean_names,
            y=clean_names,
            colorscale='RdBu',
            zmid=0,
            text=np.round(corr.values, 2),
            texttemplate='%{text}',
            textfont={"size": 10},
        ))
        
        fig.update_layout(
            template="plotly_dark",
            margin=dict(l=20, r=20, t=40, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            title={"text": f"Agreement Matrix ({len(filtered_cols)} methods)", "font": {"size": 14}},
        )
        
        return fig
        
    except Exception as e:
        return go.Figure().add_annotation(text=f"Error: {str(e)}", showarrow=False)


@callback(
    Output("model-config-table", "children"),
    Input("diag-refresh", "n_intervals"),
)
def update_config_table(n):
    """Display model configuration."""
    try:
        from config import LAYERS
        
        # Flatten detection methods list for counting
        total_methods = sum(len(m) for m in LAYERS.DETECTION_METHODS.values())
        
        configs = [
            ("Ensemble Method", LAYERS.ENSEMBLE_METHOD.replace('_', ' ').title()),
            ("Total Algorithms", total_methods),
            ("Categories", len(LAYERS.DETECTION_METHODS)),
            ("Investigation Cap", LAYERS.INVESTIGATION_CAPACITY),
            ("DQ Threshold (Completeness)", f"{LAYERS.DQ_THRESHOLDS['completeness']:.0%}"),
        ]
        
        rows = []
        for name, value in configs:
            rows.append(
                dmc.Group(
                    [
                        dmc.Text(name, c="dimmed", size="sm"),
                        dmc.Text(str(value), fw=500, size="sm"),
                    ],
                    justify="space-between",
                    p="xs",
                    style={"borderBottom": f"1px solid {THEME.DARK_BG_PRIMARY}"}
                )
            )
        
        return dmc.Stack(rows, gap=0)
        
    except Exception as e:
        return dmc.Alert(str(e), color="red")
