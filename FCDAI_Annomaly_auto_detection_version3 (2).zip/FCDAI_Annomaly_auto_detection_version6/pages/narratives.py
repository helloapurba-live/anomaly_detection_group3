"""
Narratives Page — Dynamic Alert Narratives
============================================
Reads scored data from vault, generates real SHAP-style narratives
based on actual pipeline detection scores.
Auto-refreshes with dcc.Interval.
"""

import dash
from dash import html, dcc, callback, Input, Output, State
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import sys
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, LAYERS


dash.register_page(__name__, path="/narratives", name="Narratives", order=5)


def _build_narrative_card(row, idx, score_cols):
    """Build a rich narrative card for a single scored record."""
    score = row.get("anomaly_score", 0)
    tier = row.get("risk_tier", "Low")
    # Prefer customer_name for reports, fall back to IDs
    cust_name = row.get("customer_name", None)
    if cust_name:
        cust_str = str(cust_name)
    else:
        cust_id = row.get("customer_id", row.get("party_id", f"REC-{idx}"))
        cust_str = f"****{str(cust_id)[-4:]}" if len(str(cust_id)) > 4 else str(cust_id)

    # Determine risk colour
    tier_color = {"Critical": "red", "High": "orange", "Medium": "yellow", "Low": "green"}.get(tier, "gray")

    # Auto-generate narrative from actual method scores
    if score > 0.8:
        narrative = (f"🚨 **CRITICAL ALERT**: {cust_str} exhibits extreme deviation across "
                     f"multiple detection methods. Ensemble score: {score:.2%}.")
    elif score > 0.6:
        narrative = (f"⚠️ **HIGH RISK**: {cust_str} flagged by ensemble fusion with "
                     f"elevated anomaly indicators. Ensemble score: {score:.2%}.")
    elif score > 0.4:
        narrative = (f"🔶 **MEDIUM**: {cust_str} shows moderate anomaly signals from "
                     f"statistical methods. Ensemble score: {score:.2%}.")
    else:
        narrative = (f"✅ **LOW**: {cust_str} shows minor deviations, likely benign. "
                     f"Ensemble score: {score:.2%}.")

    # Top contributing methods
    method_items = []
    for col in score_cols:
        val = row.get(col, 0)
        if val and val > 0.3:
            method_name = col.replace("score_", "").replace("_", " ").title()
            method_items.append(
                dmc.Group(
                    [dmc.Text(method_name, size="sm"), dmc.Text(f"{val:.0%}", fw=600, size="sm")],
                    justify="space-between",
                )
            )
    method_items = method_items[:6]  # Limit

    # Recommended actions based on tier
    actions = {
        "Critical": ["Immediate review required", "Escalate to senior analyst", "Consider regulatory filing"],
        "High": ["Review within 24h", "Flag for further investigation", "Monitor related entities"],
        "Medium": ["Schedule review within 48h", "Check related transactions"],
        "Low": ["No immediate action required", "Continue standard monitoring"],
    }

    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.Badge(tier, color=tier_color, size="lg"),
                    dmc.Text(f"ALT-{idx:06d}", fw=700, size="lg"),
                    dmc.Text(f"Score: {score:.0%}", c="dimmed"),
                ],
                justify="space-between",
                mb="md",
            ),
            dmc.Divider(mb="md"),
            dmc.Text("Risk Assessment", fw=600, mb="sm"),
            dmc.Text(narrative, size="sm", c="dimmed", mb="md"),
            dmc.Progress(value=min(int(score * 100), 100), color=tier_color, mb="lg"),

            dmc.Text("Detection Method Breakdown", fw=600, mb="sm") if method_items else None,
            dmc.Stack(method_items, gap="xs", mb="lg") if method_items else None,

            dmc.Text("Recommended Actions", fw=600, mb="sm"),
            dmc.List(
                [dmc.ListItem(a) for a in actions.get(tier, actions["Low"])],
                icon=DashIconify(icon="mdi:check-circle", color=THEME.SUCCESS),
            ),
        ],
        p="lg", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD, "marginBottom": "12px"},
    )


layout = dmc.Container(
    [
        dmc.Group(
            [
                dmc.Group([
                    dmc.Title("Customer Narratives", order=2),
                    dmc.Badge("Risk Explanations", color="cyan", variant="light"),
                ], gap="md"),
                dmc.Button(
                    "Refresh",
                    id="btn-refresh-narr",
                    leftSection=DashIconify(icon="mdi:refresh"),
                    color="cyan", variant="subtle", size="sm",
                ),
            ],
            justify="space-between",
            mb="lg",
        ),

        # Filters
        dmc.Paper(
            dmc.Group(
                [
                    dmc.Select(
                        id="narr-filter-tier", label="Risk Tier",
                        data=[
                            {"value": "all", "label": "All Tiers"},
                            {"value": "Critical", "label": "Critical"},
                            {"value": "High", "label": "High"},
                            {"value": "Medium", "label": "Medium"},
                            {"value": "Low", "label": "Low"},
                        ],
                        value="all", w=160,
                    ),
                    dmc.NumberInput(
                        id="narr-top-n", label="Show Top N Customers",
                        value=10, min=1, max=50, step=5, w=160,
                    ),
                ],
                gap="md",
            ),
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}, mb="lg",
        ),

        # Stats
        html.Div(id="narr-stats"),
        dmc.Space(h="md"),

        # Narrative Cards
        html.Div(id="narrative-content"),

        dcc.Interval(id="narr-refresh", interval=30000, n_intervals=0),
    ],
    fluid=True,
)


@callback(
    [Output("narrative-content", "children"),
     Output("narr-stats", "children")],
    [Input("btn-refresh-narr", "n_clicks"),
     Input("narr-filter-tier", "value"),
     Input("narr-top-n", "value"),
     Input("narr-refresh", "n_intervals"),
     Input("store-pipeline-complete", "data")],
)
def update_narratives(n_clicks, tier_filter, top_n, n_intervals, pipeline_complete):
    try:
        from utils.data_io import data_vault

        df = data_vault.get_scored_data()
        result = data_vault.load_pipeline_result()

        if df is None or "anomaly_score" not in df.columns or "risk_tier" not in df.columns:
            stats = dmc.SimpleGrid(
                cols=4, spacing="md", mb="lg",
                children=[
                    dmc.Paper([dmc.Text("Total Customers", c="dimmed", size="sm"),
                               dmc.Text("0", fw=700, size="xl")],
                              p="md", ta="center", radius="md",
                              style={"backgroundColor": THEME.DARK_BG_CARD}),
                ] * 4,
            )
            no_data = dmc.Alert(
                "No pipeline results available. Run the execution engine first to generate narratives from customer data.",
                color="gray", icon=DashIconify(icon="mdi:information"),
            )
            return no_data, stats

        # Filter to anomaly records
        alerts_df = df[df["anomaly_score"] > 0.3].sort_values("anomaly_score", ascending=False)

        if tier_filter != "all":
            alerts_df = alerts_df[alerts_df["risk_tier"] == tier_filter]

        top_n = top_n or 10
        display_df = alerts_df.head(top_n)
        score_cols = [c for c in df.columns if c.startswith("score_")]

        # Build cards
        cards = []
        for i, (_, row) in enumerate(display_df.iterrows()):
            cards.append(_build_narrative_card(row.to_dict(), i + 1, score_cols))

        if not cards:
            cards = [dmc.Text("No customers match the current filters.", c="dimmed", ta="center")]

        # V6: Stats at CUSTOMER level
        total = len(alerts_df)
        critical = int((alerts_df["risk_tier"] == "CRITICAL").sum()) + int((alerts_df["risk_tier"] == "Critical").sum())
        high = int((alerts_df["risk_tier"] == "HIGH").sum()) + int((alerts_df["risk_tier"] == "High").sum())
        medium = int((alerts_df["risk_tier"] == "MEDIUM").sum()) + int((alerts_df["risk_tier"] == "Medium").sum())

        stats = dmc.SimpleGrid(
            cols=4, spacing="md", mb="lg",
            children=[
                dmc.Paper([dmc.Text("Total Customers", c="dimmed", size="sm"),
                           dmc.Text(str(total), fw=700, size="xl")],
                          p="md", ta="center", radius="md",
                          style={"backgroundColor": THEME.DARK_BG_CARD}),
                dmc.Paper([dmc.Text("Critical Customers", c="dimmed", size="sm"),
                           dmc.Text(str(critical), fw=700, size="xl", c="red")],
                          p="md", ta="center", radius="md",
                          style={"backgroundColor": THEME.DARK_BG_CARD}),
                dmc.Paper([dmc.Text("High Risk Customers", c="dimmed", size="sm"),
                           dmc.Text(str(high), fw=700, size="xl", c="orange")],
                          p="md", ta="center", radius="md",
                          style={"backgroundColor": THEME.DARK_BG_CARD}),
                dmc.Paper([dmc.Text("Medium Risk Customers", c="dimmed", size="sm"),
                           dmc.Text(str(medium), fw=700, size="xl", c="yellow")],
                          p="md", ta="center", radius="md",
                          style={"backgroundColor": THEME.DARK_BG_CARD}),
            ],
        )

        return cards, stats

    except Exception as e:
        return dmc.Alert(f"Error: {e}", color="red"), html.Div()
