"""
Layer 4: Preprocessing
======================
Prepare data for detection algorithms with multiple matrix versions.

Matrix Versions: raw, scaled, pca, encoded
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional
from pathlib import Path
from sklearn.preprocessing import StandardScaler, MinMaxScaler, LabelEncoder
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import LAYERS


class Layer4Preprocessing:
    """
    Layer 4: Data preprocessing and matrix generation.
    
    Creates 4 matrix versions:
    - raw: Original numeric features
    - scaled: StandardScaler normalized
    - pca: PCA-reduced dimensionality
    - encoded: Categorical handling + scaling
    """
    
    def __init__(self):
        self.matrices: Dict[str, np.ndarray] = {}
        self.scalers: Dict[str, StandardScaler] = {}
        self.pca_model: Optional[PCA] = None
        self.label_encoders: Dict[str, LabelEncoder] = {}
        self.feature_names: List[str] = []
        self.id_columns: List[str] = []
    
    def preprocess(
        self, 
        df: pd.DataFrame,
        id_columns: List[str] = None,
        pca_components: int = 10
    ) -> Dict[str, np.ndarray]:
        """
        Generate all matrix versions.
        
        Args:
            df: Input DataFrame with features
            id_columns: Columns to exclude from processing
            pca_components: Number of PCA components
            
        Returns:
            Dict of matrix_name -> numpy array
        """
        self.id_columns = id_columns or []
        
        # Separate features from IDs
        feature_cols = [c for c in df.columns if c not in self.id_columns]
        df_features = df[feature_cols].copy()
        
        # Separate numeric and categorical
        numeric_cols = df_features.select_dtypes(include=[np.number]).columns.tolist()
        cat_cols = df_features.select_dtypes(include=['object', 'category']).columns.tolist()
        
        self.feature_names = numeric_cols
        
        # 1. Raw Matrix (numeric only, imputed)
        X_raw = self._create_raw_matrix(df_features[numeric_cols])
        self.matrices['raw'] = X_raw
        
        # 2. Scaled Matrix
        X_scaled = self._create_scaled_matrix(X_raw)
        self.matrices['scaled'] = X_scaled
        
        # 3. PCA Matrix
        n_components = min(pca_components, X_scaled.shape[1], X_scaled.shape[0])
        X_pca = self._create_pca_matrix(X_scaled, n_components)
        self.matrices['pca'] = X_pca
        
        # 4. Encoded Matrix (includes categoricals)
        X_encoded = self._create_encoded_matrix(df_features, numeric_cols, cat_cols)
        self.matrices['encoded'] = X_encoded
        
        return self.matrices
    
    def _create_raw_matrix(self, df_numeric: pd.DataFrame) -> np.ndarray:
        """Create raw numeric matrix with imputation."""
        imputer = SimpleImputer(strategy='median')
        X = imputer.fit_transform(df_numeric)
        
        # Replace infinities
        X = np.nan_to_num(X, nan=0, posinf=0, neginf=0)
        
        return X
    
    def _create_scaled_matrix(self, X: np.ndarray) -> np.ndarray:
        """Create scaled matrix using StandardScaler."""
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        self.scalers['standard'] = scaler
        
        return X_scaled
    
    def _create_pca_matrix(
        self, 
        X: np.ndarray, 
        n_components: int
    ) -> np.ndarray:
        """Create PCA-reduced matrix."""
        if n_components <= 0:
            return X
        
        self.pca_model = PCA(n_components=n_components)
        X_pca = self.pca_model.fit_transform(X)
        
        return X_pca
    
    def _create_encoded_matrix(
        self, 
        df: pd.DataFrame,
        numeric_cols: List[str],
        cat_cols: List[str]
    ) -> np.ndarray:
        """Create matrix with encoded categoricals."""
        parts = []
        
        # Numeric part (scaled)
        if numeric_cols:
            X_num = df[numeric_cols].fillna(0).values
            scaler = MinMaxScaler()
            X_num_scaled = scaler.fit_transform(X_num)
            self.scalers['minmax'] = scaler
            parts.append(X_num_scaled)
        
        # Categorical part (label encoded)
        for col in cat_cols:
            le = LabelEncoder()
            values = df[col].fillna('_missing_').astype(str)
            encoded = le.fit_transform(values).reshape(-1, 1)
            self.label_encoders[col] = le
            parts.append(encoded)
        
        if not parts:
            return np.zeros((len(df), 1))
        
        X_encoded = np.hstack(parts)
        
        return X_encoded
    
    def get_matrix(self, version: str = 'scaled') -> np.ndarray:
        """Get specific matrix version."""
        if version not in self.matrices:
            raise ValueError(f"Unknown matrix version: {version}. Available: {list(self.matrices.keys())}")
        return self.matrices[version]
    
    def transform(
        self, 
        df: pd.DataFrame, 
        version: str = 'scaled'
    ) -> np.ndarray:
        """Transform new data using fitted preprocessors."""
        # Align with fitted feature names
        if not self.feature_names:
            return np.zeros((len(df), 1))
            
        # Create DataFrame with all expected columns, initialized to 0
        X_df = pd.DataFrame(0, index=df.index, columns=self.feature_names)
        
        # Update with actual values where available
        available_cols = [c for c in self.feature_names if c in df.columns]
        if available_cols:
            X_df[available_cols] = df[available_cols].fillna(0)
            
        X = X_df.values
        
        if version == 'raw':
            return np.nan_to_num(X)
        elif version == 'scaled':
            if 'standard' in self.scalers:
                return self.scalers['standard'].transform(X)
            return X
        elif version == 'pca':
            if 'standard' in self.scalers and self.pca_model:
                X_scaled = self.scalers['standard'].transform(X)
                return self.pca_model.transform(X_scaled)
            return X
        else:
            return X
    
    def get_summary(self) -> Dict:
        """Get preprocessing summary."""
        return {
            "matrix_versions": list(self.matrices.keys()),
            "shapes": {k: v.shape for k, v in self.matrices.items()},
            "n_features": len(self.feature_names),
            "pca_variance_ratio": getattr(self.pca_model, 'explained_variance_ratio_', None)
        }
