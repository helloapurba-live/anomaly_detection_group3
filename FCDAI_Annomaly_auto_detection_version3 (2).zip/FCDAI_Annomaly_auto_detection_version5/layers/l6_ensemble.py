"""
Layer 6: Ensemble Fusion — V5 (Concordance-Based)
===================================================
Combine 22 detection scores into unified risk assessment.

V5 Improvements:
- Concordance Index weighting (not variance — variance rewards noise)
- Rank-based fusion for distribution-agnostic combination
- Robust median method as additional option

Methods: concordance_weighted, rank_fusion, max, voting, stacking
Risk Tiers: Critical, High, Medium, Low
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from pathlib import Path
from dataclasses import dataclass
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import LAYERS


@dataclass
class EnsembleResult:
    """Result of ensemble fusion."""
    final_scores: np.ndarray
    risk_tiers: np.ndarray
    method_weights: Dict[str, float]
    tier_counts: Dict[str, int]


class Layer6Ensemble:
    """
    Layer 6: Ensemble score fusion and risk tier assignment.
    
    V5: Uses concordance-based weighting instead of variance.
    Methods that agree with the majority get higher weight.
    """
    
    def __init__(self, method: str = "weighted_average"):
        """
        Initialize ensemble layer.
        
        Args:
            method: Fusion method (weighted_average, rank_fusion, max, voting, stacking)
        """
        self.method = method
        self.risk_tiers = LAYERS.RISK_TIERS
        self.weights: Dict[str, float] = {}
    
    def fuse(
        self, 
        score_matrix: np.ndarray,
        method_names: List[str],
        weights: Dict[str, float] = None
    ) -> EnsembleResult:
        """
        Fuse detection scores into unified risk score.
        
        Args:
            score_matrix: (n_samples, n_methods) matrix of scores
            method_names: Names of detection methods
            weights: Optional custom weights per method
            
        Returns:
            EnsembleResult with final scores and risk tiers
        """
        if score_matrix.size == 0:
            return EnsembleResult(
                final_scores=np.array([]),
                risk_tiers=np.array([]),
                method_weights={},
                tier_counts={}
            )
        
        # Set weights
        if weights:
            self.weights = weights
        else:
            self.weights = self._compute_concordance_weights(score_matrix, method_names)
        
        # Apply fusion method
        if self.method == "weighted_average":
            final_scores = self._weighted_average(score_matrix, method_names)
        elif self.method == "rank_fusion":
            final_scores = self._rank_fusion(score_matrix)
        elif self.method == "max":
            final_scores = self._max_fusion(score_matrix)
        elif self.method == "voting":
            final_scores = self._voting(score_matrix)
        elif self.method == "stacking":
            final_scores = self._stacking(score_matrix)
        else:
            final_scores = self._weighted_average(score_matrix, method_names)
        
        # Assign risk tiers
        risk_tiers = self._assign_risk_tiers(final_scores)
        
        # Count tiers
        unique, counts = np.unique(risk_tiers, return_counts=True)
        tier_counts = dict(zip(unique, counts.astype(int)))
        
        return EnsembleResult(
            final_scores=final_scores,
            risk_tiers=risk_tiers,
            method_weights=self.weights,
            tier_counts=tier_counts
        )
    
    def _compute_concordance_weights(
        self, 
        score_matrix: np.ndarray, 
        method_names: List[str]
    ) -> Dict[str, float]:
        """Compute weights using Concordance Index (V5).
        
        Instead of variance (which rewards noisy methods), we measure
        how much each method agrees with the ensemble median ranking.
        Methods that agree more with the consensus get higher weight.
        """
        n_methods = score_matrix.shape[1]
        
        if n_methods <= 1:
            return {name: 1.0 for name in method_names}
        
        # 1. Compute rank percentiles for each method (distribution-agnostic)
        ranks = np.zeros_like(score_matrix)
        for j in range(n_methods):
            col = score_matrix[:, j]
            order = np.argsort(col)
            ranks[order, j] = np.arange(len(col)) / (len(col) - 1 + 1e-8)
        
        # 2. Median rank across methods (consensus ordering)
        median_rank = np.median(ranks, axis=1)
        
        # 3. Concordance: Spearman correlation with consensus
        concordances = np.zeros(n_methods)
        for j in range(n_methods):
            col_rank = ranks[:, j]
            # Spearman correlation with median consensus
            d = col_rank - median_rank
            ss_d = np.sum(d ** 2)
            n = len(d)
            rho = 1 - (6 * ss_d) / (n * (n**2 - 1) + 1e-8)
            concordances[j] = max(0, rho)  # Only positive concordance counts
        
        # 4. Normalize to sum to 1
        total = concordances.sum() + 1e-8
        weights = {}
        for i, name in enumerate(method_names):
            weights[name] = float(concordances[i] / total)
        
        return weights
    
    def _weighted_average(
        self, 
        score_matrix: np.ndarray,
        method_names: List[str]
    ) -> np.ndarray:
        """Concordance-weighted average of scores."""
        weight_array = np.array([
            self.weights.get(name, 1.0 / len(method_names)) 
            for name in method_names
        ])
        weight_array = weight_array / (weight_array.sum() + 1e-8)
        
        return np.dot(score_matrix, weight_array)
    
    def _rank_fusion(self, score_matrix: np.ndarray) -> np.ndarray:
        """Rank-based fusion (V5 new method).
        
        Converts each method's scores to rank percentiles, then averages.
        This is robust to different score distributions across methods.
        """
        n_samples, n_methods = score_matrix.shape
        rank_matrix = np.zeros_like(score_matrix)
        
        for j in range(n_methods):
            col = score_matrix[:, j]
            order = np.argsort(col)
            rank_matrix[order, j] = np.arange(n_samples) / (n_samples - 1 + 1e-8)
        
        # Weighted by concordance
        weight_names = list(self.weights.keys())
        weight_array = np.array([self.weights.get(name, 1.0 / n_methods) for name in weight_names])
        if len(weight_array) == n_methods:
            weight_array = weight_array / (weight_array.sum() + 1e-8)
            return np.dot(rank_matrix, weight_array)
        else:
            return rank_matrix.mean(axis=1)
    
    def _max_fusion(self, score_matrix: np.ndarray) -> np.ndarray:
        """Maximum score across all methods."""
        return np.max(score_matrix, axis=1)
    
    def _voting(self, score_matrix: np.ndarray, threshold: float = 0.5) -> np.ndarray:
        """Voting based on threshold."""
        votes = (score_matrix > threshold).astype(float)
        return votes.mean(axis=1)
    
    def _stacking(self, score_matrix: np.ndarray) -> np.ndarray:
        """Meta-learner stacking using robust statistics."""
        mean_scores = np.mean(score_matrix, axis=1)
        median_scores = np.median(score_matrix, axis=1)
        max_scores = np.max(score_matrix, axis=1)
        
        # MAD (Median Absolute Deviation) — robust spread measure
        mad = np.median(np.abs(score_matrix - median_scores[:, None]), axis=1)
        
        # Combine: mean + median + max + spread signal
        stacked = 0.35 * mean_scores + 0.25 * median_scores + 0.25 * max_scores + 0.15 * mad
        return np.clip(stacked, 0, 1)
    
    def _assign_risk_tiers(self, scores: np.ndarray) -> np.ndarray:
        """Assign risk tier based on score thresholds."""
        tiers = np.empty(len(scores), dtype='<U10')
        
        for tier_name, (low, high) in self.risk_tiers.items():
            mask = (scores >= low) & (scores < high)
            tiers[mask] = tier_name
        
        # Handle edge cases
        tiers[scores >= 1.0] = "Critical"
        tiers[scores < 0.0] = "Low"
        
        return tiers
    
    def get_high_risk_indices(
        self, 
        result: EnsembleResult, 
        tiers: List[str] = None
    ) -> np.ndarray:
        """Get indices of high-risk records."""
        if tiers is None:
            tiers = ["Critical", "High"]
        
        mask = np.isin(result.risk_tiers, tiers)
        return np.where(mask)[0]
    
    def get_summary(self, result: EnsembleResult) -> Dict:
        """Get ensemble summary."""
        return {
            "fusion_method": self.method,
            "total_records": len(result.final_scores),
            "tier_distribution": result.tier_counts,
            "score_stats": {
                "mean": float(np.mean(result.final_scores)) if len(result.final_scores) > 0 else 0,
                "std": float(np.std(result.final_scores)) if len(result.final_scores) > 0 else 0,
                "max": float(np.max(result.final_scores)) if len(result.final_scores) > 0 else 0,
                "min": float(np.min(result.final_scores)) if len(result.final_scores) > 0 else 0,
            },
            "top_weighted_methods": sorted(
                result.method_weights.items(), 
                key=lambda x: x[1], 
                reverse=True
            )[:5]
        }


class RiskRanker:
    """Additional risk ranking utilities."""
    
    @staticmethod
    def rank_by_score(
        indices: np.ndarray, 
        scores: np.ndarray
    ) -> np.ndarray:
        """Rank indices by score (highest first)."""
        order = np.argsort(scores[indices])[::-1]
        return indices[order]
    
    @staticmethod
    def prioritize_for_investigation(
        result: EnsembleResult,
        capacity: int = 1000
    ) -> np.ndarray:
        """Prioritize records for investigation queue."""
        order = np.argsort(result.final_scores)[::-1]
        return order[:capacity]
    
    @staticmethod
    def compute_risk_percentile(scores: np.ndarray) -> np.ndarray:
        """Compute percentile rank for each score."""
        try:
            from scipy import stats
            return stats.rankdata(scores, method='average') / len(scores) * 100
        except ImportError:
            n = len(scores)
            order = np.argsort(scores)
            ranks = np.zeros(n)
            ranks[order] = np.arange(n) / (n - 1 + 1e-8) * 100
            return ranks
