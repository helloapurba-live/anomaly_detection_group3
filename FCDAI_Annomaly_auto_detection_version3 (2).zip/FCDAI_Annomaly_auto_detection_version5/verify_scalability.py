
import sys
import time
from pathlib import Path
import pandas as pd

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from utils.data_gen import DataGenerator
from utils.data_io import data_vault
from pipeline import VanguardPipeline
from utils.logger import logger

def test_scalability(num_customers=100000):
    print(f"Starting Scalability Test for {num_customers} customers...")
    logger.log_action(f"START: Scalability Test ({num_customers})")
    
    start_total = time.time()
    
    # 1. Data Generation
    print("1. Generating Data...")
    start_gen = time.time()
    dg = DataGenerator()
    data_map = dg.generate_full_schema(num_customers)
    
    # Merge for pipeline input (mimic dashboard logic)
    df_tx = data_map['transactions']
    df_acc = data_map['account']
    df_party = data_map['party']
    
    df_merged = df_tx.merge(df_acc, on='account_id', how='left')
    df_merged = df_merged.merge(df_party, on='party_id', how='left')
    
    gen_time = time.time() - start_gen
    print(f"   Generated {len(df_merged)} rows in {gen_time:.2f}s")
    
    # 2. Persist to Vault
    print("2. Saving to Vault...")
    data_vault._current_data = df_merged
    data_vault._persist_data()
    
    # 3. Run Pipeline
    print("3. Executing Pipeline...")
    start_pipe = time.time()
    pipeline = VanguardPipeline()
    result = pipeline.run(
        sources={"transactions": df_merged},
        customer_col="customer_id",
        amount_col="amount",
        timestamp_col="timestamp"
    )
    
    pipe_time = time.time() - start_pipe
    total_time = time.time() - start_total
    
    print("="*60)
    print(f"SCALABILITY TEST RESULTS ({num_customers} Customers)")
    print("="*60)
    print(f"Status:        {'SUCCESS' if result.success else 'FAILED'}")
    print(f"Rows Processed: {len(df_merged)}")
    print(f"Generation Time: {gen_time:.2f}s")
    print(f"Pipeline Time:   {pipe_time:.2f}s")
    print(f"Total Time:      {total_time:.2f}s")
    print(f"TPS (Est):       {len(df_merged)/total_time:.0f} rows/sec")
    print("="*60)
    
    if not result.success:
        print(f"Error: {result.error}")

if __name__ == "__main__":
    # Test with 10k customers (300k records) to verify memory fix quickly
    test_scalability(10000)
