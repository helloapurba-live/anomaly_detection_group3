
import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from pathlib import Path
import logging

# Configure logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("DataGen")

# ── Name pools for realistic customer names ──────────────────────────────────
FIRST_NAMES = [
    "James", "Mary", "Robert", "Jennifer", "John", "Linda", "Michael", "Sarah",
    "David", "Jessica", "William", "Emily", "Richard", "Amanda", "Joseph", "Rachel",
    "Thomas", "Laura", "Christopher", "Megan", "Daniel", "Hannah", "Matthew", "Olivia",
    "Andrew", "Sophia", "Joshua", "Emma", "Anthony", "Grace", "Kevin", "Chloe",
    "Raj", "Priya", "Wei", "Mei", "Ahmed", "Fatima", "Carlos", "Maria",
]
LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
    "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson",
    "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson",
    "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson",
    "Patel", "Chen", "Wang", "Kim", "Nguyen", "Singh", "Kumar", "Ali", "Abbas", "Tanaka",
]


class DataGenerator:
    """
    V5 Data Generator — 8 tables for full AML coverage.
    Tables: Transactions, Customer (Party), Account, Alert, Case, KYC,
            Watchlist, Relationships
    """

    def __init__(self, seed: int = 42):
        np.random.seed(seed)
        random.seed(seed)

    def generate_party_data(self, num_parties: int = 100) -> pd.DataFrame:
        """Generates Party/Customer metadata with realistic names."""
        ids = [f"CUST_{i:06d}" for i in range(num_parties)]
        types = np.random.choice(['Individual', 'Corporate', 'Trust'], num_parties, p=[0.7, 0.2, 0.1])
        risk_ratings = np.random.choice(['Low', 'Medium', 'High'], num_parties, p=[0.6, 0.3, 0.1])
        countries = np.random.choice(['US', 'UK', 'SG', 'KY', 'VG', 'DE', 'JP', 'IN'], num_parties)

        # Generate realistic customer names
        names = [
            f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"
            for _ in range(num_parties)
        ]

        df = pd.DataFrame({
            'party_id': ids,
            'customer_name': names,
            'party_type': types,
            'risk_rating': risk_ratings,
            'country_of_origin': countries,
            'kyc_status': np.random.choice(['Verified', 'Pending', 'Expired'], num_parties, p=[0.75, 0.15, 0.10]),
            'onboarding_date': [datetime.now() - timedelta(days=random.randint(10, 3650)) for _ in range(num_parties)]
        })
        logger.info(f"Generated {len(df)} Party/Customer records.")
        return df

    def generate_account_data(self, party_ids: List[str]) -> pd.DataFrame:
        """Generates Account data linked to Parties."""
        num_accounts = int(len(party_ids) * 1.5)
        acc_ids = [f"ACC_{i:09d}" for i in range(num_accounts)]
        owners = np.random.choice(party_ids, num_accounts)

        df = pd.DataFrame({
            'account_id': acc_ids,
            'party_id': owners,
            'account_type': np.random.choice(['Savings', 'Current', 'Corporate', 'Investment'], num_accounts),
            'status': np.random.choice(['Active', 'Dormant', 'Frozen'], num_accounts, p=[0.9, 0.08, 0.02]),
            'currency': np.random.choice(['USD', 'EUR', 'GBP', 'SGD'], num_accounts),
            'balance': np.random.exponential(25000, num_accounts).round(2),
            'open_date': [datetime.now() - timedelta(days=random.randint(10, 2000)) for _ in range(num_accounts)]
        })
        logger.info(f"Generated {len(df)} Account records.")
        return df

    def generate_transactions(self, account_ids: List[str], num_txns: int = 1000) -> pd.DataFrame:
        """Generates core Transaction ledger."""
        df = pd.DataFrame({
            'txn_id': [f"TXN_{i:09d}" for i in range(num_txns)],
            'account_id': np.random.choice(account_ids, num_txns),
            'counterparty_account': [f"EXT_{random.randint(1000,9999)}" for _ in range(num_txns)],
            'amount': np.random.exponential(1000, num_txns).round(2),
            'currency': 'USD',
            'txn_type': np.random.choice(['Wire', 'ACH', 'Cash', 'Check'], num_txns),
            'timestamp': [datetime.now() - timedelta(days=random.randint(0, 30), hours=random.randint(0, 23)) for _ in range(num_txns)],
            'is_credit': np.random.choice([True, False], num_txns)
        })

        # Derive customer_id from account_id
        df['customer_id'] = df['account_id'].apply(
            lambda x: f"CUST_{int(x.split('_')[1]) // 2:06d}" if '_' in str(x) else 'UNKNOWN'
        )
        # Add structuring anomalies (~2%)
        mask = np.random.random(num_txns) < 0.02
        df.loc[mask, 'amount'] = 9900 + np.random.uniform(0, 99, sum(mask))

        logger.info(f"Generated {len(df)} Transaction records.")
        return df

    def generate_alert_data(self, party_ids: List[str], num_alerts: int = None) -> pd.DataFrame:
        """Generates historical Alert records linked to customers."""
        if num_alerts is None:
            num_alerts = max(20, int(len(party_ids) * 0.3))
        df = pd.DataFrame({
            'alert_id': [f"ALT_{i:06d}" for i in range(num_alerts)],
            'party_id': np.random.choice(party_ids, num_alerts),
            'alert_type': np.random.choice(
                ['Structuring', 'Rapid Movement', 'Large Cash', 'Wire Pattern',
                 'Dormant Activation', 'Sanctions Hit', 'Unusual Volume'],
                num_alerts
            ),
            'severity': np.random.choice(['Critical', 'High', 'Medium', 'Low'], num_alerts, p=[0.05, 0.15, 0.40, 0.40]),
            'status': np.random.choice(['Open', 'Investigating', 'Escalated', 'Closed'], num_alerts, p=[0.25, 0.20, 0.10, 0.45]),
            'created_at': [datetime.now() - timedelta(days=random.randint(0, 90)) for _ in range(num_alerts)],
            'assigned_to': np.random.choice(['Analyst_A', 'Analyst_B', 'Analyst_C', 'Unassigned'], num_alerts),
        })
        logger.info(f"Generated {len(df)} Alert records.")
        return df

    def generate_case_data(self, party_ids: List[str], num_cases: int = None) -> pd.DataFrame:
        """Generates Case/Investigation records linked to customers."""
        if num_cases is None:
            num_cases = max(10, int(len(party_ids) * 0.05))
        df = pd.DataFrame({
            'case_id': [f"CASE_{i:06d}" for i in range(num_cases)],
            'party_id': np.random.choice(party_ids, num_cases),
            'case_type': np.random.choice(['Regulatory Filing', 'STR', 'Internal Review', 'Regulatory'], num_cases),
            'status': np.random.choice(['Open', 'In Progress', 'Closed - Filed', 'Closed - No Action'], num_cases, p=[0.20, 0.30, 0.25, 0.25]),
            'priority': np.random.choice(['P1', 'P2', 'P3'], num_cases, p=[0.15, 0.35, 0.50]),
            'opened_date': [datetime.now() - timedelta(days=random.randint(0, 180)) for _ in range(num_cases)],
            'investigator': np.random.choice(['Inv_Senior', 'Inv_Lead', 'Inv_Junior'], num_cases),
        })
        logger.info(f"Generated {len(df)} Case records.")
        return df

    def generate_kyc_data(self, party_ids: List[str]) -> pd.DataFrame:
        """Generates KYC review records per customer."""
        df = pd.DataFrame({
            'kyc_id': [f"KYC_{i:06d}" for i in range(len(party_ids))],
            'party_id': party_ids,
            'verification_status': np.random.choice(
                ['Verified', 'Pending Review', 'Expired', 'Failed'],
                len(party_ids), p=[0.70, 0.15, 0.10, 0.05]
            ),
            'risk_score': np.random.uniform(0, 1, len(party_ids)).round(3),
            'last_review': [datetime.now() - timedelta(days=random.randint(0, 365)) for _ in range(len(party_ids))],
            'next_review': [datetime.now() + timedelta(days=random.randint(30, 365)) for _ in range(len(party_ids))],
            'doc_type': np.random.choice(['Passport', 'Driving License', 'National ID', 'Utility Bill'], len(party_ids)),
            'reviewer': np.random.choice(['KYC_Team_1', 'KYC_Team_2', 'Auto_Verified'], len(party_ids)),
        })
        logger.info(f"Generated {len(df)} KYC records.")
        return df

    def generate_watchlist_data(self, size: int = 50) -> pd.DataFrame:
        """Generates Sanctions/Watchlist data."""
        df = pd.DataFrame({
            'watchlist_id': [f"WL_{i:05d}" for i in range(size)],
            'entity_name': [f"Bad Actor {i}" for i in range(size)],
            'list_source': np.random.choice(['OFAC', 'UN', 'EU', 'HM_TREASURY'], size),
            'category': np.random.choice(['Sanctions', 'PEP', 'Adverse Media'], size),
            'added_date': [datetime.now() - timedelta(days=random.randint(1, 1000)) for _ in range(size)]
        })
        return df

    def generate_relationship_data(self, party_ids: List[str], count: int = 200) -> pd.DataFrame:
        """Generates links between parties."""
        df = pd.DataFrame({
            'from_party_id': np.random.choice(party_ids, count),
            'to_party_id': np.random.choice(party_ids, count),
            'relationship_type': np.random.choice(['Director', 'Shareholder', 'Signatory', 'Guarantor'], count),
            'percentage': np.random.uniform(1, 100, count).round(2)
        })
        df = df[df['from_party_id'] != df['to_party_id']]
        return df

    def generate_full_schema(self, num_customers: int = 100) -> Dict[str, pd.DataFrame]:
        """
        Orchestrates generation of all 8 tables based on customer count.

        Returns dict with keys:
            transactions, party, account, alert, case, kyc, watchlist, relationships
        """
        logger.info(f"Generating schema for {num_customers} customers...")

        # 1. Parties / Customers
        parties = self.generate_party_data(num_customers)
        party_ids = parties['party_id'].tolist()

        # 2. Accounts (1.5x per customer)
        accounts = self.generate_account_data(party_ids)
        account_ids = accounts['account_id'].tolist()

        # 3. Transactions (20 per account)
        avg_txns_per_acct = 20
        total_txns = len(account_ids) * avg_txns_per_acct
        txns = self.generate_transactions(account_ids, total_txns)

        # 4. Alerts (~30% of customers)
        alerts = self.generate_alert_data(party_ids)

        # 5. Cases (~5% of customers)
        cases = self.generate_case_data(party_ids)

        # 6. KYC (1 per customer)
        kyc = self.generate_kyc_data(party_ids)

        # 7. Watchlist (fixed size)
        wl_size = min(1000, max(50, int(num_customers * 0.01)))
        watchlist = self.generate_watchlist_data(wl_size)

        # 8. Relationships (2x customers)
        rel_count = int(num_customers * 2)
        relationships = self.generate_relationship_data(party_ids, rel_count)

        logger.info("Schema generation complete.")
        return {
            "transactions": txns,
            "party": parties,
            "account": accounts,
            "alert": alerts,
            "case": cases,
            "kyc": kyc,
            "watchlist": watchlist,
            "relationships": relationships,
        }


if __name__ == "__main__":
    dg = DataGenerator()
    data = dg.generate_full_schema(100)
    for k, v in data.items():
        print(f"{k}: {v.shape}")
