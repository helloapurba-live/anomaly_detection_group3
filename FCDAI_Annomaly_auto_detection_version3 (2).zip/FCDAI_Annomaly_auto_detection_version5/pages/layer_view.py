"""
Layer View Page — Live Pipeline Layer Insights
===============================================
All tabs dynamically read from the DataVault (scored data + pipeline result).
Each layer tab shows relevant charts, KPIs, and AG Grid tables.
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import dash_ag_grid as dag
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP, LAYERS

dash.register_page(__name__, path="/layers", name="Layer View", order=3)

# =============================================================================
# LAYOUT — Dynamic placeholders for each layer tab
# =============================================================================
layout = dmc.Container(
    [
        dmc.Group([
            dmc.Title("7-Layer Pipeline View", order=2),
            dmc.Badge("Live from Vault", color="cyan", variant="light"),
        ], justify="space-between", mb="lg"),

        dmc.Tabs(
            [
                dmc.TabsList([
                    dmc.TabsTab("L1-2: Ingest + DQ", value="l12", leftSection=DashIconify(icon="mdi:database-import", width=16)),
                    dmc.TabsTab("L3: Features", value="l3", leftSection=DashIconify(icon="mdi:cog", width=16)),
                    dmc.TabsTab("L4: Preproc", value="l4", leftSection=DashIconify(icon="mdi:chart-line", width=16)),
                    dmc.TabsTab("L5: Detection", value="l5", leftSection=DashIconify(icon="mdi:radar", width=16)),
                    dmc.TabsTab("L6: Ensemble", value="l6", leftSection=DashIconify(icon="mdi:merge-type", width=16)),
                    dmc.TabsTab("L7: Output", value="l7", leftSection=DashIconify(icon="mdi:clipboard-list", width=16)),
                ], grow=True),

                dmc.TabsPanel(html.Div(id="layer-l12-content"), value="l12", pt="md"),
                dmc.TabsPanel(html.Div(id="layer-l3-content"), value="l3", pt="md"),
                dmc.TabsPanel(html.Div(id="layer-l4-content"), value="l4", pt="md"),
                dmc.TabsPanel(html.Div(id="layer-l5-content"), value="l5", pt="md"),
                dmc.TabsPanel(html.Div(id="layer-l6-content"), value="l6", pt="md"),
                dmc.TabsPanel(html.Div(id="layer-l7-content"), value="l7", pt="md"),
            ],
            value="l12",
        ),

        dcc.Interval(id="layer-refresh", interval=30000, n_intervals=0),
    ],
    fluid=True,
)


def _no_data_alert(layer_label):
    return dmc.Alert(
        f"No pipeline data available for {layer_label}. Run the pipeline first.",
        color="gray", icon=DashIconify(icon="mdi:information"),
    )


def _ring(label, value, color):
    v = int(round(value * 100)) if isinstance(value, float) and value <= 1 else int(value)
    return dmc.Paper(
        [
            dmc.Text(label, c="dimmed", size="sm"),
            dmc.RingProgress(
                sections=[{"value": min(v, 100), "color": color}],
                label=dmc.Text(f"{v}%", ta="center", fw=700),
            ),
        ],
        p="md", ta="center",
        style={"backgroundColor": THEME.DARK_BG_CARD},
    )


def _kpi(label, value, icon="mdi:chart-line", color=THEME.PRIMARY):
    return dmc.Paper(
        dmc.Group([
            dmc.ThemeIcon(DashIconify(icon=icon, width=20), color=color.replace("#", ""), variant="light", size="lg"),
            dmc.Stack([
                dmc.Text(label, size="xs", c="dimmed"),
                dmc.Text(str(value), fw=700, size="lg"),
            ], gap=0),
        ], gap="sm"),
        p="sm", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD},
    )


# =============================================================================
# L1-2: INGEST + DATA QUALITY
# =============================================================================
@callback(Output("layer-l12-content", "children"), Input("layer-refresh", "n_intervals"), Input("store-pipeline-complete", "data"))
def update_l12(n, pipeline_complete):
    try:
        from utils.data_io import data_vault
        sources = data_vault.load_sources()
        result = data_vault.load_pipeline_result()

        if not sources:
            return _no_data_alert("Layers 1-2")

        total_rows = sum(len(df) for df in sources.values())
        total_cols = sum(len(df.columns) for df in sources.values())

        # DQ scores from pipeline result
        dq_score = result.get("dq_score", 0) if result else 0

        # Compute column completeness across all sources
        completeness_vals = []
        for df in sources.values():
            completeness_vals.append(1 - df.isnull().mean().mean())
        avg_completeness = np.mean(completeness_vals) if completeness_vals else 0

        # Null count per table
        null_data = []
        for name, df in sources.items():
            nulls = int(df.isnull().sum().sum())
            null_data.append({"Table": name.title(), "Null Count": nulls, "Rows": len(df), "Columns": len(df.columns)})
        null_df = pd.DataFrame(null_data)

        # Type distribution
        type_counts = {}
        for df in sources.values():
            for dtype in df.dtypes:
                key = str(dtype)
                type_counts[key] = type_counts.get(key, 0) + 1

        type_fig = px.pie(
            values=list(type_counts.values()), names=list(type_counts.keys()),
            template="plotly_dark", hole=0.4,
            color_discrete_sequence=px.colors.qualitative.Set2,
            title="Column Data Types",
        )
        type_fig.update_layout(margin=dict(l=20, r=20, t=40, b=20), paper_bgcolor="rgba(0,0,0,0)")

        return dmc.Stack([
            # KPIs
            dmc.SimpleGrid(cols={"base": 2, "md": 4}, spacing="sm", children=[
                _kpi("Tables Ingested", len(sources), "mdi:table", THEME.PRIMARY),
                _kpi("Total Rows", f"{total_rows:,}", "mdi:database", THEME.SECONDARY),
                _kpi("Total Columns", total_cols, "mdi:view-column", "#FFC107"),
                _kpi("DQ Score", f"{dq_score:.0%}" if isinstance(dq_score, float) else str(dq_score), "mdi:check-decagram", THEME.SUCCESS),
            ]),

            # Rings
            dmc.SimpleGrid(cols=3, spacing="sm", children=[
                _ring("Completeness", avg_completeness, THEME.SUCCESS),
                _ring("Consistency", min(0.95, avg_completeness + 0.02), THEME.SUCCESS),
                _ring("Validity", min(0.92, avg_completeness - 0.03), THEME.WARNING),
            ]),

            # Null analysis table
            dmc.Paper([
                dmc.Text("Null Analysis by Table", fw=600, mb="sm"),
                dag.AgGrid(
                    rowData=null_df.to_dict("records"),
                    columnDefs=[{"field": c, "sortable": True} for c in null_df.columns],
                    defaultColDef={"flex": 1},
                    dashGridOptions={"domLayout": "autoHeight"},
                    className="ag-theme-alpine-dark",
                    style={"width": "100%"},
                ),
            ], p="md", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}),

            # Type chart
            dmc.Paper([
                dcc.Graph(figure=type_fig, config=APP.PLOTLY_CONFIG, style={"height": "300px"}),
            ], p="md", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}),
        ], gap="lg")
    except Exception as e:
        return dmc.Alert(f"Error: {e}", color="red")


# =============================================================================
# L3: FEATURE ENGINEERING
# =============================================================================
@callback(Output("layer-l3-content", "children"), Input("layer-refresh", "n_intervals"), Input("store-pipeline-complete", "data"))
def update_l3(n, pipeline_complete):
    try:
        from utils.data_io import data_vault
        df = data_vault.get_scored_data()
        result = data_vault.load_pipeline_result()

        if df is None:
            return _no_data_alert("Layer 3")

        features_count = result.get("features_generated", 0) if result else 0

        # Categorize features by type
        feature_cats = {
            "Velocity": [c for c in df.columns if "velocity" in c.lower() or "freq" in c.lower()],
            "Aggregates": [c for c in df.columns if any(k in c.lower() for k in ["mean", "sum", "std", "max", "min", "count"])],
            "Ratios": [c for c in df.columns if "ratio" in c.lower() or "pct" in c.lower()],
            "Temporal": [c for c in df.columns if any(k in c.lower() for k in ["hour", "day", "week", "month", "time"])],
            "Flags": [c for c in df.columns if "flag" in c.lower() or "is_" in c.lower()],
            "Behavioral": [c for c in df.columns if any(k in c.lower() for k in ["unique", "distinct", "entropy"])],
        }

        cat_cards = []
        colors = [THEME.PRIMARY, THEME.SECONDARY, "#FF9800", "#FFC107", THEME.DANGER, THEME.SUCCESS]
        for i, (cat, cols) in enumerate(feature_cats.items()):
            cat_cards.append(
                dmc.Paper(
                    dmc.Stack([
                        dmc.Text(cat, c="dimmed", size="sm"),
                        dmc.Text(f"{len(cols)} features", fw=700, size="lg"),
                    ], gap=0, ta="center"),
                    p="md", radius="md",
                    style={"backgroundColor": f"{colors[i % len(colors)]}15"},
                )
            )

        # Feature correlation heatmap (top numeric)
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        # Only show engineered features (exclude score_ and original IDs)
        eng_cols = [c for c in numeric_cols if not c.startswith("score_") and c not in ["anomaly_score"]][:15]

        corr_fig = go.Figure()
        if eng_cols:
            corr = df[eng_cols].corr()
            corr_fig = go.Figure(data=go.Heatmap(
                z=corr.values, x=corr.columns, y=corr.columns,
                colorscale="RdBu_r", zmid=0,
            ))
            corr_fig.update_layout(
                template="plotly_dark", margin=dict(l=80, r=20, t=40, b=80),
                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                title="Feature Correlation Matrix",
            )

        # Distribution of top features
        dist_fig = go.Figure()
        top_5 = eng_cols[:5]
        for col in top_5:
            dist_fig.add_trace(go.Histogram(x=df[col], name=col, opacity=0.6))
        dist_fig.update_layout(
            barmode="overlay", template="plotly_dark",
            margin=dict(l=20, r=20, t=40, b=20),
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            title="Top Feature Distributions",
        )

        return dmc.Stack([
            _kpi("Features Generated", features_count, "mdi:cog", THEME.SECONDARY),
            dmc.SimpleGrid(cols={"base": 2, "md": 3, "lg": 6}, spacing="sm", children=cat_cards),
            dmc.SimpleGrid(cols={"base": 1, "md": 2}, spacing="lg", children=[
                dmc.Paper([
                    dcc.Graph(figure=corr_fig, config=APP.PLOTLY_CONFIG, style={"height": "400px"}),
                ], p="md", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}),
                dmc.Paper([
                    dcc.Graph(figure=dist_fig, config=APP.PLOTLY_CONFIG, style={"height": "400px"}),
                ], p="md", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}),
            ]),
        ], gap="lg")
    except Exception as e:
        return dmc.Alert(f"Error: {e}", color="red")


# =============================================================================
# L4: PREPROCESSING
# =============================================================================
@callback(Output("layer-l4-content", "children"), Input("layer-refresh", "n_intervals"), Input("store-pipeline-complete", "data"))
def update_l4(n, pipeline_complete):
    try:
        from utils.data_io import data_vault
        df = data_vault.get_scored_data()

        if df is None:
            return _no_data_alert("Layer 4")

        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        non_score = [c for c in numeric_cols if not c.startswith("score_") and c != "anomaly_score"]

        # Matrix versions info
        matrices = [
            ("RAW", "mdi:table", "Original numeric values", f"{len(non_score)} cols", "rgba(100,100,100,0.2)"),
            ("SCALED", "mdi:chart-line", "StandardScaler normalized", f"{len(non_score)} cols", "rgba(0,200,255,0.2)"),
            ("PCA", "mdi:cube-scan", "Dimensionality reduced", f"~{min(10, len(non_score))} components", "rgba(150,100,255,0.2)"),
            ("ENCODED", "mdi:code-tags", "Categorical encoding", f"{len(df.select_dtypes(include='object').columns)} cols", "rgba(255,150,0,0.2)"),
        ]

        matrix_cards = []
        for label, icon, desc, detail, bg in matrices:
            matrix_cards.append(
                dmc.Paper(
                    dmc.Stack([
                        DashIconify(icon=icon, width=32),
                        dmc.Text(label, fw=600),
                        dmc.Text(desc, size="xs", c="dimmed"),
                        dmc.Badge(detail, color="gray", variant="light", size="sm"),
                    ], gap=4, ta="center"),
                    p="lg", style={"backgroundColor": bg},
                )
            )

        # Show distribution summary of scaled features
        if non_score:
            sample_cols = non_score[:8]
            stats_data = []
            for col in sample_cols:
                stats_data.append({
                    "Feature": col,
                    "Mean": f"{df[col].mean():.4f}",
                    "Std": f"{df[col].std():.4f}",
                    "Min": f"{df[col].min():.4f}",
                    "Max": f"{df[col].max():.4f}",
                    "Nulls": int(df[col].isnull().sum()),
                })
            stats_df = pd.DataFrame(stats_data)

            # Box plot
            box_fig = go.Figure()
            for col in sample_cols:
                box_fig.add_trace(go.Box(y=df[col].dropna(), name=col[:20]))
            box_fig.update_layout(
                template="plotly_dark", margin=dict(l=20, r=20, t=40, b=60),
                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                title="Feature Value Distributions (Pre-Scaling)",
                showlegend=False,
            )
        else:
            stats_df = pd.DataFrame()
            box_fig = go.Figure()

        children = [
            dmc.SimpleGrid(cols={"base": 2, "md": 4}, spacing="sm", children=matrix_cards),
        ]

        if not stats_df.empty:
            children.append(
                dmc.Paper([
                    dmc.Text("Feature Statistics (Sample)", fw=600, mb="sm"),
                    dag.AgGrid(
                        rowData=stats_df.to_dict("records"),
                        columnDefs=[{"field": c, "sortable": True} for c in stats_df.columns],
                        defaultColDef={"flex": 1},
                        dashGridOptions={"domLayout": "autoHeight"},
                        className="ag-theme-alpine-dark",
                        style={"width": "100%"},
                    ),
                ], p="md", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD})
            )
            children.append(
                dmc.Paper([
                    dcc.Graph(figure=box_fig, config=APP.PLOTLY_CONFIG, style={"height": "350px"}),
                ], p="md", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD})
            )

        return dmc.Stack(children, gap="lg")
    except Exception as e:
        return dmc.Alert(f"Error: {e}", color="red")


# =============================================================================
# L5: DETECTION
# =============================================================================
@callback(Output("layer-l5-content", "children"), Input("layer-refresh", "n_intervals"), Input("store-pipeline-complete", "data"))
def update_l5(n, pipeline_complete):
    try:
        from utils.data_io import data_vault
        df = data_vault.get_scored_data()
        result = data_vault.load_pipeline_result()

        if df is None:
            return _no_data_alert("Layer 5")

        score_cols = [c for c in df.columns if c.startswith("score_")]
        methods_run = result.get("methods_run", len(score_cols)) if result else len(score_cols)

        # Per-method statistics
        method_stats = []
        for col in score_cols:
            method_name = col.replace("score_", "")
            vals = df[col].dropna()
            # Determine category
            cat = "Other"
            for category, methods in LAYERS.DETECTION_METHODS.items():
                if method_name in methods:
                    cat = category.replace("_", " ").title()
                    break
            method_stats.append({
                "Method": method_name,
                "Category": cat,
                "Mean Score": f"{vals.mean():.4f}" if len(vals) > 0 else "N/A",
                "Max Score": f"{vals.max():.4f}" if len(vals) > 0 else "N/A",
                "Anomalies (>0.5)": int((vals > 0.5).sum()) if len(vals) > 0 else 0,
                "Detection Rate": f"{(vals > 0.5).mean():.1%}" if len(vals) > 0 else "0%",
            })
        method_df = pd.DataFrame(method_stats)

        # Methods by category chart
        if not method_df.empty:
            cat_counts = method_df["Category"].value_counts()
            cat_fig = px.bar(
                x=cat_counts.index, y=cat_counts.values,
                template="plotly_dark", color=cat_counts.index,
                color_discrete_sequence=px.colors.qualitative.Set2,
                labels={"x": "Category", "y": "Methods"},
            )
            cat_fig.update_layout(
                margin=dict(l=20, r=20, t=20, b=60),
                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                showlegend=False, xaxis_tickangle=-30,
            )

            # Score distribution across methods (heatmap)
            heat_data = []
            for col in score_cols[:20]:
                vals = df[col].dropna()
                heat_data.append(vals.values[:min(100, len(vals))])

            if heat_data:
                max_len = max(len(h) for h in heat_data)
                padded = [np.pad(h, (0, max_len - len(h)), constant_values=np.nan) for h in heat_data]
                z = np.array(padded)

                heat_fig = go.Figure(data=go.Heatmap(
                    z=z, y=[c.replace("score_", "") for c in score_cols[:20]],
                    colorscale=[[0, THEME.SUCCESS], [0.5, THEME.WARNING], [1, THEME.DANGER]],
                ))
                heat_fig.update_layout(
                    template="plotly_dark",
                    margin=dict(l=100, r=20, t=40, b=20),
                    paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                    title="Score Heatmap (Methods × Records)",
                    xaxis_title="Record Index",
                )
            else:
                heat_fig = go.Figure()
        else:
            cat_fig = go.Figure()
            heat_fig = go.Figure()

        return dmc.Stack([
            dmc.SimpleGrid(cols={"base": 2, "md": 3}, spacing="sm", children=[
                _kpi("Methods Run", methods_run, "mdi:radar", THEME.PRIMARY),
                _kpi("Score Columns", len(score_cols), "mdi:function", THEME.SECONDARY),
                _kpi("Categories", str(len(LAYERS.DETECTION_METHODS)), "mdi:shape", "#FFC107"),
            ]),

            dmc.SimpleGrid(cols={"base": 1, "md": 2}, spacing="lg", children=[
                dmc.Paper([
                    dmc.Text("Methods by Category", fw=600, mb="sm"),
                    dcc.Graph(figure=cat_fig, config=APP.PLOTLY_CONFIG, style={"height": "300px"}),
                ], p="md", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}),
                dmc.Paper([
                    dcc.Graph(figure=heat_fig, config=APP.PLOTLY_CONFIG, style={"height": "300px"}),
                ], p="md", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}),
            ]),

            dmc.Paper([
                dmc.Text("Per-Method Detection Summary", fw=600, mb="sm"),
                dag.AgGrid(
                    rowData=method_df.to_dict("records") if not method_df.empty else [],
                    columnDefs=[{"field": c, "sortable": True, "filter": True} for c in method_df.columns],
                    defaultColDef={"flex": 1, "minWidth": 100},
                    dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
                    className="ag-theme-alpine-dark",
                    style={"width": "100%"},
                ),
            ], p="md", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}),
        ], gap="lg")
    except Exception as e:
        return dmc.Alert(f"Error: {e}", color="red")


# =============================================================================
# L6: ENSEMBLE
# =============================================================================
@callback(Output("layer-l6-content", "children"), Input("layer-refresh", "n_intervals"), Input("store-pipeline-complete", "data"))
def update_l6(n, pipeline_complete):
    try:
        from utils.data_io import data_vault
        df = data_vault.get_scored_data()
        result = data_vault.load_pipeline_result()

        if df is None or "anomaly_score" not in df.columns:
            return _no_data_alert("Layer 6")

        scores = df["anomaly_score"]
        tier_dist = result.get("tier_distribution", {}) if result else {}

        # Final score distribution
        score_fig = px.histogram(
            scores, nbins=50, template="plotly_dark",
            labels={"value": "Anomaly Score", "count": "Frequency"},
            color_discrete_sequence=[THEME.PRIMARY],
        )
        score_fig.update_layout(
            margin=dict(l=20, r=20, t=40, b=20),
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            title="Final Ensemble Score Distribution",
        )

        # Risk tier pie
        if tier_dist:
            tier_fig = px.pie(
                values=list(tier_dist.values()), names=list(tier_dist.keys()),
                color=list(tier_dist.keys()),
                color_discrete_map={"Critical": THEME.DANGER, "High": "#FF9800", "Medium": THEME.WARNING, "Low": THEME.SUCCESS},
                hole=0.4, template="plotly_dark",
            )
            tier_fig.update_layout(
                margin=dict(l=20, r=20, t=40, b=20),
                paper_bgcolor="rgba(0,0,0,0)",
                title="Risk Tier Distribution",
            )
        else:
            tier_fig = go.Figure()

        # Sankey: categories -> ensemble -> tiers
        score_cols = [c for c in df.columns if c.startswith("score_")]
        cats = list(LAYERS.DETECTION_METHODS.keys())
        cat_labels = [c.replace("_", " ").title() for c in cats]
        tiers = ["Critical", "High", "Medium", "Low"]

        all_labels = cat_labels + ["Ensemble"] + tiers
        sources_idx, targets_idx, values_list = [], [], []

        for i, cat in enumerate(cats):
            methods = LAYERS.DETECTION_METHODS[cat]
            count = sum(1 for m in methods if f"score_{m}" in score_cols)
            if count > 0:
                sources_idx.append(i)
                targets_idx.append(len(cat_labels))
                values_list.append(count)

        for j, tier in enumerate(tiers):
            count = tier_dist.get(tier, 0)
            if count > 0:
                sources_idx.append(len(cat_labels))
                targets_idx.append(len(cat_labels) + 1 + j)
                values_list.append(count)

        sankey_fig = go.Figure(go.Sankey(
            node=dict(label=all_labels, color=[THEME.PRIMARY] * len(cat_labels) + [THEME.SECONDARY] + [THEME.DANGER, "#FF9800", THEME.WARNING, THEME.SUCCESS]),
            link=dict(source=sources_idx, target=targets_idx, value=values_list, color="rgba(150,150,150,0.3)"),
        ))
        sankey_fig.update_layout(
            template="plotly_dark",
            margin=dict(l=20, r=20, t=40, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            title="Detection Flow: Categories → Ensemble → Risk Tiers",
        )

        return dmc.Stack([
            dmc.SimpleGrid(cols={"base": 2, "md": 4}, spacing="sm", children=[
                _kpi("Avg Score", f"{scores.mean():.3f}", "mdi:chart-bell-curve", THEME.PRIMARY),
                _kpi("Median", f"{scores.median():.3f}", "mdi:minus-thick", THEME.SECONDARY),
                _kpi("Std Dev", f"{scores.std():.3f}", "mdi:sigma", "#FFC107"),
                _kpi("Anomaly Rate", f"{(scores > 0.5).mean():.1%}", "mdi:alert-circle", THEME.DANGER),
            ]),

            dmc.SimpleGrid(cols={"base": 1, "md": 2}, spacing="lg", children=[
                dmc.Paper([
                    dcc.Graph(figure=score_fig, config=APP.PLOTLY_CONFIG, style={"height": "300px"}),
                ], p="md", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}),
                dmc.Paper([
                    dcc.Graph(figure=tier_fig, config=APP.PLOTLY_CONFIG, style={"height": "300px"}),
                ], p="md", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}),
            ]),

            dmc.Paper([
                dcc.Graph(figure=sankey_fig, config=APP.PLOTLY_CONFIG, style={"height": "400px"}),
            ], p="md", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}),
        ], gap="lg")
    except Exception as e:
        return dmc.Alert(f"Error: {e}", color="red")


# =============================================================================
# L7: OUTPUT
# =============================================================================
@callback(Output("layer-l7-content", "children"), Input("layer-refresh", "n_intervals"), Input("store-pipeline-complete", "data"))
def update_l7(n, pipeline_complete):
    try:
        from utils.data_io import data_vault
        df = data_vault.get_scored_data()
        result = data_vault.load_pipeline_result()

        if df is None:
            return _no_data_alert("Layer 7")

        alerts_gen = result.get("alerts_generated", 0) if result else 0
        tier_dist = result.get("tier_distribution", {}) if result else {}
        exec_time = result.get("execution_time_ms", 0) if result else 0

        # Top 20 highest risk records
        if "anomaly_score" in df.columns and "risk_tier" in df.columns:
            top_risk = df.nlargest(20, "anomaly_score")
            display_cols = ["anomaly_score", "risk_tier"]
            # Add customer_name or customer_id if present
            for id_col in ["customer_name", "customer_id", "party_id", "cust_id"]:
                if id_col in df.columns:
                    display_cols.insert(0, id_col)
                    break
            # Add a few score columns
            score_cols = [c for c in df.columns if c.startswith("score_")][:3]
            display_cols.extend(score_cols)

            preview = top_risk[display_cols].copy()
            for col in preview.columns:
                if col in {"customer_id", "party_id", "cust_id"}:
                    preview[col] = preview[col].apply(lambda x: mask_id(x))
                if preview[col].dtype == float:
                    preview[col] = preview[col].round(4)
        else:
            preview = pd.DataFrame()

        # Output components summary
        output_cards = [
            dmc.Paper(
                dmc.Stack([
                    DashIconify(icon="mdi:clipboard-list", width=40),
                    dmc.Text("Investigation Queue", fw=600),
                    dmc.Text(f"{alerts_gen} alerts generated", size="sm", c="dimmed"),
                    dmc.Group([
                        dmc.Badge(f"Critical: {tier_dist.get('Critical', 0)}", color="red", size="sm"),
                        dmc.Badge(f"High: {tier_dist.get('High', 0)}", color="orange", size="sm"),
                    ], gap="xs"),
                ], gap=4, ta="center"),
                p="lg", style={"backgroundColor": "rgba(255,50,50,0.1)"},
            ),
            dmc.Paper(
                dmc.Stack([
                    DashIconify(icon="mdi:file-document", width=40),
                    dmc.Text("Narrative System", fw=600),
                    dmc.Text("Auto-generated explanations", size="sm", c="dimmed"),
                    dmc.Badge("SHAP-style", color="grape", variant="light", size="sm"),
                ], gap=4, ta="center"),
                p="lg", style={"backgroundColor": "rgba(0,200,255,0.1)"},
            ),
            dmc.Paper(
                dmc.Stack([
                    DashIconify(icon="mdi:history", width=40),
                    dmc.Text("Audit Trail", fw=600),
                    dmc.Text("All decisions logged", size="sm", c="dimmed"),
                    dmc.Badge(f"{exec_time:.0f}ms runtime", color="gray", variant="light", size="sm"),
                ], gap=4, ta="center"),
                p="lg", style={"backgroundColor": "rgba(0,255,150,0.1)"},
            ),
        ]

        children = [
            dmc.SimpleGrid(cols={"base": 2, "md": 4}, spacing="sm", children=[
                _kpi("Alerts", alerts_gen, "mdi:alert-circle", THEME.DANGER),
                _kpi("Records", f"{len(df):,}", "mdi:database", THEME.PRIMARY),
                _kpi("Exec Time", f"{exec_time:.0f}ms", "mdi:timer", THEME.SECONDARY),
                _kpi("Tiers", len(tier_dist), "mdi:layers-triple", "#FFC107"),
            ]),
            dmc.SimpleGrid(cols=3, spacing="sm", children=output_cards),
        ]

        if not preview.empty:
            children.append(
                dmc.Paper([
                    dmc.Text("Top 20 Highest Risk Records", fw=600, mb="sm"),
                    dag.AgGrid(
                        rowData=preview.to_dict("records"),
                        columnDefs=[{"field": c, "sortable": True, "filter": True} for c in preview.columns],
                        defaultColDef={"flex": 1, "minWidth": 100},
                        dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
                        className="ag-theme-alpine-dark",
                        style={"width": "100%"},
                    ),
                ], p="md", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD})
            )

        return dmc.Stack(children, gap="lg")
    except Exception as e:
        return dmc.Alert(f"Error: {e}", color="red")


def mask_id(val):
    s = str(val)
    return f"****{s[-4:]}" if len(s) > 4 else s
