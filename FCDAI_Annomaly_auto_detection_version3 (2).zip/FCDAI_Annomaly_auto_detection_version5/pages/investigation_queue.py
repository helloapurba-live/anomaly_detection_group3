"""
Investigation Queue Page
========================
Alert triage and investigation workflow.
Reads alerts from scored data in the vault.
"""

import dash
from dash import html, dcc, callback, Input, Output, State
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import dash_ag_grid as dag
import pandas as pd
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS

dash.register_page(__name__, path="/queue", name="Investigation Queue", order=4)

TIER_COLORS = {"Critical": "red", "High": "orange", "Medium": "yellow", "Low": "green"}


def alert_card(row, idx):
    tier = row.get("risk_tier", "Low")
    score = row.get("anomaly_score", 0)
    # Prefer customer_name for reports, fall back to IDs
    cust_name = row.get("customer_name", None)
    cust_label = cust_name if cust_name else str(row.get("customer_id", row.get("party_id", f"REC-{idx}")))[-8:]

    # Auto-generate narrative focused on customer name
    if score > 0.8:
        narrative = f"CRITICAL: {cust_label} shows extreme deviation across multiple detection methods."
    elif score > 0.6:
        narrative = f"HIGH RISK: {cust_label} flagged by ensemble fusion with elevated anomaly indicators."
    elif score > 0.4:
        narrative = f"MEDIUM: {cust_label} has moderate anomaly signals from statistical methods."
    else:
        narrative = f"LOW: {cust_label} shows minor deviations, likely benign."

    return dmc.Paper(
        [
            dmc.Group([
                dmc.Badge(tier, color=TIER_COLORS.get(tier, "gray")),
                dmc.Text(f"ALT-{idx:06d}", fw=600),
                dmc.Text(f"{score:.0%}", c="dimmed"),
            ], justify="space-between"),
            dmc.Space(h="sm"),
            dmc.Text(narrative, size="sm", c="dimmed"),
            dmc.Space(h="sm"),
            dmc.Group([
                dmc.Button("Review", size="xs", variant="subtle", color="cyan"),
                dmc.Button("Escalate", size="xs", variant="subtle", color="orange"),
                dmc.Button("Close", size="xs", variant="subtle", color="gray"),
            ], gap="xs"),
        ],
        p="md", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD, "marginBottom": "8px"},
    )


layout = dmc.Container(
    [
        dmc.Group([
            dmc.Title("Investigation Queue", order=2),
            dmc.Badge("Layer 7 Output", color="cyan", variant="light"),
        ], justify="space-between", mb="lg"),

        # Filters
        dmc.Paper(
            dmc.Group([
                dmc.Select(
                    id="filter-tier", label="Risk Tier",
                    data=[
                        {"value": "all", "label": "All Tiers"},
                        {"value": "Critical", "label": "Critical"},
                        {"value": "High", "label": "High"},
                        {"value": "Medium", "label": "Medium"},
                        {"value": "Low", "label": "Low"},
                    ],
                    value="all", w=150,
                ),
                dmc.Select(
                    id="filter-status", label="Status",
                    data=[
                        {"value": "all", "label": "All"},
                        {"value": "Open", "label": "Open"},
                    ],
                    value="all", w=150,
                ),
                dmc.Button(
                    "Refresh", id="btn-refresh-queue",
                    leftSection=DashIconify(icon="mdi:refresh"),
                    variant="subtle", ml="auto",
                ),
            ], gap="md"),
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}, mb="lg",
        ),

        # Stats
        dmc.SimpleGrid(
            cols=4, spacing="md", mb="lg",
            children=[
                dmc.Paper([
                    dmc.Text("Total Alerts", c="dimmed", size="sm"),
                    dmc.Text("0", fw=700, size="xl", id="stat-total"),
                ], p="md", ta="center", radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),
                dmc.Paper([
                    dmc.Text("Critical", c="dimmed", size="sm"),
                    dmc.Text("0", fw=700, size="xl", c="red", id="stat-critical"),
                ], p="md", ta="center", radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),
                dmc.Paper([
                    dmc.Text("High", c="dimmed", size="sm"),
                    dmc.Text("0", fw=700, size="xl", c="orange", id="stat-high"),
                ], p="md", ta="center", radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),
                dmc.Paper([
                    dmc.Text("Pending Review", c="dimmed", size="sm"),
                    dmc.Text("0", fw=700, size="xl", c="cyan", id="stat-pending"),
                ], p="md", ta="center", radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),
            ],
        ),

        # Alert list
        html.Div(id="alert-list"),

        dcc.Interval(id="queue-refresh", interval=30000, n_intervals=0),
    ],
    fluid=True,
)


@callback(
    [Output("alert-list", "children"),
     Output("stat-total", "children"),
     Output("stat-critical", "children"),
     Output("stat-high", "children"),
     Output("stat-pending", "children")],
    [Input("btn-refresh-queue", "n_clicks"),
     Input("filter-tier", "value"),
     Input("filter-status", "value"),
     Input("queue-refresh", "n_intervals"),
     Input("store-pipeline-complete", "data")],
)
def update_queue(n_clicks, tier_filter, status_filter, n_intervals, pipeline_complete):
    try:
        from utils.data_io import data_vault
        df = data_vault.get_scored_data()

        if df is None or "anomaly_score" not in df.columns or "risk_tier" not in df.columns:
            return (
                [dmc.Alert("No pipeline results. Run the pipeline first.", color="gray",
                           icon=DashIconify(icon="mdi:information"))],
                "0", "0", "0", "0",
            )

        # Filter to anomaly records only (score > threshold)
        alerts_df = df[df["anomaly_score"] > 0.3].sort_values("anomaly_score", ascending=False)

        if tier_filter != "all":
            alerts_df = alerts_df[alerts_df["risk_tier"] == tier_filter]

        # Limit to top 50 for display
        display_df = alerts_df.head(50)

        cards = []
        for i, (_, row) in enumerate(display_df.iterrows()):
            cards.append(alert_card(row.to_dict(), i + 1))

        if not cards:
            cards = [dmc.Text("No alerts match the current filters.", c="dimmed", ta="center")]

        # Stats from full alerts
        total = len(alerts_df)
        critical = int((alerts_df["risk_tier"] == "Critical").sum())
        high = int((alerts_df["risk_tier"] == "High").sum())

        return cards, str(total), str(critical), str(high), str(total)

    except Exception as e:
        return [dmc.Alert(f"Error: {e}", color="red")], "0", "0", "0", "0"
