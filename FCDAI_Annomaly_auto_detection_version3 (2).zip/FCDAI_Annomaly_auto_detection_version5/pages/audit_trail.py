"""
Audit Trail Page — Live Compliance Logging
============================================
Decision logging and compliance tracking.
Reads actual audit entries from vault pipeline results and logger.
Auto-refreshes with dcc.Interval.
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
from dash_iconify import DashIconify
from datetime import datetime, timedelta
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS


dash.register_page(__name__, path="/audit", name="Audit Trail", order=6)


def audit_entry(timestamp: str, action: str, user: str, details: str) -> dmc.Paper:
    action_icons = {
        "PIPELINE_RUN": ("mdi:rocket-launch", "cyan"),
        "PIPELINE_COMPLETED": ("mdi:check-circle", "green"),
        "PIPELINE_FAILED": ("mdi:alert-circle", "red"),
        "ALERT_GENERATED": ("mdi:alert", "orange"),
        "DATA_IMPORT": ("mdi:database-import", "grape"),
        "DATA_GENERATED": ("mdi:database-plus", "blue"),
        "ALERT_REVIEWED": ("mdi:eye", "green"),
        "ALERT_ESCALATED": ("mdi:arrow-up-bold", "orange"),
        "ALERT_CLOSED": ("mdi:check-circle", "gray"),
        "SCORED_DATA_SAVED": ("mdi:content-save", "teal"),
    }

    icon, color = action_icons.get(action, ("mdi:information", "gray"))

    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.ThemeIcon(
                        DashIconify(icon=icon, width=20),
                        color=color, variant="light", radius="xl",
                    ),
                    dmc.Stack(
                        [
                            dmc.Group(
                                [
                                    dmc.Text(action.replace("_", " ").title(), fw=600, size="sm"),
                                    dmc.Badge(user, size="xs", variant="light"),
                                ],
                                gap="xs",
                            ),
                            dmc.Text(details, size="xs", c="dimmed"),
                        ],
                        gap=0,
                    ),
                    dmc.Text(timestamp, size="xs", c="dimmed", ml="auto"),
                ],
                gap="sm",
            ),
        ],
        p="sm", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD, "marginBottom": "8px"},
    )


layout = dmc.Container(
    [
        dmc.Group(
            [
                dmc.Title("Audit Trail", order=2),
                dmc.Badge("Compliance Logging", color="cyan", variant="light"),
            ],
            justify="space-between",
            mb="lg",
        ),

        # Filters
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Select(
                            id="filter-action-type",
                            label="Action Type",
                            data=[
                                {"value": "all", "label": "All Actions"},
                                {"value": "PIPELINE_RUN", "label": "Pipeline Runs"},
                                {"value": "PIPELINE_COMPLETED", "label": "Completions"},
                                {"value": "ALERT_GENERATED", "label": "Alerts Generated"},
                                {"value": "DATA_IMPORT", "label": "Data Imports"},
                                {"value": "DATA_GENERATED", "label": "Data Generated"},
                            ],
                            value="all", w=200,
                        ),
                        dmc.Button(
                            "Refresh", id="btn-refresh-audit",
                            leftSection=DashIconify(icon="mdi:refresh"),
                            variant="subtle", ml="auto",
                        ),
                    ],
                    gap="md",
                ),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}, mb="lg",
        ),

        # Stats
        html.Div(id="audit-stats"),
        dmc.Space(h="md"),

        # Entries
        html.Div(id="audit-entries"),

        dcc.Interval(id="audit-refresh", interval=30000, n_intervals=0),
    ],
    fluid=True,
)


def _build_entries_from_vault():
    """Build audit trail entries from vault data — pipeline results, logs, metadata."""
    from utils.data_io import data_vault

    entries = []
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # 1. Pipeline result entry
    result = data_vault.load_pipeline_result()
    if result:
        ts = str(result.get("timestamp", ""))[:19] if result.get("timestamp") else now_str
        exec_time = result.get("execution_time_ms", 0)
        records = result.get("records_processed", 0)
        methods = result.get("methods_run", 0)
        alerts = result.get("alerts_generated", 0)
        data_source = result.get("data_source", "unknown")
        tier_dist = result.get("tier_distribution", {})

        entries.append({
            "ts": ts, "action": "PIPELINE_RUN", "user": "system",
            "details": f"Pipeline executed on {'sample' if data_source == 'sample' else 'actual'} data",
        })
        entries.append({
            "ts": ts, "action": "PIPELINE_COMPLETED", "user": "system",
            "details": f"Processed {records:,} records with {methods} methods in {exec_time:.0f}ms",
        })
        entries.append({
            "ts": ts, "action": "ALERT_GENERATED", "user": "system",
            "details": (f"{alerts} alerts generated — "
                       f"Critical: {tier_dist.get('Critical', 0)}, "
                       f"High: {tier_dist.get('High', 0)}, "
                       f"Medium: {tier_dist.get('Medium', 0)}, "
                       f"Low: {tier_dist.get('Low', 0)}"),
        })

        # Per-method scores summary
        method_scores = result.get("method_scores", [])
        if method_scores:
            anomaly_methods = [m for m in method_scores if m.get("anomalies", 0) > 0]
            entries.append({
                "ts": ts, "action": "SCORED_DATA_SAVED", "user": "system",
                "details": f"{len(method_scores)} methods scored, {len(anomaly_methods)} detected anomalies",
            })

    # 2. Data source entries
    sources = data_vault.load_sources()
    meta = data_vault.get_metadata()
    if sources:
        import_time = meta.get("import_time", now_str)[:19] if meta.get("import_time") else now_str
        total_rows = sum(len(df) for df in sources.values())
        table_names = ", ".join(sources.keys())
        entries.append({
            "ts": import_time, "action": "DATA_GENERATED" if "generated" in meta.get("filename", "") or "sample" in meta.get("filename", "") else "DATA_IMPORT",
            "user": "system",
            "details": f"{len(sources)} tables ({table_names}), {total_rows:,} total rows",
        })

    # 3. Read from audit log file if it exists
    audit_log_path = PATHS.DATA_VAULT / "audit_log.json"
    if audit_log_path.exists():
        try:
            with open(audit_log_path, "r") as f:
                log_entries = json.load(f)
            for le in log_entries[-20:]:  # Last 20
                entries.append(le)
        except Exception:
            pass

    # Sort by timestamp descending
    entries.sort(key=lambda x: x.get("ts", ""), reverse=True)
    return entries


@callback(
    [Output("audit-entries", "children"),
     Output("audit-stats", "children")],
    [Input("filter-action-type", "value"),
     Input("btn-refresh-audit", "n_clicks"),
     Input("audit-refresh", "n_intervals")],
)
def update_entries(action_filter, n_clicks, n_intervals):
    try:
        all_entries = _build_entries_from_vault()

        if action_filter and action_filter != "all":
            filtered = [e for e in all_entries if e["action"] == action_filter]
        else:
            filtered = all_entries

        cards = [
            audit_entry(e["ts"], e["action"], e["user"], e["details"])
            for e in filtered
        ]

        if not cards:
            cards = [dmc.Alert("No audit entries found. Run the pipeline to generate audit trail.",
                              color="gray", icon=DashIconify(icon="mdi:information"))]

        # Stats
        total = len(all_entries)
        pipeline_runs = sum(1 for e in all_entries if e["action"] == "PIPELINE_RUN")
        alerts = sum(1 for e in all_entries if e["action"] == "ALERT_GENERATED")
        data_ops = sum(1 for e in all_entries if e["action"] in ("DATA_IMPORT", "DATA_GENERATED"))

        stats = dmc.SimpleGrid(
            cols=4, spacing="md", mb="lg",
            children=[
                dmc.Paper([dmc.Text("Total Entries", c="dimmed", size="sm"),
                           dmc.Text(str(total), fw=700, size="xl")],
                          p="md", ta="center", radius="md",
                          style={"backgroundColor": THEME.DARK_BG_CARD}),
                dmc.Paper([dmc.Text("Pipeline Runs", c="dimmed", size="sm"),
                           dmc.Text(str(pipeline_runs), fw=700, size="xl", c="cyan")],
                          p="md", ta="center", radius="md",
                          style={"backgroundColor": THEME.DARK_BG_CARD}),
                dmc.Paper([dmc.Text("Alerts Generated", c="dimmed", size="sm"),
                           dmc.Text(str(alerts), fw=700, size="xl", c="orange")],
                          p="md", ta="center", radius="md",
                          style={"backgroundColor": THEME.DARK_BG_CARD}),
                dmc.Paper([dmc.Text("Data Operations", c="dimmed", size="sm"),
                           dmc.Text(str(data_ops), fw=700, size="xl", c="grape")],
                          p="md", ta="center", radius="md",
                          style={"backgroundColor": THEME.DARK_BG_CARD}),
            ],
        )

        return cards, stats

    except Exception as e:
        return [dmc.Alert(f"Error: {e}", color="red")], html.Div()
