"""
Data Sources Page
=================
Data entry point — generate sample data OR upload real CSVs/Excel
for each of the 6 source tables (Transactions, Party, Account, Alert,
Case, KYC).  Shows preview grids and source statistics.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, ctx, ALL
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import dash_ag_grid as dag
import pandas as pd
import numpy as np
import io, base64, sys, json
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS, APP

dash.register_page(__name__, path="/sources", name="Data Sources", order=1)


# =============================================================================
# TABLE CONFIG
# =============================================================================
TABLE_CONFIG = {
    "transactions": {"icon": "mdi:swap-horizontal", "color": "cyan",   "label": "Transactions"},
    "party":        {"icon": "mdi:account-group",   "color": "blue",   "label": "Customer / Party"},
    "account":      {"icon": "mdi:bank",            "color": "indigo", "label": "Accounts"},
    "alert":        {"icon": "mdi:alert",           "color": "orange", "label": "Alerts"},
    "case":         {"icon": "mdi:briefcase",       "color": "red",    "label": "Cases"},
    "kyc":          {"icon": "mdi:shield-check",    "color": "green",  "label": "KYC"},
    "others":       {"icon": "mdi:dots-horizontal", "color": "grape",  "label": "Others"},
}

MASK_COLUMNS = {"party_id", "customer_id", "account_id"}


def mask_id(val):
    s = str(val)
    return f"****{s[-4:]}" if len(s) > 4 else s


def build_ag_grid(df, table_name, max_rows=50):
    """Build AG Grid preview."""
    preview = df.head(max_rows).copy()
    for col in preview.columns:
        if col in MASK_COLUMNS:
            preview[col] = preview[col].apply(mask_id)
    cols = [{"field": c, "sortable": True, "filter": True, "resizable": True} for c in preview.columns]
    return dag.AgGrid(
        id={"type": "source-grid", "table": table_name},
        rowData=preview.to_dict("records"),
        columnDefs=cols,
        defaultColDef={"flex": 1, "minWidth": 100},
        dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
        style={"height": None, "width": "100%"},
        className="ag-theme-alpine-dark",
    )


def _upload_card(table_name, conf):
    """One upload zone per table."""
    return dmc.Paper(
        [
            dmc.Group([
                dmc.ThemeIcon(
                    DashIconify(icon=conf["icon"], width=20),
                    color=conf["color"], variant="light", size="lg",
                ),
                dmc.Text(conf["label"], fw=600, size="sm"),
            ], gap="sm", mb="xs"),
            dcc.Upload(
                id={"type": "upload-table", "table": table_name},
                children=dmc.Group([
                    DashIconify(icon="mdi:cloud-upload", width=24, color="#999"),
                    dmc.Text("Drop CSV / Excel here", size="xs", c="dimmed"),
                ], gap="xs", justify="center"),
                style={
                    "border": f"1px dashed {THEME.DARK_BORDER}",
                    "borderRadius": "8px",
                    "padding": "12px",
                    "textAlign": "center",
                    "cursor": "pointer",
                },
                multiple=False,
            ),
            html.Div(id={"type": "upload-status", "table": table_name}),
        ],
        p="sm", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD},
    )


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Container(
    [
        # Header
        dmc.Group(
            [
                dmc.Title("Data Sources", order=2),
                dmc.Badge("7 Tables • Customer-Level", color="cyan", variant="light"),
            ],
            justify="space-between",
            mb="lg",
        ),

        # ── SECTION 1: GENERATE SAMPLE DATA ──────────────────
        dmc.Paper(
            [
                dmc.Text("Quick Start — Generate Sample Data", fw=600, mb="sm"),
                dmc.Text(
                    "Generate realistic sample data for all 6 tables to test the pipeline.",
                    size="sm", c="dimmed", mb="md",
                ),
                dmc.Group(
                    [
                        dmc.NumberInput(
                            id="ds-customer-count",
                            label="Customer Count",
                            description="Range: 10 – 100,000",
                            value=100, min=10, max=100000, step=10,
                            style={"width": 180},
                        ),
                        dmc.Button(
                            "Generate Data",
                            id="ds-btn-generate",
                            leftSection=DashIconify(icon="mdi:database-plus"),
                            color="cyan", size="md", mt=26,
                        ),
                        dmc.Button(
                            "Reset All Data",
                            id="ds-btn-reset",
                            leftSection=DashIconify(icon="mdi:trash-can-outline"),
                            color="red", variant="outline", size="md", mt=26,
                        ),
                    ],
                    align="flex-start", gap="md",
                ),
                dmc.Space(h="sm"),
                html.Div(id="ds-status-output"),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
            mb="lg",
        ),

        # ── SECTION 2: UPLOAD MANUAL DATA ─────────────────────
        dmc.Paper(
            [
                dmc.Text("Upload Actual Data", fw=600, mb="sm"),
                dmc.Text(
                    "Upload CSV or Excel files for individual tables. Each upload replaces the table in the vault.",
                    size="sm", c="dimmed", mb="md",
                ),
                dmc.SimpleGrid(
                    cols={"base": 3, "md": 4, "lg": 7},
                    spacing="xs",
                    children=[_upload_card(name, conf) for name, conf in TABLE_CONFIG.items()],
                ),
                dmc.Space(h="sm"),
                html.Div(id="ds-upload-summary"),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
            mb="lg",
        ),

        # ── SECTION 2.5: EXCLUDE VARIABLES ─────────────────────
        dmc.Paper(
            [
                dmc.Text("Exclude Variables", fw=600, mb="sm"),
                dmc.Text(
                    "Upload a CSV or Excel file with variable names to exclude from the pipeline. "
                    "The file should have a column named 'variable' or a single column with variable names.",
                    size="sm", c="dimmed", mb="md",
                ),
                dcc.Upload(
                    id="ds-upload-exclude",
                    children=dmc.Group([
                        DashIconify(icon="mdi:file-remove", width=24, color="#FF9800"),
                        dmc.Text("Drop CSV / Excel with variable names to exclude", size="xs", c="dimmed"),
                    ], gap="xs", justify="center"),
                    style={
                        "border": f"1px dashed {THEME.DARK_BORDER}",
                        "borderRadius": "8px",
                        "padding": "16px",
                        "textAlign": "center",
                        "cursor": "pointer",
                    },
                    multiple=False,
                ),
                html.Div(id="ds-exclude-status"),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
            mb="lg",
        ),

        # ── SECTION 3: SOURCE STATS ──────────────────────────
        html.Div(id="ds-source-stats"),
        dmc.Space(h="lg"),

        # ── SECTION 4: TABLE PREVIEWS ────────────────────────
        html.Div(id="ds-table-previews"),

        # Store for triggering refresh after upload
        dcc.Store(id="ds-upload-trigger", data=0),
    ],
    fluid=True,
)


# =============================================================================
# CALLBACKS
# =============================================================================

# ── Generate / Reset ─────────────────────────────────────
@callback(
    Output("ds-status-output", "children"),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Input("ds-btn-generate", "n_clicks"),
    Input("ds-btn-reset", "n_clicks"),
    State("ds-customer-count", "value"),
    prevent_initial_call=True,
)
def handle_gen_reset(n_gen, n_reset, num_customers):
    from utils.data_gen import DataGenerator
    from utils.data_io import data_vault

    triggered = ctx.triggered_id
    status_msg = None

    if triggered == "ds-btn-reset":
        data_vault.clear_data()
        for f in PATHS.DATA_SOURCES.glob("*.csv"):
            f.unlink()
        status_msg = dmc.Alert(
            "All data cleared.", color="orange",
            icon=DashIconify(icon="mdi:check"), withCloseButton=True,
        )

    if triggered == "ds-btn-generate":
        try:
            num_customers = num_customers or 100
            dg = DataGenerator()
            schema = dg.generate_full_schema(num_customers)

            data_vault.save_sources(schema)

            PATHS.DATA_SOURCES.mkdir(parents=True, exist_ok=True)
            for name, df in schema.items():
                df.to_csv(PATHS.DATA_SOURCES / f"{name}.csv", index=False)

            # Merged analytical view
            df_tx = schema.get("transactions", pd.DataFrame())
            df_acc = schema.get("account", pd.DataFrame())
            df_party = schema.get("party", pd.DataFrame())
            df_merged = df_tx.copy()
            if not df_acc.empty and "account_id" in df_tx.columns and "account_id" in df_acc.columns:
                df_merged = df_merged.merge(df_acc, on="account_id", how="left", suffixes=("", "_acc"))
            if not df_party.empty and "party_id" in df_merged.columns and "party_id" in df_party.columns:
                df_merged = df_merged.merge(df_party, on="party_id", how="left", suffixes=("", "_party"))
            data_vault.set_current_data(df_merged, label=f"generated_{num_customers}_cust")

            total_rows = sum(len(v) for v in schema.values())
            status_msg = dmc.Alert(
                f"Generated {num_customers} customers → {total_rows:,} total rows across {len(schema)} tables.",
                color="green", icon=DashIconify(icon="mdi:check-circle"), withCloseButton=True,
            )
        except Exception as e:
            status_msg = dmc.Alert(f"Generation error: {e}", color="red", icon=DashIconify(icon="mdi:alert"))

    sources = data_vault.load_sources()
    return status_msg, _build_stats(sources, data_vault), _build_preview_tabs(sources)


# ── Per-table Upload ─────────────────────────────────────
@callback(
    Output({"type": "upload-status", "table": ALL}, "children"),
    Output("ds-source-stats", "children"),
    Output("ds-table-previews", "children"),
    Input({"type": "upload-table", "table": ALL}, "contents"),
    State({"type": "upload-table", "table": ALL}, "filename"),
    prevent_initial_call=False,
)
def handle_uploads(contents_list, filenames_list):
    from utils.data_io import data_vault

    table_names = list(TABLE_CONFIG.keys())
    status_outputs = [None] * len(table_names)

    any_upload = False
    for i, (contents, filename) in enumerate(zip(contents_list, filenames_list)):
        if contents is None:
            continue
        tbl = table_names[i]
        try:
            content_string = contents.split(",")[1]
            decoded = base64.b64decode(content_string)

            if filename.endswith(".csv"):
                df = pd.read_csv(io.StringIO(decoded.decode("utf-8")))
            elif filename.endswith((".xlsx", ".xls")):
                df = pd.read_excel(io.BytesIO(decoded))
            elif filename.endswith(".parquet"):
                df = pd.read_parquet(io.BytesIO(decoded))
            else:
                status_outputs[i] = dmc.Text(f"Unsupported: {filename}", size="xs", c="red")
                continue

            # Save single table into vault
            sources_dir = PATHS.DATA_VAULT / "sources"
            sources_dir.mkdir(parents=True, exist_ok=True)
            df.to_parquet(sources_dir / f"{tbl}.parquet", index=False)
            data_vault._sources[tbl] = df

            status_outputs[i] = dmc.Text(
                f"✓ {len(df):,} rows", size="xs", c="green", mt="xs",
            )
            any_upload = True
        except Exception as e:
            status_outputs[i] = dmc.Text(f"✗ {e}", size="xs", c="red", mt="xs")

    # Rebuild the merged view if any upload happened
    if any_upload:
        _rebuild_merged(data_vault)

    sources = data_vault.load_sources()
    return status_outputs, _build_stats(sources, data_vault), _build_preview_tabs(sources)


def _rebuild_merged(data_vault):
    """Rebuild the analytical merged view from current sources."""
    sources = data_vault.load_sources()
    df_tx = sources.get("transactions", pd.DataFrame())
    df_acc = sources.get("account", pd.DataFrame())
    df_party = sources.get("party", pd.DataFrame())

    if df_tx.empty:
        # Use the largest available table as base
        if sources:
            biggest = max(sources.values(), key=len)
            data_vault.set_current_data(biggest, label="manual_upload")
        return

    df_merged = df_tx.copy()
    if not df_acc.empty and "account_id" in df_tx.columns and "account_id" in df_acc.columns:
        df_merged = df_merged.merge(df_acc, on="account_id", how="left", suffixes=("", "_acc"))
    if not df_party.empty and "party_id" in df_merged.columns and "party_id" in df_party.columns:
        df_merged = df_merged.merge(df_party, on="party_id", how="left", suffixes=("", "_party"))
    data_vault.set_current_data(df_merged, label="manual_upload")


# =============================================================================
# HELPER BUILDERS
# =============================================================================
def _build_stats(sources, data_vault):
    if not sources:
        return dmc.Alert(
            "No data loaded. Generate sample data or upload files above.",
            color="gray", icon=DashIconify(icon="mdi:information"),
        )

    table_count = len(sources)
    total_rows = sum(len(df) for df in sources.values())
    meta = data_vault.get_metadata()
    last_gen = meta.get("import_time", "N/A")

    cards = []
    for name, df in sources.items():
        conf = TABLE_CONFIG.get(name, {"icon": "mdi:table", "color": "gray", "label": name.title()})
        cards.append(
            dmc.Paper(
                dmc.Group([
                    dmc.ThemeIcon(
                        DashIconify(icon=conf["icon"], width=20),
                        color=conf["color"], variant="light", size="lg",
                    ),
                    dmc.Stack([
                        dmc.Text(conf["label"], size="sm", fw=600),
                        dmc.Text(f"{len(df):,} rows • {len(df.columns)} cols", size="xs", c="dimmed"),
                    ], gap=0),
                ], gap="sm"),
                p="sm", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD},
            )
        )

    return dmc.Stack([
        dmc.Group([
            dmc.Badge(f"{table_count} Tables", color="cyan", variant="light", size="lg"),
            dmc.Badge(f"{total_rows:,} Total Rows", color="blue", variant="light", size="lg"),
            dmc.Text(
                f"Last updated: {last_gen[:19] if last_gen != 'N/A' else 'N/A'}",
                size="xs", c="dimmed",
            ),
        ], gap="md"),
        dmc.SimpleGrid(
            cols={"base": 2, "md": 3, "lg": 6}, spacing="sm", children=cards,
        ),
    ], gap="md")


def _build_preview_tabs(sources):
    if not sources:
        return None

    tabs = []
    panels = []
    for name, df in sources.items():
        conf = TABLE_CONFIG.get(name, {"icon": "mdi:table", "color": "gray", "label": name.title()})
        tabs.append(
            dmc.TabsTab(
                conf["label"], value=name,
                leftSection=DashIconify(icon=conf["icon"], width=16),
            )
        )
        panels.append(
            dmc.TabsPanel(
                dmc.Paper([
                    dmc.Group([
                        dmc.Text(f"Preview: first 50 of {len(df):,} rows", size="sm", c="dimmed"),
                        dmc.Badge(f"{len(df.columns)} columns", color="gray", variant="light", size="sm"),
                    ], justify="space-between", mb="sm"),
                    build_ag_grid(df, name),
                ], p="md", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}),
                value=name,
            )
        )

    first = list(sources.keys())[0]
    return dmc.Tabs(
        [dmc.TabsList(tabs)] + panels,
        value=first, color="cyan", variant="pills",
    )


# =============================================================================
# CALLBACK: Handle exclude-variable file upload
# =============================================================================
@callback(
    Output("ds-exclude-status", "children"),
    Input("ds-upload-exclude", "contents"),
    State("ds-upload-exclude", "filename"),
    prevent_initial_call=True,
)
def handle_exclude_upload(contents, filename):
    if contents is None:
        return ""

    try:
        from utils.data_io import data_vault

        content_type, content_string = contents.split(",")
        decoded = base64.b64decode(content_string)

        if filename.endswith((".xlsx", ".xls")):
            df = pd.read_excel(io.BytesIO(decoded))
        elif filename.endswith(".csv"):
            df = pd.read_csv(io.StringIO(decoded.decode("utf-8")))
        else:
            return dmc.Alert("Unsupported file type. Use CSV or Excel.", color="red")

        # Extract variable names from the first column or 'variable' column
        if "variable" in df.columns:
            var_list = df["variable"].dropna().astype(str).tolist()
        else:
            var_list = df.iloc[:, 0].dropna().astype(str).tolist()

        # Save to vault
        exclude_path = PATHS.DATA_VAULT / "exclude_vars.json"
        with open(exclude_path, "w") as f:
            json.dump(var_list, f)

        return dmc.Alert(
            f"✓ {len(var_list)} variables loaded for exclusion from '{filename}'",
            color="green",
            icon=DashIconify(icon="mdi:check-circle"),
        )

    except Exception as e:
        return dmc.Alert(f"Error parsing exclude file: {e}", color="red")
