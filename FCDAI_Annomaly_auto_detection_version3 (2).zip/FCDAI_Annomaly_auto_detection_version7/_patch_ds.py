"""Patch script to enhance data_sources.py layout."""
import os

file_path = os.path.join(os.path.dirname(__file__), "pages", "data_sources.py")

with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

# === PATCH 1: Add TABLE_SLOTS before LAYOUT section ===
TABLE_SLOTS_CODE = '''

# =============================================================================
# TABLE SLOTS - 12 Predefined Table Types
# =============================================================================
TABLE_SLOTS = [
    {"name": "MASTER", "icon": "mdi:database", "color": "cyan", "label": "Master", "mandatory": True, "desc": "cust_id + cust_name (Required)"},
    {"name": "transactions", "icon": "mdi:swap-horizontal", "color": "blue", "label": "Transactions", "mandatory": False, "desc": "Transaction-level data"},
    {"name": "customer_party", "icon": "mdi:account-group", "color": "indigo", "label": "Customer/Party", "mandatory": False, "desc": "Customer demographics"},
    {"name": "accounts", "icon": "mdi:bank", "color": "green", "label": "Accounts", "mandatory": False, "desc": "Account-level data"},
    {"name": "alerts", "icon": "mdi:alert", "color": "orange", "label": "Alerts", "mandatory": False, "desc": "Alert history"},
    {"name": "cases", "icon": "mdi:briefcase", "color": "red", "label": "Cases", "mandatory": False, "desc": "Investigation cases"},
    {"name": "kyc", "icon": "mdi:shield-check", "color": "teal", "label": "KYC", "mandatory": False, "desc": "KYC compliance data"},
    {"name": "watchlist", "icon": "mdi:shield-search", "color": "pink", "label": "Watchlist", "mandatory": False, "desc": "Sanctions/PEP matches"},
    {"name": "relationships", "icon": "mdi:graph-outline", "color": "violet", "label": "Relationships", "mandatory": False, "desc": "Network/graph data"},
    {"name": "temporal", "icon": "mdi:chart-timeline", "color": "grape", "label": "Temporal", "mandatory": False, "desc": "Time series data"},
    {"name": "others1", "icon": "mdi:table-plus", "color": "gray", "label": "Others1", "mandatory": False, "desc": "Custom table slot 1"},
    {"name": "others2", "icon": "mdi:table-plus", "color": "gray", "label": "Others2", "mandatory": False, "desc": "Custom table slot 2"},
]


'''

# Insert TABLE_SLOTS before the LAYOUT comment
layout_marker = "# =============================================================================\n# LAYOUT\n# ============================================================================="
content = content.replace(layout_marker, TABLE_SLOTS_CODE + layout_marker, 1)


# === PATCH 2: Replace the entire layout section ===
# Find the old layout sections (from "# Status messages" through the container close)
old_sections_start = "        # Status messages\n        html.Div(id=\"ds-status-output\", style={\"marginBottom\": \"1rem\"}),"
old_sections_end = "        dcc.Store(id=\"ds-final-data-store\", data=None),  # Stores selected final data for execution engine\n    ],\n    fluid=True,\n)"

# Find positions
start_pos = content.find(old_sections_start)
end_pos = content.find(old_sections_end)
if start_pos == -1 or end_pos == -1:
    print(f"ERROR: Could not find markers. start={start_pos}, end={end_pos}")
    exit(1)

end_pos += len(old_sections_end)

NEW_LAYOUT_SECTIONS = '''        # Status messages
        html.Div(id="ds-status-output", style={"marginBottom": "1rem"}),

        # ══════════════════════════════════════════════════════════════
        # SECTION 2: UPLOAD — MASTER (Mandatory) + Additional (Optional) SIDE BY SIDE
        # ══════════════════════════════════════════════════════════════
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2},
            spacing="md",
            mb="lg",
            children=[
                # LEFT: MASTER Table Upload (Mandatory)
                dmc.Paper([
                    dmc.Group([
                        DashIconify(icon="mdi:database", width=22, color="#22b8cf"),
                        dmc.Text("MASTER Table", fw=600, size="sm"),
                        dmc.Badge("Mandatory", color="red", size="xs", variant="filled"),
                    ], gap="xs", mb="xs"),
                    dmc.Text("Required columns: cust_id + cust_name", size="xs", c="dimmed", mb="sm"),
                    dcc.Upload(
                        id="upload-master-table",
                        children=dmc.Stack([
                            DashIconify(icon="mdi:cloud-upload", width=28, color="#22b8cf"),
                            dmc.Text("Drop MASTER file here", size="xs", fw=500),
                            dmc.Text("CSV / Excel / Parquet", size="10px", c="dimmed"),
                        ], gap=2, align="center"),
                        style={
                            "border": "2px dashed #22b8cf",
                            "borderRadius": "8px",
                            "padding": "16px",
                            "textAlign": "center",
                            "cursor": "pointer",
                            "minHeight": "90px",
                            "backgroundColor": "rgba(34, 184, 207, 0.05)",
                        },
                        multiple=False,
                    ),
                    html.Div(id="master-upload-status", style={"marginTop": "8px"}),
                ], p="sm", radius="md", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD, "height": "100%"}),

                # RIGHT: Additional Tables Upload (Optional)
                dmc.Paper([
                    dmc.Group([
                        DashIconify(icon="mdi:table-multiple", width=22, color="#51cf66"),
                        dmc.Text("Additional Tables", fw=600, size="sm"),
                        dmc.Badge("Optional", color="green", size="xs", variant="light"),
                    ], gap="xs", mb="xs"),
                    dmc.Text("Upload any tables with cust_id to auto-join", size="xs", c="dimmed", mb="sm"),
                    dcc.Upload(
                        id="upload-additional-tables",
                        children=dmc.Stack([
                            DashIconify(icon="mdi:folder-multiple-plus", width=28, color="#51cf66"),
                            dmc.Text("Drop additional files here", size="xs", fw=500),
                            dmc.Text("Multiple files allowed", size="10px", c="dimmed"),
                        ], gap=2, align="center"),
                        style={
                            "border": "2px dashed #51cf66",
                            "borderRadius": "8px",
                            "padding": "16px",
                            "textAlign": "center",
                            "cursor": "pointer",
                            "minHeight": "90px",
                            "backgroundColor": "rgba(81, 207, 102, 0.05)",
                        },
                        multiple=True,
                    ),
                    html.Div(id="additional-upload-status", style={"marginTop": "8px"}),
                ], p="sm", radius="md", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD, "height": "100%"}),
            ],
        ),

        # ══════════════════════════════════════════════════════════════
        # SECTION 3: ALL TABLE SLOTS (12 Types — 4x3 Grid)
        # ══════════════════════════════════════════════════════════════
        dmc.Text("All Table Types", fw=700, size="lg", mb="xs"),
        dmc.Text("12 integrated table slots across the data pipeline", size="xs", c="dimmed", mb="sm"),
        dmc.SimpleGrid(
            cols={"base": 2, "sm": 3, "md": 4, "lg": 6},
            spacing="xs",
            mb="lg",
            children=[
                dmc.Paper([
                    dmc.Stack([
                        dmc.Group([
                            dmc.ThemeIcon(
                                DashIconify(icon=slot["icon"], width=14),
                                color=slot["color"], variant="light", size="sm",
                            ),
                            dmc.Text(slot["label"], fw=600, size="xs"),
                        ], gap=4, wrap="nowrap"),
                        dmc.Group([
                            dmc.Badge(
                                "Required" if slot["mandatory"] else "Optional",
                                color="red" if slot["mandatory"] else "gray",
                                size="xs",
                                variant="filled" if slot["mandatory"] else "light",
                            ),
                        ]),
                        dmc.Text(slot["desc"], size="10px", c="dimmed", lineClamp=1),
                    ], gap=3),
                ], p="xs", radius="sm", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD})
                for slot in TABLE_SLOTS
            ],
        ),

        # ══════════════════════════════════════════════════════════════
        # SECTION 4: Advanced Configuration Tables (All Optional)
        # ══════════════════════════════════════════════════════════════
        dmc.Text("Advanced: Configuration Tables (All Optional)", fw=700, size="lg", mb="sm"),
        dmc.Alert(
            [
                dmc.Text(
                    "Upload config tables to override intelligent defaults. System works perfectly without these.",
                    size="xs",
                ),
            ],
            color="blue",
            variant="light",
            icon=DashIconify(icon="mdi:cog-outline", width=20),
            mb="md",
        ),
        dmc.SimpleGrid(
            cols={"base": 1, "sm": 2, "md": 4},
            spacing="sm",
            mb="lg",
            children=[
                _build_config_upload_card("EXCLUDE_FEATURES", "mdi:minus-circle", "red", "Features to exclude from modeling"),
                _build_config_upload_card("FEATURE_MAP", "mdi:map", "blue", "Rename/transform features"),
                _build_config_upload_card("TABLE_MAP", "mdi:table-multiple", "cyan", "Define table join logic"),
                _build_config_upload_card("METHOD_CONFIG", "mdi:brain", "grape", "Configure detection algorithms"),
            ],
        ),
        html.Div(id="config-upload-status"),

        # ══════════════════════════════════════════════════════════════
        # SECTION 5: LOADED TABLES SUMMARY (with Export/Delete)
        # ══════════════════════════════════════════════════════════════
        dmc.Paper([
            dmc.Group([
                dmc.Text("Loaded Tables Summary", fw=700, size="lg"),
                dmc.Group([
                    dmc.Button(
                        "Export All CSV",
                        id="ds-btn-export-all",
                        leftSection=DashIconify(icon="mdi:download", width=14),
                        color="cyan", size="xs", variant="light",
                    ),
                    dmc.Button(
                        "Delete All Data",
                        id="ds-btn-delete-all",
                        leftSection=DashIconify(icon="mdi:trash-can", width=14),
                        color="red", size="xs", variant="light",
                    ),
                ], gap="xs"),
            ], justify="space-between", mb="sm"),
            dmc.Text("All loaded tables with auto-detected schemas, record counts, and actions.", size="sm", c="dimmed", mb="md"),
            html.Div(id="ds-summary-table"),
        ], p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}, mb="lg"),

        # ── SOURCE STATS ──────────────────────────
        html.Div(id="ds-source-stats"),
        dmc.Space(h="md"),

        # ── TABLE PREVIEWS ────────────────────────
        html.Div(id="ds-table-previews"),

        # Download component for exports
        dcc.Download(id="ds-download-export"),

        # Stores
        dcc.Store(id="ds-upload-trigger", data=0),
        dcc.Store(id="ds-final-data-store", data=None),
    ],
    fluid=True,
)'''

content = content[:start_pos] + NEW_LAYOUT_SECTIONS + content[end_pos:]


# === PATCH 3: Add export/delete callbacks at end of file ===
EXPORT_DELETE_CALLBACKS = '''

# =============================================================================
# CALLBACK: Export All Tables as CSV
# =============================================================================
@callback(
    Output("ds-download-export", "data"),
    Input("ds-btn-export-all", "n_clicks"),
    prevent_initial_call=True,
)
def export_all_tables(n_clicks):
    """Export all loaded tables as a ZIP of CSVs."""
    from utils.data_io import data_vault
    import zipfile

    sources = data_vault.load_sources()
    if not sources:
        return dash.no_update

    zip_path = PATHS.DATA_VAULT / "export_all_tables.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, df in sources.items():
            csv_bytes = df.to_csv(index=False).encode("utf-8")
            zf.writestr(f"{name}.csv", csv_bytes)

    return dcc.send_file(str(zip_path), filename="all_tables_export.zip")


# =============================================================================
# CALLBACK: Delete All Data
# =============================================================================
@callback(
    Output("ds-status-output", "children", allow_duplicate=True),
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input("ds-btn-delete-all", "n_clicks"),
    prevent_initial_call=True,
)
def delete_all_data(n_clicks):
    """Delete all loaded data and reset vault."""
    from utils.data_io import data_vault

    data_vault.clear_data()

    # Clean source files
    sources_dir = PATHS.DATA_VAULT / "sources"
    if sources_dir.exists():
        for f in sources_dir.glob("*.parquet"):
            f.unlink()
    for f in PATHS.DATA_SOURCES.glob("*.csv"):
        f.unlink()

    status = dmc.Alert(
        "All data deleted successfully.",
        color="orange",
        icon=DashIconify(icon="mdi:check"),
        withCloseButton=True,
    )
    execution_info = dmc.Stack([
        dmc.Group([
            DashIconify(icon="mdi:alert-circle", width=16, color="#ffd43b"),
            dmc.Text("No Data Available", size="xs", fw=600, c="yellow"),
        ], gap=4),
        dmc.Text("Generate or upload data to begin", size="xs", c="dimmed", mt=2),
    ], gap=0)

    empty_sources = {}
    return (
        status,
        _build_summary_table(empty_sources, data_vault),
        _build_stats(empty_sources, data_vault),
        _build_preview_tabs(empty_sources),
        execution_info,
        True,
    )
'''

content = content.rstrip() + EXPORT_DELETE_CALLBACKS + "\n"


# === Write the patched file ===
with open(file_path, "w", encoding="utf-8") as f:
    f.write(content)

print(f"SUCCESS: Patched data_sources.py ({len(content)} chars)")
