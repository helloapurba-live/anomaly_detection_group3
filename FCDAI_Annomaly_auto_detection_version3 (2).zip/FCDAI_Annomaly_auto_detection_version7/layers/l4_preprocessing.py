"""
Layer 4: Preprocessing
======================
Prepare data for detection algorithms with multiple matrix versions.

STEP 8 from pipeline: Create method-specific data structures.
Matrix Versions: X_RAW, X_STANDARD, X_MINMAX, TIME_SERIES, GRAPH_NETWORK
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from pathlib import Path
from sklearn.preprocessing import StandardScaler, MinMaxScaler, LabelEncoder
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import LAYERS


class Layer4Preprocessing:
    """
    Layer 4: Data preprocessing and matrix generation.
    
    Creates method-specific matrix versions per STEP 8:
    - X_RAW: Original numeric features (for tree methods)
    - X_STANDARD: StandardScaler normalized (for distance/density/clustering)
    - X_MINMAX: MinMaxScaler 0-1 range (for deep learning)
    - TIME_SERIES: Customer × time periods (for STL, ARIMA, Prophet)
    - GRAPH_NETWORK: NetworkX graph (for PageRank, HITS, Community)
    - pca: PCA-reduced dimensionality (legacy)
    - encoded: Categorical handling + scaling (legacy)
    """
    
    def __init__(self):
        self.matrices: Dict[str, Any] = {}  # Changed to Any to support graph objects
        self.scalers: Dict[str, StandardScaler] = {}
        self.pca_model: Optional[PCA] = None
        self.label_encoders: Dict[str, LabelEncoder] = {}
        self.feature_names: List[str] = []
        self.id_columns: List[str] = []
        self.customer_ids: Optional[np.ndarray] = None
    
    def preprocess(
        self,
        df: pd.DataFrame,
        id_columns: List[str] = None,
        pca_components: int = 10,
        create_time_series: bool = False,
        create_graph: bool = False
    ) -> Dict[str, Any]:
        """
        Generate all matrix versions per STEP 8.
        
        Args:
            df: Input DataFrame with features
            id_columns: Columns to exclude from processing
            pca_components: Number of PCA components
            create_time_series: Whether to create TIME_SERIES matrix
            create_graph: Whether to create GRAPH_NETWORK
            
        Returns:
            Dict of matrix_name -> numpy array or graph object
        """
        self.id_columns = id_columns or []
        
        # Separate features from IDs
        feature_cols = [c for c in df.columns if c not in self.id_columns]
        df_features = df[feature_cols].copy()
        
        # Store customer IDs if available
        if 'cust_id' in df.columns:
            self.customer_ids = df['cust_id'].values
        
        # Separate numeric and categorical
        numeric_cols = df_features.select_dtypes(include=[np.number]).columns.tolist()
        cat_cols = df_features.select_dtypes(include=['object', 'category']).columns.tolist()
        
        self.feature_names = numeric_cols
        
        # STEP 8.1: X_RAW - Always created
        X_raw = self._create_raw_matrix(df_features[numeric_cols])
        self.matrices['X_RAW'] = X_raw
        self.matrices['raw'] = X_raw  # Legacy alias
        
        # STEP 8.2: X_STANDARD - Always created
        X_standard = self._create_standard_scaled_matrix(X_raw)
        self.matrices['X_STANDARD'] = X_standard
        self.matrices['scaled'] = X_standard  # Legacy alias
        
        # STEP 8.3: X_MINMAX - Created if features >= 10 (DL minimum)
        if len(numeric_cols) >= 10:
            X_minmax = self._create_minmax_scaled_matrix(X_raw)
            self.matrices['X_MINMAX'] = X_minmax
        
        # Legacy: PCA Matrix
        n_components = min(pca_components, X_standard.shape[1], X_standard.shape[0])
        X_pca = self._create_pca_matrix(X_standard, n_components)
        self.matrices['pca'] = X_pca
        
        # Legacy: Encoded Matrix (includes categoricals)
        X_encoded = self._create_encoded_matrix(df_features, numeric_cols, cat_cols)
        self.matrices['encoded'] = X_encoded
        
        # STEP 8.4: TIME_SERIES - Created only if temporal data available
        if create_time_series:
            time_series = self._create_time_series_matrix(df)
            if time_series is not None:
                self.matrices['TIME_SERIES'] = time_series
        
        # STEP 8.5: GRAPH_NETWORK - Created only if relationship data available
        if create_graph:
            graph_network = self._create_graph_network(df)
            if graph_network is not None:
                self.matrices['GRAPH_NETWORK'] = graph_network
        
        return self.matrices
    
    def _create_raw_matrix(self, df_numeric: pd.DataFrame) -> np.ndarray:
        """Create raw numeric matrix with imputation."""
        imputer = SimpleImputer(strategy='median')
        X = imputer.fit_transform(df_numeric)
        
        # Replace infinities
        X = np.nan_to_num(X, nan=0, posinf=0, neginf=0)
        
        return X
    
    def _create_standard_scaled_matrix(self, X: np.ndarray) -> np.ndarray:
        """Create StandardScaler matrix (mean=0, std=1)."""
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        self.scalers['standard'] = scaler
        
        return X_scaled
    
    def _create_minmax_scaled_matrix(self, X: np.ndarray) -> np.ndarray:
        """Create MinMaxScaler matrix (range 0-1)."""
        scaler = MinMaxScaler()
        X_scaled = scaler.fit_transform(X)
        
        self.scalers['minmax'] = scaler
        
        return X_scaled
    
    def _create_pca_matrix(
        self, 
        X: np.ndarray, 
        n_components: int
    ) -> np.ndarray:
        """Create PCA-reduced matrix."""
        if n_components <= 0:
            return X
        
        self.pca_model = PCA(n_components=n_components)
        X_pca = self.pca_model.fit_transform(X)
        
        return X_pca
    
    def _create_encoded_matrix(
        self, 
        df: pd.DataFrame,
        numeric_cols: List[str],
        cat_cols: List[str]
    ) -> np.ndarray:
        """Create matrix with encoded categoricals."""
        parts = []
        
        # Numeric part (scaled)
        if numeric_cols:
            X_num = df[numeric_cols].fillna(0).values
            scaler = MinMaxScaler()
            X_num_scaled = scaler.fit_transform(X_num)
            self.scalers['minmax'] = scaler
            parts.append(X_num_scaled)
        
        # Categorical part (label encoded)
        for col in cat_cols:
            le = LabelEncoder()
            values = df[col].fillna('_missing_').astype(str)
            encoded = le.fit_transform(values).reshape(-1, 1)
            self.label_encoders[col] = le
            parts.append(encoded)
        
        if not parts:
            return np.zeros((len(df), 1))
        
        X_encoded = np.hstack(parts)
        
        return X_encoded
    
    def _create_time_series_matrix(self, df: pd.DataFrame) -> Optional[np.ndarray]:
        """
        Create TIME_SERIES matrix if temporal columns exist.
        Shape: N customers × T time periods
        """
        # Check if temporal columns exist
        temporal_cols = [c for c in df.columns if 'time' in c.lower() or 'date' in c.lower()]
        
        if not temporal_cols or not self.customer_ids is not None:
            return None
        
        # Simplified: Return None for now (requires specific time-series structure)
        # Full implementation would require pivoting transaction data into time series
        return None
    
    def _create_graph_network(self, df: pd.DataFrame) -> Optional[Any]:
        """
        Create GRAPH_NETWORK if relationship columns exist.
        Returns NetworkX graph object.
        """
        # Check if relationship columns exist
        rel_cols = [c for c in df.columns if any(x in c.lower() for x in ['from', 'to', 'source', 'target', 'sender', 'receiver'])]
        
        if not rel_cols:
            return None
        
        try:
            import networkx as nx
            # Simplified: Return None for now (requires specific network structure)
            # Full implementation would build graph from relationship data
            return None
        except ImportError:
            print("[WARN] NetworkX not available for graph creation")
            return None
    
    def get_matrix(self, version: str = 'scaled') -> np.ndarray:
        """Get specific matrix version."""
        if version not in self.matrices:
            raise ValueError(f"Unknown matrix version: {version}. Available: {list(self.matrices.keys())}")
        return self.matrices[version]
    
    def transform(
        self, 
        df: pd.DataFrame, 
        version: str = 'scaled'
    ) -> np.ndarray:
        """Transform new data using fitted preprocessors."""
        # Align with fitted feature names
        if not self.feature_names:
            return np.zeros((len(df), 1))
            
        # Create DataFrame with all expected columns, initialized to 0
        X_df = pd.DataFrame(0, index=df.index, columns=self.feature_names)
        
        # Update with actual values where available
        available_cols = [c for c in self.feature_names if c in df.columns]
        if available_cols:
            X_df[available_cols] = df[available_cols].fillna(0)
            
        X = X_df.values
        
        if version == 'raw':
            return np.nan_to_num(X)
        elif version == 'scaled':
            if 'standard' in self.scalers:
                return self.scalers['standard'].transform(X)
            return X
        elif version == 'pca':
            if 'standard' in self.scalers and self.pca_model:
                X_scaled = self.scalers['standard'].transform(X)
                return self.pca_model.transform(X_scaled)
            return X
        else:
            return X
    
    def get_summary(self) -> Dict:
        """Get preprocessing summary."""
        return {
            "matrix_versions": list(self.matrices.keys()),
            "shapes": {k: v.shape for k, v in self.matrices.items()},
            "n_features": len(self.feature_names),
            "pca_variance_ratio": getattr(self.pca_model, 'explained_variance_ratio_', None)
        }
