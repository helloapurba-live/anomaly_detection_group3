"""
Layer 1 & 2: Data Ingestion and Quality
========================================
Multi-source data ingestion with validation and DQ scoring.

Sources: KYC, Transactions, Alerts, Cases
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, Optional, Tuple, List, Any
from dataclasses import dataclass
from datetime import datetime
import json
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PATHS, LAYERS, DATA_SOURCES


@dataclass
class DataQualityReport:
    """Data quality assessment results."""
    completeness: float
    consistency: float  
    validity: float
    overall_score: float
    issues: List[str]
    timestamp: str


class Layer1Ingestion:
    """
    Layer 1: Multi-source data ingestion.
    
    Handles KYC, Transaction, Alert, and Case data sources.
    Supports auto-discovery and auto-joining of additional tables.
    """
    
    def __init__(self):
        self.sources: Dict[str, pd.DataFrame] = {}
        self.metadata: Dict[str, Dict] = {}
        self.master_df: Optional[pd.DataFrame] = None
        self.join_log: List[str] = []
        self.skip_log: List[str] = []
    
    def ingest_source(
        self, 
        source_name: str, 
        data: pd.DataFrame,
        validate: bool = True
    ) -> Tuple[bool, str]:
        """
        Ingest a single data source.
        
        Args:
            source_name: Name of source (kyc, transactions, alerts, cases)
            data: DataFrame to ingest
            validate: Whether to validate against schema
            
        Returns:
            Tuple of (success, message)
        """
        # Validate source config if it exists, otherwise allow dynamically
        key_column = None
        if source_name in DATA_SOURCES.SOURCES:
            config = DATA_SOURCES.SOURCES[source_name]
            key_column = config["key_column"]
            # Validate key column exists
            if validate and key_column not in data.columns:
                return False, f"Missing key column: {key_column}"
        
        # Store data
        self.sources[source_name] = data
        self.metadata[source_name] = {
            "rows": len(data),
            "columns": len(data.columns),
            "ingested_at": datetime.now().isoformat(),
            "key_column": key_column
        }
        
        return True, f"Ingested {len(data)} rows from {source_name}"
    
    def ingest_from_file(
        self, 
        source_name: str, 
        filepath: Path
    ) -> Tuple[bool, str]:
        """Ingest from file (CSV, Parquet, Excel)."""
        try:
            if filepath.suffix == '.csv':
                df = pd.read_csv(filepath)
            elif filepath.suffix == '.parquet':
                df = pd.read_parquet(filepath)
            elif filepath.suffix in ['.xlsx', '.xls']:
                df = pd.read_excel(filepath)
            else:
                return False, f"Unsupported format: {filepath.suffix}"
            
            return self.ingest_source(source_name, df)
            
        except Exception as e:
            return False, f"Ingestion error: {str(e)}"
    
    def merge_sources(self) -> pd.DataFrame:
        """
        Merge all ingested sources into unified dataset.
        
        Returns:
            Merged DataFrame with source indicators
        """
        if not self.sources:
            raise ValueError("No sources ingested")
        
        merged_parts = []
        
        for name, df in self.sources.items():
            df_copy = df.copy()
            df_copy['_source'] = name
            merged_parts.append(df_copy)
        
        # Concatenate all sources
        merged = pd.concat(merged_parts, ignore_index=True, sort=False)
        
        return merged
    
    def get_summary(self) -> Dict[str, Any]:
        """Get ingestion summary."""
        return {
            "sources_ingested": list(self.sources.keys()),
            "total_rows": sum(len(df) for df in self.sources.values()),
            "metadata": self.metadata,
            "tables_joined": self.join_log,
            "tables_skipped": self.skip_log
        }
    
    def auto_discover_and_join(
        self,
        data_directory: Path,
        master_df: pd.DataFrame,
        master_key: str = "cust_id"
    ) -> pd.DataFrame:
        """
        Auto-discover and join additional tables to MASTER.
        
        STEP 4 from pipeline: Scan directory, detect join keys, auto-join.
        
        Args:
            data_directory: Directory to scan for data files
            master_df: MASTER DataFrame
            master_key: Key column in master (default: cust_id)
            
        Returns:
            Joined DataFrame
        """
        self.master_df = master_df.copy()
        self.join_log = []
        self.skip_log = []
        
        # Scan directory for all data files
        supported_extensions = ['.csv', '.parquet', '.xlsx', '.xls']
        data_files = []
        
        for ext in supported_extensions:
            data_files.extend(data_directory.glob(f'*{ext}'))
        
        # Process each file
        for filepath in data_files:
            # Skip MASTER file
            if 'master' in filepath.stem.lower():
                continue
                
            try:
                # Load first 100 rows to inspect schema
                if filepath.suffix == '.csv':
                    sample_df = pd.read_csv(filepath, nrows=100)
                elif filepath.suffix == '.parquet':
                    sample_df = pd.read_parquet(filepath)
                    sample_df = sample_df.head(100)
                elif filepath.suffix in ['.xlsx', '.xls']:
                    sample_df = pd.read_excel(filepath, nrows=100)
                else:
                    continue
                
                # Detect join key
                join_key = self._detect_join_key(sample_df, master_key)
                
                if join_key:
                    # Load full table
                    if filepath.suffix == '.csv':
                        full_df = pd.read_csv(filepath)
                    elif filepath.suffix == '.parquet':
                        full_df = pd.read_parquet(filepath)
                    elif filepath.suffix in ['.xlsx', '.xls']:
                        full_df = pd.read_excel(filepath)
                    
                    # Perform LEFT JOIN to master
                    n_cols_before = len(self.master_df.columns)
                    self.master_df = self.master_df.merge(
                        full_df,
                        left_on=master_key,
                        right_on=join_key,
                        how='left',
                        suffixes=('', f'_{filepath.stem}')
                    )
                    n_cols_after = len(self.master_df.columns)
                    n_new_cols = n_cols_after - n_cols_before
                    
                    log_msg = f"Auto-joined {filepath.name}: {n_new_cols} columns on {join_key}"
                    self.join_log.append(log_msg)
                    print(f"[INFO] {log_msg}")
                    
                else:
                    log_msg = f"Skipping {filepath.name}: No join key found"
                    self.skip_log.append(log_msg)
                    print(f"[WARN] {log_msg}")
                    
            except Exception as e:
                log_msg = f"Error processing {filepath.name}: {str(e)}"
                self.skip_log.append(log_msg)
                print(f"[ERROR] {log_msg}")
        
        return self.master_df
    
    def _detect_join_key(self, df: pd.DataFrame, master_key: str) -> Optional[str]:
        """
        Detect potential join key in DataFrame.
        
        Checks for:
        - Exact match: "cust_id"
        - Variants: "customer_id", "customerid", "cust", "customer"
        - Patterns: "*_cust_id", "*_customer_id"
        
        Args:
            df: DataFrame to inspect
            master_key: Key column to match against
            
        Returns:
            Detected column name or None
        """
        columns_lower = {col.lower(): col for col in df.columns}
        
        # 1. Exact match
        if master_key.lower() in columns_lower:
            return columns_lower[master_key.lower()]
        
        # 2. Common variants
        variants = [
            'customer_id', 'customerid', 'cust', 'customer',
            'custid', 'cust_identifier', 'party_id', 'partyid'
        ]
        
        for variant in variants:
            if variant in columns_lower:
                return columns_lower[variant]
        
        # 3. Pattern matching (ends with cust_id or customer_id)
        for col_lower, col_orig in columns_lower.items():
            if col_lower.endswith('_cust_id') or col_lower.endswith('_customer_id'):
                return col_orig
            if col_lower.endswith('_custid') or col_lower.endswith('_customerid'):
                return col_orig
        
        # No join key found
        return None


class Layer2DataQuality:
    """
    Layer 2: Data Quality Assessment and Cleansing.
    
    Scores data on completeness, consistency, and validity.
    """
    
    def __init__(self):
        self.thresholds = LAYERS.DQ_THRESHOLDS
    
    def assess_quality(self, df: pd.DataFrame) -> DataQualityReport:
        """
        Perform comprehensive data quality assessment.
        
        Args:
            df: DataFrame to assess
            
        Returns:
            DataQualityReport with scores and issues
        """
        issues = []
        
        # Completeness: % of non-null values
        completeness = 1 - (df.isnull().sum().sum() / df.size)
        if completeness < self.thresholds["completeness"]:
            null_cols = df.columns[df.isnull().sum() > 0].tolist()
            issues.append(f"Low completeness in: {null_cols[:5]}")
        
        # Consistency: Check for duplicate keys and type consistency
        consistency = self._assess_consistency(df, issues)
        
        # Validity: Check for valid ranges and formats
        validity = self._assess_validity(df, issues)
        
        # Overall score (weighted average)
        overall = (completeness * 0.4 + consistency * 0.3 + validity * 0.3)
        
        return DataQualityReport(
            completeness=round(completeness, 4),
            consistency=round(consistency, 4),
            validity=round(validity, 4),
            overall_score=round(overall, 4),
            issues=issues,
            timestamp=datetime.now().isoformat()
        )
    
    def _assess_consistency(
        self, 
        df: pd.DataFrame, 
        issues: List[str]
    ) -> float:
        """Assess data consistency."""
        score = 1.0
        
        # Check for duplicates
        dup_ratio = df.duplicated().sum() / len(df) if len(df) > 0 else 0
        if dup_ratio > 0.01:
            issues.append(f"Duplicate rows: {dup_ratio:.1%}")
            score -= dup_ratio
        
        # Check mixed types in columns
        for col in df.columns:
            n_types = df[col].apply(type).nunique()
            if n_types > 2:  # Allow NaN + one type
                issues.append(f"Mixed types in {col}")
                score -= 0.05
        
        return max(0, score)
    
    def _assess_validity(
        self, 
        df: pd.DataFrame, 
        issues: List[str]
    ) -> float:
        """Assess data validity."""
        score = 1.0
        
        # Check numeric columns for outliers/invalid values
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        
        for col in numeric_cols:
            # Check for negative values in columns that shouldn't have them
            if 'amount' in col.lower() or 'count' in col.lower():
                neg_count = (df[col] < 0).sum()
                if neg_count > 0:
                    issues.append(f"Negative values in {col}: {neg_count}")
                    score -= 0.02
            
            # Check for infinity values
            if np.isinf(df[col].values).any():
                issues.append(f"Infinite values in {col}")
                score -= 0.05
        
        return max(0, score)
    
    def cleanse(
        self, 
        df: pd.DataFrame, 
        strategy: str = "moderate"
    ) -> pd.DataFrame:
        """
        Cleanse data based on DQ issues.
        
        Args:
            df: DataFrame to cleanse
            strategy: "minimal", "moderate", or "aggressive"
            
        Returns:
            Cleansed DataFrame
        """
        df_clean = df.copy()
        
        # Remove duplicates
        df_clean = df_clean.drop_duplicates()
        
        # Handle missing values
        numeric_cols = df_clean.select_dtypes(include=[np.number]).columns
        
        if strategy == "minimal":
            # Only fill with column mean
            df_clean[numeric_cols] = df_clean[numeric_cols].fillna(
                df_clean[numeric_cols].mean()
            )
        elif strategy == "moderate":
            # Fill numeric with median, categorical with mode
            df_clean[numeric_cols] = df_clean[numeric_cols].fillna(
                df_clean[numeric_cols].median()
            )
            cat_cols = df_clean.select_dtypes(include=['object']).columns
            for col in cat_cols:
                mode = df_clean[col].mode()
                if len(mode) > 0:
                    df_clean[col] = df_clean[col].fillna(mode[0])
        else:  # aggressive
            # Drop rows with any nulls
            df_clean = df_clean.dropna()
        
        # Replace infinity with NaN then fill
        df_clean = df_clean.replace([np.inf, -np.inf], np.nan)
        df_clean = df_clean.fillna(df_clean.median(numeric_only=True))
        
        return df_clean


class IngestPipeline:
    """
    Combined Layer 1 + 2 pipeline.
    """
    
    def __init__(self):
        self.ingestion = Layer1Ingestion()
        self.dq = Layer2DataQuality()
        self.report: Optional[DataQualityReport] = None
    
    def run(
        self, 
        sources: Dict[str, pd.DataFrame],
        cleanse: bool = True,
        cleanse_strategy: str = "moderate"
    ) -> Tuple[pd.DataFrame, DataQualityReport]:
        """
        Run full ingestion pipeline.
        
        Args:
            sources: Dict of source_name -> DataFrame
            cleanse: Whether to cleanse data
            cleanse_strategy: Cleansing aggressiveness
            
        Returns:
            Tuple of (processed_df, dq_report)
        """
        # Ingest all sources
        for name, df in sources.items():
            success, msg = self.ingestion.ingest_source(name, df)
            if not success:
                raise ValueError(msg)
        
        # Merge sources
        merged = self.ingestion.merge_sources()
        
        # Assess quality
        self.report = self.dq.assess_quality(merged)
        
        # Cleanse if requested
        if cleanse:
            merged = self.dq.cleanse(merged, cleanse_strategy)
        
        return merged, self.report
