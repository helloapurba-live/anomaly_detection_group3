"""
Auto-Parameter Generator for Detection Methods
===============================================
Generates optimal parameters for 26 detection methods based on data characteristics.

Parameters adapt to:
- Sample count (n_samples)
- Feature count (n_features)
- Data distribution characteristics

STEP 10 ENHANCEMENT: Dynamic parameter tuning
"""

import numpy as np
from typing import Dict, Any, Optional


class AutoParamGenerator:
    """
    Auto-generate optimal parameters for detection methods.
    
    Based on data characteristics:
    - n_samples: Number of data points
    - n_features: Number of features
    - data_stats: Optional distribution statistics
    """
    
    @staticmethod
    def generate_all(n_samples: int, n_features: int, data_stats: Optional[Dict] = None) -> Dict[str, Dict[str, Any]]:
        """
        Generate parameters for all 26 methods.
        
        Args:
            n_samples: Number of samples
            n_features: Number of features
            data_stats: Optional dict with keys:
                - skewness: Array of feature skewness values
                - kurtosis: Array of feature kurtosis values
                - correlation_max: Maximum pairwise correlation
        
        Returns:
            Dict mapping method_name -> parameters dict
        """
        gen = AutoParamGenerator()
        
        return {
            # Statistical (5)
            "zscore": gen.zscore_params(),
            "iqr": gen.iqr_params(),
            "grubbs": gen.grubbs_params(),
            "dixon": gen.dixon_params(),
            "esd": gen.esd_params(n_samples),
            
            # Distance (3)
            "knn": gen.knn_params(n_samples),
            "mahalanobis": gen.mahalanobis_params(),
            "lof": gen.lof_params(n_samples),
            
            # Density (4)
            "dbscan": gen.dbscan_params(),
            "optics": gen.optics_params(),
            "hdbscan": gen.hdbscan_params(),
            "cblof": gen.cblof_params(n_samples),
            
            # Clustering (3)
            "kmeans_anomaly": gen.kmeans_params(n_samples),
            "gmm": gen.gmm_params(n_samples),
            "spectral": gen.spectral_params(n_samples),
            
            # Trees (2)
            "isolation_forest": gen.isolation_forest_params(),
            "extended_if": gen.extended_if_params(),
            
            # Time-Series (3)
            "stl": gen.stl_params(),
            "arima_residual": gen.arima_params(),
            "prophet": gen.prophet_params(),
            
            # Graph (4)
            "pagerank": gen.pagerank_params(),
            "hits": gen.hits_params(),
            "community": gen.community_params(),
            "centrality": gen.centrality_params(),
            
            # Deep Learning (2)
            "autoencoder": gen.autoencoder_params(n_features),
            "vae": gen.vae_params(n_features),
        }
    
    # =========================================================================
    # STATISTICAL METHODS (5)
    # =========================================================================
    
    @staticmethod
    def zscore_params() -> Dict[str, Any]:
        """Z-Score parameters."""
        return {"threshold": 3.0}
    
    @staticmethod
    def iqr_params() -> Dict[str, Any]:
        """IQR parameters."""
        return {"multiplier": 1.5}
    
    @staticmethod
    def grubbs_params() -> Dict[str, Any]:
        """Grubbs test parameters."""
        return {"alpha": 0.05}
    
    @staticmethod
    def dixon_params() -> Dict[str, Any]:
        """Dixon Q-test parameters."""
        return {"alpha": 0.05}
    
    @staticmethod
    def esd_params(n_samples: int) -> Dict[str, Any]:
        """Generalized ESD parameters."""
        max_outliers = max(1, int(n_samples * 0.1))  # 10% of samples
        return {"max_outliers": max_outliers, "alpha": 0.05}
    
    # =========================================================================
    # DISTANCE-BASED METHODS (3)
    # =========================================================================
    
    @staticmethod
    def knn_params(n_samples: int) -> Dict[str, Any]:
        """KNN parameters."""
        n_neighbors = min(5, max(2, n_samples // 10))
        return {"n_neighbors": n_neighbors}
    
    @staticmethod
    def mahalanobis_params() -> Dict[str, Any]:
        """Mahalanobis distance (no params)."""
        return {}
    
    @staticmethod
    def lof_params(n_samples: int) -> Dict[str, Any]:
        """Local Outlier Factor parameters."""
        n_neighbors = min(20, max(5, n_samples // 10))
        return {"n_neighbors": n_neighbors}
    
    # =========================================================================
    # DENSITY-BASED METHODS (4)
    # =========================================================================
    
    @staticmethod
    def dbscan_params() -> Dict[str, Any]:
        """DBSCAN parameters (eps auto-tuned during execution)."""
        return {"eps": "auto", "min_samples": 5}
    
    @staticmethod
    def optics_params() -> Dict[str, Any]:
        """OPTICS parameters."""
        return {"min_samples": 5}
    
    @staticmethod
    def hdbscan_params() -> Dict[str, Any]:
        """HDBSCAN parameters."""
        return {"min_cluster_size": 5}
    
    @staticmethod
    def cblof_params(n_samples: int) -> Dict[str, Any]:
        """Cluster-Based Local Outlier Factor parameters."""
        n_clusters = min(8, max(2, n_samples // 100))
        return {"n_clusters": n_clusters}
    
    # =========================================================================
    # CLUSTERING-BASED METHODS (3)
    # =========================================================================
    
    @staticmethod
    def kmeans_params(n_samples: int) -> Dict[str, Any]:
        """K-Means anomaly detection parameters."""
        n_clusters = min(10, max(2, n_samples // 100))
        return {"n_clusters": n_clusters}
    
    @staticmethod
    def gmm_params(n_samples: int) -> Dict[str, Any]:
        """Gaussian Mixture Model parameters."""
        n_components = min(10, max(2, n_samples // 100))
        return {"n_components": n_components}
    
    @staticmethod
    def spectral_params(n_samples: int) -> Dict[str, Any]:
        """Spectral clustering anomaly detection parameters."""
        n_clusters = min(10, max(2, n_samples // 100))
        return {"n_clusters": n_clusters}
    
    # =========================================================================
    # TREE-BASED METHODS (2)
    # =========================================================================
    
    @staticmethod
    def isolation_forest_params() -> Dict[str, Any]:
        """Isolation Forest parameters."""
        return {"contamination": 0.1, "n_estimators": 100}
    
    @staticmethod
    def extended_if_params() -> Dict[str, Any]:
        """Extended Isolation Forest parameters."""
        return {"contamination": 0.1}
    
    # =========================================================================
    # TIME-SERIES METHODS (3)
    # =========================================================================
    
    @staticmethod
    def stl_params() -> Dict[str, Any]:
        """STL decomposition parameters."""
        return {"period": "auto"}  # Auto-detected during execution
    
    @staticmethod
    def arima_params() -> Dict[str, Any]:
        """ARIMA parameters."""
        return {"order": "auto"}  # AIC-based selection
    
    @staticmethod
    def prophet_params() -> Dict[str, Any]:
        """Prophet parameters."""
        return {"seasonality": "auto"}
    
    # =========================================================================
    # GRAPH-BASED METHODS (4)
    # =========================================================================
    
    @staticmethod
    def pagerank_params() -> Dict[str, Any]:
        """PageRank parameters."""
        return {"alpha": 0.85}
    
    @staticmethod
    def hits_params() -> Dict[str, Any]:
        """HITS algorithm (no params)."""
        return {}
    
    @staticmethod
    def community_params() -> Dict[str, Any]:
        """Community detection parameters."""
        return {"algorithm": "louvain"}
    
    @staticmethod
    def centrality_params() -> Dict[str, Any]:
        """Centrality parameters."""
        return {"type": "eigenvector"}
    
    # =========================================================================
    # DEEP LEARNING METHODS (2)
    # =========================================================================
    
    @staticmethod
    def autoencoder_params(n_features: int) -> Dict[str, Any]:
        """Autoencoder parameters."""
        # Architecture: [n, n//2, n//4, n//2, n]
        return {
            "hidden_layers": [
                n_features,
                max(2, n_features // 2),
                max(2, n_features // 4),
                max(2, n_features // 2),
                n_features
            ],
            "epochs": 50,
            "batch_size": 32,
            "learning_rate": 0.001
        }
    
    @staticmethod
    def vae_params(n_features: int) -> Dict[str, Any]:
        """Variational Autoencoder parameters."""
        latent_dim = max(2, n_features // 10)
        return {
            "latent_dim": latent_dim,
            "epochs": 50,
            "batch_size": 32,
            "learning_rate": 0.001
        }


def get_auto_params(
    method_name: str,
    n_samples: int,
    n_features: int,
    data_stats: Optional[Dict] = None
) -> Dict[str, Any]:
    """
    Get auto-generated parameters for a specific method.
    
    Args:
        method_name: Name of detection method
        n_samples: Number of samples
        n_features: Number of features
        data_stats: Optional distribution statistics
    
    Returns:
        Parameters dict for the method
    
    Example:
        >>> params = get_auto_params("knn", n_samples=1000, n_features=10)
        >>> print(params)
        {'n_neighbors': 5}
    """
    all_params = AutoParamGenerator.generate_all(n_samples, n_features, data_stats)
    return all_params.get(method_name, {})


# =============================================================================
# EXAMPLE USAGE
# =============================================================================
if __name__ == "__main__":
    # Example: Generate parameters for 1000 samples, 10 features
    params = AutoParamGenerator.generate_all(n_samples=1000, n_features=10)
    
    print("Auto-Generated Parameters for 1000 samples, 10 features:")
    print("=" * 60)
    
    for method, param_dict in params.items():
        print(f"{method:20s}: {param_dict}")
    
    print("\n" + "=" * 60)
    print(f"Total methods: {len(params)}")
