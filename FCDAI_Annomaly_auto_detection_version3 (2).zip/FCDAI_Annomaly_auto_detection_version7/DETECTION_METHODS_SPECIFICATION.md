# 26 DETECTION METHODS: DYNAMIC EXECUTION SPECIFICATION

**Version 7 - Flexible Architecture**  
**Auto-Adaptive Method Selection Based on Data Characteristics**

---

## 📊 OVERVIEW

Version 7 implements **26 anomaly detection methods** across **8 categories**, with **intelligent auto-execution** based on data availability. Methods are conditionally enabled/disabled to ensure robust operation regardless of data structure.

**Core Principle**: Never fail due to missing data structures — gracefully skip incompatible methods.

---

## 🎯 METHOD CATEGORIES & REQUIREMENTS

### CATEGORY 1: STATISTICAL (5 Methods)
**Requirements**: `features >= 3`, `samples >= 50`

| Method   | Input        | Weight | Auto-Params                  |
|----------|--------------|--------|------------------------------|
| Z-Score  | X_STANDARD   | 1.0    | threshold=3.0                |
| IQR      | X_RAW        | 1.0    | multiplier=1.5               |
| Grubbs   | X_RAW        | 1.0    | alpha=0.05                   |
| Dixon    | X_RAW        | 1.0    | alpha=0.05                   |
| ESD      | X_RAW        | 1.0    | max_outliers=10% of samples  |

**Use Case**: Univariate outlier detection, robust to distribution assumptions.

---

### CATEGORY 2: DISTANCE-BASED (3 Methods)
**Requirements**: `features >= 3`, `samples >= 50`

| Method       | Input        | Weight | Auto-Params                     |
|--------------|--------------|--------|---------------------------------|
| KNN          | X_STANDARD   | 1.0    | n_neighbors=min(5, samples//10) |
| Mahalanobis  | X_STANDARD   | 1.0    | (no params)                     |
| LOF          | X_STANDARD   | 1.2    | n_neighbors=min(20, samples//10)|

**Use Case**: Multivariate distance-based anomaly detection, considers feature correlations.

---

### CATEGORY 3: DENSITY-BASED (4 Methods)
**Requirements**: `features >= 3`, `samples >= 50`

| Method   | Input        | Weight | Auto-Params                         |
|----------|--------------|--------|-------------------------------------|
| DBSCAN   | X_STANDARD   | 1.0    | eps=auto-tuned, min_samples=5       |
| OPTICS   | X_STANDARD   | 1.0    | min_samples=5                       |
| HDBSCAN  | X_STANDARD   | 1.0    | min_cluster_size=5                  |
| CBLOF    | X_STANDARD   | 1.0    | n_clusters=min(8, samples//100)     |

**Use Case**: Density-based clustering, identifies anomalies in low-density regions.

---

### CATEGORY 4: CLUSTERING-BASED (3 Methods)
**Requirements**: `features >= 3`, `samples >= 50`

| Method    | Input        | Weight | Auto-Params                         |
|-----------|--------------|--------|-------------------------------------|
| K-Means   | X_STANDARD   | 1.0    | n_clusters=min(10, samples//100)    |
| GMM       | X_STANDARD   | 1.0    | n_components=min(10, samples//100)  |
| Spectral  | X_STANDARD   | 1.0    | n_clusters=min(10, samples//100)    |

**Use Case**: Cluster-based anomaly detection, anomalies are far from cluster centers.

---

### CATEGORY 5: TREE-BASED (2 Methods) ⭐ **HIGHEST WEIGHT**
**Requirements**: `features >= 3`, `samples >= 50`

| Method             | Input   | Weight  | Auto-Params                           |
|--------------------|---------|---------|---------------------------------------|
| Isolation Forest   | X_RAW   | **1.5** | contamination=0.1, n_estimators=100   |
| Extended IF        | X_RAW   | **1.5** | contamination=0.1                     |

**Use Case**: Ensemble tree-based isolation, highly effective for anomaly detection. **Weighted higher due to superior performance.**

---

### CATEGORY 6: TIME-SERIES (3 Methods) — **CONDITIONAL**
**Requirements**: `TIME_SERIES data available` (from TEMPORAL table or time-indexed MASTER)

| Method   | Input         | Weight | Auto-Params              |
|----------|---------------|--------|--------------------------|
| STL      | TIME_SERIES   | 1.0    | period=auto-detected     |
| ARIMA    | TIME_SERIES   | 1.0    | order=auto (AIC)         |
| Prophet  | TIME_SERIES   | 1.0    | seasonality=auto         |

**Use Case**: Time-series anomaly detection, identifies temporal pattern deviations.

⚠️ **If `TIME_SERIES` is None**: SKIP these methods (do not fail)

---

### CATEGORY 7: GRAPH-BASED (4 Methods) — **CONDITIONAL**
**Requirements**: `GRAPH_NETWORK available` (from RELATIONSHIPS table)

| Method      | Input   | Weight | Auto-Params              |
|-------------|---------|--------|--------------------------|
| PageRank    | GRAPH   | 1.0    | alpha=0.85               |
| HITS        | GRAPH   | 1.0    | (no params)              |
| Community   | GRAPH   | 1.0    | algorithm=Louvain        |
| Centrality  | GRAPH   | 1.0    | type=eigenvector         |

**Use Case**: Network-based anomaly detection, identifies unusual relationship patterns.

⚠️ **If `GRAPH_NETWORK` is None**: SKIP these methods (do not fail)

---

### CATEGORY 8: DEEP LEARNING (2 Methods) — **CONDITIONAL**
**Requirements**: `features >= 10`, `samples >= 100`

| Method       | Input      | Weight | Auto-Params                    |
|--------------|------------|--------|--------------------------------|
| Autoencoder  | X_MINMAX   | 1.0    | layers=[n, n//2, n//4, n//2, n]|
| VAE          | X_MINMAX   | 1.0    | latent_dim=max(2, n//10)       |

**Use Case**: Neural network-based anomaly detection via reconstruction error.

⚠️ **If `features < 10` OR `samples < 100`**: SKIP deep learning (insufficient data)  
⚠️ Uses **CPU only** (tensorflow-cpu or pytorch-cpu)

---

## 🔄 EXECUTION ALGORITHM (STEP 10)

### Input
- `DATA_STRUCTURES`: Dict containing X_RAW, X_STANDARD, X_MINMAX, TIME_SERIES (optional), GRAPH_NETWORK (optional)
- `METHOD_CONFIG`: List of method configurations (loaded or auto-generated)
- `CUSTOMER_IDS`: Array of customer identifiers
- `FEATURE_NAMES`: List of feature names

### Initialization
```python
EXECUTED_METHODS = []
SKIPPED_METHODS = []
RAW_SCORES = DataFrame(columns=['cust_id'])
RAW_SCORES['cust_id'] = CUSTOMER_IDS
```

### Execution Loop
```python
FOR EACH method in METHOD_CONFIG:
    
    # Check if method is enabled
    IF method.enabled == FALSE:
        SKIPPED_METHODS.append({method, reason="Disabled in config"})
        CONTINUE
    
    # Check data requirements
    IF method.requires_temporal AND TIME_SERIES is None:
        SKIPPED_METHODS.append({method, reason="No temporal data"})
        Log: "Skipping {method} — temporal data not available"
        CONTINUE
    
    IF method.requires_graph AND GRAPH_NETWORK is None:
        SKIPPED_METHODS.append({method, reason="No graph data"})
        Log: "Skipping {method} — relationship data not available"
        CONTINUE
    
    IF len(FEATURE_NAMES) < method.min_features:
        SKIPPED_METHODS.append({method, reason=f"Need {min_features}, have {n}"})
        Log: "Skipping {method} — insufficient features"
        CONTINUE
    
    IF len(CUSTOMER_IDS) < method.min_samples:
        SKIPPED_METHODS.append({method, reason=f"Need {min_samples}, have {n}"})
        Log: "Skipping {method} — insufficient samples"
        CONTINUE
    
    # Execute method
    TRY:
        input_data = get_input_for_method(method, DATA_STRUCTURES)
        params = method.parameters or AUTO_PARAMS[method.name]
        scores = run_method(method.name, input_data, params)
        RAW_SCORES[method.name] = scores
        EXECUTED_METHODS.append(method)
        Log: "Executed {method}: {sum(scores > threshold)} anomalies"
    EXCEPT Exception as e:
        SKIPPED_METHODS.append({method, reason=f"Error: {e}"})
        Log: "Failed {method}: {e}"
```

### Output
- `RAW_SCORES`: DataFrame with shape N × M (N=customers, M=executed methods)
- `EXECUTED_METHODS`: List of successfully executed methods
- `SKIPPED_METHODS`: List of skipped methods with reasons

---

## 📋 EXAMPLE SCENARIOS

### Scenario 1: Minimal MASTER Only
**Data**: MASTER with 5 features, 100 customers (no additional tables)

**Executed (17 methods)**:
- Statistical: Z-Score, IQR, Grubbs, Dixon, ESD
- Distance: KNN, Mahalanobis, LOF
- Density: DBSCAN, OPTICS, HDBSCAN, CBLOF
- Clustering: K-Means, GMM, Spectral
- Trees: Isolation Forest (1.5×), Extended IF (1.5×)

**Skipped (9 methods)**:
- Deep Learning: Autoencoder, VAE — insufficient features (need 10, have 5)
- Time-Series: STL, ARIMA, Prophet — no temporal data
- Graph: PageRank, HITS, Community, Centrality — no relationship data

**Ensemble**: 17 methods with normalized weights

---

### Scenario 2: MASTER + TRANSACTIONS (with temporal)
**Data**: MASTER (10 features) + TRANSACTIONS (time-indexed), 200 customers

**Executed (22 methods)**:
- All 17 from Scenario 1
- Deep Learning: Autoencoder, VAE (features >= 10, samples >= 100)
- Time-Series: STL, ARIMA, Prophet (temporal data available)

**Skipped (4 methods)**:
- Graph: PageRank, HITS, Community, Centrality — no relationship data

**Ensemble**: 22 methods with normalized weights

---

### Scenario 3: Full Dataset (MASTER + TRANSACTIONS + RELATIONSHIPS)
**Data**: MASTER (10 features) + TRANSACTIONS (temporal) + RELATIONSHIPS (graph), 200 customers

**Executed (26 methods)** — ALL METHODS
- Statistical: 5
- Distance: 3
- Density: 4
- Clustering: 3
- Trees: 2
- Deep Learning: 2
- Time-Series: 3
- Graph: 4

**Skipped**: None

**Ensemble**: 26 methods with normalized weights

---

## 🛡️ ROBUSTNESS FEATURES

### 1. Graceful Degradation
- Methods fail independently without crashing pipeline
- Execution continues even if individual methods error
- Detailed logging of skipped methods with reasons

### 2. Data-Adaptive
- Auto-detects available data structures
- Adjusts method selection to data characteristics
- No manual configuration required

### 3. Parameter Auto-Tuning
- Sample-based parameter adjustment (e.g., n_neighbors)
- Feature-based architecture tuning (e.g., autoencoder layers)
- Contamination rate defaults to 10%

### 4. Input Data Routing
- **X_RAW**: Tree methods (no scaling bias)
- **X_STANDARD**: Distance/Density/Clustering (normalized)
- **X_MINMAX**: Deep Learning (gradient stability)
- **TIME_SERIES**: Temporal methods
- **GRAPH_NETWORK**: Network methods

### 5. Weight Management
- Tree methods: 1.5× (proven superiority)
- LOF: 1.2× (effective density-based)
- Others: 1.0× (standard weight)
- Weights normalized before ensemble fusion

---

## 📊 ENSEMBLE FUSION (LAYER 6)

After all methods execute:

1. **Normalize Scores**: Scale each method's scores to [0, 1]
2. **Apply Weights**: Multiply by method weights
3. **Aggregate**: Weighted average across all executed methods
4. **Final Score**: Output per-customer anomaly score

**Formula**:
```
final_score[i] = Σ(weight[m] × normalized_score[m][i]) / Σ(weight[m])
                 for m in EXECUTED_METHODS
```

---

## 🔍 LOGGING & AUDIT

**Execution Log Includes**:
- Total methods attempted
- Methods executed (with counts per category)
- Methods skipped (with specific reasons)
- Execution time per method
- Anomalies detected per method
- Final ensemble statistics

**Example Log**:
```
[INFO] Detection Engine: 26 methods configured
[INFO] Executed: 17 methods
[INFO]   Statistical: 5/5
[INFO]   Distance: 3/3
[INFO]   Density: 4/4
[INFO]   Clustering: 3/3
[INFO]   Trees: 2/2
[INFO] Skipped: 9 methods
[WARN]   Deep Learning (2): Insufficient features (have 5, need 10)
[WARN]   Time-Series (3): No temporal data available
[WARN]   Graph (4): No relationship data available
[INFO] Ensemble: 17 methods, total weight=18.5
[INFO] Anomalies detected: 8/100 customers (8.0%)
```

---

## ✅ IMPLEMENTATION STATUS

- ✅ Method specification documented
- ✅ Auto-parameter logic defined
- ✅ Conditional execution algorithm specified
- ✅ Input data routing documented
- ✅ Weight management defined
- ✅ Graceful degradation logic specified
- ⏳ Layer 5 implementation (to be enhanced)
- ⏳ UI integration for method visibility

---

**Last Updated**: February 12, 2026  
**Version**: 7.0.0  
**Status**: Specification Complete
