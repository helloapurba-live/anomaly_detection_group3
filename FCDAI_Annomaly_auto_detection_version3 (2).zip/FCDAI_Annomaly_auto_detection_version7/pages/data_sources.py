"""
Data Sources Page - VERSION 7 FLEXIBLE ARCHITECTURE
====================================================
PRINCIPLE 1: MASTER table is the ONLY mandatory input
PRINCIPLE 2: Unlimited extensibility - add ANY table at runtime
PRINCIPLE 3: Auto-detection of data types
PRINCIPLE 4: Configuration tables are optional

Data entry point:
- Upload MASTER table (mandatory: cust_id + cust_name)
- Upload ANY additional tables (optional)
- System auto-discovers and processes all tables
- No hardcoded table names or schemas
"""

import dash
from dash import html, dcc, callback, Input, Output, State, ctx, ALL
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import dash_ag_grid as dag
import pandas as pd
import numpy as np
import io, base64, sys, json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS, APP
from utils.schema_detector import SchemaDetector, ColumnType

dash.register_page(__name__, path="/sources", name="Data Sources", order=1)


# =============================================================================
# FLEXIBLE CONFIGURATION - NO HARDCODED TABLES
# =============================================================================
# VERSION 7: No TABLE_CONFIG dictionary!
# Tables are discovered dynamically based on uploaded files

MASK_COLUMNS = {"party_id", "customer_id", "account_id", "cust_id"}


# =============================================================================
# VERSION 7: DYNAMIC TABLE VALIDATION & DISCOVERY
# =============================================================================

def validate_master_table(df: pd.DataFrame) -> Tuple[bool, str]:
    """
    Validate MASTER table has required columns.
    
    PRINCIPLE 1: Only cust_id and cust_name are mandatory
    
    Returns:
        (is_valid, error_message)
    """
    required = ['cust_id', 'cust_name']
    missing = [col for col in required if col not in df.columns]
    
    if missing:
        return False, f"MASTER table missing required columns: {', '.join(missing)}"
    
    # Check cust_id uniqueness
    if df['cust_id'].duplicated().any():
        return False, "MASTER table has duplicate cust_id values"
    
    # Check for nulls in required columns
    if df['cust_id'].isnull().any():
        return False, "MASTER table has null values in cust_id"
    
    return True, ""


def can_join_to_master(df: pd.DataFrame) -> bool:
    """
    Check if table can be joined to MASTER.
    
    PRINCIPLE 2: Any table with cust_id column can be added
    
    Returns:
        True if table has cust_id column
    """
    return 'cust_id' in df.columns


def get_dynamic_table_icon(table_name: str) -> Dict[str, str]:
    """
    Assign icon and color dynamically based on table name keywords.
    
    PRINCIPLE 2: System accepts ANY table name
    """
    name_lower = table_name.lower()
    
    # Keyword-based icon assignment
    if 'master' in name_lower:
        return {"icon": "mdi:database", "color": "cyan"}
    elif 'transaction' in name_lower or 'txn' in name_lower:
        return {"icon": "mdi:swap-horizontal", "color": "blue"}
    elif 'customer' in name_lower or 'party' in name_lower or 'client' in name_lower:
        return {"icon": "mdi:account-group", "color": "indigo"}
    elif 'account' in name_lower or 'acct' in name_lower:
        return {"icon": "mdi:bank", "color": "green"}
    elif 'alert' in name_lower:
        return {"icon": "mdi:alert", "color": "orange"}
    elif 'case' in name_lower or 'investigation' in name_lower:
        return {"icon": "mdi:briefcase", "color": "red"}
    elif 'kyc' in name_lower or 'compliance' in name_lower:
        return {"icon": "mdi:shield-check", "color": "teal"}
    elif 'watchlist' in name_lower or 'sanction' in name_lower or 'pep' in name_lower:
        return {"icon": "mdi:shield-search", "color": "pink"}
    elif 'relationship' in name_lower or 'network' in name_lower or 'graph' in name_lower:
        return {"icon": "mdi:graph-outline", "color": "violet"}
    elif 'temporal' in name_lower or 'time' in name_lower or 'series' in name_lower:
        return {"icon": "mdi:chart-timeline", "color": "grape"}
    else:
        # Default for any unknown table
        return {"icon": "mdi:table", "color": "gray"}


def mask_id(val):
    s = str(val)
    return f"****{s[-4:]}" if len(s) > 4 else s


def build_ag_grid(df, table_name, max_rows=50):
    """Build AG Grid preview."""
    preview = df.head(max_rows).copy()
    for col in preview.columns:
        if col in MASK_COLUMNS:
            preview[col] = preview[col].apply(mask_id)
    cols = [{"field": c, "sortable": True, "filter": True, "resizable": True} for c in preview.columns]
    return dag.AgGrid(
        id={"type": "source-grid", "table": table_name},
        rowData=preview.to_dict("records"),
        columnDefs=cols,
        defaultColDef={"flex": 1, "minWidth": 100},
        dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
        style={"height": None, "width": "100%"},
        className="ag-theme-alpine-dark",
    )


def _upload_card(table_name, conf):
    """Mini upload zone per table - compact design."""
    return dmc.Paper(
        [
            dmc.Stack(
                [
                    dmc.Group([
                        dmc.ThemeIcon(
                            DashIconify(icon=conf["icon"], width=16),
                            color=conf["color"], variant="light", size="sm",
                        ),
                        dmc.Text(conf["label"], fw=500, size="xs"),
                    ], gap="xs", justify="flex-start"),
                    dcc.Upload(
                        id={"type": "upload-table", "table": table_name},
                        children=dmc.Stack([
                            DashIconify(icon="mdi:cloud-upload", width=20, color="#888"),
                            dmc.Text("Drop file", size="xs", c="dimmed", ta="center"),
                        ], gap=2, align="center"),
                        style={
                            "border": f"1px dashed {THEME.DARK_BORDER}",
                            "borderRadius": "6px",
                            "padding": "8px",
                            "textAlign": "center",
                            "cursor": "pointer",
                            "minHeight": "60px",
                        },
                        multiple=False,
                    ),
                    html.Div(
                        id={"type": "upload-status", "table": table_name},
                        style={"minHeight": "20px"}
                    ),
                ],
                gap="xs",
            ),
        ],
        p="xs", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD, "height": "100%"},
    )


def _build_config_upload_card(config_name, icon, color, description):
    """Build upload card for optional config tables."""
    return dmc.Paper(
        [
            dmc.Stack([
                dmc.Group([
                    dmc.ThemeIcon(
                        DashIconify(icon=icon, width=18),
                        color=color, variant="light", size="md",
                    ),
                    dmc.Text(config_name, fw=600, size="xs"),
                ], gap="xs"),
                dmc.Text(description, size="xs", c="dimmed", style={"minHeight": "32px"}),
                dcc.Upload(
                    id={"type": "upload-config", "name": config_name},
                    children=dmc.Stack([
                        DashIconify(icon="mdi:upload", width=16, color="#888"),
                        dmc.Text("Upload", size="xs", c="dimmed"),
                    ], gap=2, align="center"),
                    style={
                        "border": "1px dashed #444",
                        "borderRadius": "4px",
                        "padding": "6px",
                        "textAlign": "center",
                        "cursor": "pointer",
                        "minHeight": "40px",
                    },
                    multiple=False,
                ),
                html.Div(
                    id={"type": "config-status", "name": config_name},
                    style={"minHeight": "16px"}
                ),
            ], gap="xs"),
        ],
        p="sm", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD, "height": "100%"},
    )


def _build_schema_docs_modal():
    """Build comprehensive schema documentation modal content."""
    return dmc.ScrollArea(
        [
            dmc.Tabs(
                [
                    dmc.TabsList([
                        dmc.TabsTab("📊 Data Tables", value="data"),
                        dmc.TabsTab("⚙️ Config Tables", value="config"),
                        dmc.TabsTab("🔍 Auto-Detection", value="detection"),
                    ]),
                    
                    # Tab 1: Data Tables
                    dmc.TabsPanel(
                        dmc.Stack([
                            dmc.Title("Data Tables: Flexible Schema", order=3, mb="md"),
                            
                            # MASTER Table Section
                            dmc.Paper([
                                dmc.Title("MASTER Table (MANDATORY)", order=4, mb="sm", c="red"),
                                dmc.Text("The ONLY required table. Must have 2 columns minimum:", size="sm", mb="sm"),
                                dmc.Table([
                                    html.Thead(html.Tr([
                                        html.Th("Column"), html.Th("Type"), html.Th("Description")
                                    ])),
                                    html.Tbody([
                                        html.Tr([
                                            html.Td("cust_id"),
                                            html.Td("ANY (String/Int)"),
                                            html.Td("Unique customer identifier — PRIMARY KEY")
                                        ]),
                                        html.Tr([
                                            html.Td("cust_name"),
                                            html.Td("STRING"),
                                            html.Td("Customer name — for display/reporting only")
                                        ]),
                                    ]),
                                ], striped=True, highlightOnHover=True),
                                dmc.Divider(my="md"),
                                dmc.Text("Additional Columns (Unlimited):  ", fw=600, mb="xs"),
                                dmc.List([
                                    dmc.ListItem("ANY column name accepted"),
                                    dmc.ListItem("System auto-detects ALL data types"),
                                    dmc.ListItem("No pre-configuration needed"),
                                ], size="sm"),
                                dmc.Divider(my="md"),
                                dmc.Text("Valid MASTER Examples:", fw=600, mb="sm"),
                                dmc. Code(
                                    "Minimal (2 cols): cust_id, cust_name\n\n"
                                    "Medium (20 cols): cust_id, cust_name, total_amt, txn_count, risk_flag, ... +15 more\n\n"
                                    "Full (100+ cols): cust_id, cust_name, benford_*, volume_*, velocity_*, ... +90 more",
                                    block=True, style={"whiteSpace": "pre-wrap"}
                                ),
                            ], p="md", withBorder=True, mb="md"),
                            
                            # Additional Tables Section
                            dmc.Paper([
                                dmc.Title("Additional Tables (ALL OPTIONAL)", order=4, mb="sm", c="green"),
                                dmc.Text("Add unlimited tables with ANY names. Common patterns:", size="sm", mb="sm"),
                                dmc.Table([
                                    html.Thead(html.Tr([
                                        html.Th("Table Name"), html.Th("Status"), html.Th("Description")
                                    ])),
                                    html.Tbody([
                                        html.Tr([html.Td("transactions"), html.Td("OPTIONAL"), html.Td("Transaction-level data rolled up to customer")]),
                                        html.Tr([html.Td("party / customer"), html.Td("OPTIONAL"), html.Td("Customer demographics")]),
                                        html.Tr([html.Td("accounts"), html.Td("OPTIONAL"), html.Td("Account-level data")]),
                                        html.Tr([html.Td("alerts"), html.Td("OPTIONAL"), html.Td("Alert history")]),
                                        html.Tr([html.Td("cases"), html.Td("OPTIONAL"), html.Td("Investigation history")]),
                                        html.Tr([html.Td("kyc"), html.Td("OPTIONAL"), html.Td("KYC compliance data")]),
                                        html.Tr([html.Td("watchlist"), html.Td("OPTIONAL"), html.Td("Sanctions/PEP matches")]),
                                        html.Tr([html.Td("[ANY_NAME]"), html.Td("OPTIONAL"), html.Td("System accepts ANY table name")]),
                                    ]),
                                ], striped=True, highlightOnHover=True),
                                dmc.Alert(
                                    "✨ RULE: Any table with 'cust_id' column can be auto-joined to MASTER",
                                    color="cyan", variant="light", mt="md",
                                ),
                            ], p="md", withBorder=True),
                        ], gap="md"),
                        value="data",
                    ),
                    
                    # Tab 2: Config Tables
                    dmc.TabsPanel(
                        dmc.Stack([
                            dmc.Title("Configuration Tables (All Optional)", order=3, mb="md"),
                            dmc.Alert(
                                "⚠️ ALL config tables are OPTIONAL. System uses intelligent defaults when config is missing.",
                                color="blue", variant="light", mb="md",
                            ),
                            
                            # Config tables documentation
                            dmc.Paper([
                                dmc.Title("1. EXCLUDE_FEATURES", order=5, mb="sm"),
                                dmc.Text("Define features to EXCLUDE from final feature matrix", size="sm", mb="sm"),
                                dmc.Code(
                                    "Schema: table_name (required), feature_name (required), exclusion_reason (optional)\n\n"
                                     "Default Behavior (when missing):\n"
                                    "• Auto-exclude columns with: 'id', 'name', 'ssn', 'phone', 'email', 'address'\n"
                                    "• Auto-exclude high cardinality: >50% unique values\n"
                                    "• Auto-exclude zero variance: All values identical\n"
                                    "• Auto-exclude 100% null columns",
                                    block=True, style={"whiteSpace": "pre-wrap"}
                                ),
                            ], p="md", withBorder=True, mb="md"),
                            
                            dmc.Paper([
                                dmc.Title("2. FEATURE_MAP", order=5, mb="sm"),
                                dmc.Text("Rename/transform features across tables", size="sm", mb="sm"),
                                dmc.Code(
                                    "Schema: table_name, current_name, system_name, transformation (LOG/SQRT/ZSCORE)\n\n"
                                    "Default Behavior (when missing):\n"
                                    "• Keep original column names\n"
                                    "• Auto-apply LOG to skewed columns (skew > 2)\n"
                                    "• Auto-apply StandardScaler to continuous features",
                                    block=True, style={"whiteSpace": "pre-wrap"}
                                ),
                            ], p="md", withBorder=True, mb="md"),
                            
                            dmc.Paper([
                                dmc.Title("3. TABLE_MAP", order=5, mb="sm"),
                                dmc.Text("Define how tables join together", size="sm", mb="sm"),
                                dmc.Code(
                                    "Schema: base_table, target_table, base_key, target_key, join_type (LEFT/INNER)\n\n"
                                    "Default Behavior (when missing):\n"
                                    "• Auto-scan all tables for 'cust_id' or 'customer_id'\n"
                                    "• Auto-configure LEFT JOIN to MASTER on that column\n"
                                    "• All joins are optional by default",
                                    block=True, style={"whiteSpace": "pre-wrap"}
                                ),
                            ], p="md", withBorder=True, mb="md"),
                            
                            dmc.Paper([
                                dmc.Title("4. METHOD_CONFIG", order=5, mb="sm"),
                                dmc.Text("Configure detection algorithms to run", size="sm", mb="sm"),
                                dmc.Code(
                                    "Schema: method_name, category, is_enabled, weight, parameters (JSON)\n\n"
                                    "AUTO-GENERATION Logic (when missing):\n"
                                    "• IF features ≥ 3 AND samples ≥ 50: Enable all statistical methods\n"
                                    "• IF features ≥ 10 AND samples ≥ 100: Enable deep learning\n"
                                    "• IF temporal data available: Enable STL, ARIMA, Prophet\n"
                                    "• IF graph data available: Enable PageRank, HITS, Centrality\n"
                                    "• Auto-assign weights: Isolation Forest=1.5, LOF=1.2, Others=1.0",
                                    block=True, style={"whiteSpace": "pre-wrap"}
                                ),
                            ], p="md", withBorder=True),
                        ], gap="md"),
                        value="config",
                    ),
                    
                    # Tab 3: Auto-Detection
                    dmc.TabsPanel(
                        dmc.Stack([
                            dmc.Title("Auto-Detection Rules", order=3, mb="md"),
                            dmc.Text("System automatically classifies ALL columns into 8 types:", size="sm", mb="md"),
                            
                            dmc.Table([
                                html.Thead(html.Tr([
                                    html.Th("Data Type"), html.Th("Detection Rule"), html.Th("Usable for Modeling")
                                ])),
                                html.Tbody([
                                    html.Tr([
                                        html.Td(dmc.Badge("CONTINUOUS", color="blue")),
                                        html.Td("Float, large range integers"),
                                        html.Td("✅ YES"),
                                    ]),
                                    html.Tr([
                                        html.Td(dmc.Badge("BINARY", color="green")),
                                       html.Td("Exactly 2 unique values (0/1, Y/N, T/F)"),
                                        html.Td("✅ YES"),
                                    ]),
                                    html.Tr([
                                        html.Td(dmc.Badge("ORDINAL", color="cyan")),
                                        html.Td("Integer with 2-10 unique values"),
                                        html.Td("✅ YES"),
                                    ]),
                                    html.Tr([
                                        html.Td(dmc.Badge("CATEGORICAL", color="grape")),
                                        html.Td("String/Object with <20 unique values"),
                                        html.Td("✅ YES"),
                                    ]),
                                    html.Tr([
                                        html.Td(dmc.Badge("HIGH_CARDINALITY", color="red")),
                                        html.Td("String with >20 unique values"),
                                        html.Td("❌ EXCLUDED"),
                                    ]),
                                    html.Tr([
                                        html.Td(dmc.Badge("ID_FIELD", color="orange")),
                                        html.Td(">95% unique + keywords (id, key, pk)"),
                                        html.Td("❌ EXCLUDED (except cust_id)"),
                                    ]),
                                    html.Tr([
                                        html.Td(dmc.Badge("DATETIME", color="yellow")),
                                        html.Td("Datetime/Timestamp"),
                                        html.Td("⚠️ CONTEXT-DEPENDENT"),
                                    ]),
                                    html.Tr([
                                        html.Td(dmc.Badge("TEXT", color="gray")),
                                        html.Td("Long text, free-form fields"),
                                        html.Td("❌ EXCLUDED"),
                                    ]),
                                ]),
                            ], striped=True, highlightOnHover=True),
                            
                            dmc.Alert(
                                "Additional Exclusion Rules: Columns with >80% nulls or zero variance are marked as non-usable",
                                color="orange", variant="light", mt="md",
                            ),
                        ], gap="md"),
                        value="detection",
                    ),
                ],
                value="data",
                variant="pills",
                color="cyan",
            ),
        ],
        h=600,
    )




# =============================================================================
# TABLE SLOTS - 12 Predefined Table Types
# =============================================================================
TABLE_SLOTS = [
    {"name": "MASTER", "icon": "mdi:database", "color": "cyan", "label": "Master", "mandatory": True, "desc": "cust_id + cust_name (Required)"},
    {"name": "transactions", "icon": "mdi:swap-horizontal", "color": "blue", "label": "Transactions", "mandatory": False, "desc": "Transaction-level data"},
    {"name": "customer_party", "icon": "mdi:account-group", "color": "indigo", "label": "Customer/Party", "mandatory": False, "desc": "Customer demographics"},
    {"name": "accounts", "icon": "mdi:bank", "color": "green", "label": "Accounts", "mandatory": False, "desc": "Account-level data"},
    {"name": "alerts", "icon": "mdi:alert", "color": "orange", "label": "Alerts", "mandatory": False, "desc": "Alert history"},
    {"name": "cases", "icon": "mdi:briefcase", "color": "red", "label": "Cases", "mandatory": False, "desc": "Investigation cases"},
    {"name": "kyc", "icon": "mdi:shield-check", "color": "teal", "label": "KYC", "mandatory": False, "desc": "KYC compliance data"},
    {"name": "watchlist", "icon": "mdi:shield-search", "color": "pink", "label": "Watchlist", "mandatory": False, "desc": "Sanctions/PEP matches"},
    {"name": "relationships", "icon": "mdi:graph-outline", "color": "violet", "label": "Relationships", "mandatory": False, "desc": "Network/graph data"},
    {"name": "temporal", "icon": "mdi:chart-timeline", "color": "grape", "label": "Temporal", "mandatory": False, "desc": "Time series data"},
    {"name": "others1", "icon": "mdi:table-plus", "color": "gray", "label": "Others1", "mandatory": False, "desc": "Custom table slot 1"},
    {"name": "others2", "icon": "mdi:table-plus", "color": "gray", "label": "Others2", "mandatory": False, "desc": "Custom table slot 2"},
]


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Container(
    [
        # Header with Documentation
        dmc.Group(
            [
                dmc.Stack([
                    dmc.Title("Data Sources — V7 Flexible Architecture", order=2),
                    dmc.Text(
                        "MASTER required (cust_id+cust_name) • Unlimited tables • Auto-detection",
                        size="sm", c="dimmed"
                    ),
                ], gap=2),
                dmc.Group([
                    dmc.Badge("Dynamic Discovery", color="cyan", variant="light"),
                    dmc.Badge("Auto-Detection", color="teal", variant="light"),
                    dmc.Button(
                        "📖 Schema Docs",
                        id="btn-open-schema-docs",
                        variant="subtle",
                        size="xs",
                        color="blue",
                        leftSection=DashIconify(icon="mdi:book-open-variant", width=14),
                    ),
                ], gap="xs"),
            ],
            justify="space-between",
            mb="lg",
        ),

        # Schema Documentation Modal
        dmc.Modal(
            id="modal-schema-docs",
            title="Flexible Schema Architecture — Complete Reference",
            size="90%",
            children=_build_schema_docs_modal(),
        ),

        # ── SECTION 1: QUICK START (TWO MINI BOXES) ──────────────────
        dmc.Text("Quick Start", fw=700, size="lg", mb="sm"),
        dmc.SimpleGrid(
            cols={"base": 1, "sm": 1, "md": 2},
            spacing="md",
            mb="lg",
            children=[
                # BOX 1: Generate Sample Data
                dmc.Paper(
                    [
                        dmc.Group([
                            DashIconify(icon="mdi:database-plus", width=22, color="#22b8cf"),
                            dmc.Text("1. Sample Data", fw=600, size="sm"),
                        ], gap="xs", mb="xs"),
                        dmc.Text(
                            "Generate test data",
                            size="xs", c="dimmed", mb="sm",
                        ),
                        dmc.NumberInput(
                            id="ds-customer-count",
                            label="Customers",
                            value=100, min=10, max=100000, step=10,
                            size="xs",
                            style={"width": "100%"},
                            mb="xs",
                        ),
                        dmc.Button(
                            "Generate",
                            id="ds-btn-generate",
                            leftSection=DashIconify(icon="mdi:play", width=14),
                            color="cyan", size="xs", fullWidth=True, mb="xs",
                        ),
                        dmc.Button(
                            "Reset All",
                            id="ds-btn-reset",
                            leftSection=DashIconify(icon="mdi:trash-can", width=14),
                            color="red", variant="subtle", size="xs", fullWidth=True,
                        ),
                    ],
                    p="sm", radius="md", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD, "height": "100%"},
                ),
                
                # BOX 2: Select for Execution
                dmc.Paper(
                    [
                        dmc.Group([
                            DashIconify(icon="mdi:check-decagram", width=22, color="#51cf66"),
                            dmc.Text("2. Use for Execution", fw=600, size="sm"),
                        ], gap="xs", mb="xs"),
                        dmc.Text(
                            "Select data source",
                            size="xs", c="dimmed", mb="sm",
                        ),
                        dmc.SegmentedControl(
                            id="ds-execution-choice",
                            data=[
                                {"label": "Sample", "value": "sample"},
                                {"label": "Actual", "value": "actual"},
                            ],
                            value="sample",
                            color="green",
                            fullWidth=True,
                            size="xs",
                            mb="sm",
                        ),
                        html.Div(id="ds-execution-info", children=[
                            dmc.Alert(
                                "No data available",
                                color="gray",
                                variant="light",
                                styles={"message": {"fontSize": "11px"}},
                            )
                        ]),
                        dmc.Button(
                            "Confirm",
                            id="ds-btn-confirm-final",
                            leftSection=DashIconify(icon="mdi:check-bold", width=14),
                            color="green", size="xs", fullWidth=True, mt="xs",
                            disabled=True,
                        ),
                    ],
                    p="sm", radius="md", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD, "height": "100%"},
                ),
            ],
        ),
        
        # Status messages
        html.Div(id="ds-status-output", style={"marginBottom": "1rem"}),

        # ══════════════════════════════════════════════════════════════
        # SECTION 2: UPLOAD — MASTER (Mandatory) + Additional (Optional) SIDE BY SIDE
        # ══════════════════════════════════════════════════════════════
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2},
            spacing="md",
            mb="lg",
            children=[
                # LEFT: MASTER Table Upload (Mandatory)
                dmc.Paper([
                    dmc.Group([
                        DashIconify(icon="mdi:database", width=22, color="#22b8cf"),
                        dmc.Text("MASTER Table", fw=600, size="sm"),
                        dmc.Badge("Mandatory", color="red", size="xs", variant="filled"),
                    ], gap="xs", mb="xs"),
                    dmc.Text("Required columns: cust_id + cust_name", size="xs", c="dimmed", mb="sm"),
                    dcc.Upload(
                        id="upload-master-table",
                        children=dmc.Stack([
                            DashIconify(icon="mdi:cloud-upload", width=28, color="#22b8cf"),
                            dmc.Text("Drop MASTER file here", size="xs", fw=500),
                            dmc.Text("CSV / Excel / Parquet", size="10px", c="dimmed"),
                        ], gap=2, align="center"),
                        style={
                            "border": "2px dashed #22b8cf",
                            "borderRadius": "8px",
                            "padding": "16px",
                            "textAlign": "center",
                            "cursor": "pointer",
                            "minHeight": "90px",
                            "backgroundColor": "rgba(34, 184, 207, 0.05)",
                        },
                        multiple=False,
                    ),
                    html.Div(id="master-upload-status", style={"marginTop": "8px"}),
                ], p="sm", radius="md", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD, "height": "100%"}),

                # RIGHT: Additional Tables Upload (Optional)
                dmc.Paper([
                    dmc.Group([
                        DashIconify(icon="mdi:table-multiple", width=22, color="#51cf66"),
                        dmc.Text("Additional Tables", fw=600, size="sm"),
                        dmc.Badge("Optional", color="green", size="xs", variant="light"),
                    ], gap="xs", mb="xs"),
                    dmc.Text("Upload any tables with cust_id to auto-join", size="xs", c="dimmed", mb="sm"),
                    dcc.Upload(
                        id="upload-additional-tables",
                        children=dmc.Stack([
                            DashIconify(icon="mdi:folder-multiple-plus", width=28, color="#51cf66"),
                            dmc.Text("Drop additional files here", size="xs", fw=500),
                            dmc.Text("Multiple files allowed", size="10px", c="dimmed"),
                        ], gap=2, align="center"),
                        style={
                            "border": "2px dashed #51cf66",
                            "borderRadius": "8px",
                            "padding": "16px",
                            "textAlign": "center",
                            "cursor": "pointer",
                            "minHeight": "90px",
                            "backgroundColor": "rgba(81, 207, 102, 0.05)",
                        },
                        multiple=True,
                    ),
                    html.Div(id="additional-upload-status", style={"marginTop": "8px"}),
                ], p="sm", radius="md", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD, "height": "100%"}),
            ],
        ),

        # ══════════════════════════════════════════════════════════════
        # SECTION 3: ALL TABLE SLOTS (12 Types — 4x3 Grid)
        # ══════════════════════════════════════════════════════════════
        dmc.Text("All Table Types", fw=700, size="lg", mb="xs"),
        dmc.Text("12 integrated table slots across the data pipeline", size="xs", c="dimmed", mb="sm"),
        dmc.SimpleGrid(
            cols={"base": 2, "sm": 3, "md": 4, "lg": 6},
            spacing="xs",
            mb="lg",
            children=[
                dmc.Paper([
                    dmc.Stack([
                        dmc.Group([
                            dmc.ThemeIcon(
                                DashIconify(icon=slot["icon"], width=14),
                                color=slot["color"], variant="light", size="sm",
                            ),
                            dmc.Text(slot["label"], fw=600, size="xs"),
                        ], gap=4, wrap="nowrap"),
                        dmc.Group([
                            dmc.Badge(
                                "Required" if slot["mandatory"] else "Optional",
                                color="red" if slot["mandatory"] else "gray",
                                size="xs",
                                variant="filled" if slot["mandatory"] else "light",
                            ),
                        ]),
                        dmc.Text(slot["desc"], size="10px", c="dimmed", lineClamp=1),
                    ], gap=3),
                ], p="xs", radius="sm", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD})
                for slot in TABLE_SLOTS
            ],
        ),

        # ══════════════════════════════════════════════════════════════
        # SECTION 4: Advanced Configuration Tables (All Optional)
        # ══════════════════════════════════════════════════════════════
        dmc.Text("Advanced: Configuration Tables (All Optional)", fw=700, size="lg", mb="sm"),
        dmc.Alert(
            [
                dmc.Text(
                    "Upload config tables to override intelligent defaults. System works perfectly without these.",
                    size="xs",
                ),
            ],
            color="blue",
            variant="light",
            icon=DashIconify(icon="mdi:cog-outline", width=20),
            mb="md",
        ),
        dmc.SimpleGrid(
            cols={"base": 1, "sm": 2, "md": 4},
            spacing="sm",
            mb="lg",
            children=[
                _build_config_upload_card("EXCLUDE_FEATURES", "mdi:minus-circle", "red", "Features to exclude from modeling"),
                _build_config_upload_card("FEATURE_MAP", "mdi:map", "blue", "Rename/transform features"),
                _build_config_upload_card("TABLE_MAP", "mdi:table-multiple", "cyan", "Define table join logic"),
                _build_config_upload_card("METHOD_CONFIG", "mdi:brain", "grape", "Configure detection algorithms"),
            ],
        ),
        html.Div(id="config-upload-status"),

        # ══════════════════════════════════════════════════════════════
        # SECTION 5: LOADED TABLES SUMMARY (with Export/Delete)
        # ══════════════════════════════════════════════════════════════
        dmc.Paper([
            dmc.Group([
                dmc.Text("Loaded Tables Summary", fw=700, size="lg"),
                dmc.Group([
                    dmc.Button(
                        "Export All CSV",
                        id="ds-btn-export-all",
                        leftSection=DashIconify(icon="mdi:download", width=14),
                        color="cyan", size="xs", variant="light",
                    ),
                    dmc.Button(
                        "Delete All Data",
                        id="ds-btn-delete-all",
                        leftSection=DashIconify(icon="mdi:trash-can", width=14),
                        color="red", size="xs", variant="light",
                    ),
                ], gap="xs"),
            ], justify="space-between", mb="sm"),
            dmc.Text("All loaded tables with auto-detected schemas, record counts, and actions.", size="sm", c="dimmed", mb="md"),
            html.Div(id="ds-summary-table"),
        ], p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}, mb="lg"),

        # ── SOURCE STATS ──────────────────────────
        html.Div(id="ds-source-stats"),
        dmc.Space(h="md"),

        # ── TABLE PREVIEWS ────────────────────────
        html.Div(id="ds-table-previews"),

        # Download component for exports
        dcc.Download(id="ds-download-export"),

        # Stores
        dcc.Store(id="ds-upload-trigger", data=0),
        dcc.Store(id="ds-final-data-store", data=None),
    ],
    fluid=True,
)


# =============================================================================
# CALLBACKS - VERSION 7 FLEXIBLE ARCHITECTURE
# =============================================================================

# ── MASTER Table Upload (Mandatory) ─────────────────────────────────────
@callback(
    Output("master-upload-status", "children"),
    Output("ds-summary-table", "children"),
    Output("ds-source-stats", "children"),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input("upload-master-table", "contents"),
    State("upload-master-table", "filename"),
    State("ds-execution-choice", "value"),
    prevent_initial_call=True,
)
def upload_master_table(contents, filename, execution_choice):
    """
    Handle MASTER table upload with validation.
    
    PRINCIPLE 1: MASTER is mandatory with cust_id + cust_name
    """
    from utils.data_io import data_vault
    
    if contents is None:
        return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update
    
    try:
        # Parse file
        content_string = contents.split(",")[1]
        decoded = base64.b64decode(content_string)
        
        if filename.endswith(".csv"):
            df = pd.read_csv(io.StringIO(decoded.decode("utf-8")))
        elif filename.endswith((".xlsx", ".xls")):
            df = pd.read_excel(io.BytesIO(decoded))
        elif filename.endswith(".parquet"):
            df = pd.read_parquet(io.BytesIO(decoded))
        else:
            return dmc.Alert(
                f"Unsupported file format: {filename}",
                color="red",
                icon=DashIconify(icon="mdi:alert"),
            ), dash.no_update, dash.no_update, dash.no_update, dash.no_update
        
        # Validate MASTER table
        is_valid, error_msg = validate_master_table(df)
        
        if not is_valid:
            return dmc.Alert(
                error_msg,
               color="red",
                icon=DashIconify(icon="mdi:alert-circle"),
                withCloseButton=True,
            ), dash.no_update, dash.no_update, dash.no_update, dash.no_update
        
        # Auto-detect schema
        detector = SchemaDetector()
        schema_profiles = detector.detect_schema(df)
        usable_cols = detector.get_usable_columns(schema_profiles)
        
        # Save MASTER table
        sources_dir = PATHS.DATA_VAULT / "sources"
        sources_dir.mkdir(parents=True, exist_ok=True)
        df.to_parquet(sources_dir / "MASTER.parquet", index=False)
        
        # Update vault
        data_vault._sources["MASTER"] = df
        meta = data_vault.get_metadata()
        meta["master_uploaded"] = True
        meta["master_columns"] = list(df.columns)
        meta["master_usable_columns"] = usable_cols
        meta["data_type"] = execution_choice or "actual"
        meta["actual_tables"] = ["MASTER"]
        data_vault._metadata = meta
        data_vault.save_metadata()
        
        # Build status message
        status_alert = dmc.Stack([
            dmc.Alert(
                f"✓ MASTER table uploaded successfully: {len(df):,} customers",
                color="green",
                icon=DashIconify(icon="mdi:check-circle"),
            ),
            dmc.Paper([
                dmc.Text("Auto-Detected Schema:", fw=600, size="sm", mb="xs"),
                dmc.Text(f"Total Columns: {len(df.columns)}", size="xs"),
                dmc.Text(f"Usable for Modeling: {len(usable_cols)}", size="xs", c="green"),
                dmc.Text(f"Required: cust_id ✓, cust_name ✓", size="xs", c="cyan"),
            ], p="sm", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}),
        ], gap="sm")
        
        # Update execution info
        execution_info = dmc.Stack([
            dmc.Group([
                DashIconify(icon="mdi:check-circle", width=16, color="#51cf66"),
                dmc.Text(f"MASTER Ready — {len(df):,} customers", size="xs", fw=600, c="green"),
            ], gap=4),
            dmc.Text(f"{len(usable_cols)} usable columns detected", size="xs", c="dimmed", mt=2),
        ], gap=0)
        
        # Load sources for summary
        sources = data_vault.load_sources()
        
        return (
            status_alert,
            _build_summary_table(sources, data_vault),
            _build_stats(sources, data_vault),
            execution_info,
            False  # Enable confirm button
        )
        
    except Exception as e:
        return dmc.Alert(
            f"Error uploading MASTER table: {str(e)}",
            color="red",
            icon=DashIconify(icon="mdi:alert"),
        ), dash.no_update, dash.no_update, dash.no_update, dash.no_update


# ── Additional Tables Upload (Optional) ─────────────────────────────────────
@callback(
    Output("additional-upload-status", "children"),
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children"),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input("upload-additional-tables", "contents"),
    State("upload-additional-tables", "filename"),
    State("ds-execution-choice", "value"),
    prevent_initial_call='initial_duplicate',
)
def upload_additional_tables(contents_list, filenames_list, execution_choice):
    """
    Handle additional table uploads (unlimited, any name).
    
    PRINCIPLE 2: Unlimited extensibility - accept ANY table
    """
    from utils.data_io import data_vault
    
    if not contents_list:
        return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update
    
    # Ensure lists
    if not isinstance(contents_list, list):
        contents_list = [contents_list]
    if not isinstance(filenames_list, list):
        filenames_list = [filenames_list]
    
    status_messages = []
    uploaded_tables = []
    
    for contents, filename in zip(contents_list, filenames_list):
        try:
            # Parse file
            content_string = contents.split(",")[1]
            decoded = base64.b64decode(content_string)
            
            table_name = filename.rsplit(".", 1)[0]  # Remove extension
            
            if filename.endswith(".csv"):
                df = pd.read_csv(io.StringIO(decoded.decode("utf-8")))
            elif filename.endswith((".xlsx", ".xls")):
                df = pd.read_excel(io.BytesIO(decoded))
            elif filename.endswith(".parquet"):
                df = pd.read_parquet(io.BytesIO(decoded))
            else:
                status_messages.append(
                    dmc.Alert(f"✗ {filename}: Unsupported format", color="red", variant="light")
                )
                continue
            
            # Check if can join to MASTER
            can_join = can_join_to_master(df)
            
            if not can_join:
                status_messages.append(
                    dmc.Alert(
                        f"⚠ {table_name}: No cust_id column - cannot join to MASTER",
                        color="orange",
                        variant="light",
                    )
                )
                # Still save it, but mark as non-joinable
            
            # Auto-detect schema
            detector = SchemaDetector()
            schema_profiles = detector.detect_schema(df)
            usable_cols = detector.get_usable_columns(schema_profiles)
            
            # Save table
            sources_dir = PATHS.DATA_VAULT / "sources"
            sources_dir.mkdir(parents=True, exist_ok=True)
            df.to_parquet(sources_dir / f"{table_name}.parquet", index=False)
            
            # Update vault
            data_vault._sources[table_name] = df
            uploaded_tables.append(table_name)
            
            # Get dynamic icon
            icon_info = get_dynamic_table_icon(table_name)
            
            status_messages.append(
                dmc.Alert(
                    [
                        dmc.Group([
                            DashIconify(icon=icon_info["icon"], width=16, color=icon_info["color"]),
                            dmc.Text(f"✓ {table_name}: {len(df):,} rows, {len(usable_cols)} usable columns", size="sm"),
                        ], gap="xs"),
                    ],
                    color="green",
                    variant="light",
                )
            )
            
        except Exception as e:
            status_messages.append(
                dmc.Alert(f"✗ {filename}: {str(e)[:50]}", color="red", variant="light")
            )
    
    # Update metadata
    if uploaded_tables:
        meta = data_vault.get_metadata()
        actual_tables = set(meta.get("actual_tables", []))
        actual_tables.update(uploaded_tables)
        meta["actual_tables"] = list(actual_tables)
        data_vault._metadata = meta
        data_vault.save_metadata()
        
        # Rebuild merged view if MASTER exists
        if "MASTER" in data_vault._sources:
            _rebuild_merged_flexible(data_vault)
    
    # Update execution info
    sources = data_vault.load_sources()
    execution_info = dash.no_update
    confirm_disabled = dash.no_update
    
    if execution_choice == "actual" and len(sources) > 0:
        table_count = len(sources)
        execution_info = dmc.Stack([
            dmc.Group([
                DashIconify(icon="mdi:check-circle", width=16, color="#51cf66"),
                dmc.Text(f"Data Ready — {table_count} tables loaded", size="xs", fw=600, c="green"),
            ], gap=4),
            dmc.Text(", ".join(list(sources.keys())[:5]) + ("..." if len(sources) > 5 else ""), size="xs", c="dimmed", mt=2),
        ], gap=0)
        confirm_disabled = False
    
    return (
        dmc.Stack(status_messages, gap="xs"),
        _build_summary_table(sources, data_vault),
        _build_stats(sources, data_vault),
        _build_preview_tabs(sources),
        execution_info,
        confirm_disabled
    )


def _rebuild_merged_flexible(data_vault):
    """
    Rebuild merged view from MASTER + additional tables.
    
    PRINCIPLE 2: Dynamic joins based on available tables
    """
    sources = data_vault.load_sources()
    
    if "MASTER" not in sources:
        return
    
    df_master = sources["MASTER"].copy()
    
    # Join all additional tables that have cust_id
    for table_name, df_table in sources.items():
        if table_name == "MASTER":
            continue
        
        if can_join_to_master(df_table):
            # Join on cust_id
            df_master = df_master.merge(
                df_table,
                on="cust_id",
                how="left",
                suffixes=("", f"_{table_name}")
            )
    
    data_vault.set_current_data(df_master, label="master_merged")


# ── Generate / Reset ─────────────────────────────────────
@callback(
    Output("ds-status-output", "children"),
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input("ds-btn-generate", "n_clicks"),
    Input("ds-btn-reset", "n_clicks"),
    State("ds-customer-count", "value"),
    State("ds-execution-choice", "value"),
    prevent_initial_call=True,
)
def handle_gen_reset(n_gen, n_reset, num_customers, execution_choice):
    """
    Generate sample data or reset vault.
    
    PRINCIPLE 2: Generate flexible sample data (MASTER + additional tables)
    """
    from utils.data_gen import DataGenerator
    from utils.data_io import data_vault

    triggered = ctx.triggered_id
    status_msg = None
    execution_info = dash.no_update
    confirm_disabled = dash.no_update

    if triggered == "ds-btn-reset":
        data_vault.clear_data()
        for f in PATHS.DATA_SOURCES.glob("*.csv"):
            f.unlink()
        status_msg = dmc.Alert(
            "All data cleared.", color="orange",
            icon=DashIconify(icon="mdi:check"), withCloseButton=True,
        )
        # Update execution info after reset
        execution_info = dmc.Stack([
            dmc.Group([
                DashIconify(icon="mdi:alert-circle", width=16, color="#ffd43b"),
                dmc.Text("No Data Available", size="xs", fw=600, c="yellow"),
            ], gap=4),
            dmc.Text("Generate sample data or upload actual data", size="xs", c="dimmed", mt=2),
        ], gap=0)
        confirm_disabled = True

    if triggered == "ds-btn-generate":
        try:
            num_customers = num_customers or 100
            dg = DataGenerator()
            schema = dg.generate_full_schema(num_customers)

            # Mark as sample data
            data_vault.save_sources(schema)
            meta = data_vault.get_metadata()
            meta["data_type"] = "sample"
            meta["sample_tables"] = list(schema.keys())
            data_vault._metadata = meta
            data_vault.save_metadata()

            PATHS.DATA_SOURCES.mkdir(parents=True, exist_ok=True)
            for name, df in schema.items():
                df.to_csv(PATHS.DATA_SOURCES / f"{name}.csv", index=False)

            # Merged analytical view (flexible)
            df_tx = schema.get("transactions", pd.DataFrame())
            df_acc = schema.get("account", pd.DataFrame())
            df_party = schema.get("party", pd.DataFrame())
            df_merged = df_tx.copy()
            if not df_acc.empty and "account_id" in df_tx.columns and "account_id" in df_acc.columns:
                df_merged = df_merged.merge(df_acc, on="account_id", how="left", suffixes=("", "_acc"))
            if not df_party.empty and "party_id" in df_merged.columns and "party_id" in df_party.columns:
                df_merged = df_merged.merge(df_party, on="party_id", how="left", suffixes=("", "_party"))
            data_vault.set_current_data(df_merged, label=f"generated_{num_customers}_cust")

            total_rows = sum(len(v) for v in schema.values())
            status_msg = dmc.Alert(
                f"Generated {num_customers} customers → {total_rows:,} total rows across {len(schema)} tables.",
                color="green", icon=DashIconify(icon="mdi:check-circle"), withCloseButton=True,
            )
            
            # Update execution info if sample data is selected
            if execution_choice == "sample":
                sample_count = len(schema)
                table_names = list(schema.keys())
                table_preview = ", ".join(table_names[:4])
                if len(table_names) > 4:
                    table_preview += f" +{len(table_names)-4} more"
                
                execution_info = dmc.Stack([
                    dmc.Group([
                        DashIconify(icon="mdi:check-circle", width=16, color="#51cf66"),
                        dmc.Text(f"Sample Data Ready — {sample_count} tables", size="xs", fw=600, c="cyan"),
                    ], gap=4),
                    dmc.Text(table_preview, size="xs", c="dimmed", mt=2),
                ], gap=0)
                confirm_disabled = False
                
        except Exception as e:
            status_msg = dmc.Alert(f"Generation error: {e}", color="red", icon=DashIconify(icon="mdi:alert"))

    sources = data_vault.load_sources()
    
    return status_msg, _build_summary_table(sources, data_vault), _build_stats(sources, data_vault), _build_preview_tabs(sources), execution_info, confirm_disabled


# ── Execution Choice Info Display ─────────────────────────────────────
@callback(
    Output("ds-execution-info", "children"),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input("ds-execution-choice", "value"),
    prevent_initial_call='initial_duplicate',
)
def update_execution_info(choice):
    """
    Update execution info based on selected data source.
    
    PRINCIPLE 2: Display dynamically discovered tables
    """
    from utils.data_io import data_vault
    
    sources = data_vault.load_sources()
    meta = data_vault.get_metadata()
    
    if choice == "sample":
        sample_tables = meta.get("sample_tables", [])
        sample_count = len([t for t in sample_tables if t in sources])
        
        if sample_count > 0:
            # Dynamic table names
            table_names = [t for t in sample_tables if t in sources]
            table_preview = ", ".join(table_names[:4])
            if len(table_names) > 4:
                table_preview += f" +{len(table_names)-4} more"
            
            return dmc.Stack([
                dmc.Group([
                    DashIconify(icon="mdi:check-circle", width=16, color="#51cf66"),
                    dmc.Text(f"Sample Data Ready — {sample_count} tables", size="xs", fw=600, c="cyan"),
                ], gap=4),
                dmc.Text(table_preview, size="xs", c="dimmed", mt=2),
            ], gap=0), False
        else:
            return dmc.Stack([
                dmc.Group([
                    DashIconify(icon="mdi:alert-circle", width=16, color="#ffd43b"),
                    dmc.Text("No Sample Data", size="xs", fw=600, c="yellow"),
                ], gap=4),
                dmc.Text("Click 'Generate' in Box 1 to create sample data", size="xs", c="dimmed", mt=2),
            ], gap=0), True
    
    elif choice == "actual":
        actual_tables = meta.get("actual_tables", [])
        actual_count = len([t for t in actual_tables if t in sources])
        
        if actual_count > 0:
            # Dynamic table names
            table_names = [t for t in actual_tables if t in sources]
            table_preview = ", ".join(table_names[:4])
            if len(table_names) > 4:
                table_preview += f" +{len(table_names)-4} more"
            
            return dmc.Stack([
                dmc.Group([
                    DashIconify(icon="mdi:check-circle", width=16, color="#51cf66"),
                    dmc.Text(f"Actual Data Ready — {actual_count} tables", size="xs", fw=600, c="green"),
                ], gap=4),
                dmc.Text(table_preview, size="xs", c="dimmed", mt=2),
            ], gap=0), False
        else:
            return dmc.Stack([
                dmc.Group([
                    DashIconify(icon="mdi:alert-circle", width=16, color="#ffd43b"),
                    dmc.Text("No Actual Data", size="xs", fw=600, c="yellow"),
                ], gap=4),
                dmc.Text("Upload MASTER + additional tables below", size="xs", c="dimmed", mt=2),
            ], gap=0), True
    
    return dmc.Alert(
        "Select data source above",
        color="gray",
        variant="light",
        styles={"message": {"fontSize": "11px"}},
    ), True


# ── Confirm Final Data Selection ─────────────────────────────────────
@callback(
    Output("ds-status-output", "children", allow_duplicate=True),
    Output("ds-final-data-store", "data"),
    Input("ds-btn-confirm-final", "n_clicks"),
    State("ds-execution-choice", "value"),
    prevent_initial_call=True,
)
def confirm_final_data(n_clicks, choice):
    from utils.data_io import data_vault
    
    if not choice:
        return dmc.Alert(
            "Please select Sample or Actual data.",
            color="orange",
            icon=DashIconify(icon="mdi:alert"),
            withCloseButton=True,
        ), None
    
    meta = data_vault.get_metadata()
    meta["final_data_choice"] = choice
    data_vault._metadata = meta
    data_vault.save_metadata()
    
    # Store final data selection for use in execution engine
    final_data_info = {
        "choice": choice,
        "label": "Sample Data" if choice == "sample" else "Actual Data",
        "timestamp": pd.Timestamp.now().isoformat(),
    }
    
    choice_label = "Sample Data" if choice == "sample" else "Actual Data"
    return dmc.Alert(
        f"✓ Execution Engine will use: {choice_label}",
        color="green",
        icon=DashIconify(icon="mdi:check-circle"),
        withCloseButton=True,
    ), final_data_info


# =============================================================================
# HELPER BUILDERS - VERSION 7 FLEXIBLE ARCHITECTURE
# =============================================================================
def _build_summary_table(sources, data_vault):
    """
    Build AG Grid summary table for all data sources.
    
    PRINCIPLE 2: Dynamic table discovery - no hardcoded tables
    """
    rows = []
    
    # Get all loaded tables
    for name in sorted(sources.keys()):
        df = sources[name]
        icon_info = get_dynamic_table_icon(name)
        
        # Auto-detect schema
        detector = SchemaDetector()
        schema_profiles = detector.detect_schema(df)
        usable_cols = detector.get_usable_columns(schema_profiles)
        
        # Mark MASTER table
        table_type = "MASTER (Required)" if name == "MASTER" else "Additional"
        
        rows.append({
            "Table": name,
            "Type": table_type,
            "Status": "✓ Loaded",
            "Records": f"{len(df):,}",
            "Columns": len(df.columns),
            "Usable": len(usable_cols),
            "Icon": icon_info["icon"],
        })
    
    if not rows:
        # Empty state
        rows.append({
            "Table": "-",
            "Type": "-",
            "Status": "⚬ No Data",
            "Records": "-",
            "Columns": "-",
            "Usable": "-",
            "Icon": "mdi:table-off",
        })
    
    col_defs = [
        {
            "field": "Table",
            "headerName": "Table Name",
            "flex": 2,
            "sortable": True,
            "filter": True,
            "floatingFilter": True,
            "pinned": "left",
            "cellStyle": {"fontWeight": "600"},
        },
        {
            "field": "Type",
            "headerName": "Type",
            "flex": 1.5,
            "sortable": True,
            "filter": True,
        },
        {
            "field": "Status",
            "headerName": "Status",
            "flex": 1,
            "sortable": True,
            "filter": True,
        },
        {
            "field": "Records",
            "headerName": "Records",
            "flex": 1,
            "sortable": True,
            "filter": True,
            "type": "rightAligned",
        },
        {
            "field": "Columns",
            "headerName": "Total Cols",
            "flex": 1,
            "sortable": True,
            "filter": True,
            "type": "rightAligned",
        },
        {
            "field": "Usable",
            "headerName": "Usable Cols",
            "flex": 1,
            "sortable": True,
            "filter": True,
            "type": "rightAligned",
            "cellStyle": {"color": "#51cf66"},
        },
    ]
    
    return dag.AgGrid(
        id="ds-summary-grid",
        rowData=rows,
        columnDefs=col_defs,
        defaultColDef={
            "resizable": True,
            "sortable": True,
            "filter": True,
        },
        dashGridOptions={
            "domLayout": "autoHeight",
            "animateRows": True,
            "rowHeight": 45,
        },
        style={"height": None, "width": "100%"},
        className="ag-theme-alpine-dark",
    )


def _build_stats(sources, data_vault):
    """
    Build stats showing all loaded data sources.
    
    PRINCIPLE 2: Dynamic table discovery - show what's actually loaded
    """
    meta = data_vault.get_metadata()
    last_gen = meta.get("import_time", "N/A")

    table_count = len(sources)
    total_rows = sum(len(df) for df in sources.values())

    cards = []
    
    # Dynamic cards for all loaded tables
    for name, df in sorted(sources.items()):
        icon_info = get_dynamic_table_icon(name)
        
        # Auto-detect schema
        detector = SchemaDetector()
        schema_profiles = detector.detect_schema(df)
        usable_cols = detector.get_usable_columns(schema_profiles)
        
        # Special badge for MASTER
        is_master = (name == "MASTER")
        
        cards.append(
            dmc.Paper(
                dmc.Stack([
                    dmc.Group([
                        dmc.ThemeIcon(
                            DashIconify(icon=icon_info["icon"], width=20),
                            color=icon_info["color"], variant="light", size="lg",
                        ),
                        dmc.Stack([
                            dmc.Group([
                                dmc.Text(name, size="sm", fw=600),
                                dmc.Badge("REQUIRED", color="red", size="xs", variant="light") if is_master else None,
                            ], gap=4),
                            dmc.Text(f"{len(df):,} rows • {len(df.columns)} cols • {len(usable_cols)} usable", 
                                   size="xs", c="dimmed"),
                        ], gap=0),
                    ], gap="sm"),
                ], gap=4),
                p="sm", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD},
            )
        )
    
    if not cards:
        # Empty state
        cards.append(
            dmc.Paper(
                dmc.Group([
                    dmc.ThemeIcon(
                        DashIconify(icon="mdi:table-off", width=20),
                        color="gray", variant="light", size="lg",
                    ),
                    dmc.Text("No data loaded", size="sm", c="dimmed"),
                ], gap="sm"),
                p="sm", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD, "opacity": 0.6},
            )
        )

    return dmc.Stack([
        dmc.Group([
            dmc.Badge(f"{table_count} Tables Loaded", color="cyan", variant="light", size="lg"),
            dmc.Badge(f"{total_rows:,} Total Rows", color="blue", variant="light", size="lg") if total_rows > 0 else None,
            dmc.Text(
                f"Last updated: {last_gen[:19] if last_gen != 'N/A' else 'N/A'}",
                size="xs", c="dimmed",
            ),
        ], gap="md"),
        dmc.SimpleGrid(
            cols={"base": 2, "md": 3, "lg": 6}, spacing="sm", children=cards,
        ),
    ], gap="md")


def _build_preview_tabs(sources):
    """
    Build preview tabs for all loaded tables.
    
    PRINCIPLE 2: Dynamic table display
    """
    if not sources:
        return dmc.Alert(
            "No data sources loaded yet. Upload MASTER table or generate sample data.",
            color="gray",
            variant="light",
            icon=DashIconify(icon="mdi:information"),
        )

    tabs = []
    panels = []
    for name, df in sorted(sources.items()):
        icon_info = get_dynamic_table_icon(name)
        
        tabs.append(
            dmc.TabsTab(
                name, value=name,
                leftSection=DashIconify(icon=icon_info["icon"], width=16),
            )
        )
        panels.append(
            dmc.TabsPanel(
                dmc.Paper([
                    dmc.Group([
                        dmc.Text(f"Preview: first 50 of {len(df):,} rows", size="sm", c="dimmed"),
                        dmc.Badge(f"{len(df.columns)} columns", color="gray", variant="light", size="sm"),
                    ], justify="space-between", mb="sm"),
                    build_ag_grid(df, name),
                ], p="md", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}),
                value=name,
            )
        )

    first = list(sources.keys())[0]
    return dmc.Tabs(
        [dmc.TabsList(tabs)] + panels,
        value=first, color="cyan", variant="pills",
    )


# =============================================================================
# CALLBACK: Handle exclude-variable file upload
# =============================================================================
@callback(
    Output("ds-exclude-status", "children"),
    Input("ds-upload-exclude", "contents"),
    State("ds-upload-exclude", "filename"),
    prevent_initial_call=True,
)
def handle_exclude_upload(contents, filename):
    if contents is None:
        return ""

    try:
        from utils.data_io import data_vault

        content_type, content_string = contents.split(",")
        decoded = base64.b64decode(content_string)

        if filename.endswith((".xlsx", ".xls")):
            df = pd.read_excel(io.BytesIO(decoded))
        elif filename.endswith(".csv"):
            df = pd.read_csv(io.StringIO(decoded.decode("utf-8")))
        else:
            return dmc.Alert("Unsupported file type. Use CSV or Excel.", color="red")

        # Extract variable names from the first column or 'variable' column
        if "variable" in df.columns:
            var_list = df["variable"].dropna().astype(str).tolist()
        else:
            var_list = df.iloc[:, 0].dropna().astype(str).tolist()

        # Save to vault
        exclude_path = PATHS.DATA_VAULT / "exclude_vars.json"
        with open(exclude_path, "w") as f:
            json.dump(var_list, f)

        return dmc.Alert(
            f"✓ {len(var_list)} variables loaded for exclusion from '{filename}'",
            color="green",
            icon=DashIconify(icon="mdi:check-circle"),
        )

    except Exception as e:
        return dmc.Alert(f"Error parsing exclude file: {e}", color="red")


# =============================================================================
# CALLBACK: Initialize page on load
# =============================================================================
@callback(
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-execution-choice", "value", allow_duplicate=True),
    Input("ds-upload-trigger", "data"),
    prevent_initial_call='initial_duplicate',
)
def init_page_load(trigger):
    """Load existing data sources on page load."""
    from utils.data_io import data_vault
    sources = data_vault.load_sources()
    meta = data_vault.get_metadata()
    
    # Restore last execution choice
    final_choice = meta.get("final_data_choice", "sample")
    
    return _build_summary_table(sources, data_vault), _build_stats(sources, data_vault), _build_preview_tabs(sources), final_choice


# =============================================================================
# CALLBACK: Schema Documentation Modal
# =============================================================================
@callback(
    Output("modal-schema-docs", "opened"),
    Input("btn-open-schema-docs", "n_clicks"),
    State("modal-schema-docs", "opened"),
    prevent_initial_call=True,
)
def toggle_schema_docs_modal(n_clicks, opened):
    """Toggle schema documentation modal."""
    return not opened


# =============================================================================
# CALLBACK: Handle Config Table Uploads
# =============================================================================
@callback(
    Output({"type": "config-status", "name": ALL}, "children"),
    Output("config-upload-status", "children"),
    Input({"type": "upload-config", "name": ALL}, "contents"),
    State({"type": "upload-config", "name": ALL}, "id"),
    prevent_initial_call=True,
)
def handle_config_uploads(contents_list, ids_list):
    """
    Handle optional config table uploads.
    
    Config tables override intelligent defaults:
    - EXCLUDE_FEATURES: Define manual exclusions
    - FEATURE_MAP: Define transformations
    - TABLE_MAP: Define join logic
    - METHOD_CONFIG: Define algorithm selection
    """
    from utils.data_io import data_vault
    
    status_outputs = [None] * len(contents_list)
    overall_status = []
    
    for i, (contents, id_dict) in enumerate(zip(contents_list, ids_list)):
        if contents is None:
            continue
            
        config_name = id_dict["name"]
        
        try:
            # Parse file
            content_string = contents.split(",")[1]
            decoded = base64.b64decode(content_string)
            
            # Determine file type and parse
            df = pd.read_csv(io.StringIO(decoded.decode("utf-8")))
            
            # Save config table
            config_dir = PATHS.DATA_VAULT / "config"
            config_dir.mkdir(parents=True, exist_ok=True)
            df.to_parquet(config_dir / f"{config_name}.parquet", index=False)
            
            # Update metadata
            meta = data_vault.get_metadata()
            config_tables = meta.get("config_tables", {})
            config_tables[config_name] = {
                "loaded": True,
                "rows": len(df),
                "columns": list(df.columns),
                "timestamp": pd.Timestamp.now().isoformat(),
            }
            meta["config_tables"] = config_tables
            data_vault._metadata = meta
            data_vault.save_metadata()
            
            status_outputs[i] = dmc.Text(f"✓ {len(df)} rows", size="xs", c="green")
            overall_status.append(
                dmc.Alert(
                    f"✓ {config_name}: {len(df)} configuration rules loaded",
                    color="green",
                    variant="light",
                    icon=DashIconify(icon="mdi:check-circle"),
                )
            )
            
        except Exception as e:
            status_outputs[i] = dmc.Text("✗ Error", size="xs", c="red")
            overall_status.append(
                dmc.Alert(
                    f"✗ {config_name}: {str(e)[:50]}",
                    color="red",
                    variant="light",
                )
            )
    
    if overall_status:
        return status_outputs, dmc.Stack(overall_status, gap="xs", mt="md")
    
    return status_outputs, dash.no_update

# =============================================================================
# CALLBACK: Export All Tables as CSV
# =============================================================================
@callback(
    Output("ds-download-export", "data"),
    Input("ds-btn-export-all", "n_clicks"),
    prevent_initial_call=True,
)
def export_all_tables(n_clicks):
    """Export all loaded tables as a ZIP of CSVs."""
    from utils.data_io import data_vault
    import zipfile

    sources = data_vault.load_sources()
    if not sources:
        return dash.no_update

    zip_path = PATHS.DATA_VAULT / "export_all_tables.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, df in sources.items():
            csv_bytes = df.to_csv(index=False).encode("utf-8")
            zf.writestr(f"{name}.csv", csv_bytes)

    return dcc.send_file(str(zip_path), filename="all_tables_export.zip")


# =============================================================================
# CALLBACK: Delete All Data
# =============================================================================
@callback(
    Output("ds-status-output", "children", allow_duplicate=True),
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input("ds-btn-delete-all", "n_clicks"),
    prevent_initial_call=True,
)
def delete_all_data(n_clicks):
    """Delete all loaded data and reset vault."""
    from utils.data_io import data_vault

    data_vault.clear_data()

    # Clean source files
    sources_dir = PATHS.DATA_VAULT / "sources"
    if sources_dir.exists():
        for f in sources_dir.glob("*.parquet"):
            f.unlink()
    for f in PATHS.DATA_SOURCES.glob("*.csv"):
        f.unlink()

    status = dmc.Alert(
        "All data deleted successfully.",
        color="orange",
        icon=DashIconify(icon="mdi:check"),
        withCloseButton=True,
    )
    execution_info = dmc.Stack([
        dmc.Group([
            DashIconify(icon="mdi:alert-circle", width=16, color="#ffd43b"),
            dmc.Text("No Data Available", size="xs", fw=600, c="yellow"),
        ], gap=4),
        dmc.Text("Generate or upload data to begin", size="xs", c="dimmed", mt=2),
    ], gap=0)

    empty_sources = {}
    return (
        status,
        _build_summary_table(empty_sources, data_vault),
        _build_stats(empty_sources, data_vault),
        _build_preview_tabs(empty_sources),
        execution_info,
        True,
    )

