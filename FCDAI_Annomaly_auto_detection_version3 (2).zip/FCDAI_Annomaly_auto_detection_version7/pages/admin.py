"""
Admin Panel Page
================
System administration, user management, model configuration, and system monitoring.
Includes real-time system health monitoring with psutil integration.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, ctx
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import dash_ag_grid as dag
import pandas as pd
import sys
from pathlib import Path
from datetime import datetime, timedelta
import psutil
import time

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS, LAYERS, APP

dash.register_page(__name__, path="/admin", name="Admin Panel", order=8)


# =============================================================================
# SYSTEM DATA
# =============================================================================
JOBS_DATA = [
    {"job_id": "JOB-2026020701", "type": "Detection", "status": "✓ Complete", "duration": "3 min 42 sec"},
    {"job_id": "JOB-2026020700", "type": "Features", "status": "✓ Complete", "duration": "45 sec"},
    {"job_id": "JOB-2026020615", "type": "Detection", "status": "✓ Complete", "duration": "4 min 12 sec"},
]


# =============================================================================
# LAYOUT
# =============================================================================
def layout(**kwargs):
    return dmc.Container(
        [
            # Header
            dmc.Stack([
                dmc.Group([
                    DashIconify(icon="mdi:shield-crown", width=32, color="#22b8cf"),
                    dmc.Title("Admin Panel", order=2, c="cyan"),
                ]),
                dmc.Text("System Administration and Real-Time Monitoring", size="sm", c="dimmed"),
            ], gap="xs", mb="xl"),

            # =============================================================================
            # SYSTEM HEALTH MONITORING (TOP SECTION)
            # =============================================================================
            dmc.Paper([
                dmc.Title("System Health", order=3, mb="md"),
                
                # Real-time stats
                dmc.SimpleGrid(
                    cols=4,
                    spacing="md",
                    mb="lg",
                    children=[
                        dmc.Card([
                            dmc.Group([
                                DashIconify(icon="mdi:cpu-64-bit", width=30, color="#22b8cf"),
                                dmc.Stack([
                                    dmc.Text("CPU", size="xs", c="dimmed"),
                                    dmc.Text("--", id="stat-cpu", size="xl", fw=700),
                                ], gap=0),
                            ]),
                        ], withBorder=True, p="md"),
                        
                        dmc.Card([
                            dmc.Group([
                                DashIconify(icon="mdi:memory", width=30, color="#228be6"),
                                dmc.Stack([
                                    dmc.Text("Memory", size="xs", c="dimmed"),
                                    dmc.Text("--", id="stat-memory", size="xl", fw=700),
                                ], gap=0),
                            ]),
                        ], withBorder=True, p="md"),
                        
                        dmc.Card([
                            dmc.Group([
                                DashIconify(icon="mdi:harddisk", width=30, color="#7950f2"),
                                dmc.Stack([
                                    dmc.Text("Disk", size="xs", c="dimmed"),
                                    dmc.Text("--", id="stat-disk", size="xl", fw=700),
                                ], gap=0),
                            ]),
                        ], withBorder=True, p="md"),
                        
                        dmc.Card([
                            dmc.Group([
                                DashIconify(icon="mdi:clock", width=30, color="#20c997"),
                                dmc.Stack([
                                    dmc.Text("Uptime", size="xs", c="dimmed"),
                                    dmc.Text("--", id="stat-uptime", size="xl", fw=700),
                                ], gap=0),
                            ]),
                        ], withBorder=True, p="md"),
                    ],
                ),
                
                # Platform info
                dmc.Alert(
                    icon=DashIconify(icon="mdi:shield-lock", width=20),
                    title="AIR-GAPPED MODE ACTIVE",
                    color="green",
                    children=[
                        dmc.Text("No external network connections. All resources served locally."),
                        dmc.Divider(my="sm"),
                        dmc.SimpleGrid(cols=3, spacing="md", mt="md", children=[
                            dmc.Text("• 7 Layers", size="sm"),
                            dmc.Text("• 26 Detection Methods", size="sm"),
                            dmc.Text("• 8 Categories", size="sm"),
                        ]),
                    ],
                ),
            ], p="lg", withBorder=True, radius="md", mb="xl"),

            # =============================================================================
            # ADMIN CONFIGURATION TABS
            # =============================================================================
            dmc.Tabs(
                value="model",
                color="cyan",
                children=[
                    dmc.TabsList([
                        dmc.TabsTab("Model Config", value="model", leftSection=DashIconify(icon="mdi:cog", width=16)),
                        dmc.TabsTab("System Settings", value="settings", leftSection=DashIconify(icon="mdi:server", width=16)),
                        dmc.TabsTab("System Health", value="health", leftSection=DashIconify(icon="mdi:heart-pulse", width=16)),
                    ]),

                    # TAB A: MODEL CONFIGURATION
                    dmc.TabsPanel(
                        value="model",
                        pt="md",
                        children=[
                            _build_model_config(),
                        ],
                    ),

                    # TAB B: SYSTEM SETTINGS
                    dmc.TabsPanel(
                        value="settings",
                        pt="md",
                        children=[
                            _build_system_settings(),
                        ],
                    ),

                    # TAB C: SYSTEM HEALTH
                    dmc.TabsPanel(
                        value="health",
                        pt="md",
                        children=[
                            _build_system_health(),
                        ],
                    ),
                ],
            ),
            
            # Interval for real-time updates (5 seconds)
            dcc.Interval(id="interval-health", interval=5000, n_intervals=0),
        ],
        fluid=True,
        p="xl",
    )


# =============================================================================
# TAB A: MODEL CONFIGURATION
# =============================================================================
def _build_model_config():
    return dmc.Stack([
        # Model Version
        dmc.Alert(
            "Active Model Version: v2.3.1 (Deployed: 2026-02-01)",
            color="cyan",
            icon=DashIconify(icon="mdi:check-circle", width=20),
        ),

        # Threshold Configuration
        dmc.Paper([
            dmc.Text("Threshold Configuration", fw=600, mb="md"),
            dmc.Stack([
                dmc.Group([
                    dmc.Text("CRITICAL Tier:", fw=600, size="sm", style={"width": "120px"}),
                    dmc.Text("Score ≥", size="sm", c="dimmed"),
                    dmc.NumberInput(value=0.95, step=0.01, min=0, max=1, decimalScale=2, size="xs", style={"width": "80px"}),
                    dmc.Text("OR Votes ≥", size="sm", c="dimmed"),
                    dmc.NumberInput(value=23, step=1, min=0, max=25, size="xs", style={"width": "80px"}),
                    dmc.Text("/ 25", size="sm", c="dimmed"),
                ], gap="xs"),
                dmc.Group([
                    dmc.Text("HIGH Tier:", fw=600, size="sm", style={"width": "120px"}),
                    dmc.Text("Score ≥", size="sm", c="dimmed"),
                    dmc.NumberInput(value=0.85, step=0.01, min=0, max=1, decimalScale=2, size="xs", style={"width": "80px"}),
                    dmc.Text("OR Votes ≥", size="sm", c="dimmed"),
                    dmc.NumberInput(value=18, step=1, min=0, max=25, size="xs", style={"width": "80px"}),
                    dmc.Text("/ 25", size="sm", c="dimmed"),
                ], gap="xs"),
                dmc.Group([
                    dmc.Text("MEDIUM Tier:", fw=600, size="sm", style={"width": "120px"}),
                    dmc.Text("Score ≥", size="sm", c="dimmed"),
                    dmc.NumberInput(value=0.70, step=0.01, min=0, max=1, decimalScale=2, size="xs", style={"width": "80px"}),
                    dmc.Text("OR Votes ≥", size="sm", c="dimmed"),
                    dmc.NumberInput(value=12, step=1, min=0, max=25, size="xs", style={"width": "80px"}),
                    dmc.Text("/ 25", size="sm", c="dimmed"),
                ], gap="xs"),
                dmc.Group([
                    dmc.Text("LOW Tier:", fw=600, size="sm", style={"width": "120px"}),
                    dmc.Text("Score ≥", size="sm", c="dimmed"),
                    dmc.NumberInput(value=0.50, step=0.01, min=0, max=1, decimalScale=2, size="xs", style={"width": "80px"}),
                    dmc.Text("OR Votes ≥", size="sm", c="dimmed"),
                    dmc.NumberInput(value=8, step=1, min=0, max=25, size="xs", style={"width": "80px"}),
                    dmc.Text("/ 25", size="sm", c="dimmed"),
                ], gap="xs"),
                dmc.Divider(my="sm"),
                dmc.Group([
                    dmc.Text("Target Alert Volume:", fw=600, size="sm"),
                    dmc.NumberInput(value=1000, step=100, min=100, max=10000, size="xs", style={"width": "100px"}),
                    dmc.Text("per batch", size="sm", c="dimmed"),
                ], gap="xs"),
                dmc.Checkbox(label="Auto-adjust thresholds to meet target", checked=True, size="sm"),
            ], gap="sm"),
        ], p="md", withBorder=True, radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),

        # Method Weights
        dmc.Paper([
            dmc.Text("Method Weights", fw=600, mb="md"),
            dmc.Stack([
                _weight_slider("Benford's Law", 2.0, "(Structuring focus)"),
                _weight_slider("Isolation Forest", 1.5, ""),
                _weight_slider("LOF", 1.5, ""),
                _weight_slider("Autoencoder", 1.0, ""),
                _weight_slider("LSTM-AE", 0.5, "(Experimental)"),
            ], gap="sm"),
            dmc.Group([
                dmc.Button("Reset to Default", leftSection=DashIconify(icon="mdi:refresh", width=16), color="gray", size="xs", variant="outline"),
                dmc.Button("Save Configuration", leftSection=DashIconify(icon="mdi:content-save", width=16), color="cyan", size="xs"),
            ], gap="xs", mt="md"),
        ], p="md", withBorder=True, radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),
    ], gap="md")


def _weight_slider(label, value, note):
    return dmc.Group([
        dmc.Text(f"{label}:", fw=500, size="sm", style={"width": "150px"}),
        dmc.Slider(
            value=value,
            min=0,
            max=3,
            step=0.1,
            marks=[{"value": i, "label": str(i)} for i in range(4)],
            style={"flex": 1},
            color="cyan",
        ),
        dmc.Text(note, size="xs", c="dimmed", style={"width": "120px"}),
    ], gap="md", align="center")


# =============================================================================
# TAB C: SYSTEM SETTINGS
# =============================================================================
def _build_system_settings():
    return dmc.Stack([
        # Database Connection
        dmc.Paper([
            dmc.Text("Database Connection", fw=600, mb="md"),
            dmc.Group([
                dmc.Select(
                    label="Type",
                    value="SQLite",
                    data=["SQLite", "PostgreSQL", "MySQL"],
                    size="xs",
                    style={"width": "150px"},
                ),
                dmc.TextInput(
                    label="Path",
                    value="./data/apex_aml.db",
                    size="xs",
                    style={"flex": 1},
                ),
                dmc.Badge("✓ Connected", color="green", variant="filled", size="sm", mt="xl"),
            ], gap="md"),
        ], p="md", withBorder=True, radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),

        # Storage
        dmc.Paper([
            dmc.Text("Storage", fw=600, mb="md"),
            dmc.Stack([
                dmc.Group([
                    dmc.Text("Data Directory:", fw=500, size="sm", style={"width": "150px"}),
                    dmc.TextInput(value="./data/uploads/", size="xs", style={"flex": 1}),
                    dmc.Text("Used: 2.3 GB / 50 GB", size="xs", c="dimmed"),
                ], gap="md"),
                dmc.Group([
                    dmc.Text("Model Cache:", fw=500, size="sm", style={"width": "150px"}),
                    dmc.TextInput(value="./models/", size="xs", style={"flex": 1}),
                    dmc.Text("Used: 450 MB", size="xs", c="dimmed"),
                ], gap="md"),
            ], gap="sm"),
        ], p="md", withBorder=True, radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),

        # Retention Policy
        dmc.Paper([
            dmc.Text("Retention Policy", fw=600, mb="md"),
            dmc.SimpleGrid(cols=2, spacing="md", children=[
                dmc.Select(label="Audit Logs", value="7 years", data=["1 year", "3 years", "5 years", "7 years"], size="xs"),
                dmc.Select(label="Detection Results", value="2 years", data=["1 year", "2 years", "5 years"], size="xs"),
                dmc.Select(label="Uploaded Data", value="90 days", data=["30 days", "60 days", "90 days", "180 days"], size="xs"),
                dmc.Select(label="Temp Files", value="7 days", data=["1 day", "3 days", "7 days", "14 days"], size="xs"),
            ]),
        ], p="md", withBorder=True, radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),

        # Performance
        dmc.Paper([
            dmc.Text("Performance", fw=600, mb="md"),
            dmc.SimpleGrid(cols=2, spacing="md", children=[
                dmc.NumberInput(label="Max Concurrent Users", value=10, min=1, max=100, size="xs"),
                dmc.NumberInput(label="Max Batch Size", value=100000, step=10000, min=1000, max=1000000, size="xs"),
                dmc.NumberInput(label="Detection Timeout (minutes)", value=30, min=5, max=120, size="xs"),
                dmc.NumberInput(label="Memory Limit (GB)", value=8, min=1, max=64, size="xs"),
            ]),
        ], p="md", withBorder=True, radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),
    ], gap="md")


# =============================================================================
# TAB C: SYSTEM HEALTH
# =============================================================================
def _build_system_health():
    jobs_cols = [
        {"field": "job_id", "headerName": "Job ID", "flex": 1},
        {"field": "type", "headerName": "Type", "flex": 1},
        {"field": "status", "headerName": "Status", "flex": 1},
        {"field": "duration", "headerName": "Duration", "flex": 1},
    ]

    return dmc.Stack([
        # System Metrics
        dmc.SimpleGrid(cols=3, spacing="md", children=[
            dmc.Paper([
                dmc.Text("CPU USAGE", fw=600, size="sm", mb="xs"),
                dmc.Progress(value=78, size="xl", color="cyan", radius="xl", mb="xs"),
                dmc.Text("78%", size="xl", fw=700, ta="center"),
            ], p="md", withBorder=True, radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),
            dmc.Paper([
                dmc.Text("MEMORY", fw=600, size="sm", mb="xs"),
                dmc.Progress(value=62, size="xl", color="blue", radius="xl", mb="xs"),
                dmc.Text("62%", size="xl", fw=700, ta="center"),
            ], p="md", withBorder=True, radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),
            dmc.Paper([
                dmc.Text("DISK", fw=600, size="sm", mb="xs"),
                dmc.Progress(value=42, size="xl", color="green", radius="xl", mb="xs"),
                dmc.Text("42%", size="xl", fw=700, ta="center"),
            ], p="md", withBorder=True, radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),
        ]),

        # Recent Jobs
        dmc.Paper([
            dmc.Text("Recent Jobs", fw=600, mb="sm"),
            dag.AgGrid(
                rowData=JOBS_DATA,
                columnDefs=jobs_cols,
                defaultColDef={"sortable": True, "filter": False, "resizable": True},
                dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
                style={"height": None, "width": "100%"},
                className="ag-theme-alpine-dark",
            ),
        ], p="md", withBorder=True, radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),
    ], gap="md")


# =============================================================================
# CALLBACKS - REAL-TIME SYSTEM HEALTH UPDATES
# =============================================================================
@callback(
    [Output("stat-cpu", "children"),
     Output("stat-memory", "children"),
     Output("stat-disk", "children"),
     Output("stat-uptime", "children")],
    Input("interval-health", "n_intervals"),
)
def update_stats(n):
    """Update real-time system health statistics every 5 seconds."""
    try:
        cpu = f"{psutil.cpu_percent():.0f}%"
        mem = f"{psutil.virtual_memory().percent:.0f}%"
        
        # Handle Windows/Unix disk path differences
        import os
        if os.name == 'nt':  # Windows
            disk_path = 'C:\\'
        else:  # Unix/Linux/Mac
            disk_path = '/'
        disk = f"{psutil.disk_usage(disk_path).percent:.0f}%"
        
        boot_time = psutil.boot_time()
        uptime_seconds = time.time() - boot_time
        hours = int(uptime_seconds // 3600)
        uptime = f"{hours}h"
    except Exception as e:
        cpu = "N/A"
        mem = "N/A"
        disk = "N/A"
        uptime = "N/A"
    
    return cpu, mem, disk, uptime
