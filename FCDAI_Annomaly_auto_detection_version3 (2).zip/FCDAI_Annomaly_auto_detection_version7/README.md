# FCDAI Anomaly Auto Detection Tool — Version 7

**FLEXIBLE ARCHITECTURE: Dynamic Customer-Level AML Detection Platform**

## 🚀 Version 7: TRUE FLEXIBILITY

### **4 Core Principles Implemented:**

#### 1. **MASTER TABLE IS THE ONLY MANDATORY INPUT**
- System works with MASTER table alone (requires only `cust_id` + `cust_name`)
- All other columns in MASTER are auto-detected and processed
- Additional tables enhance detection but are NEVER required

#### 2. **UNLIMITED EXTENSIBILITY**
- Add ANY number of tables at customer level - no code changes needed
- Add ANY number of columns/features to any table
- System auto-discovers and processes new data automatically
- **NO hardcoded table names** (removed `TABLE_CONFIG` dictionary)

#### 3. **AUTO-DETECTION OF DATA TYPES**
- Automatically identifies: CONTINUOUS, ORDINAL, BINARY, CATEGORICAL
- Applies appropriate preprocessing based on detected type
- No manual configuration required for data types
- New `SchemaDetector` engine handles all inference

#### 4. **CONFIGURATION TABLES ARE OPTIONAL**
- All 4 config tables may be missing - system still runs
- Intelligent defaults used when config not provided
- METHOD_CONFIG auto-generated based on available data

---

## 📊 V7 vs V6: What Changed?

| Feature | V6 | V7 |
|---------|----|----|
| **Table Config** | 11 hardcoded tables | ANY table name accepted |
| **Mandatory Tables** | None (assumed 11) | Only MASTER required |
| **Column Detection** | Partial aliases | Full auto-detection |
| **File Upload** | Fixed cards (11) | Flexible (MASTER + unlimited) |
| **Extensibility** | Manual code changes | Runtime discovery |
| **Data Types** | Manual/partial | 100% automatic |

---

## 🆕 Version 6 Foundation (Still Included)

### 1. **Customer-Level Processing**
- **Aggregation at Source**: All transactions roll up to customer level BEFORE pipeline execution
- **Entity-Based Detection**: Detection methods run on customer profiles, not individual transactions
- **Comprehensive Features**: 80+ customer-level features including volume, amounts, structuring, temporal, and behavioral patterns

### 2. **Tiered Consensus Ensemble (Layer 6)**
- **Dual-Threshold Logic**: Risk tiers use `(score >= threshold) OR (votes >= threshold)`
- **Percentile Rank Normalization**: Robust 0-1 score normalization
- **Domain-Driven Weights**: Benford=2.0, IF=1.5, LOF=1.5, DeepLearning=0.5-0.8

### 3. **Enhanced Risk Tiers**
| TIER | SCORE ≥ | VOTES ≥ | EXPECTED |
|------|---------|---------|----------|
| CRITICAL | 0.95 | 23/25 | 0.1% |
| HIGH | 0.85 | 18/25 | 1-2% |
| MEDIUM | 0.70 | 12/25 | 5-10% |
| LOW | 0.50 | 8/25 | 10-20% |
| NORMAL | <0.50 | <8/25 | 70-80% |

## 🏗️ Architecture (V7 Enhanced)

```
┌─────────────────────────────────────────────────────────────────┐
│            V7: FLEXIBLE CUSTOMER-LEVEL PIPELINE                 │
├─────────────────────────────────────────────────────────────────┤
│   ┌────────┐  ┌────────┐  ┌────────┐  ┌────────┐               │
│   │ MASTER │  │  ANY   │  │  ANY   │  │  ANY   │  (ANY tables) │
│   │(cust_id│  │ TABLE  │  │ TABLE  │  │ TABLE  │               │
│   │cust_name)│  │  1     │  │  2     │  │  N     │               │
│   └───┬────┘  └───┬────┘  └───┬────┘  └───┬────┘               │
│       └───────────┴───────────┴────────────┘                    │
│                   │                                             │
│       ┌───────────▼───────────┐                                 │
│       │ L1-2: Ingest + DQ     │ (30s)                           │
│       │ 🆕 V7: MASTER Valid   │                                 │
│       └───────────┬───────────┘                                 │
│                   │                                             │
│       ┌───────────▼───────────┐                                 │
│       │ 🆕 V7: SCHEMA DETECT  │ (5s) ← NEW!                     │
│       │ Auto-detect types     │                                 │
│       └───────────┬───────────┘                                 │
│                   │                                             │
│       ┌───────────▼───────────┐                                 │
│       │ V6: CUSTOMER AGG      │ (15s)                           │
│       │ Dynamic: ANY→MASTER   │                                 │
│       └───────────┬───────────┘                                 │
│                   │                                             │
│       ┌───────────▼───────────┐                                 │
│       │ L3: Feature Eng (80+) │ (30s)                           │
│       │ 🆕 Flexible columns    │                                 │
│       └───────────┬───────────┘                                 │
│                   │                                             │
│       ┌───────────▼───────────┐                                 │
│       │ L4: Preprocessing     │ (10s)                           │
│       └───────────┬───────────┘                                 │
│                   │                                             │
│       ┌───────────▼───────────┐                                 │
│       │ L5: 25 Methods        │ (2m 30s)                        │
│       └───────────┬───────────┘                                 │
│                   │                                             │
│       ┌───────────▼───────────┐                                 │
│       │ 🆕 L6: Tiered         │ (5s) ← Enhanced!                │
│       │    Consensus          │                                 │
│       └───────────┬───────────┘                                 │
│                   │                                             │
│       ┌───────────▼───────────┐                                 │
│       │ L7: Output            │ (10s)                           │
│       └───────────┬───────────┘                                 │
│                   │                                             │
│          Investigation Queue                                    │
└─────────────────────────────────────────────────────────────────┘
TOTAL: ~4 minutes (500 customers) to ~6 minutes (5,000 customers)
```

## 🚀 Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run V6 application (Port: 8098)
python app.py
```

Open: **http://127.0.0.1:8098**

## 🎯 Customer Aggregation Features (V6)

**Volume Metrics**
- `txn_count`: Total transactions
- `txn_frequency`: Transactions per day

**Amount Aggregations**
- `amount_total`, `amount_mean`, `amount_median`, `amount_std`
- `amount_cv`: Coefficient of variation
- `amount_gini`: Concentration index

**Structuring Detection**
- `count_just_below_10k`: Transactions $9,000-$9,999
- `pct_just_below_10k`: Structuring percentage

**Temporal Patterns**
- `night_txn_pct`: After-hours (10 PM - 6 AM)
- `weekend_txn_pct`: Weekend activity
- `account_age_days`: Customer tenure

**Behavioral Indicators**
- `amount_entropy`: Transaction diversity
- `amount_skew`, `amount_kurtosis`: Distribution shape

## 📊 Detection Methods (25 Total)

| Category | Count | Methods |
|----------|-------|---------|
| Statistical | 5 | Z-Score, MAD, Benford, Grubbs, Dixon |
| Distance | 3 | KNN, Mahalanobis, LOF |
| Density | 4 | DBSCAN, OPTICS, HDBSCAN, CBLOF |
| Clustering | 3 | K-Means, GMM, Spectral |
| Trees | 2 | IsolationForest, ExtendedIF |
| Time-Series | 3 | STL, Change Point, Prophet |
| Graph | 4 | PageRank, HITS, Community, Centrality |
| Deep Learning | 2 | Autoencoder, VAE |

## 🆚 V5 vs V6 Comparison

| Feature | V5 | V6 |
|---------|----|----|
| **Processing Level** | Transaction | **Customer** ✨ |
| **Aggregation** | Within features | **Pre-pipeline** ✨ |
| **Ensemble** | Concordance | **Tiered Consensus** ✨ |
| **Risk Logic** | Score-only | **Score OR Votes** ✨ |
| **Normalization** | Min-max | **Percentile Rank** ✨ |
| **Weights** | Auto | **Domain-driven** ✨ |
| **Features** | 50+ | **80+** ✨ |
| **Port** | 8097 | **8098** |

## 🔧 Configuration

Edit [`config.py`](config.py):

```python
# Enable customer-level processing
APP.CUSTOMER_LEVEL_PROCESSING = True

# Use tiered consensus
LAYERS.ENSEMBLE_METHOD = "tiered_consensus"

# Risk tier thresholds (score OR votes)
LAYERS.RISK_TIERS = {
    "CRITICAL": {"score_min": 0.95, "vote_min": 23},
    "HIGH":     {"score_min": 0.85, "vote_min": 18},
    # ...
}

# Domain-driven weights
LAYERS.METHOD_WEIGHTS = {
    "benford": 2.0,  # High for structuring
    "isolation_forest": 1.5,
    "lof": 1.5,
    # ...
}
```

## 📄 Pages

1. **Command Center** - Executive dashboard with customer-level KPIs
2. **Data Sources** - Multi-source import and validation
3. **Pipeline Run** - Execute 7-layer customer-level pipeline
4. **Investigation Queue** - Tiered alert triage (CRITICAL → LOW)
5. **Narratives** - Customer profile explanations
6. **Audit Trail** - Complete decision logging
7. **System Health** - Performance monitoring

## 📁 Project Structure

```
version6/
├── app.py                       # Dash application
├── config.py                    # V6 configuration
├── pipeline.py                  # 7-layer + customer aggregation
├── layers/
│   ├── l1_l2_ingestion.py
│   ├── l3_feature_engineering.py
│   ├── l4_preprocessing.py
│   ├── l5_detection.py
│   ├── l6_ensemble.py          # 🆕 Tiered Consensus
│   └── l7_output.py
├── utils/
│   └── customer_aggregation.py # 🆕 Customer Aggregator
├── pages/                       # Dash multi-page app
├── data/                        # Data vault
└── requirements.txt
```

## 📝 Version History

- **V6.0** (Current) - Customer-level processing, tiered consensus
- **V5.0** - 7-layer architecture, concordance-based weighting
- **V4.0** - Multi-source integration
- **V3.0** - 26 detection methods
- **V2.0** - Feature engineering
- **V1.0** - Initial release

## 🎓 References

- **Guidelines**: COMPREHENSIVE_BANK_PIPELINES_LANDSCAPE.md (Layer 6 spec)
- **Architecture**: 7-layer framework for AML detection
- **Ensemble**: Tiered consensus for balanced detection

## 🔒 Air-Gapped Mode

Runs completely offline after installation. No external dependencies.

---

**Version 6.0** | FCDAI Team | February 2026
