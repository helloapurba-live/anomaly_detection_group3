"""
Dashboard Page
==============
Executive KPI dashboard combining 7-layer system status with 
Vanguard's operational analytics (Alerts, Trends, Performance).
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from datetime import datetime
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP, LAYERS

dash.register_page(__name__, path="/", name="Dashboard", order=0)


# =============================================================================
# KPI CARD COMPONENT
# =============================================================================
def create_kpi_card(
    title: str, 
    value: str, 
    subtitle: str = "", 
    icon: str = "mdi:chart-line",
    color: str = THEME.PRIMARY,
    trend: str = None
) -> dmc.Paper:
    """Create a styled KPI card."""
    trend_icon = None
    if trend:
        if trend.startswith("+"):
            trend_icon = DashIconify(icon="mdi:trending-up", color=THEME.SUCCESS, width=16)
        elif trend.startswith("-"):
            trend_icon = DashIconify(icon="mdi:trending-down", color=THEME.DANGER, width=16)
    
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.ThemeIcon(
                        DashIconify(icon=icon, width=24),
                        size="xl",
                        radius="md",
                        variant="light",
                        color=color.replace("#", ""),
                    ),
                    dmc.Stack(
                        [
                            dmc.Text(title, size="sm", c="dimmed"),
                            dmc.Group(
                                [
                                    dmc.Text(value, size="xl", fw=700),
                                    dmc.Group([trend_icon, dmc.Text(trend, size="xs", c="dimmed")]) if trend else None,
                                ],
                                gap="xs",
                            ),
                            dmc.Text(subtitle, size="xs", c="dimmed") if subtitle else None,
                        ],
                        gap=2,
                    ),
                ],
                gap="md",
            ),
        ],
        p="md",
        radius="md",
        withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD}
    )


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Container(
    [
        # Header
        dmc.Group(
            [
                dmc.Title("Dashboard V4.0 (Dev)", order=2),
                dmc.Badge("FCDAI 7-Layer System", color="cyan", variant="light"),
            ],
            justify="space-between",
            mb="lg",
        ),

        # 0. DATA CONTROLS (V4 New Feature)
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Text("Data Management Controls", fw=600, c="dimmed"),
                        dmc.Group(
                            [
                                dmc.Select(
                                    id="data-gen-size",
                                    data=[
                                        {"label": "Small (500 Txns)", "value": "small"},
                                        {"label": "Medium (2k Txns)", "value": "medium"},
                                        {"label": "Large (10k Txns)", "value": "large"},
                                    ],
                                    value="small",
                                    style={"width": 150},
                                    size="sm"
                                ),
                                dmc.Button(
                                    "Generate Sample Data",
                                    id="btn-generate",
                                    color="blue",
                                    size="sm"
                                ),
                                dmc.Button(
                                    "Reset / Clear All",
                                    id="btn-reset",
                                    color="red",
                                    variant="outline",
                                    size="sm"
                                ),
                            ],
                            gap="sm"
                        )
                    ],
                    justify="space-between"
                ),
                html.Div(id="data-control-output", style={"display": "none"}), # Hidden output for callbacks
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
            mb="lg"
        ),
        
        # 1. TOP ROW: System Stats
        html.Div(id="kpi-row-system"),
        
        dmc.Space(h="lg"),
        
        # 2. MIDDLE ROW: System Pipeline Status (Visual Grid)
        dmc.Paper(
            [
                dmc.Text("System Pipeline Status", fw=600, mb="md"),
                dmc.SimpleGrid(
                    cols={"base": 2, "md": 4, "lg": 6},
                    spacing="md",
                    children=[
                        dmc.Paper(
                            [
                                dmc.Text("L1-2", fw=600, ta="center"),
                                dmc.Text("Ingest + DQ", size="xs", c="dimmed", ta="center"),
                                dmc.Center(
                                    dmc.ThemeIcon(
                                        DashIconify(icon="mdi:check-circle", width=20),
                                        color="green",
                                        variant="light",
                                        mt="xs",
                                    )
                                ),
                            ],
                            p="sm",
                            radius="md",
                            style={"backgroundColor": "rgba(0,100,0,0.1)"}
                        ),
                        dmc.Paper(
                            [
                                dmc.Text("L3", fw=600, ta="center"),
                                dmc.Text("Features", size="xs", c="dimmed", ta="center"),
                                dmc.Center(
                                    dmc.ThemeIcon(
                                        DashIconify(icon="mdi:clock-outline", width=20),
                                        color="gray",
                                        variant="light",
                                        mt="xs",
                                    )
                                ),
                            ],
                            p="sm",
                            radius="md",
                            style={"backgroundColor": "rgba(100,100,100,0.1)"}
                        ),
                        dmc.Paper(
                            [
                                dmc.Text("L4", fw=600, ta="center"),
                                dmc.Text("Preproc", size="xs", c="dimmed", ta="center"),
                                dmc.Center(
                                    dmc.ThemeIcon(
                                        DashIconify(icon="mdi:clock-outline", width=20),
                                        color="gray",
                                        variant="light",
                                        mt="xs",
                                    )
                                ),
                            ],
                            p="sm",
                            radius="md",
                            style={"backgroundColor": "rgba(100,100,100,0.1)"}
                        ),
                        dmc.Paper(
                            [
                                dmc.Text("L5", fw=600, ta="center"),
                                dmc.Text("Detect", size="xs", c="dimmed", ta="center"),
                                dmc.Center(
                                    dmc.ThemeIcon(
                                        DashIconify(icon="mdi:clock-outline", width=20),
                                        color="gray",
                                        variant="light",
                                        mt="xs",
                                    )
                                ),
                            ],
                            p="sm",
                            radius="md",
                            style={"backgroundColor": "rgba(100,100,100,0.1)"}
                        ),
                        dmc.Paper(
                            [
                                dmc.Text("L6", fw=600, ta="center"),
                                dmc.Text("Ensemble", size="xs", c="dimmed", ta="center"),
                                dmc.Center(
                                    dmc.ThemeIcon(
                                        DashIconify(icon="mdi:clock-outline", width=20),
                                        color="gray",
                                        variant="light",
                                        mt="xs",
                                    )
                                ),
                            ],
                            p="sm",
                            radius="md",
                            style={"backgroundColor": "rgba(100,100,100,0.1)"}
                        ),
                        dmc.Paper(
                            [
                                dmc.Text("L7", fw=600, ta="center"),
                                dmc.Text("Output", size="xs", c="dimmed", ta="center"),
                                dmc.Center(
                                    dmc.ThemeIcon(
                                        DashIconify(icon="mdi:clock-outline", width=20),
                                        color="gray",
                                        variant="light",
                                        mt="xs",
                                    )
                                ),
                            ],
                            p="sm",
                            radius="md",
                            style={"backgroundColor": "rgba(100,100,100,0.1)"}
                        ),
                    ]
                ),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
            mb="lg"
        ),

        # 3. Layer Execution Status (Detailed Metrics)
        html.Div(id="layer-execution-status"),
        
        dmc.Space(h="lg"),

        # 4. BOTTOM ROW: Detection Methods Chart (Full Width)
        dmc.Paper(
            [
                dmc.Text("Detection Methods by Category", fw=600, mb="sm"),
                dcc.Graph(
                    id="chart-methods-cat",
                    config=APP.PLOTLY_CONFIG,
                    style={"height": "350px"},
                ),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),

        dmc.Space(h="lg"),
        
        # 5. Supplementary Vanguard Charts (Risk Dist, Trends, Heatmap, Algo Perf)
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2},
            spacing="lg",
            children=[
                dmc.Paper(
                    [
                        dmc.Text("Risk Tier Distribution", fw=600, mb="sm"),
                        dcc.Graph(
                            id="chart-risk-dist",
                            config=APP.PLOTLY_CONFIG,
                            style={"height": "300px"},
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                 dmc.Paper(
                    [
                        dmc.Text("Algorithm Detection Rate", fw=600, mb="sm"),
                        dcc.Graph(
                            id="chart-algo-perf",
                            config=APP.PLOTLY_CONFIG,
                            style={"height": "300px"},
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Text("Alert Volume Trend", fw=600, mb="sm"),
                        dcc.Graph(
                            id="chart-alert-trend",
                            config=APP.PLOTLY_CONFIG,
                            style={"height": "300px"},
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Text("Risk Heatmap", fw=600, mb="sm"),
                        dcc.Graph(
                            id="chart-heatmap",
                            config=APP.PLOTLY_CONFIG,
                            style={"height": "300px"},
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
            ],
        ),
        
        # Refresh interval
        dcc.Interval(id="dashboard-refresh", interval=30000, n_intervals=0),
    ],
    fluid=True,
)


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    [Output("kpi-row-system", "children"),
     Output("layer-execution-status", "children")],
    Input("dashboard-refresh", "n_intervals"),
)
def update_system_stats(n):
    """Update top-level system stats and execution details."""
    try:
        from utils.data_io import data_vault
        from config import LAYERS
        
        df = data_vault.get_scored_data()
        
        # Queue count (High Risk items)
        queue_count = 0
        total_records = 0
        active_methods = 0
        timestamp = "N/A"
        
        if df is not None:
             total_records = len(df)
             if 'anomaly_score' in df.columns:
                queue_count = int((df['anomaly_score'] > 0.8).sum())
             
             # Estimate active methods from columns
             score_cols = [c for c in df.columns if c.startswith('score_')]
             active_methods = len(score_cols)
             
             # Get timestamp if available (mock/derived)
             timestamp = datetime.now().strftime("%H:%M:%S")

        # Top Row KPIs
        kpi_row = dmc.SimpleGrid(
            cols={"base": 2, "md": 4},
            spacing="lg",
            children=[
                create_kpi_card("Layers", "7", "Pipeline Depth", "mdi:layers-triple", THEME.PRIMARY),
                create_kpi_card("Methods", str(len([m for methods in LAYERS.DETECTION_METHODS.values() for m in methods])), "Active Algorithms", "mdi:function", THEME.SECONDARY),
                create_kpi_card("Categories", str(len(LAYERS.DETECTION_METHODS)), "Method Types", "mdi:shape", "#FFC107"),
                create_kpi_card("Queue", str(queue_count), "High Risk Items", "mdi:tray-alert", THEME.DANGER),
            ],
        )
        
        # Layer Execution Status (Detailed)
        exec_status = dmc.Paper(
            [
                dmc.Text("Layer Execution Status", fw=600, mb="md"),
                dmc.SimpleGrid(
                    cols=4,
                    children=[
                        dmc.Stack([
                            dmc.Text("Last Execution", size="xs", c="dimmed"),
                            dmc.Text(timestamp, fw=500),
                        ], gap=0),
                        dmc.Stack([
                            dmc.Text("Records Processed", size="xs", c="dimmed"),
                            dmc.Text(f"{total_records:,}", fw=500),
                        ], gap=0),
                         dmc.Stack([
                            dmc.Text("Active Methods", size="xs", c="dimmed"),
                            dmc.Text(str(active_methods) if active_methods > 0 else "Pending", fw=500),
                        ], gap=0),
                        dmc.Stack([
                            dmc.Text("System State", size="xs", c="dimmed"),
                            dmc.Badge("Live" if df is not None else "Idle", color="green" if df is not None else "gray"),
                        ], gap=0),
                    ]
                )
            ],
             p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        )
        
        return kpi_row, exec_status
        
    except Exception as e:
        return dmc.Alert(f"KPI Error: {str(e)}", color="red"), html.Div()


@callback(
    Output("chart-methods-cat", "figure"),
    Input("dashboard-refresh", "n_intervals"),
)
def update_methods_chart(n):
    """Update detection methods chart from config."""
    try:
        from config import LAYERS
        
        categories = []
        counts = []
        
        for cat, methods in LAYERS.DETECTION_METHODS.items():
            categories.append(cat.replace("_", " ").title())
            counts.append(len(methods))
            
        fig = px.bar(
            x=categories,
            y=counts,
            template="plotly_dark",
            color=categories,
            color_discrete_sequence=px.colors.qualitative.Set2
        )
        
        fig.update_layout(
            margin=dict(l=20, r=20, t=20, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            showlegend=False,
            xaxis_title=None,
            yaxis_title="Count",
            xaxis_tickangle=-45,
        )
        return fig
    except Exception: return go.Figure()


@callback(
    Output("chart-risk-dist", "figure"),
    Input("dashboard-refresh", "n_intervals"),
)
def update_risk_dist(n):
    try:
        from utils.data_io import data_vault
        df = data_vault.get_scored_data()
        if df is None or 'risk_tier' not in df.columns: return go.Figure()
        
        counts = df['risk_tier'].value_counts()
        
        color_map = {
            'Critical': THEME.DANGER,
            'High': '#FF9800', 
            'Medium': THEME.WARNING,
            'Low': THEME.SUCCESS
        }
        
        fig = px.pie(
            values=counts.values, 
            names=counts.index, 
            color=counts.index,
            color_discrete_map=color_map,
            hole=0.4,
            template="plotly_dark"
        )
        fig.update_layout(
            margin=dict(l=20, r=20, t=20, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            legend=dict(orientation="h", y=-0.1)
        )
        return fig
    except Exception: return go.Figure()


@callback(
    Output("chart-alert-trend", "figure"),
    Input("dashboard-refresh", "n_intervals"),
)
def update_trend_chart(n):
    try:
        from utils.data_io import data_vault
        df = data_vault.get_scored_data()
        if df is None or 'anomaly_score' not in df.columns: return go.Figure()
        
        # Mock trend if no dates
        dates = pd.date_range(end=datetime.now(), periods=30, freq='D')
        counts = np.random.randint(5, 50, size=30) 
        
        if 'timestamp' in df.columns:
            df['date'] = pd.to_datetime(df['timestamp']).dt.date
            daily_counts = df[df['anomaly_score'] > 0.5].groupby('date').size()
            if len(daily_counts) > 1:
                dates = daily_counts.index
                counts = daily_counts.values

        fig = px.area(x=dates, y=counts, template="plotly_dark")
        fig.update_traces(line_color=THEME.PRIMARY, fillcolor="rgba(0, 212, 255, 0.2)")
        fig.update_layout(
            margin=dict(l=20, r=20, t=20, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            xaxis_title=None,
            yaxis_title="Alerts"
        )
        return fig
    except Exception: return go.Figure()


@callback(
    Output("chart-heatmap", "figure"),
    Input("dashboard-refresh", "n_intervals"),
)
def update_heatmap(n):
    try:
        # Mock Heatmap for Visuals 
        hours = list(range(24))
        days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        z = np.random.rand(7, 24)
        
        fig = go.Figure(data=go.Heatmap(
            z=z, x=hours, y=days,
            colorscale=[[0, THEME.SUCCESS], [0.5, THEME.WARNING], [1, THEME.DANGER]]
        ))
        fig.update_layout(
            margin=dict(l=20, r=20, t=20, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            template="plotly_dark",
            xaxis_title="Hour of Day"
        )
        return fig
    except Exception: return go.Figure()

@callback(
    Output("chart-algo-perf", "figure"),
    Input("dashboard-refresh", "n_intervals"),
)
def update_algo_perf(n):
    try:
        from utils.data_io import data_vault
        df = data_vault.get_scored_data()
        if df is None: return go.Figure()
        
        score_cols = [c for c in df.columns if c.startswith('score_')]
        if not score_cols: return go.Figure()
        
        rates = []
        for col in score_cols:
            rate = (df[col] > 0.5).mean() * 100
            rates.append({'Algo': col.replace('score_', ''), 'Rate': rate})
            
        rate_df = pd.DataFrame(rates).sort_values('Rate')
        
        fig = px.bar(rate_df, x='Rate', y='Algo', orientation='h', template="plotly_dark")
        fig.update_traces(marker_color=THEME.SECONDARY)
        fig.update_layout(
            margin=dict(l=20, r=20, t=20, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            xaxis_title="Detection Rate (%)",
            yaxis_title=None
        )
        return fig
    except Exception: return go.Figure()


# =============================================================================
# DATA CONTROL CALLBACKS (V4)
# =============================================================================
@callback(
    Output("data-control-output", "children"),
    Input("btn-generate", "n_clicks"),
    Input("btn-reset", "n_clicks"),
    [dash.State("data-gen-size", "value")],
    prevent_initial_call=True
)
def handle_data_controls(n_gen, n_reset, size):
    """Handle generation and reset actions."""
    from dash import ctx
    from utils.data_gen import DataGenerator
    from utils.data_io import data_vault
    from utils.logger import logger
    
    triggered_id = ctx.triggered_id
    
    if triggered_id == "btn-reset":
        data_vault.clear_data()
        logger.log_action("Data Reset Initiated from Dashboard")
        return "Data Cleared"
        
    if triggered_id == "btn-generate":
        try:
            # 1. Generate 5-Table Schema
            dg = DataGenerator()
            data_map = dg.generate_full_schema(size)
            
            # 2. Merge for Analytical View (V3 Compatibility)
            # Join Transactions -> Account -> Party
            df_tx = data_map['transactions']
            df_acc = data_map['account']
            df_party = data_map['party']
            
            # Left Join: Tx -> Account
            df_merged = df_tx.merge(df_acc, on='account_id', how='left')
            
            # Left Join: -> Party
            df_merged = df_merged.merge(df_party, on='party_id', how='left')
            
            # 3. Import to DataVault
            data_vault.import_data(
                contents="", # Bypass content parse
                filename=f"generated_v4_{size}.parquet"
            )
            # Direct override since import_data expects base64 usually
            data_vault._current_data = df_merged
            data_vault._metadata = {
                "filename": f"generated_{size}_tables_v4",
                "rows": len(df_merged),
                "columns": len(df_merged.columns),
                "import_time": datetime.now().isoformat(),
                "schema": "5-table-merged"
            }
            data_vault._persist_data()
            
            logger.log_action(f"Generated {size} dataset with {len(df_merged)} rows")
            return f"Generated {len(df_merged)} rows"
            
        except Exception as e:
            logger.log_error(e, "Dashboard Data Generation")
            return "Error Generating Data"
            
    return dash.no_update
