"""
FCDAI Version 8 — Main Application
=====================================
Statistically rigorous, scalable, production-hardened.
Air-gapped Dash Mantine Components UI for the 7-layer pipeline.

V8 Enhancements:
- Role-based column resolution (zero hardcoded column names)
- SchemaDetector + AutoParams wired into pipeline
- Cross-page data sync (vault reload)
- PII masking at storage and export levels
- Hash-chain tamper-evident audit logging
- Run versioning with data lineage

Author: Project Vanguard Team
"""

import dash
from dash import html, dcc, page_registry, page_container, callback, Input, Output, State, clientside_callback
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import diskcache
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent))

from config import APP, THEME, PATHS


# =============================================================================
# DASH APPLICATION INITIALIZATION
# =============================================================================
app = dash.Dash(
    __name__,
    use_pages=True,
    pages_folder='pages',
    suppress_callback_exceptions=True,
    assets_folder='assets',
    serve_locally=True,  # Air-gapped mode
    title=APP.TITLE,
    update_title=None,
)


# =============================================================================
# THEME DEFINITIONS
# =============================================================================
THEMES = {
    "system": {
        "label": "System Default",
        "icon": "mdi:monitor",
        "primaryColor": "cyan",
        "colorScheme": "dark",
        "bgColor": "#0D1117",
        "cardBg": "#16213e",
        "borderColor": "#30363D",
        "accentGradient": {"from": "cyan", "to": "indigo"},
    },
    "midnight": {
        "label": "Midnight Blue",
        "icon": "mdi:moon-waxing-crescent",
        "primaryColor": "indigo",
        "colorScheme": "dark",
        "bgColor": "#0a0a1a",
        "cardBg": "#1a1a3e",
        "borderColor": "#2a2a5e",
        "accentGradient": {"from": "indigo", "to": "violet"},
    },
    "emerald": {
        "label": "Emerald Dark",
        "icon": "mdi:leaf",
        "primaryColor": "teal",
        "colorScheme": "dark",
        "bgColor": "#0a1210",
        "cardBg": "#0f231e",
        "borderColor": "#1a3d32",
        "accentGradient": {"from": "teal", "to": "green"},
    },
    "rose": {
        "label": "Rose Gold",
        "icon": "mdi:flower-tulip",
        "primaryColor": "pink",
        "colorScheme": "dark",
        "bgColor": "#130a10",
        "cardBg": "#231520",
        "borderColor": "#3d1a32",
        "accentGradient": {"from": "pink", "to": "grape"},
    },
    "sunset": {
        "label": "Sunset Amber",
        "icon": "mdi:weather-sunset",
        "primaryColor": "orange",
        "colorScheme": "dark",
        "bgColor": "#131008",
        "cardBg": "#231d10",
        "borderColor": "#3d2d1a",
        "accentGradient": {"from": "orange", "to": "yellow"},
    },
    "arctic": {
        "label": "Arctic Light",
        "icon": "mdi:snowflake",
        "primaryColor": "blue",
        "colorScheme": "light",
        "bgColor": "#f0f4f8",
        "cardBg": "#ffffff",
        "borderColor": "#d0d7de",
        "accentGradient": {"from": "blue", "to": "cyan"},
    },
    "ocean": {
        "label": "Ocean Deep",
        "icon": "mdi:waves",
        "primaryColor": "cyan",
        "colorScheme": "dark",
        "bgColor": "#071318",
        "cardBg": "#0c2530",
        "borderColor": "#163848",
        "accentGradient": {"from": "cyan", "to": "teal"},
    },
    "lavender": {
        "label": "Lavender Mist",
        "icon": "mdi:flower",
        "primaryColor": "violet",
        "colorScheme": "light",
        "bgColor": "#f3f0f8",
        "cardBg": "#faf8ff",
        "borderColor": "#d4c8e8",
        "accentGradient": {"from": "violet", "to": "grape"},
    },
    "crimson": {
        "label": "Crimson Night",
        "icon": "mdi:fire",
        "primaryColor": "red",
        "colorScheme": "dark",
        "bgColor": "#130808",
        "cardBg": "#231010",
        "borderColor": "#3d1a1a",
        "accentGradient": {"from": "red", "to": "orange"},
    },
    "forest": {
        "label": "Forest Shadow",
        "icon": "mdi:pine-tree",
        "primaryColor": "green",
        "colorScheme": "dark",
        "bgColor": "#080f08",
        "cardBg": "#101e10",
        "borderColor": "#1a3d1a",
        "accentGradient": {"from": "green", "to": "lime"},
    },
}


# =============================================================================
# NAVIGATION LINK COMPONENT
# =============================================================================
def create_nav_link(icon: str, label: str, href: str) -> dmc.NavLink:
    """Create a styled navigation link."""
    return dmc.NavLink(
        label=label,
        href=href,
        leftSection=DashIconify(icon=icon, width=20),
        active="exact",
        style={"borderRadius": "6px", "marginBottom": "4px"},
    )


# =============================================================================
# THEME SELECTOR COMPONENT
# =============================================================================
def build_theme_selector():
    """Build the theme selector dropdown for the sidebar."""
    theme_data = [{"value": k, "label": t["label"]} for k, t in THEMES.items()]

    return dmc.Paper(
        [
            dmc.Text("THEME", size="xs", c="dimmed", fw=500, mb="xs"),
            dmc.Select(
                id="theme-selector",
                data=theme_data,
                value="system",
                placeholder="Select theme…",
                searchable=False,
                clearable=False,
                size="xs",
            ),
        ],
        p="sm", mx="sm", radius="md",
        style={"backgroundColor": "rgba(0,0,0,0.2)"},
    )


# =============================================================================
# SIDEBAR LAYOUT
# =============================================================================
sidebar = dmc.Paper(
    [
        # Logo
        dmc.Group(
            [
                dmc.ThemeIcon(
                    DashIconify(icon="mdi:shield-lock", width=28),
                    size="xl",
                    radius="md",
                    variant="gradient",
                    gradient={"from": "cyan", "to": "indigo"},
                    id="sidebar-logo-icon",
                ),
                dmc.Stack(
                    [
                        dmc.Text("FCDAI", size="lg", fw=700),
                        dmc.Text("Anomaly Auto Detection", size="xs", c="dimmed"),
                    ],
                    gap=0,
                ),
            ],
            gap="sm",
            px="md",
            py="lg",
        ),

        dmc.Divider(id="sidebar-divider"),

        # Navigation - Pipeline Layers
        dmc.Stack(
            [
                dmc.Text("WORKFLOW", size="xs", c="dimmed", fw=500, px="md", pt="md"),
                create_nav_link("mdi:view-dashboard", "Dashboard", "/"),
                create_nav_link("mdi:database-import", "Data Sources", "/sources"),
                create_nav_link("mdi:rocket-launch", "Execution Engine", "/pipeline"),
                create_nav_link("mdi:layers-triple", "Layer View", "/layers"),
            ],
            gap=2,
            px="sm",
        ),

        # Navigation - Results
        dmc.Stack(
            [
                dmc.Text("RESULTS", size="xs", c="dimmed", fw=500, px="md", pt="md"),
                create_nav_link("mdi:alert-circle", "Investigation Queue", "/queue"),
                create_nav_link("mdi:file-document", "Narratives", "/narratives"),
                create_nav_link("mdi:history", "Audit Trail", "/audit"),
            ],
            gap=2,
            px="sm",
        ),

        # Navigation - Advanced Analytics
        dmc.Stack(
            [
                dmc.Text("ADVANCED ANALYTICS", size="xs", c="dimmed", fw=500, px="md", pt="md"),
                create_nav_link("mdi:table-search", "Audit Vault (AG Grid)", "/audit-vault"),
                create_nav_link("mdi:chart-sankey", "Model Diagnostics", "/diagnostics"),
                create_nav_link("mdi:brain", "Explainability", "/explainability"),
            ],
            gap=2,
            px="sm",
        ),

        # Navigation - Admin
        dmc.Stack(
            [
                dmc.Text("ADMIN", size="xs", c="dimmed", fw=500, px="md", pt="md"),
                create_nav_link("mdi:shield-account", "Admin Panel", "/admin"),
            ],
            gap=2,
            px="sm",
        ),

        # Spacer to push theme to bottom
        html.Div(style={"flex": "1"}),

        # Theme Selector (bottom of sidebar)
        build_theme_selector(),

        dmc.Space(h="sm"),
    ],
    id="sidebar",
    style={
        "width": "260px",
        "height": "100vh",
        "position": "fixed",
        "top": 0,
        "left": 0,
        "backgroundColor": THEME.DARK_BG_CARD,
        "borderRight": f"1px solid {THEME.DARK_BORDER}",
        "overflowY": "auto",
        "display": "flex",
        "flexDirection": "column",
    },
    radius=0,
)


# =============================================================================
# MAIN LAYOUT
# =============================================================================
app.layout = dmc.MantineProvider(
    [
        dmc.NotificationProvider(position="top-right"),
        html.Div(id="notification-container"),

        # Stores for state management
        dcc.Store(id="store-privacy-mode", data=True, storage_type="local"),
        dcc.Store(id="store-theme", data="system", storage_type="local"),
        dcc.Store(id="store-pipeline-complete", data=None, storage_type="memory"),  # Timestamp when pipeline completes

        # CSS variables injector for theme
        html.Div(id="theme-css-injector"),

        dmc.Box(
            [
                sidebar,
                dmc.Box(
                    [
                        page_container
                    ],
                    id="page-content",
                    style={
                        "marginLeft": "260px",
                        "padding": "24px 32px",
                        "minHeight": "100vh",
                        "backgroundColor": THEME.DARK_BG,
                    }
                ),
            ],
            id="app-container",
        ),
    ],
    id="mantine-provider",
    forceColorScheme="dark",
    theme=THEME.get_mantine_theme(),
)


# =============================================================================
# THEME SWITCHER CALLBACK
# =============================================================================
@callback(
    Output("mantine-provider", "forceColorScheme"),
    Output("mantine-provider", "theme"),
    Output("page-content", "style"),
    Output("sidebar", "style"),
    Output("sidebar-divider", "color"),
    Output("sidebar-logo-icon", "gradient"),
    Output("theme-css-injector", "children"),
    Output("store-theme", "data"),
    Input("theme-selector", "value"),
    State("store-theme", "data"),
)
def switch_theme(selected, stored_theme):
    """Apply the selected theme across the entire application."""
    theme_key = selected or stored_theme or "system"
    t = THEMES.get(theme_key, THEMES["system"])

    # Build Mantine theme dict
    mantine_theme = THEME.get_mantine_theme()
    mantine_theme["primaryColor"] = t["primaryColor"]

    color_scheme = t["colorScheme"]

    # Dynamic styles
    page_style = {
        "marginLeft": "260px",
        "padding": "24px 32px",
        "minHeight": "100vh",
        "backgroundColor": t["bgColor"],
        "color": "#c9d1d9" if color_scheme == "dark" else "#1f2328",
    }

    sidebar_style = {
        "width": "260px",
        "height": "100vh",
        "position": "fixed",
        "top": 0,
        "left": 0,
        "backgroundColor": t["cardBg"],
        "borderRight": f"1px solid {t['borderColor']}",
        "overflowY": "auto",
        "display": "flex",
        "flexDirection": "column",
    }

    # Inject global CSS overrides for cards and papers
    css_content = f"""
<style>
    .mantine-Paper-root {{
        background-color: {t["cardBg"]} !important;
        border-color: {t["borderColor"]} !important;
    }}
    .ag-theme-alpine-dark {{
        --ag-background-color: {t["cardBg"]};
        --ag-header-background-color: {t["bgColor"]};
        --ag-odd-row-background-color: {t["bgColor"]};
        --ag-border-color: {t["borderColor"]};
    }}
    /* For light theme */
    {''.join([f'''
    .ag-theme-alpine-dark .ag-header-cell-text,
    .ag-theme-alpine-dark .ag-cell {{
        color: #1f2328 !important;
    }}
    .mantine-Text-root {{ color: #1f2328; }}
    .mantine-Title-root {{ color: #1f2328; }}
    ''' if color_scheme == "light" else ''])}
</style>
"""
    css_overrides = dcc.Markdown(css_content, dangerously_allow_html=True)

    return color_scheme, mantine_theme, page_style, sidebar_style, t["borderColor"], t["accentGradient"], css_overrides, theme_key


# =============================================================================
# SERVER
# =============================================================================
server = app.server


if __name__ == "__main__":
    try:
        print("""
===========================================================
  FCDAI ANOMALY AUTO DETECTION -- VERSION 8                
  Role-Based Architecture (Zero Hardcoded Column Names)    
===========================================================
  AIR-GAPPED MODE: No external connections                 
  MASTER Required | ANY Additional Tables Accepted        
  Auto-Detection: 8 Column Types | Unlimited Tables       
  V8: SchemaDetector + AutoParams + Data Lineage          
  Running at: http://{host}:{port}                         
                                                           
  Press Ctrl+C to stop the server                         
===========================================================
""".format(host=APP.HOST, port=APP.PORT))
    except UnicodeEncodeError:
        print("=" * 60)
        print("  FCDAI ANOMALY AUTO DETECTION - VERSION 8 (Role-Based)")
        print("  Zero Hardcoded Column Names Architecture")
        print("=" * 60)
        print(f"  Running at: http://{APP.HOST}:{APP.PORT}")
        print("  Press Ctrl+C to stop the server")
        print("=" * 60)
    
    app.run(debug=APP.DEBUG, host=APP.HOST, port=APP.PORT)
