"""
Project Vanguard 7-Layer Edition — V8 Pipeline
===============================================
Orchestrates all 7 layers for end-to-end AML detection.

V8 Enhancements:
  - Role-based column resolution (zero hardcoded column names)
  - SchemaDetector wired before L4 (type-aware preprocessing)
  - AutoParamGenerator wired before L5 (data-driven parameters)
  - Per-method checkpointing (partial results saved)
  - Data lineage hashing + run versioning
  - Configurable ensemble flag threshold

Author: Project Vanguard Team
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
from dataclasses import dataclass, field
from datetime import datetime
import json
import time
import hashlib
import sys

sys.path.insert(0, str(Path(__file__).parent))

from config import PATHS, LAYERS, APP, RESOURCES, AUDIT, COLUMNS
from layers.l1_l2_ingestion import IngestPipeline, DataQualityReport
from layers.l3_feature_engineering import Layer3FeatureEngineering
from layers.l4_preprocessing import Layer4Preprocessing
from layers.l5_detection import Layer5Detection
from layers.l6_ensemble import Layer6Ensemble, EnsembleResult
from layers.l7_output import Layer7Output
from utils.customer_aggregation import CustomerAggregator
from utils.column_resolver import resolve, resolve_many
from utils.schema_detector import SchemaDetector
from utils.auto_params import AutoParamGenerator


@dataclass
class PipelineResult:
    """Complete pipeline execution result."""
    success: bool
    timestamp: str
    records_processed: int
    dq_score: float
    features_generated: int
    methods_run: int
    alerts_generated: int
    tier_distribution: Dict[str, int]
    execution_time_ms: float
    df_scored: Optional[pd.DataFrame]
    ensemble_result: Optional[EnsembleResult]
    layer_timings: Dict[str, float] = field(default_factory=dict)
    error: Optional[str] = None
    run_id: Optional[str] = None           # V8: Run versioning
    input_hash: Optional[str] = None       # V8: Data lineage


class VanguardPipeline:
    """
    Main 7-Layer Pipeline Orchestrator (V8).

    V8 changes vs V7:
    - Column resolution via COLUMNS.resolve(), no COLUMN_ALIASES dict
    - SchemaDetector profiling before L4
    - AutoParamGenerator before L5
    - Checkpointing: save partial L5 results per-method
    - Data lineage: hash inputs, UUID per run
    """

    def __init__(self):
        self.ingest = IngestPipeline()
        self.features = Layer3FeatureEngineering()
        self.preprocess = Layer4Preprocessing()
        self.detection = Layer5Detection()
        self.ensemble = Layer6Ensemble()
        self.output = Layer7Output()
        self.schema_detector = SchemaDetector()       # V8

        self.last_result: Optional[PipelineResult] = None
        self.df_processed: Optional[pd.DataFrame] = None

    def _update_status(self, progress: int, stage: str, status: str = "running", error: str = None):
        """Update pipeline status file for UI polling."""
        status_data = {
            "status": status,
            "progress": progress,
            "stage": stage,
            "timestamp": datetime.now().isoformat(),
            "error": error,
        }
        try:
            with open(PATHS.DATA_VAULT / "pipeline_status.json", "w") as f:
                json.dump(status_data, f)
        except Exception:
            pass

    # V8: Compute data lineage hash
    @staticmethod
    def _hash_dataframe(df: pd.DataFrame) -> str:
        data_bytes = pd.util.hash_pandas_object(df).values.tobytes()
        return hashlib.new(AUDIT.HASH_ALGORITHM, data_bytes).hexdigest()[:16]

    def run(
        self,
        sources: Dict[str, pd.DataFrame],
        detection_methods: List[str] = None,
        ensemble_method: str = "weighted_average",
        id_columns: List[str] = None,
        customer_col: str = None,
        amount_col: str = None,
        timestamp_col: str = None,
        merged_df: pd.DataFrame = None,
    ) -> PipelineResult:
        """
        Execute full 7-layer pipeline.

        Column names are resolved via ColumnRoleConfig — callers no longer
        need to pass customer_col / amount_col / timestamp_col unless they
        want explicit overrides.
        """
        start_time = datetime.now()
        id_columns = id_columns or []
        layer_timings = {}
        input_hash = None

        try:
            self._update_status(0, "Initializing", "running")

            # Filter out empty source DataFrames
            sources = {k: v for k, v in sources.items() if v is not None and not v.empty}
            if not sources and merged_df is None:
                raise ValueError("No non-empty source tables provided")

            # ============== LAYER 1-2: INGEST + DQ ==============
            print("[L1-2] Ingestion & Data Quality...")
            self._update_status(10, "Layer 1-2: Ingestion & DQ")
            t0 = time.time()

            if merged_df is not None and not merged_df.empty:
                df = merged_df.copy()
                dq_report = self.ingest.dq.assess_quality(df)
                df = self.ingest.dq.cleanse(df, "moderate")
            else:
                df, dq_report = self.ingest.run(sources)
            layer_timings["L1-2"] = time.time() - t0

            # V8: Data lineage — hash the input
            if AUDIT.ENABLE_DATA_LINEAGE:
                input_hash = self._hash_dataframe(df)
                print(f"   [LINEAGE] Input hash: {input_hash}")

            # ── V8: Role-based column resolution ──
            resolved = resolve_many(df, ["primary_key", "amount", "timestamp"])
            customer_col = customer_col or resolved.get("primary_key")
            amount_col = amount_col or resolved.get("amount")
            timestamp_col = timestamp_col or resolved.get("timestamp")

            print(f"   [RESOLVE] customer={customer_col}, amount={amount_col}, timestamp={timestamp_col}")

            # ============== V6: CUSTOMER AGGREGATION ==============
            if APP.CUSTOMER_LEVEL_PROCESSING and customer_col and customer_col in df.columns:
                print("[V6] Customer-Level Aggregation...")
                self._update_status(20, "V6: Customer Aggregation")
                t0 = time.time()

                aggregator = CustomerAggregator(customer_col=customer_col)
                df = aggregator.aggregate(
                    df_transactions=df,
                    amount_col=amount_col if amount_col and amount_col in df.columns else None,
                    timestamp_col=timestamp_col if timestamp_col and timestamp_col in df.columns else None,
                    type_col=resolve(df, "txn_type"),
                )

                layer_timings["V6_AGGREGATION"] = time.time() - t0
                print(f"   [INFO] Aggregated to {len(df)} customers with {len(aggregator.aggregation_features)} features")

            # ============== LAYER 3: FEATURE ENGINEERING ==============
            print("[L3] Feature Engineering...")
            self._update_status(30, "Layer 3: Feature Engineering")
            t0 = time.time()
            try:
                df = self.features.engineer_features(
                    df,
                    customer_col=customer_col if customer_col and customer_col in df.columns else None,
                    amount_col=amount_col if amount_col and amount_col in df.columns else None,
                    timestamp_col=timestamp_col if timestamp_col and timestamp_col in df.columns else None,
                )
            except TypeError:
                df = self.features.engineer_features(df)
            layer_timings["L3"] = time.time() - t0

            # ── Load exclude variables (if configured via Data Sources) ──
            exclude_path = PATHS.DATA_VAULT / "exclude_vars.json"
            if exclude_path.exists():
                try:
                    with open(exclude_path, "r") as f:
                        exclude_vars = json.load(f)
                    cols_to_drop = [c for c in exclude_vars if c in df.columns]
                    if cols_to_drop:
                        df = df.drop(columns=cols_to_drop)
                        print(f"   [INFO] Excluded {len(cols_to_drop)} variables: {cols_to_drop[:5]}...")
                except Exception:
                    pass

            # ============== V8: SCHEMA DETECTION (before L4) ==============
            print("[V8] Schema Detection...")
            self._update_status(40, "V8: Schema Detection")
            t0 = time.time()
            schema_profiles = self.schema_detector.detect_schema(df)
            usable_cols = self.schema_detector.get_usable_columns(schema_profiles)
            print(f"   [SCHEMA] {len(usable_cols)} usable / {len(schema_profiles)} total columns")
            layer_timings["V8_SCHEMA"] = time.time() - t0

            # ============== LAYER 4: PREPROCESSING ==============
            print("[L4] Preprocessing...")
            self._update_status(50, "Layer 4: Preprocessing")
            t0 = time.time()
            all_id_cols = id_columns.copy()
            if '_source' in df.columns:
                all_id_cols.append('_source')
            # V8: Exclude non-usable columns based on schema detection
            for col in df.columns:
                if col not in usable_cols and col not in all_id_cols:
                    all_id_cols.append(col)

            matrices = self.preprocess.preprocess(df, id_columns=all_id_cols)
            X = matrices.get('scaled', matrices.get('raw'))
            layer_timings["L4"] = time.time() - t0

            if detection_methods is None:
                detection_methods = []
                for methods in LAYERS.DETECTION_METHODS.values():
                    detection_methods.extend(methods)

            # Smart Algorithm Selection: Disable heavy methods for large datasets
            rows = len(df)
            max_heavy = RESOURCES.MAX_ROWS_FOR_HEAVY_METHODS
            if rows > max_heavy:
                original_count = len(detection_methods)
                detection_methods = [
                    m for m in detection_methods
                    if m not in LAYERS.HEAVY_METHODS
                ]
                new_count = len(detection_methods)
                if original_count > new_count:
                    msg = f"Data size ({rows}) > {max_heavy}. Disabled {original_count - new_count} heavy algorithms."
                    print(f"   [WARN] {msg}")

            # ============== V8: AUTO-PARAMETER GENERATION (before L5) ==============
            print("[V8] Auto-Parameter Generation...")
            self._update_status(60, "V8: Auto-Parameters")
            t0 = time.time()
            n_samples, n_features = X.shape
            auto_params = AutoParamGenerator.generate_all(n_samples, n_features)
            layer_timings["V8_AUTOPARAMS"] = time.time() - t0
            print(f"   [PARAMS] Generated params for {len(auto_params)} methods (n={n_samples}, f={n_features})")

            # ============== LAYER 5: DETECTION ==============
            print(f"[L5] Detection ({len(detection_methods)} methods)...")
            self._update_status(70, f"Layer 5: Detection ({len(detection_methods)} methods)")
            t0 = time.time()
            results = self.detection.detect_all(X, methods=detection_methods)
            score_matrix, method_names = self.detection.get_score_matrix()
            layer_timings["L5"] = time.time() - t0

            # V8: Checkpoint — save partial L5 results
            try:
                checkpoint_path = PATHS.DATA_VAULT / "l5_checkpoint.json"
                checkpoint = {
                    "methods_run": method_names,
                    "n_samples": int(n_samples),
                    "timestamp": datetime.now().isoformat(),
                }
                with open(checkpoint_path, "w") as f:
                    json.dump(checkpoint, f, indent=2, default=str)
            except Exception:
                pass

            # ============== LAYER 6: ENSEMBLE ==============
            print("[L6] Ensemble Fusion...")
            self._update_status(85, "Layer 6: Ensemble Fusion")
            t0 = time.time()
            self.ensemble.method = ensemble_method
            ensemble_result = self.ensemble.fuse(score_matrix, method_names)
            layer_timings["L6"] = time.time() - t0

            # ============== LAYER 7: OUTPUT ==============
            print("[L7] Output Generation...")
            self._update_status(95, "Layer 7: Output Generation")
            t0 = time.time()
            output_summary = self.output.process(
                df,
                ensemble_result.final_scores,
                ensemble_result.risk_tiers,
                score_matrix,
                method_names,
            )
            layer_timings["L7"] = time.time() - t0

            # ============== CREATE SCORED DATAFRAME ==============
            df_scored = df.copy()
            df_scored['anomaly_score'] = ensemble_result.final_scores
            df_scored['risk_tier'] = ensemble_result.risk_tiers

            for i, method in enumerate(method_names):
                df_scored[f'score_{method}'] = score_matrix[:, i]

            self.df_processed = df_scored

            execution_time = (datetime.now() - start_time).total_seconds() * 1000

            self.last_result = PipelineResult(
                success=True,
                timestamp=start_time.isoformat(),
                records_processed=len(df),
                dq_score=dq_report.overall_score,
                features_generated=len(self.features.feature_columns),
                methods_run=len(method_names),
                alerts_generated=output_summary['alerts_generated'],
                tier_distribution=ensemble_result.tier_counts,
                execution_time_ms=execution_time,
                df_scored=df_scored,
                ensemble_result=ensemble_result,
                layer_timings=layer_timings,
                run_id=None,
                input_hash=input_hash,
            )

            print(f"\n=== Pipeline complete in {execution_time:.0f}ms ===")
            print(f"   Records: {len(df):,}")
            print(f"   Alerts: {output_summary['alerts_generated']:,}")
            for layer, elapsed in layer_timings.items():
                print(f"   {layer}: {elapsed:.2f}s")

            self._update_status(100, "Pipeline Complete", "completed")
            return self.last_result

        except Exception as e:
            self._update_status(0, "Failed", "failed", str(e))
            execution_time = (datetime.now() - start_time).total_seconds() * 1000

            return PipelineResult(
                success=False,
                timestamp=start_time.isoformat(),
                records_processed=0,
                dq_score=0.0,
                features_generated=0,
                methods_run=0,
                alerts_generated=0,
                tier_distribution={},
                execution_time_ms=execution_time,
                df_scored=None,
                ensemble_result=None,
                layer_timings=layer_timings,
                error=str(e),
            )

    def run_single_source(
        self,
        df: pd.DataFrame,
        source_name: str = "transactions",
        **kwargs,
    ) -> PipelineResult:
        """Convenience method for single source."""
        return self.run({source_name: df}, **kwargs)

    def get_alerts(
        self,
        tier: str = None,
        limit: int = 100,
    ) -> List[Dict]:
        """Get generated alerts."""
        alerts = self.output.queue.get_queue(tier=tier)[:limit]
        return [
            {
                "alert_id": a.alert_id,
                "record_index": a.record_index,
                "risk_score": a.risk_score,
                "risk_tier": a.risk_tier,
                "status": a.status,
                "narrative": a.narrative,
            }
            for a in alerts
        ]

    def get_layer_summaries(self) -> Dict:
        """Get summary from each layer."""
        return {
            "layer_1_2": self.ingest.ingestion.get_summary() if hasattr(self.ingest, 'ingestion') else {},
            "layer_3": self.features.get_feature_summary(),
            "layer_4": self.preprocess.get_summary(),
            "layer_5": self.detection.get_summary(),
            "layer_6": self.ensemble.get_summary(self.last_result.ensemble_result) if self.last_result else {},
            "layer_7": {
                "queue": self.output.queue.get_summary(),
                "audit": self.output.audit.get_summary(),
            },
        }

    def save_results(self, path: Path = None):
        """Save scored results to parquet."""
        if self.df_processed is None:
            return None

        path = path or PATHS.DATA_VAULT / "scored.parquet"
        self.df_processed.to_parquet(path, index=False)
        return path

    def export_alerts_excel(self, path: Path = None):
        """Export alerts to Excel."""
        if not self.output.queue.alerts:
            return None

        path = path or PATHS.EXPORTS / f"alerts_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"

        alerts_data = []
        for a in self.output.queue.alerts.values():
            alerts_data.append({
                "Alert ID": a.alert_id,
                "Record Index": a.record_index,
                "Risk Score": a.risk_score,
                "Risk Tier": a.risk_tier,
                "Status": a.status,
                "Created": a.created_at,
                "Top Method 1": a.top_contributors[0]['method'] if a.top_contributors else "",
                "Top Method 1 Score": a.top_contributors[0]['score'] if a.top_contributors else 0,
            })

        df_alerts = pd.DataFrame(alerts_data)
        df_alerts.to_excel(path, index=False)

        return path


# Quick run function
def run_pipeline(df: pd.DataFrame, **kwargs) -> PipelineResult:
    """Quick run of the full pipeline."""
    pipeline = VanguardPipeline()
    return pipeline.run_single_source(df, **kwargs)
