"""
Data Sources Page - VERSION 8.1 ENHANCED
==========================================
PRINCIPLE 1: MASTER table is the ONLY mandatory input
PRINCIPLE 2: 12 integrated table slots (Master + 11 optional)
PRINCIPLE 3: Per-table upload / export / delete
PRINCIPLE 4: Configuration tables are optional
PRINCIPLE 5: Loaded Tables Summary with full actions

V8.1 Enhancements:
  - 12 table slots in compact 4x3 grid with individual upload
  - Per-table export (CSV) and delete actions
  - Loaded Tables Summary with AG Grid + action rows
  - All tables integrated and reflected across the page
"""

import dash
from dash import html, dcc, callback, Input, Output, State, ctx, ALL
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import dash_ag_grid as dag
import pandas as pd
import numpy as np
import io, base64, sys, json, zipfile
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS, APP, COLUMNS
from utils.schema_detector import SchemaDetector, ColumnType
from utils.column_resolver import resolve

dash.register_page(__name__, path="/sources", name="Data Sources", order=1)


# =============================================================================
# CONSTANTS
# =============================================================================
MASK_COLUMNS = {"party_id", "customer_id", "account_id", "cust_id"}

TABLE_SLOTS = [
    {"name": "MASTER",          "icon": "mdi:database",         "color": "cyan",   "label": "Master",          "mandatory": True,  "desc": "Primary key + entity (Required)"},
    {"name": "transactions",    "icon": "mdi:swap-horizontal",  "color": "blue",   "label": "Transactions",    "mandatory": False, "desc": "Transaction-level data"},
    {"name": "customer_party",  "icon": "mdi:account-group",    "color": "indigo", "label": "Customer/Party",  "mandatory": False, "desc": "Customer demographics"},
    {"name": "accounts",        "icon": "mdi:bank",             "color": "green",  "label": "Accounts",        "mandatory": False, "desc": "Account-level data"},
    {"name": "alerts",          "icon": "mdi:alert",            "color": "orange", "label": "Alerts",          "mandatory": False, "desc": "Alert history"},
    {"name": "cases",           "icon": "mdi:briefcase",        "color": "red",    "label": "Cases",           "mandatory": False, "desc": "Investigation cases"},
    {"name": "kyc",             "icon": "mdi:shield-check",     "color": "teal",   "label": "KYC",             "mandatory": False, "desc": "KYC compliance data"},
    {"name": "watchlist",       "icon": "mdi:shield-search",    "color": "pink",   "label": "Watchlist",       "mandatory": False, "desc": "Sanctions/PEP matches"},
    {"name": "relationships",   "icon": "mdi:graph-outline",    "color": "violet", "label": "Relationships",   "mandatory": False, "desc": "Network/graph data"},
    {"name": "temporal",        "icon": "mdi:chart-timeline",   "color": "grape",  "label": "Temporal",        "mandatory": False, "desc": "Time series data"},
    {"name": "others1",         "icon": "mdi:table-plus",       "color": "gray",   "label": "Others1",         "mandatory": False, "desc": "Custom table slot 1"},
    {"name": "others2",         "icon": "mdi:table-plus",       "color": "gray",   "label": "Others2",         "mandatory": False, "desc": "Custom table slot 2"},
]

SLOT_LOOKUP = {s["name"]: s for s in TABLE_SLOTS}


# =============================================================================
# VALIDATION HELPERS
# =============================================================================
def validate_master_table(df: pd.DataFrame) -> Tuple[bool, str]:
    """Validate MASTER table has required role columns (V8 role-based)."""
    pk_col = resolve(df, 'primary_key')
    if pk_col is None:
        return False, f"MASTER table missing a primary key column. Expected one of: {COLUMNS.ROLE_ALIASES.get('primary_key', [])}"
    if df[pk_col].duplicated().any():
        return False, f"MASTER table has duplicate values in '{pk_col}'"
    if df[pk_col].isnull().any():
        return False, f"MASTER table has null values in '{pk_col}'"
    return True, ""


def can_join_to_master(df: pd.DataFrame) -> bool:
    """Check if table has a primary_key-like column for joining."""
    return resolve(df, 'primary_key') is not None


def get_dynamic_table_icon(table_name: str) -> Dict[str, str]:
    """Assign icon/color based on table name keywords."""
    if table_name in SLOT_LOOKUP:
        s = SLOT_LOOKUP[table_name]
        return {"icon": s["icon"], "color": s["color"]}
    name_lower = table_name.lower()
    if 'master' in name_lower:    return {"icon": "mdi:database", "color": "cyan"}
    elif 'transaction' in name_lower or 'txn' in name_lower: return {"icon": "mdi:swap-horizontal", "color": "blue"}
    elif 'customer' in name_lower or 'party' in name_lower:  return {"icon": "mdi:account-group", "color": "indigo"}
    elif 'account' in name_lower:  return {"icon": "mdi:bank", "color": "green"}
    elif 'alert' in name_lower:    return {"icon": "mdi:alert", "color": "orange"}
    elif 'case' in name_lower:     return {"icon": "mdi:briefcase", "color": "red"}
    elif 'kyc' in name_lower:      return {"icon": "mdi:shield-check", "color": "teal"}
    elif 'watchlist' in name_lower: return {"icon": "mdi:shield-search", "color": "pink"}
    elif 'relationship' in name_lower or 'network' in name_lower: return {"icon": "mdi:graph-outline", "color": "violet"}
    elif 'temporal' in name_lower or 'time' in name_lower: return {"icon": "mdi:chart-timeline", "color": "grape"}
    return {"icon": "mdi:table", "color": "gray"}


def mask_id(val):
    s = str(val)
    return f"****{s[-4:]}" if len(s) > 4 else s


def _parse_upload(contents, filename):
    """Parse uploaded file contents into DataFrame."""
    content_string = contents.split(",")[1]
    decoded = base64.b64decode(content_string)
    if filename.endswith(".csv"):
        return pd.read_csv(io.StringIO(decoded.decode("utf-8")))
    elif filename.endswith((".xlsx", ".xls")):
        return pd.read_excel(io.BytesIO(decoded))
    elif filename.endswith(".parquet"):
        return pd.read_parquet(io.BytesIO(decoded))
    raise ValueError(f"Unsupported format: {filename}")


# =============================================================================
# UI BUILDER HELPERS
# =============================================================================
def build_ag_grid(df, table_name, max_rows=None, page_size=20):
    """Build AG Grid preview with pagination."""
    preview = df if max_rows is None else df.head(max_rows)
    preview = preview.copy()
    for col in preview.columns:
        if col in MASK_COLUMNS:
            preview[col] = preview[col].apply(mask_id)
    cols = [{"field": c, "sortable": True, "filter": True, "resizable": True} for c in preview.columns]
    return dag.AgGrid(
        id={"type": "source-grid", "table": table_name},
        rowData=preview.to_dict("records"),
        columnDefs=cols,
        defaultColDef={"flex": 1, "minWidth": 100},
        dashGridOptions={
            "animateRows": True,
            "pagination": True,
            "paginationPageSize": page_size,
            "paginationPageSizeSelector": [10, 20, 50, 100],
        },
        style={"height": "520px", "width": "100%"},
        className="ag-theme-alpine-dark",
    )


def _build_slot_card(slot):
    """Build a compact upload card for one of the 12 table slots."""
    name = slot["name"]
    is_mandatory = slot["mandatory"]
    border_color = "#22b8cf" if is_mandatory else THEME.DARK_BORDER

    return dmc.Paper([
        dmc.Stack([
            # Header: icon + label + badge
            dmc.Group([
                DashIconify(icon=slot["icon"], width=14, color=slot["color"]),
                dmc.Text(slot["label"], fw=600, size="xs", style={"flex": 1}),
                dmc.Badge(
                    "REQ" if is_mandatory else "",
                    color="red" if is_mandatory else "gray",
                    size="xs",
                    variant="filled" if is_mandatory else "light",
                ) if is_mandatory else None,
            ], gap=3, wrap="nowrap"),

            # Upload zone (compact)
            dcc.Upload(
                id={"type": "slot-upload", "slot": name},
                children=dmc.Center(
                    dmc.Text("Drop / Click", size="9px", c="dimmed"),
                    style={"minHeight": "28px"},
                ),
                style={
                    "border": f"1px dashed {border_color}",
                    "borderRadius": "4px",
                    "padding": "2px",
                    "textAlign": "center",
                    "cursor": "pointer",
                },
                multiple=False,
            ),

            # Status + actions row
            dmc.Group([
                html.Div(id={"type": "slot-status", "slot": name}, children=[
                    dmc.Text("Empty", size="9px", c="dimmed"),
                ], style={"flex": 1}),
                dmc.ActionIcon(
                    DashIconify(icon="mdi:download", width=12),
                    id={"type": "slot-export", "slot": name},
                    color="cyan", variant="subtle", size="xs",
                ),
                dmc.ActionIcon(
                    DashIconify(icon="mdi:trash-can-outline", width=12),
                    id={"type": "slot-delete", "slot": name},
                    color="red", variant="subtle", size="xs",
                ),
            ], gap=2),
        ], gap=2),
    ], p=6, radius="sm", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD})


def _build_config_upload_card(config_name, icon, color, description):
    """Build upload card for optional config tables."""
    return dmc.Paper([
        dmc.Stack([
            dmc.Group([
                DashIconify(icon=icon, width=14, color=color),
                dmc.Text(config_name, fw=600, size="xs"),
            ], gap=4),
            dmc.Text(description, size="10px", c="dimmed", lineClamp=1),
            dcc.Upload(
                id={"type": "upload-config", "name": config_name},
                children=dmc.Group([
                    DashIconify(icon="mdi:upload", width=12, color="#888"),
                    dmc.Text("Upload", size="10px", c="dimmed"),
                ], gap=4, justify="center"),
                style={
                    "border": "1px dashed #444", "borderRadius": "4px",
                    "padding": "2px 4px", "textAlign": "center", "cursor": "pointer",
                    "minHeight": "24px",
                },
                multiple=False,
            ),
            html.Div(id={"type": "config-status", "name": config_name}, style={"minHeight": "12px"}),
        ], gap=4),
    ], p=6, radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD})


def _build_loaded_summary(sources, data_vault):
    """
    Build the Loaded Tables Summary section.
    Shows all 12 slots with their status, record counts, and per-table actions.
    """
    rows = []
    for slot in TABLE_SLOTS:
        name = slot["name"]
        if name in sources:
            df = sources[name]
            detector = SchemaDetector()
            schema_profiles = detector.detect_schema(df)
            usable_cols = detector.get_usable_columns(schema_profiles)
            rows.append({
                "Table": name,
                "Label": slot["label"],
                "Type": "MANDATORY" if slot["mandatory"] else "Optional",
                "Status": "Loaded",
                "Records": f"{len(df):,}",
                "Columns": len(df.columns),
                "Usable": len(usable_cols),
                "Joinable": "Yes" if can_join_to_master(df) or name == "MASTER" else "No",
            })
        else:
            rows.append({
                "Table": name,
                "Label": slot["label"],
                "Type": "MANDATORY" if slot["mandatory"] else "Optional",
                "Status": "Empty",
                "Records": "-",
                "Columns": "-",
                "Usable": "-",
                "Joinable": "-",
            })

    # Also add any tables loaded that aren't in predefined slots
    slot_names = {s["name"] for s in TABLE_SLOTS}
    for name in sorted(sources.keys()):
        if name not in slot_names:
            df = sources[name]
            detector = SchemaDetector()
            schema_profiles = detector.detect_schema(df)
            usable_cols = detector.get_usable_columns(schema_profiles)
            rows.append({
                "Table": name,
                "Label": name,
                "Type": "Custom",
                "Status": "Loaded",
                "Records": f"{len(df):,}",
                "Columns": len(df.columns),
                "Usable": len(usable_cols),
                "Joinable": "Yes" if can_join_to_master(df) else "No",
            })

    col_defs = [
        {"field": "Table",    "headerName": "Table Name", "flex": 1.5, "pinned": "left",
         "cellStyle": {"fontWeight": "600"}},
        {"field": "Label",    "headerName": "Label",     "flex": 1.2},
        {"field": "Type",     "headerName": "Type",      "flex": 1,
         "cellStyle": {"conditions": [
             {"condition": "params.value === 'MANDATORY'", "style": {"color": "#FF5252", "fontWeight": "600"}},
         ]} if False else {}},
        {"field": "Status",   "headerName": "Status",    "flex": 0.8,
         "cellStyle": {"conditions": []} if False else {}},
        {"field": "Records",  "headerName": "Records",   "flex": 0.8, "type": "rightAligned"},
        {"field": "Columns",  "headerName": "Total Cols", "flex": 0.7, "type": "rightAligned"},
        {"field": "Usable",   "headerName": "Usable",    "flex": 0.7, "type": "rightAligned",
         "cellStyle": {"color": "#51cf66"}},
        {"field": "Joinable", "headerName": "Joinable",  "flex": 0.7},
    ]

    return dag.AgGrid(
        id="ds-summary-grid",
        rowData=rows,
        columnDefs=col_defs,
        defaultColDef={"resizable": True, "sortable": True, "filter": True},
        dashGridOptions={"domLayout": "autoHeight", "animateRows": True, "rowHeight": 36},
        style={"height": None, "width": "100%"},
        className="ag-theme-alpine-dark",
    )


def _build_stats(sources, data_vault):
    """Build stats row showing loaded data overview."""
    meta = data_vault.get_metadata()
    table_count = len(sources)
    total_rows = sum(len(df) for df in sources.values())
    slot_names = {s["name"] for s in TABLE_SLOTS}
    loaded_slots = sum(1 for s in TABLE_SLOTS if s["name"] in sources)

    cards = []
    for slot in TABLE_SLOTS:
        name = slot["name"]
        if name in sources:
            df = sources[name]
            detector = SchemaDetector()
            usable = len(detector.get_usable_columns(detector.detect_schema(df)))
            cards.append(
                dmc.Paper(
                    dmc.Group([
                        dmc.ThemeIcon(
                            DashIconify(icon=slot["icon"], width=16),
                            color=slot["color"], variant="light", size="md",
                        ),
                        dmc.Stack([
                            dmc.Group([
                                dmc.Text(slot["label"], size="xs", fw=600),
                                dmc.Badge("REQ", color="red", size="xs") if slot["mandatory"] else None,
                            ], gap=4),
                            dmc.Text(f"{len(df):,} rows | {usable} usable", size="10px", c="dimmed"),
                        ], gap=0),
                    ], gap="xs"),
                    p="xs", radius="sm", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD},
                )
            )
        else:
            cards.append(
                dmc.Paper(
                    dmc.Group([
                        dmc.ThemeIcon(
                            DashIconify(icon=slot["icon"], width=16),
                            color="gray", variant="light", size="md",
                        ),
                        dmc.Stack([
                            dmc.Text(slot["label"], size="xs", fw=500, c="dimmed"),
                            dmc.Text("Not loaded", size="10px", c="dimmed"),
                        ], gap=0),
                    ], gap="xs"),
                    p="xs", radius="sm", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD, "opacity": 0.5},
                )
            )

    return dmc.Stack([
        dmc.Group([
            dmc.Badge(f"{loaded_slots}/12 Slots Filled", color="cyan", variant="light", size="lg"),
            dmc.Badge(f"{total_rows:,} Total Rows", color="blue", variant="light", size="lg") if total_rows > 0 else None,
            dmc.Badge(f"{table_count} Tables", color="green", variant="light", size="lg") if table_count > 0 else None,
        ], gap="md"),
        dmc.SimpleGrid(
            cols={"base": 2, "sm": 3, "md": 4, "lg": 6}, spacing="xs", children=cards,
        ),
    ], gap="sm")


def _build_preview_tabs(sources):
    """Build tabbed preview for loaded tables."""
    if not sources:
        return dmc.Alert(
            "No data loaded yet. Upload tables or generate sample data above.",
            color="gray", variant="light",
            icon=DashIconify(icon="mdi:information"),
        )
    tabs, panels = [], []
    for name, df in sorted(sources.items()):
        icon_info = get_dynamic_table_icon(name)
        tabs.append(dmc.TabsTab(name, value=name,
                                leftSection=DashIconify(icon=icon_info["icon"], width=14)))
        panels.append(dmc.TabsPanel(
            dmc.Paper([
                dmc.Group([
                    dmc.Text(f"{len(df):,} rows (paginated, {len(df.columns)} cols)", size="xs", c="dimmed"),
                    dmc.Badge(f"{len(df.columns)} cols", color="gray", variant="light", size="xs"),
                ], justify="space-between", mb="xs"),
                build_ag_grid(df, name),
            ], p="sm", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}),
            value=name,
        ))
    first = sorted(sources.keys())[0]
    return dmc.Tabs([dmc.TabsList(tabs)] + panels, value=first, color="cyan", variant="pills")


# =============================================================================
# CROSS-TABLE CONSISTENCY & INTEGRATION CHECK
# =============================================================================
def _build_consistency_check(sources):
    """Validate referential integrity across all loaded tables."""
    if not sources or len(sources) < 2:
        return dmc.Alert(
            "Need at least 2 tables to run consistency checks.",
            color="gray", variant="light",
            icon=DashIconify(icon="mdi:information"),
        )

    checks = []
    # Identify primary key column from MASTER
    pk_col = None
    if "MASTER" in sources:
        pk_col = resolve(sources["MASTER"], "primary_key")

    # 1. Primary key presence check
    pk_aliases = {"cust_id", "customer_id", "party_id", "client_id", "entity_id", "account_id"}
    pk_results = []
    for name, df in sorted(sources.items()):
        found_pk = resolve(df, "primary_key")
        has_pk = found_pk is not None
        pk_results.append({
            "Table": name,
            "PK Column": found_pk or "—",
            "Has PK": "Yes" if has_pk else "No",
            "Unique PKs": int(df[found_pk].nunique()) if has_pk else 0,
            "Null PKs": int(df[found_pk].isnull().sum()) if has_pk else 0,
            "Dup PKs": int(df[found_pk].duplicated().sum()) if has_pk else 0,
        })

    pk_df = pd.DataFrame(pk_results)
    checks.append(dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:key", width=18, color="#22b8cf"),
            dmc.Text("Primary Key Presence", fw=600, size="sm"),
        ], gap="xs", mb="xs"),
        dag.AgGrid(
            id="consistency-pk-grid",
            rowData=pk_df.to_dict("records"),
            columnDefs=[{"field": c, "sortable": True, "filter": True} for c in pk_df.columns],
            defaultColDef={"flex": 1, "minWidth": 90},
            dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
            style={"height": None, "width": "100%"},
            className="ag-theme-alpine-dark",
        ),
    ], p="sm", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}))

    # 2. Cross-table key overlap / referential integrity
    if pk_col and "MASTER" in sources:
        master_keys = set(sources["MASTER"][pk_col].dropna().astype(str))
        overlap_results = []
        for name, df in sorted(sources.items()):
            if name == "MASTER":
                continue
            tpk = resolve(df, "primary_key")
            if tpk is None:
                overlap_results.append({
                    "Table": name, "Join Key": "—", "MASTER Keys": len(master_keys),
                    "Table Keys": 0, "Matched": 0, "Overlap %": "—",
                    "Orphans": "—", "Status": "No PK",
                })
                continue
            table_keys = set(df[tpk].dropna().astype(str))
            matched = master_keys & table_keys
            overlap_pct = round(len(matched) / max(len(table_keys), 1) * 100, 1)
            orphan_count = len(table_keys - master_keys)
            status = "OK" if overlap_pct >= 80 else ("Warn" if overlap_pct >= 50 else "Low")
            overlap_results.append({
                "Table": name, "Join Key": tpk, "MASTER Keys": len(master_keys),
                "Table Keys": len(table_keys), "Matched": len(matched),
                "Overlap %": f"{overlap_pct}%",
                "Orphans": orphan_count, "Status": status,
            })

        if overlap_results:
            ov_df = pd.DataFrame(overlap_results)
            checks.append(dmc.Paper([
                dmc.Group([
                    DashIconify(icon="mdi:link-variant", width=18, color="#51cf66"),
                    dmc.Text("Cross-Table Key Overlap (vs MASTER)", fw=600, size="sm"),
                ], gap="xs", mb="xs"),
                dag.AgGrid(
                    id="consistency-overlap-grid",
                    rowData=ov_df.to_dict("records"),
                    columnDefs=[{"field": c, "sortable": True, "filter": True} for c in ov_df.columns],
                    defaultColDef={"flex": 1, "minWidth": 80},
                    dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
                    style={"height": None, "width": "100%"},
                    className="ag-theme-alpine-dark",
                ),
            ], p="sm", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}))

    # 3. Column overlap heatmap data
    col_overlap_rows = []
    table_names = sorted(sources.keys())
    for t1 in table_names:
        cols1 = set(sources[t1].columns)
        row = {"Table": t1}
        for t2 in table_names:
            cols2 = set(sources[t2].columns)
            shared = len(cols1 & cols2)
            row[t2] = shared
        col_overlap_rows.append(row)

    co_df = pd.DataFrame(col_overlap_rows)
    checks.append(dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:table-column", width=18, color="#be4bdb"),
            dmc.Text("Shared Columns Matrix", fw=600, size="sm"),
        ], gap="xs", mb="xs"),
        dmc.Text("Count of columns with the same name across table pairs", size="xs", c="dimmed", mb="xs"),
        dag.AgGrid(
            id="consistency-colmatrix-grid",
            rowData=co_df.to_dict("records"),
            columnDefs=[{"field": c, "sortable": True, "filter": True} for c in co_df.columns],
            defaultColDef={"flex": 1, "minWidth": 70},
            dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
            style={"height": None, "width": "100%"},
            className="ag-theme-alpine-dark",
        ),
    ], p="sm", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}))

    # 4. Data quality summary per table
    dq_results = []
    for name, df in sorted(sources.items()):
        null_pct = round(df.isnull().sum().sum() / max(df.size, 1) * 100, 2)
        dup_rows = int(df.duplicated().sum())
        numeric_cols = len(df.select_dtypes(include=[np.number]).columns)
        cat_cols = len(df.select_dtypes(include=["object", "category"]).columns)
        dq_results.append({
            "Table": name, "Rows": len(df), "Cols": len(df.columns),
            "Null %": f"{null_pct}%", "Dup Rows": dup_rows,
            "Numeric": numeric_cols, "Categorical": cat_cols,
        })

    dq_df = pd.DataFrame(dq_results)
    checks.append(dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:chart-box", width=18, color="#ffd43b"),
            dmc.Text("Data Quality Summary", fw=600, size="sm"),
        ], gap="xs", mb="xs"),
        dag.AgGrid(
            id="consistency-dq-grid",
            rowData=dq_df.to_dict("records"),
            columnDefs=[{"field": c, "sortable": True, "filter": True} for c in dq_df.columns],
            defaultColDef={"flex": 1, "minWidth": 80},
            dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
            style={"height": None, "width": "100%"},
            className="ag-theme-alpine-dark",
        ),
    ], p="sm", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}))

    return dmc.Stack(checks, gap="sm")


# =============================================================================
# CUSTOMER-LEVEL AGGREGATE TABLE BUILDER
# =============================================================================
def _safe_merge(agg, right_df, pk_col, right_pk, suffix):
    """Safely merge right_df into agg, handling column name conflicts."""
    try:
        # Drop columns from right that already exist in agg (except the join key)
        existing_cols = set(agg.columns) - {pk_col}
        right_cols_to_keep = [right_pk] + [c for c in right_df.columns if c != right_pk and c not in existing_cols]
        right_clean = right_df[right_cols_to_keep]
        agg = agg.merge(right_clean, left_on=pk_col, right_on=right_pk, how="left", suffixes=("", suffix))
        if right_pk != pk_col and right_pk in agg.columns:
            agg.drop(columns=[right_pk], inplace=True, errors="ignore")
    except Exception:
        pass
    return agg


def _build_customer_aggregate(sources):
    """
    Build a combined rolled-up customer-level aggregate from ALL tables.
    MASTER columns are FULLY preserved. Temporal, customer_party, relationships,
    others1, others2 are all aggregated and merged.
    """
    if "MASTER" not in sources:
        return None, dmc.Alert(
            "MASTER table required to build customer aggregate.",
            color="yellow", variant="light",
            icon=DashIconify(icon="mdi:alert"),
        )

    df_master = sources["MASTER"].copy()
    pk_col = resolve(df_master, "primary_key")
    if pk_col is None:
        return None, dmc.Alert("MASTER has no primary key column.", color="red")

    # ── START with ALL MASTER columns (not just PK!) ─────────────────
    agg = df_master.drop_duplicates(subset=[pk_col]).copy()

    # ── Helper: find a joinable key in a table ───────────────────────
    def _find_join_key(df):
        """Resolve primary_key, or check for from_party_id-style columns."""
        k = resolve(df, "primary_key")
        if k:
            return k
        # Fallback: check for party-like columns directly
        for candidate in ["from_party_id", "to_party_id", "party_id", "cust_id", "customer_id"]:
            if candidate in df.columns:
                return candidate
        return None

    # ── Aggregate from transactions ──────────────────────────────────
    if "transactions" in sources:
        df_tx = sources["transactions"]
        tpk = _find_join_key(df_tx)
        if tpk:
            amt_col = next((c for c in df_tx.columns if "amount" in c.lower()), None)
            agg_dict = {"txn_count": pd.NamedAgg(column=tpk, aggfunc="count")}
            if amt_col:
                agg_dict["txn_total_amount"] = pd.NamedAgg(column=amt_col, aggfunc="sum")
                agg_dict["txn_avg_amount"] = pd.NamedAgg(column=amt_col, aggfunc="mean")
                agg_dict["txn_max_amount"] = pd.NamedAgg(column=amt_col, aggfunc="max")
            tx_agg = df_tx.groupby(tpk).agg(**agg_dict).reset_index()
            agg = _safe_merge(agg, tx_agg, pk_col, tpk, "_tx")

    # ── Aggregate from accounts ──────────────────────────────────────
    if "accounts" in sources:
        df_acc = sources["accounts"]
        tpk = _find_join_key(df_acc)
        if tpk:
            bal_col = next((c for c in df_acc.columns if "balance" in c.lower()), None)
            acc_agg_dict = {"account_count": pd.NamedAgg(column=tpk, aggfunc="count")}
            if bal_col:
                acc_agg_dict["total_balance"] = pd.NamedAgg(column=bal_col, aggfunc="sum")
                acc_agg_dict["avg_balance"] = pd.NamedAgg(column=bal_col, aggfunc="mean")
            acc_agg = df_acc.groupby(tpk).agg(**acc_agg_dict).reset_index()
            agg = _safe_merge(agg, acc_agg, pk_col, tpk, "_acc")

    # ── Aggregate from alerts ────────────────────────────────────────
    if "alerts" in sources:
        df_al = sources["alerts"]
        tpk = _find_join_key(df_al)
        if tpk:
            al_agg = df_al.groupby(tpk).agg(
                alert_count=pd.NamedAgg(column=tpk, aggfunc="count"),
            ).reset_index()
            sev_col = next((c for c in df_al.columns if "severity" in c.lower() or "level" in c.lower()), None)
            if sev_col:
                try:
                    sev_pivot = df_al.groupby([tpk, sev_col]).size().unstack(fill_value=0)
                    sev_pivot.columns = [f"alert_{str(c).lower()}" for c in sev_pivot.columns]
                    al_agg = al_agg.merge(sev_pivot, left_on=tpk, right_index=True, how="left")
                except Exception:
                    pass
            agg = _safe_merge(agg, al_agg, pk_col, tpk, "_al")

    # ── Aggregate from cases ─────────────────────────────────────────
    if "cases" in sources:
        df_cs = sources["cases"]
        tpk = _find_join_key(df_cs)
        if tpk:
            cs_agg = df_cs.groupby(tpk).agg(
                case_count=pd.NamedAgg(column=tpk, aggfunc="count"),
            ).reset_index()
            status_col = next((c for c in df_cs.columns if "status" in c.lower()), None)
            if status_col:
                try:
                    st_pivot = df_cs.groupby([tpk, status_col]).size().unstack(fill_value=0)
                    st_pivot.columns = [f"case_{str(c).lower()}" for c in st_pivot.columns]
                    cs_agg = cs_agg.merge(st_pivot, left_on=tpk, right_index=True, how="left")
                except Exception:
                    pass
            agg = _safe_merge(agg, cs_agg, pk_col, tpk, "_cs")

    # ── Aggregate from kyc ───────────────────────────────────────────
    if "kyc" in sources:
        df_kyc = sources["kyc"]
        tpk = _find_join_key(df_kyc)
        if tpk:
            kyc_status_col = next((c for c in df_kyc.columns if "status" in c.lower() or "kyc" in c.lower()), None)
            if kyc_status_col and kyc_status_col != tpk:
                kyc_agg = df_kyc.groupby(tpk).agg(
                    kyc_latest=pd.NamedAgg(column=kyc_status_col, aggfunc="last"),
                ).reset_index()
                agg = _safe_merge(agg, kyc_agg, pk_col, tpk, "_kyc")

    # ── Aggregate from watchlist (may not have a customer key) ───────
    if "watchlist" in sources:
        df_wl = sources["watchlist"]
        tpk = _find_join_key(df_wl)
        if tpk:
            wl_agg = df_wl.groupby(tpk).agg(
                watchlist_hits=pd.NamedAgg(column=tpk, aggfunc="count"),
            ).reset_index()
            agg = _safe_merge(agg, wl_agg, pk_col, tpk, "_wl")

    # ── Aggregate from customer_party (demographics) ─────────────────
    if "customer_party" in sources:
        df_cp = sources["customer_party"]
        tpk = _find_join_key(df_cp)
        if tpk:
            # Bring in demographic columns (exclude columns already in MASTER)
            demo_cols = [c for c in df_cp.columns if c not in agg.columns or c == tpk]
            if len(demo_cols) > 1:  # more than just the key
                cp_dedup = df_cp[demo_cols].drop_duplicates(subset=[tpk])
                agg = _safe_merge(agg, cp_dedup, pk_col, tpk, "_cp")

    # ── Aggregate from temporal (time-series rollup) ─────────────────
    if "temporal" in sources:
        df_tmp = sources["temporal"]
        tpk = _find_join_key(df_tmp)
        if tpk:
            tmp_agg_dict = {"temporal_periods": pd.NamedAgg(column=tpk, aggfunc="count")}
            # Aggregate all numeric columns from temporal
            for col in df_tmp.select_dtypes(include=[np.number]).columns:
                if col == tpk:
                    continue
                col_clean = col.replace(" ", "_").lower()
                tmp_agg_dict[f"tmp_{col_clean}_sum"] = pd.NamedAgg(column=col, aggfunc="sum")
                tmp_agg_dict[f"tmp_{col_clean}_avg"] = pd.NamedAgg(column=col, aggfunc="mean")
                tmp_agg_dict[f"tmp_{col_clean}_max"] = pd.NamedAgg(column=col, aggfunc="max")
            tmp_agg = df_tmp.groupby(tpk).agg(**tmp_agg_dict).reset_index()
            agg = _safe_merge(agg, tmp_agg, pk_col, tpk, "_tmp")

    # ── Aggregate from relationships (network metrics) ───────────────
    if "relationships" in sources:
        df_rel = sources["relationships"]
        # Relationships use from_party_id / to_party_id — aggregate both directions
        rel_agg_rows = {}
        for direction_col in ["from_party_id", "to_party_id"]:
            if direction_col in df_rel.columns:
                counts = df_rel[direction_col].value_counts()
                for k, v in counts.items():
                    rel_agg_rows.setdefault(k, {"outgoing": 0, "incoming": 0})
                    if "from" in direction_col:
                        rel_agg_rows[k]["outgoing"] += v
                    else:
                        rel_agg_rows[k]["incoming"] += v
        if rel_agg_rows:
            rel_df = pd.DataFrame([
                {pk_col: k, "rel_outgoing": v["outgoing"], "rel_incoming": v["incoming"],
                 "rel_total": v["outgoing"] + v["incoming"]}
                for k, v in rel_agg_rows.items()
            ])
            agg = _safe_merge(agg, rel_df, pk_col, pk_col, "_rel")

    # ── Aggregate from others1 ───────────────────────────────────────
    if "others1" in sources:
        df_o1 = sources["others1"]
        tpk = _find_join_key(df_o1)
        if tpk:
            o1_agg_dict = {"others1_count": pd.NamedAgg(column=tpk, aggfunc="count")}
            for col in df_o1.select_dtypes(include=[np.number]).columns:
                if col == tpk:
                    continue
                col_clean = col.replace(" ", "_").lower()
                o1_agg_dict[f"o1_{col_clean}_sum"] = pd.NamedAgg(column=col, aggfunc="sum")
            o1_agg = df_o1.groupby(tpk).agg(**o1_agg_dict).reset_index()
            agg = _safe_merge(agg, o1_agg, pk_col, tpk, "_o1")

    # ── Aggregate from others2 ───────────────────────────────────────
    if "others2" in sources:
        df_o2 = sources["others2"]
        tpk = _find_join_key(df_o2)
        if tpk:
            o2_agg_dict = {"others2_count": pd.NamedAgg(column=tpk, aggfunc="count")}
            for col in df_o2.select_dtypes(include=[np.number]).columns:
                if col == tpk:
                    continue
                col_clean = col.replace(" ", "_").lower()
                o2_agg_dict[f"o2_{col_clean}_sum"] = pd.NamedAgg(column=col, aggfunc="sum")
            o2_agg = df_o2.groupby(tpk).agg(**o2_agg_dict).reset_index()
            agg = _safe_merge(agg, o2_agg, pk_col, tpk, "_o2")

    # ── Fill NaN numeric with 0 ──────────────────────────────────────
    for col in agg.columns:
        if agg[col].dtype in [np.float64, np.int64, np.float32, np.int32]:
            agg[col] = agg[col].fillna(0)

    # ── Round floats ─────────────────────────────────────────────────
    for col in agg.select_dtypes(include=[np.floating]).columns:
        agg[col] = agg[col].round(2)

    # ── Build display ────────────────────────────────────────────────
    # Count how many source tables contributed
    contributing = [t for t in sources if t != "MASTER" and t != "customer_aggregate"]
    display = dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:account-details", width=20, color="#22b8cf"),
            dmc.Text("Customer-Level Combined Aggregate", fw=700, size="lg"),
            dmc.Badge(f"{len(agg):,} customers | {len(agg.columns)} features | {len(contributing)+1} tables merged",
                      color="cyan", variant="light", size="sm"),
        ], gap="xs", mb="xs"),
        dmc.Text(
            f"MASTER + {', '.join(contributing[:6])}{' ...' if len(contributing) > 6 else ''} — one row per customer",
            size="xs", c="dimmed", mb="sm",
        ),
        build_ag_grid(agg, "customer_aggregate", page_size=20),
    ], p="md", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD})

    return agg, display


def _build_schema_docs_modal():
    """Build comprehensive schema documentation modal."""
    return dmc.ScrollArea([
        dmc.Tabs([
            dmc.TabsList([
                dmc.TabsTab("Data Tables", value="data"),
                dmc.TabsTab("Config Tables", value="config"),
                dmc.TabsTab("Auto-Detection", value="detection"),
            ]),
            dmc.TabsPanel(
                dmc.Stack([
                    dmc.Title("12 Integrated Table Slots", order=3, mb="md"),
                    dmc.Paper([
                        dmc.Title("MASTER Table (MANDATORY)", order=4, mb="sm", c="red"),
                        dmc.Text("Must have a primary key column (cust_id / customer_id / party_id).", size="sm", mb="sm"),
                        dmc.Code(
                            "Minimal: cust_id, cust_name\n"
                            "Medium:  cust_id, cust_name, total_amt, txn_count, ...\n"
                            "Full:    cust_id, cust_name + 100 feature columns",
                            block=True,
                        ),
                    ], p="md", withBorder=True, mb="md"),
                    dmc.Paper([
                        dmc.Title("11 Additional Table Slots (ALL OPTIONAL)", order=4, mb="sm", c="green"),
                        dmc.Table([
                            html.Thead(html.Tr([html.Th("Slot"), html.Th("Purpose"), html.Th("Auto-Join")])),
                            html.Tbody([
                                html.Tr([html.Td("Transactions"), html.Td("Transaction-level data"), html.Td("cust_id")]),
                                html.Tr([html.Td("Customer/Party"), html.Td("Demographics"), html.Td("cust_id")]),
                                html.Tr([html.Td("Accounts"), html.Td("Account-level data"), html.Td("account_id")]),
                                html.Tr([html.Td("Alerts"), html.Td("Alert history"), html.Td("cust_id")]),
                                html.Tr([html.Td("Cases"), html.Td("Investigation cases"), html.Td("cust_id")]),
                                html.Tr([html.Td("KYC"), html.Td("Compliance data"), html.Td("cust_id")]),
                                html.Tr([html.Td("Watchlist"), html.Td("Sanctions/PEP"), html.Td("cust_id")]),
                                html.Tr([html.Td("Relationships"), html.Td("Network/graph data"), html.Td("cust_id")]),
                                html.Tr([html.Td("Temporal"), html.Td("Time series"), html.Td("cust_id")]),
                                html.Tr([html.Td("Others1"), html.Td("Custom slot"), html.Td("auto-detect")]),
                                html.Tr([html.Td("Others2"), html.Td("Custom slot"), html.Td("auto-detect")]),
                            ]),
                        ], striped=True, highlightOnHover=True),
                    ], p="md", withBorder=True),
                ]),
                value="data",
            ),
            dmc.TabsPanel(
                dmc.Stack([
                    dmc.Title("Configuration Tables (All Optional)", order=3, mb="md"),
                    dmc.Alert("All config tables are OPTIONAL. System uses intelligent defaults.", color="blue", variant="light", mb="md"),
                    dmc.Paper([
                        dmc.Title("EXCLUDE_FEATURES", order=5, mb="sm"),
                        dmc.Code("Schema: table_name, feature_name, exclusion_reason", block=True),
                    ], p="md", withBorder=True, mb="md"),
                    dmc.Paper([
                        dmc.Title("FEATURE_MAP", order=5, mb="sm"),
                        dmc.Code("Schema: table_name, current_name, system_name, transformation", block=True),
                    ], p="md", withBorder=True, mb="md"),
                    dmc.Paper([
                        dmc.Title("TABLE_MAP", order=5, mb="sm"),
                        dmc.Code("Schema: base_table, target_table, base_key, target_key, join_type", block=True),
                    ], p="md", withBorder=True, mb="md"),
                    dmc.Paper([
                        dmc.Title("METHOD_CONFIG", order=5, mb="sm"),
                        dmc.Code("Schema: method_name, category, is_enabled, weight, parameters", block=True),
                    ], p="md", withBorder=True),
                ]),
                value="config",
            ),
            dmc.TabsPanel(
                dmc.Stack([
                    dmc.Title("Auto-Detection Rules", order=3, mb="md"),
                    dmc.Table([
                        html.Thead(html.Tr([html.Th("Type"), html.Th("Detection"), html.Th("Usable")])),
                        html.Tbody([
                            html.Tr([html.Td(dmc.Badge("CONTINUOUS", color="blue")), html.Td("Float / large range int"), html.Td("YES")]),
                            html.Tr([html.Td(dmc.Badge("BINARY", color="green")), html.Td("2 unique values"), html.Td("YES")]),
                            html.Tr([html.Td(dmc.Badge("ORDINAL", color="cyan")), html.Td("Int 2-10 unique"), html.Td("YES")]),
                            html.Tr([html.Td(dmc.Badge("CATEGORICAL", color="grape")), html.Td("String <20 unique"), html.Td("YES")]),
                            html.Tr([html.Td(dmc.Badge("HIGH_CARD", color="red")), html.Td("String >20 unique"), html.Td("NO")]),
                            html.Tr([html.Td(dmc.Badge("ID_FIELD", color="orange")), html.Td(">95% unique + id keyword"), html.Td("NO")]),
                            html.Tr([html.Td(dmc.Badge("DATETIME", color="yellow")), html.Td("Date/timestamp"), html.Td("CONTEXT")]),
                            html.Tr([html.Td(dmc.Badge("TEXT", color="gray")), html.Td("Free-form text"), html.Td("NO")]),
                        ]),
                    ], striped=True, highlightOnHover=True),
                ]),
                value="detection",
            ),
        ], value="data", variant="pills", color="cyan"),
    ], h=500)


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Container([
    # ── HEADER ────────────────────────────────────────────────────────
    dmc.Group([
        dmc.Stack([
            dmc.Title("Data Sources V8.1", order=2),
            dmc.Text("12 table slots | Per-table export/delete | Auto-detection", size="sm", c="dimmed"),
        ], gap=2),
        dmc.Group([
            dmc.Badge("12 Slots", color="cyan", variant="light"),
            dmc.Badge("Auto-Join", color="teal", variant="light"),
            dmc.Button("Schema Docs", id="btn-open-schema-docs", variant="subtle", size="xs",
                       color="blue", leftSection=DashIconify(icon="mdi:book-open-variant", width=14)),
        ], gap="xs"),
    ], justify="space-between", mb="md"),

    # Schema Docs Modal
    dmc.Modal(id="modal-schema-docs", title="Schema Architecture Reference", size="90%",
              children=_build_schema_docs_modal()),

    # ══════════════════════════════════════════════════════════════════
    # QUICK START: Generate / Select / Confirm (TOP OF PAGE)
    # ══════════════════════════════════════════════════════════════════
    dmc.Text("Quick Start", fw=700, size="lg", mb="xs"),
    dmc.SimpleGrid(
        cols={"base": 1, "sm": 2}, spacing="md", mb="md",
        children=[
            # Generate Sample Data
            dmc.Paper([
                dmc.Group([
                    DashIconify(icon="mdi:database-plus", width=18, color="#22b8cf"),
                    dmc.Text("Generate Sample Data", fw=600, size="sm"),
                ], gap="xs", mb="xs"),
                dmc.NumberInput(
                    id="ds-customer-count", label="Customers",
                    value=100, min=10, max=100000, step=10, size="xs", mb="xs",
                ),
                dmc.Button("Generate", id="ds-btn-generate",
                           leftSection=DashIconify(icon="mdi:play", width=14),
                           color="cyan", size="xs", fullWidth=True, mb="xs"),
                dmc.Button("Reset All", id="ds-btn-reset",
                           leftSection=DashIconify(icon="mdi:trash-can", width=14),
                           color="red", variant="subtle", size="xs", fullWidth=True),
            ], p="sm", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD, "height": "100%"}),

            # Select for Execution
            dmc.Paper([
                dmc.Group([
                    DashIconify(icon="mdi:check-decagram", width=18, color="#51cf66"),
                    dmc.Text("Select for Execution", fw=600, size="sm"),
                ], gap="xs", mb="xs"),
                dmc.SegmentedControl(
                    id="ds-execution-choice",
                    data=[{"label": "Sample", "value": "sample"}, {"label": "Actual", "value": "actual"}],
                    value="sample", color="green", fullWidth=True, size="xs", mb="xs",
                ),
                html.Div(id="ds-execution-info", children=[
                    dmc.Alert("No data available", color="gray", variant="light",
                              styles={"message": {"fontSize": "11px"}}),
                ]),
                dmc.Button("Confirm", id="ds-btn-confirm-final",
                           leftSection=DashIconify(icon="mdi:check-bold", width=14),
                           color="green", size="xs", fullWidth=True, mt="xs", disabled=True),
            ], p="sm", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD, "height": "100%"}),
        ],
    ),

    # Status
    html.Div(id="ds-status-output", style={"marginBottom": "8px"}),

    # ══════════════════════════════════════════════════════════════════
    # ALL TABLE SLOTS — Consolidated Upload Grid (12 slots)
    # ══════════════════════════════════════════════════════════════════
    dmc.Text("All Table Slots", fw=700, size="lg", mb="xs"),
    dmc.Text(
        "Upload to any slot — MASTER required, all others optional | Export or delete per table",
        size="xs", c="dimmed", mb="sm",
    ),
    dmc.SimpleGrid(
        cols={"base": 3, "sm": 4, "md": 6, "lg": 6},
        spacing="xs",
        mb="md",
        children=[_build_slot_card(slot) for slot in TABLE_SLOTS],
    ),

    # ══════════════════════════════════════════════════════════════════
    # SECTION 4: Advanced Configuration Tables (All Optional)
    # ══════════════════════════════════════════════════════════════════
    dmc.Text("Advanced: Configuration Tables (All Optional)", fw=700, size="lg", mb="xs"),
    dmc.Alert(
        "Upload config tables to override intelligent defaults. System works perfectly without these.",
        color="blue", variant="light",
        icon=DashIconify(icon="mdi:cog-outline", width=18), mb="sm",
    ),
    dmc.SimpleGrid(
        cols={"base": 1, "sm": 2, "md": 4}, spacing="sm", mb="md",
        children=[
            _build_config_upload_card("EXCLUDE_FEATURES", "mdi:minus-circle", "red", "Features to exclude"),
            _build_config_upload_card("FEATURE_MAP", "mdi:map", "blue", "Rename/transform features"),
            _build_config_upload_card("TABLE_MAP", "mdi:table-multiple", "cyan", "Define join logic"),
            _build_config_upload_card("METHOD_CONFIG", "mdi:brain", "grape", "Configure algorithms"),
        ],
    ),
    html.Div(id="config-upload-status"),

    # ══════════════════════════════════════════════════════════════════
    # SECTION 5: LOADED TABLES SUMMARY (after config, with actions)
    # ══════════════════════════════════════════════════════════════════
    dmc.Paper([
        dmc.Group([
            dmc.Text("Loaded Tables Summary", fw=700, size="lg"),
            dmc.Group([
                dmc.Button("Export All", id="ds-btn-export-all",
                           leftSection=DashIconify(icon="mdi:download", width=14),
                           color="cyan", size="xs", variant="light"),
                dmc.Button("Delete All", id="ds-btn-delete-all",
                           leftSection=DashIconify(icon="mdi:trash-can", width=14),
                           color="red", size="xs", variant="light"),
            ], gap="xs"),
        ], justify="space-between", mb="xs"),
        dmc.Text("All 12 slots + any custom tables — with status, record counts, and joinability", size="xs", c="dimmed", mb="sm"),
        html.Div(id="ds-summary-table"),
    ], p="md", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD}, mb="md"),

    # ── STATS ROW ─────────────────────────────────────────────────────
    html.Div(id="ds-source-stats"),
    dmc.Space(h="sm"),

    # ══════════════════════════════════════════════════════════════════
    # CROSS-TABLE CONSISTENCY & INTEGRATION CHECK
    # ══════════════════════════════════════════════════════════════════
    dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:check-network", width=20, color="#22b8cf"),
            dmc.Text("Cross-Table Consistency & Integration", fw=700, size="lg"),
        ], gap="xs", mb="xs"),
        dmc.Text("Referential integrity, key overlap, column sharing, data quality", size="xs", c="dimmed", mb="sm"),
        html.Div(id="ds-consistency-check"),
    ], p="md", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD}, mb="md"),

    # ── TABLE PREVIEWS (Tabbed) ───────────────────────────────────────
    html.Div(id="ds-table-previews"),
    dmc.Space(h="sm"),

    # ══════════════════════════════════════════════════════════════════
    # CUSTOMER-LEVEL COMBINED AGGREGATE TABLE (LAST SECTION)
    # ══════════════════════════════════════════════════════════════════
    html.Div(id="ds-customer-aggregate"),

    # Hidden components
    dcc.Download(id="ds-download-export"),
    dcc.Download(id="ds-download-single"),
    dcc.Store(id="ds-upload-trigger", data=0),
    dcc.Store(id="ds-final-data-store", data=None),
    dcc.Store(id="ds-slot-refresh", data=0),
    dcc.Upload(id="ds-upload-exclude", style={"display": "none"}),
    html.Div(id="ds-exclude-status", style={"display": "none"}),
    # Hidden: legacy upload IDs (callbacks still reference these)
    dcc.Upload(id="upload-master-table", style={"display": "none"}),
    html.Div(id="master-upload-status", style={"display": "none"}),
    dcc.Upload(id="upload-additional-tables", style={"display": "none"}, multiple=True),
    html.Div(id="additional-upload-status", style={"display": "none"}),
], fluid=True)


# =============================================================================
# CALLBACKS
# =============================================================================

# ── CALLBACK: MASTER Table Upload ────────────────────────────────────
@callback(
    Output("master-upload-status", "children"),
    Output("ds-summary-table", "children"),
    Output("ds-source-stats", "children"),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input("upload-master-table", "contents"),
    State("upload-master-table", "filename"),
    State("ds-execution-choice", "value"),
    prevent_initial_call=True,
)
def upload_master_table(contents, filename, execution_choice):
    """Handle MASTER table upload with validation."""
    from utils.data_io import data_vault

    if contents is None:
        raise dash.exceptions.PreventUpdate

    try:
        df = _parse_upload(contents, filename)
        is_valid, error_msg = validate_master_table(df)

        if not is_valid:
            err = dmc.Alert(error_msg, color="red", icon=DashIconify(icon="mdi:alert-circle"))
            return err, dash.no_update, dash.no_update, dash.no_update, dash.no_update

        detector = SchemaDetector()
        schema_profiles = detector.detect_schema(df)
        usable_cols = detector.get_usable_columns(schema_profiles)

        sources_dir = PATHS.DATA_VAULT / "sources"
        sources_dir.mkdir(parents=True, exist_ok=True)
        df.to_parquet(sources_dir / "MASTER.parquet", index=False)

        data_vault._sources["MASTER"] = df
        meta = data_vault.get_metadata()
        meta["master_uploaded"] = True
        meta["master_columns"] = list(df.columns)
        meta["master_usable_columns"] = usable_cols
        meta["data_type"] = execution_choice or "actual"
        actual_tables = set(meta.get("actual_tables", []))
        actual_tables.add("MASTER")
        meta["actual_tables"] = list(actual_tables)
        data_vault._metadata = meta
        data_vault.save_metadata()

        status_alert = dmc.Alert(
            f"MASTER uploaded: {len(df):,} rows, {len(usable_cols)} usable cols",
            color="green", icon=DashIconify(icon="mdi:check-circle"),
        )
        exec_info = dmc.Stack([
            dmc.Group([
                DashIconify(icon="mdi:check-circle", width=14, color="#51cf66"),
                dmc.Text(f"MASTER Ready - {len(df):,} rows", size="xs", fw=600, c="green"),
            ], gap=4),
        ], gap=0)

        sources = data_vault.load_sources()
        return (status_alert, _build_loaded_summary(sources, data_vault),
                _build_stats(sources, data_vault), exec_info, False)

    except Exception as e:
        err = dmc.Alert(f"Error: {str(e)[:100]}", color="red", icon=DashIconify(icon="mdi:alert"))
        return err, dash.no_update, dash.no_update, dash.no_update, dash.no_update


# ── CALLBACK: Additional Tables Upload (bulk) ───────────────────────
@callback(
    Output("additional-upload-status", "children"),
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children"),
    Output("ds-consistency-check", "children"),
    Output("ds-customer-aggregate", "children"),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input("upload-additional-tables", "contents"),
    State("upload-additional-tables", "filename"),
    State("ds-execution-choice", "value"),
    prevent_initial_call=True,
)
def upload_additional_tables(contents_list, filenames_list, execution_choice):
    """Handle additional table uploads (unlimited, any name)."""
    from utils.data_io import data_vault

    if not contents_list:
        raise dash.exceptions.PreventUpdate

    if not isinstance(contents_list, list):
        contents_list, filenames_list = [contents_list], [filenames_list]

    msgs = []
    uploaded = []
    for contents, filename in zip(contents_list, filenames_list):
        try:
            df = _parse_upload(contents, filename)
            table_name = filename.rsplit(".", 1)[0]
            can_join = can_join_to_master(df)

            sources_dir = PATHS.DATA_VAULT / "sources"
            sources_dir.mkdir(parents=True, exist_ok=True)
            df.to_parquet(sources_dir / f"{table_name}.parquet", index=False)
            data_vault._sources[table_name] = df
            uploaded.append(table_name)

            join_status = "joinable" if can_join else "standalone"
            msgs.append(dmc.Alert(
                f"{table_name}: {len(df):,} rows ({join_status})",
                color="green", variant="light",
            ))
        except Exception as e:
            msgs.append(dmc.Alert(f"{filename}: {str(e)[:60]}", color="red", variant="light"))

    if uploaded:
        meta = data_vault.get_metadata()
        actual_tables = set(meta.get("actual_tables", []))
        actual_tables.update(uploaded)
        meta["actual_tables"] = list(actual_tables)
        data_vault._metadata = meta
        data_vault.save_metadata()
        if "MASTER" in data_vault._sources:
            _rebuild_merged(data_vault)

    sources = data_vault.load_sources()
    exec_info = dash.no_update
    confirm_disabled = dash.no_update
    if execution_choice == "actual" and sources:
        exec_info = dmc.Stack([
            dmc.Group([
                DashIconify(icon="mdi:check-circle", width=14, color="#51cf66"),
                dmc.Text(f"{len(sources)} tables loaded", size="xs", fw=600, c="green"),
            ], gap=4),
        ], gap=0)
        confirm_disabled = False

    _, cust_agg_display = _build_customer_aggregate(sources)

    return (dmc.Stack(msgs, gap="xs"),
            _build_loaded_summary(sources, data_vault),
            _build_stats(sources, data_vault),
            _build_preview_tabs(sources),
            _build_consistency_check(sources),
            cust_agg_display or "",
            exec_info, confirm_disabled)


# ── CALLBACK: Per-Slot Upload (12 table slots) ──────────────────────
@callback(
    Output({"type": "slot-status", "slot": ALL}, "children", allow_duplicate=True),
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-consistency-check", "children", allow_duplicate=True),
    Output("ds-customer-aggregate", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input({"type": "slot-upload", "slot": ALL}, "contents"),
    State({"type": "slot-upload", "slot": ALL}, "filename"),
    State({"type": "slot-upload", "slot": ALL}, "id"),
    prevent_initial_call=True,
)
def handle_slot_upload(contents_list, filenames_list, ids_list):
    """Handle upload to a specific table slot (ALL pattern)."""
    from utils.data_io import data_vault

    # Determine which slot triggered
    triggered = ctx.triggered_id
    if triggered is None:
        raise dash.exceptions.PreventUpdate

    slot_name = triggered["slot"]

    # Find the index of the triggered slot
    idx = None
    for i, id_dict in enumerate(ids_list):
        if id_dict["slot"] == slot_name:
            idx = i
            break
    if idx is None or contents_list[idx] is None:
        raise dash.exceptions.PreventUpdate

    contents = contents_list[idx]
    filename = filenames_list[idx]

    try:
        df = _parse_upload(contents, filename)

        # Validate MASTER if that's the slot
        if slot_name == "MASTER":
            is_valid, error_msg = validate_master_table(df)
            if not is_valid:
                statuses = [dash.no_update] * len(ids_list)
                statuses[idx] = dmc.Text("Invalid", size="10px", c="red", ta="center")
                return statuses, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update

        sources_dir = PATHS.DATA_VAULT / "sources"
        sources_dir.mkdir(parents=True, exist_ok=True)
        df.to_parquet(sources_dir / f"{slot_name}.parquet", index=False)
        data_vault._sources[slot_name] = df

        meta = data_vault.get_metadata()
        actual_tables = set(meta.get("actual_tables", []))
        actual_tables.add(slot_name)
        meta["actual_tables"] = list(actual_tables)
        if slot_name == "MASTER":
            meta["master_uploaded"] = True
            detector = SchemaDetector()
            schema_profiles = detector.detect_schema(df)
            meta["master_usable_columns"] = detector.get_usable_columns(schema_profiles)
        data_vault._metadata = meta
        data_vault.save_metadata()

        if "MASTER" in data_vault._sources and slot_name != "MASTER":
            _rebuild_merged(data_vault)

        sources = data_vault.load_sources()

        # Build slot statuses for ALL slots
        slot_statuses = []
        for id_dict in ids_list:
            sn = id_dict["slot"]
            if sn in sources:
                df_s = sources[sn]
                slot_statuses.append(dmc.Text(f"{len(df_s):,} rows", size="10px", c="green", ta="center", fw=600))
            else:
                slot_statuses.append(dmc.Text("Empty", size="10px", c="dimmed", ta="center"))

        _, cust_agg_display = _build_customer_aggregate(sources)

        # Auto-enable confirm when data is available
        confirm_disabled = len(sources) == 0

        return (slot_statuses,
                _build_loaded_summary(sources, data_vault),
                _build_stats(sources, data_vault),
                _build_preview_tabs(sources),
                _build_consistency_check(sources),
                cust_agg_display or "",
                confirm_disabled)

    except Exception as e:
        statuses = [dash.no_update] * len(ids_list)
        statuses[idx] = dmc.Text("Error", size="10px", c="red", ta="center")
        return statuses, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update


# ── CALLBACK: Per-Slot Export ────────────────────────────────────────
@callback(
    Output("ds-download-single", "data"),
    Input({"type": "slot-export", "slot": ALL}, "n_clicks"),
    State({"type": "slot-export", "slot": ALL}, "id"),
    prevent_initial_call=True,
)
def handle_slot_export(n_clicks_list, ids_list):
    """Export a single table as CSV."""
    from utils.data_io import data_vault

    # Find which button was clicked
    triggered = ctx.triggered_id
    if triggered is None:
        raise dash.exceptions.PreventUpdate

    slot_name = triggered["slot"]
    sources = data_vault.load_sources()

    if slot_name not in sources:
        raise dash.exceptions.PreventUpdate

    df = sources[slot_name]
    csv_string = df.to_csv(index=False)
    return dict(content=csv_string, filename=f"{slot_name}.csv")


# ── CALLBACK: Per-Slot Delete ────────────────────────────────────────
@callback(
    Output({"type": "slot-status", "slot": ALL}, "children", allow_duplicate=True),
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-consistency-check", "children", allow_duplicate=True),
    Output("ds-customer-aggregate", "children", allow_duplicate=True),
    Output("ds-status-output", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input({"type": "slot-delete", "slot": ALL}, "n_clicks"),
    State({"type": "slot-delete", "slot": ALL}, "id"),
    prevent_initial_call=True,
)
def handle_slot_delete(n_clicks_list, ids_list):
    """Delete a single table from its slot."""
    from utils.data_io import data_vault

    triggered = ctx.triggered_id
    if triggered is None:
        raise dash.exceptions.PreventUpdate

    slot_name = triggered["slot"]

    # Check if any button was actually clicked
    all_none = all(nc is None for nc in n_clicks_list)
    if all_none:
        raise dash.exceptions.PreventUpdate

    # Remove from vault
    if slot_name in data_vault._sources:
        del data_vault._sources[slot_name]

    # Remove parquet file
    parquet_file = PATHS.DATA_VAULT / "sources" / f"{slot_name}.parquet"
    if parquet_file.exists():
        parquet_file.unlink()

    # Update metadata
    meta = data_vault.get_metadata()
    actual_tables = set(meta.get("actual_tables", []))
    actual_tables.discard(slot_name)
    meta["actual_tables"] = list(actual_tables)
    if slot_name == "MASTER":
        meta["master_uploaded"] = False
    data_vault._metadata = meta
    data_vault.save_metadata()

    sources = data_vault.load_sources()

    # Build slot status for ALL slots
    slot_statuses = []
    for id_dict in ids_list:
        sn = id_dict["slot"]
        if sn in sources:
            df = sources[sn]
            slot_statuses.append(dmc.Text(f"{len(df):,} rows", size="10px", c="green", ta="center", fw=600))
        else:
            slot_statuses.append(dmc.Text("Empty", size="10px", c="dimmed", ta="center"))

    status_msg = dmc.Alert(
        f"Deleted: {slot_name}", color="orange",
        icon=DashIconify(icon="mdi:check"), withCloseButton=True,
    )

    _, cust_agg_display = _build_customer_aggregate(sources)

    # Disable confirm if no data remains
    confirm_disabled = len(sources) == 0

    return (slot_statuses,
            _build_loaded_summary(sources, data_vault),
            _build_stats(sources, data_vault),
            _build_preview_tabs(sources),
            _build_consistency_check(sources),
            cust_agg_display or "",
            status_msg,
            confirm_disabled)


# ── CALLBACK: Generate / Reset ───────────────────────────────────────
@callback(
    Output("ds-status-output", "children", allow_duplicate=True),
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-consistency-check", "children", allow_duplicate=True),
    Output("ds-customer-aggregate", "children", allow_duplicate=True),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Output("ds-execution-choice", "value", allow_duplicate=True),
    Output({"type": "slot-status", "slot": ALL}, "children", allow_duplicate=True),
    Input("ds-btn-generate", "n_clicks"),
    Input("ds-btn-reset", "n_clicks"),
    State("ds-customer-count", "value"),
    State("ds-execution-choice", "value"),
    State({"type": "slot-status", "slot": ALL}, "id"),
    prevent_initial_call=True,
)
def handle_gen_reset(n_gen, n_reset, num_customers, execution_choice, slot_ids):
    """Generate sample data or reset vault."""
    from utils.data_gen import DataGenerator
    from utils.data_io import data_vault

    triggered = ctx.triggered_id
    status_msg = None
    exec_info = dash.no_update
    confirm_disabled = dash.no_update
    choice_value = dash.no_update

    if triggered == "ds-btn-reset":
        data_vault.clear_data()
        sources_dir = PATHS.DATA_VAULT / "sources"
        if sources_dir.exists():
            for f in sources_dir.glob("*.parquet"):
                f.unlink()
        for f in PATHS.DATA_SOURCES.glob("*.csv"):
            f.unlink()
        status_msg = dmc.Alert("All data cleared.", color="orange",
                               icon=DashIconify(icon="mdi:check"), withCloseButton=True)
        exec_info = dmc.Stack([
            dmc.Group([
                DashIconify(icon="mdi:alert-circle", width=14, color="#ffd43b"),
                dmc.Text("No Data Available", size="xs", fw=600, c="yellow"),
            ], gap=4),
        ], gap=0)
        confirm_disabled = True
        choice_value = "sample"

    if triggered == "ds-btn-generate":
        try:
            num_customers = num_customers or 100
            dg = DataGenerator()
            schema = dg.generate_full_schema(num_customers)

            data_vault.save_sources(schema)
            meta = data_vault.get_metadata()
            meta["data_type"] = "sample"
            meta["sample_tables"] = list(schema.keys())
            data_vault._metadata = meta
            data_vault.save_metadata()

            PATHS.DATA_SOURCES.mkdir(parents=True, exist_ok=True)
            for name, df in schema.items():
                df.to_csv(PATHS.DATA_SOURCES / f"{name}.csv", index=False)

            # Build merged view using MASTER (now generated with all 12 tables)
            if "MASTER" in data_vault._sources:
                _rebuild_merged(data_vault)
            else:
                # Fallback: merge transactions + accounts + customer_party
                df_tx = schema.get("transactions", pd.DataFrame())
                df_acc = schema.get("accounts", pd.DataFrame())
                df_party = schema.get("customer_party", pd.DataFrame())
                df_merged = df_tx.copy() if not df_tx.empty else pd.DataFrame()
                if not df_merged.empty and not df_acc.empty and "account_id" in df_tx.columns and "account_id" in df_acc.columns:
                    df_merged = df_merged.merge(df_acc, on="account_id", how="left", suffixes=("", "_acc"))
                if not df_merged.empty and not df_party.empty and "party_id" in df_merged.columns and "party_id" in df_party.columns:
                    df_merged = df_merged.merge(df_party, on="party_id", how="left", suffixes=("", "_party"))
                if not df_merged.empty:
                    data_vault.set_current_data(df_merged, label=f"generated_{num_customers}_cust")

            total_rows = sum(len(v) for v in schema.values())
            status_msg = dmc.Alert(
                f"Generated {num_customers} customers -> {total_rows:,} rows across {len(schema)} tables.",
                color="green", icon=DashIconify(icon="mdi:check-circle"), withCloseButton=True,
            )

            # Auto-switch to sample mode and enable confirm
            choice_value = "sample"
            table_preview = ", ".join(list(schema.keys())[:5])
            exec_info = dmc.Stack([
                dmc.Group([
                    DashIconify(icon="mdi:check-circle", width=14, color="#51cf66"),
                    dmc.Text(f"Sample Ready - {len(schema)} tables", size="xs", fw=600, c="cyan"),
                ], gap=4),
                dmc.Text(table_preview, size="xs", c="dimmed"),
            ], gap=0)
            confirm_disabled = False

        except Exception as e:
            status_msg = dmc.Alert(f"Generation error: {e}", color="red",
                                   icon=DashIconify(icon="mdi:alert"))

    sources = data_vault.load_sources()

    # Build slot statuses for all 12 slots
    slot_statuses = []
    for id_dict in slot_ids:
        sn = id_dict["slot"]
        if sn in sources:
            df = sources[sn]
            slot_statuses.append(dmc.Text(f"{len(df):,} rows", size="10px", c="green", ta="center", fw=600))
        else:
            slot_statuses.append(dmc.Text("Empty", size="10px", c="dimmed", ta="center"))

    _, cust_agg_display = _build_customer_aggregate(sources)

    return (status_msg,
            _build_loaded_summary(sources, data_vault),
            _build_stats(sources, data_vault),
            _build_preview_tabs(sources),
            _build_consistency_check(sources),
            cust_agg_display or "",
            exec_info, confirm_disabled,
            choice_value,
            slot_statuses)


# ── CALLBACK: Execution Choice ───────────────────────────────────────
@callback(
    Output("ds-execution-info", "children"),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input("ds-execution-choice", "value"),
    prevent_initial_call='initial_duplicate',
)
def update_execution_info(choice):
    """Update info based on selected data source."""
    from utils.data_io import data_vault

    sources = data_vault.load_sources()
    meta = data_vault.get_metadata()

    # Filter out derived tables (customer_aggregate) from the count
    real_sources = {k: v for k, v in sources.items() if k != "customer_aggregate"}

    if choice == "sample":
        # Check sources directly — don't rely only on metadata sample_tables
        sample_tables = meta.get("sample_tables", [])
        # Count tables that actually exist in sources — whether in sample_tables or not
        count = len(real_sources)
        if count > 0:
            names = list(real_sources.keys())
            preview = ", ".join(names[:4]) + (f" +{len(names)-4}" if len(names) > 4 else "")
            return dmc.Stack([
                dmc.Group([
                    DashIconify(icon="mdi:check-circle", width=14, color="#51cf66"),
                    dmc.Text(f"Sample Ready - {count} tables", size="xs", fw=600, c="cyan"),
                ], gap=4),
                dmc.Text(preview, size="xs", c="dimmed"),
            ], gap=0), False
        return dmc.Text("No sample data. Click Generate.", size="xs", c="yellow"), True

    elif choice == "actual":
        count = len(real_sources)
        if count > 0:
            return dmc.Stack([
                dmc.Group([
                    DashIconify(icon="mdi:check-circle", width=14, color="#51cf66"),
                    dmc.Text(f"Actual Ready - {count} tables", size="xs", fw=600, c="green"),
                ], gap=4),
            ], gap=0), False
        return dmc.Text("No actual data. Upload above.", size="xs", c="yellow"), True

    return dmc.Text("Select data source", size="xs", c="dimmed"), True


# ── CALLBACK: Confirm Final ──────────────────────────────────────────
@callback(
    Output("ds-status-output", "children", allow_duplicate=True),
    Output("ds-final-data-store", "data"),
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-consistency-check", "children", allow_duplicate=True),
    Output("ds-customer-aggregate", "children", allow_duplicate=True),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Output({"type": "slot-status", "slot": ALL}, "children", allow_duplicate=True),
    Input("ds-btn-confirm-final", "n_clicks"),
    State("ds-execution-choice", "value"),
    State({"type": "slot-status", "slot": ALL}, "id"),
    prevent_initial_call=True,
)
def confirm_final_data(n_clicks, choice, slot_ids):
    """Confirm data selection and refresh ALL downstream sections."""
    from utils.data_io import data_vault

    if not n_clicks:
        raise dash.exceptions.PreventUpdate

    if not choice:
        empty_slots = [dash.no_update] * len(slot_ids) if slot_ids else []
        return (dmc.Alert("Select Sample or Actual.", color="orange"), None,
                dash.no_update, dash.no_update, dash.no_update,
                dash.no_update, dash.no_update,
                dash.no_update, dash.no_update, empty_slots)

    try:
        # Persist the choice
        meta = data_vault.get_metadata()
        meta["final_data_choice"] = choice
        meta["data_type"] = choice
        data_vault._metadata = meta
        data_vault.save_metadata()

        # Rebuild merged current_data based on choice
        sources = data_vault.load_sources()

        if "MASTER" in sources:
            # Best path: use _rebuild_merged which joins MASTER with all related tables
            _rebuild_merged(data_vault)
        elif choice == "sample":
            # Fallback: merge transactions + accounts + customer_party
            df_tx = sources.get("transactions", pd.DataFrame())
            df_acc = sources.get("accounts", pd.DataFrame())
            df_party = sources.get("customer_party", pd.DataFrame())
            if not df_tx.empty:
                df_merged = df_tx.copy()
                if not df_acc.empty and "account_id" in df_tx.columns and "account_id" in df_acc.columns:
                    df_merged = df_merged.merge(df_acc, on="account_id", how="left", suffixes=("", "_acc"))
                if not df_party.empty and "party_id" in df_merged.columns and "party_id" in df_party.columns:
                    df_merged = df_merged.merge(df_party, on="party_id", how="left", suffixes=("", "_party"))
                data_vault.set_current_data(df_merged, label="sample_confirmed")
        else:
            # Actual data — rebuild merged from MASTER + additional
            if sources:
                biggest = max(sources.values(), key=len)
                data_vault.set_current_data(biggest, label="actual_fallback")

        # Build slot statuses for ALL 12 slots
        slot_statuses = []
        for id_dict in slot_ids:
            sn = id_dict["slot"]
            if sn in sources:
                df_s = sources[sn]
                slot_statuses.append(dmc.Text(f"{len(df_s):,} rows", size="10px", c="green", ta="center", fw=600))
            else:
                slot_statuses.append(dmc.Text("Empty", size="10px", c="dimmed", ta="center"))

        total_tables = len(sources)
        total_rows = sum(len(df) for df in sources.values())
        label = "Sample Data" if choice == "sample" else "Actual Data"

        status = dmc.Alert(
            f"Confirmed: {label} — {total_tables} tables, {total_rows:,} total rows",
            color="green", icon=DashIconify(icon="mdi:check-circle"), withCloseButton=True,
        )
        store_data = {
            "choice": choice, "label": label,
            "tables": total_tables, "rows": total_rows,
            "timestamp": pd.Timestamp.now().isoformat(),
        }

        exec_confirmed = dmc.Stack([
            dmc.Group([
                DashIconify(icon="mdi:check-decagram", width=16, color="#51cf66"),
                dmc.Text(f"Confirmed: {label}", size="xs", fw=700, c="green"),
            ], gap=4),
            dmc.Text(f"{total_tables} tables | {total_rows:,} rows", size="10px", c="dimmed"),
        ], gap=2)

        # Build and save customer aggregate
        cust_agg_df, cust_agg_display = _build_customer_aggregate(sources)
        if cust_agg_df is not None:
            # Save aggregate to vault for downstream pages
            sources_dir = PATHS.DATA_VAULT / "sources"
            sources_dir.mkdir(parents=True, exist_ok=True)
            cust_agg_df.to_parquet(sources_dir / "customer_aggregate.parquet", index=False)
            data_vault._sources["customer_aggregate"] = cust_agg_df

        return (status, store_data,
                _build_loaded_summary(sources, data_vault),
                _build_stats(sources, data_vault),
                _build_preview_tabs(sources),
                _build_consistency_check(sources),
                cust_agg_display or "",
                exec_confirmed, False,
                slot_statuses)

    except Exception as e:
        empty_slots = [dash.no_update] * len(slot_ids) if slot_ids else []
        return (dmc.Alert(f"Confirm error: {str(e)[:200]}", color="red",
                          icon=DashIconify(icon="mdi:alert-circle")),
                None, dash.no_update, dash.no_update, dash.no_update,
                dash.no_update, dash.no_update,
                dash.no_update, False, empty_slots)


# ── CALLBACK: Init Page Load ────────────────────────────────────────
@callback(
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-consistency-check", "children", allow_duplicate=True),
    Output("ds-customer-aggregate", "children", allow_duplicate=True),
    Output("ds-execution-choice", "value", allow_duplicate=True),
    Output({"type": "slot-status", "slot": ALL}, "children", allow_duplicate=True),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input("ds-upload-trigger", "data"),
    State({"type": "slot-status", "slot": ALL}, "id"),
    prevent_initial_call='initial_duplicate',
)
def init_page_load(trigger, slot_ids):
    """Load existing data on page load — auto-enable confirm if data available."""
    from utils.data_io import data_vault
    sources = data_vault.load_sources()
    meta = data_vault.get_metadata()
    final_choice = meta.get("final_data_choice", "sample")

    slot_statuses = []
    for id_dict in slot_ids:
        sn = id_dict["slot"]
        if sn in sources:
            df = sources[sn]
            slot_statuses.append(dmc.Text(f"{len(df):,} rows", size="10px", c="green", ta="center", fw=600))
        else:
            slot_statuses.append(dmc.Text("Empty", size="10px", c="dimmed", ta="center"))

    # Auto-enable confirm when data is already available
    if sources:
        total = len(sources)
        total_rows = sum(len(df) for df in sources.values())
        label = "Sample" if final_choice == "sample" else "Actual"
        names = list(sources.keys())
        preview = ", ".join(names[:4]) + (f" +{len(names)-4}" if len(names) > 4 else "")
        exec_info = dmc.Stack([
            dmc.Group([
                DashIconify(icon="mdi:check-circle", width=14, color="#51cf66"),
                dmc.Text(f"{label} Ready - {total} tables, {total_rows:,} rows", size="xs", fw=600, c="cyan"),
            ], gap=4),
            dmc.Text(preview, size="xs", c="dimmed"),
        ], gap=0)
        confirm_disabled = False
    else:
        exec_info = dmc.Stack([
            dmc.Group([
                DashIconify(icon="mdi:alert-circle", width=14, color="#ffd43b"),
                dmc.Text("No Data Available", size="xs", fw=600, c="yellow"),
            ], gap=4),
        ], gap=0)
        confirm_disabled = True

    _, cust_agg_display = _build_customer_aggregate(sources)

    return (_build_loaded_summary(sources, data_vault),
            _build_stats(sources, data_vault),
            _build_preview_tabs(sources),
            _build_consistency_check(sources),
            cust_agg_display or "",
            final_choice,
            slot_statuses,
            exec_info,
            confirm_disabled)


# ── CALLBACK: Schema Docs Modal ─────────────────────────────────────
@callback(
    Output("modal-schema-docs", "opened"),
    Input("btn-open-schema-docs", "n_clicks"),
    State("modal-schema-docs", "opened"),
    prevent_initial_call=True,
)
def toggle_schema_docs_modal(n_clicks, opened):
    return not opened


# ── CALLBACK: Config Table Uploads ───────────────────────────────────
@callback(
    Output({"type": "config-status", "name": ALL}, "children"),
    Output("config-upload-status", "children"),
    Input({"type": "upload-config", "name": ALL}, "contents"),
    State({"type": "upload-config", "name": ALL}, "id"),
    prevent_initial_call=True,
)
def handle_config_uploads(contents_list, ids_list):
    """Handle optional config table uploads."""
    from utils.data_io import data_vault

    status_outputs = [None] * len(contents_list)
    overall = []

    for i, (contents, id_dict) in enumerate(zip(contents_list, ids_list)):
        if contents is None:
            continue
        config_name = id_dict["name"]
        try:
            content_string = contents.split(",")[1]
            decoded = base64.b64decode(content_string)
            df = pd.read_csv(io.StringIO(decoded.decode("utf-8")))

            config_dir = PATHS.DATA_VAULT / "config"
            config_dir.mkdir(parents=True, exist_ok=True)
            df.to_parquet(config_dir / f"{config_name}.parquet", index=False)

            meta = data_vault.get_metadata()
            config_tables = meta.get("config_tables", {})
            config_tables[config_name] = {"loaded": True, "rows": len(df)}
            meta["config_tables"] = config_tables
            data_vault._metadata = meta
            data_vault.save_metadata()

            status_outputs[i] = dmc.Text(f"{len(df)} rows", size="xs", c="green")
            overall.append(dmc.Alert(f"{config_name}: {len(df)} rules loaded", color="green", variant="light"))
        except Exception as e:
            status_outputs[i] = dmc.Text("Error", size="xs", c="red")
            overall.append(dmc.Alert(f"{config_name}: {str(e)[:50]}", color="red", variant="light"))

    return status_outputs, dmc.Stack(overall, gap="xs") if overall else dash.no_update


# ── CALLBACK: Export All ─────────────────────────────────────────────
@callback(
    Output("ds-download-export", "data"),
    Input("ds-btn-export-all", "n_clicks"),
    prevent_initial_call=True,
)
def export_all_tables(n_clicks):
    """Export all loaded tables as a ZIP of CSVs."""
    from utils.data_io import data_vault

    sources = data_vault.load_sources()
    if not sources:
        raise dash.exceptions.PreventUpdate

    zip_path = PATHS.DATA_VAULT / "export_all_tables.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, df in sources.items():
            zf.writestr(f"{name}.csv", df.to_csv(index=False).encode("utf-8"))

    return dcc.send_file(str(zip_path), filename="all_tables_export.zip")


# ── CALLBACK: Delete All ─────────────────────────────────────────────
@callback(
    Output("ds-status-output", "children", allow_duplicate=True),
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-consistency-check", "children", allow_duplicate=True),
    Output("ds-customer-aggregate", "children", allow_duplicate=True),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Output("ds-execution-choice", "value", allow_duplicate=True),
    Output("ds-final-data-store", "data", allow_duplicate=True),
    Output({"type": "slot-status", "slot": ALL}, "children", allow_duplicate=True),
    Input("ds-btn-delete-all", "n_clicks"),
    State({"type": "slot-status", "slot": ALL}, "id"),
    prevent_initial_call=True,
)
def delete_all_data(n_clicks, slot_ids):
    """Delete all loaded data and reset vault."""
    from utils.data_io import data_vault

    data_vault.clear_data()
    sources_dir = PATHS.DATA_VAULT / "sources"
    if sources_dir.exists():
        for f in sources_dir.glob("*.parquet"):
            f.unlink()
    for f in PATHS.DATA_SOURCES.glob("*.csv"):
        f.unlink()

    status = dmc.Alert("All data deleted.", color="orange",
                       icon=DashIconify(icon="mdi:check"), withCloseButton=True)
    exec_info = dmc.Stack([
        dmc.Group([
            DashIconify(icon="mdi:alert-circle", width=14, color="#ffd43b"),
            dmc.Text("No Data Available", size="xs", fw=600, c="yellow"),
        ], gap=4),
    ], gap=0)

    empty = {}
    slot_statuses = [dmc.Text("Empty", size="10px", c="dimmed", ta="center") for _ in slot_ids]

    return (status,
            _build_loaded_summary(empty, data_vault),
            _build_stats(empty, data_vault),
            _build_preview_tabs(empty),
            _build_consistency_check(empty),
            "",
            exec_info, True, "sample", None, slot_statuses)


# ── CALLBACK: Exclude variable upload ────────────────────────────────
@callback(
    Output("ds-exclude-status", "children"),
    Input("ds-upload-exclude", "contents"),
    State("ds-upload-exclude", "filename"),
    prevent_initial_call=True,
)
def handle_exclude_upload(contents, filename):
    if contents is None:
        return ""
    try:
        from utils.data_io import data_vault
        content_type, content_string = contents.split(",")
        decoded = base64.b64decode(content_string)
        if filename.endswith((".xlsx", ".xls")):
            df = pd.read_excel(io.BytesIO(decoded))
        elif filename.endswith(".csv"):
            df = pd.read_csv(io.StringIO(decoded.decode("utf-8")))
        else:
            return dmc.Alert("Unsupported. Use CSV or Excel.", color="red")
        var_list = (df["variable"].dropna().astype(str).tolist()
                    if "variable" in df.columns
                    else df.iloc[:, 0].dropna().astype(str).tolist())
        with open(PATHS.DATA_VAULT / "exclude_vars.json", "w") as f:
            json.dump(var_list, f)
        return dmc.Alert(f"{len(var_list)} variables loaded for exclusion", color="green",
                         icon=DashIconify(icon="mdi:check-circle"))
    except Exception as e:
        return dmc.Alert(f"Error: {e}", color="red")


# =============================================================================
# HELPER: Rebuild merged view
# =============================================================================
def _rebuild_merged(data_vault):
    """Rebuild merged view from MASTER + additional tables."""
    sources = data_vault.load_sources()
    if "MASTER" not in sources:
        return
    df_master = sources["MASTER"].copy()
    pk_col = resolve(df_master, 'primary_key')
    if pk_col is None:
        return
    for table_name, df_table in sources.items():
        if table_name == "MASTER":
            continue
        tpk = resolve(df_table, 'primary_key')
        if tpk and pk_col:
            try:
                df_master = df_master.merge(
                    df_table, left_on=pk_col, right_on=tpk,
                    how="left", suffixes=("", f"_{table_name}")
                )
            except Exception:
                pass
    data_vault.set_current_data(df_master, label="master_merged")

