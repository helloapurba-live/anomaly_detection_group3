"""
V8: Column Resolver — Zero Hardcoded Column Names
==================================================
Central utility that resolves semantic ROLES to actual DataFrame column names.
Every layer and page uses this instead of hardcoding "cust_id" / "amount" etc.

Usage:
    from utils.column_resolver import resolve, resolve_many, resolve_or_fail

    amount_col = resolve(df, "amount")       # Returns actual col name or None
    cols = resolve_many(df, ["amount", "timestamp", "primary_key"])
"""

import sys
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import COLUMNS


def resolve(df: pd.DataFrame, role: str) -> Optional[str]:
    """
    Resolve a semantic role to the actual column name present in *df*.

    Args:
        df: DataFrame whose columns will be searched.
        role: One of the keys in COLUMNS.ROLE_ALIASES (e.g. "amount", "primary_key").

    Returns:
        The actual column name or None if no match found.
    """
    return COLUMNS.resolve(df.columns.tolist(), role)


def resolve_many(df: pd.DataFrame, roles: List[str]) -> Dict[str, Optional[str]]:
    """
    Resolve multiple roles at once.

    Returns:
        Dict  role -> actual_column_name  (value is None when unresolved).
    """
    cols = df.columns.tolist()
    return {role: COLUMNS.resolve(cols, role) for role in roles}


def resolve_or_fail(df: pd.DataFrame, role: str) -> str:
    """
    Like resolve(), but raises ValueError when the role cannot be resolved.
    Useful for mandatory roles.
    """
    col = resolve(df, role)
    if col is None:
        raise ValueError(
            f"Mandatory column role '{role}' could not be resolved. "
            f"Columns in data: {df.columns.tolist()}"
        )
    return col


def set_override(role: str, column_name: str):
    """
    Set a runtime user override (e.g. from the Data Sources UI).
    """
    COLUMNS.USER_OVERRIDES[role] = column_name


def clear_overrides():
    """Clear all user overrides."""
    COLUMNS.USER_OVERRIDES.clear()


def get_current_mappings(df: pd.DataFrame) -> Dict[str, Optional[str]]:
    """
    Return a dict of ALL known roles resolved against *df*.
    Useful for debugging and for the Admin / Data Sources page.
    """
    return resolve_many(df, list(COLUMNS.ROLE_ALIASES.keys()))
