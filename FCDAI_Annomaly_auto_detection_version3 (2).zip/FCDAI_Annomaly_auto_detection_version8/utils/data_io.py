"""
FCDAI V8 — Data I/O Module
==============================
Handles multi-table source persistence, pipeline result persistence,
scored data, export with anomaly scorecards, and V8 enhancements:
- Vault reload from disk (cross-page sync)
- PII masking at storage level
- Run versioning with UUID and config snapshots
- Data lineage hashing

All data stored as Parquet in the vault directory.  Pipeline results
stored as JSON.  Data is persistent across page refreshes and server
restarts — only cleared on explicit reset or re-run.
"""

import os
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional, Tuple, List, Dict, Any
import pandas as pd
import numpy as np
import io
import base64
import json
import hashlib
import uuid

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import PATHS, PII, AUDIT, APP
from utils.logger import logger


class DataVault:
    """
    Local Parquet-based data persistence layer.

    Stores:
      - Source tables  (vault/sources/<table>.parquet)
      - Merged analytical view (vault/current.parquet)
      - Scored data    (vault/scored.parquet)
      - Pipeline result JSON (vault/pipeline_result.json)
      - Import metadata (vault/metadata.json)
    """

    def __init__(self):
        self._current_data: Optional[pd.DataFrame] = None
        self._scored_data: Optional[pd.DataFrame] = None
        self._sources: Dict[str, pd.DataFrame] = {}
        self._metadata: Dict[str, Any] = {}
        self._pipeline_result: Dict[str, Any] = {}
        self._load_persisted_data()

    # -----------------------------------------------------------------
    # V8: Force reload from disk (fixes cross-page sync)
    # -----------------------------------------------------------------
    def reload_from_disk(self):
        """Re-read ALL vault data from disk. Call after subprocess writes."""
        self._current_data = None
        self._scored_data = None
        self._sources = {}
        self._metadata = {}
        self._pipeline_result = {}
        self._load_persisted_data()

    # -----------------------------------------------------------------
    # Loading
    # -----------------------------------------------------------------
    def _load_persisted_data(self):
        """Load any previously persisted data from vault."""
        vault = PATHS.DATA_VAULT

        # Load raw/merged data
        vault_path = vault / "current.parquet"
        meta_path = vault / "metadata.json"
        scored_path = vault / "scored.parquet"
        result_path = vault / "pipeline_result.json"

        if vault_path.exists():
            try:
                self._current_data = pd.read_parquet(vault_path)
                if meta_path.exists():
                    with open(meta_path, 'r') as f:
                        self._metadata = json.load(f)
            except Exception as e:
                logger.log_error(e, "Loading persisted data")

        # Load scored data
        if scored_path.exists():
            try:
                self._scored_data = pd.read_parquet(scored_path)
            except Exception as e:
                logger.log_error(e, "Loading scored data")

        # Load pipeline result
        if result_path.exists():
            try:
                with open(result_path, 'r') as f:
                    self._pipeline_result = json.load(f)
            except Exception as e:
                logger.log_error(e, "Loading pipeline result")

        # Load individual source tables
        sources_dir = vault / "sources"
        if sources_dir.exists():
            for pq in sources_dir.glob("*.parquet"):
                try:
                    self._sources[pq.stem] = pd.read_parquet(pq)
                except Exception:
                    pass

    # -----------------------------------------------------------------
    # Source Tables (per-table persistence)
    # -----------------------------------------------------------------
    def save_sources(self, tables: Dict[str, pd.DataFrame]):
        """Save individual source tables to vault/sources/ as Parquet.
        V8: Optionally apply PII masking before writing."""
        sources_dir = PATHS.DATA_VAULT / "sources"
        sources_dir.mkdir(parents=True, exist_ok=True)
        self._sources = {}
        for name, df in tables.items():
            try:
                df_to_save = df
                # V8: PII masking at storage level
                if PII.MASK_AT_STORAGE:
                    from utils.pii_masking import mask_dataframe, detect_pii_columns
                    pii_cols = detect_pii_columns(df_to_save)
                    if pii_cols:
                        df_to_save = mask_dataframe(df_to_save, columns=pii_cols, enabled=True)
                df_to_save.to_parquet(sources_dir / f"{name}.parquet", index=False)
                self._sources[name] = df  # Keep unmasked in memory
            except Exception as e:
                logger.log_error(e, f"Saving source table: {name}")

    def load_sources(self) -> Dict[str, pd.DataFrame]:
        """Load all source tables from vault."""
        if not self._sources:
            sources_dir = PATHS.DATA_VAULT / "sources"
            if sources_dir.exists():
                for pq in sources_dir.glob("*.parquet"):
                    try:
                        self._sources[pq.stem] = pd.read_parquet(pq)
                    except Exception:
                        pass
        return self._sources

    def get_source_stats(self) -> Dict[str, Any]:
        """Get summary stats for loaded sources."""
        sources = self.load_sources()
        stats = {
            "table_count": len(sources),
            "tables": {},
            "total_rows": 0,
            "last_generated": self._metadata.get("import_time", None),
        }
        for name, df in sources.items():
            stats["tables"][name] = {
                "rows": len(df),
                "columns": len(df.columns),
                "column_list": df.columns.tolist(),
            }
            stats["total_rows"] += len(df)
        return stats

    # -----------------------------------------------------------------
    # Merged / Analytical View
    # -----------------------------------------------------------------
    def import_data(
        self,
        contents: str,
        filename: str
    ) -> Tuple[bool, str, Optional[pd.DataFrame]]:
        """Import data from uploaded file contents."""
        try:
            content_type, content_string = contents.split(',')
            decoded = base64.b64decode(content_string)

            if filename.endswith('.csv'):
                df = pd.read_csv(io.StringIO(decoded.decode('utf-8')))
            elif filename.endswith('.parquet'):
                df = pd.read_parquet(io.BytesIO(decoded))
            elif filename.endswith(('.xlsx', '.xls')):
                df = pd.read_excel(io.BytesIO(decoded))
            else:
                return False, f"Unsupported file type: {filename}", None

            is_valid, issues = self._validate_data(df)
            if not is_valid:
                return False, f"Validation failed: {', '.join(issues)}", None

            self._current_data = df
            self._metadata = {
                "filename": filename,
                "rows": len(df),
                "columns": len(df.columns),
                "import_time": datetime.now().isoformat(),
                "columns_list": df.columns.tolist()
            }
            self._persist_data()
            logger.log_data_import(filename, len(df), len(df.columns))
            return True, f"Successfully imported {len(df):,} rows", df

        except Exception as e:
            logger.log_error(e, f"Data import: {filename}")
            return False, f"Import error: {str(e)}", None

    def set_current_data(self, df: pd.DataFrame, label: str = "generated"):
        """Directly set the merged analytical view and persist."""
        self._current_data = df
        self._metadata = {
            "filename": label,
            "rows": len(df),
            "columns": len(df.columns),
            "import_time": datetime.now().isoformat(),
            "columns_list": df.columns.tolist(),
        }
        self._persist_data()

    def _validate_data(self, df: pd.DataFrame) -> Tuple[bool, List[str]]:
        issues = []
        if len(df) < 10:
            issues.append("Dataset has fewer than 10 rows")
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) == 0:
            issues.append("No numeric columns found for analysis")
        empty_cols = df.columns[df.isnull().all()].tolist()
        if empty_cols:
            issues.append(f"Empty columns: {empty_cols}")
        return len(issues) == 0, issues

    def _persist_data(self):
        if self._current_data is not None:
            vault = PATHS.DATA_VAULT
            try:
                self._current_data.to_parquet(vault / "current.parquet", index=False)
                with open(vault / "metadata.json", 'w') as f:
                    json.dump(self._metadata, f, indent=2)
            except Exception as e:
                logger.log_error(e, "Persisting data to vault")

    def get_data(self) -> Optional[pd.DataFrame]:
        return self._current_data

    def get_scored_data(self) -> Optional[pd.DataFrame]:
        return self._scored_data

    def set_scored_data(self, df: pd.DataFrame):
        self._scored_data = df
        try:
            df.to_parquet(PATHS.DATA_VAULT / "scored.parquet", index=False)
        except Exception as e:
            logger.log_error(e, "Persisting scored data")

    def get_metadata(self) -> Dict[str, Any]:
        return self._metadata
    
    def save_metadata(self):
        """Save metadata to vault/metadata.json."""
        try:
            with open(PATHS.DATA_VAULT / "metadata.json", 'w') as f:
                json.dump(self._metadata, f, indent=2)
        except Exception as e:
            logger.log_error(e, "Saving metadata")

    # -----------------------------------------------------------------
    # Pipeline Result Persistence
    # -----------------------------------------------------------------
    def save_pipeline_result(self, result: Dict[str, Any]):
        """Save pipeline result JSON to vault for dashboard consumption."""
        self._pipeline_result = result
        try:
            with open(PATHS.DATA_VAULT / "pipeline_result.json", 'w') as f:
                json.dump(result, f, indent=2, default=str)
        except Exception as e:
            logger.log_error(e, "Saving pipeline result")

    def load_pipeline_result(self) -> Dict[str, Any]:
        """Load last pipeline result from vault."""
        if not self._pipeline_result:
            path = PATHS.DATA_VAULT / "pipeline_result.json"
            if path.exists():
                try:
                    with open(path, 'r') as f:
                        self._pipeline_result = json.load(f)
                except Exception:
                    pass
        return self._pipeline_result

    # -----------------------------------------------------------------
    # Clear / Reset
    # -----------------------------------------------------------------
    def clear_data(self):
        """Clear ALL data from vault (sources, merged, scored, results)."""
        self._current_data = None
        self._scored_data = None
        self._sources = {}
        self._metadata = {}
        self._pipeline_result = {}

        vault = PATHS.DATA_VAULT
        for f in ["current.parquet", "scored.parquet", "metadata.json",
                   "pipeline_result.json", "pipeline_status.json"]:
            path = vault / f
            if path.exists():
                path.unlink()

        # Clear source tables
        sources_dir = vault / "sources"
        if sources_dir.exists():
            for pq in sources_dir.glob("*.parquet"):
                pq.unlink()

        logger.log_action("Data Cleared", metadata={"vault": "full_reset"})

    # -----------------------------------------------------------------
    # V8: Run Versioning & Data Lineage
    # -----------------------------------------------------------------
    def create_run_record(self, config_snapshot: Dict = None) -> str:
        """Create a new run record with UUID and config snapshot.
        Returns run_id."""
        run_id = str(uuid.uuid4())[:8]
        run_dir = PATHS.RUN_HISTORY / run_id
        run_dir.mkdir(parents=True, exist_ok=True)

        record = {
            "run_id": run_id,
            "timestamp": datetime.now().isoformat(),
            "version": APP.VERSION,
        }
        if AUDIT.CAPTURE_CONFIG_SNAPSHOT and config_snapshot:
            record["config_snapshot"] = config_snapshot

        # Hash the input data for lineage
        if AUDIT.ENABLE_DATA_LINEAGE and self._current_data is not None:
            data_bytes = self._current_data.to_csv(index=False).encode()
            record["input_hash"] = hashlib.new(
                AUDIT.HASH_ALGORITHM, data_bytes
            ).hexdigest()

        with open(run_dir / "run_manifest.json", "w") as f:
            json.dump(record, f, indent=2, default=str)

        logger.log_action("Run Created", metadata={"run_id": run_id})
        return run_id

    def save_run_artifact(self, run_id: str, name: str, df: pd.DataFrame):
        """Save a DataFrame artifact to a run folder."""
        run_dir = PATHS.RUN_HISTORY / run_id
        run_dir.mkdir(parents=True, exist_ok=True)
        df.to_parquet(run_dir / f"{name}.parquet", index=False)

    def list_runs(self) -> List[Dict]:
        """List all saved run records."""
        runs = []
        if not PATHS.RUN_HISTORY.exists():
            return runs
        for d in sorted(PATHS.RUN_HISTORY.iterdir(), reverse=True):
            manifest = d / "run_manifest.json"
            if manifest.exists():
                try:
                    with open(manifest) as f:
                        runs.append(json.load(f))
                except Exception:
                    pass
        return runs

    # -----------------------------------------------------------------
    # Export
    # -----------------------------------------------------------------
    def export_scorecard(self, format: str = "excel") -> Tuple[bytes, str]:
        if self._scored_data is None:
            raise ValueError("No scored data available. Run pipeline first.")

        df = self._scored_data.copy()
        # V8: PII masking in exports
        if PII.MASK_IN_EXPORTS:
            from utils.pii_masking import mask_dataframe, detect_pii_columns
            pii_cols = detect_pii_columns(df)
            if pii_cols:
                df = mask_dataframe(df, columns=pii_cols, enabled=True)
        export_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = io.BytesIO()

        if format == "excel":
            filename = f"fcdai_scorecard_{export_timestamp}.xlsx"
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name='Anomaly Scorecard', index=False)
                summary = pd.DataFrame([{
                    "Export Date": datetime.now().isoformat(),
                    "Total Records": len(df),
                    "Anomalies Detected": df['anomaly_score'].apply(
                        lambda x: x > 0.5 if pd.notna(x) else False
                    ).sum() if 'anomaly_score' in df.columns else 'N/A',
                    "Source File": self._metadata.get('filename', 'Unknown'),
                    "Import Date": self._metadata.get('import_time', 'Unknown')
                }])
                summary.to_excel(writer, sheet_name='Export Summary', index=False)
        else:
            filename = f"fcdai_scorecard_{export_timestamp}.csv"
            df.to_csv(output, index=False)

        output.seek(0)
        logger.log_export(format.upper(), filename, len(df))
        return output.getvalue(), filename


# Global data vault instance
data_vault = DataVault()


# Convenience functions
def clear_data():
    data_vault.clear_data()


def clear_scored_data():
    data_vault._scored_data = None
    scored_path = PATHS.DATA_VAULT / "scored.parquet"
    if scored_path.exists():
        scored_path.unlink()
