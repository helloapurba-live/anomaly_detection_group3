"""
Layer 3: Feature Engineering
============================
Generate 50+ engineered features for AML detection.

Categories: velocity, aggregates, ratios, flags, temporal, behavioral
Includes auto-transform for skewed features (STEP 6 from pipeline).
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Optional, Tuple
from pathlib import Path
from scipy.stats import skew
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import LAYERS
from utils.column_resolver import resolve


class Layer3FeatureEngineering:
    """
    Layer 3: Feature engineering for anomaly detection.
    
    Generates velocity, aggregate, ratio, flag, temporal,
    and behavioral features.
    """
    
    def __init__(self):
        self.feature_columns: List[str] = []
        self.categories = LAYERS.FEATURE_CATEGORIES
        self.transform_log: List[Dict] = []
        self.skew_threshold = LAYERS.SKEW_THRESHOLD  # V8: from config
    
    def engineer_features(
        self, 
        df: pd.DataFrame,
        customer_col: str = "customer_id",
        amount_col: Optional[str] = "amount",
        timestamp_col: Optional[str] = "timestamp"
    ) -> pd.DataFrame:
        """
        Generate all engineered features.
        
        Args:
            df: Input DataFrame
            customer_col: Customer identifier column
            amount_col: Transaction amount column
            timestamp_col: Timestamp column
            
        Returns:
            DataFrame with engineered features
        """
        df_feat = df.copy()
        
        # V8: Resolve columns via role-based config if strict names missing
        target_cust = self._identify_column(df, customer_col, ['customer', 'party', 'entity', 'id'], 'object')
        if not target_cust:
            target_cust = resolve(df, 'primary_key')
        target_amt = self._identify_column(df, amount_col, ['amount', 'amt', 'value', 'txn_amt'], 'number')
        if not target_amt:
            target_amt = resolve(df, 'amount')
        target_time = self._identify_column(df, timestamp_col, ['timestamp', 'date', 'time', 'created'], 'datetime')
        if not target_time:
            target_time = resolve(df, 'timestamp')
        
        # Add features by category using identified columns
        if target_cust:
            df_feat = self._velocity_features(df_feat, target_cust, target_amt)
            df_feat = self._aggregate_features(df_feat, target_cust, target_amt)
            df_feat = self._behavioral_features(df_feat, target_cust, target_amt)
            
        if target_amt:
            df_feat = self._ratio_features(df_feat, target_amt)
            df_feat = self._flag_features(df_feat, target_amt)
            
        if target_time:
            df_feat = self._temporal_features(df_feat, target_time)
        
        # Track engineered columns
        self.feature_columns = [c for c in df_feat.columns if c not in df.columns]
        
        return df_feat

    def _identify_column(self, df: pd.DataFrame, strict_name: str, aliases: List[str], dtype_family: str) -> Optional[str]:
        """Find best matching column by name or dtype."""
        # 1. Check strict name
        if strict_name in df.columns:
            return strict_name
            
        # 2. Check aliases (case-insensitive)
        lower_cols = {c.lower(): c for c in df.columns}
        for alias in aliases:
            if alias in lower_cols:
                return lower_cols[alias]
            for col in lower_cols:
                if alias in col: # Partial match
                    return lower_cols[col]
                    
        # 3. Fallback by Dtype (Last resort: take first match)
        if dtype_family == 'number':
            nums = df.select_dtypes(include=[np.number]).columns
            # Exclude obvious IDs
            nums = [c for c in nums if 'id' not in c.lower() and 'index' not in c.lower()]
            return nums[0] if len(nums) > 0 else None
            
        if dtype_family == 'datetime':
            dates = df.select_dtypes(include=['datetime', 'datetimetz']).columns
            return dates[0] if len(dates) > 0 else None
            
        if dtype_family == 'object':
            # Hard to guess ID column without name match, return None to be safe
            return None
            
        return None
    
    def _velocity_features(
        self, 
        df: pd.DataFrame,
        customer_col: str,
        amount_col: str
    ) -> pd.DataFrame:
        """Velocity-based features (transaction frequency, speed)."""
        if customer_col not in df.columns:
            return df
        
        # Transaction count per customer
        df['vel_txn_count'] = df.groupby(customer_col)[customer_col].transform('count')
        
        # Cumulative transaction count
        df['vel_cumsum'] = df.groupby(customer_col).cumcount() + 1
        
        # Amount velocity (if amount exists)
        if amount_col and amount_col in df.columns:
            df['vel_amount_sum'] = df.groupby(customer_col)[amount_col].transform('sum')
            df['vel_amount_mean'] = df.groupby(customer_col)[amount_col].transform('mean')
            df['vel_amount_std'] = df.groupby(customer_col)[amount_col].transform('std').fillna(0)
        
        return df
    
    def _aggregate_features(
        self, 
        df: pd.DataFrame,
        customer_col: str,
        amount_col: str
    ) -> pd.DataFrame:
        """Aggregate statistics per entity."""
        if customer_col not in df.columns or not amount_col or amount_col not in df.columns:
            return df
        
        # Rolling aggregates
        df['agg_amount_max'] = df.groupby(customer_col)[amount_col].transform('max')
        df['agg_amount_min'] = df.groupby(customer_col)[amount_col].transform('min')
        df['agg_amount_range'] = df['agg_amount_max'] - df['agg_amount_min']
        
        # Percentile rank
        df['agg_amount_prank'] = df[amount_col].rank(pct=True)
        
        # Quartile
        df['agg_amount_quartile'] = pd.qcut(
            df[amount_col], q=4, labels=False, duplicates='drop'
        ).fillna(0).astype(int)
        
        return df
    
    def _ratio_features(
        self, 
        df: pd.DataFrame,
        amount_col: str
    ) -> pd.DataFrame:
        """Ratio-based features."""
        if not amount_col or amount_col not in df.columns:
            return df
        
        # Amount relative to mean
        global_mean = df[amount_col].mean()
        global_std = df[amount_col].std()
        
        if global_mean > 0:
            df['ratio_to_mean'] = df[amount_col] / global_mean
        else:
            df['ratio_to_mean'] = 1
        
        # Z-score
        if global_std > 0:
            df['ratio_zscore'] = (df[amount_col] - global_mean) / global_std
        else:
            df['ratio_zscore'] = 0
        
        # Log transform (handle zeros)
        df['ratio_log_amount'] = np.log1p(df[amount_col].clip(lower=0))
        
        return df
    
    def _flag_features(
        self, 
        df: pd.DataFrame,
        amount_col: str
    ) -> pd.DataFrame:
        """Binary flag features."""
        if not amount_col or amount_col not in df.columns:
            return df
        
        # Round amount flag — V8: use config divisor
        df['flag_round_amount'] = (df[amount_col] % LAYERS.ROUND_AMOUNT_DIVISOR == 0).astype(int)
        
        # Large transaction flag — V8: use config quantile
        threshold_95 = df[amount_col].quantile(LAYERS.HIGH_AMOUNT_QUANTILE)
        df['flag_large_txn'] = (df[amount_col] > threshold_95).astype(int)
        
        # Very small transaction flag (bottom 5%)
        threshold_05 = df[amount_col].quantile(0.05)
        df['flag_small_txn'] = (df[amount_col] < threshold_05).astype(int)
        
        # Zero amount flag
        df['flag_zero_amount'] = (df[amount_col] == 0).astype(int)
        
        return df
    
    def _temporal_features(
        self, 
        df: pd.DataFrame,
        timestamp_col: str
    ) -> pd.DataFrame:
        """Time-based features."""
        if not timestamp_col or timestamp_col not in df.columns:
            return df
        
        try:
            ts = pd.to_datetime(df[timestamp_col], errors='coerce')
            
            df['temp_hour'] = ts.dt.hour
            df['temp_day_of_week'] = ts.dt.dayofweek
            df['temp_day_of_month'] = ts.dt.day
            df['temp_month'] = ts.dt.month
            df['temp_quarter'] = ts.dt.quarter
            
            # Weekend flag
            df['temp_is_weekend'] = (ts.dt.dayofweek >= 5).astype(int)
            
            # Night hours flag (10pm - 6am)
            df['temp_is_night'] = (
                (ts.dt.hour >= 22) | (ts.dt.hour < 6)
            ).astype(int)
            
            # Business hours flag
            df['temp_is_business'] = (
                (ts.dt.hour >= 9) & (ts.dt.hour < 17) & (ts.dt.dayofweek < 5)
            ).astype(int)
            
        except Exception:
            pass
        
        return df
    
    def _behavioral_features(
        self, 
        df: pd.DataFrame,
        customer_col: str,
        amount_col: str
    ) -> pd.DataFrame:
        """Behavioral pattern features."""
        if customer_col not in df.columns or not amount_col or amount_col not in df.columns:
            return df
        
        # Deviation from customer's typical behavior
        customer_stats = df.groupby(customer_col)[amount_col].agg(['mean', 'std'])
        customer_stats.columns = ['_cust_mean', '_cust_std']
        df = df.merge(customer_stats, left_on=customer_col, right_index=True, how='left')
        
        # Customer-specific z-score
        df['behav_cust_zscore'] = (
            (df[amount_col] - df['_cust_mean']) / df['_cust_std'].replace(0, 1)
        ).fillna(0)
        
        # Is this transaction unusual for customer?
        df['behav_unusual'] = (np.abs(df['behav_cust_zscore']) > 2).astype(int)
        
        # Transaction relative to customer's max
        max_by_cust = df.groupby(customer_col)[amount_col].transform('max')
        df['behav_pct_of_max'] = (df[amount_col] / max_by_cust.replace(0, 1)).fillna(0)
        
        # Clean up temp columns
        df = df.drop(columns=['_cust_mean', '_cust_std'], errors='ignore')
        
        return df
    
    def get_feature_summary(self) -> Dict:
        """Get summary of engineered features."""
        return {
            "total_features": len(self.feature_columns),
            "categories": self.categories,
            "feature_names": self.feature_columns,
            "transforms_applied": self.transform_log
        }
    
    def auto_transform_skewed_features(
        self,
        df: pd.DataFrame,
        schema_profiles: Optional[Dict] = None
    ) -> pd.DataFrame:
        """
        Auto-transform highly skewed continuous features.
        
        STEP 6 from pipeline: Apply LOG(x+1) to features with skew > threshold.
        
        Args:
            df: DataFrame with features
            schema_profiles: Optional column profiles from SchemaDetector
            
        Returns:
            DataFrame with transformed features
        """
        df_transformed = df.copy()
        self.transform_log = []
        
        # Get numeric columns
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        
        # Filter to continuous features (exclude IDs, flags, binary)
        continuous_cols = []
        for col in numeric_cols:
            # Skip obvious non-continuous columns
            if any(x in col.lower() for x in ['id', 'flag_', 'is_', 'count', 'temp_']):
                continue
            # Skip if only 2 unique values (binary)
            if df[col].nunique() <= 2:
                continue
            continuous_cols.append(col)
        
        # Check skewness and transform if needed
        for col in continuous_cols:
            try:
                col_data = df[col].dropna()
                if len(col_data) < 10:  # Need enough data
                    continue
                
                # Calculate skewness
                col_skew = skew(col_data, nan_policy='omit')
                
                # If highly skewed, apply log transform
                if abs(col_skew) > self.skew_threshold:
                    # Apply LOG(x + 1) to handle zeros
                    min_val = col_data.min()
                    if min_val < 0:
                        # Shift to positive before log
                        shift = abs(min_val) + 1
                        df_transformed[col] = np.log1p(df[col] + shift)
                        transform_type = f"LOG(x + {shift})"
                    else:
                        df_transformed[col] = np.log1p(df[col])
                        transform_type = "LOG(x + 1)"
                    
                    # Log the transformation
                    log_entry = {
                        'column': col,
                        'original_skew': float(col_skew),
                        'transform': transform_type,
                        'reason': f'Skew {col_skew:.2f} > threshold {self.skew_threshold}'
                    }
                    self.transform_log.append(log_entry)
                    print(f"[INFO] Auto-transformed {col}: {transform_type} due to skew={col_skew:.2f}")
                    
            except Exception as e:
                print(f"[WARN] Could not transform {col}: {str(e)}")
                continue
        
        return df_transformed
