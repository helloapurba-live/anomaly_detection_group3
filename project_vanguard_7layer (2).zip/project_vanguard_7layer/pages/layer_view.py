"""
Layer View Page
===============
Detailed view of each layer's output and statistics.
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP


dash.register_page(__name__, path="/layers", name="Layer View", order=3)


layout = dmc.Container(
    [
        dmc.Group(
            [
                dmc.Title("Layer Dashboard", order=2),
            ],
            justify="space-between",
            mb="lg",
        ),
        
        dmc.Tabs(
            [
                dmc.TabsList(
                    [
                        dmc.TabsTab("L1-2: Ingest", value="l12"),
                        dmc.TabsTab("L3: Features", value="l3"),
                        dmc.TabsTab("L4: Preproc", value="l4"),
                        dmc.TabsTab("L5: Detect", value="l5"),
                        dmc.TabsTab("L6: Ensemble", value="l6"),
                        dmc.TabsTab("L7: Output", value="l7"),
                    ],
                    grow=True,
                ),
                
                # Layer 1-2
                dmc.TabsPanel(
                    dmc.Paper(
                        [
                            dmc.Text("Data Quality Report", fw=600, mb="md"),
                            dmc.SimpleGrid(
                                cols=3,
                                children=[
                                    dmc.Paper(
                                        [
                                            dmc.Text("Completeness", c="dimmed", size="sm"),
                                            dmc.RingProgress(
                                                sections=[{"value": 98, "color": THEME.SUCCESS}],
                                                label=dmc.Text("98%", ta="center", fw=700),
                                            ),
                                        ],
                                        p="md",
                                        ta="center",
                                    ),
                                    dmc.Paper(
                                        [
                                            dmc.Text("Consistency", c="dimmed", size="sm"),
                                            dmc.RingProgress(
                                                sections=[{"value": 95, "color": THEME.SUCCESS}],
                                                label=dmc.Text("95%", ta="center", fw=700),
                                            ),
                                        ],
                                        p="md",
                                        ta="center",
                                    ),
                                    dmc.Paper(
                                        [
                                            dmc.Text("Validity", c="dimmed", size="sm"),
                                            dmc.RingProgress(
                                                sections=[{"value": 92, "color": THEME.WARNING}],
                                                label=dmc.Text("92%", ta="center", fw=700),
                                            ),
                                        ],
                                        p="md",
                                        ta="center",
                                    ),
                                ],
                            ),
                        ],
                        p="lg",
                        radius="md",
                        withBorder=True,
                        style={"backgroundColor": THEME.DARK_BG_CARD}
                    ),
                    value="l12",
                    pt="md",
                ),
                
                # Layer 3
                dmc.TabsPanel(
                    dmc.Paper(
                        [
                            dmc.Text("Feature Engineering Summary", fw=600, mb="md"),
                            dmc.SimpleGrid(
                                cols={"base": 2, "md": 3},
                                children=[
                                    dmc.Paper(
                                        dmc.Stack([
                                            dmc.Text("Velocity", c="dimmed", size="sm"),
                                            dmc.Text("5 features", fw=600),
                                        ], gap=0, ta="center"),
                                        p="md",
                                        style={"backgroundColor": "rgba(0,200,255,0.1)"}
                                    ),
                                    dmc.Paper(
                                        dmc.Stack([
                                            dmc.Text("Aggregates", c="dimmed", size="sm"),
                                            dmc.Text("8 features", fw=600),
                                        ], gap=0, ta="center"),
                                        p="md",
                                        style={"backgroundColor": "rgba(150,100,255,0.1)"}
                                    ),
                                    dmc.Paper(
                                        dmc.Stack([
                                            dmc.Text("Ratios", c="dimmed", size="sm"),
                                            dmc.Text("6 features", fw=600),
                                        ], gap=0, ta="center"),
                                        p="md",
                                        style={"backgroundColor": "rgba(255,150,0,0.1)"}
                                    ),
                                    dmc.Paper(
                                        dmc.Stack([
                                            dmc.Text("Flags", c="dimmed", size="sm"),
                                            dmc.Text("4 features", fw=600),
                                        ], gap=0, ta="center"),
                                        p="md",
                                        style={"backgroundColor": "rgba(255,50,50,0.1)"}
                                    ),
                                    dmc.Paper(
                                        dmc.Stack([
                                            dmc.Text("Temporal", c="dimmed", size="sm"),
                                            dmc.Text("9 features", fw=600),
                                        ], gap=0, ta="center"),
                                        p="md",
                                        style={"backgroundColor": "rgba(0,255,150,0.1)"}
                                    ),
                                    dmc.Paper(
                                        dmc.Stack([
                                            dmc.Text("Behavioral", c="dimmed", size="sm"),
                                            dmc.Text("4 features", fw=600),
                                        ], gap=0, ta="center"),
                                        p="md",
                                        style={"backgroundColor": "rgba(255,255,0,0.1)"}
                                    ),
                                ],
                            ),
                        ],
                        p="lg",
                        radius="md",
                        withBorder=True,
                        style={"backgroundColor": THEME.DARK_BG_CARD}
                    ),
                    value="l3",
                    pt="md",
                ),
                
                # Layer 4
                dmc.TabsPanel(
                    dmc.Paper(
                        [
                            dmc.Text("Matrix Versions", fw=600, mb="md"),
                            dmc.SimpleGrid(
                                cols=4,
                                children=[
                                    dmc.Paper(
                                        dmc.Stack([
                                            DashIconify(icon="mdi:table", width=32),
                                            dmc.Text("RAW", fw=600),
                                            dmc.Text("Original values", size="xs", c="dimmed"),
                                        ], gap=4, ta="center"),
                                        p="lg",
                                        style={"backgroundColor": "rgba(100,100,100,0.2)"}
                                    ),
                                    dmc.Paper(
                                        dmc.Stack([
                                            DashIconify(icon="mdi:chart-line", width=32),
                                            dmc.Text("SCALED", fw=600),
                                            dmc.Text("StandardScaler", size="xs", c="dimmed"),
                                        ], gap=4, ta="center"),
                                        p="lg",
                                        style={"backgroundColor": "rgba(0,200,255,0.2)"}
                                    ),
                                    dmc.Paper(
                                        dmc.Stack([
                                            DashIconify(icon="mdi:cube-scan", width=32),
                                            dmc.Text("PCA", fw=600),
                                            dmc.Text("Reduced dims", size="xs", c="dimmed"),
                                        ], gap=4, ta="center"),
                                        p="lg",
                                        style={"backgroundColor": "rgba(150,100,255,0.2)"}
                                    ),
                                    dmc.Paper(
                                        dmc.Stack([
                                            DashIconify(icon="mdi:code-tags", width=32),
                                            dmc.Text("ENCODED", fw=600),
                                            dmc.Text("Categoricals", size="xs", c="dimmed"),
                                        ], gap=4, ta="center"),
                                        p="lg",
                                        style={"backgroundColor": "rgba(255,150,0,0.2)"}
                                    ),
                                ],
                            ),
                        ],
                        p="lg",
                        radius="md",
                        withBorder=True,
                        style={"backgroundColor": THEME.DARK_BG_CARD}
                    ),
                    value="l4",
                    pt="md",
                ),
                
                # Layer 5
                dmc.TabsPanel(
                    dmc.Paper(
                        [
                            dmc.Text("Detection Methods (26)", fw=600, mb="md"),
                            dcc.Graph(
                                id="chart-l5-methods",
                                config=APP.PLOTLY_CONFIG,
                                style={"height": "400px"},
                            ),
                        ],
                        p="lg",
                        radius="md",
                        withBorder=True,
                        style={"backgroundColor": THEME.DARK_BG_CARD}
                    ),
                    value="l5",
                    pt="md",
                ),
                
                # Layer 6
                dmc.TabsPanel(
                    dmc.Paper(
                        [
                            dmc.Text("Ensemble Fusion", fw=600, mb="md"),
                            dmc.Text("Method: Weighted Average", c="dimmed", mb="lg"),
                            dmc.Text("Score Aggregation: 26 → 1", c="dimmed", mb="lg"),
                            dcc.Graph(
                                id="chart-l6-fusion",
                                config=APP.PLOTLY_CONFIG,
                                style={"height": "300px"},
                            ),
                        ],
                        p="lg",
                        radius="md",
                        withBorder=True,
                        style={"backgroundColor": THEME.DARK_BG_CARD}
                    ),
                    value="l6",
                    pt="md",
                ),
                
                # Layer 7
                dmc.TabsPanel(
                    dmc.Paper(
                        [
                            dmc.Text("Output Components", fw=600, mb="md"),
                            dmc.SimpleGrid(
                                cols=3,
                                children=[
                                    dmc.Paper(
                                        dmc.Stack([
                                            DashIconify(icon="mdi:clipboard-list", width=40),
                                            dmc.Text("Investigation Queue", fw=600),
                                            dmc.Text("~1000 alerts capacity", size="sm", c="dimmed"),
                                        ], gap=4, ta="center"),
                                        p="lg",
                                        style={"backgroundColor": "rgba(255,50,50,0.2)"}
                                    ),
                                    dmc.Paper(
                                        dmc.Stack([
                                            DashIconify(icon="mdi:file-document", width=40),
                                            dmc.Text("Narrative System", fw=600),
                                            dmc.Text("SHAP explanations", size="sm", c="dimmed"),
                                        ], gap=4, ta="center"),
                                        p="lg",
                                        style={"backgroundColor": "rgba(0,200,255,0.2)"}
                                    ),
                                    dmc.Paper(
                                        dmc.Stack([
                                            DashIconify(icon="mdi:history", width=40),
                                            dmc.Text("Audit Trail", fw=600),
                                            dmc.Text("All decisions logged", size="sm", c="dimmed"),
                                        ], gap=4, ta="center"),
                                        p="lg",
                                        style={"backgroundColor": "rgba(0,255,150,0.2)"}
                                    ),
                                ],
                            ),
                        ],
                        p="lg",
                        radius="md",
                        withBorder=True,
                        style={"backgroundColor": THEME.DARK_BG_CARD}
                    ),
                    value="l7",
                    pt="md",
                ),
            ],
            value="l12",
        ),
    ],
    fluid=True,
)


@callback(
    Output("chart-l5-methods", "figure"),
    Input("chart-l5-methods", "id"),
)
def render_l5_chart(_):
    data = {
        'Category': ['Statistical', 'Distance', 'Density', 'Clustering', 
                     'Trees', 'Time-Series', 'Graph', 'Deep Learning'],
        'Methods': [5, 3, 4, 3, 2, 3, 4, 2],
        'Details': [
            'Z-Score, IQR, Grubbs, Dixon, ESD',
            'KNN, Mahalanobis, LOF',
            'DBSCAN, OPTICS, HDBSCAN, CBLOF',
            'K-Means, GMM, Spectral',
            'IsolationForest, ExtendedIF',
            'STL, ARIMA, Prophet',
            'PageRank, HITS, Community, Centrality',
            'Autoencoder, VAE'
        ]
    }
    
    fig = px.bar(
        data, x='Category', y='Methods',
        template="plotly_dark",
        color='Category',
        color_discrete_sequence=px.colors.qualitative.Set2,
        hover_data=['Details']
    )
    
    fig.update_layout(
        margin=dict(l=20, r=20, t=20, b=60),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        showlegend=False,
        xaxis=dict(showgrid=False, tickangle=45),
        yaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,0.1)", title="Method Count"),
    )
    
    return fig


@callback(
    Output("chart-l6-fusion", "figure"),
    Input("chart-l6-fusion", "id"),
)
def render_l6_chart(_):
    fig = go.Figure(go.Sankey(
        node=dict(
            label=["Statistical", "Distance", "Density", "Clustering", 
                   "Trees", "Time-Series", "Graph", "Deep Learning",
                   "Ensemble", "Risk Tiers"],
            color=[THEME.PRIMARY] * 8 + [THEME.SECONDARY, THEME.SUCCESS]
        ),
        link=dict(
            source=[0, 1, 2, 3, 4, 5, 6, 7, 8],
            target=[8, 8, 8, 8, 8, 8, 8, 8, 9],
            value=[5, 3, 4, 3, 2, 3, 4, 2, 26],
            color="rgba(150,150,150,0.3)"
        )
    ))
    
    fig.update_layout(
        template="plotly_dark",
        margin=dict(l=20, r=20, t=20, b=20),
        paper_bgcolor="rgba(0,0,0,0)",
    )
    
    return fig
