"""
Pipeline Run Page
=================
Execute and monitor the 7-layer pipeline.
"""

import dash
from dash import html, dcc, callback, Input, Output, State
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import pandas as pd
import time
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS


dash.register_page(__name__, path="/pipeline", name="Pipeline Run", order=2)


def layer_step(number: str, name: str, description: str) -> dmc.Paper:
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.Avatar(number, radius="xl", color="cyan", variant="filled"),
                    dmc.Stack(
                        [
                            dmc.Text(name, fw=600),
                            dmc.Text(description, size="sm", c="dimmed"),
                        ],
                        gap=0,
                    ),
                    dmc.ThemeIcon(
                        DashIconify(icon="mdi:clock-outline", width=20),
                        color="gray",
                        variant="light",
                        id={"type": "layer-status", "layer": number},
                    ),
                ],
                justify="space-between",
            ),
        ],
        p="sm",
        radius="md",
        withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD, "marginBottom": "8px"}
    )


layout = dmc.Container(
    [
        dmc.Group(
            [
                dmc.Title("Pipeline Execution", order=2),
                dmc.Badge("7 Layers | 26 Methods", color="cyan", variant="light"),
            ],
            justify="space-between",
            mb="lg",
        ),
        
        dmc.SimpleGrid(
            cols={"base": 1, "lg": 2},
            spacing="lg",
            children=[
                # Left: Pipeline Steps
                dmc.Paper(
                    [
                        dmc.Text("Pipeline Layers", fw=600, mb="md"),
                        layer_step("1-2", "Ingest + Data Quality", "Load sources, validate, DQ scoring"),
                        layer_step("3", "Feature Engineering", "50+ features: velocity, aggregates, ratios"),
                        layer_step("4", "Preprocessing", "4 matrix versions: raw, scaled, PCA, encoded"),
                        layer_step("5", "Detection", "26 methods across 8 categories"),
                        layer_step("6", "Ensemble Fusion", "Score fusion → Risk tiers"),
                        layer_step("7", "Output", "Investigation queue, narratives, audit"),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                
                # Right: Controls
                dmc.Stack(
                    [
                        dmc.Paper(
                            [
                                dmc.Text("Execution Settings", fw=600, mb="md"),
                                dmc.Select(
                                    id="select-ensemble",
                                    label="Ensemble Method",
                                    data=[
                                        {"value": "weighted_average", "label": "Weighted Average"},
                                        {"value": "max", "label": "Max Score"},
                                        {"value": "voting", "label": "Voting"},
                                        {"value": "stacking", "label": "Stacking"},
                                    ],
                                    value="weighted_average",
                                    mb="md",
                                ),
                                dmc.MultiSelect(
                                    id="select-categories",
                                    label="Detection Categories",
                                    data=[
                                        {"value": "statistical", "label": "Statistical (5)"},
                                        {"value": "distance", "label": "Distance (3)"},
                                        {"value": "density", "label": "Density (4)"},
                                        {"value": "clustering", "label": "Clustering (3)"},
                                        {"value": "trees", "label": "Trees (2)"},
                                        {"value": "timeseries", "label": "Time-Series (3)"},
                                        {"value": "graph", "label": "Graph (4)"},
                                        {"value": "deep_learning", "label": "Deep Learning (2)"},
                                    ],
                                    value=["statistical", "distance", "density", "clustering", 
                                           "trees", "timeseries", "graph", "deep_learning"],
                                    mb="lg",
                                ),
                                dmc.Button(
                                    "Run Pipeline",
                                    id="btn-run-pipeline",
                                    leftSection=DashIconify(icon="mdi:rocket-launch"),
                                    color="cyan",
                                    size="lg",
                                    fullWidth=True,
                                ),
                            ],
                            p="md",
                            radius="md",
                            withBorder=True,
                            style={"backgroundColor": THEME.DARK_BG_CARD}
                        ),
                        
                        # Results
                        html.Div(id="pipeline-results"),
                    ],
                ),
            ],
        ),
    ],
    fluid=True,
)


@callback(
    Output("pipeline-results", "children"),
    Input("btn-run-pipeline", "n_clicks"),
    State("select-ensemble", "value"),
    State("select-categories", "value"),
    prevent_initial_call=True,
)
def run_pipeline(n_clicks, ensemble_method, categories):
    if not n_clicks:
        return ""
    
    try:
        from pipeline import VanguardPipeline
        from utils.generate_data import generate_multi_source_data
        from config import LAYERS
        
        # Get methods for selected categories
        methods = []
        for cat in categories:
            if cat in LAYERS.DETECTION_METHODS:
                methods.extend(LAYERS.DETECTION_METHODS[cat])
        
        # Load or generate data
        sources = {}
        for source_file in PATHS.DATA_SOURCES.glob("*.csv"):
            name = source_file.stem
            sources[name] = pd.read_csv(source_file)
        
        if not sources:
            sources = generate_multi_source_data()
        
        # Run pipeline
        pipeline = VanguardPipeline()
        result = pipeline.run(
            sources,
            detection_methods=methods if methods else None,
            ensemble_method=ensemble_method
        )
        
        if result.success:
            # Save results
            pipeline.save_results()
            
            return dmc.Paper(
                [
                    dmc.Alert(
                        "Pipeline completed successfully!",
                        color="green",
                        icon=DashIconify(icon="mdi:check-circle"),
                        mb="md",
                    ),
                    dmc.SimpleGrid(
                        cols=2,
                        children=[
                            dmc.Text(f"Records: {result.records_processed:,}", c="dimmed"),
                            dmc.Text(f"DQ Score: {result.dq_score:.0%}", c="dimmed"),
                            dmc.Text(f"Features: {result.features_generated}", c="dimmed"),
                            dmc.Text(f"Methods: {result.methods_run}", c="dimmed"),
                            dmc.Text(f"Alerts: {result.alerts_generated}", c="dimmed"),
                            dmc.Text(f"Time: {result.execution_time_ms:.0f}ms", c="dimmed"),
                        ],
                    ),
                    dmc.Space(h="md"),
                    dmc.Text("Risk Distribution:", fw=600, mb="sm"),
                    dmc.Group(
                        [
                            dmc.Badge(f"Critical: {result.tier_distribution.get('Critical', 0)}", color="red"),
                            dmc.Badge(f"High: {result.tier_distribution.get('High', 0)}", color="orange"),
                            dmc.Badge(f"Medium: {result.tier_distribution.get('Medium', 0)}", color="yellow"),
                            dmc.Badge(f"Low: {result.tier_distribution.get('Low', 0)}", color="green"),
                        ],
                    ),
                ],
                p="md",
                radius="md",
                withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD}
            )
        else:
            return dmc.Alert(
                "Pipeline failed",
                color="red",
                icon=DashIconify(icon="mdi:alert"),
            )
            
    except Exception as e:
        return dmc.Alert(
            f"Error: {str(e)}",
            color="red",
            icon=DashIconify(icon="mdi:alert"),
        )
