"""
Project Vanguard 7-Layer Edition - Main Application
====================================================
Air-gapped Dash Mantine Components UI for the 7-layer pipeline.

Author: Project Vanguard Team
"""

import dash
from dash import html, dcc, page_registry, page_container
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import diskcache
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent))

from config import APP, THEME, PATHS


# =============================================================================
# DASH APPLICATION INITIALIZATION
# =============================================================================
app = dash.Dash(
    __name__,
    use_pages=True,
    pages_folder='pages',
    suppress_callback_exceptions=True,
    assets_folder='assets',
    serve_locally=True,  # Air-gapped mode
    title=APP.TITLE,
    update_title=None,
)


# =============================================================================
# NAVIGATION LINK COMPONENT
# =============================================================================
def create_nav_link(icon: str, label: str, href: str) -> dmc.NavLink:
    """Create a styled navigation link."""
    return dmc.NavLink(
        label=label,
        href=href,
        leftSection=DashIconify(icon=icon, width=20),
        active="exact",
        style={"borderRadius": "6px", "marginBottom": "4px"},
    )


# =============================================================================
# SIDEBAR LAYOUT
# =============================================================================
sidebar = dmc.Paper(
    [
        # Logo
        dmc.Group(
            [
                dmc.ThemeIcon(
                    DashIconify(icon="mdi:shield-lock", width=28),
                    size="xl",
                    radius="md",
                    variant="gradient",
                    gradient={"from": "cyan", "to": "indigo"},
                ),
                dmc.Stack(
                    [
                        dmc.Text("FCDAI", size="lg", fw=700, c="white"),
                        dmc.Text("Anomaly Auto Detection", size="xs", c="dimmed"),
                    ],
                    gap=0,
                ),
            ],
            gap="sm",
            px="md",
            py="lg",
        ),
        
        dmc.Divider(color=THEME.DARK_BORDER),
        
        # Navigation - Pipeline Layers
        dmc.Stack(
            [
                dmc.Text("PIPELINE", size="xs", c="dimmed", fw=500, px="md", pt="md"),
                create_nav_link("mdi:view-dashboard", "Dashboard", "/"),
                create_nav_link("mdi:database-import", "Data Sources", "/sources"),
                create_nav_link("mdi:rocket-launch", "Pipeline Run", "/pipeline"),
                create_nav_link("mdi:layers-triple", "Layer View", "/layers"),
            ],
            gap=2,
            px="sm",
        ),
        
        # Navigation - Results
        dmc.Stack(
            [
                dmc.Text("RESULTS", size="xs", c="dimmed", fw=500, px="md", pt="md"),
                create_nav_link("mdi:alert-circle", "Investigation Queue", "/queue"),
                create_nav_link("mdi:file-document", "Narratives", "/narratives"),
                create_nav_link("mdi:history", "Audit Trail", "/audit"),
            ],
            gap=2,
            px="sm",
        ),

        # Navigation - Advanced Analytics (Merged from Vanguard)
        dmc.Stack(
            [
                dmc.Text("ADVANCED ANALYTICS", size="xs", c="dimmed", fw=500, px="md", pt="md"),
                create_nav_link("mdi:table-search", "Audit Vault (AG Grid)", "/audit-vault"),
                create_nav_link("mdi:chart-sankey", "Model Diagnostics", "/diagnostics"),
                create_nav_link("mdi:brain", "Explainability (SHAP)", "/explainability"),
            ],
            gap=2,
            px="sm",
        ),
        
        # Navigation - Admin
        dmc.Stack(
            [
                dmc.Text("ADMIN", size="xs", c="dimmed", fw=500, px="md", pt="md"),
                create_nav_link("mdi:server", "System Health", "/health"),
            ],
            gap=2,
            px="sm",
        ),
        
        # Spacer
        dmc.Space(h="xl"),
        
        # Status
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Badge("7-Layer + Apex", color="cyan", variant="light"),
                        dmc.Badge("v3.0", color="grape", variant="light"),
                    ],
                    gap="xs",
                    justify="center",
                ),
            ],
            p="sm",
            mx="sm",
            radius="md",
            style={"backgroundColor": "rgba(0,0,0,0.2)"}
        ),
    ],
    style={
        "width": "260px",
        "height": "100vh",
        "position": "fixed",
        "top": 0,
        "left": 0,
        "backgroundColor": THEME.DARK_BG_CARD,
        "borderRight": f"1px solid {THEME.DARK_BORDER}",
        "overflowY": "auto",
    },
    radius=0,
)


# =============================================================================
# MAIN LAYOUT
# =============================================================================
app.layout = dmc.MantineProvider(
    [
        dmc.NotificationProvider(position="top-right"),
        html.Div(id="notification-container"),
        
        # Stores for state management
        dcc.Store(id="store-privacy-mode", data=True, storage_type="local"),
        
        dmc.Box(
            [
                sidebar,
                dmc.Box(
                    [
                        page_container
                    ],
                    style={
                        "marginLeft": "260px",
                        "padding": "20px",
                        "minHeight": "100vh",
                        "backgroundColor": THEME.DARK_BG,
                    }
                ),
            ]
        ),
    ],
    forceColorScheme="dark",
    theme=THEME.get_mantine_theme(),
)


# =============================================================================
# SERVER
# =============================================================================
server = app.server


if __name__ == "__main__":
    print("""
============================================================
  FCDAI ANOMALY AUTO DETECTION TOOL
  Advanced AML Detection Pipeline (7-Layer Edition)
============================================================
  🔒 AIR-GAPPED MODE: No external connections
  📊 LAYERS: 7 | METHODS: 26 | CATEGORIES: 8
  🌐 Running at: http://{host}:{port}

  Press Ctrl+C to stop the server
============================================================
""".format(host=APP.HOST, port=APP.PORT))
    app.run(debug=APP.DEBUG, host=APP.HOST, port=APP.PORT)
