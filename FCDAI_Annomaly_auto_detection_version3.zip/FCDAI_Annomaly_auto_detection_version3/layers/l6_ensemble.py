"""
Layer 6: Ensemble Fusion
========================
Combine 26 detection scores into unified risk assessment.

Methods: weighted_average, max, voting, stacking
Risk Tiers: Critical, High, Medium, Low
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from pathlib import Path
from dataclasses import dataclass
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import LAYERS


@dataclass
class EnsembleResult:
    """Result of ensemble fusion."""
    final_scores: np.ndarray
    risk_tiers: np.ndarray
    method_weights: Dict[str, float]
    tier_counts: Dict[str, int]


class Layer6Ensemble:
    """
    Layer 6: Ensemble score fusion and risk tier assignment.
    
    Combines 25+ algorithm scores into a single risk score
    and assigns risk tiers (Critical, High, Medium, Low).
    """
    
    def __init__(self, method: str = "weighted_average"):
        """
        Initialize ensemble layer.
        
        Args:
            method: Fusion method (weighted_average, max, voting, stacking)
        """
        self.method = method
        self.risk_tiers = LAYERS.RISK_TIERS
        self.weights: Dict[str, float] = {}
    
    def fuse(
        self, 
        score_matrix: np.ndarray,
        method_names: List[str],
        weights: Dict[str, float] = None
    ) -> EnsembleResult:
        """
        Fuse detection scores into unified risk score.
        
        Args:
            score_matrix: (n_samples, n_methods) matrix of scores
            method_names: Names of detection methods
            weights: Optional custom weights per method
            
        Returns:
            EnsembleResult with final scores and risk tiers
        """
        if score_matrix.size == 0:
            return EnsembleResult(
                final_scores=np.array([]),
                risk_tiers=np.array([]),
                method_weights={},
                tier_counts={}
            )
        
        # Set weights
        if weights:
            self.weights = weights
        else:
            self.weights = self._compute_weights(score_matrix, method_names)
        
        # Apply fusion method
        if self.method == "weighted_average":
            final_scores = self._weighted_average(score_matrix, method_names)
        elif self.method == "max":
            final_scores = self._max_fusion(score_matrix)
        elif self.method == "voting":
            final_scores = self._voting(score_matrix)
        elif self.method == "stacking":
            final_scores = self._stacking(score_matrix)
        else:
            final_scores = self._weighted_average(score_matrix, method_names)
        
        # Assign risk tiers
        risk_tiers = self._assign_risk_tiers(final_scores)
        
        # Count tiers
        unique, counts = np.unique(risk_tiers, return_counts=True)
        tier_counts = dict(zip(unique, counts.astype(int)))
        
        return EnsembleResult(
            final_scores=final_scores,
            risk_tiers=risk_tiers,
            method_weights=self.weights,
            tier_counts=tier_counts
        )
    
    def _compute_weights(
        self, 
        score_matrix: np.ndarray, 
        method_names: List[str]
    ) -> Dict[str, float]:
        """Compute weights based on score variance (higher variance = more informative)."""
        variances = np.var(score_matrix, axis=0)
        total_var = variances.sum() + 1e-8
        
        weights = {}
        for i, name in enumerate(method_names):
            weights[name] = float(variances[i] / total_var)
        
        return weights
    
    def _weighted_average(
        self, 
        score_matrix: np.ndarray,
        method_names: List[str]
    ) -> np.ndarray:
        """Weighted average of scores."""
        weight_array = np.array([
            self.weights.get(name, 1.0 / len(method_names)) 
            for name in method_names
        ])
        weight_array = weight_array / weight_array.sum()
        
        return np.dot(score_matrix, weight_array)
    
    def _max_fusion(self, score_matrix: np.ndarray) -> np.ndarray:
        """Maximum score across all methods."""
        return np.max(score_matrix, axis=1)
    
    def _voting(self, score_matrix: np.ndarray, threshold: float = 0.5) -> np.ndarray:
        """Voting based on threshold."""
        votes = (score_matrix > threshold).astype(float)
        return votes.mean(axis=1)
    
    def _stacking(self, score_matrix: np.ndarray) -> np.ndarray:
        """Simple meta-learner stacking (mean + std features)."""
        mean_scores = np.mean(score_matrix, axis=1)
        std_scores = np.std(score_matrix, axis=1)
        max_scores = np.max(score_matrix, axis=1)
        
        # Combine: higher mean, std, and max = more anomalous
        stacked = 0.5 * mean_scores + 0.25 * std_scores + 0.25 * max_scores
        return np.clip(stacked, 0, 1)
    
    def _assign_risk_tiers(self, scores: np.ndarray) -> np.ndarray:
        """Assign risk tier based on score thresholds."""
        tiers = np.empty(len(scores), dtype='<U10')
        
        for tier_name, (low, high) in self.risk_tiers.items():
            mask = (scores >= low) & (scores < high)
            tiers[mask] = tier_name
        
        # Handle edge case for exactly 1.0
        tiers[scores >= 1.0] = "Critical"
        tiers[scores < 0.0] = "Low"
        
        return tiers
    
    def get_high_risk_indices(
        self, 
        result: EnsembleResult, 
        tiers: List[str] = None
    ) -> np.ndarray:
        """Get indices of high-risk records."""
        if tiers is None:
            tiers = ["Critical", "High"]
        
        mask = np.isin(result.risk_tiers, tiers)
        return np.where(mask)[0]
    
    def get_summary(self, result: EnsembleResult) -> Dict:
        """Get ensemble summary."""
        return {
            "fusion_method": self.method,
            "total_records": len(result.final_scores),
            "tier_distribution": result.tier_counts,
            "score_stats": {
                "mean": float(np.mean(result.final_scores)),
                "std": float(np.std(result.final_scores)),
                "max": float(np.max(result.final_scores)),
                "min": float(np.min(result.final_scores))
            },
            "top_weighted_methods": sorted(
                result.method_weights.items(), 
                key=lambda x: x[1], 
                reverse=True
            )[:5]
        }


class RiskRanker:
    """
    Additional risk ranking utilities.
    """
    
    @staticmethod
    def rank_by_score(
        indices: np.ndarray, 
        scores: np.ndarray
    ) -> np.ndarray:
        """Rank indices by score (highest first)."""
        order = np.argsort(scores[indices])[::-1]
        return indices[order]
    
    @staticmethod
    def prioritize_for_investigation(
        result: EnsembleResult,
        capacity: int = 1000
    ) -> np.ndarray:
        """
        Prioritize records for investigation queue.
        
        Returns top N indices by risk score.
        """
        order = np.argsort(result.final_scores)[::-1]
        return order[:capacity]
    
    @staticmethod
    def compute_risk_percentile(scores: np.ndarray) -> np.ndarray:
        """Compute percentile rank for each score."""
        from scipy import stats
        return stats.rankdata(scores, method='average') / len(scores) * 100
