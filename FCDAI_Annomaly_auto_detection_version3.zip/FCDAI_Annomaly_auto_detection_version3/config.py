"""
Project Vanguard 7-Layer Edition - Configuration
=================================================
Centralized configuration for the 7-layer AML pipeline.

Author: Project Vanguard Team
"""

from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Any


# =============================================================================
# PATH CONFIGURATION
# =============================================================================
BASE_DIR = Path(__file__).parent

@dataclass
class PathConfig:
    """File system paths."""
    BASE: Path = BASE_DIR
    DATA: Path = BASE_DIR / "data"
    DATA_VAULT: Path = BASE_DIR / "data" / "vault"
    DATA_SOURCES: Path = BASE_DIR / "data" / "sources"
    EXPORTS: Path = BASE_DIR / "data" / "exports"
    MODELS: Path = BASE_DIR / "models"
    LOGS: Path = BASE_DIR / "logs"
    CACHE: Path = BASE_DIR / "cache"
    ASSETS: Path = BASE_DIR / "assets"
    
    def __post_init__(self):
        """Create directories if they don't exist."""
        for path in [self.DATA_VAULT, self.DATA_SOURCES, self.EXPORTS, 
                     self.MODELS, self.LOGS, self.CACHE, self.ASSETS]:
            path.mkdir(parents=True, exist_ok=True)


# =============================================================================
# THEME CONFIGURATION (Unified with Vanguard Apex)
# =============================================================================
@dataclass
class ThemeConfig:
    """UI theme colors and styles."""
    PRIMARY: str = "#00D4FF"
    SECONDARY: str = "#9D4EDD"
    SUCCESS: str = "#00C853"
    WARNING: str = "#FFB300"
    DANGER: str = "#FF5252"
    INFO: str = "#2196F3"
    
    # Dark Mode Backgrounds
    DARK_BG: str = "#0D1117"
    DARK_BG_PRIMARY: str = "#0a0a12"
    DARK_BG_SECONDARY: str = "#12121f"
    DARK_BG_PAPER: str = "#1a1a2e"
    DARK_BG_CARD: str = "#16213e"
    DARK_BORDER: str = "#30363D"

    # Risk Gradient Colors (for AG Grid)
    RISK_GRADIENT: List[str] = field(default_factory=lambda: [
        "#00C853",  # 0-20: Low (Green)
        "#4CAF50",  # 20-40: Low-Medium
        "#FFC107",  # 40-60: Medium (Yellow)
        "#FF9800",  # 60-80: Medium-High (Orange)
        "#FF5252",  # 80-100: High (Red)
    ])

    def get_mantine_theme(self) -> Dict[str, Any]:
        """Return theme dict for DMC MantineProvider."""
        return {
            "colorScheme": "dark",
            "primaryColor": "cyan",
            "fontFamily": "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
            "colors": {
                "cyan": [
                    "#e3fafc", "#c5f6fa", "#99e9f2", "#66d9e8", "#3bc9db",
                    "#22b8cf", "#15aabf", "#1098ad", "#0c8599", "#0b7285"
                ],
                "grape": [
                    "#f8f0fc", "#f3d9fa", "#eebefa", "#e599f7", "#da77f2",
                    "#cc5de8", "#be4bdb", "#ae3ec9", "#9c36b5", "#862e9c"
                ]
            },
            "components": {
                "Paper": {"styles": {"root": {"backgroundColor": self.DARK_BG_PAPER}}},
                "Card": {"styles": {"root": {"backgroundColor": self.DARK_BG_CARD}}},
            }
        }


# =============================================================================
# PII MASKING CONFIGURATION (From Vanguard)
# =============================================================================
@dataclass
class PIIConfig:
    """
    Privacy mode configuration for PII data protection.
    Masks sensitive fields while keeping underlying data intact.
    """
    ENABLED_BY_DEFAULT: bool = False
    MASK_PATTERN: str = "XXXX"
    VISIBLE_CHARS: int = 4
    
    # Fields to mask (regex patterns)
    MASKED_COLUMNS: List[str] = field(default_factory=lambda: [
        "customer_id",
        "account_number",
        "ssn",
        "name",
        "email",
        "phone"
    ])
    
    # Masking patterns by field type
    PATTERNS: Dict[str, str] = field(default_factory=lambda: {
        "customer_id": r"^(.{4}).*(.{4})$",  # Keep first 4 and last 4
        "email": r"^(.{2}).*(@.*)$",          # Keep first 2 chars + domain
        "phone": r"^.*(.{4})$",               # Keep last 4 digits
        "account": r"^.*(.{4})$"              # Keep last 4 digits
    })


# =============================================================================
# LAYER CONFIGURATION
# =============================================================================
@dataclass
class LayerConfig:
    """7-Layer pipeline configuration."""
    
    # Layer 1-2: Ingestion & Data Quality
    DQ_THRESHOLDS: Dict[str, float] = field(default_factory=lambda: {
        "completeness": 0.95,
        "consistency": 0.90,
        "validity": 0.85
    })
    
    # Layer 3: Feature Engineering
    FEATURE_CATEGORIES: List[str] = field(default_factory=lambda: [
        "velocity", "aggregates", "ratios", "flags", "temporal", "behavioral"
    ])
    
    # Layer 4: Preprocessing
    MATRIX_VERSIONS: List[str] = field(default_factory=lambda: [
        "raw", "scaled", "pca", "encoded"
    ])
    
    # Layer 5: Detection Methods (26 total + Vanguard Extensions)
    DETECTION_METHODS: Dict[str, List[str]] = field(default_factory=lambda: {
        "statistical": ["zscore", "iqr", "grubbs", "dixon", "esd", "copod", "ecod", "hbos", "mcd"],
        "distance": ["knn", "mahalanobis", "lof"],
        "density": ["dbscan", "optics", "hdbscan", "cblof"],
        "clustering": ["kmeans_anomaly", "gmm", "spectral"],
        "trees": ["isolation_forest", "extended_if"],
        "svm": ["one_class_svm"],
        "timeseries": ["stl", "arima_residual", "prophet", "matrix_profile"],
        "graph": ["pagerank", "hits", "community", "centrality"],
        "deep_learning": ["autoencoder", "vae", "som"]
    })
    
    # Layer 6: Ensemble
    ENSEMBLE_METHOD: str = "weighted_average"
    RISK_TIERS: Dict[str, tuple] = field(default_factory=lambda: {
        "Critical": (0.9, 1.0),
        "High": (0.7, 0.9),
        "Medium": (0.5, 0.7),
        "Low": (0.0, 0.5)
    })
    
    # Layer 7: Output
    INVESTIGATION_CAPACITY: int = 1000


# =============================================================================
# APPLICATION CONFIGURATION
# =============================================================================
@dataclass 
class AppConfig:
    """Application settings."""
    TITLE: str = "FCDAI Anomaly Auto Detection Tool - Version 3"
    VERSION: str = "3.0.0"
    HOST: str = "127.0.0.1"
    PORT: int = 8085
    DEBUG: bool = False
    SERVE_LOCALLY: bool = True
    
    PLOTLY_CONFIG: Dict = field(default_factory=lambda: {
        "displaylogo": False,
        "modeBarButtonsToRemove": ["sendDataToCloud", "lasso2d", "select2d"],
        "toImageButtonOptions": {"format": "png", "scale": 2}
    })


# =============================================================================
# DATA SOURCES CONFIGURATION
# =============================================================================
@dataclass
class DataSourceConfig:
    """Multi-source data configuration."""
    SOURCES: Dict[str, Dict] = field(default_factory=lambda: {
        "kyc": {"expected_rows": 100, "key_column": "customer_id"},
        "transactions": {"expected_rows": 700, "key_column": "txn_id"},
        "alerts": {"expected_rows": 50, "key_column": "alert_id"},
        "cases": {"expected_rows": 20, "key_column": "case_id"}
    })


# =============================================================================
# INSTANTIATE CONFIGS
# =============================================================================
PATHS = PathConfig()
THEME = ThemeConfig()
LAYERS = LayerConfig()
PII = PIIConfig()
APP = AppConfig()
DATA_SOURCES = DataSourceConfig()
