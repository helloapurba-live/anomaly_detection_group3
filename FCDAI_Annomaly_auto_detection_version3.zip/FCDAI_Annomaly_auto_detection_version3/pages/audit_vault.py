"""
Project Vanguard Apex - Audit Vault Page
=========================================
Industrial-grade AG Grid data table with pinned columns,
conditional risk formatting, and PII masking toggle.

Author: Project Vanguard Team
"""

import dash
from dash import html, dcc, callback, Input, Output, State, ctx
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import dash_ag_grid as dag
import pandas as pd
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import THEME, APP


dash.register_page(__name__, path="/audit-vault", name="Audit Vault", order=1)


# =============================================================================
# AG GRID COLUMN DEFINITIONS
# =============================================================================
def get_column_defs(columns: list) -> list:
    """Generate AG Grid column definitions with proper formatting."""
    defs = []
    
    for col in columns:
        col_def = {
            "field": col,
            "headerName": col.replace("_", " ").title(),
            "sortable": True,
            "filter": True,
            "resizable": True,
        }
        
        # Pin customer ID column
        if 'customer' in col.lower() or col.lower() == 'id':
            col_def["pinned"] = "left"
            col_def["lockPinned"] = True
            col_def["width"] = 150
        
        # Format score columns with risk gradient
        if 'score' in col.lower() or col == 'anomaly_score':
            col_def["cellStyle"] = {
                "styleConditions": [
                    {"condition": "value < 0.2", "style": {"backgroundColor": "#1a4a2a", "color": "#00C853"}},
                    {"condition": "value >= 0.2 && value < 0.4", "style": {"backgroundColor": "#2a4a1a", "color": "#4CAF50"}},
                    {"condition": "value >= 0.4 && value < 0.6", "style": {"backgroundColor": "#4a4a1a", "color": "#FFC107"}},
                    {"condition": "value >= 0.6 && value < 0.8", "style": {"backgroundColor": "#4a3a1a", "color": "#FF9800"}},
                    {"condition": "value >= 0.8", "style": {"backgroundColor": "#4a1a1a", "color": "#FF5252"}},
                ]
            }
            col_def["valueFormatter"] = {"function": "d3.format('.3f')(params.value)"}
        
        # Format risk level column
        if col == 'risk_level':
            col_def["cellStyle"] = {
                "styleConditions": [
                    {"condition": "value === 'Low'", "style": {"backgroundColor": "#1a4a2a", "color": "#00C853"}},
                    {"condition": "value === 'Low-Medium'", "style": {"backgroundColor": "#2a4a1a", "color": "#4CAF50"}},
                    {"condition": "value === 'Medium'", "style": {"backgroundColor": "#4a4a1a", "color": "#FFC107"}},
                    {"condition": "value === 'Medium-High'", "style": {"backgroundColor": "#4a3a1a", "color": "#FF9800"}},
                    {"condition": "value === 'High'", "style": {"backgroundColor": "#4a1a1a", "color": "#FF5252"}},
                ]
            }
        
        # Format anomaly label
        if col == 'anomaly_label':
            col_def["cellRenderer"] = "agCheckboxCellRenderer"
            col_def["width"] = 100
        
        defs.append(col_def)
    
    return defs


# =============================================================================
# PAGE LAYOUT
# =============================================================================
layout = dmc.Container(
    [
        # Header
        dmc.Group(
            [
                dmc.Title("Audit Vault", order=2),
                dmc.Group(
                    [
                        dmc.Badge(id="record-count-badge", color="cyan", variant="light"),
                        dmc.Button(
                            "Refresh",
                            id="btn-refresh-table",
                            leftSection=DashIconify(icon="mdi:refresh", width=18),
                            variant="light",
                            size="sm",
                        ),
                    ],
                    gap="sm",
                ),
            ],
            justify="space-between",
            mb="lg",
        ),
        
        # Filter Controls
        dmc.Paper(
            [
                dmc.SimpleGrid(
                    cols={"base": 2, "md": 4},
                    spacing="md",
                    children=[
                        dmc.TextInput(
                            id="search-input",
                            placeholder="Search all columns...",
                            leftSection=DashIconify(icon="mdi:magnify", width=18),
                        ),
                        dmc.Select(
                            id="filter-risk",
                            placeholder="Filter by Risk Level",
                            data=[
                                {"value": "all", "label": "All Risk Levels"},
                                {"value": "High", "label": "High"},
                                {"value": "Medium-High", "label": "Medium-High"},
                                {"value": "Medium", "label": "Medium"},
                                {"value": "Low-Medium", "label": "Low-Medium"},
                                {"value": "Low", "label": "Low"},
                            ],
                            value="all",
                            clearable=True,
                        ),
                        dmc.Switch(
                            id="filter-anomalies-only",
                            label="Anomalies Only",
                            checked=False,
                        ),
                    ],
                ),
            ],
            p="md",
            mb="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),
        
        # Data Grid Container
        dmc.Paper(
            [
                html.Div(id="grid-container"),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD, "minHeight": "500px"}
        ),
        
        # Record Detail Modal
        dmc.Modal(
            id="detail-modal",
            title="Record Details",
            size="lg",
            children=[
                html.Div(id="modal-content"),
            ],
        ),
        
        # Store for selected row
        dcc.Store(id="selected-row-store"),
    ],
    fluid=True,
)


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("grid-container", "children"),
    Output("record-count-badge", "children"),
    Input("btn-refresh-table", "n_clicks"),
    Input("filter-risk", "value"),
    Input("filter-anomalies-only", "checked"),
    Input("search-input", "value"),
)
def update_grid(n_clicks, risk_filter, anomalies_only, search):
    """Update the AG Grid with filtered data."""
    try:
        from utils.data_io import data_vault
        from utils.pii_masking import mask_dataframe, detect_pii_columns
        
        df = data_vault.get_scored_data()
        
        if df is None:
            df = data_vault.get_data()
        
        if df is None:
            return dmc.Alert(
                "No data loaded. Import a dataset to begin analysis.",
                title="No Data",
                color="yellow",
            ), "0 Records"
        
        # Apply filters
        if 'anomaly_score' in df.columns:
            if anomalies_only:
                df = df[df['anomaly_score'] > 0.5]
            
            if risk_filter and risk_filter != 'all' and 'risk_level' in df.columns:
                df = df[df['risk_level'] == risk_filter]
        
        # Apply search
        if search:
            mask = df.astype(str).apply(
                lambda col: col.str.contains(search, case=False, na=False)
            ).any(axis=1)
            df = df[mask]
        
        # Apply PII masking (ALWAYS ON)
        pii_cols = detect_pii_columns(df)
        df = mask_dataframe(df, pii_cols)
        
        # Limit to first 1000 rows for performance
        display_df = df.head(1000)
        
        # Build grid
        column_defs = get_column_defs(display_df.columns.tolist())
        
        grid = dag.AgGrid(
            id="audit-grid",
            rowData=display_df.to_dict("records"),
            columnDefs=column_defs,
            defaultColDef={
                "sortable": True,
                "filter": True,
                "resizable": True,
                "minWidth": 100,
            },
            dashGridOptions={
                "pagination": True,
                "paginationPageSize": 50,
                "rowSelection": "single",
                "animateRows": True,
            },
            style={"height": "500px", "width": "100%"},
            className="ag-theme-alpine-dark",
        )
        
        count_text = f"{len(df):,} Records"
        if len(df) > 1000:
            count_text += " (showing 1,000)"
        
        return grid, count_text
        
    except Exception as e:
        return dmc.Alert(f"Error loading data: {str(e)}", color="red"), "Error"


@callback(
    Output("detail-modal", "opened"),
    Output("modal-content", "children"),
    Input("audit-grid", "selectedRows"),
    State("detail-modal", "opened"),
)
def show_record_detail(selected, is_open):
    """Show detailed view of selected record."""
    if not selected:
        return False, None
    
    row = selected[0]
    
    # Create detail cards
    detail_items = []
    for key, value in row.items():
        if pd.notna(value):
            color = "red" if 'score' in key.lower() and float(value) > 0.5 else "blue"
            detail_items.append(
                dmc.Paper(
                    [
                        dmc.Text(key.replace("_", " ").title(), size="xs", c="dimmed"),
                        dmc.Text(str(value), size="sm", fw=500),
                    ],
                    p="sm",
                    withBorder=True,
                    radius="sm",
                )
            )
    
    return True, dmc.SimpleGrid(cols=3, spacing="sm", children=detail_items)
