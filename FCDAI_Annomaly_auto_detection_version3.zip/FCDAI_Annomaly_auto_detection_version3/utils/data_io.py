"""
Project Vanguard Apex - Data I/O Module
=======================================
Handles data import, validation, persistence (Parquet),
and export with anomaly scorecards.

Author: Project Vanguard Team
"""

import os
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional, Tuple, List, Dict, Any
import pandas as pd
import numpy as np
import io
import base64

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import PATHS, PII
from utils.logger import logger


class DataVault:
    """
    Local Parquet-based data persistence layer.
    
    Maintains the "Source of Truth" dataset until explicitly
    cleared or replaced by a new import.
    
    Attributes:
        current_data: The active DataFrame in memory
        metadata: Import metadata (timestamp, filename, rows)
    """
    
    def __init__(self):
        """Initialize the data vault."""
        self._current_data: Optional[pd.DataFrame] = None
        self._scored_data: Optional[pd.DataFrame] = None
        self._metadata: Dict[str, Any] = {}
        self._load_persisted_data()
    
    def _load_persisted_data(self):
        """Load any previously persisted data from vault."""
        vault_path = PATHS.DATA_VAULT / "current.parquet"
        meta_path = PATHS.DATA_VAULT / "metadata.json"
        scored_path = PATHS.DATA_VAULT / "scored.parquet"
        
        # Load raw data
        if vault_path.exists():
            try:
                self._current_data = pd.read_parquet(vault_path)
                if meta_path.exists():
                    import json
                    with open(meta_path, 'r') as f:
                        self._metadata = json.load(f)
            except Exception as e:
                logger.log_error(e, "Loading persisted data")
        
        # Load scored data if exists
        if scored_path.exists():
            try:
                self._scored_data = pd.read_parquet(scored_path)
            except Exception as e:
                logger.log_error(e, "Loading scored data")
    
    def import_data(
        self, 
        contents: str, 
        filename: str
    ) -> Tuple[bool, str, Optional[pd.DataFrame]]:
        """
        Import data from uploaded file contents.
        
        Args:
            contents: Base64-encoded file contents
            filename: Original filename
            
        Returns:
            Tuple of (success, message, DataFrame or None)
        """
        try:
            # Decode contents
            content_type, content_string = contents.split(',')
            decoded = base64.b64decode(content_string)
            
            # Parse based on extension
            if filename.endswith('.csv'):
                df = pd.read_csv(io.StringIO(decoded.decode('utf-8')))
            elif filename.endswith('.parquet'):
                df = pd.read_parquet(io.BytesIO(decoded))
            elif filename.endswith(('.xlsx', '.xls')):
                df = pd.read_excel(io.BytesIO(decoded))
            else:
                return False, f"Unsupported file type: {filename}", None
            
            # Validate
            is_valid, issues = self._validate_data(df)
            if not is_valid:
                return False, f"Validation failed: {', '.join(issues)}", None
            
            # Store and persist
            self._current_data = df
            self._metadata = {
                "filename": filename,
                "rows": len(df),
                "columns": len(df.columns),
                "import_time": datetime.now().isoformat(),
                "columns_list": df.columns.tolist()
            }
            
            self._persist_data()
            
            # Log the import
            logger.log_data_import(filename, len(df), len(df.columns))
            
            return True, f"Successfully imported {len(df):,} rows", df
            
        except Exception as e:
            logger.log_error(e, f"Data import: {filename}")
            return False, f"Import error: {str(e)}", None
    
    def _validate_data(self, df: pd.DataFrame) -> Tuple[bool, List[str]]:
        """Validate imported data for required structure."""
        issues = []
        
        # Check minimum rows
        if len(df) < 10:
            issues.append("Dataset has fewer than 10 rows")
        
        # Check for at least some numeric columns
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) == 0:
            issues.append("No numeric columns found for analysis")
        
        # Check for completely empty columns
        empty_cols = df.columns[df.isnull().all()].tolist()
        if empty_cols:
            issues.append(f"Empty columns: {empty_cols}")
        
        return len(issues) == 0, issues
    
    def _persist_data(self):
        """Save current data to Parquet vault."""
        if self._current_data is not None:
            vault_path = PATHS.DATA_VAULT / "current.parquet"
            meta_path = PATHS.DATA_VAULT / "metadata.json"
            
            try:
                self._current_data.to_parquet(vault_path, index=False)
                
                import json
                with open(meta_path, 'w') as f:
                    json.dump(self._metadata, f, indent=2)
                    
            except Exception as e:
                logger.log_error(e, "Persisting data to vault")
    
    def get_data(self) -> Optional[pd.DataFrame]:
        """Get the current active dataset."""
        return self._current_data
    
    def get_scored_data(self) -> Optional[pd.DataFrame]:
        """Get data with anomaly scores."""
        return self._scored_data
    
    def set_scored_data(self, df: pd.DataFrame):
        """Set the scored dataset."""
        self._scored_data = df
        
        # Persist scored data
        scored_path = PATHS.DATA_VAULT / "scored.parquet"
        try:
            df.to_parquet(scored_path, index=False)
        except Exception as e:
            logger.log_error(e, "Persisting scored data")
    
    def get_metadata(self) -> Dict[str, Any]:
        """Get import metadata."""
        return self._metadata
    
    def clear_data(self):
        """Clear all data from vault."""
        self._current_data = None
        self._scored_data = None
        self._metadata = {}
        
        # Remove persisted files
        for f in ["current.parquet", "scored.parquet", "metadata.json"]:
            path = PATHS.DATA_VAULT / f
            if path.exists():
                path.unlink()
        
        logger.log_action("Data Cleared", metadata={"vault": "cleared"})
    
    def export_scorecard(
        self, 
        format: str = "excel"
    ) -> Tuple[bytes, str]:
        """
        Export anomaly scorecard with full traceability.
        
        Args:
            format: "excel" or "csv"
            
        Returns:
            Tuple of (file_bytes, filename)
        """
        if self._scored_data is None:
            raise ValueError("No scored data available. Run pipeline first.")
        
        df = self._scored_data.copy()
        
        # Add export metadata
        export_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        output = io.BytesIO()
        
        if format == "excel":
            filename = f"vanguard_scorecard_{export_timestamp}.xlsx"
            
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                # Main data sheet
                df.to_excel(writer, sheet_name='Anomaly Scorecard', index=False)
                
                # Summary sheet
                summary = pd.DataFrame([{
                    "Export Date": datetime.now().isoformat(),
                    "Total Records": len(df),
                    "Anomalies Detected": df['anomaly_score'].apply(
                        lambda x: x > 0.5 if pd.notna(x) else False
                    ).sum() if 'anomaly_score' in df.columns else 'N/A',
                    "Source File": self._metadata.get('filename', 'Unknown'),
                    "Import Date": self._metadata.get('import_time', 'Unknown')
                }])
                summary.to_excel(writer, sheet_name='Export Summary', index=False)
        else:
            filename = f"vanguard_scorecard_{export_timestamp}.csv"
            df.to_csv(output, index=False)
        
        output.seek(0)
        
        # Log export
        logger.log_export(format.upper(), filename, len(df))
        
        return output.getvalue(), filename


# Global data vault instance
data_vault = DataVault()


# Convenience functions
def clear_data():
    """Clear all data from vault."""
    data_vault.clear_data()


def clear_scored_data():
    """Clear only scored data."""
    data_vault._scored_data = None
    scored_path = PATHS.DATA_VAULT / "scored.parquet"
    if scored_path.exists():
        scored_path.unlink()

