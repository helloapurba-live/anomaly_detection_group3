"""
Project Vanguard Apex - PII Masking Module
==========================================
Privacy mode for masking sensitive data in the UI
while keeping underlying data intact for ML processing.

Author: Project Vanguard Team
"""

import re
import pandas as pd
import numpy as np
from typing import List, Optional
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import PII


def mask_value(value: str, visible_chars: int = 4, pattern: str = "XXXX") -> str:
    """
    Mask a single value, keeping only the last N characters visible.
    
    Args:
        value: String to mask
        visible_chars: Number of characters to keep visible at end
        pattern: Replacement pattern for masked portion
        
    Returns:
        Masked string (e.g., "CUST-000123" -> "CUST-XXXX23")
    """
    if pd.isna(value) or value is None:
        return ""
    
    value = str(value)
    
    if len(value) <= visible_chars:
        return value
    
    # Find the prefix (before last hyphen or space)
    separators = ['-', '_', ' ']
    prefix_end = 0
    for sep in separators:
        idx = value.rfind(sep)
        if idx > prefix_end:
            prefix_end = idx + 1
    
    prefix = value[:prefix_end]
    suffix = value[prefix_end:]
    
    if len(suffix) <= visible_chars:
        return value
    
    masked_portion = pattern
    visible_portion = suffix[-visible_chars:]
    
    return f"{prefix}{masked_portion}{visible_portion}"


def mask_email(email: str) -> str:
    """
    Mask an email address, keeping first 2 chars and domain.
    
    Example: "john.doe@company.com" -> "jo****@company.com"
    """
    if pd.isna(email) or '@' not in str(email):
        return str(email) if not pd.isna(email) else ""
    
    email = str(email)
    local, domain = email.rsplit('@', 1)
    
    if len(local) <= 2:
        masked_local = local
    else:
        masked_local = local[:2] + "****"
    
    return f"{masked_local}@{domain}"


def mask_phone(phone: str) -> str:
    """
    Mask a phone number, keeping only last 4 digits.
    
    Example: "+1-555-123-4567" -> "***-***-**-4567"
    """
    if pd.isna(phone):
        return ""
    
    phone = str(phone)
    digits = re.sub(r'\D', '', phone)
    
    if len(digits) <= 4:
        return phone
    
    return f"***-***-{digits[-4:]}"


def mask_account(account: str) -> str:
    """
    Mask an account number, keeping last 4 digits.
    
    Example: "ACC-1234567890" -> "ACC-******7890"
    """
    if pd.isna(account):
        return ""
    
    account = str(account)
    
    # Find prefix
    match = re.match(r'^([A-Za-z]+[-_]?)', account)
    prefix = match.group(1) if match else ""
    
    suffix = account[len(prefix):]
    
    if len(suffix) <= 4:
        return account
    
    return f"{prefix}******{suffix[-4:]}"


def mask_dataframe(
    df: pd.DataFrame, 
    columns: Optional[List[str]] = None,
    enabled: bool = True
) -> pd.DataFrame:
    """
    Apply PII masking to specified columns in a DataFrame.
    
    Args:
        df: DataFrame to mask
        columns: Columns to mask. If None, uses config.PII.MASKED_COLUMNS
        enabled: Whether masking is enabled
        
    Returns:
        DataFrame with masked values (original data unchanged)
    """
    if not enabled:
        return df
    
    masked_df = df.copy()
    columns = columns or PII.MASKED_COLUMNS
    
    for col in columns:
        if col not in masked_df.columns:
            continue
        
        col_lower = col.lower()
        
        # Apply appropriate masking based on column type
        if 'email' in col_lower:
            masked_df[col] = masked_df[col].apply(mask_email)
        elif 'phone' in col_lower or 'mobile' in col_lower:
            masked_df[col] = masked_df[col].apply(mask_phone)
        elif 'account' in col_lower:
            masked_df[col] = masked_df[col].apply(mask_account)
        else:
            # Default masking
            masked_df[col] = masked_df[col].apply(
                lambda x: mask_value(x, PII.VISIBLE_CHARS, PII.MASK_PATTERN)
            )
    
    return masked_df


def detect_pii_columns(df: pd.DataFrame) -> List[str]:
    """
    Automatically detect columns that may contain PII.
    
    Args:
        df: DataFrame to analyze
        
    Returns:
        List of column names likely to contain PII
    """
    pii_keywords = [
        'customer', 'client', 'account', 'id', 'name', 'email',
        'phone', 'mobile', 'ssn', 'social', 'address', 'zip',
        'postal', 'dob', 'birth', 'passport'
    ]
    
    detected = []
    
    for col in df.columns:
        col_lower = col.lower()
        for keyword in pii_keywords:
            if keyword in col_lower:
                detected.append(col)
                break
    
    return detected
