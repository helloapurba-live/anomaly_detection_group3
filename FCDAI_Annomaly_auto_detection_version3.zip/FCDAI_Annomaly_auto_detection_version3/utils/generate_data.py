"""
Synthetic Data Generator for Testing
=====================================
Generate realistic AML transaction data with controllable anomalies.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta


def generate_aml_data(
    n_records: int = 1000,
    n_customers: int = 100,
    anomaly_rate: float = 0.05,
    seed: int = 42
) -> pd.DataFrame:
    """
    Generate synthetic AML transaction data.
    
    Args:
        n_records: Number of transactions
        n_customers: Number of unique customers
        anomaly_rate: Proportion of anomalies to inject
        seed: Random seed
        
    Returns:
        DataFrame with transactions and injected anomalies
    """
    np.random.seed(seed)
    
    # Generate base data
    data = {
        'txn_id': [f'TXN{i:07d}' for i in range(n_records)],
        'customer_id': [f'CUST{np.random.randint(1, n_customers + 1):05d}' 
                       for _ in range(n_records)],
        'timestamp': [
            datetime.now() - timedelta(days=np.random.randint(0, 365))
            for _ in range(n_records)
        ],
        'amount': np.abs(np.random.lognormal(mean=6, sigma=1.5, size=n_records)),
        'transaction_type': np.random.choice(
            ['WIRE', 'ACH', 'CASH', 'CHECK', 'CARD'],
            size=n_records,
            p=[0.2, 0.3, 0.15, 0.15, 0.2]
        ),
        'country': np.random.choice(
            ['US', 'GB', 'DE', 'FR', 'CH', 'SG', 'HK', 'OTHER'],
            size=n_records,
            p=[0.4, 0.15, 0.1, 0.1, 0.05, 0.05, 0.05, 0.1]
        ),
        'account_age_days': np.random.randint(30, 3650, size=n_records),
        'previous_txn_count': np.random.poisson(50, size=n_records),
        'risk_rating': np.random.choice([1, 2, 3, 4, 5], size=n_records, p=[0.3, 0.3, 0.2, 0.15, 0.05]),
    }
    
    df = pd.DataFrame(data)
    
    # Add derived features
    df['amount_log'] = np.log1p(df['amount'])
    df['is_high_risk_country'] = df['country'].isin(['HK', 'CH', 'OTHER']).astype(int)
    df['is_new_account'] = (df['account_age_days'] < 90).astype(int)
    
    # Inject anomalies
    n_anomalies = int(n_records * anomaly_rate)
    anomaly_indices = np.random.choice(n_records, size=n_anomalies, replace=False)
    
    df['is_anomaly_injected'] = False
    df.loc[anomaly_indices, 'is_anomaly_injected'] = True
    
    # Make anomalies unusual
    for idx in anomaly_indices:
        anomaly_type = np.random.choice(['amount', 'frequency', 'pattern', 'mixed'])
        
        if anomaly_type == 'amount':
            # Very large amount
            df.loc[idx, 'amount'] = np.random.uniform(50000, 500000)
        elif anomaly_type == 'frequency':
            # Very new account with high activity
            df.loc[idx, 'account_age_days'] = np.random.randint(1, 30)
            df.loc[idx, 'previous_txn_count'] = np.random.randint(100, 500)
        elif anomaly_type == 'pattern':
            # Round amount to high-risk country
            df.loc[idx, 'amount'] = np.random.choice([10000, 50000, 100000])
            df.loc[idx, 'country'] = np.random.choice(['HK', 'CH', 'OTHER'])
        else:  # mixed
            df.loc[idx, 'amount'] = np.random.uniform(100000, 1000000)
            df.loc[idx, 'country'] = 'OTHER'
            df.loc[idx, 'risk_rating'] = 5
    
    # Recalculate derived features
    df['amount_log'] = np.log1p(df['amount'])
    df['is_high_risk_country'] = df['country'].isin(['HK', 'CH', 'OTHER']).astype(int)
    df['is_new_account'] = (df['account_age_days'] < 90).astype(int)
    
    return df


def generate_multi_source_data(
    seed: int = 42
) -> dict:
    """
    Generate multi-source data matching the diagram:
    - KYC: 100 rows
    - Transactions: 700 rows
    - Alerts: 50 rows
    - Cases: 20 rows
    """
    np.random.seed(seed)
    
    # KYC data
    kyc = pd.DataFrame({
        'customer_id': [f'CUST{i:05d}' for i in range(1, 101)],
        'name': [f'Customer {i}' for i in range(1, 101)],
        'country': np.random.choice(['US', 'GB', 'DE', 'FR', 'OTHER'], 100),
        'risk_rating': np.random.choice([1, 2, 3, 4, 5], 100),
        'account_open_date': [
            datetime.now() - timedelta(days=np.random.randint(30, 3650))
            for _ in range(100)
        ],
        'pep_status': np.random.choice([0, 1], 100, p=[0.95, 0.05]),
        'kyc_score': np.random.uniform(0.5, 1.0, 100)
    })
    
    # Transactions
    txn = generate_aml_data(n_records=700, n_customers=100, anomaly_rate=0.05, seed=seed)
    
    # Alerts
    alerts = pd.DataFrame({
        'alert_id': [f'ALT{i:05d}' for i in range(1, 51)],
        'customer_id': np.random.choice([f'CUST{i:05d}' for i in range(1, 101)], 50),
        'alert_date': [
            datetime.now() - timedelta(days=np.random.randint(0, 90))
            for _ in range(50)
        ],
        'alert_type': np.random.choice(['TM', 'SAR', 'MAN'], 50),
        'status': np.random.choice(['Open', 'Closed', 'Escalated'], 50),
        'score': np.random.uniform(0.5, 1.0, 50)
    })
    
    # Cases
    cases = pd.DataFrame({
        'case_id': [f'CASE{i:04d}' for i in range(1, 21)],
        'customer_id': np.random.choice([f'CUST{i:05d}' for i in range(1, 101)], 20),
        'case_open_date': [
            datetime.now() - timedelta(days=np.random.randint(0, 180))
            for _ in range(20)
        ],
        'case_type': np.random.choice(['SAR', 'STR', 'EDD'], 20),
        'status': np.random.choice(['Open', 'Closed', 'Filed'], 20),
        'outcome': np.random.choice(['TP', 'FP', 'Pending'], 20)
    })
    
    return {
        'kyc': kyc,
        'transactions': txn,
        'alerts': alerts,
        'cases': cases
    }


if __name__ == "__main__":
    # Generate sample data
    sources = generate_multi_source_data()
    
    print("Generated data sources:")
    for name, df in sources.items():
        print(f"  {name}: {len(df)} rows, {len(df.columns)} columns")
