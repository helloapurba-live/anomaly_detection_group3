
import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from pathlib import Path
import logging

# Configure logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("DataGen")

class DataGenerator:
    """
    Generates comprehensive AML data across 5 core tables:
    1. Transactions (Main Ledger)
    2. Party (Customer/Entity)
    3. Account (Balances & Status)
    4. Watchlist (Sanctions/PEP)
    5. Relationships (Entity Links)
    """

    def __init__(self, seed: int = 42):
        np.random.seed(seed)
        random.seed(seed)

    def generate_party_data(self, num_parties: int = 100) -> pd.DataFrame:
        """Generates Party/Customer metadata."""
        ids = [f"CUST_{i:06d}" for i in range(num_parties)]
        types = np.random.choice(['Individual', 'Corporate', 'Trust'], num_parties, p=[0.7, 0.2, 0.1])
        risk_ratings = np.random.choice(['Low', 'Medium', 'High'], num_parties, p=[0.6, 0.3, 0.1])
        countries = np.random.choice(['US', 'UK', 'SG', 'KY', 'VG'], num_parties)
        
        df = pd.DataFrame({
            'party_id': ids,
            'party_type': types,
            'risk_rating': risk_ratings,
            'country_of_origin': countries,
            'kyc_status': 'Verified',
            'onboarding_date': [datetime.now() - timedelta(days=random.randint(10, 3650)) for _ in range(num_parties)]
        })
        logger.info(f"Generated {len(df)} Party records.")
        return df

    def generate_account_data(self, party_ids: List[str]) -> pd.DataFrame:
        """Generates Account data linked to Parties."""
        num_accounts = int(len(party_ids) * 1.5)  # Avg 1.5 accounts per party
        acc_ids = [f"ACC_{i:09d}" for i in range(num_accounts)]
        owners = np.random.choice(party_ids, num_accounts)
        
        df = pd.DataFrame({
            'account_id': acc_ids,
            'party_id': owners,
            'account_type': np.random.choice(['Savings', 'Current', 'Corporate', 'Investment'], num_accounts),
            'status': np.random.choice(['Active', 'Dormant', 'Frozen'], num_accounts, p=[0.9, 0.08, 0.02]),
            'currency': np.random.choice(['USD', 'EUR', 'GBP', 'SGD'], num_accounts),
            'open_date': [datetime.now() - timedelta(days=random.randint(10, 2000)) for _ in range(num_accounts)]
        })
        logger.info(f"Generated {len(df)} Account records.")
        return df

    def generate_watchlist_data(self, size: int = 50) -> pd.DataFrame:
        """Generates Sanctions/Watchlist data."""
        df = pd.DataFrame({
            'watchlist_id': [f"WL_{i:05d}" for i in range(size)],
            'entity_name': [f"Bad Actor {i}" for i in range(size)],
            'list_source': np.random.choice(['OFAC', 'UN', 'EU', 'HM_TREASURY'], size),
            'category': np.random.choice(['Sanctions', 'PEP', 'Adverse Media'], size),
            'added_date': [datetime.now() - timedelta(days=random.randint(1, 1000)) for _ in range(size)]
        })
        return df

    def generate_relationship_data(self, party_ids: List[str], count: int = 200) -> pd.DataFrame:
        """Generates links between parties (e.g., Beneficial Owner, Director)."""
        df = pd.DataFrame({
            'from_party_id': np.random.choice(party_ids, count),
            'to_party_id': np.random.choice(party_ids, count),
            'relationship_type': np.random.choice(['Director', 'Shareholder', 'Signatory', 'Guarantor'], count),
            'percentage': np.random.uniform(1, 100, count).round(2)
        })
        # Remove self-loops
        df = df[df['from_party_id'] != df['to_party_id']]
        return df

    def generate_transactions(self, account_ids: List[str], num_txns: int = 1000) -> pd.DataFrame:
        """Generates core Transaction ledger."""
        df = pd.DataFrame({
            'transaction_id': [f"TXN_{i:09d}" for i in range(num_txns)],
            'account_id': np.random.choice(account_ids, num_txns),
            'counterparty_account': [f"EXT_{random.randint(1000,9999)}" for _ in range(num_txns)],
            'amount': np.random.exponential(1000, num_txns).round(2),
            'currency': 'USD',
            'txn_type': np.random.choice(['Wire', 'ACH', 'Cash', 'Check'], num_txns),
            'timestamp': [datetime.now() - timedelta(days=random.randint(0, 30), hours=random.randint(0,23)) for _ in range(num_txns)],
            'is_credit': np.random.choice([True, False], num_txns)
        })
        # Add basic anomalies (structuring)
        mask = np.random.random(num_txns) < 0.02
        df.loc[mask, 'amount'] = 9900 + np.random.uniform(0, 99, sum(mask))
        
        logger.info(f"Generated {len(df)} Transaction records.")
        return df

    def generate_full_schema(self, scale: str = 'medium') -> Dict[str, pd.DataFrame]:
        """Orchestrates generation of all tables based on scale."""
        scales = {
            'small': {'parties': 50, 'txns': 500},
            'medium': {'parties': 200, 'txns': 2000},
            'large': {'parties': 1000, 'txns': 10000}
        }
        cfg = scales.get(scale, scales['medium'])
        
        parties = self.generate_party_data(cfg['parties'])
        accounts = self.generate_account_data(parties['party_id'].tolist())
        txns = self.generate_transactions(accounts['account_id'].tolist(), cfg['txns'])
        watchlist = self.generate_watchlist_data()
        relationships = self.generate_relationship_data(parties['party_id'].tolist())
        
        return {
            "transactions": txns,
            "party": parties,
            "account": accounts,
            "watchlist": watchlist,
            "relationships": relationships
        }

if __name__ == "__main__":
    dg = DataGenerator()
    data = dg.generate_full_schema('small')
    for k, v in data.items():
        print(f"{k}: {v.shape}")
