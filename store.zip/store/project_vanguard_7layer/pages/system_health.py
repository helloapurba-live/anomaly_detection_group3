"""
System Health Page
==================
System monitoring and administration.
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import psutil
import sys
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP


dash.register_page(__name__, path="/health", name="System Health", order=7)


layout = dmc.Container(
    [
        dmc.Group(
            [
                dmc.Title("System Health", order=2),
                dmc.Badge(f"v{APP.VERSION}", color="cyan", variant="light"),
            ],
            justify="space-between",
            mb="lg",
        ),
        
        # System Stats
        dmc.SimpleGrid(
            cols={"base": 2, "md": 4},
            spacing="lg",
            mb="lg",
            children=[
                dmc.Paper(
                    [
                        dmc.Group(
                            [
                                dmc.ThemeIcon(
                                    DashIconify(icon="mdi:cpu-64-bit", width=24),
                                    size="xl",
                                    color="cyan",
                                    variant="light",
                                ),
                                dmc.Stack(
                                    [
                                        dmc.Text("CPU", c="dimmed", size="sm"),
                                        dmc.Text(id="stat-cpu", fw=700),
                                    ],
                                    gap=0,
                                ),
                            ],
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Group(
                            [
                                dmc.ThemeIcon(
                                    DashIconify(icon="mdi:memory", width=24),
                                    size="xl",
                                    color="grape",
                                    variant="light",
                                ),
                                dmc.Stack(
                                    [
                                        dmc.Text("Memory", c="dimmed", size="sm"),
                                        dmc.Text(id="stat-memory", fw=700),
                                    ],
                                    gap=0,
                                ),
                            ],
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Group(
                            [
                                dmc.ThemeIcon(
                                    DashIconify(icon="mdi:harddisk", width=24),
                                    size="xl",
                                    color="orange",
                                    variant="light",
                                ),
                                dmc.Stack(
                                    [
                                        dmc.Text("Disk", c="dimmed", size="sm"),
                                        dmc.Text(id="stat-disk", fw=700),
                                    ],
                                    gap=0,
                                ),
                            ],
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Group(
                            [
                                dmc.ThemeIcon(
                                    DashIconify(icon="mdi:clock", width=24),
                                    size="xl",
                                    color="green",
                                    variant="light",
                                ),
                                dmc.Stack(
                                    [
                                        dmc.Text("Uptime", c="dimmed", size="sm"),
                                        dmc.Text(id="stat-uptime", fw=700),
                                    ],
                                    gap=0,
                                ),
                            ],
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
            ],
        ),
        
        # Air-gapped status
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.ThemeIcon(
                            DashIconify(icon="mdi:shield-lock", width=24),
                            size="xl",
                            color="green",
                            variant="filled",
                        ),
                        dmc.Stack(
                            [
                                dmc.Text("AIR-GAPPED MODE ACTIVE", fw=700),
                                dmc.Text("No external network connections. All resources served locally.", c="dimmed", size="sm"),
                            ],
                            gap=0,
                        ),
                    ],
                ),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": "rgba(0,100,0,0.1)", "borderColor": THEME.SUCCESS},
            mb="lg",
        ),
        
        # Platform info
        dmc.Paper(
            [
                dmc.Text("Platform Configuration", fw=600, mb="md"),
                dmc.SimpleGrid(
                    cols=2,
                    children=[
                        dmc.Group([dmc.Text("Layers", c="dimmed"), dmc.Text("7", fw=600)]),
                        dmc.Group([dmc.Text("Detection Methods", c="dimmed"), dmc.Text("26", fw=600)]),
                        dmc.Group([dmc.Text("Categories", c="dimmed"), dmc.Text("8", fw=600)]),
                        dmc.Group([dmc.Text("Queue Capacity", c="dimmed"), dmc.Text("1,000", fw=600)]),
                        dmc.Group([dmc.Text("Matrix Versions", c="dimmed"), dmc.Text("4", fw=600)]),
                        dmc.Group([dmc.Text("Feature Categories", c="dimmed"), dmc.Text("6", fw=600)]),
                    ],
                ),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
            mb="lg",
        ),
        
        # Refresh interval
        dcc.Interval(id="interval-health", interval=5000, n_intervals=0),
    ],
    fluid=True,
)


@callback(
    [Output("stat-cpu", "children"),
     Output("stat-memory", "children"),
     Output("stat-disk", "children"),
     Output("stat-uptime", "children")],
    Input("interval-health", "n_intervals"),
)
def update_stats(n):
    try:
        cpu = f"{psutil.cpu_percent():.0f}%"
        mem = f"{psutil.virtual_memory().percent:.0f}%"
        disk = f"{psutil.disk_usage('/').percent:.0f}%"
        
        import time
        boot_time = psutil.boot_time()
        uptime_seconds = time.time() - boot_time
        hours = int(uptime_seconds // 3600)
        uptime = f"{hours}h"
    except:
        cpu = "N/A"
        mem = "N/A"
        disk = "N/A"
        uptime = "N/A"
    
    return cpu, mem, disk, uptime
