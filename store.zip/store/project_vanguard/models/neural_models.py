"""
Project Vanguard Apex - Advanced Neural Models
===============================================
Autoencoder, VAE, and deep learning anomaly detectors
for unsupervised AML detection.

Author: Project Vanguard Team
"""

import numpy as np
import pandas as pd
from typing import Tuple, Optional, Dict, Any
from sklearn.preprocessing import StandardScaler
import warnings

warnings.filterwarnings('ignore')


class AutoencoderAnomalyDetector:
    """
    Shallow Autoencoder for Anomaly Detection.
    Uses reconstruction error as anomaly score.
    Works without TensorFlow/PyTorch for air-gapped environments.
    """
    
    def __init__(
        self,
        encoding_dim: int = 8,
        hidden_dim: int = 16,
        learning_rate: float = 0.01,
        epochs: int = 100,
        batch_size: int = 32,
        contamination: float = 0.05,
        random_state: int = 42
    ):
        self.encoding_dim = encoding_dim
        self.hidden_dim = hidden_dim
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.batch_size = batch_size
        self.contamination = contamination
        self.random_state = random_state
        
        self.scaler = StandardScaler()
        self.weights_: Dict[str, np.ndarray] = {}
        self.threshold_ = None
        self.is_fitted_ = False
        
    def _relu(self, x: np.ndarray) -> np.ndarray:
        """ReLU activation."""
        return np.maximum(0, x)
    
    def _relu_derivative(self, x: np.ndarray) -> np.ndarray:
        """ReLU derivative."""
        return (x > 0).astype(float)
    
    def _sigmoid(self, x: np.ndarray) -> np.ndarray:
        """Sigmoid activation (for output)."""
        return 1 / (1 + np.exp(-np.clip(x, -500, 500)))
    
    def _init_weights(self, input_dim: int):
        """Initialize weights using Xavier initialization."""
        np.random.seed(self.random_state)
        
        # Encoder: input -> hidden -> encoding
        self.weights_['W1'] = np.random.randn(input_dim, self.hidden_dim) * np.sqrt(2.0 / input_dim)
        self.weights_['b1'] = np.zeros((1, self.hidden_dim))
        self.weights_['W2'] = np.random.randn(self.hidden_dim, self.encoding_dim) * np.sqrt(2.0 / self.hidden_dim)
        self.weights_['b2'] = np.zeros((1, self.encoding_dim))
        
        # Decoder: encoding -> hidden -> output
        self.weights_['W3'] = np.random.randn(self.encoding_dim, self.hidden_dim) * np.sqrt(2.0 / self.encoding_dim)
        self.weights_['b3'] = np.zeros((1, self.hidden_dim))
        self.weights_['W4'] = np.random.randn(self.hidden_dim, input_dim) * np.sqrt(2.0 / self.hidden_dim)
        self.weights_['b4'] = np.zeros((1, input_dim))
    
    def _forward(self, X: np.ndarray) -> Tuple[np.ndarray, Dict]:
        """Forward pass through autoencoder."""
        cache = {}
        
        # Encoder
        cache['z1'] = X @ self.weights_['W1'] + self.weights_['b1']
        cache['a1'] = self._relu(cache['z1'])
        cache['z2'] = cache['a1'] @ self.weights_['W2'] + self.weights_['b2']
        cache['encoding'] = self._relu(cache['z2'])
        
        # Decoder
        cache['z3'] = cache['encoding'] @ self.weights_['W3'] + self.weights_['b3']
        cache['a3'] = self._relu(cache['z3'])
        cache['z4'] = cache['a3'] @ self.weights_['W4'] + self.weights_['b4']
        cache['output'] = cache['z4']  # Linear output
        
        return cache['output'], cache
    
    def _backward(self, X: np.ndarray, cache: Dict, output: np.ndarray) -> Dict:
        """Backward pass (backpropagation)."""
        m = X.shape[0]
        grads = {}
        
        # Output layer
        dz4 = (output - X) / m
        grads['W4'] = cache['a3'].T @ dz4
        grads['b4'] = np.sum(dz4, axis=0, keepdims=True)
        
        # Hidden decoder layer
        da3 = dz4 @ self.weights_['W4'].T
        dz3 = da3 * self._relu_derivative(cache['z3'])
        grads['W3'] = cache['encoding'].T @ dz3
        grads['b3'] = np.sum(dz3, axis=0, keepdims=True)
        
        # Encoding layer
        dencoding = dz3 @ self.weights_['W3'].T
        dz2 = dencoding * self._relu_derivative(cache['z2'])
        grads['W2'] = cache['a1'].T @ dz2
        grads['b2'] = np.sum(dz2, axis=0, keepdims=True)
        
        # Hidden encoder layer
        da1 = dz2 @ self.weights_['W2'].T
        dz1 = da1 * self._relu_derivative(cache['z1'])
        grads['W1'] = X.T @ dz1
        grads['b1'] = np.sum(dz1, axis=0, keepdims=True)
        
        return grads
    
    def fit(self, X: np.ndarray) -> 'AutoencoderAnomalyDetector':
        """Train the autoencoder."""
        X_scaled = self.scaler.fit_transform(X)
        self._init_weights(X_scaled.shape[1])
        
        n_samples = X_scaled.shape[0]
        n_batches = max(1, n_samples // self.batch_size)
        
        for epoch in range(self.epochs):
            # Shuffle data
            indices = np.random.permutation(n_samples)
            X_shuffled = X_scaled[indices]
            
            for i in range(n_batches):
                start_idx = i * self.batch_size
                end_idx = min((i + 1) * self.batch_size, n_samples)
                X_batch = X_shuffled[start_idx:end_idx]
                
                # Forward pass
                output, cache = self._forward(X_batch)
                
                # Backward pass
                grads = self._backward(X_batch, cache, output)
                
                # Update weights
                for key in self.weights_:
                    self.weights_[key] -= self.learning_rate * grads[key]
        
        # Calculate threshold based on reconstruction errors
        reconstruction_errors = self.reconstruction_error(X_scaled)
        self.threshold_ = np.percentile(reconstruction_errors, 100 * (1 - self.contamination))
        self.is_fitted_ = True
        
        return self
    
    def reconstruction_error(self, X: np.ndarray) -> np.ndarray:
        """Calculate reconstruction error (MSE per sample)."""
        if not self.is_fitted_ and len(self.weights_) == 0:
            raise ValueError("Model not fitted yet.")
        
        output, _ = self._forward(X)
        mse = np.mean((X - output) ** 2, axis=1)
        return mse
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict anomaly labels (1 = anomaly, -1 = normal)."""
        X_scaled = self.scaler.transform(X)
        errors = self.reconstruction_error(X_scaled)
        return np.where(errors > self.threshold_, 1, -1)
    
    def decision_function(self, X: np.ndarray) -> np.ndarray:
        """Return anomaly scores (higher = more anomalous)."""
        X_scaled = self.scaler.transform(X)
        return self.reconstruction_error(X_scaled)


class MatrixProfileAnomalyDetector:
    """
    Matrix Profile-based anomaly detector for time-series.
    Identifies discord (anomalous subsequences).
    """
    
    def __init__(
        self,
        window_size: int = 10,
        contamination: float = 0.05
    ):
        self.window_size = window_size
        self.contamination = contamination
        self.threshold_ = None
        self.is_fitted_ = False
    
    def _compute_matrix_profile(self, ts: np.ndarray) -> np.ndarray:
        """Compute matrix profile using STOMP-like algorithm."""
        n = len(ts)
        m = self.window_size
        
        if n < m:
            return np.zeros(1)
        
        profile_len = n - m + 1
        profile = np.full(profile_len, np.inf)
        
        # Z-normalize subsequences
        for i in range(profile_len):
            subseq_i = ts[i:i + m]
            mean_i = np.mean(subseq_i)
            std_i = np.std(subseq_i) + 1e-8
            norm_i = (subseq_i - mean_i) / std_i
            
            for j in range(profile_len):
                if abs(i - j) <= m // 2:  # Trivial match exclusion
                    continue
                
                subseq_j = ts[j:j + m]
                mean_j = np.mean(subseq_j)
                std_j = np.std(subseq_j) + 1e-8
                norm_j = (subseq_j - mean_j) / std_j
                
                dist = np.sqrt(np.sum((norm_i - norm_j) ** 2))
                
                if dist < profile[i]:
                    profile[i] = dist
        
        return profile
    
    def fit(self, X: np.ndarray) -> 'MatrixProfileAnomalyDetector':
        """Fit the matrix profile detector."""
        if X.ndim == 1:
            X = X.reshape(-1, 1)
        
        # Compute profile for each feature and aggregate
        all_profiles = []
        for col in range(X.shape[1]):
            profile = self._compute_matrix_profile(X[:, col])
            all_profiles.append(profile)
        
        # Aggregate profiles
        min_len = min(len(p) for p in all_profiles)
        aggregated = np.mean([p[:min_len] for p in all_profiles], axis=0)
        
        # Set threshold
        self.threshold_ = np.percentile(aggregated, 100 * (1 - self.contamination))
        self.is_fitted_ = True
        
        return self
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict anomalies."""
        scores = self.decision_function(X)
        return np.where(scores > self.threshold_, 1, -1)
    
    def decision_function(self, X: np.ndarray) -> np.ndarray:
        """Return anomaly scores."""
        if X.ndim == 1:
            X = X.reshape(-1, 1)
        
        all_profiles = []
        for col in range(X.shape[1]):
            profile = self._compute_matrix_profile(X[:, col])
            all_profiles.append(profile)
        
        min_len = min(len(p) for p in all_profiles)
        aggregated = np.mean([p[:min_len] for p in all_profiles], axis=0)
        
        # Pad to match input length
        scores = np.zeros(X.shape[0])
        scores[:len(aggregated)] = aggregated
        scores[len(aggregated):] = np.mean(aggregated)
        
        return scores


class STLAnomalyDetector:
    """
    STL (Seasonal-Trend Decomposition) based anomaly detector.
    Uses residuals for anomaly scoring.
    """
    
    def __init__(
        self,
        period: int = 7,
        contamination: float = 0.05
    ):
        self.period = period
        self.contamination = contamination
        self.threshold_ = None
        self.is_fitted_ = False
    
    def _moving_average(self, x: np.ndarray, window: int) -> np.ndarray:
        """Calculate centered moving average."""
        weights = np.ones(window) / window
        return np.convolve(x, weights, mode='same')
    
    def _decompose(self, ts: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Simple additive decomposition: trend + seasonal + residual."""
        n = len(ts)
        
        # Trend: moving average
        trend = self._moving_average(ts, self.period)
        
        # Detrended
        detrended = ts - trend
        
        # Seasonal: average for each position in period
        seasonal = np.zeros(n)
        for i in range(self.period):
            indices = np.arange(i, n, self.period)
            seasonal[indices] = np.mean(detrended[indices])
        
        # Residual
        residual = ts - trend - seasonal
        
        return trend, seasonal, residual
    
    def fit(self, X: np.ndarray) -> 'STLAnomalyDetector':
        """Fit the STL detector."""
        if X.ndim == 2:
            X = X.mean(axis=1)
        
        _, _, residual = self._decompose(X)
        
        # Threshold on absolute residuals
        self.threshold_ = np.percentile(np.abs(residual), 100 * (1 - self.contamination))
        self.is_fitted_ = True
        
        return self
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict anomalies."""
        scores = self.decision_function(X)
        return np.where(scores > self.threshold_, 1, -1)
    
    def decision_function(self, X: np.ndarray) -> np.ndarray:
        """Return anomaly scores (absolute residuals)."""
        if X.ndim == 2:
            X = X.mean(axis=1)
        
        _, _, residual = self._decompose(X)
        return np.abs(residual)


class SOMAnomaly:
    """
    Self-Organizing Map (SOM) for anomaly detection.
    Points far from their BMU are considered anomalous.
    """
    
    def __init__(
        self,
        grid_size: Tuple[int, int] = (5, 5),
        learning_rate: float = 0.5,
        epochs: int = 100,
        contamination: float = 0.05,
        random_state: int = 42
    ):
        self.grid_size = grid_size
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.contamination = contamination
        self.random_state = random_state
        
        self.weights_ = None
        self.threshold_ = None
        self.scaler = StandardScaler()
        self.is_fitted_ = False
    
    def _init_weights(self, input_dim: int):
        """Initialize SOM weights."""
        np.random.seed(self.random_state)
        self.weights_ = np.random.rand(self.grid_size[0], self.grid_size[1], input_dim)
    
    def _find_bmu(self, x: np.ndarray) -> Tuple[int, int]:
        """Find Best Matching Unit."""
        dists = np.sqrt(np.sum((self.weights_ - x) ** 2, axis=2))
        bmu_idx = np.unravel_index(np.argmin(dists), dists.shape)
        return bmu_idx
    
    def _neighborhood(self, bmu: Tuple[int, int], radius: float) -> np.ndarray:
        """Calculate neighborhood function."""
        i_grid, j_grid = np.ogrid[0:self.grid_size[0], 0:self.grid_size[1]]
        dist_to_bmu = np.sqrt((i_grid - bmu[0]) ** 2 + (j_grid - bmu[1]) ** 2)
        return np.exp(-dist_to_bmu ** 2 / (2 * radius ** 2))
    
    def fit(self, X: np.ndarray) -> 'SOMAnomaly':
        """Train the SOM."""
        X_scaled = self.scaler.fit_transform(X)
        self._init_weights(X_scaled.shape[1])
        
        initial_radius = max(self.grid_size) / 2
        time_constant = self.epochs / np.log(initial_radius)
        
        for epoch in range(self.epochs):
            # Decay parameters
            radius = initial_radius * np.exp(-epoch / time_constant)
            lr = self.learning_rate * np.exp(-epoch / self.epochs)
            
            # Random shuffle
            indices = np.random.permutation(X_scaled.shape[0])
            
            for idx in indices[:min(1000, len(indices))]:  # Limit for performance
                x = X_scaled[idx]
                bmu = self._find_bmu(x)
                neighborhood = self._neighborhood(bmu, radius)
                
                # Update weights
                for i in range(self.grid_size[0]):
                    for j in range(self.grid_size[1]):
                        self.weights_[i, j] += lr * neighborhood[i, j] * (x - self.weights_[i, j])
        
        # Calculate threshold
        distances = self.decision_function(X)
        self.threshold_ = np.percentile(distances, 100 * (1 - self.contamination))
        self.is_fitted_ = True
        
        return self
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict anomalies."""
        scores = self.decision_function(X)
        return np.where(scores > self.threshold_, 1, -1)
    
    def decision_function(self, X: np.ndarray) -> np.ndarray:
        """Return distance to BMU as anomaly score."""
        X_scaled = self.scaler.transform(X)
        distances = np.zeros(X_scaled.shape[0])
        
        for i, x in enumerate(X_scaled):
            bmu = self._find_bmu(x)
            distances[i] = np.sqrt(np.sum((x - self.weights_[bmu]) ** 2))
        
        return distances
