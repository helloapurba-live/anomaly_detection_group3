"""
Project Vanguard Models Package
"""
