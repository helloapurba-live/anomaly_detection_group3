"""
Project Vanguard Apex - Logger Module
=====================================
Comprehensive audit logging and error tracking for FinCEN compliance.
Writes to local log files with timestamps and metadata.

Author: Project Vanguard Team
"""

import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any
import traceback
import json

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from config import PATHS


class AuditLogger:
    """
    Enterprise audit logging for AML compliance.
    
    Creates two log files:
    - admin_audit.log: User actions (import, export, model training)
    - system_errors.log: Errors and exceptions
    
    Attributes:
        audit_logger: Logger for user actions
        error_logger: Logger for system errors
    """
    
    _instance = None
    
    def __new__(cls):
        """Singleton pattern - only one logger instance."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        """Initialize loggers if not already done."""
        if self._initialized:
            return
            
        self._initialized = True
        self._setup_audit_logger()
        self._setup_error_logger()
    
    def _setup_audit_logger(self):
        """Configure the admin audit logger."""
        self.audit_logger = logging.getLogger("vanguard.audit")
        self.audit_logger.setLevel(logging.INFO)
        
        # Prevent duplicate handlers
        if self.audit_logger.handlers:
            return
        
        # File handler
        log_path = PATHS.LOGS / "admin_audit.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        handler = logging.FileHandler(log_path, encoding='utf-8')
        handler.setLevel(logging.INFO)
        
        formatter = logging.Formatter(
            '%(asctime)s | %(levelname)s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        handler.setFormatter(formatter)
        self.audit_logger.addHandler(handler)
    
    def _setup_error_logger(self):
        """Configure the system error logger."""
        self.error_logger = logging.getLogger("vanguard.errors")
        self.error_logger.setLevel(logging.ERROR)
        
        # Prevent duplicate handlers
        if self.error_logger.handlers:
            return
        
        # File handler
        log_path = PATHS.LOGS / "system_errors.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        handler = logging.FileHandler(log_path, encoding='utf-8')
        handler.setLevel(logging.ERROR)
        
        formatter = logging.Formatter(
            '%(asctime)s | %(levelname)s | %(name)s\n'
            'Message: %(message)s\n'
            '---\n',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        handler.setFormatter(formatter)
        self.error_logger.addHandler(handler)
    
    def log_action(
        self, 
        action: str, 
        user: str = "system",
        metadata: Optional[Dict[str, Any]] = None,
        status: str = "SUCCESS"
    ):
        """
        Log a user action to the audit trail.
        
        Args:
            action: Description of the action (e.g., "Data Import")
            user: User identifier (default: "system")
            metadata: Additional context (e.g., {"rows": 10000})
            status: Action status ("SUCCESS", "FAILED", "PENDING")
        
        Example:
            logger.log_action("Data Import", metadata={"file": "tx.csv", "rows": 10000})
        """
        meta_str = json.dumps(metadata) if metadata else "{}"
        message = f"ACTION={action} | USER={user} | STATUS={status} | META={meta_str}"
        self.audit_logger.info(message)
    
    def log_pipeline_start(self, pipeline_name: str, algorithms: list):
        """Log the start of a pipeline run."""
        self.log_action(
            action=f"Pipeline Start: {pipeline_name}",
            metadata={"algorithms": algorithms, "count": len(algorithms)}
        )
    
    def log_pipeline_complete(self, pipeline_name: str, duration: float, n_anomalies: int):
        """Log pipeline completion with metrics."""
        self.log_action(
            action=f"Pipeline Complete: {pipeline_name}",
            metadata={
                "duration_seconds": round(duration, 2),
                "anomalies_detected": n_anomalies
            }
        )
    
    def log_model_training(self, model_name: str, params: dict, duration: float):
        """Log individual model training."""
        self.log_action(
            action=f"Model Training: {model_name}",
            metadata={
                "parameters": params,
                "duration_seconds": round(duration, 2)
            }
        )
    
    def log_data_import(self, filename: str, rows: int, columns: int):
        """Log data import event."""
        self.log_action(
            action="Data Import",
            metadata={
                "filename": filename,
                "rows": rows,
                "columns": columns,
                "timestamp": datetime.now().isoformat()
            }
        )
    
    def log_export(self, export_type: str, filename: str, rows: int):
        """Log data export event."""
        self.log_action(
            action=f"Export: {export_type}",
            metadata={
                "filename": filename,
                "rows": rows,
                "timestamp": datetime.now().isoformat()
            }
        )
    
    def log_error(
        self, 
        exception: Exception, 
        context: str = "",
        metadata: Optional[Dict[str, Any]] = None
    ):
        """
        Log an error with full traceback.
        
        Args:
            exception: The exception that occurred
            context: Where the error occurred (e.g., "IsolationForest training")
            metadata: Additional context
        """
        tb = traceback.format_exc()
        meta_str = json.dumps(metadata) if metadata else "{}"
        
        message = (
            f"CONTEXT={context} | "
            f"ERROR={type(exception).__name__}: {str(exception)} | "
            f"META={meta_str}\n"
            f"TRACEBACK:\n{tb}"
        )
        
        self.error_logger.error(message)
        
        # Also log to audit trail
        self.log_action(
            action=f"Error: {context}",
            status="FAILED",
            metadata={
                "error_type": type(exception).__name__,
                "error_message": str(exception)
            }
        )
    
    def get_recent_logs(self, n_lines: int = 50, log_type: str = "audit") -> list:
        """
        Get recent log entries.
        
        Args:
            n_lines: Number of recent lines to return
            log_type: "audit" or "errors"
            
        Returns:
            List of log entry strings
        """
        if log_type == "audit":
            log_path = PATHS.LOGS / "admin_audit.log"
        else:
            log_path = PATHS.LOGS / "system_errors.log"
        
        if not log_path.exists():
            return []
        
        try:
            with open(log_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            return lines[-n_lines:] if len(lines) > n_lines else lines
        except Exception:
            return []


# Global logger instance
logger = AuditLogger()
