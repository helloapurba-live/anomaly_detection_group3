"""
Helper functions for data management.
"""

from utils.data_io import data_vault


def clear_data():
    """Clear all data from vault."""
    data_vault.clear_data()


def clear_scored_data():
    """Clear only scored data."""
    data_vault._scored_data = None
    from config import PATHS
    scored_path = PATHS.DATA_VAULT / "scored.parquet"
    if scored_path.exists():
        scored_path.unlink()


def set_data(df, metadata=None):
    """Set raw data."""
    data_vault._current_data = df
    if metadata:
        data_vault._metadata = metadata
    data_vault._persist_data()
