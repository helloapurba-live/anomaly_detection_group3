"""
Project Vanguard Apex - Command Center Page
============================================
Executive KPI dashboard with alert volume, risk distribution,
transaction velocity, and trend visualizations.

Author: Project Vanguard Team
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from datetime import datetime
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import THEME, APP


dash.register_page(__name__, path="/", name="Command Center", order=0)


# =============================================================================
# KPI CARD COMPONENT
# =============================================================================
def create_kpi_card(
    title: str, 
    value: str, 
    subtitle: str = "", 
    icon: str = "mdi:chart-line",
    color: str = THEME.PRIMARY,
    trend: str = None
) -> dmc.Paper:
    """Create a styled KPI card."""
    trend_icon = None
    if trend:
        if trend.startswith("+"):
            trend_icon = DashIconify(icon="mdi:trending-up", color=THEME.SUCCESS, width=16)
        elif trend.startswith("-"):
            trend_icon = DashIconify(icon="mdi:trending-down", color=THEME.DANGER, width=16)
    
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.ThemeIcon(
                        DashIconify(icon=icon, width=24),
                        size="xl",
                        radius="md",
                        variant="light",
                        color=color.replace("#", ""),
                    ),
                    dmc.Stack(
                        [
                            dmc.Text(title, size="sm", c="dimmed"),
                            dmc.Group(
                                [
                                    dmc.Text(value, size="xl", fw=700),
                                    dmc.Group([trend_icon, dmc.Text(trend, size="xs", c="dimmed")]) if trend else None,
                                ],
                                gap="xs",
                            ),
                            dmc.Text(subtitle, size="xs", c="dimmed") if subtitle else None,
                        ],
                        gap=2,
                    ),
                ],
                gap="md",
            ),
        ],
        p="md",
        radius="md",
        withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD}
    )


# =============================================================================
# PAGE LAYOUT
# =============================================================================
layout = dmc.Container(
    [
        # Header
        dmc.Group(
            [
                dmc.Title("Command Center", order=2),
                dmc.Badge("Live", color="green", variant="dot"),
            ],
            justify="space-between",
            mb="lg",
        ),
        
        # KPI Row (Skeleton during load)
        html.Div(id="kpi-row"),
        
        dmc.Space(h="lg"),
        
        # Charts Row 1
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2},
            spacing="lg",
            children=[
                dmc.Paper(
                    [
                        dmc.Text("Alert Trend (30 Days)", fw=600, mb="sm"),
                        dcc.Graph(
                            id="chart-alert-trend",
                            config=APP.PLOTLY_CONFIG,
                            style={"height": "300px"},
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Text("Risk Distribution", fw=600, mb="sm"),
                        dcc.Graph(
                            id="chart-risk-distribution",
                            config=APP.PLOTLY_CONFIG,
                            style={"height": "300px"},
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
            ],
        ),
        
        dmc.Space(h="lg"),
        
        # Charts Row 2
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2},
            spacing="lg",
            children=[
                dmc.Paper(
                    [
                        dmc.Text("Algorithm Performance", fw=600, mb="sm"),
                        dcc.Graph(
                            id="chart-algo-performance",
                            config=APP.PLOTLY_CONFIG,
                            style={"height": "300px"},
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Text("Score Heatmap by Hour", fw=600, mb="sm"),
                        dcc.Graph(
                            id="chart-score-heatmap",
                            config=APP.PLOTLY_CONFIG,
                            style={"height": "300px"},
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
            ],
        ),
        
        # Refresh interval
        dcc.Interval(id="interval-refresh", interval=60000, n_intervals=0),
    ],
    fluid=True,
)


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("kpi-row", "children"),
    Input("interval-refresh", "n_intervals"),
)
def update_kpis(n):
    """Update KPI cards with current data."""
    try:
        from utils.data_io import data_vault
        
        df = data_vault.get_scored_data()
        
        if df is None:
            df = data_vault.get_data()
        
        if df is None:
            return dmc.Alert(
                "No data loaded. Import a dataset to begin.",
                title="No Data",
                color="yellow",
            )
        
        # Calculate KPIs
        total_records = len(df)
        
        if 'anomaly_score' in df.columns:
            anomalies = int((df['anomaly_score'] > 0.5).sum())
            alert_rate = (anomalies / total_records * 100) if total_records > 0 else 0
            avg_score = df['anomaly_score'].mean()
            high_risk = int((df['anomaly_score'] > 0.8).sum())
        else:
            anomalies = 0
            alert_rate = 0
            avg_score = 0
            high_risk = 0
        
        return dmc.SimpleGrid(
            cols={"base": 2, "md": 4},
            spacing="lg",
            children=[
                create_kpi_card(
                    "Total Records",
                    f"{total_records:,}",
                    icon="mdi:database",
                    color=THEME.PRIMARY,
                ),
                create_kpi_card(
                    "Flagged Alerts",
                    f"{anomalies:,}",
                    subtitle="Score > 0.5",
                    icon="mdi:alert-circle",
                    color=THEME.WARNING,
                ),
                create_kpi_card(
                    "Alert Rate",
                    f"{alert_rate:.1f}%",
                    icon="mdi:percent",
                    color=THEME.SECONDARY,
                ),
                create_kpi_card(
                    "High Risk",
                    f"{high_risk:,}",
                    subtitle="Score > 0.8",
                    icon="mdi:shield-alert",
                    color=THEME.DANGER,
                ),
            ],
        )
        
    except Exception as e:
        return dmc.Alert(f"Error loading KPIs: {str(e)}", color="red")


@callback(
    Output("chart-alert-trend", "figure"),
    Input("interval-refresh", "n_intervals"),
)
def update_alert_trend(n):
    """Update alert trend chart."""
    try:
        from utils.data_io import data_vault
        
        df = data_vault.get_scored_data()
        
        if df is None or 'anomaly_score' not in df.columns:
            return go.Figure()
        
        # Generate mock trend data if no timestamp
        if 'timestamp' not in df.columns:
            dates = pd.date_range(end=datetime.now(), periods=30, freq='D')
            trend_data = pd.DataFrame({
                'date': dates,
                'alerts': np.random.randint(10, 100, size=30)
            })
        else:
            df['date'] = pd.to_datetime(df['timestamp']).dt.date
            trend_data = df[df['anomaly_score'] > 0.5].groupby('date').size().reset_index(name='alerts')
        
        fig = px.area(
            trend_data,
            x='date',
            y='alerts',
            template="plotly_dark",
        )
        
        fig.update_traces(
            fill='tozeroy',
            fillcolor=f"rgba(0, 212, 255, 0.2)",
            line=dict(color=THEME.PRIMARY, width=2),
        )
        
        fig.update_layout(
            margin=dict(l=20, r=20, t=20, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            xaxis=dict(showgrid=False),
            yaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,0.1)"),
        )
        
        return fig
        
    except Exception:
        return go.Figure()


@callback(
    Output("chart-risk-distribution", "figure"),
    Input("interval-refresh", "n_intervals"),
)
def update_risk_distribution(n):
    """Update risk distribution pie chart."""
    try:
        from utils.data_io import data_vault
        
        df = data_vault.get_scored_data()
        
        if df is None or 'risk_level' not in df.columns:
            return go.Figure()
        
        risk_counts = df['risk_level'].value_counts().reset_index()
        risk_counts.columns = ['Risk Level', 'Count']
        
        colors = {
            'Low': THEME.SUCCESS,
            'Low-Medium': '#4CAF50',
            'Medium': THEME.WARNING,
            'Medium-High': '#FF9800',
            'High': THEME.DANGER,
        }
        
        fig = px.pie(
            risk_counts,
            values='Count',
            names='Risk Level',
            color='Risk Level',
            color_discrete_map=colors,
            hole=0.4,
            template="plotly_dark",
        )
        
        fig.update_layout(
            margin=dict(l=20, r=20, t=20, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            legend=dict(orientation="h", yanchor="bottom", y=-0.2),
        )
        
        return fig
        
    except Exception:
        return go.Figure()


@callback(
    Output("chart-algo-performance", "figure"),
    Input("interval-refresh", "n_intervals"),
)
def update_algo_performance(n):
    """Update algorithm performance bar chart."""
    try:
        from utils.data_io import data_vault
        
        df = data_vault.get_scored_data()
        
        if df is None:
            return go.Figure()
        
        # Find score columns
        score_cols = [c for c in df.columns if c.startswith('score_')]
        
        if not score_cols:
            return go.Figure()
        
        # Calculate detection rates
        rates = []
        for col in score_cols:
            algo_name = col.replace('score_', '')
            detection_rate = (df[col] > 0.5).mean() * 100
            rates.append({'Algorithm': algo_name, 'Detection Rate': detection_rate})
        
        rate_df = pd.DataFrame(rates).sort_values('Detection Rate', ascending=True)
        
        fig = px.bar(
            rate_df,
            x='Detection Rate',
            y='Algorithm',
            orientation='h',
            template="plotly_dark",
        )
        
        fig.update_traces(marker_color=THEME.SECONDARY)
        
        fig.update_layout(
            margin=dict(l=20, r=20, t=20, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            xaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,0.1)"),
            yaxis=dict(showgrid=False),
        )
        
        return fig
        
    except Exception:
        return go.Figure()


@callback(
    Output("chart-score-heatmap", "figure"),
    Input("interval-refresh", "n_intervals"),
)
def update_score_heatmap(n):
    """Update score heatmap."""
    try:
        from utils.data_io import data_vault
        
        df = data_vault.get_scored_data()
        
        if df is None or 'anomaly_score' not in df.columns:
            return go.Figure()
        
        # Generate mock heatmap data
        hours = list(range(24))
        days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        
        z = np.random.rand(7, 24) * 0.5 + 0.1
        z[5:, 20:] = z[5:, 20:] * 2  # Weekend nights higher risk
        
        fig = go.Figure(data=go.Heatmap(
            z=z,
            x=hours,
            y=days,
            colorscale=[
                [0, THEME.SUCCESS],
                [0.5, THEME.WARNING],
                [1, THEME.DANGER]
            ],
            showscale=True,
        ))
        
        fig.update_layout(
            margin=dict(l=20, r=20, t=20, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            xaxis=dict(title="Hour of Day"),
            yaxis=dict(title=""),
            template="plotly_dark",
        )
        
        return fig
        
    except Exception:
        return go.Figure()
