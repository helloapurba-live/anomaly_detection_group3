"""
Project Vanguard Apex - Data Import Page
=========================================
Drag-and-drop CSV/Parquet import with validation,
preview, and data vault management.

Author: Project Vanguard Team
"""

import dash
from dash import html, dcc, callback, Input, Output, State
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import pandas as pd
import base64
import io
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import THEME


dash.register_page(__name__, path="/import", name="Data Import", order=4)


# =============================================================================
# PAGE LAYOUT
# =============================================================================
layout = dmc.Container(
    [
        # Header
        dmc.Group(
            [
                dmc.Title("Data Import", order=2),
                dmc.Badge("Secure Vault", color="cyan", variant="light"),
            ],
            justify="space-between",
            mb="lg",
        ),
        
        # Upload Area
        dmc.Paper(
            [
                dcc.Upload(
                    id='upload-data',
                    children=html.Div([
                        dmc.Stack(
                            [
                                DashIconify(icon="mdi:cloud-upload", width=64, color=THEME.PRIMARY),
                                dmc.Text("Drag & Drop or Click to Upload", size="lg", fw=500),
                                dmc.Text("Supported: CSV, Parquet, Excel (.xlsx)", size="sm", c="dimmed"),
                                dmc.Text("Max file size: 100MB", size="xs", c="dimmed"),
                            ],
                            align="center",
                            gap="sm",
                        ),
                    ]),
                    style={
                        'width': '100%',
                        'minHeight': '200px',
                        'borderWidth': '2px',
                        'borderStyle': 'dashed',
                        'borderColor': THEME.PRIMARY,
                        'borderRadius': '10px',
                        'textAlign': 'center',
                        'padding': '40px',
                        'cursor': 'pointer',
                        'backgroundColor': 'rgba(0, 212, 255, 0.05)',
                    },
                    multiple=False,
                ),
            ],
            p="md",
            mb="lg",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),
        
        # Upload Status
        html.Div(id="upload-status"),
        
        dmc.Space(h="lg"),
        
        # Data Preview
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Text("Data Preview", fw=600),
                        dmc.Group(
                            [
                                dmc.Button(
                                    "Clear Data",
                                    id="btn-clear-data",
                                    color="red",
                                    variant="light",
                                    size="sm",
                                    leftSection=DashIconify(icon="mdi:delete", width=16),
                                ),
                            ],
                            gap="xs",
                        ),
                    ],
                    justify="space-between",
                    mb="md",
                ),
                html.Div(id="data-preview"),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),
        
        dmc.Space(h="lg"),
        
        # Data Statistics
        dmc.Paper(
            [
                dmc.Text("Data Statistics", fw=600, mb="md"),
                html.Div(id="data-statistics"),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),
        
        # Notification container
        html.Div(id="import-notification"),
    ],
    fluid=True,
)


# =============================================================================
# CALLBACKS
# =============================================================================
def parse_contents(contents, filename):
    """Parse uploaded file contents."""
    content_type, content_string = contents.split(',')
    decoded = base64.b64decode(content_string)
    
    try:
        if filename.endswith('.csv'):
            df = pd.read_csv(io.StringIO(decoded.decode('utf-8')))
        elif filename.endswith('.parquet'):
            df = pd.read_parquet(io.BytesIO(decoded))
        elif filename.endswith('.xlsx') or filename.endswith('.xls'):
            df = pd.read_excel(io.BytesIO(decoded))
        else:
            return None, "Unsupported file type"
        
        return df, None
        
    except Exception as e:
        return None, str(e)


@callback(
    Output("upload-status", "children"),
    Output("data-preview", "children"),
    Output("data-statistics", "children"),
    Output("import-notification", "children"),
    Input("upload-data", "contents"),
    State("upload-data", "filename"),
    prevent_initial_call=True,
)
def handle_upload(contents, filename):
    """Handle file upload and save to vault."""
    if contents is None:
        return dash.no_update, dash.no_update, dash.no_update, dash.no_update
    
    try:
        from utils.data_io import data_vault
        from utils.logger import logger
        
        # Parse file
        df, error = parse_contents(contents, filename)
        
        if error:
            return (
                dmc.Alert(f"Error parsing file: {error}", color="red"),
                None,
                None,
                dmc.Notification(
                    title="Import Failed",
                    message=error,
                    color="red",
                    icon=DashIconify(icon="mdi:alert"),
                ),
            )
        
        # Validate
        if len(df) == 0:
            return (
                dmc.Alert("File is empty", color="yellow"),
                None,
                None,
                None,
            )
        
        # Save to vault
        data_vault.set_data(df, metadata={
            'filename': filename,
            'rows': len(df),
            'columns': len(df.columns),
        })
        
        # Log action
        logger.log_action(f"Data Import: {filename} ({len(df):,} rows)")
        
        # Status badge
        status = dmc.Alert(
            f"Successfully imported {filename}: {len(df):,} rows × {len(df.columns)} columns",
            title="Import Successful",
            color="green",
            icon=DashIconify(icon="mdi:check-circle"),
        )
        
        # Preview table (first 10 rows)
        preview_df = df.head(10)
        
        preview = dmc.Table(
            striped=True,
            highlightOnHover=True,
            children=[
                html.Thead(
                    html.Tr([html.Th(col) for col in preview_df.columns[:10]])
                ),
                html.Tbody([
                    html.Tr([
                        html.Td(str(preview_df.iloc[i][col])[:50]) 
                        for col in preview_df.columns[:10]
                    ])
                    for i in range(len(preview_df))
                ]),
            ],
        )
        
        # Statistics
        numeric_cols = df.select_dtypes(include=['number']).columns
        
        stats_items = [
            dmc.Group([
                dmc.Text("Total Rows", c="dimmed"),
                dmc.Text(f"{len(df):,}", fw=600),
            ], justify="space-between"),
            dmc.Group([
                dmc.Text("Total Columns", c="dimmed"),
                dmc.Text(str(len(df.columns)), fw=600),
            ], justify="space-between"),
            dmc.Group([
                dmc.Text("Numeric Columns", c="dimmed"),
                dmc.Text(str(len(numeric_cols)), fw=600),
            ], justify="space-between"),
            dmc.Group([
                dmc.Text("Memory Usage", c="dimmed"),
                dmc.Text(f"{df.memory_usage(deep=True).sum() / 1024 / 1024:.2f} MB", fw=600),
            ], justify="space-between"),
            dmc.Group([
                dmc.Text("Missing Values", c="dimmed"),
                dmc.Text(f"{df.isnull().sum().sum():,}", fw=600),
            ], justify="space-between"),
        ]
        
        statistics = dmc.Stack([
            dmc.Paper(item, p="sm", withBorder=True, radius="sm")
            for item in stats_items
        ], gap="xs")
        
        notification = dmc.Notification(
            title="Import Complete",
            message=f"{len(df):,} records loaded to vault",
            color="green",
            icon=DashIconify(icon="mdi:check-circle"),
        )
        
        return status, preview, statistics, notification
        
    except Exception as e:
        from utils.logger import logger
        logger.log_error(e, "Data Import")
        
        return (
            dmc.Alert(f"Error: {str(e)}", color="red"),
            None,
            None,
            dmc.Notification(
                title="Import Failed",
                message=str(e)[:100],
                color="red",
                icon=DashIconify(icon="mdi:alert"),
            ),
        )


@callback(
    Output("upload-status", "children", allow_duplicate=True),
    Output("data-preview", "children", allow_duplicate=True),
    Output("data-statistics", "children", allow_duplicate=True),
    Input("btn-clear-data", "n_clicks"),
    prevent_initial_call=True,
)
def clear_data(n_clicks):
    """Clear all data from vault."""
    if not n_clicks:
        return dash.no_update, dash.no_update, dash.no_update
    
    try:
        from utils.data_io import clear_data as vault_clear
        from utils.logger import logger
        
        vault_clear()
        logger.log_action("Data Cleared from Vault")
        
        return (
            dmc.Alert(
                "All data has been cleared from the vault.",
                title="Data Cleared",
                color="yellow",
            ),
            dmc.Text("No data loaded.", c="dimmed"),
            dmc.Text("Import data to see statistics.", c="dimmed"),
        )
        
    except Exception as e:
        return (
            dmc.Alert(f"Error clearing data: {str(e)}", color="red"),
            dash.no_update,
            dash.no_update,
        )
