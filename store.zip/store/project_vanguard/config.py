"""
Project Vanguard Apex - Configuration Hub
==========================================
Centralized configuration for the Mission-Critical AML Platform.
Contains ThemeConfig, ModelConfig, and PathConfig classes.

Author: Project Vanguard Team
Environment: Windows 10/11, Anaconda, Dash 2.14+, DMC
"""

from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Any


# =============================================================================
# PATH CONFIGURATION (Portable via pathlib)
# =============================================================================
@dataclass
class PathConfig:
    """
    Absolute-relative pathing for 100% portability.
    The entire project folder can be copied across laptops.
    """
    ROOT: Path = field(default_factory=lambda: Path(__file__).parent.resolve())
    
    @property
    def DATA_VAULT(self) -> Path:
        """Parquet data persistence directory."""
        return self.ROOT / "data" / "vault"
    
    @property
    def EXPORTS(self) -> Path:
        """Generated reports directory."""
        return self.ROOT / "data" / "exports"
    
    @property
    def CACHE(self) -> Path:
        """Diskcache persistence directory."""
        return self.ROOT / "cache"
    
    @property
    def LOGS(self) -> Path:
        """Audit and error logs directory."""
        return self.ROOT / "logs"
    
    @property
    def MODELS(self) -> Path:
        """Trained model artifacts directory."""
        return self.ROOT / "models" / "trained"
    
    @property
    def ASSETS(self) -> Path:
        """CSS, fonts, static assets."""
        return self.ROOT / "assets"
    
    def ensure_directories(self):
        """Create all required directories if they don't exist."""
        for path in [self.DATA_VAULT, self.EXPORTS, self.CACHE, 
                     self.LOGS, self.MODELS, self.ASSETS]:
            path.mkdir(parents=True, exist_ok=True)


# =============================================================================
# THEME CONFIGURATION (Corporate Standards)
# =============================================================================
@dataclass
class ThemeConfig:
    """
    Enterprise UI theming for Dash Mantine Components.
    Defines corporate color palette, typography, and spacing.
    """
    # Primary Brand Colors
    PRIMARY: str = "#00D4FF"          # Cyan - Primary accent
    SECONDARY: str = "#9D4EDD"        # Purple - Secondary accent
    SUCCESS: str = "#00C853"          # Green - Safe/Normal
    WARNING: str = "#FFB300"          # Amber - Attention
    DANGER: str = "#FF5252"           # Red - High Risk/Error
    
    # Background Colors (Dark Mode)
    DARK_BG_PRIMARY: str = "#0a0a12"
    DARK_BG_SECONDARY: str = "#12121f"
    DARK_BG_PAPER: str = "#1a1a2e"
    DARK_BG_CARD: str = "#16213e"
    
    # Background Colors (Light Mode)
    LIGHT_BG_PRIMARY: str = "#f8f9fa"
    LIGHT_BG_SECONDARY: str = "#ffffff"
    LIGHT_BG_PAPER: str = "#ffffff"
    
    # Text Colors
    TEXT_DARK: str = "#ffffff"
    TEXT_LIGHT: str = "#1a1a2e"
    TEXT_MUTED: str = "#6c757d"
    TEXT_DIMMED: str = "#868e96"
    
    # Typography (Local fonts for air-gap)
    FONT_FAMILY: str = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
    FONT_SIZE_XS: str = "12px"
    FONT_SIZE_SM: str = "14px"
    FONT_SIZE_MD: str = "16px"
    FONT_SIZE_LG: str = "20px"
    FONT_SIZE_XL: str = "28px"
    
    # Spacing & Borders
    RADIUS_SM: str = "4px"
    RADIUS_MD: str = "8px"
    RADIUS_LG: str = "12px"
    SHADOW_SM: str = "0 1px 3px rgba(0,0,0,0.2)"
    SHADOW_MD: str = "0 4px 6px rgba(0,0,0,0.3)"
    SHADOW_LG: str = "0 10px 20px rgba(0,0,0,0.4)"
    
    # Risk Gradient Colors (for AG Grid)
    RISK_GRADIENT: List[str] = field(default_factory=lambda: [
        "#00C853",  # 0-20: Low (Green)
        "#4CAF50",  # 20-40: Low-Medium
        "#FFC107",  # 40-60: Medium (Yellow)
        "#FF9800",  # 60-80: Medium-High (Orange)
        "#FF5252",  # 80-100: High (Red)
    ])
    
    def get_mantine_theme(self) -> Dict[str, Any]:
        """Return theme dict for DMC MantineProvider."""
        return {
            "colorScheme": "dark",
            "primaryColor": "cyan",
            "fontFamily": self.FONT_FAMILY,
            "colors": {
                "cyan": [
                    "#e3fafc", "#c5f6fa", "#99e9f2", "#66d9e8", "#3bc9db",
                    "#22b8cf", "#15aabf", "#1098ad", "#0c8599", "#0b7285"
                ],
                "grape": [
                    "#f8f0fc", "#f3d9fa", "#eebefa", "#e599f7", "#da77f2",
                    "#cc5de8", "#be4bdb", "#ae3ec9", "#9c36b5", "#862e9c"
                ]
            },
            "components": {
                "Paper": {"styles": {"root": {"backgroundColor": self.DARK_BG_PAPER}}},
                "Card": {"styles": {"root": {"backgroundColor": self.DARK_BG_CARD}}},
            }
        }


# =============================================================================
# MODEL CONFIGURATION (Anomaly Engine Parameters)
# =============================================================================
@dataclass
class ModelConfig:
    """
    Hyperparameters for the 20+ unsupervised anomaly detection algorithms.
    Grouped by algorithm category for easy tuning.
    """
    
    # Global Settings
    RANDOM_STATE: int = 42
    DEFAULT_CONTAMINATION: float = 0.05
    N_JOBS: int = -1  # Use all CPU cores
    
    # Isolation-Based Algorithms
    ISOLATION_FOREST: Dict[str, Any] = field(default_factory=lambda: {
        "n_estimators": 100,
        "max_samples": "auto",
        "contamination": 0.05,
        "max_features": 1.0
    })
    
    EXTENDED_ISOLATION_FOREST: Dict[str, Any] = field(default_factory=lambda: {
        "n_estimators": 100,
        "max_samples": 256
    })
    
    # Proximity/Density-Based Algorithms
    LOF: Dict[str, Any] = field(default_factory=lambda: {
        "n_neighbors": 20,
        "contamination": 0.05,
        "metric": "minkowski"
    })
    
    COF: Dict[str, Any] = field(default_factory=lambda: {
        "n_neighbors": 20,
        "contamination": 0.05
    })
    
    DBSCAN: Dict[str, Any] = field(default_factory=lambda: {
        "eps": 0.5,
        "min_samples": 5
    })
    
    OPTICS: Dict[str, Any] = field(default_factory=lambda: {
        "min_samples": 5,
        "xi": 0.05,
        "min_cluster_size": 0.05
    })
    
    KNN: Dict[str, Any] = field(default_factory=lambda: {
        "n_neighbors": 5,
        "contamination": 0.05,
        "method": "largest"
    })
    
    # Statistical/Probabilistic Algorithms
    ELLIPTIC_ENVELOPE: Dict[str, Any] = field(default_factory=lambda: {
        "contamination": 0.05,
        "support_fraction": None
    })
    
    GMM: Dict[str, Any] = field(default_factory=lambda: {
        "n_components": 3,
        "covariance_type": "full"
    })
    
    KDE: Dict[str, Any] = field(default_factory=lambda: {
        "bandwidth": 1.0,
        "kernel": "gaussian"
    })
    
    # Dimensionality/Projection-Based
    PCA: Dict[str, Any] = field(default_factory=lambda: {
        "n_components": 0.95,  # Preserve 95% variance
        "whiten": True
    })
    
    # Neural/Deep Learning (Local)
    AUTOENCODER: Dict[str, Any] = field(default_factory=lambda: {
        "hidden_neurons": [64, 32, 32, 64],
        "epochs": 50,
        "batch_size": 32,
        "dropout_rate": 0.2
    })
    
    # Time-Series Algorithms
    RRCF: Dict[str, Any] = field(default_factory=lambda: {
        "num_trees": 40,
        "tree_size": 256
    })
    
    # Algorithm Selection (Active algorithms for ensemble)
    ACTIVE_ALGORITHMS: List[str] = field(default_factory=lambda: [
        "IsolationForest",
        "ExtendedIsolationForest",
        "LOF",
        "COF", 
        "KNN",
        "DBSCAN",
        "OPTICS",
        "EllipticEnvelope",
        "GMM",
        "KDE",
        "PCA_Reconstruction",
        "Autoencoder",
        "RRCF",
        "OneSVM",
        "COPOD",
        "ECOD",
        "HBOS",
        "MCD",
        "CBLOF",
        "SOD"
    ])
    
    # Ensemble Settings
    ENSEMBLE_METHOD: str = "average"  # Options: average, max, voting
    ENSEMBLE_WEIGHTS: Dict[str, float] = field(default_factory=lambda: {
        "IsolationForest": 1.5,
        "LOF": 1.2,
        "Autoencoder": 1.3,
        "COPOD": 1.0
    })


# =============================================================================
# PII MASKING CONFIGURATION
# =============================================================================
@dataclass
class PIIConfig:
    """
    Privacy mode configuration for PII data protection.
    Masks sensitive fields while keeping underlying data intact.
    """
    ENABLED_BY_DEFAULT: bool = True
    MASK_PATTERN: str = "XXXX"
    VISIBLE_CHARS: int = 4
    
    # Fields to mask (regex patterns)
    MASKED_COLUMNS: List[str] = field(default_factory=lambda: [
        "customer_id",
        "account_number",
        "ssn",
        "name",
        "email",
        "phone"
    ])
    
    # Masking patterns by field type
    PATTERNS: Dict[str, str] = field(default_factory=lambda: {
        "customer_id": r"^(.{4}).*(.{4})$",  # Keep first 4 and last 4
        "email": r"^(.{2}).*(@.*)$",          # Keep first 2 chars + domain
        "phone": r"^.*(.{4})$",               # Keep last 4 digits
        "account": r"^.*(.{4})$"              # Keep last 4 digits
    })


# =============================================================================
# APPLICATION SETTINGS
# =============================================================================
@dataclass
class AppConfig:
    """
    Dash application runtime configuration.
    """
    TITLE: str = "Project Vanguard Apex"
    SUBTITLE: str = "Mission-Critical AML Platform"
    VERSION: str = "1.0.0"
    
    # Server Settings (Air-Gapped)
    HOST: str = "127.0.0.1"
    PORT: int = 8070
    DEBUG: bool = True
    
    # Cache Settings
    CACHE_TYPE: str = "diskcache"
    CACHE_THRESHOLD: int = 500
    
    # Background Callback Settings
    BACKGROUND_CALLBACK_MANAGER: str = "diskcache"
    
    # Plotly Configuration (No Cloud)
    PLOTLY_CONFIG: Dict[str, Any] = field(default_factory=lambda: {
        "displaylogo": False,
        "modeBarButtonsToRemove": [
            "sendDataToCloud",
            "editInChartStudio",
            "lasso2d",
            "select2d"
        ],
        "toImageButtonOptions": {
            "format": "png",
            "filename": "vanguard_chart",
            "scale": 2
        }
    })


# =============================================================================
# GLOBAL INSTANCES
# =============================================================================
PATHS = PathConfig()
THEME = ThemeConfig()
MODEL = ModelConfig()
PII = PIIConfig()
APP = AppConfig()

# Ensure directories exist on import
PATHS.ensure_directories()
