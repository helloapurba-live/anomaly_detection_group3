"""
Audit Trail Page
================
Decision logging and compliance tracking.
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
from dash_iconify import DashIconify
from datetime import datetime, timedelta
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME


dash.register_page(__name__, path="/audit", name="Audit Trail", order=6)


def audit_entry(timestamp: str, action: str, user: str, details: str) -> dmc.Paper:
    action_icons = {
        "PIPELINE_RUN": ("mdi:rocket-launch", "cyan"),
        "ALERT_REVIEWED": ("mdi:eye", "green"),
        "ALERT_ESCALATED": ("mdi:arrow-up-bold", "orange"),
        "ALERT_CLOSED": ("mdi:check-circle", "gray"),
        "DATA_IMPORT": ("mdi:database-import", "grape"),
    }
    
    icon, color = action_icons.get(action, ("mdi:information", "gray"))
    
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.ThemeIcon(
                        DashIconify(icon=icon, width=20),
                        color=color,
                        variant="light",
                        radius="xl",
                    ),
                    dmc.Stack(
                        [
                            dmc.Group(
                                [
                                    dmc.Text(action.replace("_", " ").title(), fw=600, size="sm"),
                                    dmc.Badge(user, size="xs", variant="light"),
                                ],
                                gap="xs",
                            ),
                            dmc.Text(details, size="xs", c="dimmed"),
                        ],
                        gap=0,
                    ),
                    dmc.Text(timestamp, size="xs", c="dimmed", ml="auto"),
                ],
                gap="sm",
            ),
        ],
        p="sm",
        radius="md",
        withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD, "marginBottom": "8px"}
    )


layout = dmc.Container(
    [
        dmc.Group(
            [
                dmc.Title("Audit Trail", order=2),
                dmc.Badge("Compliance Logging", color="cyan", variant="light"),
            ],
            justify="space-between",
            mb="lg",
        ),
        
        # Filters
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Select(
                            id="filter-action-type",
                            label="Action Type",
                            data=[
                                {"value": "all", "label": "All Actions"},
                                {"value": "PIPELINE_RUN", "label": "Pipeline Runs"},
                                {"value": "ALERT_REVIEWED", "label": "Reviews"},
                                {"value": "ALERT_ESCALATED", "label": "Escalations"},
                                {"value": "ALERT_CLOSED", "label": "Closures"},
                            ],
                            value="all",
                            w=200,
                        ),
                        dmc.DatePickerInput(
                            id="filter-date",
                            label="Date",
                            placeholder="Filter by date",
                            w=200,
                        ),
                        dmc.Button(
                            "Export",
                            leftSection=DashIconify(icon="mdi:download"),
                            variant="subtle",
                            ml="auto",
                        ),
                    ],
                    gap="md",
                ),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
            mb="lg",
        ),
        
        # Stats
        dmc.SimpleGrid(
            cols=4,
            mb="lg",
            children=[
                dmc.Paper(
                    [
                        dmc.Text("Total Entries", c="dimmed", size="sm"),
                        dmc.Text("47", fw=700, size="xl"),
                    ],
                    p="md",
                    ta="center",
                    radius="md",
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Text("Pipeline Runs", c="dimmed", size="sm"),
                        dmc.Text("12", fw=700, size="xl", c="cyan"),
                    ],
                    p="md",
                    ta="center",
                    radius="md",
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Text("Reviews", c="dimmed", size="sm"),
                        dmc.Text("28", fw=700, size="xl", c="green"),
                    ],
                    p="md",
                    ta="center",
                    radius="md",
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Text("Escalations", c="dimmed", size="sm"),
                        dmc.Text("7", fw=700, size="xl", c="orange"),
                    ],
                    p="md",
                    ta="center",
                    radius="md",
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
            ],
        ),
        
        # Entries
        html.Div(id="audit-entries"),
    ],
    fluid=True,
)


@callback(
    Output("audit-entries", "children"),
    Input("filter-action-type", "value"),
)
def update_entries(action_filter):
    # Sample entries
    now = datetime.now()
    entries = [
        {"ts": (now - timedelta(minutes=5)).strftime("%H:%M:%S"), "action": "PIPELINE_RUN", 
         "user": "system", "details": "Processed 870 records with 26 methods"},
        {"ts": (now - timedelta(minutes=15)).strftime("%H:%M:%S"), "action": "ALERT_REVIEWED",
         "user": "analyst1", "details": "ALT-000001 reviewed, flagged as true positive"},
        {"ts": (now - timedelta(minutes=30)).strftime("%H:%M:%S"), "action": "ALERT_ESCALATED",
         "user": "analyst1", "details": "ALT-000002 escalated to senior team"},
        {"ts": (now - timedelta(hours=1)).strftime("%H:%M:%S"), "action": "DATA_IMPORT",
         "user": "system", "details": "Imported 4 source files: KYC, TXN, Alerts, Cases"},
        {"ts": (now - timedelta(hours=2)).strftime("%H:%M:%S"), "action": "ALERT_CLOSED",
         "user": "analyst2", "details": "ALT-000003 closed as false positive"},
    ]
    
    if action_filter != "all":
        entries = [e for e in entries if e["action"] == action_filter]
    
    return [
        audit_entry(e["ts"], e["action"], e["user"], e["details"])
        for e in entries
    ]
