"""
Project Vanguard Apex - Main Application
========================================
Mission-Critical AML Platform with DMC UI, AG Grid,
Background Callbacks, and Stateful Persistence.

Author: Project Vanguard Team
Environment: Windows 10/11, Anaconda, Dash 2.14+, DMC
"""

import os
import sys
from pathlib import Path

# Ensure project root is in path
PROJECT_ROOT = Path(__file__).parent.resolve()
sys.path.insert(0, str(PROJECT_ROOT))

import dash
from dash import html, dcc, callback, Input, Output, State
import dash_mantine_components as dmc
from dash_iconify import DashIconify

# Diskcache for caching
import diskcache

from config import PATHS, THEME, APP


# =============================================================================
# DISKCACHE SETUP FOR CACHING
# =============================================================================
cache_path = PATHS.CACHE / "callback_cache"
cache_path.mkdir(parents=True, exist_ok=True)
cache = diskcache.Cache(str(cache_path))


# =============================================================================
# DASH APPLICATION INITIALIZATION
# =============================================================================
app = dash.Dash(
    __name__,
    use_pages=True,
    pages_folder='pages',
    suppress_callback_exceptions=True,
    assets_folder='assets',
    serve_locally=True,  # CRITICAL: Air-gapped mode
    title=APP.TITLE,
    update_title=None,
)

server = app.server


# =============================================================================
# SIDEBAR NAVIGATION
# =============================================================================
def create_nav_link(icon: str, label: str, href: str) -> dmc.NavLink:
    """Create a navigation link with icon."""
    return dmc.NavLink(
        label=label,
        leftSection=DashIconify(icon=icon, width=20),
        href=href,
        variant="filled",
        active=False,
        style={"borderRadius": "8px", "marginBottom": "4px"}
    )


sidebar = dmc.Paper(
    [
        # Logo & Title
        dmc.Group(
            [
                DashIconify(icon="mdi:shield-lock", width=32, color=THEME.PRIMARY),
                dmc.Stack(
                    [
                        dmc.Text("VANGUARD", fw=700, size="lg", c=THEME.PRIMARY),
                        dmc.Text("APEX", size="xs", c="dimmed"),
                    ],
                    gap=0,
                ),
            ],
            p="md",
            style={"borderBottom": f"1px solid {THEME.DARK_BG_CARD}"}
        ),
        
        # Navigation Links
        dmc.Stack(
            [
                dmc.Text("NAVIGATION", size="xs", c="dimmed", fw=500, px="md", pt="md"),
                create_nav_link("mdi:view-dashboard", "Command Center", "/"),
                create_nav_link("mdi:upload", "Data Import", "/import"),
                create_nav_link("mdi:rocket-launch", "Pipeline Control", "/pipeline"),
                create_nav_link("mdi:table-search", "Audit Vault", "/audit-vault"),
                create_nav_link("mdi:chart-sankey", "Model Diagnostics", "/diagnostics"),
                create_nav_link("mdi:brain", "Explainability", "/explainability"),
                create_nav_link("mdi:server-security", "System Health", "/system-health"),
            ],
            gap=2,
            px="sm",
        ),
        
        # Spacer
        dmc.Space(h="xl"),
        
        # Pipeline Controls
        dmc.Stack(
            [
                dmc.Text("PIPELINE", size="xs", c="dimmed", fw=500, px="md"),
                dmc.Button(
                    "Global Pipeline Run",
                    id="btn-global-run",
                    leftSection=DashIconify(icon="mdi:play-circle", width=20),
                    color="cyan",
                    fullWidth=True,
                    variant="light",
                ),
                dmc.Button(
                    "Export Results",
                    id="btn-export",
                    leftSection=DashIconify(icon="mdi:download", width=20),
                    color="grape",
                    fullWidth=True,
                    variant="light",
                ),
            ],
            gap="xs",
            px="sm",
        ),
        
        # Bottom Section - System Status
        dmc.Space(style={"flex": 1}),
        
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Badge("ONLINE", color="green", variant="dot"),
                        dmc.Text("Air-Gapped", size="xs", c="dimmed"),
                    ],
                    justify="space-between",
                ),
                dmc.Progress(
                    value=0,
                    id="pipeline-progress",
                    color="cyan",
                    size="sm",
                    mt="xs",
                    style={"display": "none"}
                ),
            ],
            p="sm",
            m="sm",
            withBorder=True,
            radius="md",
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),
        
        # Privacy Toggle
        dmc.Switch(
            id="privacy-toggle",
            label="Privacy Mode",
            checked=True,
            size="sm",
            p="sm",
        ),
    ],
    style={
        "width": "260px",
        "height": "100vh",
        "position": "fixed",
        "left": 0,
        "top": 0,
        "display": "flex",
        "flexDirection": "column",
        "backgroundColor": THEME.DARK_BG_SECONDARY,
        "borderRight": f"1px solid {THEME.DARK_BG_CARD}",
    },
    radius=0,
)


# =============================================================================
# MAIN LAYOUT
# =============================================================================
app.layout = dmc.MantineProvider(
    theme=THEME.get_mantine_theme(),
    children=[
        dmc.NotificationProvider(position="top-right"),
        html.Div(id="notification-container"),
        
        # Stores for state management
        dcc.Store(id="store-privacy-mode", data=True, storage_type="local"),
        dcc.Store(id="store-pipeline-status", data={"running": False}),
        dcc.Store(id="store-last-run", storage_type="local"),
        dcc.Download(id="download-export"),
        
        # Main Container
        html.Div(
            [
                sidebar,
                html.Div(
                    [
                        dash.page_container,
                    ],
                    style={
                        "marginLeft": "260px",
                        "padding": "20px",
                        "minHeight": "100vh",
                        "backgroundColor": THEME.DARK_BG_PRIMARY,
                    },
                    id="page-content"
                ),
            ],
        ),
    ],
    forceColorScheme="dark",
)


# =============================================================================
# CALLBACKS - Privacy Mode
# =============================================================================
@callback(
    Output("store-privacy-mode", "data"),
    Input("privacy-toggle", "checked"),
)
def update_privacy_mode(checked):
    """Store privacy mode setting."""
    return checked


# =============================================================================
# CALLBACKS - Global Pipeline Run
# =============================================================================
@callback(
    Output("notification-container", "children"),
    Output("pipeline-progress", "value"),
    Output("pipeline-progress", "style"),
    Input("btn-global-run", "n_clicks"),
    State("store-privacy-mode", "data"),
    prevent_initial_call=True,
)
def run_global_pipeline(n_clicks, privacy_mode):
    """Execute the full anomaly detection pipeline."""
    if not n_clicks:
        return dash.no_update, 0, {"display": "none"}
    
    try:
        from utils.data_io import data_vault
        from pipeline import AnomalyEngine
        from utils.logger import logger
        
        # Check if data exists
        df = data_vault.get_data()
        if df is None:
            return dmc.Notification(
                title="No Data",
                message="Please import data first.",
                color="yellow",
                icon=DashIconify(icon="mdi:alert"),
            ), 0, {"display": "none"}
        
        # Run pipeline
        logger.log_action("Pipeline Run Started")
        engine = AnomalyEngine()
        engine.fit(df)
        scored_df = engine.predict(df)
        
        # Store results
        data_vault.set_scored_data(scored_df)
        engine.save()
        
        n_anomalies = int((scored_df['anomaly_score'] > 0.5).sum())
        
        return dmc.Notification(
            title="Pipeline Complete",
            message=f"Detected {n_anomalies:,} anomalies in {len(df):,} records.",
            color="green",
            icon=DashIconify(icon="mdi:check-circle"),
        ), 100, {"display": "block"}
        
    except Exception as e:
        from utils.logger import logger
        logger.log_error(e, "Global Pipeline Run")
        
        return dmc.Notification(
            title="Pipeline Error",
            message=str(e)[:100],
            color="red",
            icon=DashIconify(icon="mdi:alert-circle"),
        ), 0, {"display": "none"}


# =============================================================================
# CALLBACKS - Export
# =============================================================================
@callback(
    Output("download-export", "data"),
    Input("btn-export", "n_clicks"),
    prevent_initial_call=True,
)
def export_results(n_clicks):
    """Export anomaly scorecard."""
    if not n_clicks:
        return dash.no_update
    
    try:
        from utils.data_io import data_vault
        
        file_bytes, filename = data_vault.export_scorecard("excel")
        
        return dcc.send_bytes(file_bytes, filename)
        
    except Exception as e:
        return dash.no_update


# =============================================================================
# ENTRY POINT
# =============================================================================
if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("  PROJECT VANGUARD APEX")
    print("  Mission-Critical AML Platform")
    print("=" * 60)
    print(f"\n  🔒 AIR-GAPPED MODE: No external connections")
    print(f"  🌐 Running at: http://{APP.HOST}:{APP.PORT}")
    print(f"\n  Press Ctrl+C to stop the server")
    print("=" * 60 + "\n")
    
    app.run(
        host=APP.HOST,
        port=APP.PORT,
        debug=APP.DEBUG,
    )
