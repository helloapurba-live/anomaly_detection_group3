# FCDAI Technical Mastery Guide

Comprehensive learning resource based on the FCDAI Anomaly Detection Platform and modern web development practices.

## 1. 🕵️‍♂️ Anomaly Detection Paradigms

| Paradigm | Key Concept | Best For | Pros | Cons |
| :--- | :--- | :--- | :--- | :--- |
| **Statistical** | Deviations from expected distribution (e.g., Z-Score, IQR) | Single variables, normal distributions | Fast, interpretable, no training needed | Assumes normal distribution, sensitive to noise |
| **Machine Learning** | Learning patterns from data (e.g., Isolation Forest, SVM) | High-dimensional data, complex patterns | Handles non-linear relationships, scalable | Requires training data, "black box" nature |
| **Graph-Based** | Anomalies in relationships/structure (e.g., PageRank, Community) | Networks, social connections, fraud rings | Detects structural anomalies, finds hidden groups | Computationally expensive for large graphs |
| **Deep Learning** | Neural networks learning representations (e.g., Autoencoders) | Image, sequence, or very complex tabular data | Highest accuracy on huge datasets | Requires massive data & compute, hard to interpret |

---

## 2. 🕸️ Graph & Network Analysis

| Metric/Algorithm | Description | Interpretation | Business Use Case |
| :--- | :--- | :--- | :--- |
| **Degree Centrality** | Number of direct connections | "Popularity" or "Hub" status | Identify most active accounts or transaction hubs |
| **Betweenness** | Bridges between clusters (shortest paths) | "Gatekeepers" or "Connectors" | Find intermediaries in money laundering chains |
| **Eigenvector** | Connection to other important nodes | "Influence" or "Network Power" | Identify key influencers or high-value network nodes |
| **Louvain Modularity** | Community detection optimization | "Groups" or "Communities" | Detect fraud rings or distinct customer segments |
| **PageRank** | Importance based on incoming links | "Authority" or "Relevance" | Ranking search results or identifying significant entities |

---

## 3. 🏗️ Modern Web App Architecture

### Frontend Frameworks Comparison

| Framework | Architecture | Best For | Learning Curve | Key Feature |
| :--- | :--- | :--- | :--- | :--- |
| **Dash** | Python Wrapper for React | Data Science Apps, Enterprise Dashboards | Low (Python only) | Pure Python, component-based, callback logic |
| **Streamlit** | Script-based (reruns top-to-bottom) | rapid Prototyping, ML Demos | Very Low | Simple API, automatic reruns on input change |
| **Reflex** | Python -> React Compiler | Full-stack Web Apps in Python | Moderate | Type-safe, customizable, compiles to optimized React |
| **React** | Component-based JS Library | High-performance, Complex UIs | High (JS/TS ecosystem) | Virtual DOM, huge ecosystem, fully customizable |

### System Design Patterns

| Pattern | Description | When to Use | Trade-off |
| :--- | :--- | :--- | :--- |
| **Monolith** | Single codebase, single deployable unit | Small teams, MVP, simple apps | Hard to scale components independently, "spaghetti code" risk |
| **Microservices** | Distributed services per business domain | Large teams, independent scaling | Complexity in deployment, networking, data consistency |
| **Layered (N-Tier)** | Separated concerns (Presentation, Logic, Data) | Enterprise apps, clear organization | Can be rigid, "sinkhole" anti-pattern (passing data through layers) |
| **Event-Driven** | Services react to events (Pub/Sub) | Real-time systems, decoupling | Debugging complexity, eventual consistency challenges |

---

## 4. 📅 Web Development Lifecycle

| Phase | Key Activities | Deliverables | Tools |
| :--- | :--- | :--- | :--- |
| **1. Planning** | Requirements gathering, Feasibility study | PRD (Product Req Doc), User Stories | Jira, Trello, Notion |
| **2. Design** | System Architecture (HLD/LLD), UI/UX Mockups | Architecture Diagrams, Figma Prototypes | Figma, Draw.io, Mermaid.js |
| **3. Development** | Coding (Frontend + Backend), API Design | Source Code, API Specs (Swagger) | VS Code, Git, Postman |
| **4. Testing** | Unit, Integration, E2E, Performance Testing | Test Reports, Bug Fixes | Pytest, Selenium, JMeter |
| **5. Deployment** | CI/CD, Infrastructure Setup, Monitoring | Live Application, Dashboards | Docker, GitHub Actions, AWS/Azure |
| **6. Maintenance** | Bug fixing, Updates, Optimization | Patch Releases, Perf Reports | Sentry, Datadog |

---

## 5. 🚀 Deployment & Operations

| Strategy | Description | Pros | Cons |
| :--- | :--- | :--- | :--- |
| **Blue/Green** | Two identical environments; switch traffic instantly | Zero downtime, instant rollback | Double resource cost |
| **Canary** | Roll out to small user % first | Validate in production safely | Complex traffic routing needed |
| **Rolling** | Update instances one by one | Zero downtime, no extra resources resources | Slow rollback, mixed versions live |
| **Recreate** | Stop old -> Deploy new | Simple, clean state | Downtime during switch |

## 6. 🛡️ System Design in FCDAI

### Architecture Used: **Monolithic Layered Architecture**
- **Monolith:** All 7 layers and UI logic reside in a single codebase/process. Best for local development and simplicity.
- **Layered:** Clear separation between `pages/` (Presentation), `pipeline/` (Logic), and `utils/` (Data).

### Why Monolith for FCDAI?
- **Simplicity:** No need for complex networking or multiple services for a team of 1-5 developers.
- **Performance:** Direct function calls between layers (L1 → L7) are faster than network API calls (e.g., REST/gRPC) for local execution.
- **Consistency:** Single source of truth for configuration (`config.py`) and state.

---

## 7. 💾 Data Storage (Local Windows Recommendations)

**Objective:** Zero-config, persisted local storage native to Python.

| Library | Type | Why Pick This? | Pros | Cons |
| :--- | :--- | :--- | :--- | :--- |
| **1. SQLite (via `sqlite3`)** | SQL Relational | **🏆 TOP PICK** | Built-in, zero setup, single file, ACID compliant. | No concurrent writes (file lock), specific to local. |
| **2. DuckDB** | OLAP SQL | Analytics | Extremely fast for analytical queries on DataFrames. | Newer ecosystem, specialized for analytics. |
| **3. Pickle** | Object Serialize | Python Native | Saves *any* Python object (models, classes) exactly. | Security risk if unsigned, Python-specific format. |
| **4. Parquet (via Pandas)** | Columnar File | Big Data Local | Highly compressed, fast read/write for huge datasets. | Immutable (cannot update 1 row, must rewrite file). |
| **5. JSON/CSV** | Text File | Human Readable | universal, easy to debut/edit manually. | Slow, no types, inefficient storage. |

**Recommendation:** **SQLite** for metadata/cases (e.g., User profiles, Case status) + **Parquet** for high-volume transaction logs.

---

## 8. 🔌 API & Interface Design

**Objective:** Best fit for a Dash/Reflex Dashboard on Local Windows.

| Approach | Best Library | Why Pick This? |
| :--- | :--- | :--- |
| **1. Direct Function Calls** | Standard Python | **🏆 TOP PICK** | You are in a **Monolith**. Calling `run_pipeline()` directly is 1000x faster than an API call. |
| **2. REST API** | `FastAPI` | If you separate Backend/Frontend. Auto-generates Swagger docs. |
| **3. WebSockets** | `FastAPI` / `Dash` | For **Real-Time** alerts pushing to the UI without refresh. |
| **4. Background Tasks** | `Celery` / `Huey` | For long-running jobs (e.g., training models) without freezing UI. |

**Recommendation:** **Direct Python Calls** + **Background Threading** (via `concurrent.futures`) to keep UI responsive. No HTTP API needed for internal comms.

---

## 9. 🔐 Enterprise Security (Local Development)

**Objective:** Secure capabilities without complex infra like Keycloak/LDAP.

| Library | Category | Features | Why for Local? | Pros / Cons |
| :--- | :--- | :--- | :--- | :--- |
| **1. `cryptography`** | Encryption | AES-256, Fernet | Industry standard, robust encryption primitives. | **Pros:** Secure, Pythonic. **Cons:** Low-level API. |
| **2. `passlib`** | Hashing | Argon2, BCrypt | Secure password hashing (never store plain text!). | **Pros:** Handles salt/hash automatically. |
| **3. `python-jose`** | Tokens | JWT | Stateless authentication tokens. | **Pros:** Good for API auth. **Cons:** Overkill for simple app. |
| **4. `flask-login`** | Auth Flow | Session Mgmt | Manages user sessions, cookies, login/logout. | **Pros:** Integrates well with Dash. |
| **5. `pydantic`** | Validation | Data Sanity | Prevents injection/bad data at the door. | **Pros:** Type safety, auto-validation. |

**Recommendation:** Use **`passlib`** to hash passwords + **`flask-login`** (for Dash) to handle user sessions cleanly.

---

## 10. 📊 Observability & Reliability (Local)

**Objective:** Understand what your code is doing without setting up Prometheus/ELK.

| Library | Category | Features | Why Pick This? | Pros / Cons |
| :--- | :--- | :--- | :--- | :--- |
| **1. `structlog`** | Logging | Structured Logs | **🏆 TOP PICK**. Outputs JSON/Color logs. "Events" over "Lines". | **Pros:** Contextual logging (add `user_id` to all logs). |
| **2. `loguru`** | Logging | Zero Config | "Print" replacement. Beautiful colored output. | **Pros:** Easiest setup. **Cons:** Non-standard (not stdlib). |
| **3. `tqdm`** | Progress | Progress Bars | Visualize loop progress (L5 Detection steps). | **Pros:** User experience gold. |
| **4. `memory_profiler`** | Profiling | Component RAM | Find memory leaks in your pipeline. | **Pros:** Line-by-line RAM usage. |
| **5. `sentry-sdk`** | Error Tracking | Exception Capture | Captures full stack trace + local vars on crash. | **Pros:** Best debugging info. |

**Recommendation:** **`structlog`** for application logs (audit trail) + **`tqdm`** for UI feedback during long tasks.

---

**Generated specific for FCDAI Technical Review** | 2026
