# Enterprise Integration Guide

You now have a powerful `utils/enterprise.py` module in both of your Dash applications.
This module implements the **4 pillars** of enterprise software we discussed:

1.  **Observability** (Structlog)
2.  **Security** (Passlib + Auth)
3.  **Storage** (SQLite)
4.  **Interface** (Background Tasks)

## 🚀 How to Use It

I designed it as a **Singleton** for easy access. You just need to import `FCDAI` from `utils.enterprise`.

### 1. Basic Setup (in `app.py`)

Add this at the top of your `app.py` or any page file:

```python
from utils.enterprise import FCDAI

# Access the components
logger = FCDAI.logger
db = FCDAI.storage
auth = FCDAI.auth
tasks = FCDAI.tasks
```

### 2. logging Events (Observability)

Instead of `print()`, use the structured logger. This will be saved to your logs with timestamps.

```python
# Log a simple info message
logger.info("application_startup", port=8071, env="local")

# Log an error with context
try:
    process_data()
except Exception as e:
    logger.error("processing_failed", error=str(e), file="data.csv")
```

### 3. Storing User Data & Audit Trails (Storage)

The `SecureStorage` class automatically creates `fcdai_local.db`.

```python
# Create a new user
FCDAI.storage.create_user("admin", "hashed_password_123", role="admin")

# Log an audit event (Compliance)
FCDAI.storage.log_event(
    event_type="pipeline_execution",
    user_id="analyst_1",
    details={"layers": [1, 2, 3], "status": "success"}
)
```

### 4. Running Long Tasks (Interface)

Don't freeze the UI! Use the `TaskManager` to run heavy detection methods in the background.

```python
def run_heavy_model(data):
    time.sleep(10)  # Simulate work
    return "Fraud Detected"

# Submit task
task_id = "job_123"
FCDAI.tasks.submit_task(task_id, run_heavy_model, data=my_data)

# Check status later
status = FCDAI.tasks.get_status(task_id)  # "running" or "completed"
```

### 5. Secure Authentication (Security)

Use the `Authenticator` to verify passwords.

```python
# Verify login
is_valid = FCDAI.auth.verify_password(
    plain_password=user_input_password,
    hashed_password=stored_hash_from_db
)

if is_valid:
    token = FCDAI.auth.generate_token(user_id="admin")
    logger.info("login_success", user="admin")
```

## 📂 File Locations

- **Dash 7-Layer (Port 8071):** `c:\Users\hello_c2bu3y4\OneDrive\Desktop\desktop_samsung_may_2024\C\git\project_vanguard_7layer\utils\enterprise.py`
- **Dash Apex (Port 8070):** `c:\Users\hello_c2bu3y4\OneDrive\Desktop\desktop_samsung_may_2024\C\git\project_vanguard\utils\enterprise.py`

**Generated for FCDAI Enterprise Upgrade** | 2026
