"""
Project Vanguard Apex - System Health Page
==========================================
Admin dashboard showing logs, RAM/CPU usage via psutil,
and pipeline execution history.

Author: Project Vanguard Team
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
from datetime import datetime
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import THEME, APP

# Try importing psutil
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False


dash.register_page(__name__, path="/system-health", name="System Health", order=3)


# =============================================================================
# PAGE LAYOUT
# =============================================================================
layout = dmc.Container(
    [
        # Header
        dmc.Group(
            [
                dmc.Title("System Health", order=2),
                dmc.Badge("Admin", color="red", variant="light"),
            ],
            justify="space-between",
            mb="lg",
        ),
        
        # System Metrics
        dmc.Paper(
            [
                dmc.Text("System Resources", fw=600, mb="md"),
                dmc.SimpleGrid(
                    id="system-metrics",
                    cols={"base": 2, "md": 4},
                    spacing="md",
                ),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
            mb="lg",
        ),
        
        # Resource Gauges
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2},
            spacing="lg",
            children=[
                dmc.Paper(
                    [
                        dmc.Text("CPU Usage", fw=600, mb="sm"),
                        dcc.Graph(
                            id="gauge-cpu",
                            config={"displayModeBar": False},
                            style={"height": "200px"},
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Text("Memory Usage", fw=600, mb="sm"),
                        dcc.Graph(
                            id="gauge-memory",
                            config={"displayModeBar": False},
                            style={"height": "200px"},
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
            ],
            mb="lg",
        ),
        
        # Audit Log Viewer
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Text("Audit Log", fw=600),
                        dmc.SegmentedControl(
                            id="log-type-select",
                            data=[
                                {"value": "audit", "label": "Actions"},
                                {"value": "errors", "label": "Errors"},
                            ],
                            value="audit",
                            size="xs",
                        ),
                    ],
                    justify="space-between",
                    mb="md",
                ),
                dmc.ScrollArea(
                    html.Div(id="log-viewer"),
                    h=300,
                ),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
            mb="lg",
        ),
        
        # Data Store Status
        dmc.Paper(
            [
                dmc.Text("Data Store Status", fw=600, mb="md"),
                html.Div(id="data-store-status"),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),
        
        # Refresh interval
        dcc.Interval(id="health-refresh", interval=5000, n_intervals=0),
    ],
    fluid=True,
)


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("system-metrics", "children"),
    Input("health-refresh", "n_intervals"),
)
def update_system_metrics(n):
    """Update system resource metrics."""
    metrics = []
    
    if PSUTIL_AVAILABLE:
        cpu_percent = psutil.cpu_percent(interval=0.1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        # Uptime
        boot_time = datetime.fromtimestamp(psutil.boot_time())
        uptime = datetime.now() - boot_time
        uptime_str = f"{uptime.days}d {uptime.seconds // 3600}h"
        
        metrics = [
            dmc.Group([
                DashIconify(icon="mdi:chip", width=24, color=THEME.PRIMARY),
                dmc.Stack([
                    dmc.Text("CPU", size="xs", c="dimmed"),
                    dmc.Text(f"{cpu_percent:.1f}%", fw=700),
                ], gap=0),
            ]),
            dmc.Group([
                DashIconify(icon="mdi:memory", width=24, color=THEME.SECONDARY),
                dmc.Stack([
                    dmc.Text("Memory", size="xs", c="dimmed"),
                    dmc.Text(f"{memory.percent:.1f}%", fw=700),
                ], gap=0),
            ]),
            dmc.Group([
                DashIconify(icon="mdi:harddisk", width=24, color=THEME.SUCCESS),
                dmc.Stack([
                    dmc.Text("Disk", size="xs", c="dimmed"),
                    dmc.Text(f"{disk.percent:.1f}%", fw=700),
                ], gap=0),
            ]),
            dmc.Group([
                DashIconify(icon="mdi:clock-outline", width=24, color=THEME.WARNING),
                dmc.Stack([
                    dmc.Text("Uptime", size="xs", c="dimmed"),
                    dmc.Text(uptime_str, fw=700),
                ], gap=0),
            ]),
        ]
    else:
        metrics = [
            dmc.Alert(
                "Install psutil for system metrics: pip install psutil",
                color="yellow",
            )
        ]
    
    return metrics


@callback(
    Output("gauge-cpu", "figure"),
    Output("gauge-memory", "figure"),
    Input("health-refresh", "n_intervals"),
)
def update_gauges(n):
    """Update resource gauge charts."""
    if PSUTIL_AVAILABLE:
        cpu_percent = psutil.cpu_percent(interval=0.1)
        memory = psutil.virtual_memory()
    else:
        cpu_percent = 0
        memory = type('obj', (object,), {'percent': 0})()
    
    def create_gauge(value, title, color):
        fig = go.Figure(go.Indicator(
            mode="gauge+number",
            value=value,
            gauge={
                'axis': {'range': [0, 100], 'tickwidth': 1},
                'bar': {'color': color},
                'bgcolor': THEME.DARK_BG_PRIMARY,
                'borderwidth': 0,
                'steps': [
                    {'range': [0, 50], 'color': 'rgba(0,200,83,0.3)'},
                    {'range': [50, 75], 'color': 'rgba(255,179,0,0.3)'},
                    {'range': [75, 100], 'color': 'rgba(255,82,82,0.3)'},
                ],
            },
            number={'suffix': '%'},
        ))
        
        fig.update_layout(
            margin=dict(l=20, r=20, t=20, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            font=dict(color="white"),
            height=180,
        )
        
        return fig
    
    cpu_fig = create_gauge(cpu_percent, "CPU", THEME.PRIMARY)
    mem_fig = create_gauge(memory.percent, "Memory", THEME.SECONDARY)
    
    return cpu_fig, mem_fig


@callback(
    Output("log-viewer", "children"),
    Input("log-type-select", "value"),
    Input("health-refresh", "n_intervals"),
)
def update_log_viewer(log_type, n):
    """Update log viewer with recent entries."""
    try:
        from utils.logger import logger
        
        logs = logger.get_recent_logs(n_lines=100, log_type=log_type)
        
        if not logs:
            return dmc.Text("No log entries found.", c="dimmed")
        
        # Reverse to show newest first
        logs = list(reversed(logs))
        
        # Create log entries
        entries = []
        for line in logs[:50]:
            line = line.strip()
            if not line:
                continue
            
            # Color based on content
            color = "dimmed"
            if "ERROR" in line or "FAILED" in line:
                color = "red"
            elif "SUCCESS" in line:
                color = "green"
            elif "Pipeline" in line:
                color = "cyan"
            
            entries.append(
                dmc.Text(
                    line,
                    size="xs",
                    c=color,
                    style={"fontFamily": "monospace", "whiteSpace": "pre-wrap"}
                )
            )
        
        return dmc.Stack(entries, gap="xs")
        
    except Exception as e:
        return dmc.Alert(f"Error loading logs: {str(e)}", color="red")


@callback(
    Output("data-store-status", "children"),
    Input("health-refresh", "n_intervals"),
)
def update_data_store_status(n):
    """Show data store status."""
    try:
        from utils.data_io import data_vault
        from config import PATHS
        
        metadata = data_vault.get_metadata()
        current_data = data_vault.get_data()
        scored_data = data_vault.get_scored_data()
        
        # Check file sizes
        vault_path = PATHS.DATA_VAULT / "current.parquet"
        vault_size = vault_path.stat().st_size if vault_path.exists() else 0
        
        scored_path = PATHS.DATA_VAULT / "scored.parquet"
        scored_size = scored_path.stat().st_size if scored_path.exists() else 0
        
        # Format sizes
        def format_size(size_bytes):
            for unit in ['B', 'KB', 'MB', 'GB']:
                if size_bytes < 1024:
                    return f"{size_bytes:.1f} {unit}"
                size_bytes /= 1024
            return f"{size_bytes:.1f} TB"
        
        items = [
            dmc.Group([
                dmc.Text("Source File", c="dimmed"),
                dmc.Text(metadata.get('filename', 'None'), fw=500),
            ], justify="space-between"),
            dmc.Group([
                dmc.Text("Raw Data Rows", c="dimmed"),
                dmc.Text(f"{len(current_data):,}" if current_data is not None else "0", fw=500),
            ], justify="space-between"),
            dmc.Group([
                dmc.Text("Scored Data Rows", c="dimmed"),
                dmc.Text(f"{len(scored_data):,}" if scored_data is not None else "0", fw=500),
            ], justify="space-between"),
            dmc.Group([
                dmc.Text("Vault Size", c="dimmed"),
                dmc.Text(format_size(vault_size), fw=500),
            ], justify="space-between"),
            dmc.Group([
                dmc.Text("Last Import", c="dimmed"),
                dmc.Text(metadata.get('import_time', 'Never')[:19] if metadata.get('import_time') else 'Never', fw=500),
            ], justify="space-between"),
        ]
        
        return dmc.Stack([
            dmc.Paper(item, p="sm", withBorder=True, radius="sm") 
            for item in items
        ], gap="xs")
        
    except Exception as e:
        return dmc.Alert(f"Error: {str(e)}", color="red")
