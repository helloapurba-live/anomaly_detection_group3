"""
Project Vanguard Apex - Explainability Page
============================================
SHAP-style visualizations and reasoning for anomaly alerts.
Provides interpretable "Why" for each flagged transaction.

Author: Project Vanguard Team
"""

import dash
from dash import html, dcc, callback, Input, Output, State
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import THEME, APP


dash.register_page(__name__, path="/explainability", name="Explainability", order=5)


# =============================================================================
# PAGE LAYOUT
# =============================================================================
layout = dmc.Container(
    [
        # Header
        dmc.Group(
            [
                dmc.Title("Alert Explainability", order=2),
                dmc.Badge("SHAP-Style Analysis", color="grape", variant="light"),
            ],
            justify="space-between",
            mb="lg",
        ),
        
        # Alert Selection
        dmc.Paper(
            [
                dmc.Text("Select Alert to Analyze", fw=600, mb="md"),
                dmc.SimpleGrid(
                    cols={"base": 1, "md": 3},
                    spacing="md",
                    children=[
                        dmc.NumberInput(
                            id="alert-index",
                            label="Alert Index",
                            value=0,
                            min=0,
                            step=1,
                        ),
                        dmc.Button(
                            "Analyze Alert",
                            id="btn-analyze",
                            leftSection=DashIconify(icon="mdi:magnify", width=18),
                            color="cyan",
                        ),
                        dmc.Button(
                            "Next High-Risk Alert",
                            id="btn-next-alert",
                            leftSection=DashIconify(icon="mdi:arrow-right", width=18),
                            variant="light",
                        ),
                    ],
                ),
            ],
            p="md",
            mb="lg",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),
        
        # Alert Summary Card
        html.Div(id="alert-summary-card"),
        
        dmc.Space(h="lg"),
        
        # Explanation Charts
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2},
            spacing="lg",
            children=[
                dmc.Paper(
                    [
                        dmc.Text("Feature Contribution", fw=600, mb="sm"),
                        dcc.Graph(
                            id="chart-feature-contribution",
                            config=APP.PLOTLY_CONFIG,
                            style={"height": "350px"},
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Text("Reasoning Breakdown", fw=600, mb="sm"),
                        html.Div(id="reasoning-breakdown"),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD, "minHeight": "350px"}
                ),
            ],
        ),
        
        dmc.Space(h="lg"),
        
        # Global Feature Importance
        dmc.Paper(
            [
                dmc.Text("Global Feature Importance (All Alerts)", fw=600, mb="sm"),
                dcc.Graph(
                    id="chart-global-importance",
                    config=APP.PLOTLY_CONFIG,
                    style={"height": "300px"},
                ),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),
        
        # Store for current alert data
        dcc.Store(id="store-current-alert"),
    ],
    fluid=True,
)


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("alert-summary-card", "children"),
    Output("store-current-alert", "data"),
    Input("btn-analyze", "n_clicks"),
    Input("btn-next-alert", "n_clicks"),
    State("alert-index", "value"),
    prevent_initial_call=True,
)
def analyze_alert(analyze_clicks, next_clicks, alert_idx):
    """Analyze selected alert and show summary."""
    try:
        from utils.data_io import data_vault
        from dash import ctx
        
        df = data_vault.get_scored_data()
        
        if df is None or 'anomaly_score' not in df.columns:
            return dmc.Alert(
                "No scored data available. Run the pipeline first.",
                color="yellow",
            ), None
        
        # Find high-risk alerts
        high_risk = df[df['anomaly_score'] > 0.5].index.tolist()
        
        if not high_risk:
            return dmc.Alert(
                "No anomalies detected in current dataset.",
                color="green",
            ), None
        
        # Handle next alert button
        if ctx.triggered_id == "btn-next-alert":
            current_pos = high_risk.index(alert_idx) if alert_idx in high_risk else -1
            next_pos = (current_pos + 1) % len(high_risk)
            alert_idx = high_risk[next_pos]
        
        if alert_idx >= len(df):
            alert_idx = 0
        
        row = df.iloc[alert_idx]
        
        # Build summary card
        score = row.get('anomaly_score', 0)
        risk_level = row.get('risk_level', 'Unknown')
        
        risk_color = {
            'High': 'red',
            'Medium-High': 'orange',
            'Medium': 'yellow',
            'Low-Medium': 'lime',
            'Low': 'green',
        }.get(risk_level, 'gray')
        
        summary = dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Stack(
                            [
                                dmc.Text(f"Alert #{alert_idx}", fw=700, size="lg"),
                                dmc.Badge(risk_level, color=risk_color, size="lg"),
                            ],
                            gap="xs",
                        ),
                        dmc.Stack(
                            [
                                dmc.Text("Anomaly Score", size="sm", c="dimmed"),
                                dmc.Text(f"{score:.3f}", fw=700, size="xl"),
                            ],
                            gap=0,
                            align="center",
                        ),
                        dmc.Stack(
                            [
                                dmc.Text("Position", size="sm", c="dimmed"),
                                dmc.Text(
                                    f"{high_risk.index(alert_idx) + 1} of {len(high_risk)}" 
                                    if alert_idx in high_risk else "N/A",
                                    fw=500,
                                ),
                            ],
                            gap=0,
                            align="center",
                        ),
                    ],
                    justify="space-between",
                ),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        )
        
        return summary, {"idx": alert_idx, "score": score}
        
    except Exception as e:
        return dmc.Alert(f"Error: {str(e)}", color="red"), None


@callback(
    Output("chart-feature-contribution", "figure"),
    Input("store-current-alert", "data"),
)
def update_feature_contribution(alert_data):
    """Update feature contribution waterfall chart."""
    try:
        from utils.data_io import data_vault
        
        if not alert_data:
            return go.Figure()
        
        df = data_vault.get_scored_data()
        if df is None:
            return go.Figure()
        
        idx = alert_data['idx']
        
        # Get score columns for contribution
        score_cols = [c for c in df.columns if c.startswith('score_')]
        
        if not score_cols:
            # Use numeric columns as proxy
            numeric_cols = df.select_dtypes(include=[np.number]).columns[:10]
            contributions = df.iloc[idx][numeric_cols].to_dict()
        else:
            contributions = df.iloc[idx][score_cols].to_dict()
        
        # Sort by absolute value
        sorted_contrib = sorted(contributions.items(), key=lambda x: abs(x[1]), reverse=True)[:10]
        
        names = [c.replace('score_', '').replace('_', ' ').title() for c, _ in sorted_contrib]
        values = [v for _, v in sorted_contrib]
        colors = [THEME.DANGER if v > 0.5 else THEME.PRIMARY for v in values]
        
        fig = go.Figure(go.Bar(
            y=names,
            x=values,
            orientation='h',
            marker_color=colors,
        ))
        
        fig.update_layout(
            template="plotly_dark",
            margin=dict(l=20, r=20, t=20, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            xaxis_title="Contribution to Risk Score",
            yaxis=dict(autorange="reversed"),
        )
        
        return fig
        
    except Exception:
        return go.Figure()


@callback(
    Output("reasoning-breakdown", "children"),
    Input("store-current-alert", "data"),
)
def update_reasoning(alert_data):
    """Generate reasoning breakdown for alert."""
    try:
        from utils.data_io import data_vault
        
        if not alert_data:
            return dmc.Text("Select an alert to view reasoning.", c="dimmed")
        
        df = data_vault.get_scored_data()
        if df is None:
            return dmc.Text("No data available.", c="dimmed")
        
        idx = alert_data['idx']
        row = df.iloc[idx]
        
        # Generate reasoning items
        reasons = []
        
        # Check various risk indicators
        if 'anomaly_score' in row and row['anomaly_score'] > 0.8:
            reasons.append({
                'icon': 'mdi:alert-circle',
                'color': 'red',
                'title': 'Critical Risk Level',
                'detail': 'Score exceeds 80% threshold'
            })
        
        # Check for high algorithm scores
        score_cols = [c for c in df.columns if c.startswith('score_')]
        high_scores = [(c, row[c]) for c in score_cols if row[c] > 0.7]
        
        for col, score in high_scores[:3]:
            algo_name = col.replace('score_', '').replace('_', ' ').title()
            reasons.append({
                'icon': 'mdi:brain',
                'color': 'orange',
                'title': f'{algo_name} Detection',
                'detail': f'Score: {score:.2f}'
            })
        
        if not reasons:
            reasons.append({
                'icon': 'mdi:check-circle',
                'color': 'green',
                'title': 'Low Risk Indicators',
                'detail': 'No significant anomaly patterns detected'
            })
        
        # Build UI
        items = []
        for reason in reasons:
            items.append(
                dmc.Paper(
                    dmc.Group(
                        [
                            dmc.ThemeIcon(
                                DashIconify(icon=reason['icon'], width=20),
                                color=reason['color'],
                                size="lg",
                                radius="md",
                            ),
                            dmc.Stack(
                                [
                                    dmc.Text(reason['title'], fw=600, size="sm"),
                                    dmc.Text(reason['detail'], size="xs", c="dimmed"),
                                ],
                                gap=2,
                            ),
                        ],
                        gap="md",
                    ),
                    p="sm",
                    mb="xs",
                    withBorder=True,
                    radius="sm",
                )
            )
        
        return dmc.Stack(items, gap="xs")
        
    except Exception as e:
        return dmc.Alert(f"Error: {str(e)}", color="red")


@callback(
    Output("chart-global-importance", "figure"),
    Input("btn-analyze", "n_clicks"),
)
def update_global_importance(n):
    """Update global feature importance chart."""
    try:
        from utils.data_io import data_vault
        
        df = data_vault.get_scored_data()
        if df is None:
            return go.Figure()
        
        # Calculate mean importance from score columns
        score_cols = [c for c in df.columns if c.startswith('score_')]
        
        if not score_cols:
            return go.Figure()
        
        # Calculate variance of each score column as proxy for importance
        importance = {}
        for col in score_cols:
            importance[col.replace('score_', '')] = df[col].std()
        
        # Sort and plot
        sorted_imp = sorted(importance.items(), key=lambda x: x[1], reverse=True)[:15]
        names = [n.replace('_', ' ').title() for n, _ in sorted_imp]
        values = [v for _, v in sorted_imp]
        
        fig = px.bar(
            x=names,
            y=values,
            template="plotly_dark",
        )
        
        fig.update_traces(marker_color=THEME.SECONDARY)
        
        fig.update_layout(
            margin=dict(l=20, r=20, t=20, b=60),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            xaxis_title="Algorithm",
            yaxis_title="Importance (Std Dev)",
            xaxis_tickangle=-45,
        )
        
        return fig
        
    except Exception:
        return go.Figure()
