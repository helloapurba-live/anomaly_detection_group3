"""
Project Vanguard Apex - Pipeline Control Page
==============================================
Run anomaly detection pipeline and export results.

Author: Project Vanguard Team
"""

import dash
from dash import html, dcc, callback, Input, Output, State
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import pandas as pd
import sys
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import THEME, PATHS


dash.register_page(__name__, path="/pipeline", name="Pipeline Control", order=3)


# =============================================================================
# PAGE LAYOUT
# =============================================================================
layout = dmc.Container(
    [
        # Header
        dmc.Group(
            [
                dmc.Title("Pipeline Control", order=2),
                dmc.Badge("Anomaly Engine", color="cyan", variant="light"),
            ],
            justify="space-between",
            mb="lg",
        ),
        
        # Status Card
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Text("Current Status", fw=600),
                        html.Div(id="pipeline-status-badge"),
                    ],
                    justify="space-between",
                ),
                html.Div(id="pipeline-status"),
            ],
            p="md",
            mb="lg",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),
        
        # Control Buttons
        dmc.SimpleGrid(
            cols={"base": 1, "md": 3},
            spacing="md",
            mb="lg",
            children=[
                dmc.Paper(
                    [
                        dmc.Stack(
                            [
                                dmc.ThemeIcon(
                                    DashIconify(icon="mdi:play-circle", width=32),
                                    size="xl",
                                    color="green",
                                    variant="light",
                                ),
                                dmc.Text("Run Full Pipeline", fw=600),
                                dmc.Text("Train & score all data", size="sm", c="dimmed"),
                                dmc.Button(
                                    "Execute",
                                    id="btn-run-pipeline",
                                    color="green",
                                    fullWidth=True,
                                    mt="md",
                                    leftSection=DashIconify(icon="mdi:rocket-launch", width=18),
                                ),
                            ],
                            align="center",
                        ),
                    ],
                    p="lg",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Stack(
                            [
                                dmc.ThemeIcon(
                                    DashIconify(icon="mdi:file-export", width=32),
                                    size="xl",
                                    color="cyan",
                                    variant="light",
                                ),
                                dmc.Text("Export Scorecard", fw=600),
                                dmc.Text("Excel with metadata", size="sm", c="dimmed"),
                                dmc.Button(
                                    "Export",
                                    id="btn-export-scorecard",
                                    color="cyan",
                                    fullWidth=True,
                                    mt="md",
                                    leftSection=DashIconify(icon="mdi:download", width=18),
                                ),
                            ],
                            align="center",
                        ),
                    ],
                    p="lg",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Stack(
                            [
                                dmc.ThemeIcon(
                                    DashIconify(icon="mdi:refresh", width=32),
                                    size="xl",
                                    color="orange",
                                    variant="light",
                                ),
                                dmc.Text("Reset Pipeline", fw=600),
                                dmc.Text("Clear models & cache", size="sm", c="dimmed"),
                                dmc.Button(
                                    "Reset",
                                    id="btn-reset-pipeline",
                                    color="orange",
                                    variant="light",
                                    fullWidth=True,
                                    mt="md",
                                    leftSection=DashIconify(icon="mdi:delete-sweep", width=18),
                                ),
                            ],
                            align="center",
                        ),
                    ],
                    p="lg",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
            ],
        ),
        
        # Algorithm Selection
        dmc.Paper(
            [
                dmc.Text("Algorithm Selection", fw=600, mb="md"),
                dmc.MultiSelect(
                    id="select-algorithms",
                    label="Active Algorithms",
                    placeholder="Select algorithms to run...",
                    data=[
                        {"value": "IsolationForest", "label": "Isolation Forest"},
                        {"value": "LocalOutlierFactor", "label": "Local Outlier Factor"},
                        {"value": "EllipticEnvelope", "label": "Elliptic Envelope"},
                        {"value": "DBSCAN", "label": "DBSCAN"},
                        {"value": "OneClassSVM", "label": "One-Class SVM"},
                        {"value": "IForest_PyOD", "label": "IForest (PyOD)"},
                        {"value": "KNN", "label": "K-Nearest Neighbors"},
                        {"value": "COF", "label": "COF"},
                        {"value": "COPOD", "label": "COPOD"},
                        {"value": "ECOD", "label": "ECOD"},
                        {"value": "HBOS", "label": "HBOS"},
                        {"value": "MCD", "label": "MCD"},
                        {"value": "CBLOF", "label": "CBLOF"},
                        {"value": "SOD", "label": "SOD"},
                        {"value": "OCSVM", "label": "OCSVM"},
                    ],
                    value=["IsolationForest", "COPOD", "ECOD", "HBOS", "KNN"],
                    searchable=True,
                    clearable=True,
                ),
            ],
            p="md",
            mb="lg",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),
        
        # Execution Log
        dmc.Paper(
            [
                dmc.Text("Execution Log", fw=600, mb="md"),
                html.Div(
                    id="execution-log",
                    style={
                        "height": "200px",
                        "overflowY": "auto",
                        "backgroundColor": "rgba(0, 0, 0, 0.3)",
                        "padding": "10px",
                        "borderRadius": "6px",
                        "fontFamily": "monospace",
                        "fontSize": "12px",
                    }
                ),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),
        
        # Hidden stores
        dcc.Store(id="store-pipeline-result"),
        dcc.Download(id="download-scorecard"),
    ],
    fluid=True,
)


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("pipeline-status", "children"),
    Output("pipeline-status-badge", "children"),
    Input("btn-run-pipeline", "n_clicks"),
    prevent_initial_call=False,
)
def check_pipeline_status(n):
    """Check current pipeline status."""
    try:
        from utils.data_io import data_vault
        
        df = data_vault.get_scored_data()
        raw_df = data_vault.get_data()
        
        if df is not None and 'anomaly_score' in df.columns:
            n_records = len(df)
            n_anomalies = (df['anomaly_score'] > 0.5).sum()
            score_cols = [c for c in df.columns if c.startswith('score_')]
            
            status = dmc.Stack([
                dmc.Group([
                    dmc.Text("Records:", c="dimmed"),
                    dmc.Text(f"{n_records:,}", fw=600),
                ]),
                dmc.Group([
                    dmc.Text("Anomalies:", c="dimmed"),
                    dmc.Text(f"{n_anomalies:,}", fw=600),
                ]),
                dmc.Group([
                    dmc.Text("Algorithms:", c="dimmed"),
                    dmc.Text(f"{len(score_cols)}", fw=600),
                ]),
            ], gap="xs")
            
            badge = dmc.Badge("Scored", color="green", variant="filled")
            
        elif raw_df is not None:
            status = dmc.Text(f"{len(raw_df):,} records loaded, not yet scored")
            badge = dmc.Badge("Data Ready", color="yellow", variant="filled")
            
        else:
            status = dmc.Text("No data loaded. Import data first.", c="dimmed")
            badge = dmc.Badge("No Data", color="gray", variant="filled")
        
        return status, badge
        
    except Exception as e:
        return dmc.Text(f"Error: {str(e)}", c="red"), dmc.Badge("Error", color="red")


@callback(
    Output("execution-log", "children"),
    Output("store-pipeline-result", "data"),
    Input("btn-run-pipeline", "n_clicks"),
    State("select-algorithms", "value"),
    prevent_initial_call=True,
)
def run_pipeline(n_clicks, algorithms):
    """Execute the anomaly detection pipeline."""
    if not n_clicks:
        return dash.no_update, dash.no_update
    
    try:
        from utils.data_io import data_vault
        from pipeline import AnomalyEngine
        from utils.logger import logger
        
        df = data_vault.get_data()
        
        if df is None:
            return [dmc.Text("❌ No data available. Import data first.", c="red")], None
        
        logs = []
        logs.append(dmc.Text(f"[{datetime.now().strftime('%H:%M:%S')}] Starting pipeline...", c="cyan"))
        logs.append(dmc.Text(f"[{datetime.now().strftime('%H:%M:%S')}] Records: {len(df):,}", c="dimmed"))
        logs.append(dmc.Text(f"[{datetime.now().strftime('%H:%M:%S')}] Algorithms: {algorithms}", c="dimmed"))
        
        # Initialize engine
        engine = AnomalyEngine()
        
        logs.append(dmc.Text(f"[{datetime.now().strftime('%H:%M:%S')}] Fitting models...", c="green"))
        
        # Fit
        engine.fit(df, algorithms)
        
        logs.append(dmc.Text(f"[{datetime.now().strftime('%H:%M:%S')}] Scoring data...", c="green"))
        
        # Predict
        scored_df = engine.predict(df, algorithms)
        
        # Save results
        data_vault.set_scored_data(scored_df)
        engine.save()
        
        n_anomalies = (scored_df['anomaly_score'] > 0.5).sum()
        
        logs.append(dmc.Text(f"[{datetime.now().strftime('%H:%M:%S')}] ✅ Complete!", c="lime"))
        logs.append(dmc.Text(f"[{datetime.now().strftime('%H:%M:%S')}] Detected {n_anomalies:,} anomalies", c="yellow"))
        
        logger.log_action("Pipeline Executed", metadata={
            "records": len(df),
            "algorithms": len(algorithms),
            "anomalies": int(n_anomalies)
        })
        
        return dmc.Stack(logs, gap=2), {"success": True, "anomalies": int(n_anomalies)}
        
    except Exception as e:
        from utils.logger import logger
        logger.log_error(e, "Pipeline Execution")
        
        return [dmc.Text(f"❌ Error: {str(e)}", c="red")], {"success": False, "error": str(e)}


@callback(
    Output("download-scorecard", "data"),
    Input("btn-export-scorecard", "n_clicks"),
    prevent_initial_call=True,
)
def export_scorecard(n_clicks):
    """Export anomaly scorecard to Excel."""
    if not n_clicks:
        return dash.no_update
    
    try:
        from utils.data_io import data_vault
        from utils.forensic_export import ForensicExporter
        
        df = data_vault.get_scored_data()
        
        if df is None:
            return dash.no_update
        
        # Export
        exporter = ForensicExporter()
        filepath = exporter.export_scorecard(df, format="xlsx")
        
        # Return for download
        return dcc.send_file(str(filepath))
        
    except Exception as e:
        return dash.no_update


@callback(
    Output("execution-log", "children", allow_duplicate=True),
    Input("btn-reset-pipeline", "n_clicks"),
    prevent_initial_call=True,
)
def reset_pipeline(n_clicks):
    """Reset pipeline state."""
    if not n_clicks:
        return dash.no_update
    
    try:
        from utils.data_io import clear_scored_data
        from utils.logger import logger
        import shutil
        
        # Clear scored data
        clear_scored_data()
        
        # Clear model files
        model_dir = PATHS.MODELS
        if model_dir.exists():
            for f in model_dir.glob("*.pkl"):
                f.unlink()
        
        logger.log_action("Pipeline Reset")
        
        return [dmc.Text(f"[{datetime.now().strftime('%H:%M:%S')}] Pipeline reset complete.", c="yellow")]
        
    except Exception as e:
        return [dmc.Text(f"❌ Error: {str(e)}", c="red")]
