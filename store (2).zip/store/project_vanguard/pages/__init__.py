"""
Project Vanguard Pages Package
"""
