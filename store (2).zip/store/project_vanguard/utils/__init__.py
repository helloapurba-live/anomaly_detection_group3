"""
Project Vanguard Utils Package
"""
