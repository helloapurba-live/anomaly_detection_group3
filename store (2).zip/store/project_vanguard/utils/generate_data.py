"""
Project Vanguard Apex - Synthetic Data Generator
=================================================
Generate realistic AML transaction data for testing
with controllable anomaly injection.

Author: Project Vanguard Team
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Optional
import random
import string


def generate_customer_id(n: int = 1000) -> list:
    """Generate customer IDs."""
    return [f"CUST-{random.randint(10000, 99999)}" for _ in range(n)]


def generate_account_numbers(n: int = 1000) -> list:
    """Generate masked account numbers."""
    return [f"****{random.randint(1000, 9999)}" for _ in range(n)]


def generate_transaction_data(
    n_records: int = 10000,
    n_customers: int = 500,
    anomaly_rate: float = 0.05,
    start_date: Optional[datetime] = None,
    seed: int = 42
) -> pd.DataFrame:
    """
    Generate synthetic AML transaction data.
    
    Args:
        n_records: Number of transactions to generate
        n_customers: Number of unique customers
        anomaly_rate: Proportion of anomalous transactions
        start_date: Start date for transactions
        seed: Random seed for reproducibility
        
    Returns:
        DataFrame with synthetic transaction data
    """
    np.random.seed(seed)
    random.seed(seed)
    
    if start_date is None:
        start_date = datetime.now() - timedelta(days=365)
    
    # Customer pools
    customer_ids = generate_customer_id(n_customers)
    account_numbers = generate_account_numbers(n_customers)
    
    # Transaction types
    tx_types = ['WIRE_TRANSFER', 'ACH_DEBIT', 'ACH_CREDIT', 'CHECK_DEPOSIT', 
                'ATM_WITHDRAWAL', 'POS_PURCHASE', 'INTERNAL_TRANSFER', 'LOAN_PAYMENT']
    
    # Locations
    locations = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix',
                 'Philadelphia', 'San Antonio', 'San Diego', 'Dallas', 'Miami',
                 'Cayman Islands', 'Hong Kong', 'Switzerland', 'Panama', 'Cyprus']
    
    high_risk_locations = ['Cayman Islands', 'Hong Kong', 'Switzerland', 'Panama', 'Cyprus']
    
    # Generate base transactions
    records = []
    
    for i in range(n_records):
        customer_idx = np.random.randint(0, n_customers)
        
        # Determine if this is an anomaly
        is_anomaly = np.random.random() < anomaly_rate
        
        if is_anomaly:
            # Generate anomalous transaction
            anomaly_type = np.random.choice([
                'amount_spike', 'velocity_burst', 'unusual_location',
                'structuring', 'round_tripping'
            ])
            
            if anomaly_type == 'amount_spike':
                amount = np.random.uniform(50000, 500000)
                tx_type = np.random.choice(['WIRE_TRANSFER', 'ACH_CREDIT'])
                location = np.random.choice(locations)
            elif anomaly_type == 'velocity_burst':
                amount = np.random.uniform(5000, 9999)
                tx_type = np.random.choice(['ACH_DEBIT', 'INTERNAL_TRANSFER'])
                location = np.random.choice(locations[:10])
            elif anomaly_type == 'unusual_location':
                amount = np.random.uniform(1000, 50000)
                tx_type = np.random.choice(['WIRE_TRANSFER', 'ATM_WITHDRAWAL'])
                location = np.random.choice(high_risk_locations)
            elif anomaly_type == 'structuring':
                amount = np.random.uniform(9000, 9999)  # Just under $10k
                tx_type = np.random.choice(['CHECK_DEPOSIT', 'ATM_WITHDRAWAL'])
                location = np.random.choice(locations[:10])
            else:  # round_tripping
                amount = np.random.uniform(10000, 100000)
                tx_type = 'INTERNAL_TRANSFER'
                location = np.random.choice(high_risk_locations)
        else:
            # Generate normal transaction
            anomaly_type = 'normal'
            amount = np.abs(np.random.lognormal(mean=7, sigma=1))
            tx_type = np.random.choice(tx_types)
            location = np.random.choice(locations[:10])
        
        # Generate timestamp
        days_offset = np.random.randint(0, 365)
        hours_offset = np.random.randint(0, 24)
        minutes_offset = np.random.randint(0, 60)
        timestamp = start_date + timedelta(
            days=days_offset, 
            hours=hours_offset, 
            minutes=minutes_offset
        )
        
        records.append({
            'transaction_id': f"TXN-{i:08d}",
            'customer_id': customer_ids[customer_idx],
            'account_number': account_numbers[customer_idx],
            'timestamp': timestamp,
            'amount': round(amount, 2),
            'transaction_type': tx_type,
            'location': location,
            'is_international': location in high_risk_locations,
            'device_id': f"DEV-{np.random.randint(1000, 9999)}",
            'ip_address': f"{np.random.randint(1, 255)}.{np.random.randint(0, 255)}.{np.random.randint(0, 255)}.{np.random.randint(0, 255)}",
            'kyc_status': np.random.choice(['VERIFIED', 'PENDING', 'UNVERIFIED'], p=[0.85, 0.10, 0.05]),
            'risk_rating': np.random.choice(['LOW', 'MEDIUM', 'HIGH'], p=[0.70, 0.25, 0.05]),
            'anomaly_type_injected': anomaly_type,  # For validation only
            'is_anomaly_injected': is_anomaly,  # Ground truth for testing
        })
    
    df = pd.DataFrame(records)
    
    # Add derived features
    df['hour_of_day'] = df['timestamp'].dt.hour
    df['day_of_week'] = df['timestamp'].dt.dayofweek
    df['is_weekend'] = df['day_of_week'].isin([5, 6]).astype(int)
    df['is_night'] = df['hour_of_day'].apply(lambda x: 1 if x < 6 or x > 22 else 0)
    
    # Customer aggregates (velocity features)
    customer_stats = df.groupby('customer_id').agg({
        'amount': ['mean', 'std', 'count'],
        'is_international': 'sum'
    })
    customer_stats.columns = ['avg_amount', 'std_amount', 'tx_count', 'intl_tx_count']
    customer_stats = customer_stats.reset_index()
    
    df = df.merge(customer_stats, on='customer_id', how='left')
    
    # Amount deviation from customer average
    df['amount_deviation'] = (df['amount'] - df['avg_amount']) / (df['std_amount'] + 1)
    df['amount_deviation'] = df['amount_deviation'].fillna(0)
    
    # Risk score based on features
    df['velocity_risk'] = df['tx_count'] / df['tx_count'].max()
    df['amount_risk'] = df['amount'] / df['amount'].max()
    df['location_risk'] = df['is_international'].astype(float)
    
    return df


def save_sample_data(
    output_path: str = "sample_transactions.csv",
    n_records: int = 10000,
    anomaly_rate: float = 0.05
) -> str:
    """
    Generate and save sample transaction data.
    
    Args:
        output_path: Path to save CSV file
        n_records: Number of records
        anomaly_rate: Anomaly rate
        
    Returns:
        Path to saved file
    """
    df = generate_transaction_data(
        n_records=n_records,
        anomaly_rate=anomaly_rate
    )
    
    df.to_csv(output_path, index=False)
    print(f"Generated {len(df):,} records with {df['is_anomaly_injected'].sum():,} anomalies")
    print(f"Saved to {output_path}")
    
    return output_path


if __name__ == "__main__":
    save_sample_data()
