# FCDAI Anomaly Auto Detection Tool

**Mission-Critical AML Anomaly Detection Platform**

An elite, air-gapped, multipage AML anomaly detection platform featuring **20+ unsupervised algorithms**, SHAP explainability, industrial-grade UI, and forensic traceability.

---

## 🚀 Quick Start

```bash
# Option 1: Automated Setup (Windows)
setup.bat

# Option 2: Manual Install
pip install -r requirements.txt
python app.py

# Open: http://127.0.0.1:8070
```

---

## 🔒 Key Features

| Feature | Description |
|---------|-------------|
| **20+ Algorithms** | Isolation Forest, LOF, KNN, DBSCAN, COPOD, ECOD, HBOS, Autoencoder, SOM, Matrix Profile |
| **SHAP Explainability** | Feature contribution analysis for each alert |
| **Forensic Export** | Excel with metadata sidecars for compliance |
| **7-Page UI** | Command Center, Import, Pipeline, Vault, Diagnostics, Explainability, Health |
| **AG Grid** | Industrial data table with PII masking |
| **DMC UI** | Dash Mantine Components for enterprise aesthetics |
| **Diskcache** | Stateful persistence across reboots |
| **Parquet Vault** | Efficient storage for 1M+ rows |
| **Audit Logging** | Full action trail in `logs/admin_audit.log` |

---

## 📊 Pages (7 Total)

| Page | URL | Description |
|------|-----|-------------|
| **Command Center** | `/` | Executive KPIs, trend charts, risk distribution |
| **Data Import** | `/import` | Drag-drop CSV/Parquet/Excel upload |
| **Pipeline Control** | `/pipeline` | Run/Export/Reset anomaly detection |
| **Audit Vault** | `/audit-vault` | AG Grid with conditional formatting |
| **Model Diagnostics** | `/diagnostics` | PCA/t-SNE latent space, feature importance |
| **Explainability** | `/explainability` | SHAP-style feature contribution |
| **System Health** | `/system-health` | CPU/RAM gauges, audit logs |

---

## 📁 Project Structure

```
project_vanguard/
├── app.py                    # Main 7-page DMC application
├── config.py                 # Theme, Model, Path configs
├── pipeline.py               # 17-algorithm AnomalyEngine
├── requirements.txt          # Dependencies
├── setup.bat / run.bat       # Windows launchers
├── assets/styles.css         # Custom dark theme
├── cache/                    # Diskcache persistence
├── data/vault/               # Parquet storage
├── logs/                     # Audit and error logs
├── models/
│   ├── trained/              # Serialized model artifacts
│   └── neural_models.py      # Autoencoder, SOM, STL, Matrix Profile
├── pages/
│   ├── command_center.py     # Executive KPIs
│   ├── data_import.py        # File upload
│   ├── pipeline_control.py   # Run/Export/Reset
│   ├── audit_vault.py        # AG Grid data table
│   ├── model_diagnostics.py  # PCA/t-SNE visualization
│   ├── explainability.py     # SHAP analysis
│   └── system_health.py      # Admin dashboard
└── utils/
    ├── data_io.py            # Parquet import/export
    ├── logger.py             # Audit logging
    ├── pii_masking.py        # Privacy mode
    ├── explainability.py     # SHAP local explanations
    ├── forensic_export.py    # Excel export with metadata
    └── generate_data.py      # Synthetic data generator
```

---

## ⚙️ Algorithms (17+)

| Category | Algorithms |
|----------|------------|
| **Isolation** | IsolationForest, IForest (PyOD) |
| **Proximity** | LOF, KNN, COF |
| **Clustering** | DBSCAN, OPTICS, CBLOF |
| **Statistical** | EllipticEnvelope, COPOD, ECOD, HBOS, MCD |
| **SVM** | OneClassSVM, OCSVM |
| **Neural** | Autoencoder, SOM |
| **Time-Series** | STL, Matrix Profile |

---

## 📝 Standard Operating Procedure (SOP)

1. **Import Data**: Go to `/import`, drag CSV/Parquet/Excel onto upload area
2. **Run Pipeline**: Go to `/pipeline`, select algorithms, click "Execute"
3. **Review Anomalies**: Go to `/audit-vault`, filter by risk level
4. **Explain Alerts**: Go to `/explainability` for SHAP feature analysis
5. **Export Report**: Click "Export" on Pipeline page for Excel scorecard
6. **Monitor System**: Check `/system-health` for CPU/RAM and logs

---

## 🛡️ Air-Gapped Security

- `serve_locally=True` - All assets served locally
- No external CDN, fonts, or telemetry
- Server binds to `127.0.0.1` only
- PII masking toggle in UI
- Full audit trail logging

---

## 📄 License

Internal use only. For financial compliance purposes.
