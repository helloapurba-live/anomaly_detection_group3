"""
Command Center Page
===================
Executive dashboard with 7-layer KPIs and visualizations.
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from datetime import datetime
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP


dash.register_page(__name__, path="/", name="Command Center", order=0)


# =============================================================================
# KPI CARD
# =============================================================================
def create_kpi_card(title: str, value: str, icon: str, color: str) -> dmc.Paper:
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.ThemeIcon(
                        DashIconify(icon=icon, width=24),
                        size="xl",
                        radius="md",
                        variant="light",
                        color=color,
                    ),
                    dmc.Stack(
                        [
                            dmc.Text(title, size="sm", c="dimmed"),
                            dmc.Text(value, size="xl", fw=700),
                        ],
                        gap=2,
                    ),
                ],
                gap="md",
            ),
        ],
        p="md",
        radius="md",
        withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD}
    )


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Container(
    [
        # Header
        dmc.Group(
            [
                dmc.Title("Command Center", order=2),
                dmc.Badge("FCDAI 7-Layer", color="cyan", variant="light"),
            ],
            justify="space-between",
            mb="lg",
        ),
        
        # KPI Row
        html.Div(id="kpi-row-7layer"),
        
        dmc.Space(h="lg"),
        
        # Layer Status Grid
        dmc.Paper(
            [
                dmc.Text("Layer Execution Status", fw=600, mb="md"),
                dmc.SimpleGrid(
                    cols={"base": 2, "md": 4, "lg": 7},
                    spacing="md",
                    children=[
                        dmc.Paper(
                            [
                                dmc.Text("L1-2", fw=600, ta="center"),
                                dmc.Text("Ingest + DQ", size="xs", c="dimmed", ta="center"),
                                dmc.Center(
                                    dmc.ThemeIcon(
                                        DashIconify(icon="mdi:check-circle", width=20),
                                        color="green",
                                        variant="light",
                                        mt="xs",
                                    )
                                ),
                            ],
                            p="sm",
                            radius="md",
                            style={"backgroundColor": "rgba(0,100,0,0.1)"}
                        )
                        for layer in ["L1-2", "L3", "L4", "L5", "L6", "L7"]
                    ] + [
                        dmc.Paper(
                            [
                                dmc.Text(f"L{i}", fw=600, ta="center"),
                                dmc.Text(name, size="xs", c="dimmed", ta="center"),
                                dmc.Center(
                                    dmc.ThemeIcon(
                                        DashIconify(icon="mdi:clock-outline", width=20),
                                        color="gray",
                                        variant="light",
                                        mt="xs",
                                    )
                                ),
                            ],
                            p="sm",
                            radius="md",
                            style={"backgroundColor": "rgba(100,100,100,0.1)"}
                        )
                        for i, name in [(3, "Features"), (4, "Preproc"), (5, "Detect"), (6, "Ensemble"), (7, "Output")]
                    ]
                ),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
            mb="lg"
        ),
        
        # Charts Row
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2},
            spacing="lg",
            children=[
                dmc.Paper(
                    [
                        dmc.Text("Detection Methods by Category", fw=600, mb="sm"),
                        dcc.Graph(
                            id="chart-methods",
                            config=APP.PLOTLY_CONFIG,
                            style={"height": "300px"},
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Text("Risk Tier Distribution", fw=600, mb="sm"),
                        dcc.Graph(
                            id="chart-tiers",
                            config=APP.PLOTLY_CONFIG,
                            style={"height": "300px"},
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
            ],
        ),
        
        # Refresh interval
        dcc.Interval(id="interval-refresh-7layer", interval=60000, n_intervals=0),
    ],
    fluid=True,
)


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("kpi-row-7layer", "children"),
    Input("interval-refresh-7layer", "n_intervals"),
)
def update_kpis(n):
    """Update KPI cards."""
    return dmc.SimpleGrid(
        cols={"base": 2, "md": 4},
        spacing="lg",
        children=[
            create_kpi_card("Layers", "7", "mdi:layers-triple", "cyan"),
            create_kpi_card("Methods", "26", "mdi:chart-scatter-plot", "grape"),
            create_kpi_card("Categories", "8", "mdi:folder-multiple", "orange"),
            create_kpi_card("Queue", "0", "mdi:alert-circle", "red"),
        ],
    )


@callback(
    Output("chart-methods", "figure"),
    Input("interval-refresh-7layer", "n_intervals"),
)
def update_methods_chart(n):
    """Show detection methods by category."""
    data = {
        'Category': ['Statistical', 'Distance', 'Density', 'Clustering', 
                     'Trees', 'Time-Series', 'Graph', 'Deep Learning'],
        'Count': [5, 3, 4, 3, 2, 3, 4, 2]
    }
    
    fig = px.bar(
        data, x='Category', y='Count',
        template="plotly_dark",
        color='Category',
        color_discrete_sequence=px.colors.qualitative.Set2
    )
    
    fig.update_layout(
        margin=dict(l=20, r=20, t=20, b=20),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        showlegend=False,
        xaxis=dict(showgrid=False),
        yaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,0.1)"),
    )
    
    return fig


@callback(
    Output("chart-tiers", "figure"),
    Input("interval-refresh-7layer", "n_intervals"),
)
def update_tiers_chart(n):
    """Show risk tier distribution."""
    data = {
        'Tier': ['Critical', 'High', 'Medium', 'Low'],
        'Count': [15, 85, 200, 700]
    }
    
    colors = [THEME.DANGER, '#FF9800', THEME.WARNING, THEME.SUCCESS]
    
    fig = px.pie(
        data, values='Count', names='Tier',
        color='Tier',
        color_discrete_map={
            'Critical': THEME.DANGER,
            'High': '#FF9800',
            'Medium': THEME.WARNING,
            'Low': THEME.SUCCESS
        },
        hole=0.4,
        template="plotly_dark"
    )
    
    fig.update_layout(
        margin=dict(l=20, r=20, t=20, b=20),
        paper_bgcolor="rgba(0,0,0,0)",
        legend=dict(orientation="h", yanchor="bottom", y=-0.2),
    )
    
    return fig
