"""
Data Sources Page
=================
Multi-source data import matching the architecture diagram.
"""

import dash
from dash import html, dcc, callback, Input, Output, State
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import pandas as pd
import base64
import io
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS


dash.register_page(__name__, path="/sources", name="Data Sources", order=1)


def source_card(name: str, icon: str, expected: int, color: str) -> dmc.Paper:
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.ThemeIcon(
                        DashIconify(icon=icon, width=24),
                        size="xl",
                        radius="md",
                        color=color,
                        variant="light",
                    ),
                    dmc.Stack(
                        [
                            dmc.Text(name.upper(), fw=700),
                            dmc.Text(f"Expected: {expected} rows", size="sm", c="dimmed"),
                        ],
                        gap=2,
                    ),
                ],
                gap="md",
            ),
            dmc.Space(h="md"),
            dcc.Upload(
                id={'type': 'upload', 'source': name.lower()},
                children=dmc.Button(
                    "Upload File",
                    leftSection=DashIconify(icon="mdi:upload"),
                    variant="outline",
                    color=color,
                    fullWidth=True,
                ),
                multiple=False,
            ),
            html.Div(id={'type': 'upload-status', 'source': name.lower()}, style={"marginTop": "10px"}),
        ],
        p="lg",
        radius="md",
        withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD}
    )


layout = dmc.Container(
    [
        dmc.Group(
            [
                dmc.Title("Data Sources", order=2),
                dmc.Badge("Layer 1-2", color="cyan", variant="light"),
            ],
            justify="space-between",
            mb="lg",
        ),
        
        # Architecture diagram visualization
        dmc.Paper(
            [
                dmc.Text("Source Architecture", fw=600, mb="md"),
                dmc.Center(
                    html.Pre(
                        """
    ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
    │   KYC    │    │   TXN    │    │  ALERTS  │    │  CASES   │
    │ 100 rows │    │ 700 rows │    │  50 rows │    │ 20 rows  │
    └────┬─────┘    └────┬─────┘    └────┬─────┘    └────┬─────┘
         │               │               │               │
         └───────────────┴───────────────┴───────────────┘
                                 │
                                 ▼
                        ┌───────────────┐
                        │  LAYER 1 & 2  │
                        │  Ingest + DQ  │
                        └───────────────┘
                        """,
                        style={"color": THEME.PRIMARY, "fontSize": "12px"}
                    )
                ),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
            mb="lg"
        ),
        
        # Upload cards
        dmc.SimpleGrid(
            cols={"base": 1, "sm": 2, "lg": 4},
            spacing="lg",
            children=[
                source_card("KYC", "mdi:account-card", 100, "cyan"),
                source_card("Transactions", "mdi:bank-transfer", 700, "grape"),
                source_card("Alerts", "mdi:alert-circle", 50, "orange"),
                source_card("Cases", "mdi:briefcase", 20, "red"),
            ],
        ),
        
        dmc.Space(h="lg"),
        
        # Generate synthetic data button
        dmc.Paper(
            [
                dmc.Text("Quick Start", fw=600, mb="md"),
                dmc.Text("Don't have data? Generate synthetic multi-source data for testing.", c="dimmed", mb="md"),
                dmc.Button(
                    "Generate Sample Data",
                    id="btn-generate-sample",
                    leftSection=DashIconify(icon="mdi:database-plus"),
                    color="teal",
                    size="lg",
                ),
                html.Div(id="generate-status", style={"marginTop": "10px"}),
            ],
            p="lg",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),
    ],
    fluid=True,
)


@callback(
    Output("generate-status", "children"),
    Input("btn-generate-sample", "n_clicks"),
    prevent_initial_call=True,
)
def generate_sample_data(n_clicks):
    if not n_clicks:
        return ""
    
    try:
        from utils.generate_data import generate_multi_source_data
        
        sources = generate_multi_source_data()
        
        # Save to sources folder
        for name, df in sources.items():
            df.to_csv(PATHS.DATA_SOURCES / f"{name}.csv", index=False)
        
        return dmc.Alert(
            "Successfully generated 4 source files!",
            color="green",
            icon=DashIconify(icon="mdi:check-circle"),
        )
    except Exception as e:
        return dmc.Alert(
            f"Error: {str(e)}",
            color="red",
            icon=DashIconify(icon="mdi:alert"),
        )
