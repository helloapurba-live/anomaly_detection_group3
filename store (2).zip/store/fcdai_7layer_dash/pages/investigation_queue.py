"""
Investigation Queue Page
========================
Alert triage and investigation workflow.
"""

import dash
from dash import html, dcc, callback, Input, Output, State
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import pandas as pd
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS


dash.register_page(__name__, path="/queue", name="Investigation Queue", order=4)


def alert_card(alert_id: str, score: float, tier: str, narrative: str) -> dmc.Paper:
    tier_colors = {
        "Critical": "red",
        "High": "orange", 
        "Medium": "yellow",
        "Low": "green"
    }
    
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.Badge(tier, color=tier_colors.get(tier, "gray")),
                    dmc.Text(alert_id, fw=600),
                    dmc.Text(f"{score:.0%}", c="dimmed"),
                ],
                justify="space-between",
            ),
            dmc.Space(h="sm"),
            dmc.Text(narrative[:150] + "..." if len(narrative) > 150 else narrative, size="sm", c="dimmed"),
            dmc.Space(h="sm"),
            dmc.Group(
                [
                    dmc.Button("Review", size="xs", variant="subtle", color="cyan"),
                    dmc.Button("Escalate", size="xs", variant="subtle", color="orange"),
                    dmc.Button("Close", size="xs", variant="subtle", color="gray"),
                ],
                gap="xs",
            ),
        ],
        p="md",
        radius="md",
        withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD, "marginBottom": "8px"}
    )


layout = dmc.Container(
    [
        dmc.Group(
            [
                dmc.Title("Investigation Queue", order=2),
                dmc.Badge("Layer 7 Output", color="cyan", variant="light"),
            ],
            justify="space-between",
            mb="lg",
        ),
        
        # Filters
        dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Select(
                            id="filter-tier",
                            label="Risk Tier",
                            data=[
                                {"value": "all", "label": "All Tiers"},
                                {"value": "Critical", "label": "Critical"},
                                {"value": "High", "label": "High"},
                                {"value": "Medium", "label": "Medium"},
                                {"value": "Low", "label": "Low"},
                            ],
                            value="all",
                            w=150,
                        ),
                        dmc.Select(
                            id="filter-status",
                            label="Status",
                            data=[
                                {"value": "all", "label": "All"},
                                {"value": "Open", "label": "Open"},
                                {"value": "Closed", "label": "Closed"},
                                {"value": "Escalated", "label": "Escalated"},
                            ],
                            value="Open",
                            w=150,
                        ),
                        dmc.Button(
                            "Refresh",
                            id="btn-refresh-queue",
                            leftSection=DashIconify(icon="mdi:refresh"),
                            variant="subtle",
                            ml="auto",
                        ),
                    ],
                    gap="md",
                ),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
            mb="lg"
        ),
        
        # Queue stats
        dmc.SimpleGrid(
            cols=4,
            spacing="md",
            mb="lg",
            children=[
                dmc.Paper(
                    [
                        dmc.Text("Total Alerts", c="dimmed", size="sm"),
                        dmc.Text("0", fw=700, size="xl", id="stat-total"),
                    ],
                    p="md",
                    ta="center",
                    radius="md",
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Text("Critical", c="dimmed", size="sm"),
                        dmc.Text("0", fw=700, size="xl", c="red", id="stat-critical"),
                    ],
                    p="md",
                    ta="center",
                    radius="md",
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Text("High", c="dimmed", size="sm"),
                        dmc.Text("0", fw=700, size="xl", c="orange", id="stat-high"),
                    ],
                    p="md",
                    ta="center",
                    radius="md",
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Text("Pending Review", c="dimmed", size="sm"),
                        dmc.Text("0", fw=700, size="xl", c="cyan", id="stat-pending"),
                    ],
                    p="md",
                    ta="center",
                    radius="md",
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
            ],
        ),
        
        # Alert list
        html.Div(id="alert-list"),
    ],
    fluid=True,
)


@callback(
    [Output("alert-list", "children"),
     Output("stat-total", "children"),
     Output("stat-critical", "children"),
     Output("stat-high", "children"),
     Output("stat-pending", "children")],
    [Input("btn-refresh-queue", "n_clicks"),
     Input("filter-tier", "value"),
     Input("filter-status", "value")],
)
def update_queue(n_clicks, tier_filter, status_filter):
    # Generate sample alerts for display
    sample_alerts = [
        {"id": "ALT-000001", "score": 0.95, "tier": "Critical", 
         "narrative": "🚨 CRITICAL ALERT: This transaction shows extreme deviation. Multiple detection methods flagged unusual patterns."},
        {"id": "ALT-000002", "score": 0.87, "tier": "High",
         "narrative": "⚠️ HIGH RISK: Large value transfer to high-risk jurisdiction with velocity anomaly detected."},
        {"id": "ALT-000003", "score": 0.72, "tier": "High",
         "narrative": "⚠️ HIGH RISK: New account with unusual transaction pattern detected by clustering algorithms."},
        {"id": "ALT-000004", "score": 0.58, "tier": "Medium",
         "narrative": "📊 MEDIUM RISK: Some unusual patterns detected by statistical methods."},
        {"id": "ALT-000005", "score": 0.45, "tier": "Low",
         "narrative": "ℹ️ LOW RISK: Minor deviations observed in time-series analysis."},
    ]
    
    # Filter
    if tier_filter != "all":
        sample_alerts = [a for a in sample_alerts if a["tier"] == tier_filter]
    
    cards = [
        alert_card(a["id"], a["score"], a["tier"], a["narrative"])
        for a in sample_alerts
    ]
    
    if not cards:
        cards = [dmc.Text("No alerts match the current filters.", c="dimmed", ta="center")]
    
    # Stats
    total = len(sample_alerts)
    critical = sum(1 for a in sample_alerts if a["tier"] == "Critical")
    high = sum(1 for a in sample_alerts if a["tier"] == "High")
    
    return cards, str(total), str(critical), str(high), str(total)
