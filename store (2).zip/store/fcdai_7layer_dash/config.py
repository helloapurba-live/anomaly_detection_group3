"""
Project Vanguard 7-Layer Edition - Configuration
=================================================
Centralized configuration for the 7-layer AML pipeline.

Author: Project Vanguard Team
"""

from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict


# =============================================================================
# PATH CONFIGURATION
# =============================================================================
BASE_DIR = Path(__file__).parent

@dataclass
class PathConfig:
    """File system paths."""
    BASE: Path = BASE_DIR
    DATA: Path = BASE_DIR / "data"
    DATA_VAULT: Path = BASE_DIR / "data" / "vault"
    DATA_SOURCES: Path = BASE_DIR / "data" / "sources"
    EXPORTS: Path = BASE_DIR / "data" / "exports"
    MODELS: Path = BASE_DIR / "models"
    LOGS: Path = BASE_DIR / "logs"
    CACHE: Path = BASE_DIR / "cache"
    ASSETS: Path = BASE_DIR / "assets"
    
    def __post_init__(self):
        """Create directories if they don't exist."""
        for path in [self.DATA_VAULT, self.DATA_SOURCES, self.EXPORTS, 
                     self.MODELS, self.LOGS, self.CACHE, self.ASSETS]:
            path.mkdir(parents=True, exist_ok=True)


# =============================================================================
# THEME CONFIGURATION
# =============================================================================
@dataclass
class ThemeConfig:
    """UI theme colors and styles."""
    PRIMARY: str = "#00D4FF"
    SECONDARY: str = "#9D4EDD"
    SUCCESS: str = "#00E676"
    WARNING: str = "#FFD600"
    DANGER: str = "#FF1744"
    INFO: str = "#2196F3"
    DARK_BG: str = "#0D1117"
    DARK_BG_CARD: str = "#161B22"
    DARK_BORDER: str = "#30363D"


# =============================================================================
# LAYER CONFIGURATION
# =============================================================================
@dataclass
class LayerConfig:
    """7-Layer pipeline configuration."""
    
    # Layer 1-2: Ingestion & Data Quality
    DQ_THRESHOLDS: Dict[str, float] = field(default_factory=lambda: {
        "completeness": 0.95,
        "consistency": 0.90,
        "validity": 0.85
    })
    
    # Layer 3: Feature Engineering
    FEATURE_CATEGORIES: List[str] = field(default_factory=lambda: [
        "velocity", "aggregates", "ratios", "flags", "temporal", "behavioral"
    ])
    
    # Layer 4: Preprocessing
    MATRIX_VERSIONS: List[str] = field(default_factory=lambda: [
        "raw", "scaled", "pca", "encoded"
    ])
    
    # Layer 5: Detection Methods (26 total)
    DETECTION_METHODS: Dict[str, List[str]] = field(default_factory=lambda: {
        "statistical": ["zscore", "iqr", "grubbs", "dixon", "esd"],
        "distance": ["knn", "mahalanobis", "lof"],
        "density": ["dbscan", "optics", "hdbscan", "cblof"],
        "clustering": ["kmeans_anomaly", "gmm", "spectral"],
        "trees": ["isolation_forest", "extended_if"],
        "timeseries": ["stl", "arima_residual", "prophet"],
        "graph": ["pagerank", "hits", "community", "centrality"],
        "deep_learning": ["autoencoder", "vae"]
    })
    
    # Layer 6: Ensemble
    ENSEMBLE_METHOD: str = "weighted_average"
    RISK_TIERS: Dict[str, tuple] = field(default_factory=lambda: {
        "Critical": (0.9, 1.0),
        "High": (0.7, 0.9),
        "Medium": (0.5, 0.7),
        "Low": (0.0, 0.5)
    })
    
    # Layer 7: Output
    INVESTIGATION_CAPACITY: int = 1000


# =============================================================================
# APPLICATION CONFIGURATION
# =============================================================================
@dataclass 
class AppConfig:
    """Application settings."""
    TITLE: str = "FCDAI Anomaly Auto Detection Tool"
    VERSION: str = "2.0.0"
    HOST: str = "127.0.0.1"
    PORT: int = 8071
    DEBUG: bool = False
    SERVE_LOCALLY: bool = True
    
    PLOTLY_CONFIG: Dict = field(default_factory=lambda: {
        "displaylogo": False,
        "modeBarButtonsToRemove": ["sendDataToCloud", "lasso2d", "select2d"],
        "toImageButtonOptions": {"format": "png", "scale": 2}
    })


# =============================================================================
# DATA SOURCES CONFIGURATION
# =============================================================================
@dataclass
class DataSourceConfig:
    """Multi-source data configuration."""
    SOURCES: Dict[str, Dict] = field(default_factory=lambda: {
        "kyc": {"expected_rows": 100, "key_column": "customer_id"},
        "transactions": {"expected_rows": 700, "key_column": "txn_id"},
        "alerts": {"expected_rows": 50, "key_column": "alert_id"},
        "cases": {"expected_rows": 20, "key_column": "case_id"}
    })


# =============================================================================
# INSTANTIATE CONFIGS
# =============================================================================
PATHS = PathConfig()
THEME = ThemeConfig()
LAYERS = LayerConfig()
APP = AppConfig()
DATA_SOURCES = DataSourceConfig()
