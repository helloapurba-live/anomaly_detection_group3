"""
Layer 5: Detection Methods
==========================
26 anomaly detection algorithms across 8 categories.

Categories:
- Statistical (5): zscore, iqr, grubbs, dixon, esd
- Distance (3): knn, mahalanobis, lof
- Density (4): dbscan, optics, hdbscan, cblof
- Clustering (3): kmeans_anomaly, gmm, spectral
- Trees (2): isolation_forest, extended_if
- Time-Series (3): stl, arima_residual, prophet
- Graph (4): pagerank, hits, community, centrality
- Deep Learning (2): autoencoder, vae
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from pathlib import Path
from dataclasses import dataclass
from abc import ABC, abstractmethod
import warnings
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import LAYERS

warnings.filterwarnings('ignore')


@dataclass
class DetectionResult:
    """Result from a detection method."""
    method_name: str
    category: str
    scores: np.ndarray
    labels: np.ndarray  # Binary: 1 = anomaly, 0 = normal
    threshold: float


# =============================================================================
# BASE DETECTOR
# =============================================================================
class BaseDetector(ABC):
    """Abstract base for all detectors."""
    
    def __init__(self, contamination: float = 0.05):
        self.contamination = contamination
        self.is_fitted = False
    
    @abstractmethod
    def fit(self, X: np.ndarray):
        """Fit the detector."""
        pass
    
    @abstractmethod
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict anomaly scores."""
        pass
    
    def fit_predict(self, X: np.ndarray) -> np.ndarray:
        """Fit and predict."""
        self.fit(X)
        return self.predict(X)


# =============================================================================
# STATISTICAL DETECTORS (5)
# =============================================================================
class ZScoreDetector(BaseDetector):
    """Z-score based anomaly detection."""
    
    def __init__(self, threshold: float = 3.0, **kwargs):
        super().__init__(**kwargs)
        self.threshold = threshold
        self.mean = None
        self.std = None
    
    def fit(self, X: np.ndarray):
        self.mean = np.mean(X, axis=0)
        self.std = np.std(X, axis=0) + 1e-8
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        z_scores = np.abs((X - self.mean) / self.std)
        scores = np.max(z_scores, axis=1)
        return scores / (self.threshold * 2)  # Normalize to ~[0,1]


class IQRDetector(BaseDetector):
    """Interquartile Range detector."""
    
    def __init__(self, multiplier: float = 1.5, **kwargs):
        super().__init__(**kwargs)
        self.multiplier = multiplier
        self.q1 = None
        self.q3 = None
        self.iqr = None
    
    def fit(self, X: np.ndarray):
        self.q1 = np.percentile(X, 25, axis=0)
        self.q3 = np.percentile(X, 75, axis=0)
        self.iqr = self.q3 - self.q1 + 1e-8
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        lower = self.q1 - self.multiplier * self.iqr
        upper = self.q3 + self.multiplier * self.iqr
        below = np.maximum(0, lower - X) / self.iqr
        above = np.maximum(0, X - upper) / self.iqr
        scores = np.max(below + above, axis=1)
        return np.clip(scores, 0, 1)


class GrubbsDetector(BaseDetector):
    """Grubbs test for outliers."""
    
    def fit(self, X: np.ndarray):
        self.mean = np.mean(X, axis=0)
        self.std = np.std(X, axis=0) + 1e-8
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        G = np.abs(X - self.mean) / self.std
        scores = np.max(G, axis=1)
        return np.clip(scores / 4, 0, 1)


class DixonDetector(BaseDetector):
    """Dixon's Q test inspired detector."""
    
    def fit(self, X: np.ndarray):
        self.sorted_X = np.sort(X, axis=0)
        self.range = np.ptp(X, axis=0) + 1e-8
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        # Distance from nearest sorted value
        diffs = np.abs(X[:, np.newaxis, :] - self.sorted_X[np.newaxis, :, :])
        min_diffs = np.min(diffs, axis=1)
        scores = np.max(min_diffs / self.range, axis=1)
        return np.clip(scores, 0, 1)


class ESDDetector(BaseDetector):
    """Extreme Studentized Deviate inspired detector."""
    
    def fit(self, X: np.ndarray):
        self.mean = np.mean(X, axis=0)
        self.std = np.std(X, axis=0) + 1e-8
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        esd = np.abs(X - self.mean) / self.std
        scores = np.max(esd, axis=1)
        return np.clip(scores / 4, 0, 1)


# =============================================================================
# DISTANCE DETECTORS (3)
# =============================================================================
class KNNDetector(BaseDetector):
    """K-Nearest Neighbors distance based detector."""
    
    def __init__(self, n_neighbors: int = 5, **kwargs):
        super().__init__(**kwargs)
        self.n_neighbors = n_neighbors
        self.X_train = None
    
    def fit(self, X: np.ndarray):
        self.X_train = X
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        from scipy.spatial.distance import cdist
        distances = cdist(X, self.X_train)
        k = min(self.n_neighbors, distances.shape[1])
        knn_dist = np.partition(distances, k, axis=1)[:, :k].mean(axis=1)
        return self._normalize(knn_dist)
    
    def _normalize(self, scores: np.ndarray) -> np.ndarray:
        min_s, max_s = scores.min(), scores.max()
        if max_s - min_s < 1e-8:
            return np.zeros_like(scores)
        return (scores - min_s) / (max_s - min_s)


class MahalanobisDetector(BaseDetector):
    """Mahalanobis distance detector."""
    
    def fit(self, X: np.ndarray):
        self.mean = np.mean(X, axis=0)
        cov = np.cov(X.T) + np.eye(X.shape[1]) * 1e-6
        try:
            self.inv_cov = np.linalg.inv(cov)
        except:
            self.inv_cov = np.eye(X.shape[1])
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        diff = X - self.mean
        left = np.dot(diff, self.inv_cov)
        mahal = np.sqrt(np.sum(left * diff, axis=1))
        return np.clip(mahal / np.percentile(mahal, 99), 0, 1)


class LOFDetector(BaseDetector):
    """Local Outlier Factor detector."""
    
    def __init__(self, n_neighbors: int = 20, **kwargs):
        super().__init__(**kwargs)
        self.n_neighbors = n_neighbors
        self.model = None
    
    def fit(self, X: np.ndarray):
        try:
            from sklearn.neighbors import LocalOutlierFactor
            self.model = LocalOutlierFactor(
                n_neighbors=min(self.n_neighbors, len(X) - 1),
                contamination=self.contamination,
                novelty=False
            )
            self._scores = -self.model.fit_predict(X)
            self._scores = (self._scores + 1) / 2  # Map to [0, 1]
        except:
            self._scores = np.zeros(len(X))
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        return self._scores


# =============================================================================
# DENSITY DETECTORS (4)
# =============================================================================
class DBSCANDetector(BaseDetector):
    """DBSCAN-based anomaly detector."""
    
    def __init__(self, eps: float = 0.5, min_samples: int = 5, **kwargs):
        super().__init__(**kwargs)
        self.eps = eps
        self.min_samples = min_samples
    
    def fit(self, X: np.ndarray):
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        try:
            from sklearn.cluster import DBSCAN
            model = DBSCAN(eps=self.eps, min_samples=self.min_samples)
            labels = model.fit_predict(X)
            # Noise points (-1) are anomalies
            scores = (labels == -1).astype(float)
        except:
            scores = np.zeros(len(X))
        return scores


class OPTICSDetector(BaseDetector):
    """OPTICS clustering based detector."""
    
    def __init__(self, min_samples: int = 5, **kwargs):
        super().__init__(**kwargs)
        self.min_samples = min_samples
    
    def fit(self, X: np.ndarray):
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        try:
            from sklearn.cluster import OPTICS
            model = OPTICS(min_samples=min(self.min_samples, len(X) // 2))
            labels = model.fit_predict(X)
            scores = (labels == -1).astype(float)
        except:
            scores = np.zeros(len(X))
        return scores


class HDBSCANDetector(BaseDetector):
    """HDBSCAN-based detector (fallback to DBSCAN if not available)."""
    
    def __init__(self, min_cluster_size: int = 5, **kwargs):
        super().__init__(**kwargs)
        self.min_cluster_size = min_cluster_size
    
    def fit(self, X: np.ndarray):
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        try:
            import hdbscan
            model = hdbscan.HDBSCAN(min_cluster_size=self.min_cluster_size)
            model.fit(X)
            scores = (model.labels_ == -1).astype(float)
        except ImportError:
            # Fallback to DBSCAN
            from sklearn.cluster import DBSCAN
            model = DBSCAN(min_samples=self.min_cluster_size)
            labels = model.fit_predict(X)
            scores = (labels == -1).astype(float)
        return scores


class CBLOFDetector(BaseDetector):
    """Cluster-Based Local Outlier Factor."""
    
    def __init__(self, n_clusters: int = 8, **kwargs):
        super().__init__(**kwargs)
        self.n_clusters = n_clusters
    
    def fit(self, X: np.ndarray):
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        try:
            from pyod.models.cblof import CBLOF
            model = CBLOF(n_clusters=min(self.n_clusters, len(X) // 5 + 1),
                          contamination=self.contamination)
            model.fit(X)
            scores = model.decision_scores_
            return self._normalize(scores)
        except:
            return np.zeros(len(X))
    
    def _normalize(self, scores: np.ndarray) -> np.ndarray:
        min_s, max_s = scores.min(), scores.max()
        if max_s - min_s < 1e-8:
            return np.zeros_like(scores)
        return (scores - min_s) / (max_s - min_s)


# =============================================================================
# CLUSTERING DETECTORS (3)
# =============================================================================
class KMeansAnomalyDetector(BaseDetector):
    """K-Means distance to centroid detector."""
    
    def __init__(self, n_clusters: int = 8, **kwargs):
        super().__init__(**kwargs)
        self.n_clusters = n_clusters
    
    def fit(self, X: np.ndarray):
        from sklearn.cluster import KMeans
        self.model = KMeans(n_clusters=min(self.n_clusters, len(X) // 2 + 1), n_init=10)
        self.model.fit(X)
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        distances = self.model.transform(X).min(axis=1)
        return self._normalize(distances)
    
    def _normalize(self, scores: np.ndarray) -> np.ndarray:
        min_s, max_s = scores.min(), scores.max()
        if max_s - min_s < 1e-8:
            return np.zeros_like(scores)
        return (scores - min_s) / (max_s - min_s)


class GMMDetector(BaseDetector):
    """Gaussian Mixture Model based detector."""
    
    def __init__(self, n_components: int = 5, **kwargs):
        super().__init__(**kwargs)
        self.n_components = n_components
    
    def fit(self, X: np.ndarray):
        from sklearn.mixture import GaussianMixture
        self.model = GaussianMixture(
            n_components=min(self.n_components, len(X) // 3 + 1),
            covariance_type='full'
        )
        self.model.fit(X)
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        log_prob = self.model.score_samples(X)
        scores = -log_prob  # Lower probability = more anomalous
        return self._normalize(scores)
    
    def _normalize(self, scores: np.ndarray) -> np.ndarray:
        min_s, max_s = scores.min(), scores.max()
        if max_s - min_s < 1e-8:
            return np.zeros_like(scores)
        return (scores - min_s) / (max_s - min_s)


class SpectralDetector(BaseDetector):
    """Spectral embedding + distance detector."""
    
    def __init__(self, n_components: int = 5, **kwargs):
        super().__init__(**kwargs)
        self.n_components = n_components
    
    def fit(self, X: np.ndarray):
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        try:
            from sklearn.manifold import SpectralEmbedding
            n_comp = min(self.n_components, X.shape[1], len(X) - 2)
            if n_comp < 1:
                return np.zeros(len(X))
            se = SpectralEmbedding(n_components=n_comp)
            embedded = se.fit_transform(X)
            center = embedded.mean(axis=0)
            distances = np.linalg.norm(embedded - center, axis=1)
            return self._normalize(distances)
        except:
            return np.zeros(len(X))
    
    def _normalize(self, scores: np.ndarray) -> np.ndarray:
        min_s, max_s = scores.min(), scores.max()
        if max_s - min_s < 1e-8:
            return np.zeros_like(scores)
        return (scores - min_s) / (max_s - min_s)


# =============================================================================
# TREE DETECTORS (2)
# =============================================================================
class IsolationForestDetector(BaseDetector):
    """Isolation Forest detector."""
    
    def __init__(self, n_estimators: int = 100, **kwargs):
        super().__init__(**kwargs)
        self.n_estimators = n_estimators
    
    def fit(self, X: np.ndarray):
        from sklearn.ensemble import IsolationForest
        self.model = IsolationForest(
            n_estimators=self.n_estimators,
            contamination=self.contamination,
            random_state=42
        )
        self.model.fit(X)
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        scores = -self.model.score_samples(X)
        return self._normalize(scores)
    
    def _normalize(self, scores: np.ndarray) -> np.ndarray:
        min_s, max_s = scores.min(), scores.max()
        if max_s - min_s < 1e-8:
            return np.zeros_like(scores)
        return (scores - min_s) / (max_s - min_s)


class ExtendedIFDetector(BaseDetector):
    """Extended Isolation Forest (uses PyOD if available)."""
    
    def __init__(self, n_estimators: int = 100, **kwargs):
        super().__init__(**kwargs)
        self.n_estimators = n_estimators
    
    def fit(self, X: np.ndarray):
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        try:
            from pyod.models.iforest import IForest
            model = IForest(n_estimators=self.n_estimators,
                           contamination=self.contamination)
            model.fit(X)
            return self._normalize(model.decision_scores_)
        except:
            # Fallback to regular IF
            from sklearn.ensemble import IsolationForest
            model = IsolationForest(n_estimators=self.n_estimators,
                                    contamination=self.contamination)
            model.fit(X)
            return self._normalize(-model.score_samples(X))
    
    def _normalize(self, scores: np.ndarray) -> np.ndarray:
        min_s, max_s = scores.min(), scores.max()
        if max_s - min_s < 1e-8:
            return np.zeros_like(scores)
        return (scores - min_s) / (max_s - min_s)


# =============================================================================
# TIME-SERIES DETECTORS (3)
# =============================================================================
class STLDetector(BaseDetector):
    """STL decomposition residual detector."""
    
    def fit(self, X: np.ndarray):
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        # Treat each feature as time series
        scores = np.zeros(len(X))
        for col in range(X.shape[1]):
            series = X[:, col]
            if len(series) < 10:
                continue
            # Simple moving average residual
            window = min(7, len(series) // 3)
            if window < 2:
                continue
            ma = np.convolve(series, np.ones(window)/window, mode='same')
            residual = np.abs(series - ma)
            scores += residual
        return self._normalize(scores)
    
    def _normalize(self, scores: np.ndarray) -> np.ndarray:
        min_s, max_s = scores.min(), scores.max()
        if max_s - min_s < 1e-8:
            return np.zeros_like(scores)
        return (scores - min_s) / (max_s - min_s)


class ARIMAResidualDetector(BaseDetector):
    """ARIMA residual based detector (simplified)."""
    
    def fit(self, X: np.ndarray):
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        scores = np.zeros(len(X))
        for col in range(X.shape[1]):
            series = X[:, col]
            # Simplified: use diff as proxy for ARIMA residual
            diff = np.diff(series, prepend=series[0])
            scores += np.abs(diff)
        return self._normalize(scores)
    
    def _normalize(self, scores: np.ndarray) -> np.ndarray:
        min_s, max_s = scores.min(), scores.max()
        if max_s - min_s < 1e-8:
            return np.zeros_like(scores)
        return (scores - min_s) / (max_s - min_s)


class ProphetDetector(BaseDetector):
    """Prophet-inspired detector (simplified without fbprophet)."""
    
    def fit(self, X: np.ndarray):
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        # Simplified trend + seasonality decomposition
        scores = np.zeros(len(X))
        n = len(X)
        for col in range(X.shape[1]):
            series = X[:, col]
            # Trend: linear regression
            x = np.arange(n)
            if np.std(series) < 1e-8:
                continue
            m = np.polyfit(x, series, 1)
            trend = np.polyval(m, x)
            detrended = series - trend
            scores += np.abs(detrended)
        return self._normalize(scores)
    
    def _normalize(self, scores: np.ndarray) -> np.ndarray:
        min_s, max_s = scores.min(), scores.max()
        if max_s - min_s < 1e-8:
            return np.zeros_like(scores)
        return (scores - min_s) / (max_s - min_s)


# =============================================================================
# GRAPH DETECTORS (4)
# =============================================================================
class PageRankDetector(BaseDetector):
    """PageRank-based anomaly detection (simplified)."""
    
    def fit(self, X: np.ndarray):
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        # Build affinity matrix and compute simplified PageRank
        try:
            from scipy.spatial.distance import pdist, squareform
            dist = squareform(pdist(X))
            # Convert distance to similarity
            sim = 1 / (1 + dist)
            np.fill_diagonal(sim, 0)
            
            # Normalize as transition probability
            row_sum = sim.sum(axis=1, keepdims=True) + 1e-8
            P = sim / row_sum
            
            # Power iteration for PageRank
            n = len(X)
            pr = np.ones(n) / n
            damping = 0.85
            for _ in range(20):
                pr = damping * P.T @ pr + (1 - damping) / n
            
            # Low PageRank = anomaly
            scores = 1 - self._normalize(pr)
            return scores
        except:
            return np.zeros(len(X))
    
    def _normalize(self, scores: np.ndarray) -> np.ndarray:
        min_s, max_s = scores.min(), scores.max()
        if max_s - min_s < 1e-8:
            return np.zeros_like(scores)
        return (scores - min_s) / (max_s - min_s)


class HITSDetector(BaseDetector):
    """HITS algorithm based detector."""
    
    def fit(self, X: np.ndarray):
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        try:
            from scipy.spatial.distance import pdist, squareform
            dist = squareform(pdist(X))
            sim = 1 / (1 + dist)
            np.fill_diagonal(sim, 0)
            
            n = len(X)
            h = np.ones(n) / n  # Hub scores
            a = np.ones(n) / n  # Authority scores
            
            for _ in range(20):
                a = sim.T @ h
                a = a / (np.linalg.norm(a) + 1e-8)
                h = sim @ a
                h = h / (np.linalg.norm(h) + 1e-8)
            
            # Low authority = anomaly
            scores = 1 - self._normalize(a)
            return scores
        except:
            return np.zeros(len(X))
    
    def _normalize(self, scores: np.ndarray) -> np.ndarray:
        min_s, max_s = scores.min(), scores.max()
        if max_s - min_s < 1e-8:
            return np.zeros_like(scores)
        return (scores - min_s) / (max_s - min_s)


class CommunityDetector(BaseDetector):
    """Community detection based anomaly scoring."""
    
    def fit(self, X: np.ndarray):
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        # K-means as proxy for community
        from sklearn.cluster import KMeans
        n_clusters = min(5, len(X) // 5 + 1)
        km = KMeans(n_clusters=n_clusters, n_init=10)
        labels = km.fit_predict(X)
        
        # Small community = anomalous
        community_sizes = np.bincount(labels)
        sizes = community_sizes[labels]
        scores = 1 - self._normalize(sizes.astype(float))
        return scores
    
    def _normalize(self, scores: np.ndarray) -> np.ndarray:
        min_s, max_s = scores.min(), scores.max()
        if max_s - min_s < 1e-8:
            return np.zeros_like(scores)
        return (scores - min_s) / (max_s - min_s)


class CentralityDetector(BaseDetector):
    """Centrality-based anomaly detection."""
    
    def fit(self, X: np.ndarray):
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        try:
            from scipy.spatial.distance import pdist, squareform
            dist = squareform(pdist(X))
            # Closeness centrality: inverse of average distance
            avg_dist = dist.mean(axis=1)
            centrality = 1 / (avg_dist + 1e-8)
            
            # Low centrality = anomaly
            scores = 1 - self._normalize(centrality)
            return scores
        except:
            return np.zeros(len(X))
    
    def _normalize(self, scores: np.ndarray) -> np.ndarray:
        min_s, max_s = scores.min(), scores.max()
        if max_s - min_s < 1e-8:
            return np.zeros_like(scores)
        return (scores - min_s) / (max_s - min_s)


# =============================================================================
# DEEP LEARNING DETECTORS (2)
# =============================================================================
class AutoencoderDetector(BaseDetector):
    """Shallow autoencoder using numpy (no TensorFlow)."""
    
    def __init__(self, encoding_dim: int = 8, epochs: int = 50, **kwargs):
        super().__init__(**kwargs)
        self.encoding_dim = encoding_dim
        self.epochs = epochs
        self.W1 = None
        self.W2 = None
    
    def fit(self, X: np.ndarray):
        n_features = X.shape[1]
        hidden = min(self.encoding_dim, n_features)
        
        # Initialize weights
        self.W1 = np.random.randn(n_features, hidden) * 0.1
        self.W2 = np.random.randn(hidden, n_features) * 0.1
        
        lr = 0.01
        for _ in range(self.epochs):
            # Forward
            H = np.tanh(X @ self.W1)
            X_recon = H @ self.W2
            
            # Backward
            error = X_recon - X
            dW2 = H.T @ error / len(X)
            dH = error @ self.W2.T
            dW1 = X.T @ (dH * (1 - H**2)) / len(X)
            
            self.W1 -= lr * dW1
            self.W2 -= lr * dW2
        
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        H = np.tanh(X @ self.W1)
        X_recon = H @ self.W2
        mse = np.mean((X - X_recon) ** 2, axis=1)
        return self._normalize(mse)
    
    def _normalize(self, scores: np.ndarray) -> np.ndarray:
        min_s, max_s = scores.min(), scores.max()
        if max_s - min_s < 1e-8:
            return np.zeros_like(scores)
        return (scores - min_s) / (max_s - min_s)


class VAEDetector(BaseDetector):
    """Variational Autoencoder (simplified numpy version)."""
    
    def __init__(self, latent_dim: int = 4, epochs: int = 50, **kwargs):
        super().__init__(**kwargs)
        self.latent_dim = latent_dim
        self.epochs = epochs
    
    def fit(self, X: np.ndarray):
        n_features = X.shape[1]
        latent = min(self.latent_dim, n_features)
        
        # Encoder weights
        self.W_enc = np.random.randn(n_features, latent) * 0.1
        self.W_mu = np.random.randn(latent, latent) * 0.1
        
        # Decoder weights
        self.W_dec = np.random.randn(latent, n_features) * 0.1
        
        lr = 0.01
        for _ in range(self.epochs):
            # Encode
            h = np.tanh(X @ self.W_enc)
            z = h @ self.W_mu
            
            # Decode
            X_recon = z @ self.W_dec
            
            # Update
            error = X_recon - X
            self.W_dec -= lr * (z.T @ error) / len(X)
        
        self.is_fitted = True
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        h = np.tanh(X @ self.W_enc)
        z = h @ self.W_mu
        X_recon = z @ self.W_dec
        mse = np.mean((X - X_recon) ** 2, axis=1)
        return self._normalize(mse)
    
    def _normalize(self, scores: np.ndarray) -> np.ndarray:
        min_s, max_s = scores.min(), scores.max()
        if max_s - min_s < 1e-8:
            return np.zeros_like(scores)
        return (scores - min_s) / (max_s - min_s)


# =============================================================================
# LAYER 5 ORCHESTRATOR
# =============================================================================
class Layer5Detection:
    """
    Layer 5: Orchestrate all 26 detection methods.
    """
    
    DETECTOR_MAP = {
        # Statistical (5)
        "zscore": ZScoreDetector,
        "iqr": IQRDetector,
        "grubbs": GrubbsDetector,
        "dixon": DixonDetector,
        "esd": ESDDetector,
        # Distance (3)
        "knn": KNNDetector,
        "mahalanobis": MahalanobisDetector,
        "lof": LOFDetector,
        # Density (4)
        "dbscan": DBSCANDetector,
        "optics": OPTICSDetector,
        "hdbscan": HDBSCANDetector,
        "cblof": CBLOFDetector,
        # Clustering (3)
        "kmeans_anomaly": KMeansAnomalyDetector,
        "gmm": GMMDetector,
        "spectral": SpectralDetector,
        # Trees (2)
        "isolation_forest": IsolationForestDetector,
        "extended_if": ExtendedIFDetector,
        # Time-Series (3)
        "stl": STLDetector,
        "arima_residual": ARIMAResidualDetector,
        "prophet": ProphetDetector,
        # Graph (4)
        "pagerank": PageRankDetector,
        "hits": HITSDetector,
        "community": CommunityDetector,
        "centrality": CentralityDetector,
        # Deep Learning (2)
        "autoencoder": AutoencoderDetector,
        "vae": VAEDetector,
    }
    
    def __init__(self, contamination: float = 0.05):
        self.contamination = contamination
        self.results: Dict[str, DetectionResult] = {}
    
    def detect_all(
        self, 
        X: np.ndarray,
        methods: List[str] = None,
        threshold: float = 0.5
    ) -> Dict[str, DetectionResult]:
        """
        Run all detection methods.
        
        Args:
            X: Input matrix
            methods: List of method names (None = all)
            threshold: Score threshold for labeling
            
        Returns:
            Dict of method_name -> DetectionResult
        """
        if methods is None:
            methods = list(self.DETECTOR_MAP.keys())
        
        for method_name in methods:
            if method_name not in self.DETECTOR_MAP:
                continue
            
            try:
                detector_class = self.DETECTOR_MAP[method_name]
                detector = detector_class(contamination=self.contamination)
                scores = detector.fit_predict(X)
                labels = (scores > threshold).astype(int)
                
                # Determine category
                category = self._get_category(method_name)
                
                self.results[method_name] = DetectionResult(
                    method_name=method_name,
                    category=category,
                    scores=scores,
                    labels=labels,
                    threshold=threshold
                )
            except Exception as e:
                print(f"Warning: {method_name} failed: {e}")
                self.results[method_name] = DetectionResult(
                    method_name=method_name,
                    category=self._get_category(method_name),
                    scores=np.zeros(len(X)),
                    labels=np.zeros(len(X), dtype=int),
                    threshold=threshold
                )
        
        return self.results
    
    def _get_category(self, method_name: str) -> str:
        """Get category for a method."""
        for cat, methods in LAYERS.DETECTION_METHODS.items():
            if method_name in methods:
                return cat
        return "unknown"
    
    def get_score_matrix(self) -> Tuple[np.ndarray, List[str]]:
        """Get matrix of all scores."""
        if not self.results:
            return np.array([]), []
        
        method_names = list(self.results.keys())
        n_samples = len(next(iter(self.results.values())).scores)
        
        score_matrix = np.zeros((n_samples, len(method_names)))
        for i, name in enumerate(method_names):
            score_matrix[:, i] = self.results[name].scores
        
        return score_matrix, method_names
    
    def get_summary(self) -> Dict:
        """Get detection summary."""
        summary = {"methods_run": len(self.results), "by_category": {}}
        
        for result in self.results.values():
            cat = result.category
            if cat not in summary["by_category"]:
                summary["by_category"][cat] = []
            summary["by_category"][cat].append({
                "method": result.method_name,
                "anomalies": int(result.labels.sum())
            })
        
        return summary
