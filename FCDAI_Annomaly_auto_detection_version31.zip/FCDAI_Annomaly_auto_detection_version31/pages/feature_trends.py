"""
Feature Importance Trends — AIM AI Vault (V14)
================================================
#19 Compare method weights & feature influence across pipeline runs.
    Visualize how method contributions change over time.
    Air-gapped. Zero-network. All data from local SQLite.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import pandas as pd
import numpy as np
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP, LAYERS

dash.register_page(__name__, path="/feature-trends", name="Feature Trends", order=18)

PLOTLY_CFG = APP.PLOTLY_CONFIG

# Default method weights from config
DEFAULT_WEIGHTS = LAYERS.METHOD_WEIGHTS


def _get_method_firing_rates():
    """
    For each run, compute what fraction of anomalies each method flagged.
    This serves as an empirical 'importance' measure per run.
    """
    try:
        from database.engine import get_session
        from database.models import Anomaly, PipelineRun
        session = get_session()

        runs = session.query(PipelineRun).filter(
            PipelineRun.status == "completed"
        ).order_by(PipelineRun.completed_at.desc()).limit(20).all()

        if not runs:
            session.close()
            return pd.DataFrame()

        records = []
        for run in runs:
            anomalies = session.query(Anomaly).filter(
                Anomaly.run_id == run.run_id
            ).all()
            if not anomalies:
                continue

            method_counts = {}
            total = 0
            for a in anomalies:
                total += 1
                if a.method_flags:
                    try:
                        flags = json.loads(a.method_flags) if isinstance(a.method_flags, str) else a.method_flags
                        if isinstance(flags, list):
                            for m in flags:
                                method_counts[m] = method_counts.get(m, 0) + 1
                    except Exception:
                        pass

            for method, count in method_counts.items():
                records.append({
                    "run_id": run.run_id,
                    "run_date": run.completed_at,
                    "method": method,
                    "fire_count": count,
                    "fire_rate": count / total if total > 0 else 0,
                    "total_anomalies": total,
                })

        session.close()
        return pd.DataFrame(records)
    except Exception:
        return pd.DataFrame()


def _build_heatmap(df):
    """Build a method-vs-run heatmap of firing rates."""
    fig = go.Figure()
    if df.empty:
        fig.add_annotation(text="No data — run pipeline first",
                           xref="paper", yref="paper", x=0.5, y=0.5,
                           showarrow=False, font=dict(size=16, color="#888"))
        fig.update_layout(template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
                          plot_bgcolor="rgba(0,0,0,0)", height=400)
        return fig

    pivot = df.pivot_table(index="method", columns="run_id", values="fire_rate", fill_value=0)
    fig = go.Figure(go.Heatmap(
        z=pivot.values,
        x=pivot.columns.tolist(),
        y=pivot.index.tolist(),
        colorscale="Viridis",
        colorbar=dict(title="Fire Rate"),
    ))
    fig.update_layout(
        template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=10, r=10, t=40, b=10),
        title="Method Firing Rate Heatmap (per Run)",
        height=max(350, len(pivot) * 22),
        xaxis_title="Run ID", yaxis_title="Detection Method",
    )
    return fig


def _build_trend_lines(df):
    """Line chart of top-N method firing rates over runs."""
    fig = go.Figure()
    if df.empty:
        fig.update_layout(template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
                          plot_bgcolor="rgba(0,0,0,0)", height=350)
        return fig

    # Top 10 methods by average fire rate
    avg_rates = df.groupby("method")["fire_rate"].mean().nlargest(10)
    for method in avg_rates.index:
        method_df = df[df["method"] == method].sort_values("run_date")
        fig.add_trace(go.Scatter(
            x=method_df["run_date"], y=method_df["fire_rate"],
            mode="lines+markers", name=method, marker=dict(size=6),
        ))

    fig.update_layout(
        template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=10, r=10, t=40, b=10),
        title="Top-10 Method Fire Rate Trends",
        height=380,
        xaxis_title="Run Date", yaxis_title="Fire Rate",
        legend=dict(orientation="h", yanchor="bottom", y=1.02),
    )
    return fig


def _build_weight_bar():
    """Horizontal bar chart of configured method weights."""
    fig = go.Figure()
    methods = list(DEFAULT_WEIGHTS.keys())
    weights = list(DEFAULT_WEIGHTS.values())

    colors = ["#22b8cf" if w >= 1.5 else "#7950f2" if w >= 1.0 else "#868e96" for w in weights]

    fig.add_trace(go.Bar(
        x=weights, y=methods, orientation="h",
        marker_color=colors,
        text=[str(w) for w in weights],
        textposition="auto",
    ))
    fig.update_layout(
        template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=10, r=10, t=40, b=10),
        title="Configured Method Weights (config.py)",
        height=max(300, len(methods) * 28),
        xaxis_title="Weight",
    )
    return fig

try:
    from auth.manager import require_role
except ImportError:
    require_role = lambda *a, **kw: (lambda fn: fn)

@require_role("viewer")
def layout(**kwargs):
    df = _get_method_firing_rates()
    heatmap_fig = _build_heatmap(df)
    trend_fig = _build_trend_lines(df)
    weight_fig = _build_weight_bar()

    n_runs = df["run_id"].nunique() if not df.empty else 0
    n_methods = df["method"].nunique() if not df.empty else 0
    top_method = df.groupby("method")["fire_rate"].mean().idxmax() if not df.empty else "N/A"

    return dmc.Container([
        dmc.Group([
            dmc.Group([
                DashIconify(icon="mdi:chart-areaspline-variant", width=28, color="#22b8cf"),
                dmc.Title("Feature Importance Trends", order=2),
            ], gap="xs"),
            dmc.Badge("Method Analysis | Offline", color="cyan", variant="light"),
        ], justify="space-between", mb="lg"),

        dmc.Text("Analyze how detection methods contribute over successive pipeline runs. "
                 "Tracks method firing rates (fraction of anomalies each method flagged) "
                 "to reveal evolving feature importance patterns.",
                 size="sm", c="dimmed", mb="lg"),

        # KPI cards
        dmc.SimpleGrid(cols={"base": 1, "md": 3}, spacing="md", mb="lg", children=[
            dmc.Card([
                dmc.Group([
                    DashIconify(icon="mdi:chart-timeline-variant", width=24, color="#22b8cf"),
                    dmc.Stack([
                        dmc.Text("Runs Analyzed", size="xs", c="dimmed"),
                        dmc.Text(str(n_runs), size="xl", fw=700),
                    ], gap=0),
                ]),
            ], withBorder=True, p="md", radius="md",
                style={"backgroundColor": THEME.DARK_BG_CARD}),
            dmc.Card([
                dmc.Group([
                    DashIconify(icon="mdi:function-variant", width=24, color="#22b8cf"),
                    dmc.Stack([
                        dmc.Text("Methods Tracked", size="xs", c="dimmed"),
                        dmc.Text(str(n_methods), size="xl", fw=700),
                    ], gap=0),
                ]),
            ], withBorder=True, p="md", radius="md",
                style={"backgroundColor": THEME.DARK_BG_CARD}),
            dmc.Card([
                dmc.Group([
                    DashIconify(icon="mdi:trophy", width=24, color="#FFB300"),
                    dmc.Stack([
                        dmc.Text("Most Active Method", size="xs", c="dimmed"),
                        dmc.Text(str(top_method), size="lg", fw=700),
                    ], gap=0),
                ]),
            ], withBorder=True, p="md", radius="md",
                style={"backgroundColor": THEME.DARK_BG_CARD}),
        ]),

        # Charts
        dmc.SimpleGrid(cols={"base": 1, "lg": 2}, spacing="lg", mb="lg", children=[
            dmc.Paper([
                dcc.Graph(figure=trend_fig, config=PLOTLY_CFG),
            ], p="md", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD}),
            dmc.Paper([
                dcc.Graph(figure=weight_fig, config=PLOTLY_CFG),
            ], p="md", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD}),
        ]),

        dmc.Paper([
            dcc.Graph(figure=heatmap_fig, config=PLOTLY_CFG),
        ], p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}),
    ], fluid=True)
