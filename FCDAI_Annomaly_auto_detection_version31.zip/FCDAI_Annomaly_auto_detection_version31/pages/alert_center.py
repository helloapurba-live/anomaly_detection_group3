"""
Alert Center — AIM AI Vault (V14)
==================================
#9  On-screen toast alerts for CRITICAL/HIGH detections.
    Zero-network: no webhooks, no cloud — all alerts stored in SQLite.
    Bank audit-proof: every alert is logged with timestamp + entity_id.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import dash_ag_grid as dag
import pandas as pd
import json
import sys
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS, APP

dash.register_page(__name__, path="/alerts", name="Alert Center", order=13)


def _get_alerts(limit=500):
    """Fetch alert events from SQLite."""
    try:
        from database.engine import get_session
        from database.models import AlertEvent
        session = get_session()
        alerts = session.query(AlertEvent).order_by(AlertEvent.id.desc()).limit(limit).all()
        rows = []
        for a in alerts:
            rows.append({
                "id": a.id,
                "run_id": a.run_id,
                "entity_id": a.entity_id or "N/A",
                "risk_tier": a.risk_tier,
                "anomaly_score": round(a.anomaly_score, 4) if a.anomaly_score else 0,
                "alert_type": a.alert_type,
                "message": (a.message or "")[:100],
                "acknowledged": "Yes" if a.is_acknowledged else "No",
                "created_at": a.created_at.strftime("%Y-%m-%d %H:%M:%S") if a.created_at else "",
            })
        session.close()
        return pd.DataFrame(rows) if rows else pd.DataFrame()
    except Exception:
        return pd.DataFrame()


def _count_by_tier():
    """Count alerts by risk tier."""
    try:
        from database.engine import get_session
        from database.models import AlertEvent
        from sqlalchemy import func
        session = get_session()
        results = session.query(
            AlertEvent.risk_tier, func.count(AlertEvent.id)
        ).group_by(AlertEvent.risk_tier).all()
        session.close()
        return {r[0]: r[1] for r in results}
    except Exception:
        return {}

try:
    from auth.manager import require_role
except ImportError:
    require_role = lambda *a, **kw: (lambda fn: fn)

@require_role("investigator")
def layout(**kwargs):
    df = _get_alerts()
    tier_counts = _count_by_tier()

    stat_cards = []
    for tier, color in [("CRITICAL", "red"), ("HIGH", "orange"), ("MEDIUM", "yellow"), ("LOW", "blue")]:
        count = tier_counts.get(tier, 0)
        stat_cards.append(
            dmc.Card([
                dmc.Group([
                    DashIconify(icon="mdi:alert-circle" if tier == "CRITICAL" else "mdi:alert",
                                width=28, color={"red": "#FF5252", "orange": "#FF9800",
                                                 "yellow": "#FFB300", "blue": "#2196F3"}.get(color, "#ccc")),
                    dmc.Stack([
                        dmc.Text(tier, size="xs", c="dimmed", fw=500),
                        dmc.Text(str(count), size="xl", fw=700),
                    ], gap=0),
                ]),
            ], withBorder=True, p="md", radius="md",
                style={"backgroundColor": THEME.DARK_BG_CARD})
        )

    grid = None
    if not df.empty:
        grid = dag.AgGrid(
            id="alerts-grid",
            rowData=df.to_dict("records"),
            columnDefs=[
                {"field": "created_at", "headerName": "Time", "minWidth": 160, "sort": "desc"},
                {"field": "risk_tier", "headerName": "Tier", "minWidth": 100},
                {"field": "entity_id", "headerName": "Entity", "minWidth": 120},
                {"field": "anomaly_score", "headerName": "Score", "minWidth": 100},
                {"field": "alert_type", "headerName": "Type", "minWidth": 140},
                {"field": "message", "headerName": "Message", "minWidth": 200},
                {"field": "acknowledged", "headerName": "Ack", "minWidth": 80},
                {"field": "run_id", "headerName": "Run", "minWidth": 100},
            ],
            defaultColDef={"flex": 1, "sortable": True, "filter": True, "resizable": True},
            dashGridOptions={"pagination": True, "paginationPageSize": 20,
                             "animateRows": True, "rowSelection": "multiple"},
            style={"height": "500px", "width": "100%"},
            className="ag-theme-alpine-dark",
        )

    return dmc.Container([
        dmc.Group([
            dmc.Group([
                DashIconify(icon="mdi:bell-alert", width=28, color="#FF5252"),
                dmc.Title("Alert Center", order=2),
            ], gap="xs"),
            dmc.Group([
                dmc.Button("Acknowledge Selected", id="ack-alerts-btn",
                           leftSection=DashIconify(icon="mdi:check-all"),
                           color="green", variant="outline", size="sm"),
                dmc.Badge("{} total".format(len(df)), color="red" if len(df) > 0 else "gray",
                          variant="light"),
            ], gap="xs"),
        ], justify="space-between", mb="lg"),

        dmc.SimpleGrid(cols=4, spacing="md", mb="lg", children=stat_cards),

        dmc.Paper([
            dmc.Text("Alert Event Log", fw=700, mb="md"),
            dmc.Text("Every CRITICAL and HIGH detection triggers an alert stored in SQLite. "
                     "Zero-network: no external notifications. All data stays local.",
                     size="xs", c="dimmed", mb="md"),
            grid if grid else dmc.Alert("No alerts recorded. Run the pipeline to generate detections.",
                                        color="blue"),
        ], p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}),

        html.Div(id="ack-feedback"),
        dcc.Interval(id="alert-refresh", interval=30000, n_intervals=0),
    ], fluid=True)


@callback(
    Output("ack-feedback", "children"),
    Input("ack-alerts-btn", "n_clicks"),
    State("alerts-grid", "selectedRows"),
    prevent_initial_call=True,
)
def acknowledge_alerts(_, selected):
    """Mark selected alerts as acknowledged."""
    if not selected:
        return dmc.Alert("Select alerts first.", color="yellow")
    try:
        from database.engine import get_session
        from database.models import AlertEvent
        session = get_session()
        ids = [r.get("id") for r in selected if r.get("id")]
        session.query(AlertEvent).filter(AlertEvent.id.in_(ids)).update(
            {"is_acknowledged": True, "acknowledged_at": datetime.utcnow()},
            synchronize_session=False,
        )
        session.commit()
        session.close()
        return dmc.Alert("{} alerts acknowledged.".format(len(ids)), color="green")
    except Exception as e:
        return dmc.Alert("An error occurred. Check audit log for details.", color="red")
