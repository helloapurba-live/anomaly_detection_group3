"""
EDA Profiling — AIM AI Vault (V27)
====================================
B1: Interactive Exploratory Data Analysis profiling page.
Displays distribution histograms, missing-value heatmaps,
skewness/kurtosis tables, and correlation matrices.

All data sourced from the last pipeline run's data vault (air-gapped).
Author: AIM AI Vault V27
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP, PATHS

dash.register_page(__name__, path="/eda", name="EDA Profiling", order=23)

PLOTLY_CFG = APP.PLOTLY_CONFIG
DARK_BG = THEME.DARK_BG
CARD_BG = THEME.DARK_BG_CARD
ACCENT = THEME.PRIMARY


# ─────────────────────────────────────────────────────────────────────────────
# DATA LOADING HELPERS
# ─────────────────────────────────────────────────────────────────────────────
def _load_scored_df() -> pd.DataFrame:
    """Load the last pipeline's scored dataframe from data vault."""
    try:
        vault = PATHS.DATA_VAULT
        # Try parquet first, then CSV
        parquet_path = vault / "df_scored.parquet"
        csv_path = vault / "df_scored.csv"
        if parquet_path.exists():
            return pd.read_parquet(parquet_path)
        elif csv_path.exists():
            return pd.read_csv(csv_path)
        # Try the features path
        feat_path = vault / "df_features.parquet"
        feat_csv = vault / "df_features.csv"
        if feat_path.exists():
            return pd.read_parquet(feat_path)
        elif feat_csv.exists():
            return pd.read_csv(feat_csv)
    except Exception:
        pass
    return pd.DataFrame()


def _load_dq_metrics() -> dict:
    """Load DQ metrics from the last pipeline run."""
    try:
        dq_path = PATHS.DATA_VAULT / "dq_validation.json"
        if dq_path.exists():
            with open(dq_path) as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _compute_eda_profile(df: pd.DataFrame) -> dict:
    """Compute EDA statistics for a DataFrame."""
    if df.empty:
        return {}

    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    profile = {
        "n_rows": len(df),
        "n_cols": len(df.columns),
        "n_numeric": len(numeric_cols),
        "columns": [],
        "missing_matrix": [],
        "correlations": None,
    }

    for col in numeric_cols:
        series = df[col].dropna()
        if len(series) == 0:
            continue
        stats = {
            "name": col,
            "count": int(len(series)),
            "missing": int(df[col].isna().sum()),
            "missing_pct": round(float(df[col].isna().mean() * 100), 2),
            "mean": round(float(series.mean()), 4),
            "std": round(float(series.std()), 4),
            "min": round(float(series.min()), 4),
            "q25": round(float(series.quantile(0.25)), 4),
            "median": round(float(series.median()), 4),
            "q75": round(float(series.quantile(0.75)), 4),
            "max": round(float(series.max()), 4),
            "skewness": round(float(series.skew()), 4),
            "kurtosis": round(float(series.kurtosis()), 4),
            "n_unique": int(series.nunique()),
            "is_binary": bool(set(series.unique()).issubset({0, 1, 0.0, 1.0})),
            "n_zeros": int((series == 0).sum()),
            "zero_pct": round(float((series == 0).mean() * 100), 2),
        }
        profile["columns"].append(stats)

    # Missing-value matrix (column x sample pattern)
    missing_cols = [c for c in df.columns if df[c].isna().any()]
    if missing_cols:
        profile["missing_matrix"] = {
            "columns": missing_cols,
            "missing_counts": [int(df[c].isna().sum()) for c in missing_cols],
            "missing_pcts": [round(float(df[c].isna().mean() * 100), 2) for c in missing_cols],
        }

    # Correlation matrix (top numeric columns, max 30)
    if len(numeric_cols) >= 2:
        top_cols = numeric_cols[:30]
        corr = df[top_cols].corr()
        profile["correlations"] = {
            "columns": top_cols,
            "values": corr.values.tolist(),
        }

    return profile


# ─────────────────────────────────────────────────────────────────────────────
# LAYOUT
# ─────────────────────────────────────────────────────────────────────────────
def layout(**kwargs):
    return dmc.Container(
        [
            # Header
            dmc.Group(
                [
                    dmc.Group(
                        [
                            DashIconify(icon="mdi:chart-histogram", width=28, color=ACCENT),
                            dmc.Title("EDA Profiling", order=2, c="white"),
                            dmc.Badge("V27", color="teal", variant="filled", size="sm"),
                        ],
                        gap="xs",
                    ),
                    dmc.Button(
                        "Refresh Profile",
                        id="eda-refresh-btn",
                        leftSection=DashIconify(icon="mdi:refresh"),
                        color="teal",
                        variant="filled",
                        size="sm",
                    ),
                ],
                justify="space-between",
                mb="lg",
            ),

            # Status
            html.Div(id="eda-status"),

            # Summary cards
            html.Div(id="eda-summary-cards"),

            # Tabs for different analyses
            dmc.Tabs(
                [
                    dmc.TabsList(
                        [
                            dmc.TabsTab("Distributions", value="dist"),
                            dmc.TabsTab("Missing Values", value="missing"),
                            dmc.TabsTab("Skewness & Kurtosis", value="skew"),
                            dmc.TabsTab("Correlations", value="corr"),
                            dmc.TabsTab("Stats Table", value="stats"),
                        ],
                    ),
                    dmc.TabsPanel(html.Div(id="eda-dist-panel"), value="dist", pt="md"),
                    dmc.TabsPanel(html.Div(id="eda-missing-panel"), value="missing", pt="md"),
                    dmc.TabsPanel(html.Div(id="eda-skew-panel"), value="skew", pt="md"),
                    dmc.TabsPanel(html.Div(id="eda-corr-panel"), value="corr", pt="md"),
                    dmc.TabsPanel(html.Div(id="eda-stats-panel"), value="stats", pt="md"),
                ],
                value="dist",
                color="teal",
                id="eda-tabs",
            ),

            # Hidden store for profile data
            dcc.Store(id="eda-profile-store"),
        ],
        fluid=True,
        px="lg",
        py="lg",
    )


# ─────────────────────────────────────────────────────────────────────────────
# CALLBACKS
# ─────────────────────────────────────────────────────────────────────────────
@callback(
    Output("eda-profile-store", "data"),
    Output("eda-status", "children"),
    Output("eda-summary-cards", "children"),
    Input("eda-refresh-btn", "n_clicks"),
    prevent_initial_call=False,
)
def load_profile(n_clicks):
    """Load data and compute EDA profile."""
    df = _load_scored_df()
    if df.empty:
        return (
            None,
            dmc.Alert(
                "No data available. Run the pipeline first to generate profiling data.",
                title="No Data",
                color="yellow",
                icon=DashIconify(icon="mdi:alert"),
            ),
            None,
        )

    profile = _compute_eda_profile(df)

    # Summary cards
    n_binary = sum(1 for c in profile.get("columns", []) if c.get("is_binary"))
    n_high_missing = sum(1 for c in profile.get("columns", []) if c.get("missing_pct", 0) > 5)
    n_high_skew = sum(1 for c in profile.get("columns", []) if abs(c.get("skewness", 0)) > 2)

    cards = dmc.SimpleGrid(
        [
            _summary_card("Rows", f"{profile['n_rows']:,}", "mdi:table-row", "blue"),
            _summary_card("Columns", f"{profile['n_cols']}", "mdi:table-column", "teal"),
            _summary_card("Numeric", f"{profile['n_numeric']}", "mdi:numeric", "indigo"),
            _summary_card("Binary", f"{n_binary}", "mdi:toggle-switch", "grape"),
            _summary_card("High Missing (>5%)", f"{n_high_missing}", "mdi:alert-circle", "orange"),
            _summary_card("High Skew (|s|>2)", f"{n_high_skew}", "mdi:chart-bell-curve", "red"),
        ],
        cols={"base": 2, "sm": 3, "lg": 6},
        mb="lg",
    )

    status = dmc.Alert(
        f"Profile computed: {profile['n_rows']:,} rows × {profile['n_cols']} columns, "
        f"{profile['n_numeric']} numeric features.",
        title="Profile Ready",
        color="green",
        icon=DashIconify(icon="mdi:check-circle"),
        mb="md",
    )

    return profile, status, cards


def _summary_card(label, value, icon, color):
    return dmc.Paper(
        dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(icon=icon, width=20, color=ACCENT),
                        dmc.Text(label, size="xs", c="dimmed"),
                    ],
                    gap="xs",
                ),
                dmc.Text(value, size="xl", fw=700, c="white"),
            ],
            gap=4,
        ),
        p="md",
        radius="md",
        style={"backgroundColor": CARD_BG},
    )


# ─── DISTRIBUTIONS TAB ───
@callback(
    Output("eda-dist-panel", "children"),
    Input("eda-profile-store", "data"),
    prevent_initial_call=True,
)
def update_distributions(profile):
    if not profile or "columns" not in profile:
        return dmc.Text("No profile data available.", c="dimmed")

    df = _load_scored_df()
    if df.empty:
        return dmc.Text("No data.", c="dimmed")

    cols = [c["name"] for c in profile["columns"][:20]]  # Top 20

    figs = []
    for col_name in cols:
        if col_name not in df.columns:
            continue
        series = df[col_name].dropna()
        if len(series) == 0:
            continue
        fig = go.Figure()
        fig.add_trace(go.Histogram(x=series, nbinsx=50, marker_color=ACCENT, opacity=0.8))
        fig.update_layout(
            title=dict(text=col_name, font=dict(size=12)),
            template="plotly_dark",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            height=220,
            margin=dict(l=40, r=20, t=35, b=30),
            xaxis=dict(title=""),
            yaxis=dict(title="Count"),
        )
        figs.append(
            dmc.Paper(
                dcc.Graph(figure=fig, config=PLOTLY_CFG, style={"height": "220px"}),
                p="xs",
                radius="md",
                style={"backgroundColor": CARD_BG},
            )
        )

    if not figs:
        return dmc.Text("No numeric columns to plot.", c="dimmed")

    return dmc.SimpleGrid(figs, cols={"base": 1, "sm": 2, "lg": 4}, spacing="md")


# ─── MISSING VALUES TAB ───
@callback(
    Output("eda-missing-panel", "children"),
    Input("eda-profile-store", "data"),
    prevent_initial_call=True,
)
def update_missing(profile):
    if not profile:
        return dmc.Text("No profile data.", c="dimmed")

    missing_data = profile.get("missing_matrix", {})
    if not missing_data or not missing_data.get("columns"):
        return dmc.Alert("No missing values detected in the dataset!", color="green",
                         icon=DashIconify(icon="mdi:check-circle"))

    cols = missing_data["columns"]
    pcts = missing_data["missing_pcts"]
    counts = missing_data["missing_counts"]

    # Bar chart of missing values
    fig = go.Figure()
    colors = ["#ff6b6b" if p > 10 else "#ffa94d" if p > 5 else "#51cf66" for p in pcts]
    fig.add_trace(go.Bar(x=cols, y=pcts, marker_color=colors, text=[f"{p}%" for p in pcts], textposition="auto"))
    fig.update_layout(
        title="Missing Value Percentage by Column",
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=400,
        margin=dict(l=50, r=20, t=40, b=80),
        xaxis=dict(tickangle=45),
        yaxis=dict(title="Missing %"),
    )

    # Table
    rows = []
    for c, cnt, pct in sorted(zip(cols, counts, pcts), key=lambda x: -x[2]):
        rows.append(html.Tr([
            html.Td(c, style={"color": "white"}),
            html.Td(f"{cnt:,}", style={"color": "#adb5bd"}),
            html.Td(f"{pct}%", style={"color": "#ff6b6b" if pct > 10 else "#ffa94d" if pct > 5 else "#51cf66"}),
        ]))

    table = dmc.Paper(
        html.Table(
            [html.Thead(html.Tr([html.Th("Column"), html.Th("Count"), html.Th("Missing %")])), html.Tbody(rows)],
            style={"width": "100%", "borderCollapse": "collapse"},
        ),
        p="md",
        radius="md",
        style={"backgroundColor": CARD_BG},
    )

    return dmc.Stack([
        dmc.Paper(
            dcc.Graph(figure=fig, config=PLOTLY_CFG),
            p="xs", radius="md", style={"backgroundColor": CARD_BG},
        ),
        table,
    ])


# ─── SKEWNESS & KURTOSIS TAB ───
@callback(
    Output("eda-skew-panel", "children"),
    Input("eda-profile-store", "data"),
    prevent_initial_call=True,
)
def update_skew_kurtosis(profile):
    if not profile or "columns" not in profile:
        return dmc.Text("No profile data.", c="dimmed")

    columns = profile["columns"]
    if not columns:
        return dmc.Text("No numeric columns.", c="dimmed")

    # Sort by absolute skewness descending
    sorted_cols = sorted(columns, key=lambda c: abs(c.get("skewness", 0)), reverse=True)

    names = [c["name"] for c in sorted_cols[:25]]
    skews = [c.get("skewness", 0) for c in sorted_cols[:25]]
    kurts = [c.get("kurtosis", 0) for c in sorted_cols[:25]]

    # Scatter: skewness vs kurtosis
    fig_scatter = go.Figure()
    fig_scatter.add_trace(go.Scatter(
        x=skews, y=kurts,
        mode="markers+text",
        text=names,
        textposition="top center",
        textfont=dict(size=8),
        marker=dict(size=10, color=np.abs(skews), colorscale="RdYlGn_r", showscale=True,
                     colorbar=dict(title="|Skew|")),
    ))
    fig_scatter.add_hline(y=3, line_dash="dash", line_color="gray", annotation_text="Normal kurtosis=3")
    fig_scatter.add_vline(x=0, line_dash="dash", line_color="gray")
    fig_scatter.update_layout(
        title="Skewness vs Kurtosis (top 25 by |skew|)",
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=450,
        xaxis=dict(title="Skewness"),
        yaxis=dict(title="Kurtosis"),
    )

    # Bar chart: skewness
    colors_sk = ["#ff6b6b" if abs(s) > 2 else "#ffa94d" if abs(s) > 1 else "#51cf66" for s in skews]
    fig_bar = go.Figure()
    fig_bar.add_trace(go.Bar(x=names, y=skews, marker_color=colors_sk))
    fig_bar.update_layout(
        title="Skewness by Feature",
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=350,
        xaxis=dict(tickangle=45),
        yaxis=dict(title="Skewness"),
    )

    return dmc.Stack([
        dmc.Paper(
            dcc.Graph(figure=fig_scatter, config=PLOTLY_CFG),
            p="xs", radius="md", style={"backgroundColor": CARD_BG},
        ),
        dmc.Paper(
            dcc.Graph(figure=fig_bar, config=PLOTLY_CFG),
            p="xs", radius="md", style={"backgroundColor": CARD_BG},
        ),
    ])


# ─── CORRELATIONS TAB ───
@callback(
    Output("eda-corr-panel", "children"),
    Input("eda-profile-store", "data"),
    prevent_initial_call=True,
)
def update_correlations(profile):
    if not profile or not profile.get("correlations"):
        return dmc.Text("Not enough numeric columns for correlation matrix.", c="dimmed")

    corr_data = profile["correlations"]
    cols = corr_data["columns"]
    values = np.array(corr_data["values"])

    fig = go.Figure(data=go.Heatmap(
        z=values,
        x=cols,
        y=cols,
        colorscale="RdBu_r",
        zmid=0,
        text=np.round(values, 2),
        texttemplate="%{text}",
        textfont={"size": 7} if len(cols) > 15 else {"size": 9},
    ))
    fig.update_layout(
        title="Correlation Matrix (Pearson)",
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=max(500, len(cols) * 22),
        xaxis=dict(tickangle=45, tickfont=dict(size=8)),
        yaxis=dict(tickfont=dict(size=8)),
    )

    # Highly correlated pairs
    pairs = []
    for i in range(len(cols)):
        for j in range(i + 1, len(cols)):
            r = values[i][j]
            if abs(r) > 0.8:
                pairs.append({"Feature A": cols[i], "Feature B": cols[j], "r": round(r, 4)})

    pair_alert = None
    if pairs:
        pair_df = pd.DataFrame(pairs).sort_values("r", key=abs, ascending=False)
        rows = [html.Tr([html.Td(r["Feature A"]), html.Td(r["Feature B"]),
                         html.Td(f"{r['r']:.4f}", style={"color": "#ff6b6b" if r["r"] > 0 else "#339af0"})
                         ]) for _, r in pair_df.iterrows()]
        pair_alert = dmc.Paper(
            dmc.Stack([
                dmc.Text(f"Highly Correlated Pairs (|r| > 0.8): {len(pairs)}", fw=600, c="white"),
                html.Table(
                    [html.Thead(html.Tr([html.Th("Feature A"), html.Th("Feature B"), html.Th("r")])),
                     html.Tbody(rows)],
                    style={"width": "100%", "borderCollapse": "collapse"},
                ),
            ]),
            p="md", radius="md", style={"backgroundColor": CARD_BG}, mt="md",
        )

    children = [
        dmc.Paper(
            dcc.Graph(figure=fig, config=PLOTLY_CFG),
            p="xs", radius="md", style={"backgroundColor": CARD_BG},
        ),
    ]
    if pair_alert:
        children.append(pair_alert)
    return dmc.Stack(children)


# ─── STATS TABLE TAB ───
@callback(
    Output("eda-stats-panel", "children"),
    Input("eda-profile-store", "data"),
    prevent_initial_call=True,
)
def update_stats_table(profile):
    if not profile or "columns" not in profile:
        return dmc.Text("No profile data.", c="dimmed")

    columns = profile["columns"]
    if not columns:
        return dmc.Text("No numeric columns.", c="dimmed")

    header = html.Tr([
        html.Th("Feature"), html.Th("Count"), html.Th("Missing%"),
        html.Th("Mean"), html.Th("Std"), html.Th("Min"),
        html.Th("Q25"), html.Th("Median"), html.Th("Q75"), html.Th("Max"),
        html.Th("Skew"), html.Th("Kurt"), html.Th("Binary"),
    ])

    rows = []
    for c in columns:
        skew_color = "#ff6b6b" if abs(c["skewness"]) > 2 else "#ffa94d" if abs(c["skewness"]) > 1 else "#adb5bd"
        rows.append(html.Tr([
            html.Td(c["name"], style={"color": "white", "fontWeight": 500}),
            html.Td(f"{c['count']:,}", style={"color": "#adb5bd"}),
            html.Td(f"{c['missing_pct']}%",
                     style={"color": "#ff6b6b" if c["missing_pct"] > 5 else "#adb5bd"}),
            html.Td(f"{c['mean']:.3f}", style={"color": "#adb5bd"}),
            html.Td(f"{c['std']:.3f}", style={"color": "#adb5bd"}),
            html.Td(f"{c['min']:.3f}", style={"color": "#adb5bd"}),
            html.Td(f"{c['q25']:.3f}", style={"color": "#adb5bd"}),
            html.Td(f"{c['median']:.3f}", style={"color": "#adb5bd"}),
            html.Td(f"{c['q75']:.3f}", style={"color": "#adb5bd"}),
            html.Td(f"{c['max']:.3f}", style={"color": "#adb5bd"}),
            html.Td(f"{c['skewness']:.2f}", style={"color": skew_color}),
            html.Td(f"{c['kurtosis']:.2f}", style={"color": "#adb5bd"}),
            html.Td("Yes" if c["is_binary"] else "—",
                     style={"color": "#a9e34b" if c["is_binary"] else "#adb5bd"}),
        ]))

    return dmc.Paper(
        dmc.ScrollArea(
            html.Table(
                [html.Thead(header), html.Tbody(rows)],
                style={"width": "100%", "borderCollapse": "collapse", "fontSize": "0.82rem"},
            ),
            type="auto",
        ),
        p="md",
        radius="md",
        style={"backgroundColor": CARD_BG, "overflowX": "auto"},
    )
