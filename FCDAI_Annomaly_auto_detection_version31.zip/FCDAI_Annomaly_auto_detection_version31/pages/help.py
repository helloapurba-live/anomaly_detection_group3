"""
AIM AI Vault V14 — Offline Help Page
======================================
Bundled documentation and keyboard shortcuts reference.
100% offline — no external links, no CDN, no cloud.

Author: AIM AI Vault Team
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import dash
from dash import html
import dash_mantine_components as dmc
from dash_iconify import DashIconify

from config import APP

dash.register_page(
    __name__,
    path="/help",
    title=f"Help — {APP.BRAND} {APP.VERSION_TAG}",
    name="Help",
)


def _section(title, icon, children):
    """Create a collapsible help section."""
    return dmc.Accordion(
        children=[
            dmc.AccordionItem(
                value=title,
                children=[
                    dmc.AccordionControl(
                        dmc.Group([
                            DashIconify(icon=icon, width=20),
                            dmc.Text(title, fw=600),
                        ], gap="sm"),
                    ),
                    dmc.AccordionPanel(children),
                ],
            ),
        ],
        variant="separated",
        mb="sm",
    )


def _kbd(key):
    """Render a keyboard key badge."""
    return dmc.Badge(key, variant="outline", color="gray", size="sm",
                     style={"fontFamily": "monospace"})


def layout(**kwargs):
    return dmc.Container([
        # Header
        dmc.Stack([
            dmc.Title("Help & Documentation", order=2),
            dmc.Group([
                dmc.Badge(APP.VERSION_TAG, color=APP.BADGE_COLOR, variant="filled", size="lg"),
                dmc.Text("Offline reference — no external connections", c="dimmed", size="sm"),
            ], gap="xs"),
        ], gap=4, mb="lg"),

        # Quick Start
        _section("Quick Start Guide", "mdi:rocket-launch", [
            dmc.List([
                dmc.ListItem("Navigate to Data Sources to upload CSV/Excel/Parquet files"),
                dmc.ListItem("Configure column mappings if auto-detection misses key columns"),
                dmc.ListItem("Go to Execution Engine to run the 7-layer pipeline"),
                dmc.ListItem("View results on Dashboard, Layer View, and Investigation Queue"),
                dmc.ListItem("Generate reports via Report Generator for regulatory submission"),
                dmc.ListItem("Monitor system health on the System Health page"),
            ]),
        ]),

        # 7-Layer Architecture
        _section("7-Layer Pipeline Architecture", "mdi:layers-triple", [
            dmc.Table(
                data={
                    "head": ["Layer", "Name", "Purpose"],
                    "body": [
                        ["L1-L2", "Ingestion & Data Quality",
                         "Load multi-source data, assess completeness/consistency/validity"],
                        ["L3", "Feature Engineering",
                         "Generate velocity, aggregate, ratio, temporal, behavioral features"],
                        ["L4", "Preprocessing",
                         "Scale, normalize, PCA, encode — prepare matrices for detection"],
                        ["L5", "Detection (26 Methods)",
                         "Statistical, distance, density, clustering, tree, time-series, graph, deep learning"],
                        ["L6", "Ensemble Fusion",
                         "Combine scores via weighted average, tiered consensus, or voting"],
                        ["L7", "Output Generation",
                         "Risk tier assignment, alert queue, audit trail, narrative generation"],
                    ],
                },
            ),
        ]),

        # 26 Detection Methods
        _section("26 Detection Methods", "mdi:brain", [
            dmc.SimpleGrid(
                cols={"base": 1, "md": 2},
                spacing="sm",
                children=[
                    dmc.Paper([
                        dmc.Text("Statistical (5)", fw=600, size="sm", mb="xs"),
                        dmc.Text("Z-Score, IQR, Grubbs, Dixon Q-test, Generalized ESD",
                                 size="xs", c="dimmed"),
                    ], p="sm", radius="sm", withBorder=True),
                    dmc.Paper([
                        dmc.Text("Distance (3)", fw=600, size="sm", mb="xs"),
                        dmc.Text("k-NN, Mahalanobis, Local Outlier Factor (LOF)",
                                 size="xs", c="dimmed"),
                    ], p="sm", radius="sm", withBorder=True),
                    dmc.Paper([
                        dmc.Text("Density (4)", fw=600, size="sm", mb="xs"),
                        dmc.Text("DBSCAN, OPTICS, HDBSCAN, CBLOF",
                                 size="xs", c="dimmed"),
                    ], p="sm", radius="sm", withBorder=True),
                    dmc.Paper([
                        dmc.Text("Clustering (3)", fw=600, size="sm", mb="xs"),
                        dmc.Text("K-Means Anomaly, Gaussian Mixture, Spectral",
                                 size="xs", c="dimmed"),
                    ], p="sm", radius="sm", withBorder=True),
                    dmc.Paper([
                        dmc.Text("Tree-Based (2)", fw=600, size="sm", mb="xs"),
                        dmc.Text("Isolation Forest, Extended Isolation Forest",
                                 size="xs", c="dimmed"),
                    ], p="sm", radius="sm", withBorder=True),
                    dmc.Paper([
                        dmc.Text("Time-Series (3)", fw=600, size="sm", mb="xs"),
                        dmc.Text("STL Decomposition, ARIMA Residuals, Prophet-style",
                                 size="xs", c="dimmed"),
                    ], p="sm", radius="sm", withBorder=True),
                    dmc.Paper([
                        dmc.Text("Graph (4)", fw=600, size="sm", mb="xs"),
                        dmc.Text("PageRank, HITS, Community Detection, Centrality",
                                 size="xs", c="dimmed"),
                    ], p="sm", radius="sm", withBorder=True),
                    dmc.Paper([
                        dmc.Text("Deep Learning (2)", fw=600, size="sm", mb="xs"),
                        dmc.Text("Autoencoder, Variational Autoencoder (VAE)",
                                 size="xs", c="dimmed"),
                    ], p="sm", radius="sm", withBorder=True),
                ],
            ),
        ]),

        # Keyboard Shortcuts
        _section("Keyboard Shortcuts", "mdi:keyboard", [
            dmc.Table(
                data={
                    "head": ["Shortcut", "Action"],
                    "body": [
                        ["Alt + D", "Go to Dashboard"],
                        ["Alt + S", "Go to Data Sources"],
                        ["Alt + P", "Go to Pipeline Execution"],
                        ["Alt + L", "Go to Layer View"],
                        ["Alt + Q", "Go to Investigation Queue"],
                        ["Alt + H", "Go to System Health"],
                        ["Alt + ?", "Open this Help page"],
                    ],
                },
            ),
        ]),

        # User Roles
        _section("User Roles & Permissions", "mdi:shield-account", [
            dmc.Table(
                data={
                    "head": ["Role", "Access Level", "Pages"],
                    "body": [
                        ["Admin", "Full access", "All pages including Admin Panel, Config, User Management"],
                        ["Investigator", "Operational", "Dashboard, Sources, Pipeline, Layers, Queue, Narratives, Audit"],
                        ["Viewer", "Read-only", "Dashboard, Layers, Audit, Diagnostics, Explainability"],
                    ],
                },
            ),
        ]),

        # Risk Tiers
        _section("Risk Tier Classification", "mdi:alert-octagon", [
            dmc.Table(
                data={
                    "head": ["Tier", "Score Range", "Vote Minimum", "Action"],
                    "body": [
                        ["CRITICAL", ">= 0.95", ">= 23 methods", "Immediate escalation + SAR filing"],
                        ["HIGH", ">= 0.85", ">= 18 methods", "Priority investigation within 24 hours"],
                        ["MEDIUM", ">= 0.70", ">= 12 methods", "Queue for investigation within 7 days"],
                        ["LOW", ">= 0.50", ">= 8 methods", "Monitor — enhanced due diligence"],
                        ["NORMAL", "< 0.50", "< 8 methods", "No action required"],
                    ],
                },
            ),
        ]),

        # System Health
        _section("System Health & Monitoring", "mdi:monitor-dashboard", [
            dmc.List([
                dmc.ListItem("System Health page shows real-time CPU, memory, disk, DB, and cache metrics"),
                dmc.ListItem("Watchdog thread monitors resources every 30 seconds"),
                dmc.ListItem("Circuit breakers auto-disable repeatedly failing detection methods"),
                dmc.ListItem("Structured JSON logs in logs/structured.jsonl for machine parsing"),
                dmc.ListItem("Audit trail with hash-chain integrity in logs/admin_audit.log"),
            ]),
        ]),

        # Air-Gapped Security
        _section("Air-Gapped Security", "mdi:shield-lock", [
            dmc.List([
                dmc.ListItem("Zero external network connections — complete air-gap enforcement"),
                dmc.ListItem("All JavaScript/CSS served locally — no CDN or Google Fonts"),
                dmc.ListItem("Fernet encryption for PII at rest"),
                dmc.ListItem("SHA-256 entity ID hashing in audit logs"),
                dmc.ListItem("Secure HttpOnly + SameSite cookies"),
                dmc.ListItem("CSV formula injection protection on all exports"),
                dmc.ListItem("PII masking enabled by default — raw data never shown in UI"),
                dmc.ListItem("Sanitized error messages — no file paths or stack traces in UI"),
            ]),
        ]),

        # Troubleshooting
        _section("Troubleshooting", "mdi:wrench", [
            dmc.Table(
                data={
                    "head": ["Issue", "Solution"],
                    "body": [
                        ["Pipeline fails immediately", "Check Data Sources page — ensure at least one source is uploaded"],
                        ["All detection scores are zero", "Check Layer View — dataset may be too small or too homogeneous"],
                        ["Database locked errors", "Only one pipeline can run at a time — wait for completion"],
                        ["Memory warning", "Reduce dataset size or disable heavy methods (LOF, HDBSCAN, Spectral)"],
                        ["Theme not applying", "Hard refresh (Ctrl+Shift+R) or reset theme to Sentinel Dark"],
                        ["Login fails", "Default credentials: admin/admin123 — change in production!"],
                    ],
                },
            ),
        ]),

        # Version Info
        dmc.Paper([
            dmc.Group([
                dmc.Text(f"{APP.BRAND} {APP.VERSION_TAG}", fw=700),
                dmc.Text(f"Version {APP.VERSION}", c="dimmed", size="sm"),
                dmc.Badge("Air-Gapped", color="green", variant="light", size="sm"),
                dmc.Badge("Bank Audit Ready", color="blue", variant="light", size="sm"),
                dmc.Badge("FCDAI", color="violet", variant="light", size="sm"),
            ], gap="sm"),
        ], p="md", radius="md", withBorder=True, mt="md"),

    ], size="xl", py="md")
