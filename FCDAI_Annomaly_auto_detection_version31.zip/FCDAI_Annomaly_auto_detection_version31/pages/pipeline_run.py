"""
Execution Engine Page — AIM AI Vault (V30)
==========================================
Execute the L01–L14 unified detection pipeline.
V30: Clean L01–L14 sequential naming, 20 algos, 8 families.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, ctx
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import dash_ag_grid as dag
import pandas as pd
import numpy as np
import time
import json
import sys
import traceback as _tb
from pathlib import Path
from datetime import datetime
import threading

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS, LAYERS, APP

# V30: algo_execution_engine imported lazily inside callbacks


def _write_pipeline_status(progress, stage, status, error=None):
    """Write pipeline status JSON (thread-safe via atomic rename)."""
    data = {"progress": progress, "stage": stage, "status": status,
            "timestamp": datetime.now().isoformat()}
    if error:
        data["error"] = error
    status_file = PATHS.DATA_VAULT / "pipeline_status.json"
    tmp = status_file.with_suffix(".tmp")
    try:
        with open(tmp, "w") as f:
            json.dump(data, f)
        tmp.replace(status_file)
    except Exception:
        pass


dash.register_page(__name__, path="/pipeline", name="Execution Engine", order=2)


# =============================================================================
# HELPER: Layer step card
# =============================================================================
def layer_step(number, name, desc):
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.Avatar(number, radius="xl", color="cyan", variant="filled"),
                    dmc.Stack([dmc.Text(name, fw=600), dmc.Text(desc, size="sm", c="dimmed")], gap=0),
                    dmc.ThemeIcon(
                        DashIconify(icon="mdi:clock-outline", width=20),
                        color="gray", variant="light",
                    ),
                ],
                justify="space-between",
            ),
        ],
        p="sm", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD, "marginBottom": "8px"},
    )


# =============================================================================
# V11 HELPERS
# =============================================================================
def _build_grid(df, grid_id, page_size=15, height="380px"):
    """Build a paginated AG Grid for a DataFrame (PII-safe: no raw IDs shown)."""
    if df is None or df.empty:
        return dmc.Alert("No data available.", color="yellow")
    cols = []
    for c in df.columns:
        col_def = {
            "field": c,
            "headerName": c.replace("_", " ").title(),
            "sortable": True, "filter": True, "resizable": True, "minWidth": 110,
        }
        if c in ("customer_id", "cust_id", "party_id", "customer_name", "cust_name"):
            col_def["pinned"] = "left"
            col_def["minWidth"] = 140
        cols.append(col_def)
    display_df = df.copy()
    for c in display_df.select_dtypes(include=[np.floating]).columns:
        display_df[c] = display_df[c].round(4)
    return dag.AgGrid(
        id=grid_id,
        rowData=display_df.head(5000).to_dict("records"),
        columnDefs=cols,
        defaultColDef={"flex": 1, "minWidth": 100, "resizable": True, "sortable": True},
        dashGridOptions={
            "pagination": True, "paginationPageSize": page_size,
            "paginationPageSizeSelector": [10, 15, 50, 100],
            "animateRows": True, "enableCellTextSelection": True,
        },
        style={"height": height, "width": "100%"},
        className="ag-theme-alpine-dark",
    )


def _load_aggregate():
    """Load data sources and build customer-level aggregate table."""
    try:
        from utils.data_io import data_vault
        from pages.data_sources import _build_master_table
        sources = data_vault.load_sources()
        if not sources:
            return None, 0, 0
        df_master, _display = _build_master_table(sources)
        n_tables = len(sources)
        n_customers = len(df_master) if df_master is not None else 0
        return df_master, n_tables, n_customers
    except Exception:
        return None, 0, 0


# =============================================================================
# LAYOUT (V11: dynamic — shows live aggregate table)
# =============================================================================
try:
    from auth.manager import require_role
except ImportError:
    require_role = lambda *a, **kw: (lambda fn: fn)

@require_role("investigator")
def layout(**kwargs):
    df_master, n_tables, n_customers = _load_aggregate()

    # V28: Auto-detect data source (Customer Aggregate Table removed)
    default_source = "actual" if (df_master is not None and not df_master.empty) else "sample"

    return dmc.Container(
        [
            dmc.Group(
                [
                    dmc.Group([
                        DashIconify(icon="mdi:rocket-launch", width=28, color="#22b8cf"),
                        dmc.Title("Execution Engine", order=2),
                    ], gap="xs"),
                    dmc.Group([
                        dmc.Badge("14 Layers", color="cyan", variant="light"),
                        dmc.Badge("20 Methods", color="cyan", variant="light"),
                        dmc.Badge("8 Families", color="cyan", variant="light"),
                    ], gap="xs"),
                ],
                justify="space-between", mb="lg",
            ),

            # ── Pipeline Progress Bar (at top for visibility) ──
            dmc.Paper(
                [
                    dmc.Text("Pipeline Progress", fw=600, mb="sm"),
                    dmc.Progress(id="pipeline-progress-bar", value=0, size="xl", radius="xl",
                                 striped=False, animated=False, color="cyan"),
                    dmc.Text("Ready — select data source and click 'Run Pipeline'",
                             id="pipeline-progress-label", size="sm", c="dimmed", mt="xs"),
                ],
                p="md", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD}, mb="lg",
            ),

            dmc.SimpleGrid(
                cols={"base": 1, "lg": 2}, spacing="lg",
                children=[
                    # ═══════════════════════════════════════════════════════
                    # LEFT: Pipeline Processing Steps (V28 — 4 step cards)
                    # Flow: df_encoded → Transform → Scale → Reduce
                    # ═══════════════════════════════════════════════════════
                    dmc.Stack([
                        # ── STEP FLOW HEADER ──
                        dmc.Paper(
                            [
                                dmc.Group([
                                    DashIconify(icon="mdi:pipe", width=22, color="#22b8cf"),
                                    dmc.Text("Pipeline Processing Steps", fw=700, size="lg"),
                                ], gap="xs"),
                                dmc.Text(
                                    "Configure each processing stage. Data flows: "
                                    "Encode → Transform → Scale → Reduce",
                                    size="xs", c="dimmed", mt=4,
                                ),
                            ],
                            p="sm", radius="md", withBorder=True,
                            style={"backgroundColor": THEME.DARK_BG_CARD},
                        ),

                        # ── STEP 1: MISSING VALUE STRATEGY (L07) ──
                        dmc.Paper(
                            [
                                dmc.Group([
                                    dmc.Avatar("L07", radius="xl", color="blue", variant="filled", size="sm"),
                                    dmc.Text("Missing Value Strategy", fw=600, size="sm"),
                                    dmc.Badge("Encoding", color="blue", variant="light", size="xs"),
                                ], gap="xs", mb="xs"),
                                dmc.Text("How to handle missing/null values before encoding", size="xs", c="dimmed", mb="xs"),
                                dmc.Select(
                                    id="pipeline-missing-strategy",
                                    data=[
                                        {"value": "ZERO", "label": "ZERO — Fill with 0"},
                                        {"value": "MEDIAN", "label": "MEDIAN — Numeric median, categorical mode"},
                                        {"value": "MODE", "label": "MODE — Most frequent value"},
                                        {"value": "DROP", "label": "DROP — Drop rows (< 5% missing)"},
                                    ],
                                    value="ZERO",
                                ),
                            ],
                            p="sm", radius="md", withBorder=True,
                            style={"backgroundColor": THEME.DARK_BG_CARD, "borderLeft": "3px solid #339af0"},
                        ),

                        # ── STEP 2: TRANSFORM (L08) ──
                        dmc.Paper(
                            [
                                dmc.Group([
                                    dmc.Avatar("L08", radius="xl", color="grape", variant="filled", size="sm"),
                                    dmc.Text("Conditional Transform", fw=600, size="sm"),
                                    dmc.Badge("L08", color="grape", variant="light", size="xs"),
                                    dmc.Badge("DEFAULT: Auto", color="green", variant="filled", size="xs"),
                                ], gap="xs", mb="xs"),
                                dmc.Text(
                                    "Per-column log/power transformation based on skewness. "
                                    "Auto mode analyses each column individually.",
                                    size="xs", c="dimmed", mb="xs",
                                ),
                                dmc.Select(
                                    id="pipeline-transform-mode",
                                    data=[
                                        {"value": "auto", "label": "Auto — Skewness-based per-column decision"},
                                        {"value": "log", "label": "Log — Force log1p on all skewed columns"},
                                        {"value": "power", "label": "Power — Force Yeo-Johnson on all skewed"},
                                        {"value": "none", "label": "None — Skip transformation step"},
                                    ],
                                    value="auto",
                                ),
                            ],
                            p="sm", radius="md", withBorder=True,
                            style={"backgroundColor": THEME.DARK_BG_CARD, "borderLeft": "3px solid #ae3ec9"},
                        ),

                        # ── STEP 3: SCALE (L09) ──
                        dmc.Paper(
                            [
                                dmc.Group([
                                    dmc.Avatar("L09", radius="xl", color="teal", variant="filled", size="sm"),
                                    dmc.Text("Scaling Method", fw=600, size="sm"),
                                    dmc.Badge("6-Way Engine", color="teal", variant="light", size="xs"),
                                ], gap="xs", mb="xs"),
                                dmc.Text(
                                    "Primary scaler whose output feeds into dimension reduction. "
                                    "Auto = each algorithm gets its optimal scaler from the routing matrix.",
                                    size="xs", c="dimmed", mb="xs",
                                ),
                                dmc.Select(
                                    id="pipeline-primary-scaler",
                                    data=[
                                        {"value": "Auto", "label": "⚡ Auto (per-algorithm optimal routing)"},
                                        {"value": "StandardScaler", "label": "Standard Scaler (z-score normalisation)"},
                                        {"value": "MinMaxScaler", "label": "MinMax Scaler (0–1 range)"},
                                        {"value": "RobustScaler", "label": "Robust Scaler (IQR-based, outlier-resistant)"},
                                        {"value": "MaxAbsScaler", "label": "MaxAbs Scaler (divide by max absolute)"},
                                        {"value": "PowerTransformer", "label": "Power Transformer (Yeo-Johnson)"},
                                        {"value": "Original", "label": "Original (no scaling — raw values)"},
                                    ],
                                    value="Auto",
                                ),
                            ],
                            p="sm", radius="md", withBorder=True,
                            style={"backgroundColor": THEME.DARK_BG_CARD, "borderLeft": "3px solid #20c997"},
                        ),

                        # ── STEP 4: DIMENSION REDUCTION (L10) ──
                        dmc.Paper(
                            [
                                dmc.Group([
                                    dmc.Avatar("L10", radius="xl", color="orange", variant="filled", size="sm"),
                                    dmc.Text("Dimension Reduction", fw=600, size="sm"),
                                    dmc.Badge("9-Path Engine", color="orange", variant="light", size="xs"),
                                ], gap="xs", mb="xs"),
                                dmc.Text(
                                    "Reduce feature space before anomaly detection. "
                                    "Agent Decide auto-selects the optimal path using R×V analysis.",
                                    size="xs", c="dimmed", mb="xs",
                                ),
                                dmc.Select(
                                    id="pipeline-reduction-path",
                                    label="Reduction Path",
                                    data=[
                                        {"value": "1", "label": "1 — None (No Reduction)"},
                                        {"value": "2", "label": "2 — Mixed PCA (PCA + keep binary/cat)"},
                                        {"value": "3", "label": "3 — FAMD (PCA + MCA unified)"},
                                        {"value": "4", "label": "4 — UMAP Mixed (UMAP + keep binary/cat)"},
                                        {"value": "5", "label": "5 — UMAP Metric Intersection"},
                                        {"value": "6", "label": "6 — SDAE (Autoencoder)"},
                                        {"value": "7", "label": "7 — Agent Quick (speed priority)"},
                                        {"value": "8", "label": "8 — Agent Think (accuracy priority)"},
                                        {"value": "9", "label": "9 — Agent Decide (R×V auto-decision) ⭐"},
                                    ],
                                    value="9", mb="xs",
                                ),
                                dmc.NumberInput(
                                    id="pipeline-target-dims",
                                    label="Output Features (Target Dims)",
                                    description="How many columns after reduction, e.g. 100→30. Empty = auto.",
                                    min=2, max=500, step=1,
                                    placeholder="Auto",
                                ),
                            ],
                            p="sm", radius="md", withBorder=True,
                            style={"backgroundColor": THEME.DARK_BG_CARD, "borderLeft": "3px solid #fd7e14"},
                        ),
                    ], gap="sm"),

                    # ═══════════════════════════════════════════════════════
                    # RIGHT: Data Source + Execution Controls
                    # ═══════════════════════════════════════════════════════
                    dmc.Stack([
                        # Hidden store keeps data-source value for the callback
                        dcc.Store(id="pipeline-data-source", data=default_source),
                        dmc.Paper(
                            [
                                dmc.Group([
                                    DashIconify(icon="mdi:database-check", width=20, color="#22b8cf"),
                                    dmc.Text("Data Summary", fw=600),
                                ], gap="xs", mb="xs"),
                                html.Div(id="pipeline-data-status"),
                            ],
                            p="sm", radius="md", withBorder=True,
                            style={"backgroundColor": THEME.DARK_BG_CARD},
                        ),
                        dmc.Paper(
                            [
                                dmc.Group([
                                    DashIconify(icon="mdi:brain", width=22, color="#ae3ec9"),
                                    dmc.Text("Execution Settings", fw=700, size="lg"),
                                    dmc.Badge("V30", color="grape", variant="filled", size="xs"),
                                    dmc.Badge("Unified Pipeline", color="grape", variant="outline", size="xs"),
                                ], gap="xs", mb="xs"),
                                dmc.Text(
                                    "One-click pipeline: DQ → Encode → Transform → Scale → Reduce → "
                                    "L11 Detection (20 algos, 8 families) → Ensemble → Output.",
                                    size="xs", c="dimmed", mb="sm",
                                ),
                                dmc.Divider(label="L11 — Detection Engine", labelPosition="center", my="xs"),
                                dmc.Select(
                                    id="pipeline-algo-mode",
                                    label="Algorithm Execution Mode",
                                    data=[
                                        {"value": "auto", "label": "Agent Auto — Auto-select based on data characteristics"},
                                        {"value": "manual", "label": "Manual — Select specific algorithm families below"},
                                        {"value": "full", "label": "Full Suite — Execute ALL applicable algorithms"},
                                    ],
                                    value="auto", mb="xs",
                                    leftSection=DashIconify(icon="mdi:cog-play", width=18),
                                ),
                                dmc.MultiSelect(
                                    id="pipeline-algo-families",
                                    label="Algorithm Families (8 families · 20 algorithms)",
                                    data=[
                                        {"value": "Statistical", "label": "Statistical"},
                                        {"value": "Tree", "label": "Tree"},
                                        {"value": "Density", "label": "Density"},
                                        {"value": "Distance", "label": "Distance"},
                                        {"value": "Clustering", "label": "Clustering"},
                                        {"value": "Graph", "label": "Graph"},
                                        {"value": "TimeSeries", "label": "TimeSeries"},
                                        {"value": "DeepLearning", "label": "DeepLearning"},
                                    ],
                                    value=["Statistical", "Tree", "Density", "Distance",
                                           "Clustering", "Graph", "TimeSeries", "DeepLearning"],
                                    mb="xs",
                                ),
                                dmc.SimpleGrid(cols={"base": 1, "sm": 2}, spacing="xs", children=[
                                    dmc.NumberInput(
                                        id="pipeline-contamination",
                                        label="Contamination Rate",
                                        value=0.05, min=0.01, max=0.30, step=0.01, decimalScale=2,
                                        description="Expected % anomalies",
                                    ),
                                    dmc.Select(
                                        id="pipeline-ensemble", label="Ensemble Method",
                                        data=[
                                            {"value": "weighted_average", "label": "Weighted Average"},
                                            {"value": "max", "label": "Max Score"},
                                            {"value": "voting", "label": "Voting"},
                                            {"value": "stacking", "label": "Stacking"},
                                        ],
                                        value="weighted_average",
                                    ),
                                ]),
                                dmc.Divider(label="V31 — Scoring Pipeline", labelPosition="center", my="xs"),
                                dmc.Text(
                                    "3-stage scoring: Raw Scores → Normalized [0,1] → Fused Ensemble → Risk Tier. "
                                    "Auto selects best-practice defaults per AML domain.",
                                    size="xs", c="dimmed", mb="xs",
                                ),
                                dmc.SimpleGrid(cols={"base": 1, "sm": 3}, spacing="xs", children=[
                                    dmc.Select(
                                        id="pipeline-score-normalization",
                                        label="Score Normalization",
                                        data=[
                                            {"value": "auto", "label": "Auto (Percentile Rank)"},
                                            {"value": "percentile_rank", "label": "Percentile Rank"},
                                            {"value": "minmax", "label": "Min-Max [0,1]"},
                                            {"value": "zscore_sigmoid", "label": "Z-Score + Sigmoid"},
                                            {"value": "rank_transform", "label": "Rank Transform"},
                                            {"value": "robust_scale", "label": "Robust Scale (IQR)"},
                                            {"value": "log_minmax", "label": "Log + Min-Max"},
                                        ],
                                        value="auto",
                                        leftSection=DashIconify(icon="mdi:chart-bell-curve", width=16),
                                    ),
                                    dmc.Select(
                                        id="pipeline-score-fusion",
                                        label="Score Fusion",
                                        data=[
                                            {"value": "auto", "label": "Auto (Family→Algo)"},
                                            {"value": "family_then_algo", "label": "Family → Algo Weighted"},
                                            {"value": "family_weighted", "label": "Family Weighted Avg"},
                                            {"value": "weighted_average", "label": "Algo Weighted Avg"},
                                            {"value": "simple_voting", "label": "Simple Voting"},
                                            {"value": "average", "label": "Equal Average"},
                                            {"value": "maximum", "label": "Maximum Score"},
                                            {"value": "tiered_consensus", "label": "Tiered Consensus"},
                                            {"value": "borda_count", "label": "Borda Count"},
                                            {"value": "rank_fusion", "label": "Rank Fusion"},
                                        ],
                                        value="auto",
                                        leftSection=DashIconify(icon="mdi:merge", width=16),
                                    ),
                                    dmc.Select(
                                        id="pipeline-score-threshold",
                                        label="Threshold Calibration",
                                        data=[
                                            {"value": "auto", "label": "Auto (Percentile-based)"},
                                            {"value": "percentile_based", "label": "Percentile-based"},
                                            {"value": "rule_based", "label": "Rule-based (Fixed)"},
                                            {"value": "borda_consensus", "label": "Borda Consensus"},
                                        ],
                                        value="auto",
                                        leftSection=DashIconify(icon="mdi:speedometer", width=16),
                                    ),
                                ]),
                                dmc.Group([
                                    dmc.Button("Agent Recommend", id="pipeline-btn-agent-recommend",
                                               variant="light", color="grape", size="xs",
                                               leftSection=DashIconify(icon="mdi:robot", width=16)),
                                ], gap="xs", mt="xs"),
                                html.Div(id="pipeline-agent-recommend-result"),
                                dmc.Divider(my="sm"),
                                dmc.Group([
                                    dmc.Button("Run Pipeline", id="pipeline-btn-run",
                                               leftSection=DashIconify(icon="mdi:rocket-launch"),
                                               color="cyan", size="lg", style={"flex": 1}),
                                    dmc.Button("Stop", id="pipeline-btn-stop",
                                               leftSection=DashIconify(icon="mdi:stop"),
                                               color="orange", variant="outline", size="lg"),
                                ], grow=True),
                                dmc.Button("Reset Pipeline", id="pipeline-btn-reset",
                                           leftSection=DashIconify(icon="mdi:refresh"),
                                           color="red", variant="subtle", size="sm", mt="sm", fullWidth=True),
                            ],
                            p="md", radius="md", withBorder=True,
                            style={"backgroundColor": THEME.DARK_BG_CARD, "borderLeft": "3px solid #ae3ec9"},
                        ),
                    ], gap="sm"),
                ],
            ),

            # ── V30: Complete Data Pipeline Workflow Reference ──
            dmc.Paper(
                [
                    dmc.Group([
                        DashIconify(icon="mdi:map-marker-path", width=22, color="#22b8cf"),
                        dmc.Text("Complete Data Pipeline Workflow", fw=700, size="lg"),
                        dmc.Badge("Variable ↔ UI Map", color="cyan", variant="outline", size="sm"),
                    ], gap="xs", mb="xs"),
                    dmc.Text(
                        "End-to-end data flow from raw input to anomaly detection. "
                        "Each stage transforms data and passes the output downstream.",
                        size="xs", c="dimmed", mb="sm",
                    ),
                    dag.AgGrid(
                        id="pipeline-workflow-table",
                        rowData=[
                            {"Stage": "L01 — Ingest & Merge",   "Python Variable": "df_merged",         "Shape Desc": "N rows × K raw cols",       "Engine": "DataVault / DataGenerator",       "UI Card": "Data Summary (right)",               "Output": "Raw merged DataFrame from uploaded/sample tables"},
                            {"Stage": "L06 — DQ Processing",  "Python Variable": "df_cleaned",        "Shape Desc": "N × K' (cols dropped)",     "Engine": "DQProcessingEngine.process()",    "UI Card": "Pipeline Processing Steps",       "Output": "12-step cleansed DataFrame + data_type_map"},
                            {"Stage": "L07 — Encode",         "Python Variable": "df_encoded",        "Shape Desc": "N × F (100% numeric)",      "Engine": "PreprocessingEngine.preprocess()", "UI Card": "L07 Missing Value Strategy",       "Output": "EncodedMaster (all float64) + encoding_map"},
                            {"Stage": "L08 — Transform",    "Python Variable": "df_transformed",    "Shape Desc": "N × F (skew-corrected)",    "Engine": "TransformationEngine.transform()", "UI Card": "L08 Conditional Transform",      "Output": "Log/Power transformed per-column + skew stats"},
                            {"Stage": "L09 — Scale",          "Python Variable": "m4_result.scaled_matrices", "Shape Desc": "6 × (N × F) matrices",  "Engine": "ScalingEngine.scale()",            "UI Card": "L09 Scaling Method",               "Output": "6-way scaled matrices (Std/MinMax/Robust/MaxAbs/Power/Orig)"},
                            {"Stage": "L10 — Reduce",         "Python Variable": "df_premaster",      "Shape Desc": "N × D (dims reduced)",      "Engine": "ReductionEngine.reduce()",         "UI Card": "L10 Dimension Reduction",          "Output": "PreMaster matrix ready for detection (9 paths)"},
                            {"Stage": "L11 — Detect",         "Python Variable": "score_matrix",      "Shape Desc": "N × 26 (per-method)",       "Engine": "DetectionLayer (20 algos)",        "UI Card": "Execution Settings → Run Pipeline", "Output": "Per-method anomaly scores [0,1] for each row"},
                            {"Stage": "L13 — Ensemble",       "Python Variable": "df_scored",         "Shape Desc": "N × (K+scores+tier)",       "Engine": "EnsembleLayer",                    "UI Card": "Ensemble Method selector",        "Output": "Final scored DataFrame with risk tiers (T1–T4)"},
                            {"Stage": "L14 — Output",         "Python Variable": "pipeline_result",   "Shape Desc": "JSON + Parquet vault",       "Engine": "OutputLayer / DataVault",          "UI Card": "Pipeline Results area",           "Output": "Persisted scored.parquet + pipeline_result.json"},
                        ],
                        columnDefs=[
                            {"field": "Stage",            "headerName": "Stage",           "pinned": "left", "minWidth": 150, "maxWidth": 180},
                            {"field": "Python Variable",  "headerName": "Python Variable", "minWidth": 180},
                            {"field": "Shape Desc",       "headerName": "Shape",           "minWidth": 160},
                            {"field": "Engine",           "headerName": "Engine / Class",  "minWidth": 200},
                            {"field": "UI Card",          "headerName": "UI Card",         "minWidth": 180},
                            {"field": "Output",           "headerName": "Description",     "minWidth": 280, "flex": 2},
                        ],
                        defaultColDef={"flex": 1, "minWidth": 120, "resizable": True, "sortable": True, "filter": True},
                        dashGridOptions={"domLayout": "autoHeight", "animateRows": True, "enableCellTextSelection": True},
                        style={"width": "100%"},
                        className="ag-theme-alpine-dark",
                    ),
                ],
                p="md", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD}, mt="lg",
            ),

            html.Div(id="pipeline-results-area"),
            html.Div(id="pipeline-stop-output", style={"display": "none"}),
            html.Div(id="pipeline-reset-output", style={"display": "none"}),
            dcc.Store(id="pipeline-run-flag", data=0, storage_type="memory"),
            dcc.Interval(id="pipeline-poll", interval=2000, n_intervals=0, disabled=True),
            dcc.Interval(id="pipeline-load-trigger", interval=1000, max_intervals=1, n_intervals=0),
        ],
        fluid=True,
    )


# =============================================================================
# DATA SOURCE STATUS
# =============================================================================
@callback(
    Output("pipeline-data-status", "children"),
    Output("pipeline-data-source", "data"),
    Input("pipeline-data-source", "data"),
)
def update_data_status(source_type):
    """V28: Auto-detect data — show compact summary, set source automatically."""
    from utils.data_io import data_vault

    sources = data_vault.load_sources()
    df_merged = data_vault.get_data()

    if sources and any(len(df) > 0 for df in sources.values()):
        total_rows = sum(len(df) for df in sources.values())
        merged_rows = len(df_merged) if df_merged is not None else 0
        customer_count = 0
        if df_merged is not None and not df_merged.empty:
            for col in ['customer_id', 'party_id', 'customer_name']:
                if col in df_merged.columns:
                    customer_count = df_merged[col].nunique()
                    break
            n_features = len(df_merged.columns)
        else:
            n_features = 0
        return (
            dmc.Stack([
                dmc.Group([
                    dmc.Badge(f"{len(sources)} tables", color="cyan", variant="light", size="sm"),
                    dmc.Badge(f"{total_rows:,} rows", color="teal", variant="light", size="sm"),
                    dmc.Badge(f"{merged_rows:,} merged", color="blue", variant="light", size="sm"),
                    dmc.Badge(f"{customer_count:,} customers", color="green", variant="filled", size="sm"),
                ], gap=4),
                dmc.Group([
                    dmc.Badge(f"{n_features} features", color="violet", variant="light", size="sm"),
                    dmc.Badge("Source: Uploaded Data", color="green", variant="outline", size="xs"),
                ], gap=4),
            ], gap=4),
            "actual",
        )
    else:
        return (
            dmc.Stack([
                dmc.Text("No uploaded data found", size="sm", c="dimmed"),
                dmc.Group([
                    dmc.Badge("Will auto-generate 100 customers", color="blue", variant="light", size="sm"),
                    dmc.Badge("Source: Sample", color="orange", variant="outline", size="xs"),
                ], gap=4),
            ], gap=4),
            "sample",
        )


# =============================================================================
# PROGRESS POLLING — detects completion/failure, renders results, resets UI
# =============================================================================
@callback(
    Output("pipeline-progress-bar", "value"),
    Output("pipeline-progress-label", "children"),
    Output("pipeline-progress-bar", "animated"),
    Output("pipeline-results-area", "children", allow_duplicate=True),
    Output("pipeline-btn-run", "disabled", allow_duplicate=True),
    Output("pipeline-btn-run", "loading", allow_duplicate=True),
    Output("pipeline-btn-stop", "disabled", allow_duplicate=True),
    Output("pipeline-poll", "disabled", allow_duplicate=True),
    Output("pipeline-progress-bar", "striped", allow_duplicate=True),
    Output("store-pipeline-complete", "data", allow_duplicate=True),
    Input("pipeline-poll", "n_intervals"),
    prevent_initial_call=True,
)
def poll_progress(n):
    """Poll pipeline_status.json for progress updates.

    On completion: loads results from vault, re-enables buttons, stops poll.
    On failure: shows error, re-enables buttons, stops poll.
    """
    NO = dash.no_update
    status_file = PATHS.DATA_VAULT / "pipeline_status.json"
    if not status_file.exists():
        # Pipeline thread hasn't written first status yet
        return 0, "⏳ Initializing…", True, NO, NO, NO, NO, NO, NO, NO

    try:
        with open(status_file, "r") as f:
            status = json.load(f)

        progress = status.get("progress", 0)
        state = status.get("status", "unknown")
        stage = status.get("stage", "")

        if state == "running":
            return progress, f"⏳ {stage} ({progress}%)", True, NO, NO, NO, NO, NO, NO, NO

        elif state == "completed":
            # Load results from vault and render
            results_ui = _build_results_from_vault()
            if results_ui is None:
                results_ui = dmc.Alert(
                    "Pipeline completed successfully. Reload to view results.",
                    color="green", icon=DashIconify(icon="mdi:check-circle"),
                )
            return (100, f"✅ {stage}", False,
                    results_ui, False, False, True, True, False, time.time())

        elif state == "failed":
            error_msg = status.get("error", "Unknown error")
            return (progress, f"❌ Failed: {error_msg}", False,
                    dmc.Alert(f"Pipeline failed: {error_msg}", title="Pipeline Failed",
                              color="red", icon=DashIconify(icon="mdi:alert")),
                    False, False, True, True, False, NO)

        else:
            return progress, stage, False, NO, NO, NO, NO, NO, NO, NO
    except Exception:
        return NO, NO, NO, NO, NO, NO, NO, NO, NO, NO


# =============================================================================
# STOP BUTTON
# =============================================================================
@callback(
    Output("pipeline-stop-output", "children"),
    Input("pipeline-btn-stop", "n_clicks"),
    prevent_initial_call=True,
)
def stop_pipeline(n):
    # F-15 FIX: RBAC check — only admin/investigator can stop
    try:
        from flask_login import current_user
        if current_user.is_authenticated and current_user.role == "viewer":
            return "Access denied: viewer role cannot stop pipelines"
    except Exception:
        pass
    import os, signal, platform
    pid_file = PATHS.DATA_VAULT / "pipeline.pid"
    if pid_file.exists():
        try:
            with open(pid_file, "r") as f:
                pid = int(f.read().strip())
            # V24 FIX: Use CTRL_C_EVENT on Windows for graceful shutdown
            if platform.system() == "Windows":
                os.kill(pid, signal.CTRL_C_EVENT)
            else:
                os.kill(pid, signal.SIGTERM)
            return f"Stopped PID {pid}"
        except Exception as e:
            return "Operation failed. Check audit log."
    return "No active pipeline"


# =============================================================================
# RESET BUTTON
# =============================================================================
@callback(
    Output("pipeline-reset-output", "children"),
    Output("pipeline-results-area", "children", allow_duplicate=True),
    Output("pipeline-progress-bar", "value", allow_duplicate=True),
    Output("pipeline-progress-label", "children", allow_duplicate=True),
    Output("pipeline-btn-run", "disabled", allow_duplicate=True),
    Output("pipeline-btn-run", "loading", allow_duplicate=True),
    Output("pipeline-btn-stop", "disabled", allow_duplicate=True),
    Output("pipeline-poll", "disabled", allow_duplicate=True),
    Output("pipeline-progress-bar", "striped", allow_duplicate=True),
    Input("pipeline-btn-reset", "n_clicks"),
    prevent_initial_call=True,
)
def reset_pipeline(n):
    """Clear all pipeline results and scored data, fully reset UI state."""
    from utils.data_io import data_vault
    import shutil
    
    try:
        # Clear scored data
        scored_path = PATHS.DATA_VAULT / "scored.parquet"
        if scored_path.exists():
            scored_path.unlink()
        
        # Clear pipeline result
        result_path = PATHS.DATA_VAULT / "pipeline_result.json"
        if result_path.exists():
            result_path.unlink()
        
        # Clear status
        status_path = PATHS.DATA_VAULT / "pipeline_status.json"
        if status_path.exists():
            status_path.unlink()
        
        # V8: Reload vault from disk to sync across pages
        data_vault.reload_from_disk()
        data_vault._scored_data = None
        data_vault._pipeline_result = {}
        
        return (
            "Pipeline reset complete",
            dmc.Alert(
                "Pipeline reset successfully. All scored data and results cleared.",
                color="green",
                icon=DashIconify(icon="mdi:check-circle"),
                withCloseButton=True,
            ),
            0,
            "Ready — select data source and click 'Run Pipeline'",
            False,   # btn-run re-enabled
            False,   # btn-run loading off
            True,    # btn-stop disabled
            True,    # poll disabled
            False,   # progress not striped
        )
    except Exception as e:
        return ("Operation failed. Check audit log.",
                dmc.Alert("Reset failed. Check audit log.", color="red"),
                dash.no_update, dash.no_update,
                False, False, True, True, False)




# =============================================================================
# PIPELINE WORKER THREAD (runs in background thread, avoids PicklingError)
# =============================================================================
def _pipeline_worker_thread(data_source, ensemble_method, reduction_path,
                             missing_strategy, algo_families, transform_mode,
                             target_dims, primary_scaler, algo_mode, contamination,
                             score_normalization=None, score_fusion=None,
                             threshold_method=None, run_id=None):
    """Background thread: run full pipeline and save results to vault.

    Uses threading.Thread instead of background=True to avoid PicklingError
    with dmc components (dmc.Paper.LoadingState not picklable by dill).
    Status updates are written to pipeline_status.json for poll_progress.
    """
    try:
        _write_pipeline_status(1, "Loading modules…", "running")
        from pipeline import ApurbaDasPipeline
        from utils.data_io import data_vault
        from utils.data_gen import DataGenerator

        # ── 1. Load or generate data ──
        _write_pipeline_status(2, "Loading data…", "running")
        df_merged = None
        sources = {}

        if data_source == "actual":
            sources = data_vault.load_sources()
            df_merged = data_vault.get_data()

            if df_merged is None or df_merged.empty:
                if sources:
                    if "BASE" in sources:
                        from utils.column_resolver import resolve
                        df_base = sources["BASE"].copy()
                        pk_col = resolve(df_base, 'primary_key')
                        if pk_col:
                            for tname, tdf in sources.items():
                                if tname == "BASE":
                                    continue
                                tpk = resolve(tdf, 'primary_key')
                                if tpk:
                                    try:
                                        df_base = df_base.merge(
                                            tdf, left_on=pk_col, right_on=tpk,
                                            how="left", suffixes=("", f"_{tname}")
                                        )
                                    except Exception:
                                        pass
                        df_merged = df_base
                        data_vault.set_current_data(df_merged, label="actual_merged")
                    else:
                        df_tx = sources.get("transactions", pd.DataFrame())
                        df_acc = sources.get("accounts", pd.DataFrame())
                        df_party = sources.get("customer_party", pd.DataFrame())
                        if not df_tx.empty:
                            df_merged = df_tx.copy()
                            if not df_acc.empty and "account_id" in df_tx.columns and "account_id" in df_acc.columns:
                                df_merged = df_merged.merge(df_acc, on="account_id", how="left", suffixes=("", "_acc"))
                            if not df_party.empty and "party_id" in df_merged.columns and "party_id" in df_party.columns:
                                df_merged = df_merged.merge(df_party, on="party_id", how="left", suffixes=("", "_party"))
                            data_vault.set_current_data(df_merged, label="actual_merged")
                        else:
                            df_fallback = max(sources.values(), key=len)
                            df_merged = df_fallback
                            data_vault.set_current_data(df_merged, label="actual_fallback")
                else:
                    _write_pipeline_status(0, "Failed: No data found", "failed",
                                           "No actual data found. Go to Data Sources to upload data.")
                    return

        if data_source == "sample" or (df_merged is None or df_merged.empty):
            _write_pipeline_status(3, "Generating sample data…", "running")
            dg = DataGenerator()
            schema = dg.generate_full_schema(100)

            _config_names = {"EXCLUDE", "FEATURE_MAP", "TABLE_MAP", "METHOD_CONFIG",
                             "ALGO_FEATURE_MAP", "FEATURE_STORE", "METADATA",
                             "CUSTOM_CONFIG", "TABLE_GRAIN_DETECTION", "FEATURE_ENGINEERING"}
            data_tables = {k: v for k, v in schema.items() if k not in _config_names}
            config_tables = {k: v for k, v in schema.items() if k in _config_names}

            data_vault.save_sources(schema)
            sources = data_tables

            try:
                PATHS.DATA_SOURCES.mkdir(parents=True, exist_ok=True)
                for cfg_name, cfg_df in config_tables.items():
                    cfg_df.to_csv(PATHS.DATA_SOURCES / f"{cfg_name}.csv", index=False)
            except Exception:
                pass

            if "BASE" in data_tables:
                from utils.column_resolver import resolve
                df_base = data_tables["BASE"].copy()
                pk_col = resolve(df_base, 'primary_key')
                if pk_col:
                    for tname, tdf in data_tables.items():
                        if tname == "BASE":
                            continue
                        tpk = resolve(tdf, 'primary_key')
                        if tpk:
                            try:
                                df_base = df_base.merge(
                                    tdf, left_on=pk_col, right_on=tpk,
                                    how="left", suffixes=("", f"_{tname}")
                                )
                            except Exception:
                                pass
                df_merged = df_base
            else:
                df_tx = data_tables.get("transactions", pd.DataFrame())
                df_acc = data_tables.get("accounts", pd.DataFrame())
                df_party = data_tables.get("customer_party", pd.DataFrame())
                df_merged = df_tx.copy() if not df_tx.empty else pd.DataFrame()
                if not df_merged.empty and not df_acc.empty and "account_id" in df_tx.columns and "account_id" in df_acc.columns:
                    df_merged = df_merged.merge(df_acc, on="account_id", how="left", suffixes=("", "_acc"))
                if not df_merged.empty and not df_party.empty and "party_id" in df_merged.columns and "party_id" in df_party.columns:
                    df_merged = df_merged.merge(df_party, on="party_id", how="left", suffixes=("", "_party"))
            data_vault.set_current_data(df_merged, label="sample_100_cust")

        _write_pipeline_status(5, "Preparing detection methods…", "running")

        # ── 2. Determine which methods to run — V30: map algo families → categories ──
        _fam_to_cat = {"Statistical": "statistical", "Tree": "trees", "Density": "density",
                        "Distance": "distance", "Clustering": "clustering", "Graph": "graph",
                        "TimeSeries": "timeseries", "DeepLearning": "deep_learning"}
        methods = []
        for fam in (algo_families or list(_fam_to_cat.keys())):
            cat_key = _fam_to_cat.get(fam, fam.lower())
            if cat_key in LAYERS.DETECTION_METHODS:
                methods.extend(LAYERS.DETECTION_METHODS[cat_key])

        # ── 3. Run pipeline with merged_df ──
        _write_pipeline_status(8, "Starting pipeline engine…", "running")
        pipeline = ApurbaDasPipeline()
        result = pipeline.run(
            sources if sources else {"merged": df_merged},
            detection_methods=methods if methods else None,
            ensemble_method=ensemble_method,
            merged_df=df_merged,
            reduction_path=reduction_path,
            missing_strategy=missing_strategy,
            transform_mode=transform_mode or "auto",
            target_dims=int(target_dims) if target_dims else None,
            primary_scaler=primary_scaler or "Auto",
            score_normalization=score_normalization or "auto",
            score_fusion=score_fusion or "auto",
            threshold_method=threshold_method or "auto",
        )

        if result.success:
            # ── 4. Persist results ──
            pipeline.save_results()
            data_vault.set_scored_data(result.df_scored)
            data_vault.reload_from_disk()

            # Build per-method score summary
            score_matrix, method_names = pipeline.detection.get_score_matrix()
            method_scores = []
            for i, m in enumerate(method_names):
                col_scores = score_matrix[:, i]
                cat = _get_category(m)
                method_scores.append({
                    "method": m, "category": cat,
                    "mean_score": round(float(col_scores.mean()), 4),
                    "max_score": round(float(col_scores.max()), 4),
                    "anomalies": int((col_scores > 0.5).sum()),
                })

            layer_timings = getattr(result, 'layer_timings', {})
            risk_by_family = _build_risk_by_family(result.df_scored, method_names, score_matrix)
            risk_by_ensemble = _build_risk_by_ensemble(result.df_scored, score_matrix, method_names)

            # Save pipeline result JSON for dashboard
            result_json = {
                "success": True,
                "timestamp": result.timestamp,
                "records_processed": result.records_processed,
                "dq_score": result.dq_score,
                "features_generated": result.features_generated,
                "methods_run": result.methods_run,
                "alerts_generated": result.alerts_generated,
                "tier_distribution": result.tier_distribution,
                "execution_time_ms": result.execution_time_ms,
                "method_scores": method_scores,
                "layer_timings": layer_timings,
                "data_source": data_source,
                "risk_by_family": risk_by_family,
                "risk_by_ensemble": risk_by_ensemble,
                # L02/L06–L10: DQ Pipeline results for layer_view tabs
                "dq_validation": getattr(result, 'dq_validation_dict', {}),
                "dq_processing": getattr(result, 'dq_processing_dict', {}),
                "preprocessing": getattr(result, 'preprocessing_dict', {}),
                "transform": getattr(result, 'transform_dict', {}),
                "scaling": getattr(result, 'scaling_dict', {}),
                "reduction": getattr(result, 'reduction_dict', {}),
            }
            data_vault.save_pipeline_result(result_json)

            # V10: Sync anomalies to SQLite + update pipeline_run record
            try:
                data_vault.sync_anomalies_to_db(run_id or "unknown")
            except Exception:
                pass
            try:
                from database.engine import get_session
                from database.models import PipelineRun
                session = get_session()
                db_run = session.query(PipelineRun).filter_by(run_id=run_id).first() if run_id else None
                if db_run:
                    db_run.status = "completed"
                    db_run.completed_at = datetime.now()
                    db_run.n_anomalies = result.alerts_generated
                    db_run.duration_sec = result.execution_time_ms / 1000.0
                    db_run.result_json = json.dumps(result_json, default=str)
                    session.commit()
                session.close()
            except Exception:
                pass

            # ── V30: L11 — Algorithm Execution Engine (20 algos, 8 families) ──
            try:
                print("\n  [L11] Running Algorithm Execution Engine...")
                premaster_path = PATHS.DATA_VAULT / "premaster.parquet"
                if premaster_path.exists():
                    df_pm = pd.read_parquet(premaster_path)
                else:
                    df_pm = result.df_scored.drop(
                        columns=[c for c in result.df_scored.columns
                                 if c.startswith("score_") or c in ("anomaly_score", "risk_tier")],
                        errors="ignore"
                    )
                X_pm = df_pm.select_dtypes(include=[np.number]).values.astype(np.float64)
                X_pm = np.nan_to_num(X_pm, nan=0.0, posinf=0.0, neginf=0.0)
                if X_pm.shape[0] >= 10 and X_pm.shape[1] >= 2:
                    from sklearn.preprocessing import (
                        StandardScaler as _SS, RobustScaler as _RS, MinMaxScaler as _MMS)
                    scaled_mats = {
                        "Original": X_pm,
                        "StandardScaler": _SS().fit_transform(X_pm),
                        "RobustScaler": _RS().fit_transform(X_pm),
                        "MinMaxScaler": _MMS().fit_transform(X_pm),
                    }
                    _contam = contamination if contamination else 0.05
                    from utils.algo_execution_engine import AlgorithmExecutionEngine
                    algo_engine = AlgorithmExecutionEngine(contamination=_contam)
                    algo_result = algo_engine.execute(
                        scaled_matrices=scaled_mats, X_original=X_pm,
                        mode=algo_mode or "auto",
                        selected_families=algo_families if algo_mode == "manual" else None,
                        has_graph=False, has_temporal=False, has_amount=True,
                    )
                    try:
                        algo_engine.save_outputs(PATHS.DATA_VAULT / "algo_output")
                    except Exception:
                        pass

                    # Save algo tracker rows to pipeline result JSON
                    algo_tracker_rows = []
                    for aname, ares in algo_result.algo_results.items():
                        algo_tracker_rows.append({
                            "Algorithm": aname, "Family": ares.family,
                            "Status": "OK" if ares.status == "success" else ("FAIL" if ares.status == "failed" else "SKIP"),
                            "Anomalies": int(ares.n_anomalies) if ares.status == "success" else 0,
                            "Runtime (s)": round(ares.runtime_s, 3) if ares.runtime_s > 0 else 0,
                            "Mean Score": round(float(np.mean(ares.scores)), 4) if ares.scores is not None else 0,
                            "Max Score": round(float(np.max(ares.scores)), 4) if ares.scores is not None else 0,
                        })
                    algo_phase_log = [{"phase": p.get("phase", ""), "duration_s": p.get("duration_s", 0),
                                       "status": p.get("status", ""), "details": p.get("details", "")}
                                      for p in (algo_result.phase_log or [])]
                    result_json["algo_tracker_rows"] = algo_tracker_rows
                    result_json["algo_phase_log"] = algo_phase_log
                    data_vault.save_pipeline_result(result_json)

                    n_ok = sum(1 for r in algo_result.algo_results.values() if r.status == "success")
                    print(f"  [L11] Algo Exec done: {n_ok}/{len(algo_result.selected_algorithms)} succeed")
                else:
                    print(f"  [L11] Skipping algo exec: data shape {X_pm.shape} too small")
            except Exception as _ae:
                print(f"  [L11 WARN] Algo execution error: {_ae}")
                import traceback as _tb2; _tb2.print_exc()

            # Mark pipeline as complete
            _write_pipeline_status(100, "Pipeline Complete", "completed")

        else:
            _write_pipeline_status(0, "Pipeline Failed", "failed", str(result.error)[:500])
            try:
                from database.engine import get_session
                from database.models import PipelineRun
                session = get_session()
                db_run = session.query(PipelineRun).filter_by(run_id=run_id).first() if run_id else None
                if db_run:
                    db_run.status = "failed"
                    db_run.completed_at = datetime.now()
                    db_run.error_message = str(result.error)[:500]
                    session.commit()
                session.close()
            except Exception:
                pass

    except Exception as e:
        import traceback
        print(f"[Pipeline Worker] Exception: {e}")
        traceback.print_exc()
        _write_pipeline_status(0, "Failed", "failed", str(e)[:500])
        try:
            from database.engine import get_session
            from database.models import PipelineRun
            session = get_session()
            db_run = session.query(PipelineRun).filter_by(run_id=run_id).first() if run_id else None
            if db_run:
                db_run.status = "failed"
                db_run.completed_at = datetime.now()
                db_run.error_message = str(e)[:500]
                session.commit()
            session.close()
        except Exception:
            pass


# =============================================================================
# RUN PIPELINE (main callback) — V30: threading-based non-blocking execution
# =============================================================================
@callback(
    Output("pipeline-results-area", "children"),
    Output("store-pipeline-complete", "data"),
    Output("pipeline-btn-run", "disabled"),
    Output("pipeline-btn-run", "loading"),
    Output("pipeline-btn-stop", "disabled"),
    Output("pipeline-poll", "disabled"),
    Output("pipeline-progress-bar", "striped"),
    Output("pipeline-progress-bar", "value", allow_duplicate=True),
    Output("pipeline-progress-label", "children", allow_duplicate=True),
    Input("pipeline-btn-run", "n_clicks"),
    State("pipeline-data-source", "data"),
    State("pipeline-ensemble", "value"),
    State("pipeline-reduction-path", "value"),
    State("pipeline-missing-strategy", "value"),
    State("pipeline-algo-families", "value"),
    State("pipeline-transform-mode", "value"),
    State("pipeline-target-dims", "value"),
    State("pipeline-primary-scaler", "value"),
    State("pipeline-algo-mode", "value"),
    State("pipeline-contamination", "value"),
    State("pipeline-score-normalization", "value"),
    State("pipeline-score-fusion", "value"),
    State("pipeline-score-threshold", "value"),
    prevent_initial_call=True,
)
def run_pipeline(n_clicks, data_source, ensemble_method, reduction_path,
                 missing_strategy, algo_families, transform_mode, target_dims,
                 primary_scaler, algo_mode, contamination,
                 score_normalization, score_fusion, threshold_method):
    if not n_clicks:
        raise dash.exceptions.PreventUpdate

    # V10: Record pipeline run start in SQLite
    run_id = None
    try:
        from database.engine import get_session
        from database.models import PipelineRun
        import uuid as _uuid
        session = get_session()
        run_id = str(_uuid.uuid4())[:8]
        db_run = PipelineRun(
            run_id=run_id,
            status="running",
            started_at=datetime.now(),
            config_json=json.dumps({
                "data_source": data_source, "ensemble": ensemble_method,
                "reduction_path": reduction_path, "missing_strategy": missing_strategy,
                "algo_families": algo_families, "algo_mode": algo_mode,
                "contamination": contamination, "transform_mode": transform_mode,
                "target_dims": target_dims, "primary_scaler": primary_scaler,
                "score_normalization": score_normalization,
                "score_fusion": score_fusion,
                "threshold_method": threshold_method,
            }),
        )
        session.add(db_run)
        session.commit()
        session.close()
    except Exception:
        pass

    # Clear old status file and write initial status
    status_file = PATHS.DATA_VAULT / "pipeline_status.json"
    if status_file.exists():
        try:
            status_file.unlink()
        except Exception:
            pass
    _write_pipeline_status(0, "Initializing — preparing data…", "running")

    # Launch pipeline in background thread (avoids PicklingError with dmc components)
    t = threading.Thread(
        target=_pipeline_worker_thread,
        args=(data_source, ensemble_method, reduction_path, missing_strategy,
              algo_families, transform_mode, target_dims, primary_scaler,
              algo_mode, contamination),
        kwargs={"score_normalization": score_normalization,
                "score_fusion": score_fusion,
                "threshold_method": threshold_method,
                "run_id": run_id},
        daemon=True,
    )
    t.start()

    return (
        dmc.Alert(
            "Pipeline execution started. Progress updates will appear above.",
            color="cyan", icon=DashIconify(icon="mdi:rocket-launch"),
        ),
        dash.no_update,   # store-pipeline-complete (set by poll_progress on completion)
        True,             # btn-run disabled
        True,             # btn-run loading
        False,            # btn-stop enabled
        False,            # poll enabled
        True,             # progress striped
        0,                # progress value
        "⏳ Initializing — preparing data…",
    )


def _get_category(method_name):
    for cat, methods in LAYERS.DETECTION_METHODS.items():
        if method_name in methods:
            return cat.replace("_", " ").title()
    return "Unknown"


# =============================================================================
# RISK BY FAMILY (per detection category)
# =============================================================================
def _build_risk_by_family(df_scored, method_names, score_matrix):
    """Build risk counts per detection family (category)."""
    rows = []
    for cat_key, cat_methods in LAYERS.DETECTION_METHODS.items():
        cat_label = cat_key.replace("_", " ").title()
        # Indices of methods in this category
        cat_indices = [i for i, m in enumerate(method_names) if m in cat_methods]
        if not cat_indices:
            rows.append({
                "Family": cat_label, "Methods": 0,
                "Critical": 0, "High": 0, "Medium": 0, "Low": 0,
            })
            continue

        # V6: Average score across methods in this family for each CUSTOMER
        family_scores = score_matrix[:, cat_indices].mean(axis=1)

        # Apply risk tier thresholds to family-level scores (CUSTOMER level)
        critical = int((family_scores > 0.8).sum())
        high = int(((family_scores > 0.6) & (family_scores <= 0.8)).sum())
        medium = int(((family_scores > 0.4) & (family_scores <= 0.6)).sum())
        low = int((family_scores <= 0.4).sum())

        rows.append({
            "Family": cat_label,
            "Methods": len(cat_indices),
            "Critical": critical,
            "High": high,
            "Medium": medium,
            "Low": low,
        })

    return rows


# =============================================================================
# RISK BY ENSEMBLE METHOD — all 5 methods
# =============================================================================
def _build_risk_by_ensemble(df_scored, score_matrix=None, method_names=None):
    """Build risk counts for ALL 5 ensemble methods.

    Computes each method's fusion, assigns risk tiers, and returns a
    multi-row table so the user can compare ensemble strategies.
    """
    if "anomaly_score" not in df_scored.columns:
        return []

    score_cols = [c for c in df_scored.columns if c.startswith("score_")]
    if not score_cols:
        return []

    # Build score matrix from df if not provided
    if score_matrix is None:
        score_matrix = df_scored[score_cols].fillna(0).values
        method_names = [c.replace("score_", "") for c in score_cols]

    n = len(df_scored)
    thresholds = {"Critical": 0.8, "High": 0.6, "Medium": 0.4}

    def _tier_counts(scores):
        s = np.array(scores)
        c = int((s > 0.8).sum())
        h = int(((s > 0.6) & (s <= 0.8)).sum())
        m = int(((s > 0.4) & (s <= 0.6)).sum())
        l = int((s <= 0.4).sum())
        ar = f"{(s > 0.5).mean():.1%}"
        return c, h, m, l, ar

    rows = []

    # 1. Weighted Average (concordance-based — the default)
    wa_scores = df_scored["anomaly_score"].values
    c, h, m, l, ar = _tier_counts(wa_scores)
    # V6: Customer-level ensemble methods
    rows.append({"Ensemble Method": "Weighted Average (Concordance)", "Total Customers": n,
                 "Critical": c, "High": h, "Medium": m, "Low": l, "Anomaly Rate": ar})

    # 2. Max Score
    max_scores = np.clip(score_matrix.max(axis=1), 0, 1)
    c, h, m, l, ar = _tier_counts(max_scores)
    rows.append({"Ensemble Method": "Max Score", "Total Customers": n,
                 "Critical": c, "High": h, "Medium": m, "Low": l, "Anomaly Rate": ar})

    # 3. Voting (threshold 0.5)
    votes = (score_matrix > 0.5).sum(axis=1) / max(score_matrix.shape[1], 1)
    c, h, m, l, ar = _tier_counts(votes)
    rows.append({"Ensemble Method": "Majority Voting", "Total Customers": n,
                 "Critical": c, "High": h, "Medium": m, "Low": l, "Anomaly Rate": ar})

    # 4. Stacking (robust median + IQR)
    medians = np.median(score_matrix, axis=1)
    iqr = np.percentile(score_matrix, 75, axis=1) - np.percentile(score_matrix, 25, axis=1)
    stacking_scores = np.clip(0.6 * medians + 0.4 * iqr, 0, 1)
    c, h, m, l, ar = _tier_counts(stacking_scores)
    rows.append({"Ensemble Method": "Stacking (Median+IQR)", "Total Customers": n,
                 "Critical": c, "High": h, "Medium": m, "Low": l, "Anomaly Rate": ar})

    # 5. Rank Fusion
    try:
        from scipy.stats import rankdata
    except ImportError:
        # V24 FIX: fallback if scipy not installed
        def rankdata(a):
            return np.argsort(np.argsort(a)) + 1
    rank_matrix = np.zeros_like(score_matrix)
    for j in range(score_matrix.shape[1]):
        rank_matrix[:, j] = rankdata(score_matrix[:, j]) / score_matrix.shape[0]
    rank_scores = np.clip(rank_matrix.mean(axis=1), 0, 1)
    c, h, m, l, ar = _tier_counts(rank_scores)
    rows.append({"Ensemble Method": "Rank Fusion", "Total Customers": n,
                 "Critical": c, "High": h, "Medium": m, "Low": l, "Anomaly Rate": ar})

    return rows


# =============================================================================
# RESULTS UI BUILDER
# =============================================================================
def _build_results_ui(result, method_scores, layer_timings,
                       risk_by_family, risk_by_ensemble, data_source,
                       algo_tracker_rows=None, algo_df_scores=None, algo_phase_log=None):
    """Build the results section after successful pipeline run."""
    return dmc.Stack(
        [
            # ── Success Alert ──
            dmc.Alert(
                f"Pipeline completed in {result.execution_time_ms:.0f}ms "
                f"({'Sample' if data_source == 'sample' else 'Actual'} data)",
                color="green",
                icon=DashIconify(icon="mdi:check-circle"),
                withCloseButton=True,
            ),

            # ── KPI Summary ──
            dmc.SimpleGrid(
                cols={"base": 2, "md": 3, "lg": 6},
                spacing="sm",
                children=[
                    _kpi_badge("Records", f"{result.records_processed:,}", "mdi:database", "cyan"),
                    _kpi_badge("DQ Score", f"{result.dq_score:.0%}", "mdi:check-decagram", "green"),
                    _kpi_badge("Features", str(result.features_generated), "mdi:cog", "blue"),
                    _kpi_badge("Methods", str(result.methods_run), "mdi:magnify-scan", "indigo"),
                    _kpi_badge("Alerts", str(result.alerts_generated), "mdi:alert", "orange"),
                    _kpi_badge("Time", f"{result.execution_time_ms:.0f}ms", "mdi:timer", "teal"),
                ],
            ),

            # ── Risk Tier Distribution ──
            dmc.Paper(
                [
                    dmc.Group([
                        dmc.Text("Risk Tier Distribution", fw=600),
                        # V26: DataFrame variable name label
                        dmc.Badge("result.df_scored", color="violet", variant="outline", size="sm"),
                    ], gap="xs", mb="sm"),
                    dmc.Group(
                        [
                            dmc.Badge(f"Critical: {result.tier_distribution.get('Critical', 0)}", color="red", size="lg"),
                            dmc.Badge(f"High: {result.tier_distribution.get('High', 0)}", color="orange", size="lg"),
                            dmc.Badge(f"Medium: {result.tier_distribution.get('Medium', 0)}", color="yellow", size="lg"),
                            dmc.Badge(f"Low: {result.tier_distribution.get('Low', 0)}", color="green", size="lg"),
                        ],
                    ),
                ],
                p="md", radius="md", withBorder=True,
                style={"backgroundColor": "var(--bg-card)"},
            ),

            # ── Risk by Detection Family ──
            dmc.Paper(
                [
                    dmc.Text("Risk by Detection Family", fw=600, mb="sm"),
                    dmc.Text(
                        "Average score per family applied to risk thresholds (Critical >0.8, High >0.6, Medium >0.4, Low ≤0.4)",
                        size="xs", c="dimmed", mb="sm",
                    ),
                    dag.AgGrid(
                        id="pipeline-risk-by-family",
                        rowData=risk_by_family,
                        columnDefs=[
                            {"field": "Family", "headerName": "Detection Family", "sortable": True, "filter": True},
                            {"field": "Methods", "headerName": "Methods", "sortable": True},
                            {"field": "Critical", "headerName": "Critical", "sortable": True,
                             "cellStyle": {"color": "#FF5252", "fontWeight": 700}},
                            {"field": "High", "headerName": "High", "sortable": True,
                             "cellStyle": {"color": "#FF9800", "fontWeight": 600}},
                            {"field": "Medium", "headerName": "Medium", "sortable": True,
                             "cellStyle": {"color": "#FFC107"}},
                            {"field": "Low", "headerName": "Low", "sortable": True,
                             "cellStyle": {"color": "#4CAF50"}},
                        ],
                        defaultColDef={"flex": 1, "minWidth": 90, "resizable": True},
                        dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
                        style={"height": None, "width": "100%"},
                        className="ag-theme-alpine-dark",
                    ),
                ],
                p="md", radius="md", withBorder=True,
                style={"backgroundColor": "var(--bg-card)"},
            ),

            # ── Risk by Ensemble Method ──
            dmc.Paper(
                [
                    dmc.Text("Risk by Ensemble Method (Customer Level)", fw=600, mb="sm"),
                    dmc.Text(
                        "Final fused scores after ensemble aggregation at customer level, classified into risk tiers",
                        size="xs", c="dimmed", mb="sm",
                    ),
                    dag.AgGrid(
                        id="pipeline-risk-by-ensemble",
                        rowData=risk_by_ensemble,
                        columnDefs=[
                            {"field": "Ensemble Method", "headerName": "Ensemble Method", "sortable": True},
                            {"field": "Total Customers", "headerName": "Total Customers", "sortable": True},
                            {"field": "Critical", "headerName": "Critical", "sortable": True,
                             "cellStyle": {"color": "#FF5252", "fontWeight": 700}},
                            {"field": "High", "headerName": "High", "sortable": True,
                             "cellStyle": {"color": "#FF9800", "fontWeight": 600}},
                            {"field": "Medium", "headerName": "Medium", "sortable": True,
                             "cellStyle": {"color": "#FFC107"}},
                            {"field": "Low", "headerName": "Low", "sortable": True,
                             "cellStyle": {"color": "#4CAF50"}},
                            {"field": "Anomaly Rate", "headerName": "Anomaly Rate"},
                        ],
                        defaultColDef={"flex": 1, "minWidth": 100, "resizable": True},
                        dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
                        style={"height": None, "width": "100%"},
                        className="ag-theme-alpine-dark",
                    ),
                ],
                p="md", radius="md", withBorder=True,
                style={"backgroundColor": "var(--bg-card)"},
            ),

            # ── Per-Layer Timing ──
            _build_timing_section(layer_timings),

            # ── Per-Method Scores (AG Grid) ──
            dmc.Paper(
                [
                    dmc.Text("Per-Method Anomaly Scores", fw=600, mb="sm"),
                    dag.AgGrid(
                        id="pipeline-method-scores-grid",
                        rowData=method_scores,
                        columnDefs=[
                            {"field": "method", "headerName": "Method", "sortable": True, "filter": True},
                            {"field": "category", "headerName": "Category", "sortable": True, "filter": True},
                            {"field": "mean_score", "headerName": "Mean Score", "sortable": True,
                             "valueFormatter": {"function": "d3.format('.4f')(params.value)"}},
                            {"field": "max_score", "headerName": "Max Score", "sortable": True,
                             "valueFormatter": {"function": "d3.format('.4f')(params.value)"}},
                            {"field": "anomalies", "headerName": "Anomalies (>0.5)", "sortable": True},
                        ],
                        defaultColDef={"flex": 1, "minWidth": 120, "resizable": True},
                        dashGridOptions={"domLayout": "autoHeight", "animateRows": True, "pagination": True, "paginationPageSize": 10},
                        style={"height": None, "width": "100%"},
                        className="ag-theme-alpine-dark",
                    ),
                ],
                p="md", radius="md", withBorder=True,
                style={"backgroundColor": "var(--bg-card)"},
            ),

            # ── Scored Data Preview ──
            _build_scored_preview(result.df_scored),

            # ── L11: Algorithm Execution Tracker ──
            *(_build_algo_tracker_section(algo_tracker_rows, algo_phase_log) if algo_tracker_rows else []),

            # ── V30: Full Version Data-Flow DataFrame ──
            _build_full_dataflow(result, algo_tracker_rows),
        ],
        gap="md",
    )


def _kpi_badge(label, value, icon, color):
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.ThemeIcon(
                        DashIconify(icon=icon, width=20),
                        color=color, variant="light", size="lg",
                    ),
                    dmc.Stack(
                        [
                            dmc.Text(label, size="xs", c="dimmed"),
                            dmc.Text(value, size="lg", fw=700),
                        ],
                        gap=0,
                    ),
                ],
                gap="sm",
            ),
        ],
        p="sm", radius="md", withBorder=True,
        style={"backgroundColor": "var(--bg-card)"},
    )


def _build_timing_section(layer_timings):
    if not layer_timings:
        return dmc.Paper(
            [dmc.Text("Layer Timing", fw=600, mb="sm"),
             dmc.Text("Timing data not available for this run.", size="sm", c="dimmed")],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": "var(--bg-card)"},
        )

    rows = []
    for layer, elapsed in layer_timings.items():
        rows.append({"layer": layer, "time_s": round(elapsed, 3), "status": "✓"})

    return dmc.Paper(
        [
            dmc.Text("Layer Timing", fw=600, mb="sm"),
            dag.AgGrid(
                id="pipeline-timing-grid",
                rowData=rows,
                columnDefs=[
                    {"field": "layer", "headerName": "Layer", "flex": 2},
                    {"field": "time_s", "headerName": "Time (s)", "flex": 1},
                    {"field": "status", "headerName": "Status", "flex": 1},
                ],
                defaultColDef={"resizable": True},
                dashGridOptions={"domLayout": "autoHeight"},
                style={"height": None, "width": "100%"},
                className="ag-theme-alpine-dark",
            ),
        ],
        p="md", radius="md", withBorder=True,
        style={"backgroundColor": "var(--bg-card)"},
    )


def _build_scored_preview(df_scored):
    if df_scored is None or df_scored.empty:
        return None

    # Create a working copy
    preview = df_scored.copy()
    
    # Generate customer_name if it doesn't exist
    if "customer_name" not in preview.columns and "customer_id" in preview.columns:
        preview["customer_name"] = preview["customer_id"].apply(
            lambda x: f"Customer {str(x)}" if pd.notna(x) else "Unknown"
        )
    
    # Build display columns order: customer info + scores + risk tier
    display_cols = []
    
    # 1. Customer identification columns (always first)
    for col in ["customer_name", "customer_id", "party_id"]:
        if col in preview.columns:
            display_cols.append(col)
    
    # 2. Add anomaly score and risk tier
    if "anomaly_score" in preview.columns:
        display_cols.append("anomaly_score")
    if "risk_tier" in preview.columns:
        display_cols.append("risk_tier")
    
    # 3. Add ALL algorithm scores (all score_* columns)
    score_cols = sorted([c for c in preview.columns if c.startswith("score_")])
    display_cols.extend(score_cols)
    
    # If no display columns found, use all columns
    if not display_cols:
        display_cols = list(preview.columns)
    
    # Filter to only display columns
    preview = preview[display_cols].copy()
    
    # Mask sensitive IDs for privacy
    for col in ["party_id", "customer_id"]:
        if col in preview.columns:
            preview[col] = preview[col].apply(lambda x: f"****{str(x)[-4:]}" if pd.notna(x) else "")
    
    # Round numeric scores to 4 decimal places
    for col in preview.columns:
        if preview[col].dtype in [np.float64, np.float32]:
            preview[col] = preview[col].round(4)
    
    # Build column definitions with enhanced filtering
    col_defs = []
    for col in display_cols:
        col_def = {
            "field": col,
            "headerName": col.replace("_", " ").replace("score ", "").title(),
            "sortable": True,
            "filter": True,  # Enable column filter
            "floatingFilter": True,  # Show search box at top of each column
            "resizable": True,
            "minWidth": 120,
        }
        
        # Pin customer identification columns
        if col in ["customer_name", "customer_id", "party_id"]:
            col_def["pinned"] = "left"
            col_def["minWidth"] = 150
        
        # Highlight anomaly score and risk tier
        if col == "anomaly_score":
            col_def["cellStyle"] = {"fontWeight": 700, "color": "#FFD700"}
        elif col == "risk_tier":
            col_def["cellStyle"] = {"fontWeight": 700}
        
        col_defs.append(col_def)
    
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.Text("Scored Data Preview", fw=600),
                    dmc.Badge(f"{len(preview)} Customers", color="cyan", size="lg"),
                    dmc.Badge(f"{len(score_cols)} Algorithms", color="indigo", size="lg"),
                ],
                justify="space-between",
                mb="sm",
            ),
            dmc.Text(
                "All customers with calculated scores from all detection algorithms. Use column filters to search.",
                size="xs", c="dimmed", mb="sm",
            ),
            dag.AgGrid(
                id="pipeline-scored-preview",
                rowData=preview.to_dict("records"),
                columnDefs=col_defs,
                defaultColDef={
                    "flex": 1,
                    "minWidth": 120,
                    "filter": True,
                    "floatingFilter": True,  # Enable search box for all columns
                    "sortable": True,
                    "resizable": True,
                },
                dashGridOptions={
                    "pagination": True,
                    "paginationPageSize": 20,
                    "paginationPageSizeSelector": [10, 20, 50, 100],
                    "animateRows": True,
                    "enableCellTextSelection": True,
                    "suppressColumnVirtualisation": False,
                },
                style={"height": "600px", "width": "100%"},
                className="ag-theme-alpine-dark",
            ),
        ],
        p="md", radius="md", withBorder=True,
        style={"backgroundColor": "var(--bg-card)"},
    )


# =============================================================================
# V30: L11 ALGORITHM EXECUTION TRACKER SECTION
# =============================================================================
def _build_algo_tracker_section(algo_tracker_rows, algo_phase_log):
    """Build the L11 algorithm execution tracker UI sections."""
    sections = []

    if algo_tracker_rows:
        n_ok = sum(1 for r in algo_tracker_rows if r.get("Status") == "OK")
        n_fail = sum(1 for r in algo_tracker_rows if r.get("Status") == "FAIL")
        n_skip = sum(1 for r in algo_tracker_rows if r.get("Status") == "SKIP")
        total_anomalies = sum(r.get("Anomalies", 0) for r in algo_tracker_rows
                              if isinstance(r.get("Anomalies"), (int, float)))

        header_badges = [
            DashIconify(icon="mdi:brain", width=22, color="#ae3ec9"),
            dmc.Text("L11 — Algorithm Execution Tracker", fw=700, size="lg"),
            dmc.Badge(f"{n_ok} OK", color="green", variant="filled", size="sm"),
        ]
        if n_fail:
            header_badges.append(dmc.Badge(f"{n_fail} Fail", color="red", variant="filled", size="sm"))
        if n_skip:
            header_badges.append(dmc.Badge(f"{n_skip} Skip", color="gray", variant="filled", size="sm"))
        header_badges.append(dmc.Badge(f"{total_anomalies} Total Anomalies", color="orange", variant="light", size="sm"))

        sections.append(
            dmc.Paper(
                [
                    dmc.Group(header_badges, gap="xs", mb="sm"),
                    dag.AgGrid(
                        rowData=algo_tracker_rows,
                        columnDefs=[
                            {"field": "Algorithm", "headerName": "Algorithm", "sortable": True, "filter": True, "minWidth": 180},
                            {"field": "Family", "headerName": "Family", "sortable": True, "filter": True},
                            {"field": "Status", "headerName": "Status", "sortable": True,
                             "cellStyle": {"function": "params.value === 'OK' ? {'color': '#4CAF50', 'fontWeight': 700} : params.value === 'FAIL' ? {'color': '#FF5252', 'fontWeight': 700} : {'color': '#9E9E9E'}"}},
                            {"field": "Anomalies", "headerName": "Anomalies", "sortable": True},
                            {"field": "Runtime (s)", "headerName": "Runtime (s)", "sortable": True},
                            {"field": "Mean Score", "headerName": "Mean Score", "sortable": True,
                             "valueFormatter": {"function": "d3.format('.4f')(params.value)"}},
                            {"field": "Max Score", "headerName": "Max Score", "sortable": True,
                             "valueFormatter": {"function": "d3.format('.4f')(params.value)"}},
                        ],
                        defaultColDef={"flex": 1, "minWidth": 100, "resizable": True},
                        dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
                        style={"height": None, "width": "100%"},
                        className="ag-theme-alpine-dark",
                    ),
                ],
                p="md", radius="md", withBorder=True,
                style={"backgroundColor": "var(--bg-card)", "borderLeft": "3px solid #ae3ec9"},
            )
        )

    if algo_phase_log:
        phase_rows = [{"Phase": p.get("phase", ""), "Duration (s)": round(p.get("duration_s", 0), 3),
                        "Status": p.get("status", ""), "Details": p.get("details", "")}
                       for p in algo_phase_log]
        sections.append(
            dmc.Paper(
                [
                    dmc.Text("Algo Execution Phase Log", fw=600, mb="sm"),
                    dag.AgGrid(
                        rowData=phase_rows,
                        columnDefs=[
                            {"field": "Phase", "sortable": True, "minWidth": 200},
                            {"field": "Duration (s)", "sortable": True},
                            {"field": "Status", "sortable": True},
                            {"field": "Details", "minWidth": 300},
                        ],
                        defaultColDef={"flex": 1, "resizable": True},
                        dashGridOptions={"domLayout": "autoHeight"},
                        style={"height": None, "width": "100%"},
                        className="ag-theme-alpine-dark",
                    ),
                ],
                p="md", radius="md", withBorder=True,
                style={"backgroundColor": "var(--bg-card)"},
            )
        )

    return sections


# =============================================================================
# V30: FULL VERSION DATA-FLOW DATAFRAME
# =============================================================================
def _build_full_dataflow(result, algo_tracker_rows=None):
    """V30: Build the full end-to-end data-flow DataFrame showing every pipeline stage."""
    flow_rows = [
        {"Stage": "L01 \u2014 Raw Data", "Variable": "df_raw / sources",
         "Shape": f"{result.records_processed} \u00d7 (raw)", "Module": "DataVault.load_sources()",
         "Description": "Raw data ingestion from uploaded CSV/Excel or generated sample"},
        {"Stage": "L06 \u2014 DQ Processing", "Variable": "df_dq",
         "Shape": f"{result.records_processed} \u00d7 (validated)", "Module": "DQProcessingLayer",
         "Description": "Data quality: nulls, duplicates, type coercion, outlier flags"},
        {"Stage": "L07 \u2014 Encode", "Variable": "df_encoded",
         "Shape": f"{result.records_processed} \u00d7 {result.features_generated}", "Module": "EncodingLayer (WOE+Freq+Target)",
         "Description": "Categorical encoding: WOE, frequency, target encoding for string columns"},
        {"Stage": "L08 \u2014 Transform", "Variable": "df_transformed",
         "Shape": f"{result.records_processed} \u00d7 {result.features_generated}", "Module": "TransformLayer (Yeo-Johnson/log1p)",
         "Description": "Skewness correction: auto Yeo-Johnson or log1p per column"},
        {"Stage": "L09 \u2014 Scale", "Variable": "scaled_matrices{}",
         "Shape": f"{result.records_processed} \u00d7 {result.features_generated} \u00d7 4 scalers", "Module": "ScalingLayer (Std+Robust+MinMax+Orig)",
         "Description": "Multi-scaler: Standard, Robust, MinMax + Original \u2192 4 parallel matrices"},
        {"Stage": "L10 \u2014 Reduce", "Variable": "X_reduced / PreMaster",
         "Shape": f"{result.records_processed} \u00d7 (reduced)", "Module": "ReductionLayer (PCA/UMAP/t-SNE/Hybrid)",
         "Description": "Dimensionality reduction to target dims; saves premaster.parquet"},
    ]

    if algo_tracker_rows:
        n_ok = sum(1 for r in algo_tracker_rows if r.get("Status") == "OK")
        flow_rows.append({
            "Stage": "L11 \u2014 Algo Execution", "Variable": "algo_result.raw_scores",
            "Shape": f"{result.records_processed} \u00d7 {n_ok} algo scores",
            "Module": f"AlgorithmExecutionEngine ({n_ok} algos)",
            "Description": f"{n_ok} algorithms across 8 families (SUOD-optimized batch + sequential fallback)"
        })

    flow_rows.extend([
        {"Stage": "L11 \u2014 Detect", "Variable": "score_matrix",
         "Shape": f"{result.records_processed} \u00d7 {result.methods_run} methods", "Module": "DetectionLayer (20 methods)",
         "Description": f"{result.methods_run} detection methods across 8 families \u2192 per-row scores [0,1]"},
        {"Stage": "L13 \u2014 Ensemble", "Variable": "anomaly_score",
         "Shape": f"{result.records_processed} \u00d7 1 (fused)", "Module": "EnsembleLayer (weighted_avg/max/voting/stacking)",
         "Description": "Concordance-weighted fusion of all method scores \u2192 single anomaly score per customer"},
        {"Stage": "L14 \u2014 Output", "Variable": "df_scored / result",
         "Shape": f"{result.records_processed} \u00d7 (all cols + scores)", "Module": "OutputLayer \u2192 DataVault",
         "Description": "Final scored DataFrame with risk tiers, persisted to scored.parquet + pipeline_result.json"},
    ])

    return dmc.Paper(
        [
            dmc.Group([
                DashIconify(icon="mdi:flow-chart", width=22, color="#22b8cf"),
                dmc.Text("Full Version Data-Flow DataFrame (V30)", fw=700, size="lg"),
                dmc.Badge("End-to-End", color="cyan", variant="outline", size="sm"),
            ], gap="xs", mb="sm"),
            dmc.Text(
                "Complete pipeline data flow from raw ingestion through 20-algorithm execution to final scored output.",
                size="xs", c="dimmed", mb="sm",
            ),
            dag.AgGrid(
                rowData=flow_rows,
                columnDefs=[
                    {"field": "Stage", "headerName": "Stage", "sortable": True, "filter": True, "minWidth": 180,
                     "cellStyle": {"fontWeight": 700, "color": "#22b8cf"}},
                    {"field": "Variable", "headerName": "Python Variable", "minWidth": 200},
                    {"field": "Shape", "headerName": "Shape (N \u00d7 K)", "minWidth": 200},
                    {"field": "Module", "headerName": "Engine / Module", "minWidth": 250},
                    {"field": "Description", "headerName": "Description", "minWidth": 350,
                     "wrapText": True, "autoHeight": True},
                ],
                defaultColDef={"flex": 1, "resizable": True},
                dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
                style={"height": None, "width": "100%"},
                className="ag-theme-alpine-dark",
            ),
        ],
        p="md", radius="md", withBorder=True,
        style={"backgroundColor": "var(--bg-card)", "borderLeft": "3px solid #22b8cf"},
    )


# =============================================================================
# V30: AGENT RECOMMEND CALLBACK
# =============================================================================
@callback(
    Output("pipeline-agent-recommend-result", "children"),
    Input("pipeline-btn-agent-recommend", "n_clicks"),
    State("pipeline-data-source", "data"),
    prevent_initial_call=True,
)
def agent_recommend(n_clicks, data_source):
    """V30: Agent auto-selects optimal algorithms based on data characteristics."""
    try:
        from utils.data_io import data_vault
        df = data_vault.get_data()
        n_rows = len(df) if df is not None else 100
        n_cols = len(df.columns) if df is not None else 20
        has_graph = False
        has_temporal = any(c for c in (df.columns if df is not None else [])
                          if "date" in c.lower() or "time" in c.lower())
        has_amount = any(c for c in (df.columns if df is not None else [])
                         if "amount" in c.lower() or "balance" in c.lower())

        from utils.algo_execution_engine import agent_auto_select, ALGO_TO_FAMILY
        recommended = agent_auto_select(
            n_rows=n_rows, n_features=n_cols,
            has_graph=has_graph, has_temporal=has_temporal, has_amount=has_amount
        )

        badges = []
        color_map = {"Statistical": "blue", "Tree": "green", "Density": "orange",
                     "Distance": "cyan", "Clustering": "pink", "Graph": "grape",
                     "TimeSeries": "yellow", "DeepLearning": "red"}
        for algo_name in recommended:
            family = ALGO_TO_FAMILY.get(algo_name, "Unknown")
            badges.append(dmc.Badge(f"{algo_name} ({family})",
                                     color=color_map.get(family, "gray"),
                                     variant="light", size="sm"))

        return dmc.Stack([
            dmc.Text(f"Agent recommends {len(recommended)} algorithms for your data "
                     f"({n_rows} rows, {n_cols} features):",
                     size="xs", fw=600, c="dimmed"),
            dmc.Group(badges, gap="xs"),
        ], gap="xs", mt="xs")
    except Exception as e:
        return dmc.Text(f"Agent error: {str(e)[:200]}", size="xs", c="red")


# =============================================================================
# LOAD SAVED RESULTS FROM VAULT ON PAGE LOAD
# =============================================================================
def _build_results_from_vault():
    """Rebuild the results UI from persisted vault data (JSON + scored parquet).

    This is the persistence layer — when the user navigates away and
    comes back, this function re-renders the last successful pipeline run.
    """
    from utils.data_io import data_vault

    result_json = data_vault.load_pipeline_result()
    if not result_json or not result_json.get("success"):
        return None

    df_scored = data_vault.get_scored_data()

    # Pull values from the JSON dict
    exec_time = result_json.get("execution_time_ms", 0)
    data_source = result_json.get("data_source", "unknown")
    records = result_json.get("records_processed", 0)
    dq_score = result_json.get("dq_score", 0)
    features = result_json.get("features_generated", 0)
    methods_run = result_json.get("methods_run", 0)
    alerts = result_json.get("alerts_generated", 0)
    tier_dist = result_json.get("tier_distribution", {})
    method_scores = result_json.get("method_scores", [])
    layer_timings = result_json.get("layer_timings", {})
    risk_by_family = result_json.get("risk_by_family", [])
    risk_by_ensemble = result_json.get("risk_by_ensemble", [])
    timestamp = result_json.get("timestamp", "")

    # Build the scored data preview if we have scored data
    preview_section = None
    if df_scored is not None and not df_scored.empty:
        preview_section = _build_scored_preview(df_scored)

    children = [
        # ── Persisted Alert ──
        dmc.Alert(
            f"Last pipeline run completed in {exec_time:.0f}ms "
            f"({'Sample' if data_source == 'sample' else 'Actual'} data) "
            f"— {str(timestamp)[:19] if timestamp else ''}",
            color="teal",
            icon=DashIconify(icon="mdi:history"),
            withCloseButton=True,
        ),

        # ── KPI Summary ──
        dmc.SimpleGrid(
            cols={"base": 2, "md": 3, "lg": 6},
            spacing="sm",
            children=[
                _kpi_badge("Records", f"{records:,}", "mdi:database", "cyan"),
                _kpi_badge("DQ Score", f"{dq_score:.0%}" if isinstance(dq_score, float) else str(dq_score), "mdi:check-decagram", "green"),
                _kpi_badge("Features", str(features), "mdi:cog", "blue"),
                _kpi_badge("Methods", str(methods_run), "mdi:magnify-scan", "indigo"),
                _kpi_badge("Alerts", str(alerts), "mdi:alert", "orange"),
                _kpi_badge("Time", f"{exec_time:.0f}ms", "mdi:timer", "teal"),
            ],
        ),

        # ── Risk Tier Distribution ──
        dmc.Paper(
            [
                dmc.Text("Risk Tier Distribution", fw=600, mb="sm"),
                dmc.Group(
                    [
                        dmc.Badge(f"Critical: {tier_dist.get('Critical', 0)}", color="red", size="lg"),
                        dmc.Badge(f"High: {tier_dist.get('High', 0)}", color="orange", size="lg"),
                        dmc.Badge(f"Medium: {tier_dist.get('Medium', 0)}", color="yellow", size="lg"),
                        dmc.Badge(f"Low: {tier_dist.get('Low', 0)}", color="green", size="lg"),
                    ],
                ),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": "var(--bg-card)"},
        ),

        # ── Risk by Detection Family ──
        dmc.Paper(
            [
                dmc.Text("Risk by Detection Family", fw=600, mb="sm"),
                dag.AgGrid(
                    rowData=risk_by_family,
                    columnDefs=[
                        {"field": "Family", "headerName": "Detection Family", "sortable": True, "filter": True},
                        {"field": "Methods", "headerName": "Methods", "sortable": True},
                        {"field": "Critical", "sortable": True, "cellStyle": {"color": "#FF5252", "fontWeight": 700}},
                        {"field": "High", "sortable": True, "cellStyle": {"color": "#FF9800", "fontWeight": 600}},
                        {"field": "Medium", "sortable": True, "cellStyle": {"color": "#FFC107"}},
                        {"field": "Low", "sortable": True, "cellStyle": {"color": "#4CAF50"}},
                    ],
                    defaultColDef={"flex": 1, "minWidth": 90, "resizable": True},
                    dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
                    style={"height": None, "width": "100%"},
                    className="ag-theme-alpine-dark",
                ),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": "var(--bg-card)"},
        ),

        # ── Risk by Ensemble Method ──
        dmc.Paper(
            [
                dmc.Text("Risk by Ensemble Method", fw=600, mb="sm"),
                dag.AgGrid(
                    rowData=risk_by_ensemble,
                    columnDefs=[
                        {"field": "Ensemble Method", "sortable": True},
                        {"field": "Total Customers", "sortable": True},
                        {"field": "Critical", "sortable": True, "cellStyle": {"color": "#FF5252", "fontWeight": 700}},
                        {"field": "High", "sortable": True, "cellStyle": {"color": "#FF9800", "fontWeight": 600}},
                        {"field": "Medium", "sortable": True, "cellStyle": {"color": "#FFC107"}},
                        {"field": "Low", "sortable": True, "cellStyle": {"color": "#4CAF50"}},
                        {"field": "Anomaly Rate"},
                    ],
                    defaultColDef={"flex": 1, "minWidth": 100, "resizable": True},
                    dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
                    style={"height": None, "width": "100%"},
                    className="ag-theme-alpine-dark",
                ),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": "var(--bg-card)"},
        ),

        # ── Per-Layer Timing ──
        _build_timing_section(layer_timings),

        # ── Per-Method Scores ──
        dmc.Paper(
            [
                dmc.Text("Per-Method Anomaly Scores", fw=600, mb="sm"),
                dag.AgGrid(
                    rowData=method_scores,
                    columnDefs=[
                        {"field": "method", "headerName": "Method", "sortable": True, "filter": True},
                        {"field": "category", "headerName": "Category", "sortable": True, "filter": True},
                        {"field": "mean_score", "headerName": "Mean Score", "sortable": True,
                         "valueFormatter": {"function": "d3.format('.4f')(params.value)"}},
                        {"field": "max_score", "headerName": "Max Score", "sortable": True,
                         "valueFormatter": {"function": "d3.format('.4f')(params.value)"}},
                        {"field": "anomalies", "headerName": "Anomalies (>0.5)", "sortable": True},
                    ],
                    defaultColDef={"flex": 1, "minWidth": 120, "resizable": True},
                    dashGridOptions={"domLayout": "autoHeight", "animateRows": True,
                                     "pagination": True, "paginationPageSize": 10},
                    style={"height": None, "width": "100%"},
                    className="ag-theme-alpine-dark",
                ),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": "var(--bg-card)"},
        ),
    ]

    # ── Scored Data Preview ──
    if preview_section is not None:
        children.append(preview_section)

    # ── V30: Algorithm Execution Tracker (persisted) ──
    algo_tracker_rows = result_json.get("algo_tracker_rows", [])
    algo_phase_log = result_json.get("algo_phase_log", [])
    if algo_tracker_rows:
        children.extend(_build_algo_tracker_section(algo_tracker_rows, algo_phase_log))

    return dmc.Stack(children, gap="md")


# =============================================================================
# CALLBACK: Load saved results on page load
# =============================================================================
@callback(
    Output("pipeline-results-area", "children", allow_duplicate=True),
    Input("pipeline-load-trigger", "n_intervals"),
    prevent_initial_call=True,
)
def load_saved_results(n):
    """On page load, render last pipeline results from vault so they persist."""
    if n is None or n < 1:
        return dash.no_update
    try:
        saved_ui = _build_results_from_vault()
        if saved_ui is not None:
            return saved_ui
    except Exception:
        pass
    return dash.no_update
