"""
Data Sources Page - VERSION 19 SPEC-DRIVEN
============================================
PRINCIPLE 1: BASE table is the ONLY mandatory input
PRINCIPLE 2: 12 integrated table slots (Base + 11 optional)
PRINCIPLE 3: 10 optional config file slots with intelligent defaults
PRINCIPLE 4: Spec-driven rollup-before-join pipeline
PRINCIPLE 5: Separate GRAPH_DATA & TEMPORAL_DATA extraction
PRINCIPLE 6: Configurable BASE_KEY (default: cust_id)

V19 Enhancements:
  - RollupEngine: 4 strategies (DIRECT/AGGREGATE/TAKE_LATEST/AUTO_DETECT)
  - 10 config file upload slots (all optional with defaults)
  - GRAPH_DATA & TEMPORAL_DATA extracted separately (NOT joined to MASTER)
  - Processing log, data quality report, data availability dashboard
  - Handle completely missing tables and blank columns gracefully
  - Downloadable exports (MASTER_TABLE.csv, DATA_QUALITY_REPORT.csv, etc.)
"""

import dash
from dash import html, dcc, callback, Input, Output, State, ctx, ALL
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import dash_ag_grid as dag
import pandas as pd
import numpy as np
import io, base64, sys, json, zipfile
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS, APP, COLUMNS
from utils.schema_detector import SchemaDetector, ColumnType
from utils.column_resolver import resolve
from layers.rollup_engine import (
    RollupEngine, MasterBuildResult, GraphData, TemporalData,
    DEFAULT_BASE_KEY, DEFAULT_BASE_KEY_ALIASES, DEFAULT_GRAIN_CONFIG,
    TABULAR_TABLES, EXTRACT_TABLES,
)

dash.register_page(__name__, path="/sources", name="Data Sources", order=1)


# =============================================================================
# CONSTANTS
# =============================================================================
# V13: Expanded PII mask columns from config — bank compliance
from config import PII as _PII_CONFIG
MASK_COLUMNS = set(_PII_CONFIG.MASKED_COLUMNS) | {"customer_id", "account_id"}

TABLE_SLOTS = [
    {"name": "BASE",          "icon": "mdi:database",         "color": "cyan",   "label": "Base",          "mandatory": True,  "desc": "Primary key + entity (Required)"},
    {"name": "transactions",  "icon": "mdi:swap-horizontal",  "color": "blue",   "label": "Transactions",  "mandatory": False, "desc": "Transaction-level data"},
    {"name": "customer_party","icon": "mdi:account-group",    "color": "indigo", "label": "Customer/Party","mandatory": False, "desc": "Customer demographics"},
    {"name": "accounts",      "icon": "mdi:bank",             "color": "green",  "label": "Accounts",      "mandatory": False, "desc": "Account-level data"},
    {"name": "alerts",        "icon": "mdi:alert",            "color": "orange", "label": "Alerts",        "mandatory": False, "desc": "Alert history"},
    {"name": "cases",         "icon": "mdi:briefcase",        "color": "red",    "label": "Cases",         "mandatory": False, "desc": "Investigation cases"},
    {"name": "kyc",           "icon": "mdi:shield-check",     "color": "teal",   "label": "KYC",           "mandatory": False, "desc": "KYC compliance data"},
    {"name": "watchlist",     "icon": "mdi:shield-search",    "color": "pink",   "label": "Watchlist",     "mandatory": False, "desc": "Sanctions/PEP matches"},
    {"name": "relationships", "icon": "mdi:graph-outline",    "color": "violet", "label": "Relationships", "mandatory": False, "desc": "Network graph (Excel: edges + nodes)"},
    {"name": "temporal",      "icon": "mdi:chart-timeline",   "color": "grape",  "label": "Temporal",      "mandatory": False, "desc": "Time series (Excel: long + wide)"},
    {"name": "others1",       "icon": "mdi:table-plus",       "color": "gray",   "label": "Others1",       "mandatory": False, "desc": "Custom table slot 1"},
    {"name": "others2",       "icon": "mdi:table-plus",       "color": "gray",   "label": "Others2",       "mandatory": False, "desc": "Custom table slot 2"},
]

SLOT_LOOKUP = {s["name"]: s for s in TABLE_SLOTS}

# V20: Multi-sheet slots — single UI slot maps to multiple vault sub-tables
# Upload/download as ONE Excel file with two sheets; stored internally as separate parquets
MULTI_SHEET_SLOTS = {
    "relationships": {"edges": "relationships_edges", "nodes": "relationships_nodes"},
    "temporal":      {"long": "temporal_long",        "wide": "temporal_wide"},
}

# V19: 10 Config File Slots (all optional with intelligent defaults)
CONFIG_SLOTS = [
    {"name": "EXCLUDE",             "icon": "mdi:filter-remove",     "color": "red",    "desc": "Columns/tables to exclude (PII, IDs, system fields)"},
    {"name": "FEATURE_MAP",         "icon": "mdi:rename-box",        "color": "blue",   "desc": "Column renames + transformations (LOG, SQRT)"},
    {"name": "TABLE_MAP",           "icon": "mdi:table-arrow-right", "color": "green",  "desc": "Join keys, join types, table optionality"},
    {"name": "METHOD_CONFIG",       "icon": "mdi:cog",               "color": "orange", "desc": "Anomaly detection algorithms, weights"},
    {"name": "ALGO_FEATURE_MAP",    "icon": "mdi:function-variant",  "color": "grape",  "desc": "Required features per algorithm"},
    {"name": "FEATURE_STORE",       "icon": "mdi:database-search",   "color": "teal",   "desc": "Feature metadata: meanings, formats, PII flags"},
    {"name": "METADATA",            "icon": "mdi:information",       "color": "indigo", "desc": "System parameters: thresholds, paths, settings"},
    {"name": "CUSTOM_CONFIG",       "icon": "mdi:tune",              "color": "yellow", "desc": "User-defined key-value settings"},
    {"name": "TABLE_GRAIN_DETECTION", "icon": "mdi:grain",           "color": "cyan",   "desc": "Rollup strategy per table + target grain level"},
    {"name": "FEATURE_ENGINEERING", "icon": "mdi:auto-fix",          "color": "pink",   "desc": "Feature transformations: aggregations, derived features"},
]

CONFIG_LOOKUP = {c["name"]: c for c in CONFIG_SLOTS}

# V19: Global config store (populated by uploads or auto-loaded from disk)
_config_store: Dict[str, pd.DataFrame] = {}

# V20: Auto-load config CSVs from disk on startup (persist across restarts)
def _auto_load_configs():
    """Load config tables from disk if they exist (from previous generate runs)."""
    _cfg_names = [s["name"] for s in CONFIG_SLOTS]
    for cfg_name in _cfg_names:
        csv_path = PATHS.DATA_SOURCES / f"config_{cfg_name}.csv"
        if csv_path.exists():
            try:
                _config_store[cfg_name] = pd.read_csv(csv_path)
            except Exception:
                pass
    if _config_store:
        import logging as _lg
        _lg.getLogger("apurbadas.data_sources").info(
            f"Auto-loaded {len(_config_store)} config tables from disk: {list(_config_store.keys())}"
        )

_auto_load_configs()

# V19: Global graph/temporal output store
_graph_data_store: Optional[GraphData] = None
_temporal_data_store: Optional[TemporalData] = None
_last_build_result: Optional[MasterBuildResult] = None


# =============================================================================
# V20: Multi-sheet slot helpers
# =============================================================================
def _slot_status_widget(slot_name, sources):
    """Build status widget for a slot — handles both regular and multi-sheet slots."""
    if slot_name in MULTI_SHEET_SLOTS:
        sub_map = MULTI_SHEET_SLOTS[slot_name]
        parts = []
        for sheet_name, vault_key in sub_map.items():
            if vault_key in sources and sources[vault_key] is not None:
                parts.append(f"{len(sources[vault_key]):,} {sheet_name}")
        if parts:
            return dmc.Text(" | ".join(parts), size="10px", c="green", ta="center", fw=600)
        return dmc.Text("Empty", size="10px", c="dimmed", ta="center")
    elif slot_name in sources:
        return dmc.Text(f"{len(sources[slot_name]):,} rows", size="10px", c="green", ta="center", fw=600)
    return dmc.Text("Empty", size="10px", c="dimmed", ta="center")


def _slot_has_data(slot_name, sources):
    """Check if a slot has data — handles multi-sheet slots."""
    if slot_name in MULTI_SHEET_SLOTS:
        return any(vk in sources for vk in MULTI_SHEET_SLOTS[slot_name].values())
    return slot_name in sources


def _slot_total_rows(slot_name, sources):
    """Get total row count for a slot — handles multi-sheet slots."""
    if slot_name in MULTI_SHEET_SLOTS:
        return sum(len(sources[vk]) for vk in MULTI_SHEET_SLOTS[slot_name].values() if vk in sources)
    return len(sources[slot_name]) if slot_name in sources else 0


def _slot_get_primary_df(slot_name, sources):
    """Get the primary DataFrame for a slot (first sub-table for multi-sheet)."""
    if slot_name in MULTI_SHEET_SLOTS:
        for vk in MULTI_SHEET_SLOTS[slot_name].values():
            if vk in sources:
                return sources[vk]
        return None
    return sources.get(slot_name)


# =============================================================================
# V20: Temporal long ↔ wide auto-conversion helpers
# =============================================================================
def _temporal_long_to_wide(long_df):
    """
    Convert temporal LONG → WIDE.
    Expects: cust_id, period_date, amount, [transaction_count, ...]
    Produces: cust_id, month_YYYY_MM, ... (pivoting 'amount' by 'period_date')
    """
    # Detect the period column (period_date, period, date, month …)
    period_col = None
    for c in long_df.columns:
        if c.lower() in ('period_date', 'period', 'date', 'month', 'year_month'):
            period_col = c
            break
    if period_col is None:
        # Fallback: second column
        period_col = long_df.columns[1] if len(long_df.columns) > 1 else None
    if period_col is None:
        return long_df.copy()

    # Detect key column
    key_col = 'cust_id' if 'cust_id' in long_df.columns else long_df.columns[0]

    # Detect value column (amount preferred, else first numeric)
    if 'amount' in long_df.columns:
        val_col = 'amount'
    else:
        num_cols = long_df.select_dtypes(include=[np.number]).columns.tolist()
        num_cols = [c for c in num_cols if c != key_col]
        val_col = num_cols[0] if num_cols else None
    if val_col is None:
        return long_df.copy()

    try:
        wide = long_df.pivot_table(
            index=key_col, columns=period_col, values=val_col, aggfunc='sum'
        ).reset_index()
        wide.columns = [
            f"month_{str(c).replace('-', '_')}" if c != key_col else c
            for c in wide.columns
        ]
        return wide
    except Exception:
        return long_df.copy()


def _temporal_wide_to_long(wide_df):
    """
    Convert temporal WIDE → LONG.
    Expects: cust_id, month_YYYY_MM, month_YYYY_MM, ...
    Produces: cust_id, period_date, amount
    """
    key_col = 'cust_id' if 'cust_id' in wide_df.columns else wide_df.columns[0]
    month_cols = [c for c in wide_df.columns if c != key_col]
    if not month_cols:
        return wide_df.copy()

    try:
        long = wide_df.melt(id_vars=[key_col], value_vars=month_cols,
                            var_name='period_date', value_name='amount')
        # Convert 'month_2025_01' → '2025-01'
        long['period_date'] = long['period_date'].str.replace(r'^month_', '', regex=True).str.replace('_', '-')
        long = long.sort_values([key_col, 'period_date']).reset_index(drop=True)
        return long
    except Exception:
        return wide_df.copy()


def _temporal_auto_derive(loaded_sheets, sub_map, sources_dir, data_vault):
    """
    Auto-derive the missing temporal sheet from the one that was uploaded.
    If only 'long' → derive 'wide'.  If only 'wide' → derive 'long'.
    Both present → no-op.
    """
    has_long = "long" in loaded_sheets
    has_wide = "wide" in loaded_sheets
    if has_long and not has_wide:
        wide_df = _temporal_long_to_wide(loaded_sheets["long"])
        vk = sub_map["wide"]
        wide_df.to_parquet(sources_dir / f"{vk}.parquet", index=False)
        data_vault._sources[vk] = wide_df
    elif has_wide and not has_long:
        long_df = _temporal_wide_to_long(loaded_sheets["wide"])
        vk = sub_map["long"]
        long_df.to_parquet(sources_dir / f"{vk}.parquet", index=False)
        data_vault._sources[vk] = long_df


# =============================================================================
# VALIDATION HELPERS
# =============================================================================
def validate_base_table(df: pd.DataFrame) -> Tuple[bool, str]:
    """Validate BASE table has required role columns (V8 role-based)."""
    pk_col = resolve(df, 'primary_key')
    if pk_col is None:
        return False, f"BASE table missing a primary key column. Expected one of: {COLUMNS.ROLE_ALIASES.get('primary_key', [])}"
    if df[pk_col].duplicated().any():
        return False, f"BASE table has duplicate values in '{pk_col}'"
    if df[pk_col].isnull().any():
        return False, f"BASE table has null values in '{pk_col}'"
    return True, ""


def can_join_to_base(df: pd.DataFrame) -> bool:
    """Check if table has a primary_key-like column for joining."""
    return resolve(df, 'primary_key') is not None


def _safe_build(fn, *args, label="section"):
    """Safely call a UI builder function, returning an error alert on failure."""
    try:
        return fn(*args)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return dmc.Alert(
            f"Error building {label}: {str(e)[:300]}",
            color="red", variant="light",
            icon=DashIconify(icon="mdi:alert-circle"),
        )


def get_dynamic_table_icon(table_name: str) -> Dict[str, str]:
    """Assign icon/color based on table name keywords."""
    if table_name in SLOT_LOOKUP:
        s = SLOT_LOOKUP[table_name]
        return {"icon": s["icon"], "color": s["color"]}
    name_lower = table_name.lower()
    if 'base' in name_lower:    return {"icon": "mdi:database", "color": "cyan"}
    elif 'transaction' in name_lower or 'txn' in name_lower: return {"icon": "mdi:swap-horizontal", "color": "blue"}
    elif 'customer' in name_lower or 'party' in name_lower:  return {"icon": "mdi:account-group", "color": "indigo"}
    elif 'account' in name_lower:  return {"icon": "mdi:bank", "color": "green"}
    elif 'alert' in name_lower:    return {"icon": "mdi:alert", "color": "orange"}
    elif 'case' in name_lower:     return {"icon": "mdi:briefcase", "color": "red"}
    elif 'kyc' in name_lower:      return {"icon": "mdi:shield-check", "color": "teal"}
    elif 'watchlist' in name_lower: return {"icon": "mdi:shield-search", "color": "pink"}
    elif 'relationship' in name_lower or 'network' in name_lower: return {"icon": "mdi:graph-outline", "color": "violet"}
    elif 'temporal' in name_lower or 'time' in name_lower: return {"icon": "mdi:chart-timeline", "color": "grape"}
    return {"icon": "mdi:table", "color": "gray"}


def mask_id(val):
    s = str(val)
    return f"****{s[-4:]}" if len(s) > 4 else s


def _parse_upload(contents, filename):
    """Parse uploaded file contents into DataFrame."""
    content_string = contents.split(",")[1]
    decoded = base64.b64decode(content_string)
    if filename.endswith(".csv"):
        return pd.read_csv(io.StringIO(decoded.decode("utf-8")))
    elif filename.endswith((".xlsx", ".xls")):
        return pd.read_excel(io.BytesIO(decoded))
    elif filename.endswith(".parquet"):
        return pd.read_parquet(io.BytesIO(decoded))
    raise ValueError(f"Unsupported format: {filename}")


# =============================================================================
# UI BUILDER HELPERS
# =============================================================================
def build_ag_grid(df, table_name, max_rows=None, page_size=20):
    """Build AG Grid preview with pagination + V20 floating column search."""
    preview = df if max_rows is None else df.head(max_rows)
    preview = preview.copy()
    for col in preview.columns:
        if col in MASK_COLUMNS:
            preview[col] = preview[col].apply(mask_id)
    col_defs = []
    for c in preview.columns:
        dtype = str(preview[c].dtype)
        if "int" in dtype or "float" in dtype:
            col_filter = "agNumberColumnFilter"
        elif "datetime" in dtype:
            col_filter = "agDateColumnFilter"
        else:
            col_filter = "agTextColumnFilter"
        col_defs.append({"field": c, "sortable": True, "filter": col_filter, "floatingFilter": True, "resizable": True})
    return dag.AgGrid(
        id={"type": "source-grid", "table": table_name},
        rowData=preview.to_dict("records"),
        columnDefs=col_defs,
        defaultColDef={"flex": 1, "minWidth": 120},
        dashGridOptions={
            "animateRows": True,
            "pagination": True,
            "paginationPageSize": page_size,
            "paginationPageSizeSelector": [10, 20, 50, 100],
        },
        style={"height": "520px", "width": "100%"},
        className="ag-theme-alpine-dark",
    )


def _build_master_ag_grid(df, page_size=20):
    """V20: Build AG Grid for MASTER table with per-column floating filter search."""
    preview = df.copy()
    for col in preview.columns:
        if col in MASK_COLUMNS:
            preview[col] = preview[col].apply(mask_id)

    # Determine filter type per column
    col_defs = []
    for c in preview.columns:
        dtype = str(preview[c].dtype)
        if "int" in dtype or "float" in dtype:
            col_filter = "agNumberColumnFilter"
        elif "datetime" in dtype:
            col_filter = "agDateColumnFilter"
        else:
            col_filter = "agTextColumnFilter"
        col_defs.append({
            "field": c,
            "sortable": True,
            "filter": col_filter,
            "floatingFilter": True,
            "resizable": True,
        })

    return dag.AgGrid(
        id="master-ag-grid",
        rowData=preview.to_dict("records"),
        columnDefs=col_defs,
        defaultColDef={"flex": 1, "minWidth": 120},
        dashGridOptions={
            "animateRows": True,
            "pagination": True,
            "paginationPageSize": page_size,
            "paginationPageSizeSelector": [10, 20, 50, 100],
        },
        style={"height": "600px", "width": "100%"},
        className="ag-theme-alpine-dark",
    )


def _build_slot_card(slot):
    """Build a compact upload card for one of the 12 table slots."""
    name = slot["name"]
    is_mandatory = slot["mandatory"]
    border_color = "#22b8cf" if is_mandatory else THEME.DARK_BORDER
    # V20: Multi-sheet slots show file format hint in upload zone
    _upload_hint = "Drop .xlsx (2 sheets)" if name in MULTI_SHEET_SLOTS else "Drop / Click"

    return dmc.Paper([
        dmc.Stack([
            # Header: icon + label + badge + optional tag
            dmc.Group([
                DashIconify(icon=slot["icon"], width=14, color=slot["color"]),
                dmc.Text(slot["label"], fw=600, size="xs", style={"flex": 1}),
                dmc.Text(
                    "(optional)", size="8px", c="dimmed", fs="italic",
                    style={"whiteSpace": "nowrap"},
                ) if not is_mandatory else None,
                dmc.Badge(
                    "REQ" if is_mandatory else "",
                    color="red" if is_mandatory else "gray",
                    size="xs",
                    variant="filled" if is_mandatory else "light",
                ) if is_mandatory else None,
            ], gap=3, wrap="nowrap"),

            # Upload zone (compact)
            dcc.Upload(
                id={"type": "slot-upload", "slot": name},
                children=dmc.Center(
                    dmc.Text(_upload_hint, size="9px", c="dimmed"),
                    style={"minHeight": "28px"},
                ),
                style={
                    "border": f"1px dashed {border_color}",
                    "borderRadius": "4px",
                    "padding": "2px",
                    "textAlign": "center",
                    "cursor": "pointer",
                },
                multiple=False,
            ),

            # Status + actions row
            dmc.Group([
                html.Div(id={"type": "slot-status", "slot": name}, children=[
                    dmc.Text("Empty", size="9px", c="dimmed"),
                ], style={"flex": 1}),
                dmc.ActionIcon(
                    DashIconify(icon="mdi:download", width=14),
                    id={"type": "slot-export", "slot": name},
                    color="cyan", variant="light", size="sm",
                ),
                dmc.ActionIcon(
                    DashIconify(icon="mdi:trash-can-outline", width=14),
                    id={"type": "slot-delete", "slot": name},
                    color="red", variant="light", size="sm",
                ),
            ], gap=4),
        ], gap=2),
    ], p=6, radius="sm", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD})


def _build_config_upload_card(config_name, icon, color, description):
    """Build compact upload card for optional config tables — with download/delete actions."""
    return dmc.Paper([
        dmc.Stack([
            # Header: icon + name + (optional) tag
            dmc.Group([
                DashIconify(icon=icon, width=12, color=color),
                dmc.Text(config_name, fw=600, size="10px", style={"flex": 1}),
                dmc.Text(
                    "(optional)", size="7px", c="dimmed", fs="italic",
                    style={"whiteSpace": "nowrap"},
                ),
            ], gap=3, wrap="nowrap"),
            dcc.Upload(
                id={"type": "upload-config", "name": config_name},
                children=dmc.Center(
                    dmc.Text("Drop / Click", size="8px", c="dimmed"),
                    style={"minHeight": "20px"},
                ),
                style={
                    "border": "1px dashed #444", "borderRadius": "3px",
                    "padding": "1px 3px", "textAlign": "center", "cursor": "pointer",
                },
                multiple=False,
            ),
            # Status + action buttons row
            dmc.Group([
                html.Div(id={"type": "config-status", "name": config_name},
                         style={"minHeight": "10px", "flex": 1}),
                dmc.ActionIcon(
                    DashIconify(icon="mdi:download", width=14),
                    id={"type": "config-download", "name": config_name},
                    color="cyan", variant="light", size="sm",
                ),
                dmc.ActionIcon(
                    DashIconify(icon="mdi:trash-can-outline", width=14),
                    id={"type": "config-delete", "name": config_name},
                    color="red", variant="light", size="sm",
                ),
            ], gap=4),
        ], gap=2),
    ], p=4, radius="sm", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD})


def _build_loaded_summary(sources, data_vault):
    """
    Build the Loaded Tables Summary section.
    Shows all 12 slots with their status, record counts, and per-table actions.
    V20: Multi-sheet slots (relationships, temporal) show sub-table rows.
    """
    rows = []
    for slot in TABLE_SLOTS:
        name = slot["name"]
        if name in MULTI_SHEET_SLOTS:
            # V20: Multi-sheet slot — show each sub-table as its own row
            sub_map = MULTI_SHEET_SLOTS[name]
            for sheet_name, vault_key in sub_map.items():
                if vault_key in sources:
                    df = sources[vault_key]
                    detector = SchemaDetector()
                    schema_profiles = detector.detect_schema(df)
                    usable_cols = detector.get_usable_columns(schema_profiles)
                    rows.append({
                        "Table": vault_key,
                        "Label": f"{slot['label']}: {sheet_name}",
                        "Type": "Optional",
                        "Status": "Loaded",
                        "Records": f"{len(df):,}",
                        "Columns": len(df.columns),
                        "Usable": len(usable_cols),
                        "Joinable": "No",
                    })
        elif name in sources:
            df = sources[name]
            detector = SchemaDetector()
            schema_profiles = detector.detect_schema(df)
            usable_cols = detector.get_usable_columns(schema_profiles)
            rows.append({
                "Table": name,
                "Label": slot["label"],
                "Type": "MANDATORY" if slot["mandatory"] else "Optional",
                "Status": "Loaded",
                "Records": f"{len(df):,}",
                "Columns": len(df.columns),
                "Usable": len(usable_cols),
                "Joinable": "Yes" if can_join_to_base(df) or name == "BASE" else "No",
            })
        # V20: Skip empty slots — no value in showing blank entries

    # Also add any tables loaded that aren't in predefined slots (exclude MASTER)
    slot_names = {s["name"] for s in TABLE_SLOTS}
    # V20: Also exclude multi-sheet sub-table vault keys (already shown above)
    _ms_vault_keys = set()
    for _sub_map in MULTI_SHEET_SLOTS.values():
        _ms_vault_keys.update(_sub_map.values())
    for name in sorted(sources.keys()):
        if name not in slot_names and name != "MASTER" and name not in _ms_vault_keys:
            df = sources[name]
            detector = SchemaDetector()
            schema_profiles = detector.detect_schema(df)
            usable_cols = detector.get_usable_columns(schema_profiles)
            rows.append({
                "Table": name,
                "Label": name,
                "Type": "Custom",
                "Status": "Loaded",
                "Records": f"{len(df):,}",
                "Columns": len(df.columns),
                "Usable": len(usable_cols),
                "Joinable": "Yes" if can_join_to_base(df) else "No",
            })

    if not rows:
        return dmc.Alert(
            "No tables loaded yet. Upload or generate data above.",
            color="gray", variant="light",
            icon=DashIconify(icon="mdi:information"),
        )

    col_defs = [
        {"field": "Table",    "headerName": "Table Name", "flex": 1.5, "pinned": "left",
         "cellStyle": {"fontWeight": "600"}},
        {"field": "Label",    "headerName": "Label",     "flex": 1.2},
        {"field": "Type",     "headerName": "Type",      "flex": 1,
         "cellStyle": {"conditions": [
             {"condition": "params.value === 'MANDATORY'", "style": {"color": "#FF5252", "fontWeight": "600"}},
         ]} if False else {}},
        {"field": "Status",   "headerName": "Status",    "flex": 0.8,
         "cellStyle": {"conditions": []} if False else {}},
        {"field": "Records",  "headerName": "Records",   "flex": 0.8, "type": "rightAligned"},
        {"field": "Columns",  "headerName": "Total Cols", "flex": 0.7, "type": "rightAligned"},
        {"field": "Usable",   "headerName": "Usable",    "flex": 0.7, "type": "rightAligned",
         "cellStyle": {"color": "#51cf66"}},
        {"field": "Joinable", "headerName": "Joinable",  "flex": 0.7},
    ]

    # Summary badges
    loaded_count = sum(1 for r in rows if r["Status"] == "Loaded")
    total_records = sum(int(str(r["Records"]).replace(",", "")) for r in rows if r["Records"] != "-")
    total_cols = sum(int(r["Columns"]) for r in rows if r["Columns"] != "-")
    joinable_count = sum(1 for r in rows if r["Joinable"] == "Yes")

    summary_bar = dmc.Group([
        dmc.Badge(f"{loaded_count}/{len(TABLE_SLOTS)} Loaded", color="green", variant="light", size="sm"),
        dmc.Badge(f"{total_records:,} Total Rows", color="blue", variant="light", size="sm"),
        dmc.Badge(f"{total_cols:,} Total Cols", color="indigo", variant="light", size="sm"),
        dmc.Badge(f"{joinable_count} Joinable", color="cyan", variant="light", size="sm"),
    ], gap="xs", mb="xs")

    return dmc.Stack([
        summary_bar,
        dag.AgGrid(
            id="ds-summary-grid",
            rowData=rows,
            columnDefs=col_defs,
            defaultColDef={"resizable": True, "sortable": True, "filter": True},
            dashGridOptions={"domLayout": "autoHeight", "animateRows": True, "rowHeight": 36},
            style={"height": None, "width": "100%"},
            className="ag-theme-alpine-dark",
        ),
    ], gap=4)


def _build_stats(sources, data_vault):
    """Build stats row showing loaded data overview."""
    meta = data_vault.get_metadata()
    table_count = len(sources)
    total_rows = sum(len(df) for df in sources.values())
    slot_names = {s["name"] for s in TABLE_SLOTS}
    loaded_slots = sum(1 for s in TABLE_SLOTS if _slot_has_data(s["name"], sources))

    cards = []
    for slot in TABLE_SLOTS:
        name = slot["name"]
        if _slot_has_data(name, sources):
            total = _slot_total_rows(name, sources)
            primary_df = _slot_get_primary_df(name, sources)
            if primary_df is not None:
                detector = SchemaDetector()
                usable = len(detector.get_usable_columns(detector.detect_schema(primary_df)))
            else:
                usable = 0
            # Build description text
            if name in MULTI_SHEET_SLOTS:
                sub_map = MULTI_SHEET_SLOTS[name]
                desc_parts = []
                for sheet_name, vault_key in sub_map.items():
                    if vault_key in sources:
                        desc_parts.append(f"{len(sources[vault_key]):,} {sheet_name}")
                desc_text = " | ".join(desc_parts)
            else:
                desc_text = f"{total:,} rows | {usable} usable"
            cards.append(
                dmc.Paper(
                    dmc.Group([
                        dmc.ThemeIcon(
                            DashIconify(icon=slot["icon"], width=16),
                            color=slot["color"], variant="light", size="md",
                        ),
                        dmc.Stack([
                            dmc.Group([
                                dmc.Text(slot["label"], size="xs", fw=600),
                                dmc.Badge("REQ", color="red", size="xs") if slot["mandatory"] else None,
                            ], gap=4),
                            dmc.Text(desc_text, size="10px", c="dimmed"),
                        ], gap=0),
                    ], gap="xs"),
                    p="xs", radius="sm", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD},
                )
            )
        # V20: Skip empty slots — only show loaded tables

    if not cards:
        return dmc.Alert("No tables loaded yet.", color="gray", variant="light",
                         icon=DashIconify(icon="mdi:information"))

    return dmc.Stack([
        dmc.Group([
            dmc.Badge(f"{loaded_slots}/{len(TABLE_SLOTS)} Slots Filled", color="cyan", variant="light", size="lg"),
            dmc.Badge(f"{total_rows:,} Total Rows", color="blue", variant="light", size="lg") if total_rows > 0 else None,
            dmc.Badge(f"{table_count} Tables", color="green", variant="light", size="lg") if table_count > 0 else None,
        ], gap="md"),
        dmc.SimpleGrid(
            cols={"base": 2, "sm": 3, "md": 4, "lg": 6}, spacing="xs", children=cards,
        ),
    ], gap="sm")


def _build_preview_tabs(sources):
    """Build tabbed preview for loaded tables with summary header."""
    if not sources:
        return dmc.Alert(
            "No data loaded yet. Upload tables or generate sample data above.",
            color="gray", variant="light",
            icon=DashIconify(icon="mdi:information"),
        )

    # Summary header
    total_tables = len(sources)
    total_rows = sum(len(df) for df in sources.values())
    total_cols = sum(len(df.columns) for df in sources.values())
    avg_rows = total_rows // max(total_tables, 1)
    summary_bar = dmc.Group([
        dmc.Badge(f"{total_tables} Tables", color="cyan", variant="light", size="sm"),
        dmc.Badge(f"{total_rows:,} Total Rows", color="blue", variant="light", size="sm"),
        dmc.Badge(f"{total_cols:,} Total Cols", color="indigo", variant="light", size="sm"),
        dmc.Badge(f"~{avg_rows:,} Avg Rows/Table", color="teal", variant="light", size="sm"),
    ], gap="xs", mb="xs")

    tabs, panels = [], []
    for name, df in sorted(sources.items()):
        icon_info = get_dynamic_table_icon(name)
        tabs.append(dmc.TabsTab(name, value=name,
                                leftSection=DashIconify(icon=icon_info["icon"], width=14)))
        panels.append(dmc.TabsPanel(
            dmc.Paper([
                dmc.Group([
                    dmc.Text(f"{len(df):,} rows (paginated, {len(df.columns)} cols)", size="xs", c="dimmed"),
                    dmc.Badge(f"{len(df.columns)} cols", color="gray", variant="light", size="xs"),
                    # V26: Show DataFrame variable name for traceability
                    dmc.Badge(f'sources["{name}"]', color="violet", variant="outline", size="xs",
                              leftSection=DashIconify(icon="mdi:variable", width=12)),
                ], justify="space-between", mb="xs"),
                build_ag_grid(df, name),
            ], p="sm", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}),
            value=name,
        ))
    first = sorted(sources.keys())[0]
    return dmc.Stack([
        summary_bar,
        dmc.Tabs([dmc.TabsList(tabs)] + panels, value=first, color="cyan", variant="pills"),
    ], gap=4)


# =============================================================================
# CROSS-TABLE CONSISTENCY & INTEGRATION CHECK
# =============================================================================
def _build_consistency_check(sources):
    """Validate referential integrity across all loaded tables."""
    # V20: Exclude MASTER from cross-table analysis — it's the derived output, not an input
    sources = {k: v for k, v in sources.items() if k != "MASTER"}

    if not sources or len(sources) < 2:
        return dmc.Alert(
            "Need at least 2 tables to run consistency checks.",
            color="gray", variant="light",
            icon=DashIconify(icon="mdi:information"),
        )

    checks = []
    # Identify primary key column from BASE
    pk_col = None
    if "BASE" in sources:
        pk_col = resolve(sources["BASE"], "primary_key")

    # 1. Primary key presence check
    pk_aliases = {"cust_id", "customer_id", "party_id", "client_id", "entity_id", "account_id"}
    pk_results = []
    for name, df in sorted(sources.items()):
        found_pk = resolve(df, "primary_key")
        has_pk = found_pk is not None
        pk_results.append({
            "Table": name,
            "PK Column": found_pk or "—",
            "Has PK": "Yes" if has_pk else "No",
            "Unique PKs": int(df[found_pk].nunique()) if has_pk else 0,
            "Null PKs": int(df[found_pk].isnull().sum()) if has_pk else 0,
            "Dup PKs": int(df[found_pk].duplicated().sum()) if has_pk else 0,
        })

    pk_df = pd.DataFrame(pk_results)
    pk_with_key = sum(1 for r in pk_results if r["Has PK"] == "Yes")
    total_null_pks = sum(r["Null PKs"] for r in pk_results)
    total_dup_pks = sum(r["Dup PKs"] for r in pk_results)
    checks.append(dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:key", width=18, color="#22b8cf"),
            dmc.Text("Primary Key Presence", fw=600, size="sm"),
        ], gap="xs", mb="xs"),
        dmc.Group([
            dmc.Badge(f"{pk_with_key}/{len(pk_results)} Have PK", color="green", variant="light", size="sm"),
            dmc.Badge(f"{total_null_pks} Null PKs", color="orange" if total_null_pks > 0 else "gray", variant="light", size="sm"),
            dmc.Badge(f"{total_dup_pks} Dup PKs", color="red" if total_dup_pks > 0 else "gray", variant="light", size="sm"),
        ], gap="xs", mb="xs"),
        dag.AgGrid(
            id="consistency-pk-grid",
            rowData=pk_df.to_dict("records"),
            columnDefs=[{"field": c, "sortable": True, "filter": True} for c in pk_df.columns],
            defaultColDef={"flex": 1, "minWidth": 90},
            dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
            style={"height": None, "width": "100%"},
            className="ag-theme-alpine-dark",
        ),
    ], p="sm", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}))

    # 2. Cross-table key overlap / referential integrity
    if pk_col and "BASE" in sources:
        base_keys = set(sources["BASE"][pk_col].dropna().astype(str))
        overlap_results = []
        for name, df in sorted(sources.items()):
            if name == "BASE":
                continue
            tpk = resolve(df, "primary_key")
            if tpk is None:
                overlap_results.append({
                    "Table": name, "Join Key": "—", "BASE Keys": len(base_keys),
                    "Table Keys": 0, "Matched": 0, "Overlap %": "—",
                    "Orphans": "—", "Status": "No PK",
                })
                continue
            table_keys = set(df[tpk].dropna().astype(str))
            matched = base_keys & table_keys
            overlap_pct = round(len(matched) / max(len(table_keys), 1) * 100, 1)
            orphan_count = len(table_keys - base_keys)
            status = "OK" if overlap_pct >= 80 else ("Warn" if overlap_pct >= 50 else "Low")
            overlap_results.append({
                "Table": name, "Join Key": tpk, "BASE Keys": len(base_keys),
                "Table Keys": len(table_keys), "Matched": len(matched),
                "Overlap %": f"{overlap_pct}%",
                "Orphans": orphan_count, "Status": status,
            })

        if overlap_results:
            ov_df = pd.DataFrame(overlap_results)
            ok_count = sum(1 for r in overlap_results if r["Status"] == "OK")
            warn_count = sum(1 for r in overlap_results if r["Status"] == "Warn")
            low_count = sum(1 for r in overlap_results if r["Status"] == "Low")
            no_pk_count = sum(1 for r in overlap_results if r["Status"] == "No PK")
            total_orphans = sum(r["Orphans"] for r in overlap_results if isinstance(r["Orphans"], int))
            checks.append(dmc.Paper([
                dmc.Group([
                    DashIconify(icon="mdi:link-variant", width=18, color="#51cf66"),
                    dmc.Text("Cross-Table Key Overlap (vs BASE)", fw=600, size="sm"),
                ], gap="xs", mb="xs"),
                dmc.Group([
                    dmc.Badge(f"{ok_count} OK", color="green", variant="light", size="sm"),
                    dmc.Badge(f"{warn_count} Warn", color="orange", variant="light", size="sm") if warn_count else None,
                    dmc.Badge(f"{low_count} Low", color="red", variant="light", size="sm") if low_count else None,
                    dmc.Badge(f"{no_pk_count} No PK", color="gray", variant="light", size="sm") if no_pk_count else None,
                    dmc.Badge(f"{total_orphans:,} Orphans", color="orange" if total_orphans > 0 else "gray", variant="light", size="sm"),
                ], gap="xs", mb="xs"),
                dag.AgGrid(
                    id="consistency-overlap-grid",
                    rowData=ov_df.to_dict("records"),
                    columnDefs=[{"field": c, "sortable": True, "filter": True} for c in ov_df.columns],
                    defaultColDef={"flex": 1, "minWidth": 80},
                    dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
                    style={"height": None, "width": "100%"},
                    className="ag-theme-alpine-dark",
                ),
            ], p="sm", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}))

    # 3. Column overlap heatmap data
    col_overlap_rows = []
    table_names = sorted(sources.keys())
    for t1 in table_names:
        cols1 = set(sources[t1].columns)
        row = {"Table": t1}
        for t2 in table_names:
            cols2 = set(sources[t2].columns)
            shared = len(cols1 & cols2)
            row[t2] = shared
        col_overlap_rows.append(row)

    co_df = pd.DataFrame(col_overlap_rows)
    checks.append(dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:table-column", width=18, color="#be4bdb"),
            dmc.Text("Shared Columns Matrix", fw=600, size="sm"),
        ], gap="xs", mb="xs"),
        dmc.Text("Count of columns with the same name across table pairs", size="xs", c="dimmed", mb="xs"),
        dag.AgGrid(
            id="consistency-colmatrix-grid",
            rowData=co_df.to_dict("records"),
            columnDefs=[{"field": c, "sortable": True, "filter": True} for c in co_df.columns],
            defaultColDef={"flex": 1, "minWidth": 70},
            dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
            style={"height": None, "width": "100%"},
            className="ag-theme-alpine-dark",
        ),
    ], p="sm", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}))

    # 4. Data quality summary per table
    dq_results = []
    for name, df in sorted(sources.items()):
        null_pct = round(df.isnull().sum().sum() / max(df.size, 1) * 100, 2)
        dup_rows = int(df.duplicated().sum())
        numeric_cols = len(df.select_dtypes(include=[np.number]).columns)
        cat_cols = len(df.select_dtypes(include=["object", "category"]).columns)
        dq_results.append({
            "Table": name, "Rows": len(df), "Cols": len(df.columns),
            "Null %": f"{null_pct}%", "Dup Rows": dup_rows,
            "Numeric": numeric_cols, "Categorical": cat_cols,
        })

    dq_df = pd.DataFrame(dq_results)
    total_rows_dq = sum(r["Rows"] for r in dq_results)
    total_cols_dq = sum(r["Cols"] for r in dq_results)
    total_dup_rows = sum(r["Dup Rows"] for r in dq_results)
    total_numeric = sum(r["Numeric"] for r in dq_results)
    total_cat = sum(r["Categorical"] for r in dq_results)
    avg_null = round(sum(float(r["Null %"].rstrip('%')) for r in dq_results) / max(len(dq_results), 1), 2)
    checks.append(dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:chart-box", width=18, color="#ffd43b"),
            dmc.Text("Data Quality Summary", fw=600, size="sm"),
        ], gap="xs", mb="xs"),
        dmc.Group([
            dmc.Badge(f"{total_rows_dq:,} Total Rows", color="blue", variant="light", size="sm"),
            dmc.Badge(f"{total_cols_dq:,} Total Cols", color="indigo", variant="light", size="sm"),
            dmc.Badge(f"{avg_null}% Avg Null", color="orange" if avg_null > 5 else "gray", variant="light", size="sm"),
            dmc.Badge(f"{total_dup_rows:,} Dup Rows", color="red" if total_dup_rows > 0 else "gray", variant="light", size="sm"),
            dmc.Badge(f"{total_numeric} Numeric", color="teal", variant="light", size="sm"),
            dmc.Badge(f"{total_cat} Categorical", color="grape", variant="light", size="sm"),
        ], gap="xs", mb="xs"),
        dag.AgGrid(
            id="consistency-dq-grid",
            rowData=dq_df.to_dict("records"),
            columnDefs=[{"field": c, "sortable": True, "filter": True} for c in dq_df.columns],
            defaultColDef={"flex": 1, "minWidth": 80},
            dashGridOptions={"domLayout": "autoHeight", "animateRows": True},
            style={"height": None, "width": "100%"},
            className="ag-theme-alpine-dark",
        ),
    ], p="sm", radius="md", withBorder=True, style={"backgroundColor": THEME.DARK_BG_CARD}))

    return dmc.Stack(checks, gap="sm")


# =============================================================================
# CUSTOMER-LEVEL AGGREGATE TABLE BUILDER
# =============================================================================
def _safe_merge(agg, right_df, pk_col, right_pk, suffix):
    """Safely merge right_df into agg, handling column name conflicts."""
    try:
        # Drop columns from right that already exist in agg (except the join key)
        existing_cols = set(agg.columns) - {pk_col}
        right_cols_to_keep = [right_pk] + [c for c in right_df.columns if c != right_pk and c not in existing_cols]
        right_clean = right_df[right_cols_to_keep]
        agg = agg.merge(right_clean, left_on=pk_col, right_on=right_pk, how="left", suffixes=("", suffix))
        if right_pk != pk_col and right_pk in agg.columns:
            agg.drop(columns=[right_pk], inplace=True, errors="ignore")
    except Exception:
        pass
    return agg


def _build_master_table(sources):
    """
    V19: Build MASTER table using spec-driven RollupEngine.
    
    7-Step Pipeline:
      1. Load BASE (mandatory) → MASTER_DF
      2. Scan & classify tables (TABULAR / GRAPH / TEMPORAL)
      3. Rollup & LEFT JOIN tabular tables to MASTER
      4. Extract GRAPH_DATA separately (NOT joined)
      5. Extract TEMPORAL_DATA separately (NOT joined)
      6. Apply exclusions (PII, 100% null, zero-variance)
      7. Generate display with processing log
    
    Returns:
      (df_master, display_component)
    """
    global _graph_data_store, _temporal_data_store, _last_build_result

    if "BASE" not in sources:
        return None, dmc.Alert(
            "BASE table required to build master table.",
            color="yellow", variant="light",
            icon=DashIconify(icon="mdi:alert"),
        )

    # Build rollup engine with current configs
    base_key = DEFAULT_BASE_KEY
    base_key_aliases = list(DEFAULT_BASE_KEY_ALIASES)
    grain_config = dict(DEFAULT_GRAIN_CONFIG)

    # Apply TABLE_GRAIN_DETECTION config if loaded
    if "TABLE_GRAIN_DETECTION" in _config_store:
        cfg_df = _config_store["TABLE_GRAIN_DETECTION"]
        cols_lower = {c.lower(): c for c in cfg_df.columns}
        if "parameter" in cols_lower and "value" in cols_lower:
            for _, row in cfg_df.iterrows():
                p = str(row[cols_lower["parameter"]]).lower().strip()
                v = str(row[cols_lower["value"]]).strip()
                if p == "base_key":
                    base_key = v
                elif p == "base_key_alias":
                    base_key_aliases = [a.strip() for a in v.split(",")]
        if "table_name" in cols_lower and "rollup_strategy" in cols_lower:
            for _, row in cfg_df.iterrows():
                t = str(row[cols_lower["table_name"]]).lower().strip()
                s = str(row[cols_lower["rollup_strategy"]]).upper().strip()
                if t in grain_config:
                    grain_config[t]["rollup_strategy"] = s

    engine = RollupEngine(
        base_key=base_key,
        base_key_aliases=base_key_aliases,
        grain_config=grain_config,
        table_map=_config_store.get("TABLE_MAP"),
        exclude_config=_config_store.get("EXCLUDE"),
    )

    # Run the 7-step pipeline
    build_result = engine.build_master(sources)
    _last_build_result = build_result

    if not build_result.success:
        return None, dmc.Alert(
            build_result.error or "Master table build failed.",
            color="red", variant="light",
            icon=DashIconify(icon="mdi:alert-circle"),
        )

    # Store separate outputs
    _graph_data_store = build_result.graph_data
    _temporal_data_store = build_result.temporal_data

    # V25: Standardized naming — master table is always df_master
    df_master = build_result.master_df

    # ── Build display ────────────────────────────────────────────────
    # Count contributing tables
    joined_tables = [r.table_name for r in build_result.rollup_results if r.success]
    skipped_tables = [r.table_name for r in build_result.rollup_results if not r.success]

    # Rollup summary rows
    # V20: Only show tables that actually joined — skip empty/skipped
    rollup_rows = []
    for r in build_result.rollup_results:
        if not r.success:
            continue
        rollup_rows.append({
            "Table": r.table_name,
            "Strategy": r.strategy,
            "Status": "✅ Joined",
            "Rows Before": f"{r.n_rows_before:,}" if r.n_rows_before else "—",
            "Rows After": f"{r.n_rows_after:,}" if r.n_rows_after else "—",
            "Cols Added": r.n_cols_added,
            "Message": r.message[:80],
        })

    rollup_grid = dag.AgGrid(
        id="rollup-summary-grid",
        rowData=rollup_rows,
        columnDefs=[
            {"field": "Table", "flex": 1.2, "pinned": "left", "cellStyle": {"fontWeight": "600"}},
            {"field": "Strategy", "flex": 0.9},
            {"field": "Status", "flex": 0.8},
            {"field": "Rows Before", "flex": 0.8, "type": "rightAligned"},
            {"field": "Rows After", "flex": 0.8, "type": "rightAligned"},
            {"field": "Cols Added", "flex": 0.7, "type": "rightAligned"},
            {"field": "Message", "flex": 2},
        ],
        defaultColDef={"resizable": True, "sortable": True, "filter": True},
        dashGridOptions={"domLayout": "autoHeight", "animateRows": True, "rowHeight": 34},
        style={"height": None, "width": "100%"},
        className="ag-theme-alpine-dark",
    )

    # Availability badges
    graph_badge = dmc.Badge(
        "GRAPH_DATA: Available" if build_result.graph_data and build_result.graph_data.available else "GRAPH_DATA: None",
        color="green" if build_result.graph_data and build_result.graph_data.available else "gray",
        variant="light", size="sm",
    )
    temporal_badge = dmc.Badge(
        "TEMPORAL_DATA: Available" if build_result.temporal_data and build_result.temporal_data.available else "TEMPORAL_DATA: None",
        color="green" if build_result.temporal_data and build_result.temporal_data.available else "gray",
        variant="light", size="sm",
    )

    # Processing log (last 15 entries)
    log_entries = build_result.processing_log[-15:] if build_result.processing_log else []
    log_text = "\n".join([
        f"[{e.get('level','INFO')}] [{e.get('table','—')}] {e.get('message','')}"
        for e in log_entries
    ])

    display = dmc.Stack([
        # Header
        dmc.Paper([
            dmc.Group([
                DashIconify(icon="mdi:account-details", width=20, color="#22b8cf"),
                dmc.Text("MASTER TABLE — Spec-Driven Pipeline", fw=700, size="lg"),
                dmc.Badge(
                    f"{len(df_master):,} rows × {len(df_master.columns)} cols | "
                    f"{len(joined_tables)} joined, {len(skipped_tables)} skipped",
                    color="cyan", variant="light", size="sm",
                ),
                # V26: DataFrame variable name label
                dmc.Badge("df_master", color="violet", variant="outline", size="sm",
                          leftSection=DashIconify(icon="mdi:variable", width=14)),
                # V20: Export Master Data button
                dmc.Button(
                    "Export MASTER CSV",
                    id="ds-btn-export-master",
                    leftSection=DashIconify(icon="mdi:download", width=16),
                    color="teal", size="xs", variant="light",
                    style={"marginLeft": "auto"},
                ),
            ], gap="xs", mb="xs"),
            dmc.Group([
                dmc.Text(f"BASE_KEY: {build_result.base_key}", size="xs", c="dimmed"),
                dmc.Text("|", size="xs", c="dimmed"),
                graph_badge,
                temporal_badge,
                dmc.Badge(f"{len(_config_store)} configs loaded", color="indigo", variant="light", size="xs"),
            ], gap="xs", mb="sm"),
            # V20: Master grid with per-column floating filter search
            _build_master_ag_grid(df_master, page_size=20),
        ], p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}),

        # Rollup Summary — only show if tables actually joined
        *([] if not rollup_rows else [dmc.Paper([
            dmc.Group([
                DashIconify(icon="mdi:table-merge-cells", width=18, color="#51cf66"),
                dmc.Text(f"Rollup & Join Summary ({len(rollup_rows)} tables joined)", fw=600, size="sm"),
            ], gap="xs", mb="xs"),
            rollup_grid,
        ], p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD})]),

        # Processing Log
        dmc.Paper([
            dmc.Group([
                DashIconify(icon="mdi:text-box-outline", width=18, color="#ffd43b"),
                dmc.Text("Processing Log", fw=600, size="sm"),
            ], gap="xs", mb="xs"),
            dmc.Code(log_text or "No log entries", block=True,
                     style={"maxHeight": "200px", "overflowY": "auto", "fontSize": "11px"}),
        ], p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}),
    ], gap="sm")

    return df_master, display


def _build_schema_docs_modal():
    """Build comprehensive schema documentation modal — V19 with rollup strategies."""
    return dmc.ScrollArea([
        dmc.Tabs([
            dmc.TabsList([
                dmc.TabsTab("Data Tables", value="data"),
                dmc.TabsTab("Config Tables", value="config"),
                dmc.TabsTab("Rollup Strategies", value="rollup"),
                dmc.TabsTab("Auto-Detection", value="detection"),
            ]),
            dmc.TabsPanel(
                dmc.Stack([
                    dmc.Title("12 Integrated Table Slots — V19 Spec", order=3, mb="md"),
                    dmc.Paper([
                        dmc.Title("BASE Table (MANDATORY)", order=4, mb="sm", c="red"),
                        dmc.Text("Defines the GRAIN. Must have BASE_KEY (default: cust_id). System FAILS if missing.", size="sm", mb="sm"),
                        dmc.Code(
                            "Minimal: cust_id, cust_name\n"
                            "Medium:  cust_id, cust_name, total_amt, txn_count, ...\n"
                            "Full:    cust_id, cust_name + 100 feature columns\n"
                            "\nBASE_KEY can be: cust_id, account_id, txn_id, alert_id, case_id (any grain)",
                            block=True,
                        ),
                    ], p="md", withBorder=True, mb="md"),
                    dmc.Paper([
                        dmc.Title("9 Tabular Tables — Rollup & JOIN to MASTER", order=4, mb="sm", c="green"),
                        dmc.Table([
                            html.Thead(html.Tr([html.Th("Slot"), html.Th("Rollup"), html.Th("If Missing")])),
                            html.Tbody([
                                html.Tr([html.Td("Transactions"), html.Td("AGGREGATE"), html.Td("Skip txn features")]),
                                html.Tr([html.Td("Customer/Party"), html.Td("DIRECT"), html.Td("Skip profile features")]),
                                html.Tr([html.Td("Accounts"), html.Td("AGGREGATE"), html.Td("Skip account features")]),
                                html.Tr([html.Td("Alerts"), html.Td("AGGREGATE"), html.Td("Skip alert features")]),
                                html.Tr([html.Td("Cases"), html.Td("AGGREGATE"), html.Td("Skip case features")]),
                                html.Tr([html.Td("KYC"), html.Td("TAKE_LATEST"), html.Td("Skip KYC features")]),
                                html.Tr([html.Td("Watchlist"), html.Td("AGGREGATE"), html.Td("Skip watchlist features")]),
                                html.Tr([html.Td("Others1"), html.Td("AUTO_DETECT"), html.Td("Graceful skip")]),
                                html.Tr([html.Td("Others2"), html.Td("AUTO_DETECT"), html.Td("Graceful skip")]),
                            ]),
                        ], striped=True, highlightOnHover=True),
                    ], p="md", withBorder=True, mb="md"),
                    dmc.Paper([
                        dmc.Title("2 Extract Tables — Separate Outputs (NOT in MASTER)", order=4, mb="sm", c="violet"),
                        dmc.Table([
                            html.Thead(html.Tr([html.Th("Slot"), html.Th("Output"), html.Th("If Missing")])),
                            html.Tbody([
                                html.Tr([html.Td("Relationships"), html.Td("→ GRAPH_DATA/"), html.Td("GRAPH_DATA = None")]),
                                html.Tr([html.Td("Temporal"), html.Td("→ TEMPORAL_DATA/"), html.Td("TEMPORAL_DATA = None")]),
                            ]),
                        ], striped=True, highlightOnHover=True),
                    ], p="md", withBorder=True),
                ]),
                value="data",
            ),
            dmc.TabsPanel(
                dmc.Stack([
                    dmc.Title("10 Configuration Files (All Optional)", order=3, mb="md"),
                    dmc.Alert("All config files are OPTIONAL. System uses intelligent defaults.", color="blue", variant="light", mb="md"),
                    dmc.Table([
                        html.Thead(html.Tr([html.Th("#"), html.Th("Config"), html.Th("Purpose"), html.Th("Default")])),
                        html.Tbody([
                            html.Tr([html.Td("1"), html.Td("EXCLUDE"), html.Td("Columns/tables to exclude"), html.Td("Auto-detect PII/*_id")]),
                            html.Tr([html.Td("2"), html.Td("FEATURE_MAP"), html.Td("Renames + transforms"), html.Td("Keep originals, auto-LOG")]),
                            html.Tr([html.Td("3"), html.Td("TABLE_MAP"), html.Td("Join keys & types"), html.Td("Auto-discover")]),
                            html.Tr([html.Td("4"), html.Td("METHOD_CONFIG"), html.Td("Algorithm config"), html.Td("Enable all compatible")]),
                            html.Tr([html.Td("5"), html.Td("ALGO_FEATURE_MAP"), html.Td("Feature-to-algo map"), html.Td("Auto-map by type")]),
                            html.Tr([html.Td("6"), html.Td("FEATURE_STORE"), html.Td("Feature metadata"), html.Td("Auto-detect")]),
                            html.Tr([html.Td("7"), html.Td("METADATA"), html.Td("System parameters"), html.Td("Hardcoded defaults")]),
                            html.Tr([html.Td("8"), html.Td("CUSTOM_CONFIG"), html.Td("User key-value pairs"), html.Td("No overrides")]),
                            html.Tr([html.Td("9"), html.Td("TABLE_GRAIN_DETECTION"), html.Td("Rollup + grain level"), html.Td("Auto-detect grain")]),
                            html.Tr([html.Td("10"), html.Td("FEATURE_ENGINEERING"), html.Td("Feature transforms"), html.Td("Standard aggs")]),
                        ]),
                    ], striped=True, highlightOnHover=True),
                ]),
                value="config",
            ),
            dmc.TabsPanel(
                dmc.Stack([
                    dmc.Title("4 Rollup Strategies", order=3, mb="md"),
                    dmc.Table([
                        html.Thead(html.Tr([html.Th("Strategy"), html.Th("When"), html.Th("What Happens")])),
                        html.Tbody([
                            html.Tr([
                                html.Td(dmc.Badge("DIRECT", color="green")),
                                html.Td("1:1 relationship"),
                                html.Td("Join as-is, dedup by key"),
                            ]),
                            html.Tr([
                                html.Td(dmc.Badge("AGGREGATE", color="blue")),
                                html.Td("Many:1 relationship"),
                                html.Td("Numeric: SUM/AVG/MAX/MIN/STD/COUNT | Categorical: COUNT/NUNIQUE/MODE"),
                            ]),
                            html.Tr([
                                html.Td(dmc.Badge("TAKE_LATEST", color="teal")),
                                html.Td("Multiple records/entity"),
                                html.Td("Sort by date DESC, keep most recent record"),
                            ]),
                            html.Tr([
                                html.Td(dmc.Badge("AUTO_DETECT", color="grape")),
                                html.Td("Unknown grain"),
                                html.Td("Count rows/key: if ≈1 → DIRECT, else → AGGREGATE"),
                            ]),
                        ]),
                    ], striped=True, highlightOnHover=True),
                ]),
                value="rollup",
            ),
            dmc.TabsPanel(
                dmc.Stack([
                    dmc.Title("Auto-Detection Rules", order=3, mb="md"),
                    dmc.Table([
                        html.Thead(html.Tr([html.Th("Type"), html.Th("Detection"), html.Th("Usable")])),
                        html.Tbody([
                            html.Tr([html.Td(dmc.Badge("CONTINUOUS", color="blue")), html.Td("Float / large range int"), html.Td("YES")]),
                            html.Tr([html.Td(dmc.Badge("BINARY", color="green")), html.Td("2 unique values"), html.Td("YES")]),
                            html.Tr([html.Td(dmc.Badge("ORDINAL", color="cyan")), html.Td("Int 2-10 unique"), html.Td("YES")]),
                            html.Tr([html.Td(dmc.Badge("CATEGORICAL", color="grape")), html.Td("String <20 unique"), html.Td("YES")]),
                            html.Tr([html.Td(dmc.Badge("HIGH_CARD", color="red")), html.Td("String >20 unique"), html.Td("NO")]),
                            html.Tr([html.Td(dmc.Badge("ID_FIELD", color="orange")), html.Td(">95% unique + id keyword"), html.Td("NO")]),
                            html.Tr([html.Td(dmc.Badge("DATETIME", color="yellow")), html.Td("Date/timestamp"), html.Td("CONTEXT")]),
                            html.Tr([html.Td(dmc.Badge("TEXT", color="gray")), html.Td("Free-form text"), html.Td("NO")]),
                        ]),
                    ], striped=True, highlightOnHover=True),
                ]),
                value="detection",
            ),
        ], value="data", variant="pills", color="cyan"),
    ], h=500)


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Container([
    # ── HEADER ────────────────────────────────────────────────────────
    dmc.Group([
        dmc.Stack([
            dmc.Title("Data Sources", order=2),
            dmc.Text("12 table slots | Per-table export/delete | Auto-detection", size="sm", c="dimmed"),
        ], gap=2),
        dmc.Group([
            dmc.Badge("12 Slots", color="cyan", variant="light"),
            dmc.Badge("Auto-Join", color="cyan", variant="light"),
            dmc.Button("Schema Docs", id="btn-open-schema-docs", variant="subtle", size="xs",
                       color="blue", leftSection=DashIconify(icon="mdi:book-open-variant", width=14)),
        ], gap="xs"),
    ], justify="space-between", mb="md"),

    # Schema Docs Modal
    dmc.Modal(id="modal-schema-docs", title="Schema Architecture Reference", size="90%",
              children=_build_schema_docs_modal()),

    # ══════════════════════════════════════════════════════════════════
    # QUICK START: Generate / Select / Confirm (TOP OF PAGE)
    # ══════════════════════════════════════════════════════════════════
    dmc.Text("Quick Start", fw=700, size="lg", mb="xs"),
    dmc.SimpleGrid(
        cols={"base": 1, "sm": 2}, spacing="md", mb="md",
        children=[
            # Generate Sample Data
            dmc.Paper([
                dmc.Group([
                    DashIconify(icon="mdi:database-plus", width=18, color="#22b8cf"),
                    dmc.Text("Generate Sample Data", fw=600, size="sm"),
                ], gap="xs", mb="xs"),
                dmc.NumberInput(
                    id="ds-customer-count", label="Customers",
                    value=100, min=10, max=100000, step=10, size="xs", mb="xs",
                ),
                dmc.Button("Generate", id="ds-btn-generate",
                           leftSection=DashIconify(icon="mdi:play", width=14),
                           color="cyan", size="xs", fullWidth=True, mb="xs"),
                dmc.Button("Reset All", id="ds-btn-reset",
                           leftSection=DashIconify(icon="mdi:trash-can", width=14),
                           color="red", variant="subtle", size="xs", fullWidth=True),
            ], p="sm", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD, "height": "100%"}),

            # Select for Execution
            dmc.Paper([
                dmc.Group([
                    DashIconify(icon="mdi:check-decagram", width=18, color="#51cf66"),
                    dmc.Text("Select for Execution", fw=600, size="sm"),
                ], gap="xs", mb="xs"),
                dmc.SegmentedControl(
                    id="ds-execution-choice",
                    data=[{"label": "Sample", "value": "sample"}, {"label": "Actual", "value": "actual"}],
                    value="sample", color="green", fullWidth=True, size="xs", mb="xs",
                ),
                html.Div(id="ds-execution-info", children=[
                    dmc.Alert("No data available", color="gray", variant="light",
                              styles={"message": {"fontSize": "11px"}}),
                ]),
                dmc.Button("Confirm", id="ds-btn-confirm-final",
                           leftSection=DashIconify(icon="mdi:check-bold", width=14),
                           color="green", size="xs", fullWidth=True, mt="xs", disabled=True),
            ], p="sm", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD, "height": "100%"}),
        ],
    ),

    # Status
    html.Div(id="ds-status-output", style={"marginBottom": "8px"}),

    # ══════════════════════════════════════════════════════════════════
    # ALL TABLE SLOTS — Consolidated Upload Grid (12 slots)
    # ══════════════════════════════════════════════════════════════════
    dmc.Text("All Table Slots", fw=700, size="lg", mb="xs"),
    dmc.Text(
        "Upload to any slot — BASE required, all others optional | Export or delete per table",
        size="xs", c="dimmed", mb="sm",
    ),
    dmc.SimpleGrid(
        cols={"base": 3, "sm": 4, "md": 6, "lg": 6},
        spacing="xs",
        mb="md",
        children=[_build_slot_card(slot) for slot in TABLE_SLOTS],
    ),

    # ══════════════════════════════════════════════════════════════════
    # SECTION 4: V19 — 10 Config File Upload Slots (All Optional)
    # ══════════════════════════════════════════════════════════════════
    dmc.Text("Configuration Files (All Optional — 10 Slots)", fw=700, size="lg", mb="xs"),
    dmc.Alert(
        "Upload config files to override defaults. System uses intelligent auto-detection when configs are missing.",
        color="blue", variant="light",
        icon=DashIconify(icon="mdi:cog-outline", width=18), mb="sm",
    ),
    dmc.SimpleGrid(
        cols={"base": 3, "sm": 5, "md": 5}, spacing="xs", mb="md",
        children=[
            _build_config_upload_card(cfg["name"], cfg["icon"], cfg["color"], cfg["desc"])
            for cfg in CONFIG_SLOTS
        ],
    ),
    html.Div(id="config-upload-status"),

    # ══════════════════════════════════════════════════════════════════
    # SECTION 4b: V19 — GRAPH_DATA & TEMPORAL_DATA Output Panels
    # ══════════════════════════════════════════════════════════════════
    dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:graph-outline", width=20, color="#be4bdb"),
            dmc.Text("Separate Outputs: GRAPH_DATA & TEMPORAL_DATA", fw=700, size="lg"),
        ], gap="xs", mb="xs"),
        dmc.Text(
            "Per spec: Relationships → GRAPH_DATA, Temporal → TEMPORAL_DATA (NOT joined to MASTER)",
            size="xs", c="dimmed", mb="sm",
        ),
        html.Div(id="ds-graph-temporal-output"),
    ], p="md", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD}, mb="md"),

    # ══════════════════════════════════════════════════════════════════
    # SECTION 5: LOADED TABLES SUMMARY (after config, with actions)
    # ══════════════════════════════════════════════════════════════════
    dmc.Paper([
        dmc.Group([
            dmc.Text("Loaded Tables Summary", fw=700, size="lg"),
            dmc.Group([
                dmc.Button("Export All", id="ds-btn-export-all",
                           leftSection=DashIconify(icon="mdi:download", width=14),
                           color="cyan", size="xs", variant="light"),
                dmc.Button("Delete All", id="ds-btn-delete-all",
                           leftSection=DashIconify(icon="mdi:trash-can", width=14),
                           color="red", size="xs", variant="light"),
            ], gap="xs"),
        ], justify="space-between", mb="xs"),
        dmc.Text("All 12 slots + any custom tables — with status, record counts, and joinability", size="xs", c="dimmed", mb="sm"),
        html.Div(id="ds-summary-table"),
    ], p="md", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD}, mb="md"),

    # ── STATS ROW ─────────────────────────────────────────────────────
    html.Div(id="ds-source-stats"),
    dmc.Space(h="sm"),

    # ══════════════════════════════════════════════════════════════════
    # CROSS-TABLE CONSISTENCY & INTEGRATION CHECK
    # ══════════════════════════════════════════════════════════════════
    dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:check-network", width=20, color="#22b8cf"),
            dmc.Text("Cross-Table Consistency & Integration", fw=700, size="lg"),
        ], gap="xs", mb="xs"),
        dmc.Text("Referential integrity, key overlap, column sharing, data quality", size="xs", c="dimmed", mb="sm"),
        html.Div(id="ds-consistency-check"),
    ], p="md", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD}, mb="md"),

    # ── TABLE PREVIEWS (Tabbed) ───────────────────────────────────────
    html.Div(id="ds-table-previews"),
    dmc.Space(h="sm"),

    # ══════════════════════════════════════════════════════════════════
    # CUSTOMER-LEVEL COMBINED AGGREGATE TABLE (LAST SECTION)
    # ══════════════════════════════════════════════════════════════════
    html.Div(id="ds-customer-aggregate"),

    # Hidden components
    dcc.Download(id="ds-download-export"),
    dcc.Download(id="ds-download-single"),
    dcc.Download(id="ds-download-config"),
    dcc.Download(id="ds-download-master"),  # V20: Master data export
    dcc.Store(id="ds-upload-trigger", data=0),
    dcc.Store(id="ds-final-data-store", data=None),
    dcc.Store(id="ds-slot-refresh", data=0),
    dcc.Upload(id="ds-upload-exclude", style={"display": "none"}),
    html.Div(id="ds-exclude-status", style={"display": "none"}),
    # Hidden: legacy upload IDs (callbacks still reference these)
    dcc.Upload(id="upload-base-table", style={"display": "none"}),
    html.Div(id="base-upload-status", style={"display": "none"}),
    dcc.Upload(id="upload-additional-tables", style={"display": "none"}, multiple=True),
    html.Div(id="additional-upload-status", style={"display": "none"}),
], fluid=True)


# =============================================================================
# CALLBACKS
# =============================================================================

# ── CALLBACK: BASE Table Upload ────────────────────────────────────
@callback(
    Output("base-upload-status", "children"),
    Output("ds-summary-table", "children"),
    Output("ds-source-stats", "children"),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input("upload-base-table", "contents"),
    State("upload-base-table", "filename"),
    State("ds-execution-choice", "value"),
    prevent_initial_call=True,
)
def upload_base_table(contents, filename, execution_choice):
    """Handle BASE table upload with validation."""
    from utils.data_io import data_vault

    if contents is None:
        raise dash.exceptions.PreventUpdate

    try:
        df = _parse_upload(contents, filename)
        is_valid, error_msg = validate_base_table(df)

        if not is_valid:
            err = dmc.Alert(error_msg, color="red", icon=DashIconify(icon="mdi:alert-circle"))
            return err, dash.no_update, dash.no_update, dash.no_update, dash.no_update

        detector = SchemaDetector()
        schema_profiles = detector.detect_schema(df)
        usable_cols = detector.get_usable_columns(schema_profiles)

        sources_dir = PATHS.DATA_VAULT / "sources"
        sources_dir.mkdir(parents=True, exist_ok=True)
        df.to_parquet(sources_dir / "BASE.parquet", index=False)

        data_vault._sources["BASE"] = df
        meta = data_vault.get_metadata()
        meta["base_uploaded"] = True
        meta["base_columns"] = list(df.columns)
        meta["base_usable_columns"] = usable_cols
        meta["data_type"] = execution_choice or "actual"
        actual_tables = set(meta.get("actual_tables", []))
        actual_tables.add("BASE")
        meta["actual_tables"] = list(actual_tables)
        data_vault._metadata = meta
        data_vault.save_metadata()

        status_alert = dmc.Alert(
            f"BASE uploaded: {len(df):,} rows, {len(usable_cols)} usable cols",
            color="green", icon=DashIconify(icon="mdi:check-circle"),
        )
        exec_info = dmc.Stack([
            dmc.Group([
                DashIconify(icon="mdi:check-circle", width=14, color="#51cf66"),
                dmc.Text(f"BASE Ready - {len(df):,} rows", size="xs", fw=600, c="green"),
            ], gap=4),
        ], gap=0)

        sources = data_vault.load_sources()
        return (status_alert, _build_loaded_summary(sources, data_vault),
                _build_stats(sources, data_vault), exec_info, False)

    except Exception as e:
        err = dmc.Alert("An error occurred. Check audit log for details.", color="red", icon=DashIconify(icon="mdi:alert"))
        return err, dash.no_update, dash.no_update, dash.no_update, dash.no_update


# ── CALLBACK: Additional Tables Upload (bulk) ───────────────────────
@callback(
    Output("additional-upload-status", "children"),
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children"),
    Output("ds-consistency-check", "children"),
    Output("ds-customer-aggregate", "children"),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input("upload-additional-tables", "contents"),
    State("upload-additional-tables", "filename"),
    State("ds-execution-choice", "value"),
    prevent_initial_call=True,
)
def upload_additional_tables(contents_list, filenames_list, execution_choice):
    """Handle additional table uploads (unlimited, any name)."""
    from utils.data_io import data_vault

    if not contents_list:
        raise dash.exceptions.PreventUpdate

    if not isinstance(contents_list, list):
        contents_list, filenames_list = [contents_list], [filenames_list]

    msgs = []
    uploaded = []
    for contents, filename in zip(contents_list, filenames_list):
        try:
            df = _parse_upload(contents, filename)
            table_name = filename.rsplit(".", 1)[0]
            can_join = can_join_to_base(df)

            sources_dir = PATHS.DATA_VAULT / "sources"
            sources_dir.mkdir(parents=True, exist_ok=True)
            df.to_parquet(sources_dir / f"{table_name}.parquet", index=False)
            data_vault._sources[table_name] = df
            uploaded.append(table_name)

            join_status = "joinable" if can_join else "standalone"
            msgs.append(dmc.Alert(
                f"{table_name}: {len(df):,} rows ({join_status})",
                color="green", variant="light",
            ))
        except Exception as e:
            msgs.append(dmc.Alert(f"{filename}: Upload failed", color="red", variant="light"))

    if uploaded:
        meta = data_vault.get_metadata()
        actual_tables = set(meta.get("actual_tables", []))
        actual_tables.update(uploaded)
        meta["actual_tables"] = list(actual_tables)
        data_vault._metadata = meta
        data_vault.save_metadata()
        if "BASE" in data_vault._sources:
            _rebuild_merged(data_vault)

    sources = data_vault.load_sources()
    exec_info = dash.no_update
    confirm_disabled = dash.no_update
    if execution_choice == "actual" and sources:
        exec_info = dmc.Stack([
            dmc.Group([
                DashIconify(icon="mdi:check-circle", width=14, color="#51cf66"),
                dmc.Text(f"{len(sources)} tables loaded", size="xs", fw=600, c="green"),
            ], gap=4),
        ], gap=0)
        confirm_disabled = False

    try:
        _, master_display = _build_master_table(sources)
    except Exception as e:
        master_display = dmc.Alert(f"Master build error: {str(e)[:200]}", color="red", variant="light")

    return (dmc.Stack(msgs, gap="xs"),
            _build_loaded_summary(sources, data_vault),
            _build_stats(sources, data_vault),
            _build_preview_tabs(sources),
            _build_consistency_check(sources),
            master_display or "",
            exec_info, confirm_disabled)


# ── CALLBACK: Per-Slot Upload (12 table slots) ──────────────────────
@callback(
    Output({"type": "slot-status", "slot": ALL}, "children", allow_duplicate=True),
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-consistency-check", "children", allow_duplicate=True),
    Output("ds-customer-aggregate", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input({"type": "slot-upload", "slot": ALL}, "contents"),
    State({"type": "slot-upload", "slot": ALL}, "filename"),
    State({"type": "slot-upload", "slot": ALL}, "id"),
    prevent_initial_call=True,
)
def handle_slot_upload(contents_list, filenames_list, ids_list):
    """Handle upload to a specific table slot (ALL pattern)."""
    from utils.data_io import data_vault

    # Determine which slot triggered
    triggered = ctx.triggered_id
    if triggered is None:
        raise dash.exceptions.PreventUpdate

    slot_name = triggered["slot"]

    # Find the index of the triggered slot
    idx = None
    for i, id_dict in enumerate(ids_list):
        if id_dict["slot"] == slot_name:
            idx = i
            break
    if idx is None or contents_list[idx] is None:
        raise dash.exceptions.PreventUpdate

    contents = contents_list[idx]
    filename = filenames_list[idx]

    try:
        sources_dir = PATHS.DATA_VAULT / "sources"
        sources_dir.mkdir(parents=True, exist_ok=True)

        # V20: Multi-sheet slots — parse Excel with two sheets (edges+nodes / long+wide)
        if slot_name in MULTI_SHEET_SLOTS and filename.endswith(('.xlsx', '.xls')):
            content_string = contents.split(",")[1]
            decoded = base64.b64decode(content_string)
            xls = pd.ExcelFile(io.BytesIO(decoded))
            sub_map = MULTI_SHEET_SLOTS[slot_name]
            loaded_sheets = {}
            for sheet_name, vault_key in sub_map.items():
                if sheet_name in xls.sheet_names:
                    df_sheet = pd.read_excel(xls, sheet_name=sheet_name)
                    df_sheet.to_parquet(sources_dir / f"{vault_key}.parquet", index=False)
                    data_vault._sources[vault_key] = df_sheet
                    loaded_sheets[sheet_name] = df_sheet
            # V20: Temporal auto-derive — if only one sheet uploaded, derive the other
            if slot_name == "temporal":
                _temporal_auto_derive(loaded_sheets, sub_map, sources_dir, data_vault)
        elif slot_name in MULTI_SHEET_SLOTS:
            # CSV upload to multi-sheet slot → treat as primary sub-table (edges / long)
            df = _parse_upload(contents, filename)
            primary_sheet = list(MULTI_SHEET_SLOTS[slot_name].keys())[0]
            primary_key = list(MULTI_SHEET_SLOTS[slot_name].values())[0]
            df.to_parquet(sources_dir / f"{primary_key}.parquet", index=False)
            data_vault._sources[primary_key] = df
            # V20: Temporal auto-derive from single CSV
            if slot_name == "temporal":
                _temporal_auto_derive({primary_sheet: df}, MULTI_SHEET_SLOTS[slot_name], sources_dir, data_vault)
        else:
            df = _parse_upload(contents, filename)

            # Validate BASE if that's the slot
            if slot_name == "BASE":
                is_valid, error_msg = validate_base_table(df)
                if not is_valid:
                    statuses = [dash.no_update] * len(ids_list)
                    statuses[idx] = dmc.Text("Invalid", size="10px", c="red", ta="center")
                    return statuses, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update

            df.to_parquet(sources_dir / f"{slot_name}.parquet", index=False)
            data_vault._sources[slot_name] = df

        meta = data_vault.get_metadata()
        actual_tables = set(meta.get("actual_tables", []))
        if slot_name in MULTI_SHEET_SLOTS:
            actual_tables.update(MULTI_SHEET_SLOTS[slot_name].values())
        else:
            actual_tables.add(slot_name)
        meta["actual_tables"] = list(actual_tables)
        if slot_name == "BASE":
            meta["base_uploaded"] = True
            detector = SchemaDetector()
            schema_profiles = detector.detect_schema(df)
            meta["base_usable_columns"] = detector.get_usable_columns(schema_profiles)
        data_vault._metadata = meta
        data_vault.save_metadata()

        if "BASE" in data_vault._sources and slot_name != "BASE":
            _rebuild_merged(data_vault)

        sources = data_vault.load_sources()

        # Build slot statuses for ALL slots (V20: multi-sheet aware)
        slot_statuses = []
        for id_dict in ids_list:
            slot_statuses.append(_slot_status_widget(id_dict["slot"], sources))

        try:
            _, master_display = _build_master_table(sources)
        except Exception as e:
            master_display = dmc.Alert(f"Master build error: {str(e)[:200]}", color="red", variant="light")

        # Auto-enable confirm when data is available
        confirm_disabled = len(sources) == 0

        return (slot_statuses,
                _build_loaded_summary(sources, data_vault),
                _build_stats(sources, data_vault),
                _build_preview_tabs(sources),
                _build_consistency_check(sources),
                master_display or "",
                confirm_disabled)

    except Exception as e:
        statuses = [dash.no_update] * len(ids_list)
        statuses[idx] = dmc.Text("Error", size="10px", c="red", ta="center")
        return statuses, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update


# ── CALLBACK: Per-Slot Export ────────────────────────────────────────
@callback(
    Output("ds-download-single", "data"),
    Input({"type": "slot-export", "slot": ALL}, "n_clicks"),
    State({"type": "slot-export", "slot": ALL}, "id"),
    prevent_initial_call=True,
)
def handle_slot_export(n_clicks_list, ids_list):
    """Export a single table — V20: multi-sheet slots export as Excel with 2 sheets."""
    from utils.data_io import data_vault
    from utils.pii_masking import mask_dataframe, detect_pii_columns

    # Find which button was clicked
    triggered = ctx.triggered_id
    if triggered is None:
        raise dash.exceptions.PreventUpdate

    slot_name = triggered["slot"]
    sources = data_vault.load_sources()

    # V20: Multi-sheet slot → export as Excel with two sheets
    if slot_name in MULTI_SHEET_SLOTS:
        if not _slot_has_data(slot_name, sources):
            raise dash.exceptions.PreventUpdate
        output = io.BytesIO()
        total_exported = 0
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            for sheet_name, vault_key in MULTI_SHEET_SLOTS[slot_name].items():
                if vault_key in sources:
                    df = sources[vault_key].copy()
                    pii_cols = detect_pii_columns(df)
                    if pii_cols:
                        df = mask_dataframe(df, pii_cols)
                    for col in df.select_dtypes(include=["object"]).columns:
                        df[col] = df[col].apply(lambda v: "'" + str(v) if isinstance(v, str) and len(v) > 0 and v[0] in ('=', '+', '-', '@') else v)
                    df.to_excel(writer, sheet_name=sheet_name, index=False)
                    total_exported += len(df)
        try:
            from utils.logger import logger
            logger.log_export(export_type="xlsx_slot", filename=slot_name + ".xlsx", row_count=total_exported)
        except Exception:
            pass
        return dcc.send_bytes(output.getvalue(), f"{slot_name}.xlsx")

    # Regular single-table slot → export as CSV
    if slot_name not in sources:
        raise dash.exceptions.PreventUpdate

    df = sources[slot_name].copy()
    # V13 FIX: Apply PII masking before export
    pii_cols = detect_pii_columns(df)
    if pii_cols:
        df = mask_dataframe(df, pii_cols)
    # V13 FIX: CSV formula injection protection
    for col in df.select_dtypes(include=["object"]).columns:
        df[col] = df[col].apply(lambda v: "'" + str(v) if isinstance(v, str) and len(v) > 0 and v[0] in ('=', '+', '-', '@') else v)
    # V13 FIX: Audit log the export
    try:
        from utils.logger import logger
        logger.log_export(export_type="csv_slot", filename=slot_name + ".csv", row_count=len(df))
    except Exception:
        pass
    csv_string = df.to_csv(index=False)
    return dict(content=csv_string, filename=f"{slot_name}.csv")


# ── CALLBACK: Per-Slot Delete ────────────────────────────────────────
@callback(
    Output({"type": "slot-status", "slot": ALL}, "children", allow_duplicate=True),
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-consistency-check", "children", allow_duplicate=True),
    Output("ds-customer-aggregate", "children", allow_duplicate=True),
    Output("ds-status-output", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input({"type": "slot-delete", "slot": ALL}, "n_clicks"),
    State({"type": "slot-delete", "slot": ALL}, "id"),
    prevent_initial_call=True,
)
def handle_slot_delete(n_clicks_list, ids_list):
    """Delete a single table from its slot."""
    from utils.data_io import data_vault

    triggered = ctx.triggered_id
    if triggered is None:
        raise dash.exceptions.PreventUpdate

    slot_name = triggered["slot"]

    # Check if any button was actually clicked
    all_none = all(nc is None for nc in n_clicks_list)
    if all_none:
        raise dash.exceptions.PreventUpdate

    # V20: Remove from vault — handle multi-sheet slots (both sub-tables)
    if slot_name in MULTI_SHEET_SLOTS:
        for vault_key in MULTI_SHEET_SLOTS[slot_name].values():
            if vault_key in data_vault._sources:
                del data_vault._sources[vault_key]
            pq = PATHS.DATA_VAULT / "sources" / f"{vault_key}.parquet"
            if pq.exists():
                pq.unlink()
    else:
        if slot_name in data_vault._sources:
            del data_vault._sources[slot_name]
        parquet_file = PATHS.DATA_VAULT / "sources" / f"{slot_name}.parquet"
        if parquet_file.exists():
            parquet_file.unlink()

    # Update metadata
    meta = data_vault.get_metadata()
    actual_tables = set(meta.get("actual_tables", []))
    if slot_name in MULTI_SHEET_SLOTS:
        for vk in MULTI_SHEET_SLOTS[slot_name].values():
            actual_tables.discard(vk)
    else:
        actual_tables.discard(slot_name)
    meta["actual_tables"] = list(actual_tables)
    if slot_name == "BASE":
        meta["base_uploaded"] = False
    data_vault._metadata = meta
    data_vault.save_metadata()

    sources = data_vault.load_sources()

    # Build slot status for ALL slots (V20: multi-sheet aware)
    slot_statuses = []
    for id_dict in ids_list:
        slot_statuses.append(_slot_status_widget(id_dict["slot"], sources))

    status_msg = dmc.Alert(
        f"Deleted: {slot_name}", color="orange",
        icon=DashIconify(icon="mdi:check"), withCloseButton=True,
    )

    try:
        _, master_display = _build_master_table(sources)
    except Exception as e:
        master_display = dmc.Alert(f"Master build error: {str(e)[:200]}", color="red", variant="light")

    # Disable confirm if no data remains
    confirm_disabled = len(sources) == 0

    return (slot_statuses,
            _safe_build(_build_loaded_summary, sources, data_vault, label="loaded summary"),
            _safe_build(_build_stats, sources, data_vault, label="stats"),
            _safe_build(_build_preview_tabs, sources, label="preview tabs"),
            _safe_build(_build_consistency_check, sources, label="consistency check"),
            master_display or "",
            status_msg,
            confirm_disabled)


# ── CALLBACK: Generate / Reset ───────────────────────────────────────
@callback(
    Output("ds-status-output", "children", allow_duplicate=True),
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-consistency-check", "children", allow_duplicate=True),
    Output("ds-customer-aggregate", "children", allow_duplicate=True),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Output("ds-execution-choice", "value", allow_duplicate=True),
    Output({"type": "slot-status", "slot": ALL}, "children", allow_duplicate=True),
    Output({"type": "config-status", "name": ALL}, "children", allow_duplicate=True),
    Input("ds-btn-generate", "n_clicks"),
    Input("ds-btn-reset", "n_clicks"),
    State("ds-customer-count", "value"),
    State("ds-execution-choice", "value"),
    State({"type": "slot-status", "slot": ALL}, "id"),
    State({"type": "config-status", "name": ALL}, "id"),
    prevent_initial_call=True,
)
def handle_gen_reset(n_gen, n_reset, num_customers, execution_choice, slot_ids, config_ids):
    """Generate sample data or reset vault."""
    global _config_store
    from utils.data_gen import DataGenerator
    from utils.data_io import data_vault

    triggered = ctx.triggered_id
    status_msg = None
    exec_info = dash.no_update
    confirm_disabled = dash.no_update
    choice_value = dash.no_update

    if triggered == "ds-btn-reset":
        data_vault.clear_data()
        sources_dir = PATHS.DATA_VAULT / "sources"
        if sources_dir.exists():
            for f in sources_dir.glob("*.parquet"):
                f.unlink()
        for f in PATHS.DATA_SOURCES.glob("*.csv"):
            f.unlink()
        # V20: Also clear Excel files on reset
        for f in PATHS.DATA_SOURCES.glob("*.xlsx"):
            f.unlink()
        # V20: Clear config store on reset
        _config_store.clear()
        status_msg = dmc.Alert("All data cleared.", color="orange",
                               icon=DashIconify(icon="mdi:check"), withCloseButton=True)
        exec_info = dmc.Stack([
            dmc.Group([
                DashIconify(icon="mdi:alert-circle", width=14, color="#ffd43b"),
                dmc.Text("No Data Available", size="xs", fw=600, c="yellow"),
            ], gap=4),
        ], gap=0)
        confirm_disabled = True
        choice_value = "sample"

    if triggered == "ds-btn-generate":
        try:
            num_customers = num_customers or 100
            dg = DataGenerator()
            schema = dg.generate_full_schema(num_customers)

            # V20: Separate data tables (12) from config tables (10)
            config_names = {"EXCLUDE", "FEATURE_MAP", "TABLE_MAP", "METHOD_CONFIG",
                            "ALGO_FEATURE_MAP", "FEATURE_STORE", "METADATA",
                            "CUSTOM_CONFIG", "TABLE_GRAIN_DETECTION", "FEATURE_ENGINEERING"}
            data_tables = {k: v for k, v in schema.items() if k not in config_names}
            config_tables = {k: v for k, v in schema.items() if k in config_names}

            # Save data tables to vault
            data_vault.save_sources(data_tables)
            meta = data_vault.get_metadata()
            meta["data_type"] = "sample"
            meta["sample_tables"] = list(data_tables.keys())
            meta["config_tables"] = list(config_tables.keys())
            data_vault._metadata = meta
            data_vault.save_metadata()

            # V20: Load config tables into _config_store
            for cfg_name, cfg_df in config_tables.items():
                _config_store[cfg_name] = cfg_df

            PATHS.DATA_SOURCES.mkdir(parents=True, exist_ok=True)
            for name, df in data_tables.items():
                df.to_csv(PATHS.DATA_SOURCES / f"{name}.csv", index=False)
            # V20: Save combined Excel for multi-sheet slots (relationships.xlsx, temporal.xlsx)
            for ui_slot, sheet_map in MULTI_SHEET_SLOTS.items():
                try:
                    with pd.ExcelWriter(PATHS.DATA_SOURCES / f"{ui_slot}.xlsx", engine='openpyxl') as writer:
                        for sheet_name, vault_key in sheet_map.items():
                            if vault_key in data_tables:
                                data_tables[vault_key].to_excel(writer, sheet_name=sheet_name, index=False)
                except Exception:
                    pass
            # Also save configs to disk
            for name, df in config_tables.items():
                df.to_csv(PATHS.DATA_SOURCES / f"config_{name}.csv", index=False)

            # Build merged view using BASE (now generated with all 12 tables)
            if "BASE" in data_vault._sources:
                _rebuild_merged(data_vault)
            else:
                # Fallback: merge transactions + accounts + customer_party
                df_tx = data_tables.get("transactions", pd.DataFrame())
                df_acc = data_tables.get("accounts", pd.DataFrame())
                df_party = data_tables.get("customer_party", pd.DataFrame())
                df_merged = df_tx.copy() if not df_tx.empty else pd.DataFrame()
                if not df_merged.empty and not df_acc.empty and "account_id" in df_tx.columns and "account_id" in df_acc.columns:
                    df_merged = df_merged.merge(df_acc, on="account_id", how="left", suffixes=("", "_acc"))
                if not df_merged.empty and not df_party.empty and "party_id" in df_merged.columns and "party_id" in df_party.columns:
                    df_merged = df_merged.merge(df_party, on="party_id", how="left", suffixes=("", "_party"))
                if not df_merged.empty:
                    data_vault.set_current_data(df_merged, label=f"generated_{num_customers}_cust")

            total_rows = sum(len(v) for v in data_tables.values())
            status_msg = dmc.Alert(
                f"Generated {num_customers} customers → {total_rows:,} rows across "
                f"{len(data_tables)} data tables + {len(config_tables)} config tables.",
                color="green", icon=DashIconify(icon="mdi:check-circle"), withCloseButton=True,
            )

            # Auto-switch to sample mode and enable confirm
            choice_value = "sample"
            table_preview = ", ".join(list(data_tables.keys())[:6])
            exec_info = dmc.Stack([
                dmc.Group([
                    DashIconify(icon="mdi:check-circle", width=14, color="#51cf66"),
                    dmc.Text(f"Sample Ready — {len(data_tables)} data + {len(config_tables)} configs", size="xs", fw=600, c="cyan"),
                ], gap=4),
                dmc.Text(table_preview, size="xs", c="dimmed"),
            ], gap=0)
            confirm_disabled = False

        except Exception as e:
            import traceback
            err_detail = str(e)[:200]
            status_msg = dmc.Alert(
                f"Data generation failed: {err_detail}",
                color="red",
                icon=DashIconify(icon="mdi:alert"),
                withCloseButton=True,
            )

    try:
        sources = data_vault.load_sources()
    except Exception as e:
        import traceback
        traceback.print_exc()
        sources = {}

    # Build slot statuses for all 12 slots (V20: multi-sheet aware)
    slot_statuses = []
    for id_dict in slot_ids:
        slot_statuses.append(_slot_status_widget(id_dict["slot"], sources))

    # V20: Build config statuses — show obs counts for generated/uploaded configs
    config_statuses = []
    for id_dict in config_ids:
        cn = id_dict["name"]
        if cn in _config_store and _config_store[cn] is not None:
            cdf = _config_store[cn]
            config_statuses.append(dmc.Text(f"{len(cdf):,} rows", size="10px", c="green", fw=600))
        else:
            config_statuses.append("")

    try:
        _, master_display = _build_master_table(sources)
    except Exception as e:
        master_display = dmc.Alert(
            f"Master table build error: {str(e)[:200]}",
            color="red", variant="light",
        )

    return (status_msg,
            _safe_build(_build_loaded_summary, sources, data_vault, label="loaded summary"),
            _safe_build(_build_stats, sources, data_vault, label="stats"),
            _safe_build(_build_preview_tabs, sources, label="preview tabs"),
            _safe_build(_build_consistency_check, sources, label="consistency check"),
            master_display or "",
            exec_info, confirm_disabled,
            choice_value,
            slot_statuses,
            config_statuses)


# ── CALLBACK: Execution Choice ───────────────────────────────────────
@callback(
    Output("ds-execution-info", "children"),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input("ds-execution-choice", "value"),
    prevent_initial_call='initial_duplicate',
)
def update_execution_info(choice):
    """Update info based on selected data source."""
    from utils.data_io import data_vault

    sources = data_vault.load_sources()
    meta = data_vault.get_metadata()

    # Filter out derived tables (MASTER) from the count
    real_sources = {k: v for k, v in sources.items() if k != "MASTER"}

    if choice == "sample":
        # Check sources directly — don't rely only on metadata sample_tables
        sample_tables = meta.get("sample_tables", [])
        # Count tables that actually exist in sources — whether in sample_tables or not
        count = len(real_sources)
        if count > 0:
            names = list(real_sources.keys())
            preview = ", ".join(names[:4]) + (f" +{len(names)-4}" if len(names) > 4 else "")
            return dmc.Stack([
                dmc.Group([
                    DashIconify(icon="mdi:check-circle", width=14, color="#51cf66"),
                    dmc.Text(f"Sample Ready - {count} tables", size="xs", fw=600, c="cyan"),
                ], gap=4),
                dmc.Text(preview, size="xs", c="dimmed"),
            ], gap=0), False
        return dmc.Text("No sample data. Click Generate.", size="xs", c="yellow"), True

    elif choice == "actual":
        count = len(real_sources)
        if count > 0:
            return dmc.Stack([
                dmc.Group([
                    DashIconify(icon="mdi:check-circle", width=14, color="#51cf66"),
                    dmc.Text(f"Actual Ready - {count} tables", size="xs", fw=600, c="green"),
                ], gap=4),
            ], gap=0), False
        return dmc.Text("No actual data. Upload above.", size="xs", c="yellow"), True

    return dmc.Text("Select data source", size="xs", c="dimmed"), True


# ── CALLBACK: Confirm Final ──────────────────────────────────────────
@callback(
    Output("ds-status-output", "children", allow_duplicate=True),
    Output("ds-final-data-store", "data"),
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-consistency-check", "children", allow_duplicate=True),
    Output("ds-customer-aggregate", "children", allow_duplicate=True),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Output({"type": "slot-status", "slot": ALL}, "children", allow_duplicate=True),
    Input("ds-btn-confirm-final", "n_clicks"),
    State("ds-execution-choice", "value"),
    State({"type": "slot-status", "slot": ALL}, "id"),
    prevent_initial_call=True,
)
def confirm_final_data(n_clicks, choice, slot_ids):
    """Confirm data selection and refresh ALL downstream sections."""
    from utils.data_io import data_vault

    if not n_clicks:
        raise dash.exceptions.PreventUpdate

    if not choice:
        empty_slots = [dash.no_update] * len(slot_ids) if slot_ids else []
        return (dmc.Alert("Select Sample or Actual.", color="orange"), None,
                dash.no_update, dash.no_update, dash.no_update,
                dash.no_update, dash.no_update,
                dash.no_update, dash.no_update, empty_slots)

    try:
        # Persist the choice
        meta = data_vault.get_metadata()
        meta["final_data_choice"] = choice
        meta["data_type"] = choice
        data_vault._metadata = meta
        data_vault.save_metadata()

        # Rebuild merged current_data based on choice
        sources = data_vault.load_sources()

        if "BASE" in sources:
            # Best path: use _rebuild_merged which joins BASE with all related tables
            _rebuild_merged(data_vault)
        elif choice == "sample":
            # Fallback: merge transactions + accounts + customer_party
            df_tx = sources.get("transactions", pd.DataFrame())
            df_acc = sources.get("accounts", pd.DataFrame())
            df_party = sources.get("customer_party", pd.DataFrame())
            if not df_tx.empty:
                df_merged = df_tx.copy()
                if not df_acc.empty and "account_id" in df_tx.columns and "account_id" in df_acc.columns:
                    df_merged = df_merged.merge(df_acc, on="account_id", how="left", suffixes=("", "_acc"))
                if not df_party.empty and "party_id" in df_merged.columns and "party_id" in df_party.columns:
                    df_merged = df_merged.merge(df_party, on="party_id", how="left", suffixes=("", "_party"))
                data_vault.set_current_data(df_merged, label="sample_confirmed")
        else:
            # Actual data — rebuild merged from BASE + additional
            if sources:
                df_fallback = max(sources.values(), key=len)
                data_vault.set_current_data(df_fallback, label="actual_fallback")

        # Build slot statuses for ALL 12 slots
        slot_statuses = []
        for id_dict in slot_ids:
            sn = id_dict["slot"]
            if sn in sources:
                df_s = sources[sn]
                slot_statuses.append(dmc.Text(f"{len(df_s):,} rows", size="10px", c="green", ta="center", fw=600))
            else:
                slot_statuses.append(dmc.Text("Empty", size="10px", c="dimmed", ta="center"))

        total_tables = len(sources)
        total_rows = sum(len(df) for df in sources.values())
        label = "Sample Data" if choice == "sample" else "Actual Data"

        status = dmc.Alert(
            f"Confirmed: {label} — {total_tables} tables, {total_rows:,} total rows",
            color="green", icon=DashIconify(icon="mdi:check-circle"), withCloseButton=True,
        )
        store_data = {
            "choice": choice, "label": label,
            "tables": total_tables, "rows": total_rows,
            "timestamp": pd.Timestamp.now().isoformat(),
        }

        exec_confirmed = dmc.Stack([
            dmc.Group([
                DashIconify(icon="mdi:check-decagram", width=16, color="#51cf66"),
                dmc.Text(f"Confirmed: {label}", size="xs", fw=700, c="green"),
            ], gap=4),
            dmc.Text(f"{total_tables} tables | {total_rows:,} rows", size="10px", c="dimmed"),
        ], gap=2)

        # Build and save master table
        try:
            df_master, master_display = _build_master_table(sources)
        except Exception as e:
            df_master = None
            master_display = dmc.Alert(f"Master build error: {str(e)[:200]}", color="red", variant="light")
        if df_master is not None:
            # Save aggregate to vault for downstream pages
            sources_dir = PATHS.DATA_VAULT / "sources"
            sources_dir.mkdir(parents=True, exist_ok=True)
            df_master.to_parquet(sources_dir / "MASTER.parquet", index=False)
            data_vault._sources["MASTER"] = df_master

        return (status, store_data,
                _safe_build(_build_loaded_summary, sources, data_vault, label="loaded summary"),
                _safe_build(_build_stats, sources, data_vault, label="stats"),
                _safe_build(_build_preview_tabs, sources, label="preview tabs"),
                _safe_build(_build_consistency_check, sources, label="consistency check"),
                master_display or "",
                exec_confirmed, False,
                slot_statuses)

    except Exception as e:
        empty_slots = [dash.no_update] * len(slot_ids) if slot_ids else []
        return (dmc.Alert("Operation failed. Check audit log.", color="red",
                          icon=DashIconify(icon="mdi:alert-circle")),
                None, dash.no_update, dash.no_update, dash.no_update,
                dash.no_update, dash.no_update,
                dash.no_update, False, empty_slots)


# ── CALLBACK: Init Page Load ────────────────────────────────────────
@callback(
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-consistency-check", "children", allow_duplicate=True),
    Output("ds-customer-aggregate", "children", allow_duplicate=True),
    Output("ds-execution-choice", "value", allow_duplicate=True),
    Output({"type": "slot-status", "slot": ALL}, "children", allow_duplicate=True),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Input("ds-upload-trigger", "data"),
    State({"type": "slot-status", "slot": ALL}, "id"),
    prevent_initial_call='initial_duplicate',
)
def init_page_load(trigger, slot_ids):
    """Load existing data on page load — auto-enable confirm if data available."""
    from utils.data_io import data_vault
    sources = data_vault.load_sources()
    meta = data_vault.get_metadata()
    final_choice = meta.get("final_data_choice", "sample")

    slot_statuses = []
    for id_dict in slot_ids:
        sn = id_dict["slot"]
        if sn in sources:
            df = sources[sn]
            slot_statuses.append(dmc.Text(f"{len(df):,} rows", size="10px", c="green", ta="center", fw=600))
        else:
            slot_statuses.append(dmc.Text("Empty", size="10px", c="dimmed", ta="center"))

    # Auto-enable confirm when data is already available
    if sources:
        total = len(sources)
        total_rows = sum(len(df) for df in sources.values())
        label = "Sample" if final_choice == "sample" else "Actual"
        names = list(sources.keys())
        preview = ", ".join(names[:4]) + (f" +{len(names)-4}" if len(names) > 4 else "")
        exec_info = dmc.Stack([
            dmc.Group([
                DashIconify(icon="mdi:check-circle", width=14, color="#51cf66"),
                dmc.Text(f"{label} Ready - {total} tables, {total_rows:,} rows", size="xs", fw=600, c="cyan"),
            ], gap=4),
            dmc.Text(preview, size="xs", c="dimmed"),
        ], gap=0)
        confirm_disabled = False
    else:
        exec_info = dmc.Stack([
            dmc.Group([
                DashIconify(icon="mdi:alert-circle", width=14, color="#ffd43b"),
                dmc.Text("No Data Available", size="xs", fw=600, c="yellow"),
            ], gap=4),
        ], gap=0)
        confirm_disabled = True

    try:
        _, master_display = _build_master_table(sources)
    except Exception as e:
        master_display = dmc.Alert(f"Master build error: {str(e)[:200]}", color="red", variant="light")

    return (_safe_build(_build_loaded_summary, sources, data_vault, label="loaded summary"),
            _safe_build(_build_stats, sources, data_vault, label="stats"),
            _safe_build(_build_preview_tabs, sources, label="preview tabs"),
            _safe_build(_build_consistency_check, sources, label="consistency check"),
            master_display or "",
            final_choice,
            slot_statuses,
            exec_info,
            confirm_disabled)


# ── CALLBACK: Schema Docs Modal ─────────────────────────────────────
@callback(
    Output("modal-schema-docs", "opened"),
    Input("btn-open-schema-docs", "n_clicks"),
    State("modal-schema-docs", "opened"),
    prevent_initial_call=True,
)
def toggle_schema_docs_modal(n_clicks, opened):
    return not opened


# ── CALLBACK: Config Table Uploads ───────────────────────────────────
@callback(
    Output({"type": "config-status", "name": ALL}, "children"),
    Output("config-upload-status", "children"),
    Input({"type": "upload-config", "name": ALL}, "contents"),
    State({"type": "upload-config", "name": ALL}, "id"),
    prevent_initial_call=True,
)
def handle_config_uploads(contents_list, ids_list):
    """V19: Handle optional config table uploads — store in _config_store for rollup engine."""
    from utils.data_io import data_vault
    global _config_store

    status_outputs = [None] * len(contents_list)
    overall = []

    for i, (contents, id_dict) in enumerate(zip(contents_list, ids_list)):
        if contents is None:
            continue
        config_name = id_dict["name"]
        try:
            content_string = contents.split(",")[1]
            decoded = base64.b64decode(content_string)
            df = pd.read_csv(io.StringIO(decoded.decode("utf-8")))

            # V19: Store in global config store for rollup engine
            _config_store[config_name] = df

            config_dir = PATHS.DATA_VAULT / "config"
            config_dir.mkdir(parents=True, exist_ok=True)
            df.to_parquet(config_dir / f"{config_name}.parquet", index=False)

            meta = data_vault.get_metadata()
            config_tables = meta.get("config_tables", {})
            config_tables[config_name] = {"loaded": True, "rows": len(df)}
            meta["config_tables"] = config_tables
            data_vault._metadata = meta
            data_vault.save_metadata()

            status_outputs[i] = dmc.Text(f"{len(df)} rows", size="xs", c="green")
            overall.append(dmc.Alert(f"{config_name}: {len(df)} rules loaded", color="green", variant="light"))
        except Exception as e:
            status_outputs[i] = dmc.Text("Error", size="xs", c="red")
            overall.append(dmc.Alert(f"{config_name}: Processing failed", color="red", variant="light"))

    return status_outputs, dmc.Stack(overall, gap="xs") if overall else dash.no_update


# ── CALLBACK: Config Download ────────────────────────────────────────
@callback(
    Output("ds-download-config", "data"),
    Input({"type": "config-download", "name": ALL}, "n_clicks"),
    State({"type": "config-download", "name": ALL}, "id"),
    prevent_initial_call=True,
)
def handle_config_download(n_clicks_list, ids_list):
    """Download a single config as CSV."""
    triggered = ctx.triggered_id
    if triggered is None:
        raise dash.exceptions.PreventUpdate

    config_name = triggered["name"]

    # Check if any button was actually clicked
    if all(nc is None for nc in n_clicks_list):
        raise dash.exceptions.PreventUpdate

    # Try global store first, then parquet file
    if config_name in _config_store:
        df = _config_store[config_name]
    else:
        parquet_path = PATHS.DATA_VAULT / "config" / f"{config_name}.parquet"
        if parquet_path.exists():
            df = pd.read_parquet(parquet_path)
        else:
            raise dash.exceptions.PreventUpdate

    csv_string = df.to_csv(index=False)
    return dict(content=csv_string, filename=f"{config_name}.csv")


# ── CALLBACK: Config Delete ──────────────────────────────────────────
@callback(
    Output({"type": "config-status", "name": ALL}, "children", allow_duplicate=True),
    Output("config-upload-status", "children", allow_duplicate=True),
    Input({"type": "config-delete", "name": ALL}, "n_clicks"),
    State({"type": "config-delete", "name": ALL}, "id"),
    prevent_initial_call=True,
)
def handle_config_delete(n_clicks_list, ids_list):
    """Delete a single config from store and disk."""
    from utils.data_io import data_vault
    global _config_store

    triggered = ctx.triggered_id
    if triggered is None:
        raise dash.exceptions.PreventUpdate

    config_name = triggered["name"]

    if all(nc is None for nc in n_clicks_list):
        raise dash.exceptions.PreventUpdate

    # Remove from global config store
    _config_store.pop(config_name, None)

    # Remove parquet file
    parquet_path = PATHS.DATA_VAULT / "config" / f"{config_name}.parquet"
    if parquet_path.exists():
        parquet_path.unlink()

    # Update metadata
    meta = data_vault.get_metadata()
    config_tables = meta.get("config_tables", {})
    config_tables.pop(config_name, None)
    meta["config_tables"] = config_tables
    data_vault._metadata = meta
    data_vault.save_metadata()

    # Build status outputs for ALL config slots
    status_outputs = []
    for id_dict in ids_list:
        cn = id_dict["name"]
        if cn in _config_store:
            df = _config_store[cn]
            status_outputs.append(dmc.Text(f"{len(df)} rows", size="xs", c="green"))
        else:
            status_outputs.append(html.Div())

    overall = dmc.Alert(
        f"Deleted config: {config_name}", color="orange",
        icon=DashIconify(icon="mdi:check"), withCloseButton=True,
    )

    return status_outputs, overall


# ── CALLBACK: Export All ─────────────────────────────────────────────
@callback(
    Output("ds-download-export", "data"),
    Input("ds-btn-export-all", "n_clicks"),
    prevent_initial_call=True,
)
def export_all_tables(n_clicks):
    """Export all loaded tables as a ZIP of CSVs — V13: PII masked, formula-sanitized, audit-logged."""
    from utils.data_io import data_vault
    from utils.pii_masking import mask_dataframe, detect_pii_columns

    sources = data_vault.load_sources()
    if not sources:
        raise dash.exceptions.PreventUpdate

    zip_path = PATHS.DATA_VAULT / "export_all_tables.zip"
    total_rows = 0
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, df in sources.items():
            safe_df = df.copy()
            # V13 FIX: Apply PII masking
            pii_cols = detect_pii_columns(safe_df)
            if pii_cols:
                safe_df = mask_dataframe(safe_df, pii_cols)
            # V13 FIX: CSV formula injection protection
            for col in safe_df.select_dtypes(include=["object"]).columns:
                safe_df[col] = safe_df[col].apply(lambda v: "'" + str(v) if isinstance(v, str) and len(v) > 0 and v[0] in ('=', '+', '-', '@') else v)
            zf.writestr(f"{name}.csv", safe_df.to_csv(index=False).encode("utf-8"))
            total_rows += len(safe_df)
    # V13 FIX: Audit log
    try:
        from utils.logger import logger
        logger.log_export(export_type="zip_all", filename="all_tables_export.zip", row_count=total_rows)
    except Exception:
        pass
    return dcc.send_file(str(zip_path), filename="all_tables_export.zip")


# ── CALLBACK: Export Master Data (V20) ───────────────────────────────
@callback(
    Output("ds-download-master", "data"),
    Input("ds-btn-export-master", "n_clicks"),
    prevent_initial_call=True,
)
def export_master_table(n_clicks):
    """V20: Export the current MASTER table as a CSV download."""
    if not n_clicks:
        raise dash.exceptions.PreventUpdate
    global _last_build_result
    if _last_build_result is None or not _last_build_result.success:
        raise dash.exceptions.PreventUpdate
    # V27: Standardized naming — local var aligned to df_master convention
    df_master = _last_build_result.master_df
    if df_master is None or df_master.empty:
        raise dash.exceptions.PreventUpdate
    # Apply PII masking for safe export
    try:
        from utils.pii_masking import mask_dataframe, detect_pii_columns
        safe_df = df_master.copy()
        pii_cols = detect_pii_columns(safe_df)
        if pii_cols:
            safe_df = mask_dataframe(safe_df, pii_cols)
    except Exception:
        safe_df = df_master.copy()
    # Formula injection protection
    for col in safe_df.select_dtypes(include=["object"]).columns:
        safe_df[col] = safe_df[col].apply(
            lambda v: "'" + str(v) if isinstance(v, str) and len(v) > 0 and v[0] in ('=', '+', '-', '@') else v
        )
    # Save and return
    export_path = PATHS.EXPORTS / "MASTER_TABLE.csv"
    export_path.parent.mkdir(parents=True, exist_ok=True)
    safe_df.to_csv(export_path, index=False)
    # Audit log
    try:
        from utils.logger import logger
        logger.log_export(export_type="master_csv", filename="MASTER_TABLE.csv", row_count=len(safe_df))
    except Exception:
        pass
    return dcc.send_file(str(export_path), filename="MASTER_TABLE.csv")


# ── CALLBACK: Delete All ─────────────────────────────────────────────
@callback(
    Output("ds-status-output", "children", allow_duplicate=True),
    Output("ds-summary-table", "children", allow_duplicate=True),
    Output("ds-source-stats", "children", allow_duplicate=True),
    Output("ds-table-previews", "children", allow_duplicate=True),
    Output("ds-consistency-check", "children", allow_duplicate=True),
    Output("ds-customer-aggregate", "children", allow_duplicate=True),
    Output("ds-execution-info", "children", allow_duplicate=True),
    Output("ds-btn-confirm-final", "disabled", allow_duplicate=True),
    Output("ds-execution-choice", "value", allow_duplicate=True),
    Output("ds-final-data-store", "data", allow_duplicate=True),
    Output({"type": "slot-status", "slot": ALL}, "children", allow_duplicate=True),
    Input("ds-btn-delete-all", "n_clicks"),
    State({"type": "slot-status", "slot": ALL}, "id"),
    prevent_initial_call=True,
)
def delete_all_data(n_clicks, slot_ids):
    """Delete all loaded data and reset vault."""
    from utils.data_io import data_vault

    data_vault.clear_data()
    sources_dir = PATHS.DATA_VAULT / "sources"
    if sources_dir.exists():
        for f in sources_dir.glob("*.parquet"):
            f.unlink()
    for f in PATHS.DATA_SOURCES.glob("*.csv"):
        f.unlink()

    status = dmc.Alert("All data deleted.", color="orange",
                       icon=DashIconify(icon="mdi:check"), withCloseButton=True)
    exec_info = dmc.Stack([
        dmc.Group([
            DashIconify(icon="mdi:alert-circle", width=14, color="#ffd43b"),
            dmc.Text("No Data Available", size="xs", fw=600, c="yellow"),
        ], gap=4),
    ], gap=0)

    empty = {}
    slot_statuses = [dmc.Text("Empty", size="10px", c="dimmed", ta="center") for _ in slot_ids]

    return (status,
            _build_loaded_summary(empty, data_vault),
            _build_stats(empty, data_vault),
            _build_preview_tabs(empty),
            _build_consistency_check(empty),
            "",
            exec_info, True, "sample", None, slot_statuses)


# ── CALLBACK: Exclude variable upload ────────────────────────────────
@callback(
    Output("ds-exclude-status", "children"),
    Input("ds-upload-exclude", "contents"),
    State("ds-upload-exclude", "filename"),
    prevent_initial_call=True,
)
def handle_exclude_upload(contents, filename):
    if contents is None:
        return ""
    try:
        from utils.data_io import data_vault
        content_type, content_string = contents.split(",")
        decoded = base64.b64decode(content_string)
        if filename.endswith((".xlsx", ".xls")):
            df = pd.read_excel(io.BytesIO(decoded))
        elif filename.endswith(".csv"):
            df = pd.read_csv(io.StringIO(decoded.decode("utf-8")))
        else:
            return dmc.Alert("Unsupported. Use CSV or Excel.", color="red")
        var_list = (df["variable"].dropna().astype(str).tolist()
                    if "variable" in df.columns
                    else df.iloc[:, 0].dropna().astype(str).tolist())
        with open(PATHS.DATA_VAULT / "exclude_vars.json", "w") as f:
            json.dump(var_list, f)
        return dmc.Alert(f"{len(var_list)} variables loaded for exclusion", color="green",
                         icon=DashIconify(icon="mdi:check-circle"))
    except Exception as e:
        return dmc.Alert("An error occurred. Check audit log for details.", color="red")


# =============================================================================
# HELPER: Rebuild merged view
# =============================================================================
def _rebuild_merged(data_vault):
    """Rebuild merged view from BASE + additional tables."""
    sources = data_vault.load_sources()
    if "BASE" not in sources:
        return
    df_base = sources["BASE"].copy()
    pk_col = resolve(df_base, 'primary_key')
    if pk_col is None:
        return
    for table_name, df_table in sources.items():
        if table_name == "BASE":
            continue
        tpk = resolve(df_table, 'primary_key')
        if tpk and pk_col:
            try:
                df_base = df_base.merge(
                    df_table, left_on=pk_col, right_on=tpk,
                    how="left", suffixes=("", f"_{table_name}")
                )
            except Exception:
                pass
    data_vault.set_current_data(df_base, label="base_merged")


# =============================================================================
# RBAC ENFORCEMENT
# =============================================================================
from auth.manager import require_role as _require_role
_static_layout = layout

@_require_role("investigator")
def layout(**kwargs):
    return _static_layout

