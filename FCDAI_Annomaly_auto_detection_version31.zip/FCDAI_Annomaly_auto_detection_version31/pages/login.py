"""
FCDAI V10 — Login Page
========================
Secure entry point with DMC authentication form.
Handles login/logout via Flask-Login session management.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME

# NOTE: NOT registered as a Dash page — rendered conditionally in app.layout


# =============================================================================
# LOGIN LAYOUT
# =============================================================================
def get_login_layout():
    """Return the login page layout."""
    return dmc.MantineProvider(
        [
            dmc.Center(
                dmc.Stack(
                    [
                        # Logo / Branding
                        dmc.Stack(
                            [
                                dmc.ThemeIcon(
                                    DashIconify(icon="mdi:shield-lock", width=48),
                                    size=80,
                                    radius="xl",
                                    variant="gradient",
                                    gradient={"from": "cyan", "to": "indigo"},
                                ),
                                dmc.Title("AIM AI Vault", order=1, ta="center"),
                                dmc.Text(
                                    "FCDAI Anomaly Auto Detection — V10",
                                    size="sm", c="dimmed", ta="center",
                                ),
                            ],
                            align="center",
                            gap="xs",
                        ),

                        # Login Card
                        dmc.Paper(
                            [
                                dmc.Stack(
                                    [
                                        dmc.Text("Sign In", fw=700, size="lg"),
                                        dmc.Text(
                                            "Enter your credentials to access the system",
                                            size="sm", c="dimmed",
                                        ),

                                        dmc.Divider(my="xs"),

                                        dmc.TextInput(
                                            id="login-username",
                                            label="Username",
                                            placeholder="Enter username",
                                            leftSection=DashIconify(icon="mdi:account", width=18),
                                            required=True,
                                            size="md",
                                        ),
                                        dmc.PasswordInput(
                                            id="login-password",
                                            label="Password",
                                            placeholder="Enter password",
                                            leftSection=DashIconify(icon="mdi:lock", width=18),
                                            required=True,
                                            size="md",
                                        ),

                                        # Error alert (hidden by default)
                                        html.Div(id="login-error"),

                                        dmc.Button(
                                            "Sign In",
                                            id="login-btn",
                                            fullWidth=True,
                                            size="md",
                                            variant="gradient",
                                            gradient={"from": "cyan", "to": "indigo"},
                                            leftSection=DashIconify(icon="mdi:login", width=20),
                                        ),

                                        # F-12 FIX: Default credentials removed from production UI
                                        # Credentials should be communicated via secure channels only
                                        dmc.Text(
                                            "Contact your administrator for access credentials.",
                                            size="xs", c="dimmed", ta="center", mt="xs",
                                        ),
                                    ],
                                    gap="md",
                                ),
                            ],
                            p="xl",
                            radius="lg",
                            withBorder=True,
                            shadow="xl",
                            w=440,
                            style={"backgroundColor": THEME.DARK_BG_CARD},
                        ),

                        # Footer
                        dmc.Text(
                            "Air-Gapped Mode | No External Connections",
                            size="xs", c="dimmed", ta="center",
                        ),
                    ],
                    align="center",
                    gap="lg",
                ),
                style={"minHeight": "100vh", "backgroundColor": THEME.DARK_BG},
            ),
        ],
        forceColorScheme="dark",
        theme=THEME.get_mantine_theme(),
    )
