"""
AIM AI Vault V14 — System Health Monitoring Page
=================================================
Real-time system metrics dashboard showing CPU, memory, disk,
database size, cache size, circuit breaker status, and watchdog alerts.

Author: AIM AI Vault Team
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
from datetime import datetime

from config import APP, WATCHDOG

dash.register_page(
    __name__,
    path="/system-health",
    title=f"System Health — {APP.BRAND} {APP.VERSION_TAG}",
    name="System Health",
)


def _metric_card(title, value, unit, icon, color="cyan", status="ok"):
    """Create a single metric display card."""
    status_colors = {"ok": "green", "warn": "yellow", "critical": "red"}
    return dmc.Paper(
        dmc.Stack([
            dmc.Group([
                dmc.ThemeIcon(
                    DashIconify(icon=icon, width=20),
                    size="lg", radius="md", variant="light", color=color,
                ),
                dmc.Badge(status.upper(), size="xs",
                          color=status_colors.get(status, "gray"), variant="filled"),
            ], justify="space-between"),
            dmc.Text(title, size="xs", c="dimmed", fw=500),
            dmc.Group([
                dmc.Text(str(value), size="xl", fw=700),
                dmc.Text(unit, size="sm", c="dimmed"),
            ], gap="xs"),
        ], gap="xs"),
        p="md", radius="md", withBorder=True,
    )


def layout(**kwargs):
    return dmc.Container([
        # Header
        dmc.Group([
            dmc.Stack([
                dmc.Title("System Health Monitor", order=2),
                dmc.Group([
                    dmc.Badge(APP.VERSION_TAG, color=APP.BADGE_COLOR, variant="filled", size="lg"),
                    dmc.Text("Real-time system resource monitoring", c="dimmed", size="sm"),
                ], gap="xs"),
            ], gap=4),
            dmc.ActionIcon(
                DashIconify(icon="mdi:refresh", width=20),
                id="health-refresh-btn", variant="light", color="cyan", size="lg",
            ),
        ], justify="space-between", mb="lg"),

        # Auto-refresh interval
        dcc.Interval(id="health-interval", interval=10_000, n_intervals=0),

        # Metrics Grid
        html.Div(id="health-metrics-grid"),

        dmc.Space(h="md"),

        # Charts Row
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2},
            spacing="md",
            children=[
                dmc.Paper([
                    dmc.Text("Memory Usage (Last 30 min)", fw=600, mb="sm"),
                    dcc.Graph(id="health-memory-chart", config=APP.PLOTLY_CONFIG,
                              style={"height": "280px"}),
                ], p="md", radius="md", withBorder=True),
                dmc.Paper([
                    dmc.Text("CPU Usage (Last 30 min)", fw=600, mb="sm"),
                    dcc.Graph(id="health-cpu-chart", config=APP.PLOTLY_CONFIG,
                              style={"height": "280px"}),
                ], p="md", radius="md", withBorder=True),
            ],
        ),

        dmc.Space(h="md"),

        # Circuit Breaker Status
        dmc.Paper([
            dmc.Text("Circuit Breaker Status", fw=600, mb="sm"),
            html.Div(id="health-circuit-breakers"),
        ], p="md", radius="md", withBorder=True),

        dmc.Space(h="md"),

        # Watchdog Alerts
        dmc.Paper([
            dmc.Group([
                dmc.Text("Watchdog Alerts", fw=600),
                dmc.Button("Clear", id="health-clear-alerts-btn", size="xs",
                           variant="subtle", color="gray"),
            ], justify="space-between"),
            html.Div(id="health-alerts-list"),
        ], p="md", radius="md", withBorder=True),

    ], size="xl", py="md")


@callback(
    Output("health-metrics-grid", "children"),
    Output("health-memory-chart", "figure"),
    Output("health-cpu-chart", "figure"),
    Output("health-circuit-breakers", "children"),
    Output("health-alerts-list", "children"),
    Input("health-interval", "n_intervals"),
    Input("health-refresh-btn", "n_clicks"),
)
def update_health_dashboard(n_intervals, n_clicks):
    """Refresh all health metrics."""
    try:
        from utils.watchdog import SystemWatchdog
        wd = SystemWatchdog()
        metrics = wd.get_latest_metrics()
        history = wd.get_metrics_history(minutes=30)
        alerts = wd.get_alerts(limit=20)
    except Exception:
        metrics = {}
        history = []
        alerts = []

    # ── Metric Cards ──
    mem_pct = metrics.get("memory_percent", 0)
    mem_status = "critical" if mem_pct > WATCHDOG.MEMORY_CRITICAL_PERCENT else (
        "warn" if mem_pct > WATCHDOG.MEMORY_WARN_PERCENT else "ok")

    disk_pct = metrics.get("disk_percent", 0)
    disk_status = "critical" if disk_pct > WATCHDOG.DISK_CRITICAL_PERCENT else (
        "warn" if disk_pct > WATCHDOG.DISK_WARN_PERCENT else "ok")

    cards = dmc.SimpleGrid(
        cols={"base": 2, "sm": 3, "lg": 6},
        spacing="md",
        children=[
            _metric_card("CPU Usage", f"{metrics.get('cpu_system_percent', 0):.0f}",
                         "%", "mdi:cpu-64-bit", "blue", "ok"),
            _metric_card("Memory", f"{mem_pct:.0f}",
                         f"% ({metrics.get('memory_rss_mb', 0):.0f} MB RSS)",
                         "mdi:memory", "cyan", mem_status),
            _metric_card("Disk", f"{disk_pct:.0f}",
                         f"% ({metrics.get('disk_free_gb', 0):.1f} GB free)",
                         "mdi:harddisk", "orange", disk_status),
            _metric_card("Database", f"{metrics.get('db_size_mb', 0):.1f}",
                         "MB", "mdi:database", "violet", "ok"),
            _metric_card("Cache", f"{metrics.get('cache_size_mb', 0):.1f}",
                         "MB", "mdi:cached", "teal", "ok"),
            _metric_card("Threads", f"{metrics.get('thread_count', 0)}",
                         "active", "mdi:cogs", "gray", "ok"),
        ],
    )

    # ── Memory Chart ──
    mem_fig = go.Figure()
    if history:
        timestamps = [h.get("timestamp", "") for h in history]
        mem_values = [h.get("memory_percent", 0) for h in history]
        mem_fig.add_trace(go.Scatter(
            x=timestamps, y=mem_values, mode="lines",
            fill="tozeroy", line=dict(color="#15aabf", width=2),
            fillcolor="rgba(21,170,191,0.1)", name="Memory %",
        ))
        mem_fig.add_hline(y=WATCHDOG.MEMORY_WARN_PERCENT,
                          line_dash="dash", line_color="orange",
                          annotation_text="Warning")
    mem_fig.update_layout(
        template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)", margin=dict(l=40, r=20, t=10, b=30),
        yaxis=dict(range=[0, 100], title=""),
        xaxis=dict(title=""),
        showlegend=False,
    )

    # ── CPU Chart ──
    cpu_fig = go.Figure()
    if history:
        timestamps = [h.get("timestamp", "") for h in history]
        cpu_values = [h.get("cpu_system_percent", 0) for h in history]
        cpu_fig.add_trace(go.Scatter(
            x=timestamps, y=cpu_values, mode="lines",
            fill="tozeroy", line=dict(color="#4c6ef5", width=2),
            fillcolor="rgba(76,110,245,0.1)", name="CPU %",
        ))
    cpu_fig.update_layout(
        template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)", margin=dict(l=40, r=20, t=10, b=30),
        yaxis=dict(range=[0, 100], title=""),
        xaxis=dict(title=""),
        showlegend=False,
    )

    # ── Circuit Breakers ──
    try:
        from utils.circuit_breaker import cb_registry
        cb_statuses = cb_registry.get_all_status()
        if cb_statuses:
            cb_rows = []
            for name, status in cb_statuses.items():
                state = status.get("state", "CLOSED")
                color = "green" if state == "CLOSED" else ("yellow" if state == "HALF_OPEN" else "red")
                cb_rows.append(
                    dmc.Group([
                        dmc.Badge(state, color=color, size="sm", variant="filled"),
                        dmc.Text(name, size="sm"),
                        dmc.Text(f"calls: {status.get('total_calls', 0)}", size="xs", c="dimmed"),
                        dmc.Text(f"fails: {status.get('total_failures', 0)}", size="xs", c="dimmed"),
                    ], gap="sm", mb="xs")
                )
            cb_content = dmc.Stack(cb_rows, gap="xs")
        else:
            cb_content = dmc.Text("No circuit breakers active", c="dimmed", size="sm")
    except Exception:
        cb_content = dmc.Text("Circuit breaker module unavailable", c="dimmed", size="sm")

    # ── Alerts ──
    if alerts:
        alert_items = [
            dmc.Alert(
                a.get("message", "Unknown alert"),
                color="red" if a.get("severity") == "CRITICAL" else "yellow",
                title=f"{a.get('severity', 'ALERT')} — {a.get('component', '')}",
                withCloseButton=False,
                mb="xs",
            )
            for a in alerts[:10]
        ]
    else:
        alert_items = [dmc.Text("No watchdog alerts", c="dimmed", size="sm")]

    return cards, mem_fig, cpu_fig, cb_content, alert_items


@callback(
    Output("health-alerts-list", "children", allow_duplicate=True),
    Input("health-clear-alerts-btn", "n_clicks"),
    prevent_initial_call=True,
)
def clear_alerts(n_clicks):
    if not n_clicks:
        return no_update
    try:
        from utils.watchdog import SystemWatchdog
        SystemWatchdog().clear_alerts()
    except Exception:
        pass
    return [dmc.Text("Alerts cleared", c="dimmed", size="sm")]
