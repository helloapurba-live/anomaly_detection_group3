"""
Dashboard Page — Read-Only View
================================
Displays data source stats and pipeline output from vault.
No controls — those are on Data Sources and Pipeline pages.
Auto-refreshes from persisted vault data.
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from datetime import datetime
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP, LAYERS

dash.register_page(__name__, path="/", name="Dashboard", order=0)


# =============================================================================
# KPI CARD COMPONENT
# =============================================================================
def create_kpi_card(title, value, subtitle="", icon="mdi:chart-line",
                    color=THEME.PRIMARY):
    return dmc.Paper(
        [
            dmc.Group(
                [
                    dmc.ThemeIcon(
                        DashIconify(icon=icon, width=24),
                        size="xl", radius="md", variant="light",
                        color=color.replace("#", ""),
                    ),
                    dmc.Stack(
                        [
                            dmc.Text(title, size="sm", c="dimmed"),
                            dmc.Text(value, size="xl", fw=700),
                            dmc.Text(subtitle, size="xs", c="dimmed") if subtitle else None,
                        ],
                        gap=2,
                    ),
                ],
                gap="md",
            ),
        ],
        p="md", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD},
    )


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Container(
    [
        # Header
        dmc.Group(
            [
                dmc.Group([
                    dmc.Title("Dashboard", order=2),
                    dmc.Badge("Customer-Level Analytics", color="cyan", variant="light"),
                ], gap="md"),
                dmc.Group([
                    dmc.Button(
                        "Clear Cache",
                        id="dashboard-btn-clear-cache",
                        leftSection=DashIconify(icon="mdi:delete-sweep"),
                        color="red", variant="light", size="sm",
                    ),
                    dmc.Button(
                        "Refresh",
                        id="dashboard-btn-refresh",
                        leftSection=DashIconify(icon="mdi:refresh"),
                        color="cyan", variant="subtle", size="sm",
                    ),
                ], gap="xs"),
            ],
            justify="space-between",
            mb="lg",
        ),
        
        # Cache clear status
        html.Div(id="dashboard-cache-status", style={"marginBottom": "15px"}),

        # 0. QUICK LINKS
        dmc.Group(
            [
                dcc.Link(
                    dmc.Button(
                        "Manage Data Sources",
                        leftSection=DashIconify(icon="mdi:database-import"),
                        color="blue", variant="light", size="sm",
                    ),
                    href="/sources",
                ),
                dcc.Link(
                    dmc.Button(
                        "Run Pipeline",
                        leftSection=DashIconify(icon="mdi:rocket-launch"),
                        color="cyan", variant="light", size="sm",
                    ),
                    href="/pipeline",
                ),
            ],
            gap="sm",
            mb="lg",
        ),

        # 1. DATA SOURCE STATS
        html.Div(id="dash-source-stats"),

        dmc.Space(h="lg"),

        # 2. PIPELINE RUN SUMMARY
        html.Div(id="dash-pipeline-summary"),

        dmc.Space(h="lg"),

        # 3. TOP ROW: KPIs
        html.Div(id="dash-kpi-row"),

        dmc.Space(h="lg"),

        # 4. SYSTEM PIPELINE STATUS (Visual Grid)
        html.Div(id="dash-layer-status"),

        dmc.Space(h="lg"),

        # 5. CHARTS ROW
        dmc.Paper(
            [
                dmc.Text("Detection Methods by Category", fw=600, mb="sm"),
                dcc.Graph(id="chart-methods-cat", config=APP.PLOTLY_CONFIG, style={"height": "350px"}),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
        ),

        dmc.Space(h="lg"),

        # 6. SECONDARY CHARTS
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2},
            spacing="lg",
            children=[
                dmc.Paper(
                    [
                        dmc.Text("Risk Tier Distribution", fw=600, mb="sm"),
                        dcc.Graph(id="chart-risk-dist", config=APP.PLOTLY_CONFIG, style={"height": "300px"}),
                    ],
                    p="md", radius="md", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD},
                ),
                dmc.Paper(
                    [
                        dmc.Text("Algorithm Detection Rate", fw=600, mb="sm"),
                        dcc.Graph(id="chart-algo-perf", config=APP.PLOTLY_CONFIG, style={"height": "300px"}),
                    ],
                    p="md", radius="md", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD},
                ),
                dmc.Paper(
                    [
                        dmc.Text("Alert Volume Trend", fw=600, mb="sm"),
                        dcc.Graph(id="chart-alert-trend", config=APP.PLOTLY_CONFIG, style={"height": "300px"}),
                    ],
                    p="md", radius="md", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD},
                ),
                dmc.Paper(
                    [
                        dmc.Text("Risk Heatmap", fw=600, mb="sm"),
                        dcc.Graph(id="chart-heatmap", config=APP.PLOTLY_CONFIG, style={"height": "300px"}),
                    ],
                    p="md", radius="md", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD},
                ),
            ],
        ),

        # Refresh interval (V13 B-1: 30s instead of 15s to reduce Parquet reloads)
        dcc.Interval(id="dashboard-refresh", interval=30000, n_intervals=0),
    ],
    fluid=True,
)


# =============================================================================
# CALLBACKS — all read from vault, no controls
# =============================================================================

@callback(
    Output("dashboard-cache-status", "children"),
    Input("dashboard-btn-clear-cache", "n_clicks"),
    prevent_initial_call=True,
)
def clear_cache(n_clicks):
    """Clear all cached data and reset the data vault."""
    if n_clicks is None:
        return None
    
    try:
        from utils.data_io import data_vault
        import shutil
        import os
        from pathlib import Path
        
        cleared_items = []
        
        # Clear data vault
        try:
            data_vault.clear_data()
            cleared_items.append("Data vault")
        except Exception as e:
            pass
        
        # Remove cache directory contents (not the directory itself)
        cache_dir = Path(__file__).parent.parent / "cache"
        if cache_dir.exists():
            try:
                for item in cache_dir.iterdir():
                    try:
                        if item.is_file():
                            item.unlink()
                        elif item.is_dir():
                            shutil.rmtree(item, ignore_errors=True)
                    except Exception:
                        pass
                cleared_items.append("Cache files")
            except Exception:
                pass
        
        # Remove __pycache__ directories more safely
        base_dir = Path(__file__).parent.parent
        pycache_count = 0
        for pycache in base_dir.rglob("__pycache__"):
            if pycache.is_dir():
                try:
                    shutil.rmtree(pycache, ignore_errors=True)
                    pycache_count += 1
                except Exception:
                    pass
        if pycache_count > 0:
            cleared_items.append(f"{pycache_count} __pycache__ dirs")
        
        message = "Cleared: " + ", ".join(cleared_items) if cleared_items else "Cache cleared!"
        
        return dmc.Alert(
            [
                DashIconify(icon="mdi:check-circle", width=20),
                dmc.Text(message, ml="xs"),
            ],
            color="green",
            variant="light",
            withCloseButton=True,
        )
    except Exception as e:
        return dmc.Alert(
            [
                DashIconify(icon="mdi:alert-circle", width=20),
                dmc.Text("Cache clear failed. Check audit log.", ml="xs"),
            ],
            color="red",
            variant="light",
            withCloseButton=True,
        )


@callback(
    Output("dash-source-stats", "children"),
    Input("dashboard-refresh", "n_intervals"),
    Input("dashboard-btn-refresh", "n_clicks"),
    Input("store-pipeline-complete", "data"),
)
def update_source_stats(n, btn_refresh, pipeline_complete):
    """Show data source stats from vault."""
    try:
        from utils.data_io import data_vault
        # V8: Force reload from disk for cross-page sync
        data_vault.reload_from_disk()
        stats = data_vault.get_source_stats()

        if stats["table_count"] == 0:
            return dmc.Alert(
                "No data loaded. Go to Data Sources page to generate data.",
                color="gray",
                icon=DashIconify(icon="mdi:information"),
            )

        cards = []
        for name, info in stats["tables"].items():
            cards.append(
                dmc.Paper(
                    dmc.Stack([
                        dmc.Text(name.title(), size="sm", fw=600),
                        dmc.Text(f"{info['rows']:,} rows", size="xs", c="dimmed"),
                    ], gap=0),
                    p="xs", radius="md", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD, "textAlign": "center"},
                )
            )

        return dmc.Paper(
            [
                dmc.Group([
                    dmc.Text("Data Sources", fw=600),
                    dmc.Badge(f"{stats['table_count']} tables • {stats['total_rows']:,} rows", color="cyan", variant="light"),
                ], justify="space-between", mb="sm"),
                dmc.SimpleGrid(cols={"base": 3, "md": 6}, spacing="xs", children=cards),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
        )
    except Exception:
        return html.Div()


@callback(
    Output("dash-pipeline-summary", "children"),
    Input("dashboard-refresh", "n_intervals"),
    Input("dashboard-btn-refresh", "n_clicks"),
    Input("store-pipeline-complete", "data"),
)
def update_pipeline_summary(n, btn_refresh, pipeline_complete):
    """Show pipeline run summary from vault."""
    try:
        from utils.data_io import data_vault
        result = data_vault.load_pipeline_result()

        if not result:
            return dmc.Alert(
                "Pipeline has not been run yet. Go to Pipeline page to execute.",
                color="gray",
                icon=DashIconify(icon="mdi:rocket-launch-outline"),
            )

        time_str = result.get("timestamp", "N/A")
        if time_str and time_str != "N/A":
            try:
                time_str = time_str[:19]
            except Exception:
                pass

        return dmc.Paper(
            [
                dmc.Group([
                    dmc.Text("Last Pipeline Run (Customer-Level)", fw=600),
                    dmc.Badge("✓ Completed" if result.get("success") else "✗ Failed",
                              color="green" if result.get("success") else "red", variant="light"),
                ], justify="space-between", mb="sm"),
                dmc.Text(
                    "Data aggregated at customer level - all statistics reflect unique customers, not individual transactions/alerts.",
                    size="xs", c="dimmed", mb="sm"
                ),
                dmc.SimpleGrid(
                    cols={"base": 2, "md": 4, "lg": 6},
                    spacing="sm",
                    children=[
                        _stat("Customers", f"{result.get('records_processed', 0):,}"),
                        _stat("DQ Score", f"{result.get('dq_score', 0):.0%}"),
                        _stat("Features", str(result.get("features_generated", 0))),
                        _stat("Methods", str(result.get("methods_run", 0))),
                        _stat("High-Risk", str(result.get("alerts_generated", 0))),
                        _stat("Time", f"{result.get('execution_time_ms', 0):.0f}ms"),
                    ],
                ),
                dmc.Space(h="sm"),
                dmc.Group([
                    dmc.Badge(f"Critical: {result.get('tier_distribution', {}).get('Critical', 0)}", color="red"),
                    dmc.Badge(f"High: {result.get('tier_distribution', {}).get('High', 0)}", color="orange"),
                    dmc.Badge(f"Medium: {result.get('tier_distribution', {}).get('Medium', 0)}", color="yellow"),
                    dmc.Badge(f"Low: {result.get('tier_distribution', {}).get('Low', 0)}", color="green"),
                ]),
                dmc.Text(f"Run at: {time_str}", size="xs", c="dimmed", mt="xs"),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
        )
    except Exception:
        return html.Div()


def _stat(label, value):
    return dmc.Stack([
        dmc.Text(label, size="xs", c="dimmed"),
        dmc.Text(value, fw=600),
    ], gap=0)


@callback(
    Output("dash-kpi-row", "children"),
    Input("dashboard-refresh", "n_intervals"),
    Input("dashboard-btn-refresh", "n_clicks"),
    Input("store-pipeline-complete", "data"),
)
def update_kpi_row(n, btn_refresh, pipeline_complete):
    try:
        from utils.data_io import data_vault
        df = data_vault.get_scored_data()
        result = data_vault.load_pipeline_result()

        queue_count = 0
        total_records = 0
        active_methods = 0

        if df is not None:
            total_records = len(df)
            if 'anomaly_score' in df.columns:
                queue_count = int((df['anomaly_score'] > 0.8).sum())
            score_cols = [c for c in df.columns if c.startswith('score_')]
            active_methods = len(score_cols)

        total_methods = sum(len(m) for m in LAYERS.DETECTION_METHODS.values())

        return dmc.SimpleGrid(
            cols={"base": 2, "md": 4},
            spacing="lg",
            children=[
                create_kpi_card("Layers", "7", "Pipeline Depth", "mdi:layers-triple", THEME.PRIMARY),
                create_kpi_card("Methods", f"{active_methods}/{total_methods}", "Active/Total", "mdi:function", THEME.SECONDARY),
                create_kpi_card("Records", f"{total_records:,}", "Processed", "mdi:database", "#FFC107"),
                create_kpi_card("Queue", str(queue_count), "High Risk Items", "mdi:tray-alert", THEME.DANGER),
            ],
        )
    except Exception:
        return html.Div()


@callback(
    Output("dash-layer-status", "children"),
    Input("dashboard-refresh", "n_intervals"),
    Input("dashboard-btn-refresh", "n_clicks"),
    Input("store-pipeline-complete", "data"),
)
def update_layer_status(n, btn_refresh, pipeline_complete):
    """Show per-layer status from pipeline result."""
    try:
        from utils.data_io import data_vault
        result = data_vault.load_pipeline_result()
        timings = result.get("layer_timings", {}) if result else {}

        layers = [
            ("L01", "Ingest"), ("L04", "Features"), ("L06_L10", "Preprocess"),
            ("L11", "Detection"), ("L13", "Ensemble"), ("L14", "Output"),
        ]

        cards = []
        for label, desc in layers:
            t = timings.get(label, timings.get(desc, None))
            has_run = result.get("success", False) if result else False

            if has_run:
                icon = "mdi:check-circle"
                color = "green"
                bg = "rgba(0,100,0,0.1)"
            else:
                icon = "mdi:clock-outline"
                color = "gray"
                bg = "rgba(100,100,100,0.1)"

            cards.append(
                dmc.Paper(
                    [
                        dmc.Text(label, fw=600, ta="center"),
                        dmc.Text(desc, size="xs", c="dimmed", ta="center"),
                        dmc.Center(
                            dmc.ThemeIcon(
                                DashIconify(icon=icon, width=20),
                                color=color, variant="light", mt="xs",
                            )
                        ),
                        dmc.Text(f"{t:.2f}s" if t else "", size="xs", c="dimmed", ta="center", mt="xs") if t else None,
                    ],
                    p="sm", radius="md",
                    style={"backgroundColor": bg},
                )
            )

        return dmc.Paper(
            [
                dmc.Text("System Pipeline Status", fw=600, mb="md"),
                dmc.SimpleGrid(cols={"base": 2, "md": 4, "lg": 6}, spacing="md", children=cards),
            ],
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
        )
    except Exception:
        return html.Div()


# =============================================================================
# CHART CALLBACKS — read from scored data in vault
# =============================================================================

@callback(Output("chart-methods-cat", "figure"), Input("dashboard-refresh", "n_intervals"), Input("dashboard-btn-refresh", "n_clicks"))
def update_methods_cat(n, btn_refresh):
    try:
        categories, counts = [], []
        for cat, methods in LAYERS.DETECTION_METHODS.items():
            categories.append(cat.replace("_", " ").title())
            counts.append(len(methods))

        fig = px.bar(x=categories, y=counts, template="plotly_dark",
                     color=categories, color_discrete_sequence=px.colors.qualitative.Set2)
        fig.update_layout(
            margin=dict(l=20, r=20, t=20, b=20),
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            showlegend=False, xaxis_title=None, yaxis_title="Count", xaxis_tickangle=-45,
        )
        return fig
    except Exception:
        return go.Figure()


@callback(Output("chart-risk-dist", "figure"), Input("dashboard-refresh", "n_intervals"), Input("dashboard-btn-refresh", "n_clicks"))
def update_risk_dist(n, btn_refresh):
    try:
        from utils.data_io import data_vault
        df = data_vault.get_scored_data()
        if df is None or 'risk_tier' not in df.columns:
            return go.Figure()

        counts = df['risk_tier'].value_counts()
        color_map = {'Critical': THEME.DANGER, 'High': '#FF9800', 'Medium': THEME.WARNING, 'Low': THEME.SUCCESS}

        fig = px.pie(values=counts.values, names=counts.index, color=counts.index,
                     color_discrete_map=color_map, hole=0.4, template="plotly_dark")
        fig.update_layout(margin=dict(l=20, r=20, t=20, b=20), paper_bgcolor="rgba(0,0,0,0)",
                          legend=dict(orientation="h", y=-0.1))
        return fig
    except Exception:
        return go.Figure()


@callback(Output("chart-alert-trend", "figure"), Input("dashboard-refresh", "n_intervals"))
def update_trend_chart(n):
    try:
        from utils.data_io import data_vault
        df = data_vault.get_scored_data()
        if df is None or 'anomaly_score' not in df.columns:
            fig = go.Figure()
            fig.update_layout(
                annotations=[dict(text="No scored data — run pipeline first", showarrow=False, font=dict(size=14, color="#888"))],
                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", template="plotly_dark",
            )
            return fig

        # Try to build real daily alert trend from timestamp column
        dates, counts = None, None
        if 'timestamp' in df.columns:
            df_ts = df.copy()
            df_ts['date'] = pd.to_datetime(df_ts['timestamp'], errors='coerce').dt.date
            daily = df_ts[df_ts['anomaly_score'] > 0.5].groupby('date').size()
            if len(daily) > 1:
                dates = daily.index
                counts = daily.values

        if dates is None or counts is None:
            # Aggregate by record index as fallback (no random data)
            n_alerts = int((df['anomaly_score'] > 0.5).sum())
            fig = go.Figure()
            fig.add_annotation(text=f"{n_alerts} alerts found — no timestamp for daily trend", showarrow=False, font=dict(size=13, color="#888"))
            fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", template="plotly_dark")
            return fig

        fig = px.area(x=dates, y=counts, template="plotly_dark")
        fig.update_traces(line_color=THEME.PRIMARY, fillcolor="rgba(0, 212, 255, 0.2)")
        fig.update_layout(margin=dict(l=20, r=20, t=20, b=20),
                          paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                          xaxis_title=None, yaxis_title="Alerts")
        return fig
    except Exception:
        return go.Figure()


@callback(Output("chart-heatmap", "figure"), Input("dashboard-refresh", "n_intervals"), Input("dashboard-btn-refresh", "n_clicks"))
def update_heatmap(n, btn_refresh):
    try:
        from utils.data_io import data_vault
        hours = list(range(24))
        days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        z = np.zeros((7, 24))  # Default: empty heatmap

        # Try to build real heatmap from scored data
        df = data_vault.get_scored_data()
        if df is not None and 'timestamp' in df.columns and 'anomaly_score' in df.columns:
            df_hm = df[df['anomaly_score'] > 0.5].copy()
            df_hm['ts'] = pd.to_datetime(df_hm['timestamp'], errors='coerce')
            df_hm = df_hm.dropna(subset=['ts'])
            if len(df_hm) > 0:
                df_hm['dow'] = df_hm['ts'].dt.dayofweek  # 0=Mon
                df_hm['hour'] = df_hm['ts'].dt.hour
                for _, row in df_hm.iterrows():
                    z[int(row['dow'])][int(row['hour'])] += 1

        fig = go.Figure(data=go.Heatmap(
            z=z, x=hours, y=days,
            colorscale=[[0, THEME.SUCCESS], [0.5, THEME.WARNING], [1, THEME.DANGER]]
        ))
        fig.update_layout(margin=dict(l=20, r=20, t=20, b=20),
                          paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                          template="plotly_dark", xaxis_title="Hour of Day")
        return fig
    except Exception:
        return go.Figure()


@callback(Output("chart-algo-perf", "figure"), Input("dashboard-refresh", "n_intervals"), Input("dashboard-btn-refresh", "n_clicks"))
def update_algo_perf(n, btn_refresh):
    try:
        from utils.data_io import data_vault
        df = data_vault.get_scored_data()
        if df is None:
            return go.Figure()

        score_cols = [c for c in df.columns if c.startswith('score_')]
        if not score_cols:
            return go.Figure()

        rates = []
        for col in score_cols:
            rate = (df[col] > 0.5).mean() * 100
            rates.append({'Algo': col.replace('score_', ''), 'Rate': rate})

        rate_df = pd.DataFrame(rates).sort_values('Rate')

        fig = px.bar(rate_df, x='Rate', y='Algo', orientation='h', template="plotly_dark")
        fig.update_traces(marker_color=THEME.SECONDARY)
        fig.update_layout(margin=dict(l=20, r=20, t=20, b=20),
                          paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                          xaxis_title="Detection Rate (%)", yaxis_title=None)
        return fig
    except Exception:
        return go.Figure()


# =============================================================================
# RBAC ENFORCEMENT
# =============================================================================
from auth.manager import require_role as _require_role
_static_layout = layout

@_require_role("viewer")
def layout(**kwargs):
    return _static_layout
