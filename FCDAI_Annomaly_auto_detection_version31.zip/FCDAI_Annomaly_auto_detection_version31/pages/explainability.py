"""
AIM AI Vault V14 — Explainability Page
============================================
Customer-level explanations and feature contributions.
Provides interpretable "Why" for each flagged customer.

Author: AIM AI Vault Team
"""

import dash
from dash import html, dcc, callback, Input, Output, State
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import THEME, APP


dash.register_page(__name__, path="/explainability", name="Explainability", order=5)


# =============================================================================
# PAGE LAYOUT
# =============================================================================
layout = dmc.Container(
    [
        # Header
        dmc.Group(
            [
                dmc.Group([
                    dmc.Title("Customer Explainability", order=2),
                    dmc.Badge("Feature Analysis", color="cyan", variant="light"),
                ], gap="md"),
                dmc.Button(
                    "Refresh",
                    id="explainability-btn-refresh",
                    leftSection=DashIconify(icon="mdi:refresh"),
                    color="cyan", variant="subtle", size="sm",
                ),
            ],
            justify="space-between",
            mb="lg",
        ),
        
        # Customer Selection
        dmc.Paper(
            [
                dmc.Text("Search for Customer", fw=600, mb="md"),
                dmc.SimpleGrid(
                    cols={"base": 1, "md": 3},
                    spacing="md",
                    children=[
                        dmc.TextInput(
                            id="customer-search",
                            label="Customer Name or ID",
                            placeholder="Enter customer name or ID...",
                            leftSection=DashIconify(icon="mdi:magnify", width=18),
                        ),
                        dmc.Button(
                            "Analyze Customer",
                            id="btn-analyze",
                            leftSection=DashIconify(icon="mdi:account-search", width=18),
                            color="cyan",
                            mt="xl",
                        ),
                        dmc.Button(
                            "Next High-Risk Customer",
                            id="btn-next-customer",
                            leftSection=DashIconify(icon="mdi:arrow-right", width=18),
                            variant="light",
                            mt="xl",
                        ),
                    ],
                ),
            ],
            p="md",
            mb="lg",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),
        
        # Customer Summary Card
        html.Div(id="customer-summary-card"),
        
        dmc.Space(h="lg"),
        
        # Explanation Charts
        dmc.SimpleGrid(
            cols={"base": 1, "md": 2},
            spacing="lg",
            children=[
                dmc.Paper(
                    [
                        dmc.Text("Feature Contribution", fw=600, mb="sm"),
                        dcc.Graph(
                            id="chart-feature-contribution",
                            config=APP.PLOTLY_CONFIG,
                            style={"height": "350px"},
                        ),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}
                ),
                dmc.Paper(
                    [
                        dmc.Text("Reasoning Breakdown", fw=600, mb="sm"),
                        html.Div(id="reasoning-breakdown"),
                    ],
                    p="md",
                    radius="md",
                    withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD, "minHeight": "350px"}
                ),
            ],
        ),
        
        dmc.Space(h="lg"),
        
        # Global Feature Importance
        dmc.Paper(
            [
                dmc.Text("Global Feature Importance (All Customers)", fw=600, mb="sm"),
                dcc.Graph(
                    id="chart-global-importance",
                    config=APP.PLOTLY_CONFIG,
                    style={"height": "300px"},
                ),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),
        
        dmc.Space(h="lg"),
        
        # Risk Group Analysis
        dmc.Paper(
            [
                dmc.Text("Risk Group-Wise Analysis", fw=600, mb="sm"),
                html.Div(id="risk-group-analysis"),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        ),
        
        # Store for current customer data
        dcc.Store(id="store-current-customer"),
    ],
    fluid=True,
)


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("customer-summary-card", "children"),
    Output("store-current-customer", "data"),
    Input("btn-analyze", "n_clicks"),
    Input("btn-next-customer", "n_clicks"),
    State("customer-search", "value"),
    prevent_initial_call=True,
)
def analyze_customer(analyze_clicks, next_clicks, search_value):
    """Analyze selected customer by name or ID and show summary."""
    try:
        from utils.data_io import data_vault
        from dash import ctx
        
        df = data_vault.get_scored_data()
        
        if df is None or 'anomaly_score' not in df.columns:
            return dmc.Alert(
                "No scored data available. Run the execution engine first.",
                color="yellow",
            ), None
        
        # Find high-risk customers
        high_risk_df = df[df['anomaly_score'] > 0.5]
        
        if high_risk_df.empty:
            return dmc.Alert(
                "No high-risk customers detected in current dataset.",
                color="green",
            ), None
        
        # Handle next customer button
        if ctx.triggered_id == "btn-next-customer":
            # Just get the first or next high-risk customer
            customer_idx = high_risk_df.index[0]
            row = high_risk_df.iloc[0]
        else:
            # Search for customer by name or ID
            if not search_value:
                return dmc.Alert(
                    "Please enter a customer name or ID to search.",
                    color="blue",
                ), None
            
            # Try to find customer by name or ID (case-insensitive partial match)
            search_lower = str(search_value).lower()
            matches = df[
                df.apply(lambda r: (
                    (search_lower in str(r.get('customer_name', '')).lower()) or
                    (search_lower in str(r.get('customer_id', '')).lower()) or
                    (search_lower in str(r.get('party_id', '')).lower())
                ), axis=1)
            ]
            
            if matches.empty:
                return dmc.Alert(
                    f"No customer found matching '{search_value}'. Try a different name or ID.",
                    color="orange",
                ), None
            
            # Take first match
            customer_idx = matches.index[0]
            row = matches.iloc[0]
        
        # Build summary card
        score = row.get('anomaly_score', 0)
        risk_level = row.get('risk_tier', 'Unknown')
        
        risk_color = {
            'Critical': 'red',
            'High': 'orange',
            'Medium': 'yellow',
            'Low': 'green',
        }.get(risk_level, 'gray')
        
        summary = dmc.Paper(
            [
                dmc.Group(
                    [
                        dmc.Stack(
                            [
                                dmc.Text(f"Customer #{customer_idx}", fw=700, size="lg"),
                                dmc.Badge(risk_level, color=risk_color, size="lg"),
                            ],
                            gap="xs",
                        ),
                        dmc.Stack(
                            [
                                dmc.Text("Anomaly Score", size="sm", c="dimmed"),
                                dmc.Text(f"{score:.3f}", fw=700, size="xl"),
                            ],
                            gap=0,
                            align="center",
                        ),
                        dmc.Stack(
                            [
                                dmc.Text("Position", size="sm", c="dimmed"),
                                dmc.Text(
                                    f"{list(high_risk_df.index).index(customer_idx) + 1} of {len(high_risk_df)}" 
                                    if customer_idx in high_risk_df.index else "N/A",
                                    fw=500,
                                ),
                            ],
                            gap=0,
                            align="center",
                        ),
                    ],
                    justify="space-between",
                ),
            ],
            p="md",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}
        )
        
        return summary, {"idx": customer_idx, "score": score}
        
    except Exception as e:
        return dmc.Alert("An error occurred. Check audit log for details.", color="red"), None


@callback(
    Output("chart-feature-contribution", "figure"),
    Input("store-current-customer", "data"),
)
def update_feature_contribution(customer_data):
    """Update feature contribution waterfall chart."""
    try:
        from utils.data_io import data_vault
        
        if not customer_data:
            return go.Figure()
        
        df = data_vault.get_scored_data()
        if df is None:
            return go.Figure()
        
        idx = customer_data['idx']
        
        # Get score columns for contribution
        score_cols = [c for c in df.columns if c.startswith('score_')]
        
        if not score_cols:
            # Use numeric columns as proxy
            numeric_cols = df.select_dtypes(include=[np.number]).columns[:10]
            contributions = df.iloc[idx][numeric_cols].to_dict()
        else:
            contributions = df.iloc[idx][score_cols].to_dict()
        
        # Sort by absolute value
        sorted_contrib = sorted(contributions.items(), key=lambda x: abs(x[1]), reverse=True)[:10]
        
        names = [c.replace('score_', '').replace('_', ' ').title() for c, _ in sorted_contrib]
        values = [v for _, v in sorted_contrib]
        colors = [THEME.DANGER if v > 0.5 else THEME.PRIMARY for v in values]
        
        fig = go.Figure(go.Bar(
            y=names,
            x=values,
            orientation='h',
            marker_color=colors,
        ))
        
        fig.update_layout(
            template="plotly_dark",
            margin=dict(l=20, r=20, t=20, b=20),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            xaxis_title="Contribution to Risk Score",
            yaxis=dict(autorange="reversed"),
        )
        
        return fig
        
    except Exception:
        return go.Figure()


@callback(
    Output("reasoning-breakdown", "children"),
    Input("store-current-customer", "data"),
)
def update_reasoning(customer_data):
    """Generate reasoning breakdown for customer."""
    try:
        from utils.data_io import data_vault
        
        if not customer_data:
            return dmc.Text("Select a customer to view reasoning.", c="dimmed")
        
        df = data_vault.get_scored_data()
        if df is None:
            return dmc.Text("No data available.", c="dimmed")
        
        idx = customer_data['idx']
        row = df.iloc[idx]
        
        # Generate reasoning items
        reasons = []
        
        # Check various risk indicators
        if 'anomaly_score' in row and row['anomaly_score'] > 0.8:
            reasons.append({
                'icon': 'mdi:alert-circle',
                'color': 'red',
                'title': 'Critical Risk Level',
                'detail': 'Score exceeds 80% threshold'
            })
        
        # Check for high algorithm scores
        score_cols = [c for c in df.columns if c.startswith('score_')]
        high_scores = [(c, row[c]) for c in score_cols if row[c] > 0.7]
        
        for col, score in high_scores[:3]:
            algo_name = col.replace('score_', '').replace('_', ' ').title()
            reasons.append({
                'icon': 'mdi:brain',
                'color': 'orange',
                'title': f'{algo_name} Detection',
                'detail': f'Score: {score:.2f}'
            })
        
        if not reasons:
            reasons.append({
                'icon': 'mdi:check-circle',
                'color': 'green',
                'title': 'Low Risk Indicators',
                'detail': 'No significant anomaly patterns detected'
            })
        
        # Build UI
        items = []
        for reason in reasons:
            items.append(
                dmc.Paper(
                    dmc.Group(
                        [
                            dmc.ThemeIcon(
                                DashIconify(icon=reason['icon'], width=20),
                                color=reason['color'],
                                size="lg",
                                radius="md",
                            ),
                            dmc.Stack(
                                [
                                    dmc.Text(reason['title'], fw=600, size="sm"),
                                    dmc.Text(reason['detail'], size="xs", c="dimmed"),
                                ],
                                gap=2,
                            ),
                        ],
                        gap="md",
                    ),
                    p="sm",
                    mb="xs",
                    withBorder=True,
                    radius="sm",
                )
            )
        
        return dmc.Stack(items, gap="xs")
        
    except Exception as e:
        return dmc.Alert("An error occurred. Check audit log for details.", color="red")


@callback(
    Output("chart-global-importance", "figure"),
    Input("btn-analyze", "n_clicks"),
)
def update_global_importance(n):
    """Update global feature importance chart."""
    try:
        from utils.data_io import data_vault
        
        df = data_vault.get_scored_data()
        if df is None:
            return go.Figure()
        
        # Calculate mean importance from score columns
        score_cols = [c for c in df.columns if c.startswith('score_')]
        
        if not score_cols:
            return go.Figure()
        
        # Calculate variance of each score column as proxy for importance
        importance = {}
        for col in score_cols:
            importance[col.replace('score_', '')] = df[col].std()
        
        # Sort and plot
        sorted_imp = sorted(importance.items(), key=lambda x: x[1], reverse=True)[:15]
        names = [n.replace('_', ' ').title() for n, _ in sorted_imp]
        values = [v for _, v in sorted_imp]
        
        fig = px.bar(
            x=names,
            y=values,
            template="plotly_dark",
        )
        
        fig.update_traces(marker_color=THEME.SECONDARY)
        
        fig.update_layout(
            margin=dict(l=20, r=20, t=20, b=60),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            xaxis_title="Algorithm",
            yaxis_title="Importance (Std Dev)",
            xaxis_tickangle=-45,
        )
        
        return fig
        
    except Exception:
        return go.Figure()


# =============================================================================
# RBAC ENFORCEMENT
# =============================================================================
try:
    from auth.manager import require_role as _require_role
except ImportError:
    _require_role = lambda *a, **kw: (lambda fn: fn)
_static_layout = layout

@_require_role("viewer")
def layout(**kwargs):
    return _static_layout
