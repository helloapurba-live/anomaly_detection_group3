"""
Configuration Panel — AIM AI Vault (V14)
==========================================
V13 Enhancement #15: Real-time config editor with audit trail.
Comprehensive view + inline editing of key parameters.
All changes logged to ConfigSnapshot table for bank audit compliance.

Version: 12.0.0
"""

import dash
from dash import html, dcc, callback, Input, Output, State, ctx, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import json
from pathlib import Path
from datetime import datetime
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PATHS, THEME, LAYERS, PII, APP, DATA_SOURCES, ALERTS, DRIFT, REPORTS

dash.register_page(__name__, path="/config", name="Configuration", icon="carbon:settings")


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================
def create_config_card(title: str, icon: str, items: list, color: str = "cyan") -> dmc.Card:
    """Create a configuration section card."""
    return dmc.Card(
        [
            dmc.Group(
                [
                    DashIconify(icon=icon, width=24, color=THEME.PRIMARY),
                    dmc.Title(title, order=4, style={"color": THEME.PRIMARY}),
                ],
                gap="sm",
            ),
            dmc.Space(h=10),
            dmc.Stack(
                [
                    dmc.Group(
                        [
                            dmc.Text(
                                item["name"],
                                fw=500,
                                size="sm",
                                c=THEME.INFO,
                                style={"minWidth": "200px"},
                            ),
                            dmc.Badge(
                                str(item["value"]),
                                color=color,
                                variant="light",
                                size="lg",
                                style={"maxWidth": "400px", "overflow": "auto"},
                            ),
                        ],
                        gap="md",
                        style={
                            "padding": "8px 12px",
                            "backgroundColor": THEME.DARK_BG_SECONDARY,
                            "borderRadius": "4px",
                            "borderLeft": f"3px solid {THEME.PRIMARY}",
                        },
                    )
                    for item in items
                ],
                gap="xs",
            ),
        ],
        withBorder=True,
        shadow="sm",
        p="lg",
        radius="md",
        style={"backgroundColor": THEME.DARK_BG_CARD},
    )


def format_value(value):
    """Format configuration value for display."""
    if isinstance(value, dict):
        return json.dumps(value, indent=2)[:200] + ("..." if len(json.dumps(value)) > 200 else "")
    elif isinstance(value, list):
        if len(value) > 5:
            return f"[{', '.join(map(str, value[:5]))}, ... ({len(value)} items)]"
        return str(value)
    elif isinstance(value, Path):
        return str(value)
    else:
        return str(value)


# =============================================================================
# CONFIGURATION DATA
# =============================================================================

# Path Configuration
path_items = [
    {"name": "Base Directory", "value": format_value(PATHS.BASE)},
    {"name": "Data Vault", "value": format_value(PATHS.DATA_VAULT)},
    {"name": "Data Sources", "value": format_value(PATHS.DATA_SOURCES)},
    {"name": "Exports", "value": format_value(PATHS.EXPORTS)},
    {"name": "Models", "value": format_value(PATHS.MODELS)},
    {"name": "Logs", "value": format_value(PATHS.LOGS)},
    {"name": "Cache", "value": format_value(PATHS.CACHE)},
    {"name": "Assets", "value": format_value(PATHS.ASSETS)},
]

# Theme Configuration
theme_items = [
    {"name": "Primary Color", "value": THEME.PRIMARY},
    {"name": "Secondary Color", "value": THEME.SECONDARY},
    {"name": "Success Color", "value": THEME.SUCCESS},
    {"name": "Warning Color", "value": THEME.WARNING},
    {"name": "Danger Color", "value": THEME.DANGER},
    {"name": "Info Color", "value": THEME.INFO},
    {"name": "Dark Background", "value": THEME.DARK_BG},
    {"name": "Dark Background Primary", "value": THEME.DARK_BG_PRIMARY},
    {"name": "Dark Background Secondary", "value": THEME.DARK_BG_SECONDARY},
    {"name": "Dark Background Paper", "value": THEME.DARK_BG_PAPER},
    {"name": "Dark Background Card", "value": THEME.DARK_BG_CARD},
    {"name": "Dark Border", "value": THEME.DARK_BORDER},
    {"name": "Risk Gradient Colors", "value": f"{len(THEME.RISK_GRADIENT)} colors"},
]

# Application Configuration
app_items = [
    {"name": "Application Title", "value": APP.TITLE},
    {"name": "Version", "value": APP.VERSION},
    {"name": "Host", "value": APP.HOST},
    {"name": "Port", "value": APP.PORT},
    {"name": "Debug Mode", "value": APP.DEBUG},
    {"name": "Serve Locally", "value": APP.SERVE_LOCALLY},
    {"name": "Customer-Level Processing", "value": APP.CUSTOMER_LEVEL_PROCESSING},
]

# PII Configuration
pii_items = [
    {"name": "Enabled by Default", "value": PII.ENABLED_BY_DEFAULT},
    {"name": "Mask Pattern", "value": PII.MASK_PATTERN},
    {"name": "Visible Characters", "value": PII.VISIBLE_CHARS},
    {"name": "Masked Columns", "value": format_value(PII.MASKED_COLUMNS)},
    {"name": "Patterns Defined", "value": f"{len(PII.PATTERNS)} patterns"},
]

# Layer Configuration - Detection Methods
detection_items = []
for category, methods in LAYERS.DETECTION_METHODS.items():
    detection_items.append({
        "name": f"{category.title()} Methods",
        "value": f"{len(methods)} methods: {', '.join(methods[:3])}{'...' if len(methods) > 3 else ''}"
    })

detection_items.extend([
    {"name": "Heavy Methods", "value": f"{len(LAYERS.HEAVY_METHODS)} methods"},
    {"name": "Max Rows (Distance Methods)", "value": LAYERS.MAX_ROWS_FOR_DISTANCE_METHODS},
    {"name": "Ensemble Method", "value": LAYERS.ENSEMBLE_METHOD},
    {"name": "Score Normalization", "value": LAYERS.SCORE_NORMALIZATION},
    {"name": "Investigation Capacity", "value": LAYERS.INVESTIGATION_CAPACITY},
])

# Layer Configuration - Risk Tiers
risk_tier_items = []
for tier, thresholds in LAYERS.RISK_TIERS.items():
    risk_tier_items.append({
        "name": tier,
        "value": f"Score≥{thresholds['score_min']}, Votes≥{thresholds['vote_min']}"
    })

# Layer Configuration - Method Weights
weight_items = []
sorted_weights = sorted(LAYERS.METHOD_WEIGHTS.items(), key=lambda x: x[1], reverse=True)
for method, weight in sorted_weights[:10]:  # Show top 10
    weight_items.append({
        "name": method.replace("_", " ").title(),
        "value": f"{weight}×"
    })
if len(sorted_weights) > 10:
    weight_items.append({
        "name": f"... and {len(sorted_weights) - 10} more methods",
        "value": "..."
    })

# Layer Configuration - Feature Engineering
feature_items = [
    {"name": "Feature Categories", "value": format_value(LAYERS.FEATURE_CATEGORIES)},
    {"name": "Matrix Versions", "value": format_value(LAYERS.MATRIX_VERSIONS)},
]

# Layer Configuration - Data Quality
dq_items = []
for metric, threshold in LAYERS.DQ_THRESHOLDS.items():
    dq_items.append({
        "name": metric.title(),
        "value": f"{threshold:.1%}"
    })

# Data Sources Configuration
data_source_items = []
for source, config in DATA_SOURCES.SOURCES.items():
    data_source_items.append({
        "name": source.upper(),
        "value": f"Key: {config.get('key_role', config.get('key_column', 'N/A'))}"
    })


# =============================================================================
# V11: EDITABLE CONFIG PARAMETERS
# Define which parameters can be edited via the UI.
# =============================================================================
EDITABLE_PARAMS = [
    {"section": "LAYERS", "key": "ENSEMBLE_FLAG_THRESHOLD", "label": "Ensemble Flag Threshold",
     "type": "number", "min": 0, "max": 1, "step": 0.05,
     "getter": lambda: LAYERS.ENSEMBLE_FLAG_THRESHOLD},
    {"section": "LAYERS", "key": "INVESTIGATION_CAPACITY", "label": "Investigation Capacity",
     "type": "number", "min": 100, "max": 10000, "step": 100,
     "getter": lambda: LAYERS.INVESTIGATION_CAPACITY},
    {"section": "LAYERS", "key": "CONTAMINATION_RATE", "label": "Contamination Rate",
     "type": "number", "min": 0.01, "max": 0.20, "step": 0.01,
     "getter": lambda: LAYERS.CONTAMINATION_RATE},
    {"section": "PII", "key": "ENABLED_BY_DEFAULT", "label": "PII Masking Enabled",
     "type": "switch", "getter": lambda: PII.ENABLED_BY_DEFAULT},
    {"section": "PII", "key": "VISIBLE_CHARS", "label": "PII Visible Characters",
     "type": "number", "min": 0, "max": 10, "step": 1,
     "getter": lambda: PII.VISIBLE_CHARS},
    {"section": "ALERTS", "key": "CRITICAL_THRESHOLD", "label": "Alert CRITICAL Threshold",
     "type": "number", "min": 0.5, "max": 1.0, "step": 0.01,
     "getter": lambda: ALERTS.CRITICAL_THRESHOLD},
    {"section": "ALERTS", "key": "HIGH_THRESHOLD", "label": "Alert HIGH Threshold",
     "type": "number", "min": 0.3, "max": 0.99, "step": 0.01,
     "getter": lambda: ALERTS.HIGH_THRESHOLD},
    {"section": "DRIFT", "key": "PSI_THRESHOLD", "label": "Drift PSI Threshold",
     "type": "number", "min": 0.05, "max": 1.0, "step": 0.05,
     "getter": lambda: DRIFT.PSI_THRESHOLD},
    {"section": "REPORTS", "key": "MAX_CUSTOMERS_PER_REPORT", "label": "Max Customers per Report",
     "type": "number", "min": 50, "max": 5000, "step": 50,
     "getter": lambda: REPORTS.MAX_CUSTOMERS_PER_REPORT},
]


def _get_config_history():
    """Load recent config changes from DB."""
    try:
        from database.engine import get_session
        from database.models import ConfigSnapshot
        session = get_session()
        snaps = session.query(ConfigSnapshot).order_by(
            ConfigSnapshot.changed_at.desc()
        ).limit(30).all()
        session.close()
        return snaps
    except Exception:
        return []


# =============================================================================
# LAYOUT
# =============================================================================
try:
    from auth.manager import require_role
except ImportError:
    require_role = lambda *a, **kw: (lambda fn: fn)

@require_role("admin")
def layout(**kwargs):
    history = _get_config_history()

    # Build editable parameter cards
    editable_cards = []
    for i, param in enumerate(EDITABLE_PARAMS):
        current_val = param["getter"]()
        if param["type"] == "switch":
            input_el = dmc.Switch(
                id={"type": "config-edit-input", "index": i},
                checked=bool(current_val), label=str(current_val), size="sm",
            )
        else:
            input_el = dmc.NumberInput(
                id={"type": "config-edit-input", "index": i},
                value=current_val, min=param.get("min"), max=param.get("max"),
                step=param.get("step"), size="sm", style={"maxWidth": "180px"},
            )
        editable_cards.append(
            dmc.Group([
                dmc.Text(param["label"], size="sm", fw=500, style={"minWidth": "250px"}),
                dmc.Badge(param["section"], color="cyan", variant="light", size="sm"),
                input_el,
            ], gap="md", style={
                "padding": "8px 12px", "backgroundColor": THEME.DARK_BG_SECONDARY,
                "borderRadius": "4px", "borderLeft": "3px solid " + THEME.PRIMARY,
            })
        )

    # Change history rows
    history_rows = []
    for h in history:
        history_rows.append(
            dmc.Group([
                dmc.Text(str(h.changed_at)[:19] if h.changed_at else "", size="xs", c="dimmed",
                         style={"minWidth": "140px"}),
                dmc.Badge(h.section, color="cyan", variant="light", size="xs"),
                dmc.Text(h.key, size="xs", fw=500, style={"minWidth": "200px"}),
                dmc.Text(str(h.old_value)[:30], size="xs", c="red", style={"minWidth": "100px"}),
                dmc.Text("->", size="xs", c="dimmed"),
                dmc.Text(str(h.new_value)[:30], size="xs", c="green", style={"minWidth": "100px"}),
                dmc.Text(h.reason or "", size="xs", c="dimmed"),
            ], gap="xs", style={
                "padding": "4px 8px", "borderBottom": "1px solid " + THEME.DARK_BORDER,
            })
        )

    return dmc.Container([
        # Header
        dmc.Paper([
            dmc.Group([
                DashIconify(icon="carbon:settings-services", width=40, color=THEME.PRIMARY),
                dmc.Stack([
                    dmc.Title("System Configuration", order=2, style={"color": THEME.PRIMARY}),
                    dmc.Text("View & edit configuration parameters — V13 audit-proof editor",
                             size="sm", opacity=0.6),
                ], gap=0),
            ], gap="md"),
        ], p="xl", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD, "marginBottom": "20px"}),

        # Application Info Banner
        dmc.Alert([
            dmc.Group([
                DashIconify(icon="carbon:information", width=24),
                dmc.Stack([
                    dmc.Text("Version " + APP.VERSION, fw=600),
                    dmc.Text("Running on http://{}:{}".format(APP.HOST, APP.PORT), size="sm"),
                ], gap=2),
            ], gap="md"),
        ], title="Application Status", color="blue", variant="light",
            style={"marginBottom": "20px"}),
        
        # Configuration Sections (read-only view)
        dmc.Tabs([
                dmc.TabsList([
                    dmc.TabsTab("Application", value="app", leftSection=DashIconify(icon="carbon:application")),
                    dmc.TabsTab("Paths", value="paths", leftSection=DashIconify(icon="carbon:folder")),
                    dmc.TabsTab("Theme", value="theme", leftSection=DashIconify(icon="carbon:color-palette")),
                    dmc.TabsTab("Detection", value="detection", leftSection=DashIconify(icon="carbon:chart-radar")),
                    dmc.TabsTab("Risk Tiers", value="risk", leftSection=DashIconify(icon="carbon:warning-alt")),
                    dmc.TabsTab("Weights", value="weights", leftSection=DashIconify(icon="carbon:chart-line")),
                    dmc.TabsTab("PII", value="pii", leftSection=DashIconify(icon="carbon:security")),
                    dmc.TabsTab("Data Sources", value="sources", leftSection=DashIconify(icon="carbon:data-base")),
                    dmc.TabsTab("EDIT (V13)", value="edit", leftSection=DashIconify(icon="mdi:pencil-lock")),
                ], grow=True),
                
                # Application Tab
                dmc.TabsPanel(
                    dmc.Stack(
                        [create_config_card("Application Settings", "carbon:application", app_items, "cyan")],
                        gap="md",
                    ),
                    value="app",
                    pt="md",
                ),
                
                # Paths Tab
                dmc.TabsPanel(
                    dmc.Stack(
                        [create_config_card("File System Paths", "carbon:folder", path_items, "green")],
                        gap="md",
                    ),
                    value="paths",
                    pt="md",
                ),
                
                # Theme Tab
                dmc.TabsPanel(
                    dmc.Stack(
                        [create_config_card("UI Theme Configuration", "carbon:color-palette", theme_items, "grape")],
                        gap="md",
                    ),
                    value="theme",
                    pt="md",
                ),
                
                # Detection Tab
                dmc.TabsPanel(
                    dmc.Stack(
                        [create_config_card("Detection Methods (26 Total)", "carbon:chart-radar", detection_items, "orange")],
                        gap="md",
                    ),
                    value="detection",
                    pt="md",
                ),
                
                # Risk Tiers Tab
                dmc.TabsPanel(
                    dmc.Stack(
                        [create_config_card("Risk Tier Thresholds", "carbon:warning-alt", risk_tier_items, "red")],
                        gap="md",
                    ),
                    value="risk",
                    pt="md",
                ),
                
                # Weights Tab
                dmc.TabsPanel(
                    dmc.Stack(
                        [create_config_card("Method Weights (Top 10)", "carbon:chart-line", weight_items, "yellow")],
                        gap="md",
                    ),
                    value="weights",
                    pt="md",
                ),
                
                # Features Tab
                dmc.TabsPanel(
                    dmc.Stack(
                        [create_config_card("Feature Engineering", "carbon:tree-view", feature_items, "teal")],
                        gap="md",
                    ),
                    value="features",
                    pt="md",
                ),
                
                # Data Quality Tab
                dmc.TabsPanel(
                    dmc.Stack(
                        [create_config_card("Data Quality Thresholds", "carbon:data-quality-definition", dq_items, "indigo")],
                        gap="md",
                    ),
                    value="dq",
                    pt="md",
                ),
                
                # PII Tab
                dmc.TabsPanel(
                    dmc.Stack(
                        [create_config_card("PII Protection", "carbon:security", pii_items, "pink")],
                        gap="md",
                    ),
                    value="pii",
                    pt="md",
                ),
                
                # Data Sources Tab
                dmc.TabsPanel(
                    dmc.Stack(
                        [create_config_card("Data Source Configuration", "carbon:data-base", data_source_items, "violet")],
                        gap="md",
                    ),
                    value="sources",
                    pt="md",
                ),

                # V11: EDIT Tab (real-time config editor)
                dmc.TabsPanel(
                    dmc.Stack([
                        dmc.Alert(
                            "Changes are applied to the running session and logged to the audit trail. "
                            "They do NOT persist to config.py on disk (air-gapped safety).",
                            title="Runtime Config Editor", color="orange", variant="light",
                            icon=DashIconify(icon="mdi:alert-outline", width=20),
                        ),
                        dmc.Paper([
                            dmc.Title("Editable Parameters", order=4, mb="md"),
                            dmc.Stack(editable_cards, gap="sm"),
                            dmc.Group([
                                dmc.TextInput(id="config-change-reason",
                                              placeholder="Reason for change (required for audit)...",
                                              size="sm", style={"flex": "1"}),
                                dmc.Button("Save Changes", id="btn-save-config",
                                           leftSection=DashIconify(icon="mdi:content-save-check", width=18),
                                           color="green"),
                            ], mt="md"),
                            html.Div(id="config-save-result", style={"marginTop": "12px"}),
                        ], p="lg", radius="md", withBorder=True,
                            style={"backgroundColor": THEME.DARK_BG_CARD}),

                        # Change history
                        dmc.Paper([
                            dmc.Title("Change History (Audit Trail)", order=4, mb="md"),
                            dmc.Stack(history_rows if history_rows else [
                                dmc.Text("No configuration changes recorded yet.", c="dimmed", size="sm"),
                            ], gap=2),
                        ], p="lg", radius="md", withBorder=True,
                            style={"backgroundColor": THEME.DARK_BG_CARD}),
                    ], gap="md"),
                    value="edit",
                    pt="md",
                ),
            ],
            value="app",
            color="cyan",
            orientation="horizontal",
            style={"marginBottom": "30px"},
        ),
        
        # System Statistics Footer
        dmc.Paper(
            [
                dmc.Title("System Statistics", order=5, style={"color": THEME.PRIMARY, "marginBottom": "15px"}),
                dmc.SimpleGrid(
                    [
                        dmc.Card(
                            [
                                DashIconify(icon="carbon:chart-radar", width=30, color=THEME.SUCCESS),
                                dmc.Text("Detection Methods", size="sm", opacity=0.6, style={"marginTop": "8px"}),
                                dmc.Title(
                                    str(sum(len(methods) for methods in LAYERS.DETECTION_METHODS.values())),
                                    order=3,
                                    style={"color": THEME.SUCCESS},
                                ),
                            ],
                            withBorder=True,
                            p="md",
                            style={"backgroundColor": THEME.DARK_BG_SECONDARY, "textAlign": "center"},
                        ),
                        dmc.Card(
                            [
                                DashIconify(icon="carbon:warning-alt", width=30, color=THEME.WARNING),
                                dmc.Text("Risk Tiers", size="sm", opacity=0.6, style={"marginTop": "8px"}),
                                dmc.Title(
                                    str(len(LAYERS.RISK_TIERS)),
                                    order=3,
                                    style={"color": THEME.WARNING},
                                ),
                            ],
                            withBorder=True,
                            p="md",
                            style={"backgroundColor": THEME.DARK_BG_SECONDARY, "textAlign": "center"},
                        ),
                        dmc.Card(
                            [
                                DashIconify(icon="carbon:chart-line", width=30, color=THEME.INFO),
                                dmc.Text("Weighted Methods", size="sm", opacity=0.6, style={"marginTop": "8px"}),
                                dmc.Title(
                                    str(len(LAYERS.METHOD_WEIGHTS)),
                                    order=3,
                                    style={"color": THEME.INFO},
                                ),
                            ],
                            withBorder=True,
                            p="md",
                            style={"backgroundColor": THEME.DARK_BG_SECONDARY, "textAlign": "center"},
                        ),
                        dmc.Card(
                            [
                                DashIconify(icon="carbon:tree-view", width=30, color=THEME.SECONDARY),
                                dmc.Text("Feature Categories", size="sm", opacity=0.6, style={"marginTop": "8px"}),
                                dmc.Title(
                                    str(len(LAYERS.FEATURE_CATEGORIES)),
                                    order=3,
                                    style={"color": THEME.SECONDARY},
                                ),
                            ],
                            withBorder=True,
                            p="md",
                            style={"backgroundColor": THEME.DARK_BG_SECONDARY, "textAlign": "center"},
                        ),
                        dmc.Card(
                            [
                                DashIconify(icon="carbon:data-base", width=30, color=THEME.PRIMARY),
                                dmc.Text("Data Sources", size="sm", opacity=0.6, style={"marginTop": "8px"}),
                                dmc.Title(
                                    str(len(DATA_SOURCES.SOURCES)),
                                    order=3,
                                    style={"color": THEME.PRIMARY},
                                ),
                            ],
                            withBorder=True,
                            p="md",
                            style={"backgroundColor": THEME.DARK_BG_SECONDARY, "textAlign": "center"},
                        ),
                        dmc.Card(
                            [
                                DashIconify(icon="carbon:script", width=30, color=THEME.DANGER),
                                dmc.Text("Matrix Versions", size="sm", opacity=0.6, style={"marginTop": "8px"}),
                                dmc.Title(
                                    str(len(LAYERS.MATRIX_VERSIONS)),
                                    order=3,
                                    style={"color": THEME.DANGER},
                                ),
                            ],
                            withBorder=True,
                            p="md",
                            style={"backgroundColor": THEME.DARK_BG_SECONDARY, "textAlign": "center"},
                        ),
                    ],
                    cols={"base": 2, "sm": 3, "md": 6},
                    spacing="md",
                ),
            ],
            p="xl",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD, "marginTop": "30px"},
        ),
        
        # Version Info
        dmc.Center(
            dmc.Text(
                "Version {} | FCDAI 7-Layer AML Pipeline | Enhanced Detection System".format(APP.VERSION),
                size="xs",
                opacity=0.6,
                style={"marginTop": "32px", "marginBottom": "32px"},
            ),
        ),
    ],
    fluid=True,
    style={"padding": "20px"},
    )


# =============================================================================
# V11: SAVE CONFIG CALLBACK (audit-proof)
# =============================================================================
@callback(
    Output("config-save-result", "children"),
    Input("btn-save-config", "n_clicks"),
    [State({"type": "config-edit-input", "index": i}, "value" if EDITABLE_PARAMS[i]["type"] != "switch" else "checked")
     for i in range(len(EDITABLE_PARAMS))],
    State("config-change-reason", "value"),
    prevent_initial_call=True,
)
def save_config_changes(n_clicks, *args):
    """Apply runtime config changes and log to ConfigSnapshot DB table."""
    if not n_clicks:
        return no_update

    values = args[:-1]
    reason = args[-1]

    if not reason or not reason.strip():
        return dmc.Alert("A reason is required for audit compliance.", color="red",
                         icon=DashIconify(icon="mdi:alert", width=20))

    changes = []
    config_objects = {
        "LAYERS": LAYERS, "PII": PII, "ALERTS": ALERTS,
        "DRIFT": DRIFT, "REPORTS": REPORTS,
    }

    for i, param in enumerate(EDITABLE_PARAMS):
        new_val = values[i]
        old_val = param["getter"]()
        if param["type"] == "switch":
            new_val = bool(new_val)
        else:
            if new_val is None:
                continue

        if str(new_val) != str(old_val):
            # Apply runtime change
            obj = config_objects.get(param["section"])
            if obj and hasattr(obj, param["key"]):
                setattr(obj, param["key"], type(old_val)(new_val))
                changes.append({
                    "section": param["section"],
                    "key": param["key"],
                    "old_value": str(old_val),
                    "new_value": str(new_val),
                })

    if not changes:
        return dmc.Alert("No changes detected.", color="blue")

    # Log to DB
    try:
        from database.engine import get_session
        from database.models import ConfigSnapshot
        session = get_session()
        for ch in changes:
            snap = ConfigSnapshot(
                section=ch["section"], key=ch["key"],
                old_value=ch["old_value"], new_value=ch["new_value"],
                reason=reason.strip(),
            )
            session.add(snap)
        session.commit()
        session.close()
    except Exception as e:
        return dmc.Alert("Database error. Check audit log.", color="red")

    return dmc.Alert(
        "{} parameter(s) updated and logged to audit trail.".format(len(changes)),
        title="Configuration Saved", color="green",
        icon=DashIconify(icon="mdi:check-circle", width=20),
    )