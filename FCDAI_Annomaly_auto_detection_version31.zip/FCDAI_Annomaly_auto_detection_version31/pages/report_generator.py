"""
Report Generator — AIM AI Vault (V11)
=======================================
#11 Offline PDF/HTML investigation report generation.
#12 Narrative compliance template (no SAR — uses Narrative terminology).

Air-gapped: uses only stdlib + Jinja2-like string templates.
Zero PII leakage: all entity IDs are hashed in reports when PII mode is on.
Reports stored locally, SHA-256 hashed, logged in DB.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import dash_ag_grid as dag
import pandas as pd
import json
import hashlib
import sys
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS, APP, REPORTS, PII

dash.register_page(__name__, path="/reports", name="Report Generator", order=14)


# =============================================================================
# HELPERS
# =============================================================================
REPORT_DIR = Path(REPORTS.OUTPUT_DIR)
REPORT_DIR.mkdir(parents=True, exist_ok=True)


def _mask_entity(entity_id):
    """Hash entity ID for report output (zero PII leakage)."""
    if PII.ENABLED_BY_DEFAULT and entity_id:
        h = hashlib.sha256(entity_id.encode()).hexdigest()[:12]
        return "ENT-{}".format(h.upper())
    return entity_id or "N/A"


def _get_anomalies_for_report(run_id=None, tier_filter=None):
    """Fetch anomalies from DB for report generation."""
    try:
        from database.engine import get_session
        from database.models import Anomaly, PipelineRun
        session = get_session()
        query = session.query(Anomaly)
        if run_id:
            query = query.filter(Anomaly.run_id == run_id)
        if tier_filter:
            query = query.filter(Anomaly.risk_tier.in_(tier_filter))
        anomalies = query.order_by(Anomaly.anomaly_score.desc()).limit(REPORTS.MAX_CUSTOMERS_PER_REPORT).all()
        rows = []
        for a in anomalies:
            rows.append({
                "entity_id": _mask_entity(a.entity_id),
                "anomaly_score": round(a.anomaly_score, 4) if a.anomaly_score else 0,
                "risk_tier": a.risk_tier or "NORMAL",
                "vote_count": a.vote_count or 0,
                "ensemble_score": round(a.ensemble_score, 4) if a.ensemble_score else 0,
                "method_flags": a.method_flags or "[]",
                "run_id": a.run_id,
                "confirmed": "Yes" if a.is_confirmed else "No",
            })
        session.close()
        return pd.DataFrame(rows) if rows else pd.DataFrame()
    except Exception:
        return pd.DataFrame()


def _get_run_ids():
    """Get available run IDs for report generation."""
    try:
        from database.engine import get_session
        from database.models import PipelineRun
        session = get_session()
        runs = session.query(PipelineRun).order_by(PipelineRun.id.desc()).limit(50).all()
        session.close()
        return [{"value": r.run_id, "label": "{} ({})".format(r.run_id, r.status)} for r in runs]
    except Exception:
        return []


def _generate_html_report(df, report_type, run_id):
    """Generate an HTML investigation/narrative report locally."""
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    report_id = "RPT-{}-{}".format(
        datetime.now().strftime("%Y%m%d%H%M%S"),
        hashlib.sha256(now.encode()).hexdigest()[:8].upper()
    )

    # Tier summary
    tier_counts = df["risk_tier"].value_counts().to_dict() if not df.empty else {}
    total = len(df)

    # Build HTML (no Jinja2 dependency — pure string formatting)
    html_parts = []
    html_parts.append("<!DOCTYPE html><html><head>")
    html_parts.append("<meta charset='utf-8'>")
    html_parts.append("<title>{} Report - {}</title>".format(report_type.title(), report_id))
    html_parts.append("<style>")
    html_parts.append("body{font-family:'Segoe UI',sans-serif;margin:40px;color:#1a1a2e;}")
    html_parts.append("h1{color:#0c8599;border-bottom:3px solid #0c8599;padding-bottom:10px;}")
    html_parts.append("h2{color:#364fc7;margin-top:30px;}")
    html_parts.append(".header{background:#f1f3f5;padding:20px;border-radius:8px;margin-bottom:30px;}")
    html_parts.append(".classification{color:#FF5252;font-weight:bold;text-align:center;font-size:14px;"
                       "padding:8px;background:#fff5f5;border:1px solid #FF5252;margin-bottom:20px;}")
    html_parts.append("table{width:100%;border-collapse:collapse;margin:15px 0;}")
    html_parts.append("th{background:#364fc7;color:white;padding:10px;text-align:left;}")
    html_parts.append("td{padding:8px 10px;border-bottom:1px solid #dee2e6;}")
    html_parts.append("tr:nth-child(even){background:#f8f9fa;}")
    html_parts.append(".critical{background:#fff5f5;color:#c92a2a;font-weight:bold;}")
    html_parts.append(".high{background:#fff9db;color:#e67700;font-weight:bold;}")
    html_parts.append(".footer{margin-top:40px;padding-top:20px;border-top:2px solid #dee2e6;"
                       "color:#868e96;font-size:12px;}")
    html_parts.append("</style></head><body>")

    # Classification banner
    html_parts.append("<div class='classification'>{}</div>".format(REPORTS.REPORT_CLASSIFICATION))

    # Header
    html_parts.append("<h1>AIM AI Vault - {} Report</h1>".format(report_type.title()))
    html_parts.append("<div class='header'>")
    html_parts.append("<strong>Report ID:</strong> {}<br>".format(report_id))
    html_parts.append("<strong>Generated:</strong> {}<br>".format(now))
    html_parts.append("<strong>Pipeline Run:</strong> {}<br>".format(run_id or "All Available"))
    html_parts.append("<strong>Total Entities:</strong> {:,}<br>".format(total))
    html_parts.append("<strong>Report Type:</strong> {}<br>".format(report_type))
    html_parts.append("<strong>Institution:</strong> {}<br>".format(REPORTS.BANK_NAME))
    html_parts.append("<strong>System Version:</strong> {}<br>".format(APP.VERSION))
    html_parts.append("</div>")

    # Tier Summary
    html_parts.append("<h2>Risk Tier Summary</h2>")
    html_parts.append("<table><tr><th>Risk Tier</th><th>Count</th><th>Percentage</th></tr>")
    for tier in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "NORMAL"]:
        count = tier_counts.get(tier, 0)
        pct = "{:.1f}%".format(count / total * 100) if total > 0 else "0%"
        cls = "critical" if tier == "CRITICAL" else ("high" if tier == "HIGH" else "")
        html_parts.append("<tr class='{}'>".format(cls))
        html_parts.append("<td>{}</td><td>{}</td><td>{}</td></tr>".format(tier, count, pct))
    html_parts.append("</table>")

    # Entity details
    if not df.empty:
        html_parts.append("<h2>Entity Details (Top {})</h2>".format(min(100, total)))
        html_parts.append("<table><tr><th>Entity</th><th>Score</th><th>Tier</th>"
                          "<th>Votes</th><th>Confirmed</th></tr>")
        for _, row in df.head(100).iterrows():
            cls = "critical" if row["risk_tier"] == "CRITICAL" else (
                "high" if row["risk_tier"] == "HIGH" else "")
            html_parts.append("<tr class='{}'>".format(cls))
            html_parts.append("<td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>".format(
                row["entity_id"], row["anomaly_score"], row["risk_tier"],
                row["vote_count"], row["confirmed"]))
        html_parts.append("</table>")

    # Narrative section for compliance
    if report_type == "narrative":
        html_parts.append("<h2>Narrative Summary</h2>")
        html_parts.append("<p>This narrative report documents anomalous activity patterns detected by "
                          "AIM AI Vault's 7-layer detection pipeline. The system employs 26 detection "
                          "methods across 8 categories (statistical, distance, density, clustering, "
                          "trees, time-series, graph, deep learning) to identify potential risks.</p>")
        crit_count = tier_counts.get("CRITICAL", 0)
        high_count = tier_counts.get("HIGH", 0)
        if crit_count > 0 or high_count > 0:
            html_parts.append("<p><strong>Key Findings:</strong> {} CRITICAL and {} HIGH risk entities "
                              "were identified requiring immediate investigation. These entities exhibited "
                              "anomalous patterns across multiple detection methods with high consensus "
                              "voting scores.</p>".format(crit_count, high_count))
        html_parts.append("<p><strong>Methodology:</strong> Tiered consensus ensemble scoring normalizes "
                          "all 26 method outputs to [0,1] range, applies method-specific weights, and "
                          "classifies entities into 5 risk tiers based on composite score and vote count "
                          "thresholds.</p>")

    # Footer
    html_parts.append("<div class='footer'>")
    html_parts.append("<p>{}</p>".format(REPORTS.REPORT_CLASSIFICATION))
    html_parts.append("<p>Generated by AIM AI Vault v{} | Air-Gapped Mode | "
                      "No data was transmitted externally</p>".format(APP.VERSION))
    html_parts.append("<p>SHA-256 verification hash will be stored in the system database.</p>")
    html_parts.append("</div></body></html>")

    html_content = "\n".join(html_parts)

    # Save to disk
    fname = "{}_{}.html".format(report_id, report_type)
    fpath = REPORT_DIR / fname
    fpath.write_text(html_content, encoding="utf-8")

    # Hash the file
    file_hash = hashlib.sha256(html_content.encode()).hexdigest()

    # Log to DB
    try:
        from database.engine import get_session
        from database.models import InvestigationReport
        session = get_session()
        rpt = InvestigationReport(
            report_id=report_id,
            report_type=report_type,
            run_id=run_id,
            n_entities=total,
            file_path=str(fpath),
            file_format="html",
            file_hash=file_hash,
            classification=REPORTS.REPORT_CLASSIFICATION,
        )
        session.add(rpt)
        session.commit()
        session.close()
    except Exception:
        pass

    return html_content, report_id, str(fpath), file_hash


def _get_past_reports():
    """Get list of previously generated reports."""
    try:
        from database.engine import get_session
        from database.models import InvestigationReport
        session = get_session()
        reports = session.query(InvestigationReport).order_by(
            InvestigationReport.id.desc()).limit(50).all()
        rows = []
        for r in reports:
            rows.append({
                "report_id": r.report_id,
                "type": r.report_type,
                "run_id": r.run_id or "All",
                "entities": r.n_entities,
                "format": r.file_format,
                "generated_at": r.generated_at.strftime("%Y-%m-%d %H:%M") if r.generated_at else "",
                "file_hash": (r.file_hash or "")[:16] + "...",
            })
        session.close()
        return pd.DataFrame(rows) if rows else pd.DataFrame()
    except Exception:
        return pd.DataFrame()


# =============================================================================
# LAYOUT
# =============================================================================
try:
    from auth.manager import require_role
except ImportError:
    require_role = lambda *a, **kw: (lambda fn: fn)

@require_role("investigator")
def layout(**kwargs):
    run_ids = _get_run_ids()
    past = _get_past_reports()

    return dmc.Container([
        dmc.Group([
            dmc.Group([
                DashIconify(icon="mdi:file-document-edit", width=28, color="#22b8cf"),
                dmc.Title("Report Generator", order=2),
            ], gap="xs"),
            dmc.Badge("Offline | Air-Gapped | Zero PII", color="cyan", variant="light"),
        ], justify="space-between", mb="lg"),

        dmc.Text("Generate investigation and narrative compliance reports. "
                 "All reports are generated locally with SHA-256 integrity hashes. "
                 "Entity IDs are hashed when PII mode is enabled. No data leaves this machine.",
                 size="sm", c="dimmed", mb="lg"),

        # Report Generation Form
        dmc.Paper([
            dmc.Text("Generate New Report", fw=700, size="lg", mb="md"),
            dmc.SimpleGrid(cols={"base": 1, "md": 3}, spacing="md", mb="md", children=[
                dmc.Select(id="rpt-type", label="Report Type",
                           data=[
                               {"value": "narrative", "label": "Narrative Compliance Report"},
                               {"value": "investigation", "label": "Investigation Report"},
                               {"value": "regulatory", "label": "Regulatory Summary"},
                           ], value="narrative"),
                dmc.Select(id="rpt-run-id", label="Pipeline Run",
                           data=[{"value": "", "label": "All Runs"}] + run_ids,
                           value="", clearable=True),
                dmc.MultiSelect(id="rpt-tiers", label="Risk Tiers to Include",
                                data=[
                                    {"value": "CRITICAL", "label": "CRITICAL"},
                                    {"value": "HIGH", "label": "HIGH"},
                                    {"value": "MEDIUM", "label": "MEDIUM"},
                                    {"value": "LOW", "label": "LOW"},
                                ],
                                value=["CRITICAL", "HIGH"]),
            ]),
            dmc.Group([
                dmc.Button("Generate Report", id="gen-report-btn",
                           leftSection=DashIconify(icon="mdi:file-document-plus"),
                           color="cyan", size="lg"),
                dmc.Button("Download Last Report", id="dl-report-btn",
                           leftSection=DashIconify(icon="mdi:download"),
                           color="teal", variant="outline", size="lg"),
            ], gap="md"),
        ], p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}, mb="lg"),

        html.Div(id="report-feedback"),
        dcc.Download(id="download-report"),

        # Past Reports
        dmc.Paper([
            dmc.Group([
                dmc.Text("Report Archive", fw=700, size="lg"),
                dmc.Badge("{} reports".format(len(past)), color="indigo", variant="light"),
            ], gap="xs", mb="md"),
            dag.AgGrid(
                id="reports-grid",
                rowData=past.to_dict("records") if not past.empty else [],
                columnDefs=[
                    {"field": "report_id", "headerName": "Report ID", "minWidth": 180},
                    {"field": "type", "headerName": "Type", "minWidth": 120},
                    {"field": "run_id", "headerName": "Run", "minWidth": 100},
                    {"field": "entities", "headerName": "Entities", "minWidth": 90},
                    {"field": "generated_at", "headerName": "Generated", "minWidth": 140},
                    {"field": "file_hash", "headerName": "SHA-256", "minWidth": 160},
                ],
                defaultColDef={"flex": 1, "sortable": True, "resizable": True},
                dashGridOptions={"pagination": True, "paginationPageSize": 10},
                style={"height": "300px", "width": "100%"},
                className="ag-theme-alpine-dark",
            ) if not past.empty else dmc.Text("No reports generated yet.", c="dimmed"),
        ], p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}),
    ], fluid=True)


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("report-feedback", "children"),
    Input("gen-report-btn", "n_clicks"),
    State("rpt-type", "value"),
    State("rpt-run-id", "value"),
    State("rpt-tiers", "value"),
    prevent_initial_call=True,
)
def generate_report(_, rtype, run_id, tiers):
    """Generate report and save to disk."""
    df = _get_anomalies_for_report(run_id=run_id if run_id else None, tier_filter=tiers)
    if df.empty:
        return dmc.Alert("No anomaly data found for the selected filters. "
                         "Run the pipeline first.", color="yellow")
    _content, report_id, fpath, fhash = _generate_html_report(df, rtype, run_id)
    return dmc.Alert(
        [
            dmc.Text("Report generated successfully!", fw=600),
            dmc.Text("Report ID: {}".format(report_id), size="sm"),
            dmc.Text("Location: {}".format(fpath), size="xs", c="dimmed"),
            dmc.Text("SHA-256: {}".format(fhash[:32] + "..."), size="xs", c="dimmed"),
        ],
        color="green", icon=DashIconify(icon="mdi:check-circle"),
    )


@callback(
    Output("download-report", "data"),
    Input("dl-report-btn", "n_clicks"),
    prevent_initial_call=True,
)
def download_last_report(_):
    """Download the most recently generated report."""
    try:
        files = sorted(REPORT_DIR.glob("RPT-*.html"), key=lambda p: p.stat().st_mtime, reverse=True)
        if files:
            content = files[0].read_text(encoding="utf-8")
            return {"content": content, "filename": files[0].name, "type": "text/html"}
    except Exception:
        pass
    return no_update
