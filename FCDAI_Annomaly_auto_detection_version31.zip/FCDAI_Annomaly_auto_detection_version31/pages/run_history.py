"""
Pipeline Run History + Scheduler — AIM AI Vault (V11)
=====================================================
#6  View / compare past pipeline runs with timing, scores, configs
#7  Create & manage scheduled recurring pipeline runs (offline cron)
#8  Export pipeline results as CSV (air-gapped, no cloud)

Zero-network, fully offline, bank audit-proof.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, ctx, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import dash_ag_grid as dag
import pandas as pd
import json
import sys
import hashlib
from pathlib import Path
from datetime import datetime, timedelta

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS, APP

dash.register_page(__name__, path="/run-history", name="Run History", order=3)


# =============================================================================
# HELPERS
# =============================================================================
def _get_runs():
    """Fetch all pipeline runs from SQLite."""
    try:
        from database.engine import get_session
        from database.models import PipelineRun
        session = get_session()
        runs = session.query(PipelineRun).order_by(PipelineRun.id.desc()).limit(200).all()
        rows = []
        for r in runs:
            rows.append({
                "run_id": r.run_id,
                "status": r.status or "unknown",
                "progress": r.progress or 0,
                "started_at": r.started_at.strftime("%Y-%m-%d %H:%M") if r.started_at else "",
                "completed_at": r.completed_at.strftime("%Y-%m-%d %H:%M") if r.completed_at else "",
                "duration_sec": round(r.duration_sec, 1) if r.duration_sec else "",
                "n_anomalies": r.n_anomalies or 0,
                "current_step": r.current_step or "",
            })
        session.close()
        return pd.DataFrame(rows) if rows else pd.DataFrame()
    except Exception:
        return pd.DataFrame()


def _get_schedules():
    """Fetch all scheduled runs from SQLite."""
    try:
        from database.engine import get_session
        from database.models import ScheduledRun
        session = get_session()
        schedules = session.query(ScheduledRun).order_by(ScheduledRun.id.desc()).all()
        rows = []
        for s in schedules:
            rows.append({
                "id": s.id,
                "name": s.name,
                "cron": s.cron_expression,
                "data_source": s.data_source,
                "is_active": "Active" if s.is_active else "Paused",
                "last_run": s.last_run_at.strftime("%Y-%m-%d %H:%M") if s.last_run_at else "Never",
                "next_run": s.next_run_at.strftime("%Y-%m-%d %H:%M") if s.next_run_at else "Pending",
                "total_runs": s.total_runs,
            })
        session.close()
        return pd.DataFrame(rows) if rows else pd.DataFrame()
    except Exception:
        return pd.DataFrame()


def _parse_simple_cron(cron_str):
    """Parse simple cron-like expression to next datetime (offline, no croniter)."""
    parts = cron_str.strip().split()
    now = datetime.now()
    if len(parts) >= 2:
        try:
            hour = int(parts[1]) if parts[1] != "*" else now.hour
            minute = int(parts[0]) if parts[0] != "*" else 0
            next_run = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if next_run <= now:
                next_run += timedelta(days=1)
            return next_run
        except (ValueError, IndexError):
            pass
    return now + timedelta(hours=24)


# =============================================================================
# LAYOUT
# =============================================================================
try:
    from auth.manager import require_role
except ImportError:
    require_role = lambda *a, **kw: (lambda fn: fn)

@require_role("investigator")
def layout(**kwargs):
    df_runs = _get_runs()
    df_sched = _get_schedules()

    # Run history AG Grid
    if not df_runs.empty:
        run_cols = [
            {"field": "run_id", "headerName": "Run ID", "pinned": "left", "minWidth": 120},
            {"field": "status", "headerName": "Status", "minWidth": 100,
             "cellStyle": {"conditions": [
                 {"condition": "params.value === 'completed'", "style": {"color": "#00C853"}},
                 {"condition": "params.value === 'failed'", "style": {"color": "#FF5252"}},
                 {"condition": "params.value === 'running'", "style": {"color": "#FFB300"}},
             ]}},
            {"field": "started_at", "headerName": "Started", "minWidth": 140},
            {"field": "completed_at", "headerName": "Completed", "minWidth": 140},
            {"field": "duration_sec", "headerName": "Duration (s)", "minWidth": 110},
            {"field": "n_anomalies", "headerName": "Anomalies", "minWidth": 100},
            {"field": "current_step", "headerName": "Last Step", "minWidth": 180},
            {"field": "progress", "headerName": "Progress %", "minWidth": 100},
        ]
        run_grid = dag.AgGrid(
            id="run-history-grid",
            rowData=df_runs.to_dict("records"),
            columnDefs=run_cols,
            defaultColDef={"flex": 1, "sortable": True, "filter": True, "resizable": True},
            dashGridOptions={"pagination": True, "paginationPageSize": 15,
                             "rowSelection": "single", "animateRows": True},
            style={"height": "400px", "width": "100%"},
            className="ag-theme-alpine-dark",
        )
    else:
        run_grid = dmc.Alert("No pipeline runs recorded yet. Run the Execution Engine first.",
                             color="blue", icon=DashIconify(icon="mdi:information"))

    return dmc.Container([
        dmc.Group([
            dmc.Group([
                DashIconify(icon="mdi:history", width=28, color="#22b8cf"),
                dmc.Title("Run History & Scheduler", order=2),
            ], gap="xs"),
            dmc.Group([
                dmc.Button("Export Last Run CSV", id="export-run-btn",
                           leftSection=DashIconify(icon="mdi:download"),
                           color="cyan", variant="outline", size="sm"),
                dmc.Button("Export All Runs CSV", id="export-all-runs-btn",
                           leftSection=DashIconify(icon="mdi:file-export"),
                           color="teal", variant="outline", size="sm"),
            ], gap="xs"),
        ], justify="space-between", mb="lg"),

        # Run History Table
        dmc.Paper([
            dmc.Group([
                dmc.Text("Pipeline Run History", fw=700, size="lg"),
                dmc.Badge("{} runs".format(len(df_runs)), color="cyan", variant="light"),
            ], gap="xs", mb="md"),
            run_grid,
        ], p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}, mb="lg"),

        # Scheduler Section
        dmc.Paper([
            dmc.Group([
                DashIconify(icon="mdi:calendar-clock", width=24, color="#22b8cf"),
                dmc.Text("Scheduled Pipeline Runs", fw=700, size="lg"),
                dmc.Badge("Offline Cron", color="indigo", variant="light"),
            ], gap="xs", mb="md"),
            dmc.Text("Schedule recurring pipeline runs (local-only, no cloud). "
                     "Uses simple cron expressions: minute hour * * * (e.g., '0 2 * * *' = daily at 2 AM).",
                     size="sm", c="dimmed", mb="md"),
            dmc.SimpleGrid(cols={"base": 1, "md": 4}, spacing="md", mb="md", children=[
                dmc.TextInput(id="sched-name", label="Schedule Name",
                              placeholder="Daily 2AM Run"),
                dmc.TextInput(id="sched-cron", label="Cron Expression",
                              placeholder="0 2 * * *"),
                dmc.Select(id="sched-source", label="Data Source",
                           data=[{"value": "actual", "label": "Actual Data"},
                                 {"value": "sample", "label": "Sample Data"}],
                           value="actual"),
                dmc.Button("Create Schedule", id="create-schedule-btn",
                           leftSection=DashIconify(icon="mdi:plus"),
                           color="cyan", mt="xl", fullWidth=True),
            ]),
            html.Div(id="schedule-feedback"),
            dmc.Space(h="md"),
            html.Div(id="schedule-grid-container", children=[
                dag.AgGrid(
                    id="schedule-grid",
                    rowData=df_sched.to_dict("records") if not df_sched.empty else [],
                    columnDefs=[
                        {"field": "name", "headerName": "Name", "minWidth": 140},
                        {"field": "cron", "headerName": "Cron", "minWidth": 120},
                        {"field": "data_source", "headerName": "Source", "minWidth": 100},
                        {"field": "is_active", "headerName": "Status", "minWidth": 100},
                        {"field": "last_run", "headerName": "Last Run", "minWidth": 140},
                        {"field": "next_run", "headerName": "Next Run", "minWidth": 140},
                        {"field": "total_runs", "headerName": "Total", "minWidth": 80},
                    ],
                    defaultColDef={"flex": 1, "sortable": True, "resizable": True},
                    dashGridOptions={"pagination": True, "paginationPageSize": 10},
                    style={"height": "250px", "width": "100%"},
                    className="ag-theme-alpine-dark",
                ) if not df_sched.empty else dmc.Text("No schedules configured.", c="dimmed"),
            ]),
        ], p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}),

        # Hidden download components
        dcc.Download(id="download-run-csv"),
        dcc.Download(id="download-all-csv"),
    ], fluid=True)


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("download-run-csv", "data"),
    Input("export-run-btn", "n_clicks"),
    prevent_initial_call=True,
)
def export_last_run(_):
    """Export the most recent pipeline run results as CSV."""
    df = _get_runs()
    if df.empty:
        return no_update
    # Get the last completed run's anomalies
    try:
        from database.engine import get_session
        from database.models import Anomaly
        last_run_id = df.iloc[0]["run_id"]
        session = get_session()
        anomalies = session.query(Anomaly).filter(Anomaly.run_id == last_run_id).all()
        rows = []
        for a in anomalies:
            rows.append({
                "entity_id": a.entity_id,
                "anomaly_score": round(a.anomaly_score, 4) if a.anomaly_score else 0,
                "risk_tier": a.risk_tier,
                "vote_count": a.vote_count,
                "ensemble_score": round(a.ensemble_score, 4) if a.ensemble_score else 0,
            })
        session.close()
        if rows:
            export_df = pd.DataFrame(rows)
            fname = "run_{}_results_{}.csv".format(last_run_id, datetime.now().strftime("%Y%m%d_%H%M%S"))
            return dcc.send_data_frame(export_df.to_csv, fname, index=False)
    except Exception:
        pass
    return no_update


@callback(
    Output("download-all-csv", "data"),
    Input("export-all-runs-btn", "n_clicks"),
    prevent_initial_call=True,
)
def export_all_runs(_):
    """Export all pipeline run metadata as CSV."""
    df = _get_runs()
    if df.empty:
        return no_update
    fname = "all_runs_{}.csv".format(datetime.now().strftime("%Y%m%d_%H%M%S"))
    return dcc.send_data_frame(df.to_csv, fname, index=False)


@callback(
    Output("schedule-feedback", "children"),
    Input("create-schedule-btn", "n_clicks"),
    State("sched-name", "value"),
    State("sched-cron", "value"),
    State("sched-source", "value"),
    prevent_initial_call=True,
)
def create_schedule(_, name, cron, source):
    """Create a new scheduled pipeline run."""
    if not name or not cron:
        return dmc.Alert("Please provide a name and cron expression.", color="yellow")
    try:
        next_run = _parse_simple_cron(cron)
        from database.engine import get_session
        from database.models import ScheduledRun
        session = get_session()
        sched = ScheduledRun(
            name=name,
            cron_expression=cron,
            data_source=source or "actual",
            next_run_at=next_run,
            is_active=True,
            categories_json=json.dumps(["statistical", "distance", "density", "clustering",
                                        "trees", "timeseries", "graph", "deep_learning"]),
        )
        session.add(sched)
        session.commit()
        session.close()
        return dmc.Alert(
            "Schedule '{}' created. Next run at: {}".format(name, next_run.strftime("%Y-%m-%d %H:%M")),
            color="green", icon=DashIconify(icon="mdi:check-circle"),
        )
    except Exception as e:
        return dmc.Alert("Schedule creation failed. Check audit log.", color="red")
