"""
Investigation Queue Page — AIM AI Vault (V14)
==============================
Customer-level risk triage and investigation workflow.
Reads customer scores from scored data in the vault.

V6: All processing at customer level, not transaction/alert level.
"""

import dash
from dash import html, dcc, callback, Input, Output, State
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import dash_ag_grid as dag
import pandas as pd
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS

dash.register_page(__name__, path="/queue", name="Investigation Queue", order=4)

TIER_COLORS = {"CRITICAL": "red", "HIGH": "orange", "MEDIUM": "yellow", "LOW": "green", "NORMAL": "gray"}


def customer_card(row, idx):
    """Create customer risk card with V6 tier names. V13: PII-masked display."""
    tier = row.get("risk_tier", "LOW")
    score = row.get("anomaly_score", 0)
    votes = row.get("vote_count", 0) if "vote_count" in row else None
    
    # V13 FIX: Never display raw PII — use masked entity label
    raw_id = str(row.get("customer_id", row.get("party_id", "")))
    if raw_id and len(raw_id) > 4:
        cust_label = "XXXX" + raw_id[-4:]
    else:
        cust_label = f"ENT-{idx:06d}"

    # V6: Customer-level narrative with votes
    if tier == "CRITICAL":
        narrative = f"CRITICAL: {cust_label} shows extreme deviation across {votes if votes else 'multiple'} detection methods."
    elif tier == "HIGH":
        narrative = f"HIGH RISK: {cust_label} flagged by ensemble with elevated anomaly indicators ({votes if votes else 'several'} votes)."
    elif tier == "MEDIUM":
        narrative = f"MEDIUM: {cust_label} has moderate anomaly signals from statistical and density methods."
    elif tier == "LOW":
        narrative = f"LOW: {cust_label} shows minor deviations, likely benign pattern."
    else:
        narrative = f"NORMAL: {cust_label} within expected behavioral range."

    return dmc.Paper(
        [
            dmc.Group([
                dmc.Badge(tier, color=TIER_COLORS.get(tier, "gray")),
                dmc.Text(f"CUST-{idx:06d}", fw=600),
                dmc.Text(f"{score:.0%}", c="dimmed"),
                dmc.Text(f"({votes if votes else 0} votes)", size="xs", c="dimmed") if votes is not None else None,
            ], justify="space-between"),
            dmc.Space(h="sm"),
            dmc.Text(narrative, size="sm", c="dimmed"),
            dmc.Space(h="sm"),
            dmc.Group([
                dmc.Button("Review", size="xs", variant="subtle", color="cyan"),
                dmc.Button("Escalate", size="xs", variant="subtle", color="orange"),
                dmc.Button("Close", size="xs", variant="subtle", color="gray"),
            ], gap="xs"),
        ],
        p="md", radius="md", withBorder=True,
        style={"backgroundColor": THEME.DARK_BG_CARD, "marginBottom": "8px"},
    )


layout = dmc.Container(
    [
        dmc.Group([
            dmc.Title("Investigation Queue", order=2),
            dmc.Badge("Customer-Level Analysis", color="cyan", variant="light"),
        ], justify="space-between", mb="lg"),

        # Filters
        dmc.Paper(
            dmc.Group([
                dmc.Select(
                    id="filter-tier", label="Risk Tier",
                    data=[
                        {"value": "all", "label": "All Tiers"},
                        {"value": "CRITICAL", "label": "Critical"},
                        {"value": "HIGH", "label": "High"},
                        {"value": "MEDIUM", "label": "Medium"},
                        {"value": "LOW", "label": "Low"},
                    ],
                    value="all", w=150,
                ),
                dmc.Select(
                    id="filter-status", label="Status",
                    data=[
                        {"value": "all", "label": "All"},
                        {"value": "Open", "label": "Open"},
                    ],
                    value="all", w=150,
                ),
                dmc.Button(
                    "Refresh", id="btn-refresh-queue",
                    leftSection=DashIconify(icon="mdi:refresh"),
                    variant="subtle", ml="auto",
                ),
            ], gap="md"),
            p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}, mb="lg",
        ),

        # Stats
        dmc.SimpleGrid(
            cols=4, spacing="md", mb="lg",
            children=[
                dmc.Paper([
                    dmc.Text("Total Customers", c="dimmed", size="sm"),
                    dmc.Text("0", fw=700, size="xl", id="stat-total"),
                ], p="md", ta="center", radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),
                dmc.Paper([
                    dmc.Text("Critical Customers", c="dimmed", size="sm"),
                    dmc.Text("0", fw=700, size="xl", c="red", id="stat-critical"),
                ], p="md", ta="center", radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),
                dmc.Paper([
                    dmc.Text("High Risk Customers", c="dimmed", size="sm"),
                    dmc.Text("0", fw=700, size="xl", c="orange", id="stat-high"),
                ], p="md", ta="center", radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),
                dmc.Paper([
                    dmc.Text("Pending Review", c="dimmed", size="sm"),
                    dmc.Text("0", fw=700, size="xl", c="cyan", id="stat-pending"),
                ], p="md", ta="center", radius="md", style={"backgroundColor": THEME.DARK_BG_CARD}),
            ],
        ),

        # Customer list
        html.Div(id="alert-list"),

        dcc.Interval(id="queue-refresh", interval=30000, n_intervals=0),
    ],
    fluid=True,
)


@callback(
    [Output("alert-list", "children"),
     Output("stat-total", "children"),
     Output("stat-critical", "children"),
     Output("stat-high", "children"),
     Output("stat-pending", "children")],
    [Input("btn-refresh-queue", "n_clicks"),
     Input("filter-tier", "value"),
     Input("filter-status", "value"),
     Input("queue-refresh", "n_intervals"),
     Input("store-pipeline-complete", "data")],
)
def update_queue(n_clicks, tier_filter, status_filter, n_intervals, pipeline_complete):
    """V6: Customer-level queue with tiered consensus results."""
    try:
        from utils.data_io import data_vault
        df = data_vault.get_scored_data()

        if df is None or "anomaly_score" not in df.columns or "risk_tier" not in df.columns:
            return (
                [dmc.Alert("No pipeline results. Run the pipeline first to analyze customers.", color="gray",
                           icon=DashIconify(icon="mdi:information"))],
                "0", "0", "0", "0",
            )

        # V6: Filter to high-risk customers (excluding NORMAL tier)
        customers_df = df[df["risk_tier"] != "NORMAL"].sort_values("anomaly_score", ascending=False)

        if tier_filter != "all":
            customers_df = customers_df[customers_df["risk_tier"] == tier_filter]

        # Limit to top 50 for display
        display_df = customers_df.head(50)

        cards = []
        for i, (_, row) in enumerate(display_df.iterrows()):
            cards.append(customer_card(row.to_dict(), i + 1))

        if not cards:
            cards = [dmc.Text("No customers match the current filters.", c="dimmed", ta="center")]

        # Stats from full customer set
        total = len(customers_df)
        critical = int((customers_df["risk_tier"] == "CRITICAL").sum())
        high = int((customers_df["risk_tier"] == "HIGH").sum())

        return cards, str(total), str(critical), str(high), str(total)

    except Exception as e:
        return [dmc.Alert("An error occurred. Check audit log for details.", color="red")], "0", "0", "0", "0"


# =============================================================================
# RBAC ENFORCEMENT
# =============================================================================
from auth.manager import require_role as _require_role
_static_layout = layout

@_require_role("investigator")
def layout(**kwargs):
    return _static_layout
