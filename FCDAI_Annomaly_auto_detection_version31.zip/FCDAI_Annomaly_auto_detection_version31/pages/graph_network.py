"""
Graph Network Visualization — AIM AI Vault (V14)
==================================================
#14 Interactive entity relationship graph using Plotly network diagram.
    Shows PageRank, community, and centrality results visually.
    Pure Plotly (no Cytoscape dependency). Air-gapped. Zero-network.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import pandas as pd
import numpy as np
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP

dash.register_page(__name__, path="/graph", name="Graph Network", order=16)

PLOTLY_CFG = APP.PLOTLY_CONFIG


def _load_graph_data():
    """
    Build entity-relationship graph from anomaly method_flags.
    Nodes = entities, edges = shared-method co-flagging.
    """
    try:
        from database.engine import get_session
        from database.models import Anomaly
        session = get_session()
        anomalies = session.query(Anomaly).filter(
            Anomaly.risk_tier.in_(["CRITICAL", "HIGH", "MEDIUM"])
        ).limit(500).all()
        session.close()

        if not anomalies:
            return pd.DataFrame(), [], []

        # Build node list
        nodes = {}
        for a in anomalies:
            eid = a.entity_id or f"E-{a.id}"
            if eid not in nodes:
                nodes[eid] = {
                    "entity_id": eid,
                    "max_score": a.anomaly_score or 0,
                    "risk_tier": a.risk_tier or "NORMAL",
                    "methods": set(),
                    "vote_count": a.vote_count or 0,
                }
            nodes[eid]["max_score"] = max(nodes[eid]["max_score"], a.anomaly_score or 0)
            if a.method_flags:
                try:
                    flags = json.loads(a.method_flags) if isinstance(a.method_flags, str) else a.method_flags
                    if isinstance(flags, list):
                        nodes[eid]["methods"].update(flags)
                except Exception:
                    pass

        # Build edges: two entities sharing ≥2 flagging methods
        node_list = list(nodes.values())
        edges = []
        for i in range(len(node_list)):
            for j in range(i + 1, min(i + 50, len(node_list))):  # limit O(n^2)
                shared = node_list[i]["methods"] & node_list[j]["methods"]
                if len(shared) >= 2:
                    edges.append({
                        "source": node_list[i]["entity_id"],
                        "target": node_list[j]["entity_id"],
                        "weight": len(shared),
                        "shared_methods": list(shared)[:5],
                    })

        # Node dataframe
        for n in node_list:
            n["n_methods"] = len(n["methods"])
            n["methods"] = ",".join(list(n["methods"])[:5])
        node_df = pd.DataFrame(node_list)

        return node_df, edges, node_list
    except Exception:
        return pd.DataFrame(), [], []


def _build_network_figure(node_df, edges):
    """Create Plotly scatter-based network graph."""
    fig = go.Figure()

    if node_df.empty:
        fig.add_annotation(text="No graph data — run pipeline first",
                           xref="paper", yref="paper", x=0.5, y=0.5,
                           showarrow=False, font=dict(size=16, color="#888"))
        fig.update_layout(template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
                          plot_bgcolor="rgba(0,0,0,0)", height=550)
        return fig

    n_nodes = len(node_df)
    # Force-directed layout (simple spring-embedding)
    np.random.seed(42)
    pos_x = np.random.randn(n_nodes) * 3
    pos_y = np.random.randn(n_nodes) * 3

    # Simple force iterations
    id_to_idx = {row["entity_id"]: idx for idx, row in node_df.iterrows()}
    for _ in range(50):
        for e in edges:
            si = id_to_idx.get(e["source"])
            ti = id_to_idx.get(e["target"])
            if si is None or ti is None:
                continue
            dx = pos_x[ti] - pos_x[si]
            dy = pos_y[ti] - pos_y[si]
            dist = max(np.sqrt(dx**2 + dy**2), 0.01)
            force = (dist - 1.5) * 0.05
            pos_x[si] += dx / dist * force
            pos_y[si] += dy / dist * force
            pos_x[ti] -= dx / dist * force
            pos_y[ti] -= dy / dist * force

    # Repulsion
    for _ in range(30):
        for i in range(n_nodes):
            for j in range(i + 1, min(i + 20, n_nodes)):
                dx = pos_x[j] - pos_x[i]
                dy = pos_y[j] - pos_y[i]
                dist = max(np.sqrt(dx**2 + dy**2), 0.1)
                if dist < 2:
                    repel = 0.3 / dist**2
                    pos_x[i] -= dx / dist * repel
                    pos_y[i] -= dy / dist * repel
                    pos_x[j] += dx / dist * repel
                    pos_y[j] += dy / dist * repel

    # Draw edges
    for e in edges:
        si = id_to_idx.get(e["source"])
        ti = id_to_idx.get(e["target"])
        if si is None or ti is None:
            continue
        fig.add_trace(go.Scatter(
            x=[pos_x[si], pos_x[ti], None],
            y=[pos_y[si], pos_y[ti], None],
            mode="lines",
            line=dict(width=max(1, e["weight"] * 0.5), color="rgba(100,180,255,0.25)"),
            hoverinfo="skip",
            showlegend=False,
        ))

    # Node colors by tier
    tier_colors = {"CRITICAL": "#FF5252", "HIGH": "#FF9800",
                   "MEDIUM": "#FFB300", "LOW": "#2196F3", "NORMAL": "#00C853"}

    colors = [tier_colors.get(row["risk_tier"], "#888") for _, row in node_df.iterrows()]
    sizes = [max(10, min(35, row.get("vote_count", 5))) for _, row in node_df.iterrows()]
    hover = [f"Entity: {row['entity_id'][:12]}...<br>"
             f"Tier: {row['risk_tier']}<br>"
             f"Score: {row['max_score']:.3f}<br>"
             f"Methods: {row['n_methods']}"
             for _, row in node_df.iterrows()]

    fig.add_trace(go.Scatter(
        x=pos_x, y=pos_y,
        mode="markers+text",
        marker=dict(size=sizes, color=colors, line=dict(width=1, color="#fff"), opacity=0.85),
        text=[row["entity_id"][:6] for _, row in node_df.iterrows()],
        textposition="top center",
        textfont=dict(size=8, color="#ccc"),
        hovertext=hover,
        hoverinfo="text",
        showlegend=False,
    ))

    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=600,
        margin=dict(l=10, r=10, t=40, b=10),
        title="Entity Relationship Network (shared detection methods)",
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
    )

    return fig

try:
    from auth.manager import require_role
except ImportError:
    require_role = lambda *a, **kw: (lambda fn: fn)

@require_role("viewer")
def layout(**kwargs):
    node_df, edges, _ = _load_graph_data()
    fig = _build_network_figure(node_df, edges)

    n_nodes = len(node_df) if not node_df.empty else 0
    n_edges = len(edges)

    stat_cards = [
        ("Entities in Graph", str(n_nodes), "mdi:account-group", "cyan"),
        ("Relationships", str(n_edges), "mdi:link-variant", "indigo"),
        ("Avg Methods/Entity",
         "{:.1f}".format(node_df["n_methods"].mean()) if not node_df.empty else "0",
         "mdi:function-variant", "grape"),
    ]

    return dmc.Container([
        dmc.Group([
            dmc.Group([
                DashIconify(icon="mdi:graph-outline", width=28, color="#22b8cf"),
                dmc.Title("Graph Network", order=2),
            ], gap="xs"),
            dmc.Badge("Entity Relationships | Air-Gapped", color="cyan", variant="light"),
        ], justify="space-between", mb="lg"),

        dmc.Text("Interactive entity relationship visualization. Nodes represent entities "
                 "flagged by the pipeline. Edges connect entities sharing similar detection patterns. "
                 "Node size reflects vote count; color reflects risk tier.",
                 size="sm", c="dimmed", mb="lg"),

        dmc.SimpleGrid(cols={"base": 1, "md": 3}, spacing="md", mb="lg", children=[
            dmc.Card([
                dmc.Group([
                    DashIconify(icon=icon, width=24, color="#22b8cf"),
                    dmc.Stack([
                        dmc.Text(label, size="xs", c="dimmed"),
                        dmc.Text(value, size="xl", fw=700),
                    ], gap=0),
                ]),
            ], withBorder=True, p="md", radius="md",
                style={"backgroundColor": THEME.DARK_BG_CARD})
            for label, value, icon, _c in stat_cards
        ]),

        dmc.Paper([
            dcc.Graph(figure=fig, config=PLOTLY_CFG, style={"height": "600px"}),
        ], p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}),

        # Legend
        dmc.Paper([
            dmc.Text("Legend", fw=600, mb="xs"),
            dmc.Group([
                dmc.Badge("CRITICAL", color="red", variant="filled", size="sm"),
                dmc.Badge("HIGH", color="orange", variant="filled", size="sm"),
                dmc.Badge("MEDIUM", color="yellow", variant="filled", size="sm"),
                dmc.Badge("LOW", color="blue", variant="filled", size="sm"),
                dmc.Badge("NORMAL", color="green", variant="filled", size="sm"),
            ], gap="xs"),
            dmc.Text("Node size = vote count | Edge = ≥2 shared flagging methods",
                     size="xs", c="dimmed", mt="xs"),
        ], p="md", radius="md", withBorder=True, mt="md",
            style={"backgroundColor": THEME.DARK_BG_CARD}),
    ], fluid=True)
