"""
Task Manager Page — Background Job Tracker (V10)
=================================================
Monitors Diskcache background callback jobs and SQLite pipeline_runs.
Shows: Pending, Running, Completed, Failed tasks with timing data.

dash.register_page — accessible at /tasks
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
from dash_iconify import DashIconify
from datetime import datetime
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

dash.register_page(
    __name__,
    path="/tasks",
    name="Task Manager",
    title="Task Manager — AIM AI Vault V10",
)


# =============================================================================
# LAYOUT
# =============================================================================
try:
    from auth.manager import require_role
except ImportError:
    require_role = lambda *a, **kw: (lambda fn: fn)

@require_role("admin")
def layout(**kwargs):
    return dmc.Container(
        [
            # Header
            dmc.Group(
                [
                    dmc.ThemeIcon(
                        DashIconify(icon="mdi:clipboard-list", width=28),
                        size="xl", radius="md", variant="gradient",
                        gradient={"from": "cyan", "to": "indigo"},
                    ),
                    dmc.Stack(
                        [
                            dmc.Title("Task Manager", order=2),
                            dmc.Text(
                                "Background job tracker — pipeline runs, data imports, audit events",
                                size="sm", c="dimmed",
                            ),
                        ],
                        gap=0,
                    ),
                ],
                gap="md", mb="lg",
            ),

            # Summary stats row
            html.Div(id="task-summary-cards"),

            dmc.Space(h="md"),

            # Pipeline runs table
            dmc.Paper(
                [
                    dmc.Group(
                        [
                            dmc.Text("Pipeline Run History", fw=600, size="lg"),
                            dmc.ActionIcon(
                                DashIconify(icon="mdi:refresh", width=20),
                                id="task-refresh-btn",
                                variant="subtle", color="cyan", size="lg",
                            ),
                        ],
                        justify="space-between", mb="md",
                    ),
                    html.Div(id="task-pipeline-table"),
                ],
                p="lg", radius="md",
                style={"backgroundColor": "rgba(0,0,0,0.2)", "border": "1px solid #30363D"},
            ),

            dmc.Space(h="md"),

            # Recent audit events
            dmc.Paper(
                [
                    dmc.Text("Recent Audit Events (Last 25)", fw=600, size="lg", mb="md"),
                    html.Div(id="task-audit-table"),
                ],
                p="lg", radius="md",
                style={"backgroundColor": "rgba(0,0,0,0.2)", "border": "1px solid #30363D"},
            ),

            # Auto-refresh interval
            dcc.Interval(id="task-poll-interval", interval=3000, n_intervals=0),
        ],
        size="xl", py="lg",
    )


# =============================================================================
# STATUS BADGE HELPERS
# =============================================================================
STATUS_COLORS = {
    "pending": "yellow",
    "running": "blue",
    "completed": "green",
    "failed": "red",
}
STATUS_ICONS = {
    "pending": "mdi:clock-outline",
    "running": "mdi:loading",
    "completed": "mdi:check-circle",
    "failed": "mdi:alert-circle",
}


def _status_badge(status: str):
    color = STATUS_COLORS.get(status, "gray")
    return dmc.Badge(
        status.upper(), color=color, variant="light", size="sm",
        leftSection=DashIconify(icon=STATUS_ICONS.get(status, "mdi:help"), width=14),
    )


def _stat_card(label: str, value: int, color: str, icon: str):
    return dmc.Paper(
        dmc.Group(
            [
                dmc.ThemeIcon(
                    DashIconify(icon=icon, width=24),
                    size="lg", radius="md", color=color, variant="light",
                ),
                dmc.Stack(
                    [
                        dmc.Text(str(value), fw=700, size="xl"),
                        dmc.Text(label, size="xs", c="dimmed"),
                    ],
                    gap=0,
                ),
            ],
            gap="md",
        ),
        p="md", radius="md",
        style={"backgroundColor": "rgba(0,0,0,0.15)", "border": "1px solid #30363D", "flex": "1"},
    )


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("task-summary-cards", "children"),
    Output("task-pipeline-table", "children"),
    Output("task-audit-table", "children"),
    Input("task-poll-interval", "n_intervals"),
    Input("task-refresh-btn", "n_clicks"),
)
def refresh_task_manager(_n, _clicks):
    """Refresh all task manager panels."""

    # --- Pipeline Runs from SQLite ---
    runs = []
    counts = {"pending": 0, "running": 0, "completed": 0, "failed": 0}
    try:
        from database.engine import get_session
        from database.models import PipelineRun
        session = get_session()
        runs = session.query(PipelineRun).order_by(PipelineRun.started_at.desc()).limit(50).all()
        for r in runs:
            if r.status in counts:
                counts[r.status] += 1
        session.close()
    except Exception:
        pass

    # Summary cards
    summary = dmc.SimpleGrid(
        [
            _stat_card("Pending", counts["pending"], "yellow", "mdi:clock-outline"),
            _stat_card("Running", counts["running"], "blue", "mdi:loading"),
            _stat_card("Completed", counts["completed"], "green", "mdi:check-circle"),
            _stat_card("Failed", counts["failed"], "red", "mdi:alert-circle"),
        ],
        cols={"base": 2, "sm": 4},
    )

    # Pipeline runs table
    if not runs:
        pipeline_table = dmc.Text("No pipeline runs recorded yet.", c="dimmed", size="sm")
    else:
        rows = []
        for r in runs[:25]:
            duration_str = f"{r.duration_sec:.1f}s" if r.duration_sec else "—"
            started_str = r.started_at.strftime("%Y-%m-%d %H:%M:%S") if r.started_at else "—"
            rows.append(
                html.Tr([
                    html.Td(_status_badge(r.status or "pending")),
                    html.Td(dmc.Code(r.run_id or "—")),
                    html.Td(dmc.Text(started_str, size="sm")),
                    html.Td(dmc.Text(duration_str, size="sm")),
                    html.Td(dmc.Badge(str(r.n_anomalies or 0), color="orange", variant="light", size="sm")),
                    html.Td(dmc.Text(r.error_message[:60] if r.error_message else "—", size="xs", c="red" if r.error_message else "dimmed")),
                ])
            )

        pipeline_table = html.Table(
            [
                html.Thead(html.Tr([
                    html.Th(dmc.Text("Status", size="xs", fw=600)),
                    html.Th(dmc.Text("Run ID", size="xs", fw=600)),
                    html.Th(dmc.Text("Started", size="xs", fw=600)),
                    html.Th(dmc.Text("Duration", size="xs", fw=600)),
                    html.Th(dmc.Text("Anomalies", size="xs", fw=600)),
                    html.Th(dmc.Text("Error", size="xs", fw=600)),
                ])),
                html.Tbody(rows),
            ],
            style={"width": "100%", "borderCollapse": "collapse"},
            className="w-full text-sm",
        )

    # --- Recent Audit Events ---
    audit_rows = []
    try:
        from database.engine import get_session
        from database.models import AuditLog
        session = get_session()
        events = session.query(AuditLog).order_by(AuditLog.created_at.desc()).limit(25).all()
        for e in events:
            ts = e.created_at.strftime("%H:%M:%S") if e.created_at else "—"
            audit_rows.append(
                html.Tr([
                    html.Td(dmc.Text(ts, size="xs")),
                    html.Td(dmc.Badge(e.username or "system", size="xs", variant="outline")),
                    html.Td(dmc.Text(e.action or "—", size="xs")),
                    html.Td(dmc.Badge(e.status or "—", size="xs",
                                       color="green" if e.status == "SUCCESS" else "red", variant="light")),
                    html.Td(dmc.Text(e.client_ip or "—", size="xs", c="dimmed")),
                ])
            )
        session.close()
    except Exception:
        pass

    if not audit_rows:
        audit_table = dmc.Text("No audit events yet.", c="dimmed", size="sm")
    else:
        audit_table = html.Table(
            [
                html.Thead(html.Tr([
                    html.Th(dmc.Text("Time", size="xs", fw=600)),
                    html.Th(dmc.Text("User", size="xs", fw=600)),
                    html.Th(dmc.Text("Action", size="xs", fw=600)),
                    html.Th(dmc.Text("Status", size="xs", fw=600)),
                    html.Th(dmc.Text("Client IP", size="xs", fw=600)),
                ])),
                html.Tbody(audit_rows),
            ],
            style={"width": "100%", "borderCollapse": "collapse"},
            className="w-full text-sm",
        )

    return summary, pipeline_table, audit_table
