"""
AIM AI Vault V27 — SHAP Explanations Page
============================================
Real Shapley-value explanations for anomaly detection models.
Shows global feature importance, per-method SHAP summary,
and per-entity waterfall/force charts.

Author: AIM AI Vault V27
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import THEME, APP, PATHS

dash.register_page(__name__, path="/shap", name="SHAP Explanations", order=22)

PLOTLY_CFG = APP.PLOTLY_CONFIG

# =============================================================================
# PAGE LAYOUT
# =============================================================================
layout = dmc.Container(
    [
        # Header
        dmc.Group(
            [
                dmc.Group([
                    dmc.Title("SHAP Explanations", order=2),
                    dmc.Badge("V27 — Real Shapley Values", color="violet", variant="light"),
                    dmc.Badge(APP.VERSION_TAG, color="cyan", variant="outline", size="sm"),
                ], gap="md"),
                dmc.Button(
                    "Compute SHAP",
                    id="shap-btn-compute",
                    leftSection=DashIconify(icon="mdi:brain", width=18),
                    color="violet",
                    variant="filled",
                    size="sm",
                ),
            ],
            justify="space-between",
            mb="lg",
        ),

        # Status bar
        html.Div(id="shap-status-bar"),

        dmc.Space(h="md"),

        # Method selector
        dmc.Paper(
            [
                dmc.SimpleGrid(
                    cols={"base": 1, "md": 3},
                    spacing="md",
                    children=[
                        dmc.Select(
                            id="shap-method-select",
                            label="Detection Method",
                            placeholder="Select method...",
                            data=[],
                            clearable=True,
                        ),
                        dmc.NumberInput(
                            id="shap-entity-idx",
                            label="Entity Index (for waterfall)",
                            value=0,
                            min=0,
                            max=9999,
                        ),
                        dmc.Group([
                            dmc.Button(
                                "Show Global SHAP",
                                id="shap-btn-global",
                                leftSection=DashIconify(icon="mdi:chart-bar", width=18),
                                color="violet",
                                variant="light",
                                mt="xl",
                            ),
                            dmc.Button(
                                "Show Entity SHAP",
                                id="shap-btn-entity",
                                leftSection=DashIconify(icon="mdi:account-details", width=18),
                                color="teal",
                                variant="light",
                                mt="xl",
                            ),
                        ], gap="sm"),
                    ],
                ),
            ],
            p="md",
            mb="lg",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
        ),

        # Global SHAP Summary
        dmc.Paper(
            [
                dmc.Text("Global Feature Importance (mean |SHAP|)", fw=600, mb="md", size="lg"),
                dcc.Graph(id="shap-global-bar", config=PLOTLY_CFG, style={"height": "500px"}),
            ],
            p="md",
            mb="lg",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
        ),

        # SHAP Bee swarm / dot plot
        dmc.Paper(
            [
                dmc.Text("SHAP Value Distribution (Bee Swarm)", fw=600, mb="md", size="lg"),
                dcc.Graph(id="shap-beeswarm", config=PLOTLY_CFG, style={"height": "500px"}),
            ],
            p="md",
            mb="lg",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
        ),

        # Entity-level waterfall
        dmc.Paper(
            [
                dmc.Text("Entity Waterfall — Top Feature Contributions", fw=600, mb="md", size="lg"),
                dcc.Graph(id="shap-waterfall", config=PLOTLY_CFG, style={"height": "450px"}),
            ],
            p="md",
            mb="lg",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
        ),

        # Method comparison table
        dmc.Paper(
            [
                dmc.Text("All Methods — SHAP Computation Summary", fw=600, mb="md", size="lg"),
                html.Div(id="shap-methods-table"),
            ],
            p="md",
            mb="lg",
            radius="md",
            withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD},
        ),

        # Hidden store for SHAP data
        dcc.Store(id="shap-store", storage_type="memory"),
    ],
    size="xl",
    py="lg",
)


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("shap-store", "data"),
    Output("shap-status-bar", "children"),
    Output("shap-method-select", "data"),
    Input("shap-btn-compute", "n_clicks"),
    prevent_initial_call=True,
)
def compute_shap(n_clicks):
    """Compute SHAP values for all detection methods."""
    if not n_clicks:
        return no_update, no_update, no_update

    # Load persisted SHAP results if available
    shap_path = PATHS.DATA_VAULT / "shap_results.json"
    if shap_path.exists():
        try:
            with open(shap_path, "r") as f:
                shap_data = json.load(f)

            methods = list(shap_data.keys())
            method_options = [{"value": m, "label": m} for m in methods]

            status = dmc.Alert(
                f"Loaded SHAP results for {len(methods)} methods from last pipeline run",
                title="SHAP Data Loaded",
                color="green",
                icon=DashIconify(icon="mdi:check-circle"),
            )
            return shap_data, status, method_options
        except Exception as e:
            status = dmc.Alert(
                f"Failed to load SHAP data: {e}",
                title="Error",
                color="red",
                icon=DashIconify(icon="mdi:alert"),
            )
            return {}, status, []

    status = dmc.Alert(
        "No SHAP data found. Run the pipeline first — V27 computes SHAP automatically during execution.",
        title="No SHAP Data",
        color="yellow",
        icon=DashIconify(icon="mdi:information"),
    )
    return {}, status, []


@callback(
    Output("shap-global-bar", "figure"),
    Output("shap-beeswarm", "figure"),
    Input("shap-btn-global", "n_clicks"),
    State("shap-store", "data"),
    State("shap-method-select", "value"),
    prevent_initial_call=True,
)
def update_global_charts(n_clicks, shap_data, selected_method):
    """Render global SHAP bar chart and bee swarm."""
    empty_fig = go.Figure()
    empty_fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        annotations=[{"text": "Select a method and click 'Show Global SHAP'",
                       "xref": "paper", "yref": "paper", "x": 0.5, "y": 0.5,
                       "showarrow": False, "font": {"size": 16, "color": "gray"}}],
    )

    if not shap_data or not selected_method or selected_method not in shap_data:
        return empty_fig, empty_fig

    method_data = shap_data[selected_method]
    importance = method_data.get("global_importance", [])

    if not importance:
        return empty_fig, empty_fig

    df_imp = pd.DataFrame(importance)
    df_top = df_imp.head(20)

    # Bar chart
    bar_fig = go.Figure(go.Bar(
        x=df_top["mean_abs_shap"],
        y=df_top["feature"],
        orientation="h",
        marker_color="mediumpurple",
    ))
    bar_fig.update_layout(
        title=f"Global Feature Importance — {selected_method}",
        xaxis_title="Mean |SHAP value|",
        yaxis_title="Feature",
        yaxis=dict(autorange="reversed"),
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=500,
        margin=dict(l=200),
    )

    # Bee swarm approximation (jittered strip plot)
    shap_values_top = method_data.get("shap_values_top", [])
    features = method_data.get("features", [])

    if shap_values_top and features:
        sv_arr = np.array(shap_values_top)
        rows = []
        for j, feat in enumerate(features[:15]):
            for i in range(min(sv_arr.shape[0], 200)):
                rows.append({
                    "Feature": feat,
                    "SHAP Value": sv_arr[i, j],
                    "jitter": np.random.normal(0, 0.1),
                })
        df_bee = pd.DataFrame(rows)

        bee_fig = px.strip(
            df_bee, x="SHAP Value", y="Feature", color="SHAP Value",
            color_continuous_scale="RdBu_r",
            color_continuous_midpoint=0,
        )
        bee_fig.update_layout(
            title=f"SHAP Value Distribution — {selected_method}",
            template="plotly_dark",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            height=500,
            yaxis=dict(autorange="reversed"),
        )
    else:
        bee_fig = empty_fig

    return bar_fig, bee_fig


@callback(
    Output("shap-waterfall", "figure"),
    Input("shap-btn-entity", "n_clicks"),
    State("shap-store", "data"),
    State("shap-method-select", "value"),
    State("shap-entity-idx", "value"),
    prevent_initial_call=True,
)
def update_entity_waterfall(n_clicks, shap_data, selected_method, entity_idx):
    """Render entity-level SHAP waterfall chart."""
    empty_fig = go.Figure()
    empty_fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        annotations=[{"text": "Select a method and entity, then click 'Show Entity SHAP'",
                       "xref": "paper", "yref": "paper", "x": 0.5, "y": 0.5,
                       "showarrow": False, "font": {"size": 16, "color": "gray"}}],
    )

    if not shap_data or not selected_method or selected_method not in shap_data:
        return empty_fig

    method_data = shap_data[selected_method]
    shap_values_top = method_data.get("shap_values_top", [])
    features = method_data.get("features", [])
    base_value = method_data.get("base_value", 0)

    if not shap_values_top or not features:
        return empty_fig

    sv_arr = np.array(shap_values_top)
    idx = int(entity_idx or 0)
    if idx >= sv_arr.shape[0]:
        idx = 0

    entity_shap = sv_arr[idx]
    # Sort by absolute value
    sorted_idx = np.argsort(-np.abs(entity_shap))[:15]
    sorted_features = [features[i] for i in sorted_idx if i < len(features)]
    sorted_values = [entity_shap[i] for i in sorted_idx if i < len(entity_shap)]

    colors = ["rgba(220, 50, 50, 0.8)" if v > 0 else "rgba(50, 120, 220, 0.8)" for v in sorted_values]

    fig = go.Figure(go.Bar(
        x=sorted_values,
        y=sorted_features,
        orientation="h",
        marker_color=colors,
        text=[f"{v:+.4f}" for v in sorted_values],
        textposition="outside",
    ))

    fig.add_vline(x=0, line_dash="dash", line_color="gray")

    fig.update_layout(
        title=f"Entity #{idx} — SHAP Waterfall ({selected_method})",
        xaxis_title="SHAP Value (contribution to risk score)",
        yaxis=dict(autorange="reversed"),
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=450,
        margin=dict(l=200),
        annotations=[
            dict(text=f"Base value: {base_value:.4f}", xref="paper", yref="paper",
                 x=0.98, y=0.02, showarrow=False, font=dict(size=12, color="gray")),
        ],
    )

    return fig


@callback(
    Output("shap-methods-table", "children"),
    Input("shap-store", "data"),
)
def update_methods_table(shap_data):
    """Render summary table of all SHAP computations."""
    if not shap_data:
        return dmc.Text("No SHAP data available. Click 'Compute SHAP' to load.", c="dimmed")

    rows = []
    for method_name, data in shap_data.items():
        rows.append(html.Tr([
            html.Td(method_name, style={"fontWeight": "bold"}),
            html.Td(dmc.Badge(data.get("explainer_type", "?"),
                              color="violet" if "tree" in data.get("explainer_type", "") else
                                     "teal" if "kernel" in data.get("explainer_type", "") else "gray",
                              variant="light")),
            html.Td(str(data.get("n_samples", 0))),
            html.Td(str(data.get("n_features", 0))),
            html.Td(f"{data.get('computation_time_ms', 0):.0f} ms"),
            html.Td(data.get("error", "—") if data.get("error") else "✓",
                     style={"color": "red" if data.get("error") else "lime"}),
        ]))

    table = html.Table(
        [
            html.Thead(html.Tr([
                html.Th("Method"), html.Th("Explainer"), html.Th("Samples"),
                html.Th("Features"), html.Th("Time"), html.Th("Status"),
            ])),
            html.Tbody(rows),
        ],
        style={"width": "100%", "borderCollapse": "collapse"},
    )
    return table
