"""
Regulatory Dashboard — AIM AI Vault (V11)
==========================================
#13 Compliance metrics, filing statistics, aging analysis.
    Offline: all data from local SQLite. Zero-network.
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import sys
from pathlib import Path
from datetime import datetime, timedelta

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS, APP

dash.register_page(__name__, path="/regulatory", name="Regulatory Dashboard", order=15)

PLOTLY_CFG = APP.PLOTLY_CONFIG


def _load_compliance_data():
    """Load anomalies + pipeline runs for compliance metrics."""
    try:
        from database.engine import get_session
        from database.models import Anomaly, PipelineRun, AuditLog
        session = get_session()

        # Anomaly metrics
        anomalies = session.query(Anomaly).all()
        anom_df = pd.DataFrame([{
            "entity_id": a.entity_id, "risk_tier": a.risk_tier,
            "anomaly_score": a.anomaly_score, "is_confirmed": a.is_confirmed,
            "vote_count": a.vote_count, "created_at": a.created_at,
            "run_id": a.run_id,
        } for a in anomalies]) if anomalies else pd.DataFrame()

        # Pipeline runs
        runs = session.query(PipelineRun).order_by(PipelineRun.id.desc()).limit(100).all()
        run_df = pd.DataFrame([{
            "run_id": r.run_id, "status": r.status,
            "started_at": r.started_at, "completed_at": r.completed_at,
            "n_anomalies": r.n_anomalies, "duration_sec": r.duration_sec,
        } for r in runs]) if runs else pd.DataFrame()

        # Audit counts
        audit_count = session.query(AuditLog).count()

        session.close()
        return anom_df, run_df, audit_count
    except Exception:
        return pd.DataFrame(), pd.DataFrame(), 0

try:
    from auth.manager import require_role
except ImportError:
    require_role = lambda *a, **kw: (lambda fn: fn)

@require_role("viewer")
def layout(**kwargs):
    anom_df, run_df, audit_count = _load_compliance_data()

    # KPIs
    total_entities = anom_df["entity_id"].nunique() if not anom_df.empty else 0
    critical = len(anom_df[anom_df["risk_tier"] == "CRITICAL"]) if not anom_df.empty else 0
    high = len(anom_df[anom_df["risk_tier"] == "HIGH"]) if not anom_df.empty else 0
    confirmed = len(anom_df[anom_df["is_confirmed"] == True]) if not anom_df.empty else 0
    total_runs = len(run_df)
    confirmation_rate = "{:.1f}%".format(confirmed / total_entities * 100) if total_entities > 0 else "N/A"

    kpis = [
        ("Total Entities Screened", str(total_entities), "mdi:account-search", "cyan"),
        ("CRITICAL Detections", str(critical), "mdi:alert-octagon", "red"),
        ("HIGH Risk Detections", str(high), "mdi:alert", "orange"),
        ("Confirmed Anomalies", str(confirmed), "mdi:check-decagram", "green"),
        ("Confirmation Rate", confirmation_rate, "mdi:percent", "indigo"),
        ("Pipeline Runs", str(total_runs), "mdi:rocket-launch", "teal"),
        ("Audit Log Entries", str(audit_count), "mdi:shield-check", "violet"),
    ]

    kpi_cards = [
        dmc.Card([
            dmc.Group([
                DashIconify(icon=icon, width=28, color="#22b8cf"),
                dmc.Stack([
                    dmc.Text(label, size="xs", c="dimmed"),
                    dmc.Text(value, size="xl", fw=700),
                ], gap=0),
            ]),
        ], withBorder=True, p="md", radius="md",
            style={"backgroundColor": THEME.DARK_BG_CARD})
        for label, value, icon, _color in kpis
    ]

    # Risk tier distribution chart
    tier_fig = go.Figure()
    if not anom_df.empty:
        tier_counts = anom_df["risk_tier"].value_counts()
        colors = {"CRITICAL": "#FF5252", "HIGH": "#FF9800", "MEDIUM": "#FFB300",
                  "LOW": "#2196F3", "NORMAL": "#00C853"}
        tier_fig = go.Figure(go.Bar(
            x=[tier_counts.get(t, 0) for t in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "NORMAL"]],
            y=["CRITICAL", "HIGH", "MEDIUM", "LOW", "NORMAL"],
            orientation="h",
            marker_color=[colors.get(t, "#ccc") for t in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "NORMAL"]],
        ))
    tier_fig.update_layout(
        template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)", margin=dict(l=10, r=10, t=30, b=10),
        title="Risk Tier Distribution", height=280,
    )

    # Run timeline chart
    timeline_fig = go.Figure()
    if not run_df.empty and "started_at" in run_df.columns:
        run_df_valid = run_df.dropna(subset=["started_at"])
        if not run_df_valid.empty:
            timeline_fig = go.Figure(go.Scatter(
                x=run_df_valid["started_at"], y=run_df_valid["n_anomalies"],
                mode="lines+markers", marker=dict(size=8, color="#22b8cf"),
                line=dict(color="#22b8cf"),
            ))
    timeline_fig.update_layout(
        template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)", margin=dict(l=10, r=10, t=30, b=10),
        title="Anomalies per Run (Timeline)", height=280,
        xaxis_title="Run Date", yaxis_title="Anomalies Detected",
    )

    # Aging analysis
    aging_fig = go.Figure()
    if not anom_df.empty and "created_at" in anom_df.columns:
        now = datetime.utcnow()
        anom_df_c = anom_df.dropna(subset=["created_at"]).copy()
        if not anom_df_c.empty:
            anom_df_c["age_days"] = (now - pd.to_datetime(anom_df_c["created_at"])).dt.days
            unconfirmed = anom_df_c[anom_df_c["is_confirmed"] == False]
            if not unconfirmed.empty:
                bins = [0, 1, 7, 30, 90, 999]
                labels = ["<1 day", "1-7 days", "7-30 days", "30-90 days", "90+ days"]
                unconfirmed = unconfirmed.copy()
                unconfirmed["age_bucket"] = pd.cut(unconfirmed["age_days"], bins=bins, labels=labels)
                aging_counts = unconfirmed["age_bucket"].value_counts().reindex(labels, fill_value=0)
                aging_fig = go.Figure(go.Bar(
                    x=labels, y=aging_counts.values,
                    marker_color=["#00C853", "#2196F3", "#FFB300", "#FF9800", "#FF5252"],
                ))
    aging_fig.update_layout(
        template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)", margin=dict(l=10, r=10, t=30, b=10),
        title="Unconfirmed Alert Aging", height=280,
    )

    return dmc.Container([
        dmc.Group([
            dmc.Group([
                DashIconify(icon="mdi:gavel", width=28, color="#22b8cf"),
                dmc.Title("Regulatory Dashboard", order=2),
            ], gap="xs"),
            dmc.Badge("Compliance Metrics | Air-Gapped", color="cyan", variant="light"),
        ], justify="space-between", mb="lg"),

        dmc.Text("Regulatory compliance overview: detection metrics, confirmation rates, "
                 "audit trail statistics, and alert aging analysis. All data from local SQLite.",
                 size="sm", c="dimmed", mb="lg"),

        # KPI Cards
        dmc.SimpleGrid(cols={"base": 2, "md": 4, "lg": 7}, spacing="md", mb="lg",
                       children=kpi_cards),

        # Charts
        dmc.SimpleGrid(cols={"base": 1, "lg": 2}, spacing="lg", mb="lg", children=[
            dmc.Paper([
                dcc.Graph(figure=tier_fig, config=PLOTLY_CFG),
            ], p="md", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD}),
            dmc.Paper([
                dcc.Graph(figure=timeline_fig, config=PLOTLY_CFG),
            ], p="md", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD}),
        ]),

        dmc.Paper([
            dcc.Graph(figure=aging_fig, config=PLOTLY_CFG),
        ], p="md", radius="md", withBorder=True,
            style={"backgroundColor": THEME.DARK_BG_CARD}),
    ], fluid=True)
