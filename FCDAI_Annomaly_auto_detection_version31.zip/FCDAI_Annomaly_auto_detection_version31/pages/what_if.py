"""
What-If Simulator — AIM AI Vault (V27)
========================================
#20 Interactive risk score simulator.
    V27: Uses actual trained models from last pipeline run when available.
    Falls back to heuristic scoring when no models are loaded.
    Adjust customer features, recalculate risk in real-time.
    Uses configured method weights + ensemble logic.
    All offline. Zero-network. Air-gapped. Bank-safe.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update, ALL, ctx
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import numpy as np
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP, LAYERS, PATHS

dash.register_page(__name__, path="/what-if", name="What-If Simulator", order=19)

PLOTLY_CFG = APP.PLOTLY_CONFIG

# Method weights from config
WEIGHTS = LAYERS.METHOD_WEIGHTS

# Simulation parameters — the adjustable "features"
SIMULATION_FEATURES = [
    {"id": "txn_volume", "label": "Transaction Volume (daily)", "min": 0, "max": 500, "default": 25, "step": 5},
    {"id": "avg_amount", "label": "Average Transaction Amount ($)", "min": 0, "max": 100000, "default": 2000, "step": 100},
    {"id": "max_amount", "label": "Max Single Transaction ($)", "min": 0, "max": 500000, "default": 10000, "step": 500},
    {"id": "unique_counterparties", "label": "Unique Counterparties", "min": 0, "max": 200, "default": 10, "step": 1},
    {"id": "round_amount_pct", "label": "Round Amount Transactions (%)", "min": 0, "max": 100, "default": 10, "step": 1},
    {"id": "cross_border_pct", "label": "Cross-Border Transactions (%)", "min": 0, "max": 100, "default": 5, "step": 1},
    {"id": "high_risk_country_pct", "label": "High-Risk Jurisdiction (%)", "min": 0, "max": 100, "default": 0, "step": 1},
    {"id": "rapid_movement", "label": "Rapid Fund Movement (bool)", "min": 0, "max": 1, "default": 0, "step": 1},
    {"id": "structuring_flag", "label": "Structuring Pattern (bool)", "min": 0, "max": 1, "default": 0, "step": 1},
    {"id": "dormancy_reactivation", "label": "Dormancy Reactivation (bool)", "min": 0, "max": 1, "default": 0, "step": 1},
]


def _simulate_risk(features: dict) -> dict:
    """
    V27: Simulate ensemble risk score.
    
    Strategy:
    1. Try to load actual trained models from the last pipeline run
       and score the feature vector through them.
    2. Fall back to heuristic scoring if no models are available.
    
    Returns dict with per-method scores and ensemble result.
    """
    # ─── Try actual model inference ───
    model_result = _try_model_inference(features)
    if model_result is not None:
        return model_result
    
    # ─── Fallback: heuristic scoring ───
    return _heuristic_scoring(features)


def _try_model_inference(features: dict):
    """
    V27 C7: Attempt to score through actual trained models.
    
    Loads the last pipeline's L5 detection layer (stored models dict)
    and Pipeline's scaler/reduction state to transform the input vector,
    then scores it through each available model.
    """
    try:
        from services.pipeline_service import PipelineService
        svc = PipelineService()
        pipeline = svc.get_pipeline_instance()
        
        detection = getattr(pipeline, 'detection', None)
        if detection is None or not hasattr(detection, 'models') or not detection.models:
            return None
        
        # Build feature vector from the what-if inputs
        # Map simulation features to the pipeline's feature space
        feature_cols = getattr(pipeline.features, 'feature_columns', None)
        if feature_cols is None or len(feature_cols) == 0:
            return None
        
        # Create a 1-row vector with defaults, then overlay known features
        n_features = len(feature_cols)
        X_vec = np.zeros((1, n_features), dtype=np.float32)
        
        # Map what-if feature names to column indices
        col_index = {col: i for i, col in enumerate(feature_cols)}
        for feat_id, feat_val in features.items():
            # Try direct match or partial match
            if feat_id in col_index:
                X_vec[0, col_index[feat_id]] = float(feat_val)
            else:
                for col_name, idx in col_index.items():
                    if feat_id in col_name.lower() or col_name.lower() in feat_id:
                        X_vec[0, idx] = float(feat_val)
                        break
        
        # Score through each available model
        method_scores = {}
        for method_name, model in detection.models.items():
            try:
                if hasattr(model, 'decision_function'):
                    raw = -model.decision_function(X_vec)[0]
                elif hasattr(model, 'score_samples'):
                    raw = -model.score_samples(X_vec)[0]
                elif hasattr(model, 'predict'):
                    raw = float(model.predict(X_vec)[0])
                else:
                    continue
                # Normalize to 0-1 range using last run's score distribution
                method_scores[method_name] = float(np.clip(raw, 0, 1))
            except Exception:
                continue
        
        if len(method_scores) < 2:
            return None  # Not enough models, fall back to heuristic
        
        # Weighted ensemble
        weighted_sum = 0
        weight_total = 0
        vote_count = 0
        for method, score in method_scores.items():
            w = WEIGHTS.get(method, 1.0)
            weighted_sum += score * w
            weight_total += w
            if score > 0.5:
                vote_count += 1
        
        ensemble_score = weighted_sum / max(weight_total, 1)
        
        # Risk tier
        tiers = LAYERS.RISK_TIERS
        risk_tier = "NORMAL"
        for tier_name in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            if ensemble_score >= tiers[tier_name]["score_min"]:
                risk_tier = tier_name
                break
        
        return {
            "method_scores": method_scores,
            "ensemble_score": round(ensemble_score, 4),
            "vote_count": vote_count,
            "total_methods": len(method_scores),
            "risk_tier": risk_tier,
            "inference_mode": "actual_models",  # V27 badge
        }
    
    except Exception:
        return None


def _heuristic_scoring(features: dict) -> dict:
    """
    Original heuristic scoring (V11 fallback).
    Uses heuristic scoring for each method category.
    """
    method_scores = {}

    # Statistical methods — triggered by volume/amount outliers
    vol = features.get("txn_volume", 25)
    avg = features.get("avg_amount", 2000)
    max_amt = features.get("max_amount", 10000)

    zscore_signal = min(1.0, (vol / 100) * 0.3 + (avg / 50000) * 0.4 + (max_amt / 200000) * 0.3)
    method_scores["zscore"] = np.clip(zscore_signal, 0, 1)
    method_scores["mad"] = np.clip(zscore_signal * 0.9, 0, 1)
    method_scores["grubbs"] = np.clip(zscore_signal * 0.85, 0, 1)

    # Benford: round amounts increase suspicion
    round_pct = features.get("round_amount_pct", 10)
    method_scores["benford"] = np.clip(round_pct / 50, 0, 1)

    # Distance methods — counterparty diversity
    cp = features.get("unique_counterparties", 10)
    dist_signal = min(1.0, cp / 80)
    method_scores["knn"] = np.clip(dist_signal * 0.7, 0, 1)
    method_scores["lof"] = np.clip(dist_signal * 0.8 + (vol / 200) * 0.2, 0, 1)

    # Tree methods — combination signals
    combo_signal = (zscore_signal * 0.4 + dist_signal * 0.3 + round_pct / 100 * 0.3)
    method_scores["isolation_forest"] = np.clip(combo_signal, 0, 1)
    method_scores["extended_if"] = np.clip(combo_signal * 0.95, 0, 1)

    # Graph methods — cross-border + counterparties
    cb_pct = features.get("cross_border_pct", 5)
    hr_pct = features.get("high_risk_country_pct", 0)
    graph_signal = min(1.0, cb_pct / 30 * 0.4 + hr_pct / 20 * 0.4 + cp / 50 * 0.2)
    method_scores["pagerank"] = np.clip(graph_signal, 0, 1)
    method_scores["community"] = np.clip(graph_signal * 0.85, 0, 1)

    # Behavioral flags
    rapid = features.get("rapid_movement", 0)
    struct = features.get("structuring_flag", 0)
    dormancy = features.get("dormancy_reactivation", 0)
    flag_signal = min(1.0, rapid * 0.4 + struct * 0.4 + dormancy * 0.2)
    method_scores["hdbscan"] = np.clip(flag_signal, 0, 1)
    method_scores["dbscan"] = np.clip(flag_signal * 0.9, 0, 1)

    # Deep learning — overall pattern
    overall = (zscore_signal + dist_signal + combo_signal + graph_signal + flag_signal) / 5
    method_scores["autoencoder"] = np.clip(overall * 0.85, 0, 1)
    method_scores["vae"] = np.clip(overall * 0.80, 0, 1)

    # Weighted ensemble
    weighted_sum = 0
    weight_total = 0
    vote_count = 0
    for method, score in method_scores.items():
        w = WEIGHTS.get(method, 1.0)
        weighted_sum += score * w
        weight_total += w
        if score > 0.5:
            vote_count += 1

    ensemble_score = weighted_sum / max(weight_total, 1)

    # Risk tier
    tiers = LAYERS.RISK_TIERS
    risk_tier = "NORMAL"
    for tier_name in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
        if ensemble_score >= tiers[tier_name]["score_min"]:
            risk_tier = tier_name
            break

    return {
        "method_scores": method_scores,
        "ensemble_score": round(ensemble_score, 4),
        "vote_count": vote_count,
        "total_methods": len(method_scores),
        "risk_tier": risk_tier,
        "inference_mode": "heuristic",  # V27: indicates fallback mode
    }


def _build_gauge(score, tier):
    """Create a gauge chart for the ensemble risk score."""
    tier_colors = {"CRITICAL": "#FF5252", "HIGH": "#FF9800",
                   "MEDIUM": "#FFB300", "LOW": "#2196F3", "NORMAL": "#00C853"}

    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=score * 100,
        number=dict(suffix="%", font=dict(size=36)),
        title=dict(text="Ensemble Risk Score", font=dict(size=14, color="#ccc")),
        gauge=dict(
            axis=dict(range=[0, 100], tickwidth=1, tickcolor="#666"),
            bar=dict(color=tier_colors.get(tier, "#888")),
            bgcolor="rgba(0,0,0,0)",
            borderwidth=0,
            steps=[
                dict(range=[0, 50], color="rgba(0,200,83,0.15)"),
                dict(range=[50, 70], color="rgba(255,179,0,0.15)"),
                dict(range=[70, 85], color="rgba(255,152,0,0.15)"),
                dict(range=[85, 95], color="rgba(255,82,82,0.15)"),
                dict(range=[95, 100], color="rgba(255,0,0,0.25)"),
            ],
            threshold=dict(line=dict(color="#FF5252", width=3), thickness=0.8, value=95),
        ),
    ))
    fig.update_layout(
        template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)", height=280,
        margin=dict(l=30, r=30, t=40, b=10),
    )
    return fig


def _build_method_bars(method_scores):
    """Horizontal bar chart of per-method scores."""
    methods = sorted(method_scores.keys(), key=lambda m: method_scores[m], reverse=True)
    scores = [method_scores[m] for m in methods]
    colors = ["#FF5252" if s > 0.85 else "#FF9800" if s > 0.7 else "#FFB300" if s > 0.5
              else "#2196F3" if s > 0.3 else "#00C853" for s in scores]

    fig = go.Figure(go.Bar(
        x=scores, y=methods, orientation="h",
        marker_color=colors,
        text=["{:.0f}%".format(s * 100) for s in scores],
        textposition="auto",
    ))
    fig.update_layout(
        template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=10, r=10, t=40, b=10),
        title="Per-Method Risk Scores",
        height=max(300, len(methods) * 26),
        xaxis=dict(range=[0, 1], title="Score"),
    )
    return fig

try:
    from auth.manager import require_role
except ImportError:
    require_role = lambda *a, **kw: (lambda fn: fn)

@require_role("viewer")
def layout(**kwargs):
    # Default simulation
    default_features = {f["id"]: f["default"] for f in SIMULATION_FEATURES}
    result = _simulate_risk(default_features)

    gauge_fig = _build_gauge(result["ensemble_score"], result["risk_tier"])
    method_fig = _build_method_bars(result["method_scores"])

    sliders = []
    for feat in SIMULATION_FEATURES:
        if feat["max"] == 1:  # Boolean
            sliders.append(
                dmc.Switch(
                    id={"type": "sim-feature", "index": feat["id"]},
                    label=feat["label"],
                    checked=bool(feat["default"]),
                    size="sm",
                    mb="sm",
                )
            )
        else:
            sliders.append(
                html.Div([
                    dmc.Text(feat["label"], size="sm", mb=2),
                    dcc.Slider(
                        id={"type": "sim-feature", "index": feat["id"]},
                        min=feat["min"], max=feat["max"],
                        value=feat["default"], step=feat["step"],
                        marks={feat["min"]: str(feat["min"]),
                               feat["max"]: str(feat["max"])},
                        tooltip={"placement": "bottom", "always_visible": True},
                    ),
                ], style={"marginBottom": "12px"})
            )

    return dmc.Container([
        dmc.Group([
            dmc.Group([
                DashIconify(icon="mdi:tune-vertical-variant", width=28, color="#22b8cf"),
                dmc.Title("What-If Simulator", order=2),
            ], gap="xs"),
            dmc.Badge("Interactive Risk Scoring | Offline", color="cyan", variant="light"),
        ], justify="space-between", mb="lg"),

        dmc.Text("Adjust customer behavior features to see how the ensemble risk score changes "
                 "in real-time. Explores 'what-if' scenarios using configured method weights. "
                 "No data is persisted — purely exploratory.",
                 size="sm", c="dimmed", mb="lg"),

        dmc.Grid([
            # Left: Feature sliders
            dmc.GridCol([
                dmc.Paper([
                    dmc.Group([
                        DashIconify(icon="mdi:sliders", width=22, color="#22b8cf"),
                        dmc.Title("Scenario Parameters", order=4),
                    ], gap="xs", mb="md"),
                    *sliders,
                    dmc.Button("Recalculate", id="btn-simulate", fullWidth=True, mt="md",
                               leftSection=DashIconify(icon="mdi:calculator-variant", width=18)),
                ], p="lg", radius="md", withBorder=True,
                    style={"backgroundColor": THEME.DARK_BG_CARD}),
            ], span=5),

            # Right: Results
            dmc.GridCol([
                dmc.Stack([
                    # Risk tier badge
                    html.Div(id="sim-tier-display", children=[
                        dmc.Group([
                            dmc.Badge(result["risk_tier"], color="red" if result["risk_tier"] == "CRITICAL"
                                      else "orange" if result["risk_tier"] == "HIGH"
                                      else "yellow" if result["risk_tier"] == "MEDIUM"
                                      else "blue" if result["risk_tier"] == "LOW"
                                      else "green", size="xl", variant="filled"),
                            dmc.Text("Votes: {} / {}".format(result["vote_count"], result["total_methods"]),
                                     size="sm", c="dimmed"),
                        ], gap="md"),
                    ]),

                    # Gauge
                    dmc.Paper([
                        dcc.Graph(id="sim-gauge", figure=gauge_fig, config=PLOTLY_CFG),
                    ], p="sm", radius="md", withBorder=True,
                        style={"backgroundColor": THEME.DARK_BG_CARD}),

                    # Method bars
                    dmc.Paper([
                        dcc.Graph(id="sim-method-bars", figure=method_fig, config=PLOTLY_CFG),
                    ], p="sm", radius="md", withBorder=True,
                        style={"backgroundColor": THEME.DARK_BG_CARD}),
                ], gap="md"),
            ], span=7),
        ]),
    ], fluid=True)


# ─── Callback: Recalculate ────────────────────────────────────────────────────
@callback(
    Output("sim-gauge", "figure"),
    Output("sim-method-bars", "figure"),
    Output("sim-tier-display", "children"),
    Input("btn-simulate", "n_clicks"),
    [State({"type": "sim-feature", "index": feat["id"]}, "value" if feat["max"] != 1 else "checked")
     for feat in SIMULATION_FEATURES],
    prevent_initial_call=True,
)
def recalculate_simulation(n_clicks, *values):
    if not n_clicks:
        return no_update, no_update, no_update

    features = {}
    for i, feat in enumerate(SIMULATION_FEATURES):
        val = values[i]
        if feat["max"] == 1:
            features[feat["id"]] = 1 if val else 0
        else:
            features[feat["id"]] = val or feat["default"]

    result = _simulate_risk(features)
    gauge_fig = _build_gauge(result["ensemble_score"], result["risk_tier"])
    method_fig = _build_method_bars(result["method_scores"])

    tier = result["risk_tier"]
    tier_badge = dmc.Group([
        dmc.Badge(tier, color="red" if tier == "CRITICAL"
                  else "orange" if tier == "HIGH"
                  else "yellow" if tier == "MEDIUM"
                  else "blue" if tier == "LOW"
                  else "green", size="xl", variant="filled"),
        dmc.Text("Votes: {} / {}".format(result["vote_count"], result["total_methods"]),
                 size="sm", c="dimmed"),
    ], gap="md")

    return gauge_fig, method_fig, tier_badge
