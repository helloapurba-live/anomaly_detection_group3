"""
Model Drift Monitor — AIM AI Vault (V14)
==========================================
#18 Track detection-score distributions across pipeline runs.
    KS-test, PSI calculation, distribution comparison.
    All offline — zero-network.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import pandas as pd
import numpy as np
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, APP, DRIFT

dash.register_page(__name__, path="/drift", name="Drift Monitor", order=17)

PLOTLY_CFG = APP.PLOTLY_CONFIG


def _get_drift_snapshots():
    """Load drift snapshots from DB."""
    try:
        from database.engine import get_session
        from database.models import DriftSnapshot
        session = get_session()
        snaps = session.query(DriftSnapshot).order_by(DriftSnapshot.created_at.desc()).limit(500).all()
        session.close()
        if not snaps:
            return pd.DataFrame()
        return pd.DataFrame([{
            "run_id": s.run_id, "method_name": s.method_name,
            "n_scores": s.n_scores, "mean_score": s.mean_score,
            "std_score": s.std_score, "median_score": s.median_score,
            "p25": s.p25, "p75": s.p75,
            "histogram_json": s.histogram_json,
            "created_at": s.created_at,
        } for s in snaps])
    except Exception:
        return pd.DataFrame()


def _get_pipeline_runs():
    """Get run IDs for dropdown."""
    try:
        from database.engine import get_session
        from database.models import PipelineRun
        session = get_session()
        runs = session.query(PipelineRun).filter(
            PipelineRun.status == "completed"
        ).order_by(PipelineRun.id.desc()).limit(50).all()
        session.close()
        return [{"value": r.run_id, "label": f"{r.run_id} ({r.completed_at})"} for r in runs]
    except Exception:
        return []


def _calculate_psi(expected, actual, bins=10):
    """Population Stability Index — offline calculation."""
    try:
        expected = np.array(expected, dtype=float)
        actual = np.array(actual, dtype=float)
        if len(expected) < 5 or len(actual) < 5:
            return None

        breakpoints = np.linspace(0, 1, bins + 1)
        exp_perc = np.histogram(expected, bins=breakpoints)[0] / len(expected)
        act_perc = np.histogram(actual, bins=breakpoints)[0] / len(actual)

        # Avoid division by zero
        exp_perc = np.where(exp_perc == 0, 0.001, exp_perc)
        act_perc = np.where(act_perc == 0, 0.001, act_perc)

        psi = np.sum((act_perc - exp_perc) * np.log(act_perc / exp_perc))
        return round(psi, 4)
    except Exception:
        return None


def _ks_statistic(d1, d2):
    """Two-sample Kolmogorov-Smirnov statistic (offline, no scipy)."""
    try:
        d1 = np.sort(np.array(d1, dtype=float))
        d2 = np.sort(np.array(d2, dtype=float))
        all_vals = np.sort(np.concatenate([d1, d2]))
        cdf1 = np.searchsorted(d1, all_vals, side="right") / len(d1)
        cdf2 = np.searchsorted(d2, all_vals, side="right") / len(d2)
        return round(float(np.max(np.abs(cdf1 - cdf2))), 4)
    except Exception:
        return None


def _compute_run_scores(run_id):
    """Extract anomaly scores for a specific run."""
    try:
        from database.engine import get_session
        from database.models import Anomaly
        session = get_session()
        anomalies = session.query(Anomaly.anomaly_score).filter(
            Anomaly.run_id == run_id
        ).all()
        session.close()
        return [a[0] for a in anomalies if a[0] is not None]
    except Exception:
        return []

try:
    from auth.manager import require_role
except ImportError:
    require_role = lambda *a, **kw: (lambda fn: fn)

@require_role("viewer")
def layout(**kwargs):
    snap_df = _get_drift_snapshots()
    runs = _get_pipeline_runs()

    # Summary stats
    n_snapshots = len(snap_df)
    n_methods = snap_df["method_name"].nunique() if not snap_df.empty else 0
    n_runs = snap_df["run_id"].nunique() if not snap_df.empty else 0

    # Mean-score over time chart (per method)
    mean_fig = go.Figure()
    if not snap_df.empty:
        for method in snap_df["method_name"].unique()[:8]:
            method_df = snap_df[snap_df["method_name"] == method].sort_values("created_at")
            mean_fig.add_trace(go.Scatter(
                x=method_df["created_at"], y=method_df["mean_score"],
                mode="lines+markers", name=method, marker=dict(size=6),
            ))
    mean_fig.update_layout(
        template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)", margin=dict(l=10, r=10, t=40, b=10),
        title="Mean Score Trend by Method", height=350,
        xaxis_title="Run Date", yaxis_title="Mean Score",
        legend=dict(orientation="h", yanchor="bottom", y=1.02),
    )

    # Std deviation trend
    std_fig = go.Figure()
    if not snap_df.empty:
        for method in snap_df["method_name"].unique()[:8]:
            method_df = snap_df[snap_df["method_name"] == method].sort_values("created_at")
            std_fig.add_trace(go.Scatter(
                x=method_df["created_at"], y=method_df["std_score"],
                mode="lines+markers", name=method, marker=dict(size=6),
            ))
    std_fig.update_layout(
        template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)", margin=dict(l=10, r=10, t=40, b=10),
        title="Score Std Deviation Trend (Volatility)", height=350,
        xaxis_title="Run Date", yaxis_title="Std Dev",
        legend=dict(orientation="h", yanchor="bottom", y=1.02),
    )

    return dmc.Container([
        dmc.Group([
            dmc.Group([
                DashIconify(icon="mdi:chart-bell-curve", width=28, color="#22b8cf"),
                dmc.Title("Model Drift Monitor", order=2),
            ], gap="xs"),
            dmc.Badge("Score Distribution Tracking | Offline", color="cyan", variant="light"),
        ], justify="space-between", mb="lg"),

        dmc.Text("Track how detection score distributions evolve across pipeline runs. "
                 "Detects model drift using KS-test and PSI metrics. "
                 "Requires ≥ {} completed runs for meaningful comparison.".format(DRIFT.MIN_RUNS_FOR_DRIFT),
                 size="sm", c="dimmed", mb="lg"),

        # KPI cards
        dmc.SimpleGrid(cols={"base": 1, "md": 3}, spacing="md", mb="lg", children=[
            dmc.Card([
                dmc.Group([
                    DashIconify(icon="mdi:database-clock", width=24, color="#22b8cf"),
                    dmc.Stack([
                        dmc.Text("Snapshots", size="xs", c="dimmed"),
                        dmc.Text(str(n_snapshots), size="xl", fw=700),
                    ], gap=0),
                ]),
            ], withBorder=True, p="md", radius="md",
                style={"backgroundColor": THEME.DARK_BG_CARD}),
            dmc.Card([
                dmc.Group([
                    DashIconify(icon="mdi:function-variant", width=24, color="#22b8cf"),
                    dmc.Stack([
                        dmc.Text("Methods Tracked", size="xs", c="dimmed"),
                        dmc.Text(str(n_methods), size="xl", fw=700),
                    ], gap=0),
                ]),
            ], withBorder=True, p="md", radius="md",
                style={"backgroundColor": THEME.DARK_BG_CARD}),
            dmc.Card([
                dmc.Group([
                    DashIconify(icon="mdi:chart-timeline-variant", width=24, color="#22b8cf"),
                    dmc.Stack([
                        dmc.Text("Runs Compared", size="xs", c="dimmed"),
                        dmc.Text(str(n_runs), size="xl", fw=700),
                    ], gap=0),
                ]),
            ], withBorder=True, p="md", radius="md",
                style={"backgroundColor": THEME.DARK_BG_CARD}),
        ]),

        # Drift comparison tool
        dmc.Paper([
            dmc.Title("PSI / KS-Test Comparison", order=4, mb="md"),
            dmc.SimpleGrid(cols={"base": 1, "md": 2}, spacing="md", children=[
                dmc.Select(id="drift-run-a", label="Baseline Run",
                           data=runs, placeholder="Select baseline run...", size="sm"),
                dmc.Select(id="drift-run-b", label="Current Run",
                           data=runs, placeholder="Select current run...", size="sm"),
            ]),
            dmc.Button("Calculate Drift", id="btn-calc-drift", mt="md",
                       leftSection=DashIconify(icon="mdi:chart-bell-curve-cumulative", width=18)),
            html.Div(id="drift-results", style={"marginTop": "16px"}),
        ], p="lg", radius="md", withBorder=True, mb="lg",
            style={"backgroundColor": THEME.DARK_BG_CARD}),

        # Charts
        dmc.SimpleGrid(cols={"base": 1, "lg": 2}, spacing="lg", children=[
            dmc.Paper([
                dcc.Graph(figure=mean_fig, config=PLOTLY_CFG),
            ], p="md", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD}),
            dmc.Paper([
                dcc.Graph(figure=std_fig, config=PLOTLY_CFG),
            ], p="md", radius="md", withBorder=True,
                style={"backgroundColor": THEME.DARK_BG_CARD}),
        ]),
    ], fluid=True)


# ─── Callback: Calculate drift ───────────────────────────────────────────────
@callback(
    Output("drift-results", "children"),
    Input("btn-calc-drift", "n_clicks"),
    State("drift-run-a", "value"),
    State("drift-run-b", "value"),
    prevent_initial_call=True,
)
def calculate_drift(n_clicks, run_a, run_b):
    if not n_clicks or not run_a or not run_b:
        return dmc.Alert("Select both baseline and current runs.", color="yellow")

    scores_a = _compute_run_scores(run_a)
    scores_b = _compute_run_scores(run_b)

    if len(scores_a) < 5 or len(scores_b) < 5:
        return dmc.Alert("Insufficient scores in one or both runs (need ≥ 5).", color="orange")

    psi_val = _calculate_psi(scores_a, scores_b)
    ks_val = _ks_statistic(scores_a, scores_b)

    psi_status = "Stable"
    psi_color = "green"
    if psi_val and psi_val > DRIFT.PSI_THRESHOLD:
        psi_status = "DRIFT DETECTED"
        psi_color = "red"
    elif psi_val and psi_val > DRIFT.PSI_THRESHOLD * 0.5:
        psi_status = "Warning"
        psi_color = "yellow"

    ks_status = "Stable"
    ks_color = "green"
    if ks_val and ks_val > 0.3:
        ks_status = "DRIFT DETECTED"
        ks_color = "red"
    elif ks_val and ks_val > 0.15:
        ks_status = "Warning"
        ks_color = "yellow"

    return dmc.Stack([
        dmc.SimpleGrid(cols=2, spacing="md", children=[
            dmc.Card([
                dmc.Text("PSI (Population Stability Index)", size="xs", c="dimmed"),
                dmc.Text(str(psi_val) if psi_val else "N/A", size="xl", fw=700),
                dmc.Badge(psi_status, color=psi_color, variant="light", mt="xs"),
                dmc.Text("Threshold: {:.2f}".format(DRIFT.PSI_THRESHOLD),
                         size="xs", c="dimmed", mt="xs"),
            ], withBorder=True, p="md", radius="md",
                style={"backgroundColor": THEME.DARK_BG_CARD}),
            dmc.Card([
                dmc.Text("KS Statistic", size="xs", c="dimmed"),
                dmc.Text(str(ks_val) if ks_val else "N/A", size="xl", fw=700),
                dmc.Badge(ks_status, color=ks_color, variant="light", mt="xs"),
                dmc.Text("Alpha: {:.2f}".format(DRIFT.KS_TEST_ALPHA),
                         size="xs", c="dimmed", mt="xs"),
            ], withBorder=True, p="md", radius="md",
                style={"backgroundColor": THEME.DARK_BG_CARD}),
        ]),
        dmc.Text("Baseline: {} ({} scores) vs Current: {} ({} scores)".format(
            run_a, len(scores_a), run_b, len(scores_b)),
            size="sm", c="dimmed"),
    ])
