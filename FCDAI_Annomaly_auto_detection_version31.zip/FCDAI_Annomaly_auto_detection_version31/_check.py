import sys, os, traceback
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.getcwd())
out = []
try:
    out.append("1-OK")
    from config import APP
    out.append(f"2-PORT={APP.PORT}")
    from app import app, server
    out.append("3-APP-OK")
except Exception:
    out.append(f"ERR={traceback.format_exc()[-500:]}")
with open("_check.txt", "w") as f:
    f.write("\n".join(out))
