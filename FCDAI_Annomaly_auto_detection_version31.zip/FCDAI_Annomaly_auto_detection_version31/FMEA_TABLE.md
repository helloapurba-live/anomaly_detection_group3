# Project ApurbaDas V9 — FMEA Table
## Failure Mode and Effects Analysis for Unsupervised AML Detection System

> **Standard**: Adapted from IEC 60812 / AIAG FMEA 4th Edition  
> **Scope**: 7-Layer Pipeline, 26 Detection Methods, Ensemble Fusion, Data I/O  
> **Risk Priority Number (RPN)** = Severity × Occurrence × Detection (1-10 each, max 1000)

---

## RPN Severity Scale (AML Context)

| Score | Severity | Description |
|-------|----------|-------------|
| 10 | Catastrophic | Missed CRITICAL-tier money laundering; regulatory penalty |
| 9 | Very High | Systematic false negatives across an entire detection family |
| 8 | High | PII data leak; audit trail corruption |
| 7 | Significant | Investigation queue invalid; wrong risk tier assignment |
| 6 | Moderate | Ensemble score miscalculation; 10-20% accuracy drop |
| 5 | Low-Moderate | UI shows stale data; minor feature engineering error |
| 4 | Low | Performance degradation; slow pipeline run |
| 3 | Minor | Cosmetic UI error; non-critical config mismatch |
| 2 | Very Minor | Warning message missing; log formatting issue |
| 1 | None | No user-visible impact |

---

## FMEA Table

| ID | Component | Failure Mode | Effect on System | Cause | SEV | OCC | DET | RPN | Current Control | Recommended Action |
|----|-----------|-------------|------------------|-------|-----|-----|-----|-----|----------------|-------------------|
| **FM-001** | L5 Detection (All 26) | **Static thresholds fail on shifted distributions** | Z-Score, IQR, Grubbs flag ALL records as anomalous (or none) when data distribution changes significantly | Fixed thresholds (z=3.0, IQR×1.5) do not adapt to per-dataset statistics beyond mean/std | 9 | 5 | 3 | **135** | Percentile-rank normalization in L6 ensemble partially mitigates individual method bias | Add adaptive threshold option: compute data-driven thresholds per-run using robust statistics (MAD, trimmed mean) |
| **FM-002** | L6 Ensemble | **Concordance weights collapse to uniform** | All methods weighted equally → loss of domain-expert weighting | When all methods produce identical rankings, concordance correlation → 1.0 for all, normalizing to uniform | 6 | 3 | 4 | **72** | METHOD_WEIGHTS in config.py can override concordance | Blend concordance weights with config prior: `w = α·concordance + (1-α)·config` |
| **FM-003** | L6 Ensemble | **Risk tier boundary mis-assignment** | Record at exact score_min boundary gets wrong tier due to floating-point comparison | `>=` comparison with float scores near threshold boundary (e.g., 0.9499999 vs 0.95) | 7 | 4 | 5 | **140** | Config uses OR logic (score OR votes) as safety net | Add ε tolerance to tier boundaries; round scores to 4 decimal places before comparison |
| **FM-004** | L5 / Autoencoder+VAE | **Neural net trains on corrupted data (80%+ nulls)** | MSE-based scores dominated by imputed-median values, not true patterns | L4 uses `SimpleImputer(strategy='median')` — if 80% of feature is null, reconstruction error reflects median, not anomaly | 8 | 3 | 4 | **96** | L4 imputes nulls; SchemaDetector profiles columns before processing | Add column-level null threshold (e.g., >50% null → drop column from neural net input) |
| **FM-005** | L1-L2 Ingestion | **Data source join produces Cartesian product** | Merged dataframe explodes to N×M rows, crashing pipeline or corrupting scores | Two tables share a non-unique join key (e.g., transaction_date); LEFT JOIN creates duplicates | 8 | 4 | 3 | **96** | `auto_discover_and_join` detects join keys | Add post-join row-count check: if merged_rows > 2× master_rows, raise warning and abort join |
| **FM-006** | PII Masking | **PII exposed in export/storage** | Customer PII visible in scorecard exports or on-disk parquet files | `PIIConfig.ENABLED_BY_DEFAULT = False`; developer forgets to enable | 10 | 4 | 6 | **240** | `MASK_AT_STORAGE` and `MASK_IN_EXPORTS` flags exist but depend on `ENABLED_BY_DEFAULT` | **Change `ENABLED_BY_DEFAULT` to `True`**; add startup assertion that PII masking is enabled |
| **FM-007** | Audit Logger | **Hash chain resets on app restart** | New log entries have fresh genesis hash → tamper detection breaks across restarts | `_prev_hash = "GENESIS"` is class-level static; not persisted to disk | 8 | 8 | 2 | **128** | Hash is appended to every log line; rotating file handler preserves old entries | Persist `_prev_hash` to disk (e.g., `logs/.hash_state`); reload on startup |
| **FM-008** | Data Vault | **In-memory unmasked PII survives process lifecycle** | `_sources` dict keeps original unmasked DataFrames; memory dump exposes PII | `save_sources()` masks for disk but stores unmasked in `self._sources` for performance | 7 | 6 | 3 | **126** | Parquet on disk is masked when `MASK_AT_STORAGE=True` | Mask in-memory copies too, or use copy-on-read pattern that masks on access |
| **FM-009** | dcc.Upload | **Malicious file upload causes DoS** | Oversized file (>1GB) exhausts memory during base64 decode | No `max_size` limit on `dcc.Upload` component; `base64.b64decode` loads entire file to memory | 7 | 3 | 4 | **84** | `_validate_data()` rejects empty/all-null DataFrames | Add `max_size` prop to `dcc.Upload` (e.g., 100MB); reject before decode |
| **FM-010** | dcc.Upload / Export | **CSV formula injection** | Exported CSV contains cells starting with `=`, `+`, `-`, `@` → Excel executes as formula | Data values or column names may start with formula characters; CSV export uses `to_csv()` without sanitization | 6 | 3 | 5 | **90** | PII masking replaces some values | Prefix cells starting with `=+@-` with `'` character; or export as XLSX only |
| **FM-011** | Pipeline (L5) | **Heavy method timeout on large dataset** | Pipeline appears hung; user kills process; partial results lost | LOF/HDBSCAN/SpectralDetector on >10K rows can take minutes; no per-method timeout | 5 | 4 | 3 | **60** | Smart algorithm selection disables HEAVY_METHODS for >5000 rows | Add per-method timeout (e.g., 60s); kill and log timeout gracefully |
| **FM-012** | Pipeline Status | **Status file stale after crash** | Dashboard shows "Running" forever if pipeline crashes without writing final status | `pipeline_status.json` only updated at each layer start; crash leaves last stage as "running" | 5 | 3 | 4 | **60** | Dashboard can poll and infer from file mtime | Add watchdog: if status file mtime > 5 minutes and status="running", mark as "failed (timeout)" |
| **FM-013** | L3 Feature Engineering | **Column resolver picks wrong column** | `_identify_column()` partial match picks `"country_code"` for alias `"id"` → wrong features | Partial match is greedy: `"id" in "country_code"` = False, but `"id" in "cust_id"` = True. Edge cases exist for short alias strings | 6 | 3 | 5 | **90** | 3-step resolution: strict → aliases → partial match | Add word-boundary matching for partial: require `_id` or `id_` pattern, not substring |
| **FM-014** | Explainability | **Permutation importance is slow and approximate** | Explanation takes O(n_features × n_samples × {model eval}) — can be minutes for large datasets | Custom `_permutation_importance()` iterates samples × features × 100 permutations | 4 | 5 | 2 | **40** | `n_samples=100` limits iterations | Consider SHAP TreeExplainer for IsolationForest (exact, fast); keep permutation as fallback |
| **FM-015** | L6 Ensemble | **CONTAMINATION_RATE=0.05 is hardcoded** | Fixed 5% contamination may under-flag (high-activity laundering) or over-flag (clean portfolio) | Single global config value; not data-driven or user-adjustable per-run | 6 | 5 | 6 | **180** | Config panel page exists but contamination is not exposed | Add contamination slider to Pipeline Run page; persist per-run in run manifest |
| **FM-016** | Data Vault | **Cross-page sync race condition** | Dashboard reads vault while pipeline_run writes → partial data read → corrupt chart | `data_vault` is a singleton; no file locking on Parquet reads/writes | 5 | 3 | 5 | **75** | `reload_from_disk()` re-reads everything atomically | Add file lock (e.g., `fcntl` or portalocker) on vault reads/writes; or use write-then-rename atomic pattern |
| **FM-017** | AG Grid | **Large preview freezes browser** | 500-row × 100-column AG Grid causes browser lag/crash | `MAX_AG_GRID_PREVIEW=500` rows but no column limit | 4 | 3 | 3 | **36** | Pagination enabled (page_size=20) | Add column limit for preview (e.g., first 30 columns); full export for all |
| **FM-018** | app.py | **suppress_callback_exceptions hides bugs** | Broken callbacks silently return `no_update` → UI components never update → user sees stale data | `suppress_callback_exceptions=True` required for multi-page but swallows all callback errors | 6 | 6 | 2 | **72** | Required for multi-page Dash | Add callback error boundary: log all callback exceptions even when suppressed; add client-side error indicator |
| **FM-019** | L5 / Graph Detectors | **k-NN graph is O(N²) memory** | `_build_knn_graph` creates dense N×N similarity matrix even though only k entries per row are non-zero | After k-NN lookup (O(N·k·logN)), result is densified into `np.zeros((n, n))` | 4 | 4 | 3 | **48** | Only built when graph methods are requested | Use `scipy.sparse.csr_matrix` instead of dense matrix; reduces memory from O(N²) to O(N·k) |
| **FM-020** | L5 / VAE | **KL divergence not used in training loss backprop** | VAE training only backprops reconstruction loss; KL term only used in prediction scoring | The `fit()` method comments show `# Loss gradients (reconstruction + KL)` but only `recon_grad` is computed | 6 | 8 | 3 | **144** | VAE prediction combines 0.7×recon + 0.3×KL for scoring | Add KL gradient to training: `∂KL/∂μ = μ`, `∂KL/∂logvar = 0.5(exp(logvar) - 1)`; backprop through encoder |

---

## RPN Priority Matrix

| Priority | RPN Range | Count | Action Required |
|----------|-----------|-------|-----------------|
| **CRITICAL** | ≥ 150 | 3 | FM-006 (240), FM-015 (180), FM-001 (135) — Immediate remediation |
| **HIGH** | 100-149 | 4 | FM-020 (144), FM-003 (140), FM-007 (128), FM-008 (126) — Plan fix within sprint |
| **MEDIUM** | 50-99 | 5 | FM-004 (96), FM-005 (96), FM-010 (90), FM-013 (90), FM-009 (84) — Schedule for next release |
| **LOW** | < 50 | 8 | FM-002 (72), FM-018 (72), FM-016 (75), FM-011 (60), FM-012 (60), FM-019 (48), FM-014 (40), FM-017 (36) — Monitor/backlog |

---

## Top 5 Actions by Risk (Descending RPN)

1. **FM-006 (RPN 240)**: Enable PII masking by default — change `ENABLED_BY_DEFAULT = True` in config.py
2. **FM-015 (RPN 180)**: Expose contamination rate in Pipeline Run UI — add slider + persist to run manifest
3. **FM-020 (RPN 144)**: Fix VAE training to include KL divergence in backpropagation
4. **FM-003 (RPN 140)**: Add ε-tolerance to risk tier boundaries to prevent floating-point edge cases
5. **FM-001 (RPN 135)**: Add adaptive threshold option alongside static thresholds for distribution-shift resilience

---

## Traceability Matrix: FMEA → VAT Checklist → Test

| FMEA ID | VAT Checklist Section | pytest Test |
|---------|-----------------------|-------------|
| FM-001 | 2.2.1, 2.3.6 | `test_contamination_rate_monotonic` |
| FM-003 | 2.3.4 | `test_risk_tier_boundary` |
| FM-004 | 2.2.4 | (manual: run pipeline with 80% nulls) |
| FM-005 | 1.5.3 | (manual: upload two tables with same key) |
| FM-006 | 4.1.1 | `test_pii_default_config`, `test_pii_mask_dataframe` |
| FM-007 | 4.3.3 | `test_hash_chain_logging` |
| FM-009 | 4.2.3 | (manual: upload oversized file) |
| FM-010 | 4.2.4 | (manual: upload CSV with `=CMD` cells) |
| FM-014 | 2.4.1 | (manual: check explanation latency) |
| FM-015 | 2.3.2 | `test_contamination_rate_monotonic` |
| FM-018 | 1.3.2 | `test_suppress_callback_exceptions_flag` |
| FM-019 | 3.3.3 | `test_knn_graph_builds` |
| FM-020 | 2.1.2 | `test_isolation_forest_detects_outliers` (VAE needs dedicated test) |
