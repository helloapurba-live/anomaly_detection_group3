# Security Policy

> **Classification: INTERNAL — Bank AML Investigation Team Only**

---

## Supported Versions

| Version | Supported |
|---------|-----------|
| 15.x    | Yes (current) |
| 14.x    | Security patches only |
| < 14.0  | No |

---

## Reporting a Vulnerability

**Do NOT create a public issue for security vulnerabilities.**

1. Report security issues directly to the AML Technology team lead
2. Include: description, reproduction steps, impact assessment, suggested fix
3. Expected response time: 1 business day
4. Critical vulnerabilities will be patched within 24 hours

---

## Security Architecture

### Air-Gap Enforcement

- **Zero external network calls** — No CDN, no telemetry, no cloud phoning
- `PLOTLY_RENDERER` set to suppress external calls
- All assets served locally (`SERVE_LOCALLY = True`)
- No package auto-update checks
- CORS disabled on API (no cross-origin requests)
- TrustedHostMiddleware: localhost/127.0.0.1 only

### Authentication

#### Dashboard (Flask-Login)
- Session-based authentication with secure cookies
- `HttpOnly`, `SameSite=Lax` cookie flags
- Password hashing: passlib scrypt (never plaintext)
- Session timeout: configurable (default 30 min)
- Failed login rate limiting

#### REST API
- **JWT Tokens**: HMAC-SHA256 signed, configurable expiry (default 60 min)
- **API Keys**: SHA-256 hashed in SQLite (plaintext shown once at creation)
- Token revocation via in-memory blacklist (JWT) and DB flag (API Key)
- No third-party JWT libraries — stdlib only (hmac, hashlib, base64)

### Authorization (RBAC)

| Role | Dashboard | API | Description |
|------|-----------|-----|-------------|
| Admin | Full access | Full access + key management | System administration |
| Investigator | Analysis + alerts | Read scored data, alerts, entity detail | Case investigation |
| Viewer | Read-only dashboard | Health + risk tiers only | Oversight / audit |

### PII Protection

| Layer | Mechanism |
|-------|-----------|
| At rest | Fernet symmetric encryption (AES-128-CBC) |
| In transit (API) | Role-based auto-masking in all responses |
| In logs | PII fields detected and redacted before logging |
| In errors | Generic error messages — never leak PII in stack traces |

**API PII Masking by Role:**
- **Admin**: SHA-256 hash of original value
- **Investigator**: Partial mask (first/last char visible)
- **Viewer**: Full redaction (`[REDACTED]`)

### Audit Trail

- Every dashboard action and API call logged
- Hash-chain integrity (SHA-256 chain linking each entry)
- Tamper detection via `/api/v1/audit/verify` endpoint
- Fields: timestamp, action, username, client IP, request ID, duration

### Data Protection

- No data upload via API (PII safety — upload via dashboard UI only)
- Database: SQLite WAL mode with filesystem permissions
- Encryption key: derived from `VAULT_SECRET_KEY` environment variable
- Data directory excluded from version control (.gitignore)
- No data caching in API responses (served fresh each request)

### Rate Limiting

- Sliding window algorithm (not fixed window)
- Default: 100 requests per minute per IP
- Configurable via `config.toml` → `[api] rate_limit_per_minute`
- Returns HTTP 429 with retry guidance on limit exceed

---

## Configuration Security

- **config.toml** is `.gitignored` — never committed to VCS
- **config.toml.example** provides template without secrets
- Secrets should be set via environment variables:
  - `VAULT_SECRET_KEY` — Dashboard encryption key
  - Or in `config.toml` → `[api] jwt_secret`
- Default JWT secret is randomly generated at startup (non-persistent)

---

## Compliance

This system is designed to support compliance with:

- **BSA** (Bank Secrecy Act)
- **USA PATRIOT Act** (Section 314/326)
- **FinCEN** SAR/CTR filing requirements
- **GDPR** data minimization principles
- **SOX** audit trail requirements
- **PCI DSS** data protection standards

See [docs/COMPLIANCE.md](docs/COMPLIANCE.md) for detailed compliance guidance.

---

## Dependencies

All dependencies use permissive licenses (BSD/MIT/Apache 2.0).  
No GPL or copyleft dependencies.  
Dependency audit should be performed quarterly via `pip audit`.

---

*Last updated: V15.0.0*
