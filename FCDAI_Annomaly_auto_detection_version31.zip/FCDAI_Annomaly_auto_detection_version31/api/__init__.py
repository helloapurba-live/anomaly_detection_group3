"""
AIM AI Vault V15 — REST API Package
=====================================
FastAPI-based programmatic interface for the 7-layer AML pipeline.
Runs alongside Dash on a separate port for machine-to-machine integration.

Endpoints:
  /api/v1/pipeline/*     — Run pipeline, check status, list history
  /api/v1/results/*      — Scored data, alerts, risk tiers, entity lookup
  /api/v1/data/*         — List loaded data sources
  /api/v1/audit/*        — Audit trail, hash-chain verification
  /api/v1/system/*       — Health, metrics, circuit breaker status
  /api/v1/auth/*         — JWT token issuance, API key auth

Security:
  - JWT (HMAC-SHA256) + API Key dual authentication
  - RBAC enforcement (admin / investigator / viewer)
  - PII auto-masking in all responses
  - Rate limiting per client
  - Full request/response audit logging
  - Air-gapped: zero external network calls

Author: AIM AI Vault Team
"""

__version__ = "15.0.0"
