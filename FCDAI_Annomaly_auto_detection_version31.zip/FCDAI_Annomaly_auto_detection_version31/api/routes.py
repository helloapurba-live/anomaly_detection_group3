"""
AIM AI Vault V17 — API Routes
================================
14 RESTful endpoints for machine-to-machine integration.

V17 E2: mask_for_api() applied to DataFrames before dict conversion.

All endpoints:
  - Require JWT or API Key authentication (except POST /auth/token)
  - Enforce RBAC based on user role
  - Auto-mask PII fields in responses (V17: DataFrame-level + dict-level)
  - Rate-limited per client
  - Audit-logged with hash-chain

Author: AIM AI Vault Team
"""

from __future__ import annotations

import sys
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request

sys.path.insert(0, str(Path(__file__).parent.parent))

from api.auth import (
    authenticate_request,
    create_jwt,
    generate_api_key,
    list_api_keys,
    revoke_api_key,
    revoke_jwt,
    verify_jwt,
)
from api.middleware import (
    audit_api_request,
    check_permission,
    generate_request_id,
    mask_pii_in_dict,
    rate_limiter,
)
from api.schemas import (
    APIKeyCreate,
    APIKeyResponse,
    APIResponse,
    AuditLogEntry,
    CircuitBreakerStatus,
    DataSourceInfo,
    EntityDetail,
    HashChainVerification,
    HealthResponse,
    PaginatedResponse,
    PipelineHistoryItem,
    PipelineRunRequest,
    PipelineRunResponse,
    PipelineStatus,
    PipelineStatusResponse,
    RiskTier,
    RiskTierSummary,
    ScoredEntity,
    SystemMetrics,
    TokenRequest,
    TokenResponse,
)

router = APIRouter(prefix="/api/v1")


# =============================================================================
# DEPENDENCY: Auth + Rate Limit + Audit
# =============================================================================
async def get_current_user(
    request: Request,
    authorization: str = Header(default=""),
    x_api_key: str = Header(default="", alias="X-API-Key"),
) -> dict:
    """Authenticate the request and return user info."""
    # Rate limit check
    client_ip = request.client.host if request.client else "unknown"
    if not rate_limiter.check(client_ip):
        raise HTTPException(
            status_code=429,
            detail="Rate limit exceeded. Please wait before retrying.",
        )

    user = authenticate_request(authorization, x_api_key)
    if user is None:
        raise HTTPException(
            status_code=401,
            detail="Invalid or missing authentication. Provide Bearer token or X-API-Key header.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    user["client_ip"] = client_ip
    return user


def require_permission(permission: str):
    """Create a dependency that checks a specific permission."""
    async def checker(user: dict = Depends(get_current_user)):
        if not check_permission(user["role"], permission):
            raise HTTPException(
                status_code=403,
                detail=f"Insufficient permissions. Required: {permission}",
            )
        return user
    return checker


# =============================================================================
# AUTH ENDPOINTS
# =============================================================================
@router.post("/auth/token", response_model=TokenResponse, tags=["Authentication"])
async def issue_token(body: TokenRequest, request: Request):
    """
    Authenticate with username/password and receive a JWT token.
    This is the ONLY endpoint that does not require prior authentication.
    """
    request_id = generate_request_id()
    client_ip = request.client.host if request.client else "unknown"

    try:
        from auth.manager import authenticate
        user = authenticate(body.username, body.password)
        if user is None:
            audit_api_request("POST", "/auth/token", body.username, "none",
                              client_ip, 401, request_id, error="Auth failed")
            raise HTTPException(status_code=401, detail="Invalid credentials")

        token, expires_in = create_jwt(user.username, user.role)
        audit_api_request("POST", "/auth/token", user.username, user.role,
                          client_ip, 200, request_id)

        return TokenResponse(
            access_token=token,
            expires_in=expires_in,
            role=user.role,
        )
    except HTTPException:
        raise
    except Exception as e:
        audit_api_request("POST", "/auth/token", body.username, "none",
                          client_ip, 500, request_id, error=str(e)[:100])
        raise HTTPException(status_code=500, detail="Authentication service error")


@router.delete("/auth/revoke", tags=["Authentication"])
async def revoke_token(
    authorization: str = Header(default=""),
    user: dict = Depends(require_permission("auth:revoke")),
):
    """Revoke the current JWT token (blacklist it)."""
    if authorization.startswith("Bearer "):
        token = authorization[7:]
        success = revoke_jwt(token)
        return APIResponse(success=success, data={"revoked": success})
    return APIResponse(success=False, error="No bearer token to revoke")


@router.get("/auth/keys", tags=["Authentication"])
async def get_api_keys(user: dict = Depends(require_permission("auth:keys_list"))):
    """List all API keys (admin only). Shows hashes, not plaintext."""
    keys = list_api_keys()
    return APIResponse(data=keys)


@router.post("/auth/keys", response_model=APIResponse, tags=["Authentication"])
async def create_api_key_endpoint(
    body: APIKeyCreate,
    user: dict = Depends(require_permission("auth:keys_create")),
):
    """Create a new API key (admin only). Key shown ONCE in response."""
    plaintext, key_hash = generate_api_key(body.label, body.role.value, body.expires_days or 90)
    return APIResponse(data=APIKeyResponse(
        key=plaintext,
        label=body.label,
        role=body.role,
        expires_at=datetime.now(),
    ))


# =============================================================================
# PIPELINE ENDPOINTS
# =============================================================================
@router.post("/pipeline/run", response_model=PipelineRunResponse, tags=["Pipeline"])
async def run_pipeline(
    body: PipelineRunRequest = PipelineRunRequest(),
    user: dict = Depends(require_permission("pipeline:run")),
):
    """
    Start a new pipeline execution.
    Runs all 7 layers (L1-L7) with optional method subset.
    Returns a run_id for status tracking.
    """
    request_id = generate_request_id()
    run_id = str(uuid.uuid4())

    try:
        from services.pipeline_service import PipelineService
        svc = PipelineService()

        # Queue the pipeline (runs synchronously in this version)
        import threading
        def _run():
            try:
                svc.execute_pipeline(
                    run_id=run_id,
                    user=user["username"],
                    description=body.description,
                )
            except Exception:
                pass

        t = threading.Thread(target=_run, daemon=True)
        t.start()

        audit_api_request("POST", "/pipeline/run", user["username"], user["role"],
                          user.get("client_ip", ""), 202, request_id)

        return PipelineRunResponse(
            run_id=run_id,
            status=PipelineStatus.PENDING,
            message="Pipeline queued for execution",
            started_at=datetime.now(),
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Pipeline start failed: {type(e).__name__}")


@router.get("/pipeline/status/{run_id}", response_model=APIResponse, tags=["Pipeline"])
async def get_pipeline_status(
    run_id: str,
    user: dict = Depends(require_permission("pipeline:status")),
):
    """Get the current status of a specific pipeline run."""
    try:
        from utils.data_io import DataVault
        vault = DataVault()
        run_ids = vault.list_run_ids() if hasattr(vault, "list_run_ids") else []

        if run_id in run_ids:
            return APIResponse(data=PipelineStatusResponse(
                run_id=run_id,
                status=PipelineStatus.COMPLETED,
            ))

        # Check if pipeline is currently running
        result = vault.load_pipeline_result()
        if result and hasattr(result, "get"):
            return APIResponse(data={"run_id": run_id, "status": "UNKNOWN"})

        return APIResponse(data={"run_id": run_id, "status": "NOT_FOUND"})
    except Exception:
        return APIResponse(data={"run_id": run_id, "status": "UNKNOWN"})


@router.get("/pipeline/history", response_model=APIResponse, tags=["Pipeline"])
async def get_pipeline_history(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    user: dict = Depends(require_permission("pipeline:history")),
):
    """List all past pipeline runs with summary stats."""
    try:
        from utils.data_io import DataVault
        vault = DataVault()
        run_ids = vault.list_run_ids() if hasattr(vault, "list_run_ids") else []

        # Paginate
        total = len(run_ids)
        start = (page - 1) * page_size
        page_ids = run_ids[start:start + page_size]

        items = [
            PipelineHistoryItem(
                run_id=rid,
                status=PipelineStatus.COMPLETED,
                started_at=datetime.now(),
            )
            for rid in page_ids
        ]

        return APIResponse(data=PaginatedResponse(
            items=items,
            total=total,
            page=page,
            page_size=page_size,
            has_more=(start + page_size) < total,
        ))
    except Exception:
        return APIResponse(data=PaginatedResponse(items=[], total=0))


# =============================================================================
# RESULTS ENDPOINTS
# =============================================================================
@router.get("/results/scored/{run_id}", response_model=APIResponse, tags=["Results"])
async def get_scored_data(
    run_id: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=500),
    min_score: float = Query(0.0, ge=0.0, le=1.0),
    tier: Optional[RiskTier] = Query(None),
    user: dict = Depends(require_permission("results:scored")),
):
    """
    Get scored entities for a specific pipeline run.
    PII fields are automatically masked based on your role.
    """
    try:
        from utils.data_io import DataVault
        vault = DataVault()

        df = vault.load_run_scored(run_id) if hasattr(vault, "load_run_scored") else None
        if df is None:
            df = vault.get_scored_data()
        if df is None or df.empty:
            return APIResponse(data=PaginatedResponse(items=[], total=0))

        # Filter
        if "anomaly_score" in df.columns:
            df = df[df["anomaly_score"] >= min_score]
        if tier and "risk_tier" in df.columns:
            df = df[df["risk_tier"] == tier.value]

        total = len(df)
        start = (page - 1) * page_size
        page_df = df.iloc[start:start + page_size]

        # Convert to dicts and mask PII
        # V17 E2: DataFrame-level PII masking first, then dict-level as defense-in-depth
        from utils.pii_masking import mask_for_api
        page_df = mask_for_api(page_df)
        items = [
            mask_pii_in_dict(row, user["role"])
            for row in page_df.to_dict(orient="records")
        ]

        return APIResponse(data=PaginatedResponse(
            items=items, total=total, page=page,
            page_size=page_size, has_more=(start + page_size) < total,
        ))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Data retrieval error: {type(e).__name__}")


@router.get("/results/alerts", response_model=APIResponse, tags=["Results"])
async def get_alerts(
    status: Optional[str] = Query(None, description="Filter: OPEN, INVESTIGATING, CLOSED, ESCALATED"),
    tier: Optional[RiskTier] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    user: dict = Depends(require_permission("results:alerts")),
):
    """Get investigation queue alerts. PII masked."""
    try:
        from utils.data_io import DataVault
        vault = DataVault()
        df = vault.get_scored_data()
        if df is None or df.empty:
            return APIResponse(data=PaginatedResponse(items=[], total=0))

        # Filter high-risk as "alerts"
        if "risk_tier" in df.columns:
            alert_tiers = {"CRITICAL", "HIGH", "MEDIUM"}
            if tier:
                alert_tiers = {tier.value}
            df = df[df["risk_tier"].isin(alert_tiers)]

        total = len(df)
        start = (page - 1) * page_size
        page_df = df.iloc[start:start + page_size]

        # V17 E2: DataFrame-level PII masking first
        from utils.pii_masking import mask_for_api
        page_df = mask_for_api(page_df)
        items = [mask_pii_in_dict(row, user["role"]) for row in page_df.to_dict(orient="records")]

        return APIResponse(data=PaginatedResponse(
            items=items, total=total, page=page,
            page_size=page_size, has_more=(start + page_size) < total,
        ))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Alert retrieval error: {type(e).__name__}")


@router.get("/results/risk-tiers", response_model=APIResponse, tags=["Results"])
async def get_risk_tier_summary(
    user: dict = Depends(require_permission("results:risk_tiers")),
):
    """Get aggregate statistics broken down by risk tier."""
    try:
        from utils.data_io import DataVault
        vault = DataVault()
        df = vault.get_scored_data()
        if df is None or df.empty:
            return APIResponse(data=[])

        summaries = []
        if "risk_tier" in df.columns and "anomaly_score" in df.columns:
            total = len(df)
            for tier_name in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "NORMAL"]:
                subset = df[df["risk_tier"] == tier_name]
                if not subset.empty:
                    summaries.append(RiskTierSummary(
                        tier=tier_name,
                        count=len(subset),
                        percentage=round(len(subset) / total * 100, 2),
                        avg_score=round(float(subset["anomaly_score"].mean()), 4),
                        min_score=round(float(subset["anomaly_score"].min()), 4),
                        max_score=round(float(subset["anomaly_score"].max()), 4),
                    ))

        return APIResponse(data=summaries)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Statistics error: {type(e).__name__}")


@router.get("/results/entity/{entity_id}", response_model=APIResponse, tags=["Results"])
async def get_entity_detail(
    entity_id: str,
    user: dict = Depends(require_permission("results:entity")),
):
    """
    Get detailed analysis for a single entity.
    entity_id should be the SHA-256 hashed identifier.
    """
    try:
        from utils.data_io import DataVault
        vault = DataVault()
        df = vault.get_scored_data()
        if df is None or df.empty:
            raise HTTPException(status_code=404, detail="No scored data available")

        # Search by hashed entity_id or original cust_id
        import hashlib
        match = None
        for col in ["entity_id", "cust_id", "customer_id"]:
            if col in df.columns:
                # Try direct match or hash match
                direct = df[df[col].astype(str) == entity_id]
                if not direct.empty:
                    match = direct.iloc[0]
                    break
                hashed = df[df[col].apply(lambda x: hashlib.sha256(str(x).encode()).hexdigest()[:16]) == entity_id]
                if not hashed.empty:
                    match = hashed.iloc[0]
                    break

        if match is None:
            raise HTTPException(status_code=404, detail="Entity not found")

        # V17 E2: DataFrame-level PII masking on single row
        import pandas as _pd
        from utils.pii_masking import mask_for_api
        match_df = mask_for_api(_pd.DataFrame([match.to_dict()]))
        result = mask_pii_in_dict(match_df.iloc[0].to_dict(), user["role"])
        return APIResponse(data=result)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Entity lookup error: {type(e).__name__}")


# =============================================================================
# DATA ENDPOINTS
# =============================================================================
@router.get("/data/sources", response_model=APIResponse, tags=["Data"])
async def get_data_sources(
    user: dict = Depends(require_permission("data:sources")),
):
    """List all loaded data sources with row/column counts."""
    try:
        from utils.data_io import DataVault
        vault = DataVault()
        sources = vault.get_source_names() if hasattr(vault, "get_source_names") else []
        source_info = []
        for name in sources:
            df = vault.get_source(name) if hasattr(vault, "get_source") else None
            source_info.append(DataSourceInfo(
                name=name,
                row_count=len(df) if df is not None else 0,
                column_count=len(df.columns) if df is not None else 0,
            ))
        return APIResponse(data=source_info)
    except Exception:
        return APIResponse(data=[])


# =============================================================================
# AUDIT ENDPOINTS
# =============================================================================
@router.get("/audit/log", response_model=APIResponse, tags=["Audit"])
async def get_audit_log(
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    action: Optional[str] = Query(None, description="Filter by action type"),
    user_filter: Optional[str] = Query(None, alias="user", description="Filter by username"),
    user: dict = Depends(require_permission("audit:log")),
):
    """
    Retrieve audit trail entries.
    Each entry includes timestamp, action, user, and hash-chain integrity hash.
    """
    try:
        from database.engine import safe_session
        from sqlalchemy import text

        with safe_session() as session:
            query = "SELECT timestamp, action, username, details, client_ip, hash_chain FROM audit_log"
            conditions = []
            params = {}

            if action:
                conditions.append("action = :action")
                params["action"] = action
            if user_filter:
                conditions.append("username = :uname")
                params["uname"] = user_filter

            if conditions:
                query += " WHERE " + " AND ".join(conditions)
            query += " ORDER BY id DESC"

            rows = session.execute(text(query), params).fetchall()

        total = len(rows)
        start = (page - 1) * page_size
        page_rows = rows[start:start + page_size]

        items = [
            AuditLogEntry(
                timestamp=datetime.fromisoformat(r[0]) if r[0] else datetime.now(),
                action=r[1] or "",
                user=r[2] or "",
                details=r[3],
                client_ip=r[4],
                hash_chain=r[5],
            )
            for r in page_rows
        ]

        return APIResponse(data=PaginatedResponse(
            items=items, total=total, page=page,
            page_size=page_size, has_more=(start + page_size) < total,
        ))
    except Exception as e:
        return APIResponse(success=False, error=f"Audit log error: {type(e).__name__}")


@router.get("/audit/verify", response_model=APIResponse, tags=["Audit"])
async def verify_hash_chain(
    user: dict = Depends(require_permission("audit:verify")),
):
    """
    Verify the integrity of the audit hash chain.
    V17 E4: Uses logger.verify_hash_chain() and persists result to HashVerification table.
    """
    try:
        # V17 E4: Use the V16 logger.verify_hash_chain() method
        from utils.logger import logger as audit_logger
        result = audit_logger.verify_hash_chain()

        # V17 E4: Persist result to HashVerification DB table
        try:
            import json as _json
            from database.engine import write_session
            from database.models import HashVerification as HVModel
            with write_session() as session:
                session.add(HVModel(
                    status=result.get("status", "UNKNOWN"),
                    entries_checked=result.get("entries_checked", 0),
                    mismatches=len(result.get("mismatches", [])),
                    mismatch_lines=_json.dumps(result.get("mismatches", [])),
                    current_hash=result.get("current_hash", ""),
                    disk_hash=result.get("disk_hash", ""),
                    triggered_by="api",
                    notes=f"API verify by {user.get('username', 'unknown')}",
                ))
        except Exception:
            pass  # non-blocking — result still returned

        is_valid = result.get("valid", False)
        return APIResponse(data=HashChainVerification(
            valid=is_valid,
            total_entries=result.get("entries_checked", 0),
            verified_entries=result.get("entries_checked", 0) - len(result.get("mismatches", [])),
            first_broken_at=result.get("mismatches", [None])[0] if result.get("mismatches") else None,
            message=f"Hash chain {result.get('status', 'UNKNOWN')} — "
                    f"{result.get('entries_checked', 0)} entries checked, "
                    f"{len(result.get('mismatches', []))} mismatches",
        ))
    except Exception as e:
        return APIResponse(success=False, error=f"Verification error: {type(e).__name__}")


# =============================================================================
# SYSTEM ENDPOINTS
# =============================================================================
@router.get("/system/health", response_model=HealthResponse, tags=["System"])
async def system_health(
    user: dict = Depends(require_permission("system:health")),
):
    """Liveness + component health checks."""
    try:
        from utils.health import get_health_response
        h = get_health_response()
        return HealthResponse(**h)
    except Exception:
        return HealthResponse(
            status="unhealthy", version="15.0.0", version_tag="V15",
            uptime_seconds=0, timestamp=datetime.now(),
        )


@router.get("/system/metrics", response_model=APIResponse, tags=["System"])
async def system_metrics(
    user: dict = Depends(require_permission("system:metrics")),
):
    """Current system resource metrics from watchdog."""
    try:
        from utils.watchdog import SystemWatchdog
        wd = SystemWatchdog()
        m = wd.get_latest_metrics()
        return APIResponse(data=SystemMetrics(
            cpu_percent=m.get("cpu_system_percent", 0),
            memory_percent=m.get("memory_percent", 0),
            memory_rss_mb=m.get("memory_rss_mb", 0),
            disk_percent=m.get("disk_percent", 0),
            disk_free_gb=m.get("disk_free_gb", 0),
            db_size_mb=m.get("db_size_mb", 0),
            cache_size_mb=m.get("cache_size_mb", 0),
            thread_count=m.get("thread_count", 0),
            timestamp=datetime.now(),
        ))
    except Exception:
        return APIResponse(success=False, error="Watchdog unavailable")


@router.get("/system/circuit-breakers", response_model=APIResponse, tags=["System"])
async def get_circuit_breakers(
    user: dict = Depends(require_permission("system:circuit_breakers")),
):
    """Get status of all circuit breakers (admin only)."""
    try:
        from utils.circuit_breaker import cb_registry
        statuses = cb_registry.get_all_status()
        items = [
            CircuitBreakerStatus(
                name=name,
                state=info.get("state", "UNKNOWN"),
                failure_count=info.get("failure_count", 0),
                success_count=info.get("success_count", 0),
                total_calls=info.get("total_calls", 0),
            )
            for name, info in statuses.items()
        ]
        return APIResponse(data=items)
    except Exception:
        return APIResponse(data=[])
