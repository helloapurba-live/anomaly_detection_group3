"""
AIM AI Vault V15 — FastAPI Server
====================================
Standalone API server running on port 8079.
Launched alongside the Dash dashboard (port 8078).

Features:
  - Swagger UI at /docs  (disabled in production profiles)
  - ReDoc at /redoc
  - OpenAPI JSON at /openapi.json
  - CORS disabled (air-gapped environment)
  - Startup: initializes JWT secrets, creates api_keys table

Usage:
  python -m api.server        # direct launch
  make run-api                 # via Makefile
  From app.py                 # auto-launched in background thread

Author: AIM AI Vault Team
"""

from __future__ import annotations

import os
import sys
import signal
import secrets
from pathlib import Path

# Ensure project root is on path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from fastapi import FastAPI
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse

from api.routes import router
from api.auth import init_api_auth


def create_api_app() -> FastAPI:
    """Build and configure the FastAPI application."""

    # Load config
    api_port = 8079
    jwt_secret = None
    jwt_expiry = 60  # minutes

    try:
        import tomllib
        config_path = PROJECT_ROOT / "config.toml"
        if config_path.exists():
            with open(config_path, "rb") as f:
                cfg = tomllib.load(f)
            api_cfg = cfg.get("api", {})
            api_port = api_cfg.get("port", 8079)
            jwt_secret = api_cfg.get("jwt_secret")
            jwt_expiry = api_cfg.get("jwt_token_expiry_minutes", 60)
    except Exception:
        pass

    # Generate JWT secret if not configured
    if not jwt_secret:
        jwt_secret = secrets.token_hex(32)

    # Initialize auth module
    init_api_auth(jwt_secret, jwt_expiry)

    # Ensure api_keys table exists
    _ensure_api_keys_table()

    app = FastAPI(
        title="AIM AI Vault — AML Detection API",
        description=(
            "REST API for the AIM AI Vault Anti-Money Laundering detection platform.\n\n"
            "**Authentication**: JWT Bearer token or X-API-Key header.\n"
            "**PII Protection**: All responses auto-mask PII fields based on user role.\n"
            "**Audit**: Every API call is logged with hash-chain integrity.\n\n"
            "⚠️ **Internal Use Only** — Bank AML Investigation Team\n\n"
            "This system is air-gapped. No external network calls are made."
        ),
        version="15.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
        license_info={
            "name": "Proprietary — Internal Bank Use Only",
        },
        contact={
            "name": "AML Technology Team",
        },
    )

    # Trusted host middleware (localhost only for air-gap)
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=["localhost", "127.0.0.1", "0.0.0.0"],
    )

    # Include API routes
    app.include_router(router)

    # Global exception handler — never leak PII in errors
    @app.exception_handler(Exception)
    async def global_exception_handler(request, exc):
        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "error": "Internal server error. Check application logs.",
                "error_type": type(exc).__name__,
            },
        )

    # Startup event
    @app.on_event("startup")
    async def on_startup():
        import logging
        logger = logging.getLogger("api")
        logger.info("AIM AI Vault API v15.0.0 starting on port %d", api_port)

    return app


def _ensure_api_keys_table():
    """Create the api_keys table in SQLite if it doesn't exist."""
    try:
        from database.engine import safe_session
        from sqlalchemy import text

        create_sql = """
        CREATE TABLE IF NOT EXISTS api_keys (
            key_hash   TEXT PRIMARY KEY,
            label      TEXT NOT NULL,
            role       TEXT NOT NULL DEFAULT 'viewer',
            created_at TEXT NOT NULL,
            expires_at TEXT,
            revoked    INTEGER NOT NULL DEFAULT 0
        )
        """
        with safe_session() as session:
            session.execute(text(create_sql))
            session.commit()
    except Exception:
        pass  # DB may not be initialized yet; table created on first use


def run_server(host: str = "127.0.0.1", port: int = 8079):
    """Run the API server with Uvicorn."""
    import uvicorn

    app = create_api_app()

    print(f"""
╔══════════════════════════════════════════════════════════════╗
║           AIM AI Vault — REST API Server v15.0.0            ║
╠══════════════════════════════════════════════════════════════╣
║  Endpoint:   http://{host}:{port}                          ║
║  Swagger UI: http://{host}:{port}/docs                     ║
║  ReDoc:      http://{host}:{port}/redoc                    ║
║  OpenAPI:    http://{host}:{port}/openapi.json             ║
╠══════════════════════════════════════════════════════════════╣
║  Auth:       JWT Bearer Token  or  X-API-Key header         ║
║  PII:        Auto-masked in all responses                   ║
║  Audit:      Every call logged with hash-chain              ║
╠══════════════════════════════════════════════════════════════╣
║  ⚠  INTERNAL USE ONLY — Bank AML Investigation Team        ║
║  ⚠  Air-gapped — No external network connections           ║
╚══════════════════════════════════════════════════════════════╝
""")

    uvicorn.run(
        app,
        host=host,
        port=port,
        log_level="info",
        access_log=True,
        server_header=False,     # Don't leak server info
        proxy_headers=False,     # Air-gapped, no proxy
    )


# Thread-based launcher for embedding in app.py
def start_api_in_background(host: str = "127.0.0.1", port: int = 8079):
    """Start the API server in a background daemon thread."""
    import threading
    import logging

    logger = logging.getLogger("api")

    def _run():
        try:
            import uvicorn
            app = create_api_app()
            logger.info("API server starting in background on %s:%d", host, port)
            uvicorn.run(
                app,
                host=host,
                port=port,
                log_level="warning",
                access_log=False,
                server_header=False,
            )
        except Exception as e:
            logger.error("API server failed: %s", e)

    thread = threading.Thread(target=_run, name="api-server", daemon=True)
    thread.start()
    return thread


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="AIM AI Vault REST API Server")
    parser.add_argument("--host", default="127.0.0.1", help="Bind address (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8079, help="Port (default: 8079)")
    args = parser.parse_args()

    run_server(args.host, args.port)
