"""
AIM AI Vault V15 — API Authentication Module
===============================================
Dual auth: JWT (HMAC-SHA256) + API Key.
Zero external dependencies — uses stdlib hmac, hashlib, json, base64.

JWT tokens are stateless, signed with HMAC-SHA256.
API keys are stored as SHA-256 hashes in SQLite.

Banking compliance:
  - Tokens expire after configurable minutes (default 60)
  - Failed auth attempts are audit-logged
  - Revoked tokens tracked via in-memory blacklist
  - API keys hashed at rest (never stored in plaintext)
  - RBAC enforced on every request

Author: AIM AI Vault Team
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Tuple

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import APP


# =============================================================================
# CONFIGURATION
# =============================================================================
_JWT_SECRET: str = ""          # Set by init_api_auth()
_JWT_EXPIRY_MINUTES: int = 60
_REVOKED_TOKENS: set = set()   # In-memory blacklist (cleared on restart)


def init_api_auth(secret: str = "", expiry_minutes: int = 60):
    """Initialize JWT secret and expiry. Called once at startup."""
    global _JWT_SECRET, _JWT_EXPIRY_MINUTES
    _JWT_SECRET = secret or APP.SECRET_KEY
    _JWT_EXPIRY_MINUTES = expiry_minutes


# =============================================================================
# JWT — HMAC-SHA256 (stdlib only, no PyJWT)
# =============================================================================
def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(s: str) -> bytes:
    s += "=" * (4 - len(s) % 4)
    return base64.urlsafe_b64decode(s)


def create_jwt(username: str, role: str, extra: dict | None = None) -> Tuple[str, int]:
    """
    Create a signed JWT token.
    Returns (token_string, expires_in_seconds).
    """
    now = int(time.time())
    exp = now + (_JWT_EXPIRY_MINUTES * 60)
    payload = {
        "sub": username,
        "role": role,
        "iat": now,
        "exp": exp,
        "jti": secrets.token_hex(16),  # unique token id for revocation
    }
    if extra:
        payload.update(extra)

    header = _b64url_encode(json.dumps({"alg": "HS256", "typ": "JWT"}).encode())
    body = _b64url_encode(json.dumps(payload).encode())
    sig_input = f"{header}.{body}".encode()
    signature = _b64url_encode(
        hmac.new(_JWT_SECRET.encode(), sig_input, hashlib.sha256).digest()
    )
    return f"{header}.{body}.{signature}", _JWT_EXPIRY_MINUTES * 60


def verify_jwt(token: str) -> Optional[dict]:
    """
    Verify JWT signature and expiry.
    Returns payload dict or None if invalid/expired/revoked.
    """
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None

        header_b, body_b, sig_b = parts

        # Verify signature
        sig_input = f"{header_b}.{body_b}".encode()
        expected_sig = _b64url_encode(
            hmac.new(_JWT_SECRET.encode(), sig_input, hashlib.sha256).digest()
        )
        if not hmac.compare_digest(sig_b, expected_sig):
            return None

        # Decode payload
        payload = json.loads(_b64url_decode(body_b))

        # Check expiry
        if payload.get("exp", 0) < int(time.time()):
            return None

        # Check revocation
        if payload.get("jti") in _REVOKED_TOKENS:
            return None

        return payload
    except Exception:
        return None


def revoke_jwt(token: str) -> bool:
    """Add token's jti to revocation blacklist."""
    payload = verify_jwt(token)
    if payload and "jti" in payload:
        _REVOKED_TOKENS.add(payload["jti"])
        return True
    return False


# =============================================================================
# API KEY MANAGEMENT — SHA-256 hashed storage in SQLite
# =============================================================================
_API_KEYS: dict = {}  # {hash: {"label": str, "role": str, "expires_at": datetime, "created_at": datetime}}


def generate_api_key(label: str, role: str = "viewer", expires_days: int = 90) -> Tuple[str, str]:
    """
    Generate a new API key.
    Returns (plaintext_key, key_hash).
    The plaintext key is shown ONCE — only the hash is stored.
    """
    raw_key = f"avk_{secrets.token_urlsafe(32)}"  # avk_ prefix for identification
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()

    _API_KEYS[key_hash] = {
        "label": label,
        "role": role,
        "created_at": datetime.now(),
        "expires_at": datetime.now() + timedelta(days=expires_days),
    }

    # Persist to database
    _persist_api_key(key_hash, label, role, expires_days)

    return raw_key, key_hash


def verify_api_key(key: str) -> Optional[dict]:
    """
    Verify an API key.
    Returns {"label", "role", "expires_at"} or None.
    """
    key_hash = hashlib.sha256(key.encode()).hexdigest()
    entry = _API_KEYS.get(key_hash)
    if not entry:
        # Try loading from database
        entry = _load_api_key(key_hash)
        if entry:
            _API_KEYS[key_hash] = entry

    if not entry:
        return None
    if entry["expires_at"] < datetime.now():
        return None  # Expired

    return {"label": entry["label"], "role": entry["role"], "expires_at": entry["expires_at"]}


def revoke_api_key(key_hash: str) -> bool:
    """Revoke an API key by its hash."""
    if key_hash in _API_KEYS:
        del _API_KEYS[key_hash]
        _delete_api_key(key_hash)
        return True
    return False


def list_api_keys() -> list:
    """List all active (non-expired) API keys (hashes + labels, not plaintext)."""
    _load_all_api_keys()
    now = datetime.now()
    return [
        {"hash": h[:12] + "...", "label": v["label"], "role": v["role"],
         "expires_at": v["expires_at"].isoformat(), "active": v["expires_at"] > now}
        for h, v in _API_KEYS.items()
    ]


# =============================================================================
# DATABASE PERSISTENCE (api_keys table)
# =============================================================================
def _persist_api_key(key_hash: str, label: str, role: str, expires_days: int):
    """Save API key hash to SQLite."""
    try:
        from database.engine import safe_session
        from sqlalchemy import text
        with safe_session() as session:
            session.execute(text(
                "INSERT OR REPLACE INTO api_keys (key_hash, label, role, created_at, expires_at) "
                "VALUES (:h, :l, :r, :c, :e)"
            ), {
                "h": key_hash, "l": label, "r": role,
                "c": datetime.now().isoformat(),
                "e": (datetime.now() + timedelta(days=expires_days)).isoformat(),
            })
    except Exception:
        pass  # Table might not exist yet — keys stay in memory


def _load_api_key(key_hash: str) -> Optional[dict]:
    """Load a single API key from SQLite."""
    try:
        from database.engine import safe_session
        from sqlalchemy import text
        with safe_session() as session:
            row = session.execute(
                text("SELECT label, role, expires_at FROM api_keys WHERE key_hash = :h"),
                {"h": key_hash},
            ).fetchone()
            if row:
                return {
                    "label": row[0], "role": row[1],
                    "created_at": datetime.now(),
                    "expires_at": datetime.fromisoformat(row[2]),
                }
    except Exception:
        pass
    return None


def _load_all_api_keys():
    """Load all API keys from SQLite into memory."""
    try:
        from database.engine import safe_session
        from sqlalchemy import text
        with safe_session() as session:
            rows = session.execute(
                text("SELECT key_hash, label, role, created_at, expires_at FROM api_keys")
            ).fetchall()
            for row in rows:
                if row[0] not in _API_KEYS:
                    _API_KEYS[row[0]] = {
                        "label": row[1], "role": row[2],
                        "created_at": datetime.fromisoformat(row[3]) if row[3] else datetime.now(),
                        "expires_at": datetime.fromisoformat(row[4]),
                    }
    except Exception:
        pass


def _delete_api_key(key_hash: str):
    """Remove API key from SQLite."""
    try:
        from database.engine import safe_session
        from sqlalchemy import text
        with safe_session() as session:
            session.execute(text("DELETE FROM api_keys WHERE key_hash = :h"), {"h": key_hash})
    except Exception:
        pass


# =============================================================================
# AUTHENTICATE REQUEST — unified check for JWT or API Key
# =============================================================================
def authenticate_request(authorization: str = "", x_api_key: str = "") -> Optional[dict]:
    """
    Try JWT first (Authorization: Bearer <token>), then API Key (X-API-Key header).
    Returns {"username": str, "role": str, "auth_method": "jwt"|"api_key"} or None.
    """
    # Try JWT
    if authorization.startswith("Bearer "):
        token = authorization[7:]
        payload = verify_jwt(token)
        if payload:
            return {
                "username": payload["sub"],
                "role": payload["role"],
                "auth_method": "jwt",
                "jti": payload.get("jti"),
            }

    # Try API Key
    if x_api_key:
        entry = verify_api_key(x_api_key)
        if entry:
            return {
                "username": f"apikey:{entry['label']}",
                "role": entry["role"],
                "auth_method": "api_key",
            }

    return None
