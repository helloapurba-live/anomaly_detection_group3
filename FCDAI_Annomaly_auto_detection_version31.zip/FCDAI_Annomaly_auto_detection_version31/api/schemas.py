"""
AIM AI Vault V15 — API Pydantic Schemas
=========================================
Request/response models for all API endpoints.
Uses Pydantic v2 for automatic validation and OpenAPI doc generation.
PII fields are excluded from responses by default.

Author: AIM AI Vault Team
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, ConfigDict


# =============================================================================
# ENUMS
# =============================================================================
class RiskTier(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    NORMAL = "NORMAL"


class PipelineStatus(str, Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


class UserRole(str, Enum):
    ADMIN = "admin"
    INVESTIGATOR = "investigator"
    VIEWER = "viewer"


# =============================================================================
# AUTH SCHEMAS
# =============================================================================
class TokenRequest(BaseModel):
    """Credentials for JWT token issuance."""
    username: str = Field(..., min_length=1, max_length=64, description="Login username")
    password: str = Field(..., min_length=1, max_length=128, description="Login password")

    model_config = ConfigDict(json_schema_extra={
        "example": {"username": "analyst1", "password": "*** REDACTED ***"}
    })


class TokenResponse(BaseModel):
    """JWT token returned after successful authentication."""
    access_token: str = Field(..., description="JWT bearer token")
    token_type: str = Field(default="bearer")
    expires_in: int = Field(..., description="Token lifetime in seconds")
    role: UserRole = Field(..., description="Authenticated user role")


class APIKeyCreate(BaseModel):
    """Request to create a new API key (admin only)."""
    label: str = Field(..., min_length=1, max_length=64, description="Human-readable key label")
    role: UserRole = Field(default=UserRole.VIEWER, description="Role assigned to this key")
    expires_days: Optional[int] = Field(default=90, ge=1, le=365, description="Key expiry in days")


class APIKeyResponse(BaseModel):
    """Newly created API key — shown ONCE, then hashed."""
    key: str = Field(..., description="API key (save immediately — not shown again)")
    label: str
    role: UserRole
    expires_at: datetime


# =============================================================================
# PIPELINE SCHEMAS
# =============================================================================
class PipelineRunRequest(BaseModel):
    """Request to start a pipeline execution."""
    description: Optional[str] = Field(
        default=None, max_length=256,
        description="Optional run description for audit trail"
    )
    methods: Optional[List[str]] = Field(
        default=None,
        description="Subset of detection methods to run (null = all 26)"
    )

    model_config = ConfigDict(json_schema_extra={
        "example": {"description": "Weekly batch run", "methods": None}
    })


class PipelineRunResponse(BaseModel):
    """Acknowledgement that pipeline started."""
    run_id: str = Field(..., description="UUID for this pipeline run")
    status: PipelineStatus = PipelineStatus.PENDING
    message: str = "Pipeline queued for execution"
    started_at: datetime


class PipelineStatusResponse(BaseModel):
    """Current status of a pipeline run."""
    run_id: str
    status: PipelineStatus
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    duration_seconds: Optional[float] = None
    total_entities: Optional[int] = None
    total_anomalies: Optional[int] = None
    methods_run: Optional[int] = None
    circuit_breaker_skipped: Optional[List[str]] = None
    failed_methods: Optional[List[str]] = None
    error: Optional[str] = None


class PipelineHistoryItem(BaseModel):
    """Summary of a past pipeline run."""
    run_id: str
    status: PipelineStatus
    started_at: datetime
    completed_at: Optional[datetime] = None
    duration_seconds: Optional[float] = None
    total_entities: Optional[int] = None
    total_anomalies: Optional[int] = None
    description: Optional[str] = None


# =============================================================================
# RESULTS SCHEMAS
# =============================================================================
class ScoredEntity(BaseModel):
    """A single scored entity from pipeline results.
    PII fields (cust_name, account details) are masked by middleware."""
    entity_id: str = Field(..., description="SHA-256 hashed entity identifier")
    risk_tier: RiskTier
    anomaly_score: float = Field(..., ge=0.0, le=1.0, description="Ensemble anomaly score")
    vote_count: int = Field(..., ge=0, description="Number of methods flagging this entity")
    top_methods: List[str] = Field(default_factory=list, description="Top contributing methods")


class AlertItem(BaseModel):
    """An alert from the investigation queue."""
    alert_id: str
    entity_id: str = Field(..., description="SHA-256 hashed entity identifier")
    risk_tier: RiskTier
    anomaly_score: float
    created_at: datetime
    status: str = Field(..., description="OPEN / INVESTIGATING / CLOSED / ESCALATED")
    assigned_to: Optional[str] = None


class RiskTierSummary(BaseModel):
    """Aggregate statistics for a risk tier."""
    tier: RiskTier
    count: int
    percentage: float = Field(..., description="Percentage of total entities")
    avg_score: float
    min_score: float
    max_score: float


class EntityDetail(BaseModel):
    """Deep-dive on a single entity (PII masked)."""
    entity_id: str
    risk_tier: RiskTier
    anomaly_score: float
    vote_count: int
    method_scores: Dict[str, float] = Field(
        default_factory=dict,
        description="Score from each detection method"
    )
    feature_importance: Optional[Dict[str, float]] = None
    alert_history: List[AlertItem] = Field(default_factory=list)


# =============================================================================
# DATA SCHEMAS
# =============================================================================
class DataSourceInfo(BaseModel):
    """Information about a loaded data source."""
    name: str
    row_count: int
    column_count: int
    loaded_at: Optional[datetime] = None
    file_type: Optional[str] = None
    size_mb: Optional[float] = None


# =============================================================================
# AUDIT SCHEMAS
# =============================================================================
class AuditLogEntry(BaseModel):
    """A single audit trail record."""
    timestamp: datetime
    action: str
    user: str
    details: Optional[str] = None
    client_ip: Optional[str] = None
    hash_chain: Optional[str] = Field(None, description="SHA-256 chain hash")


class HashChainVerification(BaseModel):
    """Result of audit hash-chain integrity verification."""
    valid: bool
    total_entries: int
    verified_entries: int
    first_broken_at: Optional[int] = Field(None, description="Entry index where chain broke")
    message: str


# =============================================================================
# SYSTEM SCHEMAS
# =============================================================================
class HealthResponse(BaseModel):
    """System health check response."""
    status: str = Field(..., description="healthy / degraded / unhealthy")
    version: str
    version_tag: str
    uptime_seconds: float
    timestamp: datetime
    checks: Dict[str, Any] = Field(default_factory=dict)


class SystemMetrics(BaseModel):
    """Current system resource metrics."""
    cpu_percent: float
    memory_percent: float
    memory_rss_mb: float
    disk_percent: float
    disk_free_gb: float
    db_size_mb: float
    cache_size_mb: float
    thread_count: int
    timestamp: datetime


class CircuitBreakerStatus(BaseModel):
    """Status of a single circuit breaker."""
    name: str
    state: str = Field(..., description="CLOSED / OPEN / HALF_OPEN")
    failure_count: int
    success_count: int
    total_calls: int
    last_failure_at: Optional[datetime] = None


# =============================================================================
# GENERIC WRAPPERS
# =============================================================================
class APIResponse(BaseModel):
    """Standard envelope for all API responses."""
    success: bool = True
    data: Any = None
    error: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.now)
    request_id: Optional[str] = None


class PaginatedResponse(BaseModel):
    """Paginated list response."""
    items: List[Any]
    total: int
    page: int = 1
    page_size: int = 50
    has_more: bool = False
