"""
AIM AI Vault V15 — API Middleware
===================================
Security middleware applied to every API request:
  1. Authentication (JWT / API Key)
  2. RBAC authorization
  3. Rate limiting (per-client, sliding window)
  4. PII masking in responses
  5. Request/response audit logging
  6. Request ID injection

Banking compliance:
  - Every API call is audit-logged with user, endpoint, timestamp, IP
  - PII fields auto-masked based on role (viewer sees masked, admin sees hashed)
  - Rate limiting prevents abuse (configurable per minute)
  - Sanitized errors — no stack traces or file paths in responses

Author: AIM AI Vault Team
"""

from __future__ import annotations

import hashlib
import re
import sys
import time
import uuid
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from threading import Lock
from typing import Any, Dict, Optional, Set

sys.path.insert(0, str(Path(__file__).parent.parent))


# =============================================================================
# PII FIELD PATTERNS — fields that must be masked in API responses
# =============================================================================
PII_FIELD_NAMES: Set[str] = {
    "cust_name", "customer_name", "name", "full_name", "first_name", "last_name",
    "email", "phone", "address", "ssn", "social_security", "tax_id", "tin",
    "dob", "date_of_birth", "account_number", "card_number", "routing_number",
    "passport", "drivers_license", "ip_address", "beneficiary_name",
    "sender_name", "receiver_name",
}
PII_PARTIAL_PATTERNS = re.compile(
    r"(name|email|phone|addr|ssn|account|card|passport|license|birth|beneficiary)",
    re.IGNORECASE,
)


def mask_pii_value(value: Any, field_name: str = "") -> Any:
    """Mask a PII value for API response."""
    if value is None:
        return None
    s = str(value)
    if len(s) <= 2:
        return "***"
    # Show first and last char with asterisks
    return s[0] + "*" * (len(s) - 2) + s[-1]


def mask_pii_in_dict(data: dict, role: str = "viewer") -> dict:
    """
    Recursively mask PII fields in a dictionary.
    admin: sees SHA-256 hashes
    investigator: sees partial mask (first/last char)
    viewer: sees full mask (***)
    """
    if not isinstance(data, dict):
        return data

    result = {}
    for key, value in data.items():
        key_lower = key.lower()
        is_pii = (
            key_lower in PII_FIELD_NAMES
            or PII_PARTIAL_PATTERNS.search(key_lower)
        )

        if is_pii and value is not None:
            if role == "admin":
                result[key] = hashlib.sha256(str(value).encode()).hexdigest()[:16]
            elif role == "investigator":
                result[key] = mask_pii_value(value, key)
            else:  # viewer
                result[key] = "***REDACTED***"
        elif isinstance(value, dict):
            result[key] = mask_pii_in_dict(value, role)
        elif isinstance(value, list):
            result[key] = [
                mask_pii_in_dict(item, role) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            result[key] = value

    return result


# =============================================================================
# RATE LIMITER — sliding window per client
# =============================================================================
class RateLimiter:
    """Thread-safe sliding window rate limiter."""

    def __init__(self, max_per_minute: int = 100):
        self._max = max_per_minute
        self._windows: Dict[str, list] = defaultdict(list)
        self._lock = Lock()

    def check(self, client_id: str) -> bool:
        """Returns True if request is allowed, False if rate-limited."""
        now = time.time()
        cutoff = now - 60.0  # 1-minute window

        with self._lock:
            timestamps = self._windows[client_id]
            # Remove old entries
            self._windows[client_id] = [t for t in timestamps if t > cutoff]
            if len(self._windows[client_id]) >= self._max:
                return False
            self._windows[client_id].append(now)
            return True

    def get_remaining(self, client_id: str) -> int:
        """Get remaining requests in current window."""
        now = time.time()
        cutoff = now - 60.0
        with self._lock:
            active = [t for t in self._windows.get(client_id, []) if t > cutoff]
            return max(0, self._max - len(active))


# Global rate limiter instance
rate_limiter = RateLimiter(max_per_minute=100)


# =============================================================================
# AUDIT LOGGING — every API call recorded
# =============================================================================
def audit_api_request(
    method: str,
    path: str,
    user: str,
    role: str,
    client_ip: str,
    status_code: int,
    request_id: str,
    duration_ms: float = 0,
    error: Optional[str] = None,
):
    """Log an API request to the audit trail."""
    try:
        from utils.logger import logger
        metadata = {
            "api_method": method,
            "api_path": path,
            "status_code": status_code,
            "request_id": request_id,
            "client_ip": client_ip,
            "duration_ms": round(duration_ms, 2),
            "auth_role": role,
        }
        if error:
            metadata["error"] = error[:200]  # Truncate for safety

        logger.log_action(
            action="API_REQUEST",
            user=user,
            metadata=metadata,
        )
    except Exception:
        pass  # Never let audit failure break API


def generate_request_id() -> str:
    """Generate a unique request ID for tracing."""
    return str(uuid.uuid4())


# =============================================================================
# RBAC — role-based access control for API endpoints
# =============================================================================
ENDPOINT_PERMISSIONS: Dict[str, set] = {
    # Pipeline operations
    "pipeline:run": {"admin", "investigator"},
    "pipeline:status": {"admin", "investigator", "viewer"},
    "pipeline:history": {"admin", "investigator", "viewer"},
    # Results
    "results:scored": {"admin", "investigator"},
    "results:alerts": {"admin", "investigator"},
    "results:risk_tiers": {"admin", "investigator", "viewer"},
    "results:entity": {"admin", "investigator"},
    # Data
    "data:sources": {"admin", "investigator", "viewer"},
    # Audit
    "audit:log": {"admin", "investigator"},
    "audit:verify": {"admin"},
    # System
    "system:health": {"admin", "investigator", "viewer"},
    "system:metrics": {"admin", "investigator"},
    "system:circuit_breakers": {"admin"},
    # Auth
    "auth:token": set(),       # No auth required (login endpoint)
    "auth:revoke": {"admin", "investigator", "viewer"},
    "auth:keys_list": {"admin"},
    "auth:keys_create": {"admin"},
    "auth:keys_revoke": {"admin"},
}


def check_permission(role: str, permission: str) -> bool:
    """Check if a role has the required permission."""
    allowed_roles = ENDPOINT_PERMISSIONS.get(permission, set())
    if not allowed_roles:
        return True  # No restriction (e.g., login endpoint)
    return role in allowed_roles
