"""
FCDAI V14 — Authentication Manager
=====================================
Flask-Login + RBAC for the Dash Application.

V13 Fixes:
  - F-3: Safe int() conversion in load_user (no crash on invalid ID)
  - F-1: Uses safe_session context manager pattern

Roles:
  admin        — Full control: manage users, delete data, all pages
  investigator — Run pipeline, view/flag anomalies, export
  viewer       — Dashboard read-only access

Security:
  - Passwords hashed with scrypt via passlib (never plain text)
  - Session-based auth via Flask-Login
  - Secret key from config (rotatable)
  - Client_IP captured in every audit event
"""

import sys
from pathlib import Path
from functools import wraps
from datetime import datetime

from flask_login import LoginManager, login_user, logout_user, current_user
from flask import request as flask_request
from dash import html

sys.path.insert(0, str(Path(__file__).parent.parent))

# ---------------------------------------------------------------------------
# Password hashing — prefer passlib scrypt, fallback to werkzeug PBKDF2
# ---------------------------------------------------------------------------
try:
    from passlib.hash import scrypt as _scrypt_hasher
    HAS_PASSLIB = True
except ImportError:
    HAS_PASSLIB = False
    from werkzeug.security import check_password_hash, generate_password_hash


def verify_password(stored_hash: str, password: str) -> bool:
    """Verify password against stored hash (scrypt preferred, werkzeug fallback)."""
    if HAS_PASSLIB:
        try:
            return _scrypt_hasher.verify(password, stored_hash)
        except Exception:
            # May be a legacy werkzeug hash — try that too
            try:
                from werkzeug.security import check_password_hash
                return check_password_hash(stored_hash, password)
            except Exception:
                return False
    return check_password_hash(stored_hash, password)


def hash_password(password: str) -> str:
    """Hash a password using scrypt (preferred) or werkzeug PBKDF2."""
    if HAS_PASSLIB:
        return _scrypt_hasher.hash(password)
    return generate_password_hash(password, method="pbkdf2:sha256")


def get_client_ip() -> str:
    """Extract client IP from the Flask request context."""
    try:
        return flask_request.remote_addr or "127.0.0.1"
    except RuntimeError:
        return "127.0.0.1"

# ---------------------------------------------------------------------------
# Login Manager singleton
# ---------------------------------------------------------------------------
login_manager = LoginManager()


def init_login_manager(server):
    """Attach Flask-Login to the Flask server underlying Dash."""
    from config import APP
    server.secret_key = APP.SECRET_KEY
    # V13: Secure session cookie flags — bank compliance
    server.config["SESSION_COOKIE_HTTPONLY"] = True
    server.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    server.config["SESSION_COOKIE_NAME"] = "aim_vault_session"
    server.config["PERMANENT_SESSION_LIFETIME"] = 28800  # 8 hours
    login_manager.init_app(server)
    login_manager.login_view = "/login"


@login_manager.user_loader
def load_user(user_id):
    """Required callback for Flask-Login — load user by PK.
    V13 F-3: Safe int conversion — returns None on invalid ID."""
    from database.engine import get_session
    from database.models import User
    # F-3: Validate user_id before int() conversion
    try:
        uid = int(user_id)
    except (ValueError, TypeError):
        return None
    session = get_session()
    try:
        return session.query(User).get(uid)
    except Exception:
        return None
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------
def authenticate(username: str, password: str):
    """Verify credentials. Returns User on success, None on failure."""
    from database.engine import get_session
    from database.models import User
    session = get_session()
    try:
        user = session.query(User).filter_by(username=username, is_active=True).first()
        if user and verify_password(user.password_hash, password):
            user.last_login = datetime.utcnow()
            session.commit()
            login_user(user, remember=False)  # F-13 FIX: no persistent cookie in BFSI
            # Audit the login event with Client_IP
            try:
                from utils.logger import logger
                logger.log_action(
                    "USER_LOGIN", user=username,
                    metadata={"client_ip": get_client_ip(), "role": user.role},
                )
            except Exception:
                pass
            return user
        return None
    except Exception:
        session.rollback()
        return None
    finally:
        session.close()


def do_logout():
    """Log out the current user."""
    logout_user()


def get_current_user():
    """Return the current Flask-Login user (or Anonymous)."""
    return current_user


# ---------------------------------------------------------------------------
# RBAC decorator for page layouts
# ---------------------------------------------------------------------------
ROLE_HIERARCHY = {"admin": 3, "investigator": 2, "viewer": 1}


def require_role(min_role: str = "viewer"):
    """
    V29: RBAC re-enabled. Checks that the current user has sufficient role.
    Role hierarchy: admin(3) > investigator(2) > viewer(1)
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if not current_user.is_authenticated:
                return html.Div("Please log in to access this page.")
            user_level = ROLE_HIERARCHY.get(current_user.role, 0)
            required_level = ROLE_HIERARCHY.get(min_role, 0)
            if user_level < required_level:
                from dash import html as _html
                return _html.Div(f"Access denied. Requires {min_role} role or above.")
            return func(*args, **kwargs)
        return wrapper
    return decorator
