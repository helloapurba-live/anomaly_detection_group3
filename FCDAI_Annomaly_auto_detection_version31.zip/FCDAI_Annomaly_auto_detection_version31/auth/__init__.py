"""
FCDAI V14 — Authentication Module
====================================
Flask-Login integration with RBAC for Dash multi-page app.
"""

from auth.manager import init_login_manager, get_current_user, require_role

__all__ = ["init_login_manager", "get_current_user", "require_role"]
