"""
V24 DataFrame Trace — Top 3 Records at Each Pipeline Stage
===========================================================
Shows the exact data at every transformation step, from raw sources
through to the final scored output.
"""
import sys, os, warnings
warnings.filterwarnings("ignore")
os.environ["LOKY_MAX_CPU_COUNT"] = "2"

from pathlib import Path
ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

import pandas as pd
import numpy as np
pd.set_option("display.max_columns", 20)
pd.set_option("display.width", 200)
pd.set_option("display.max_colwidth", 22)

SEP = "=" * 100
THIN = "-" * 100

def show(title, df, obs=""):
    """Display top 3 records of a DataFrame with shape summary."""
    print(f"\n{SEP}")
    print(f"  STEP: {title}")
    print(f"  Shape: {df.shape[0]} rows × {df.shape[1]} columns")
    print(f"  Columns: {list(df.columns[:15])}{'  ...' if len(df.columns)>15 else ''}")
    if obs:
        print(f"  Observation: {obs}")
    print(THIN)
    print(df.head(3).to_string(index=True))
    print(SEP)

def show_matrix(title, arr, names=None, obs=""):
    """Display top 3 rows of a numpy array."""
    print(f"\n{SEP}")
    print(f"  STEP: {title}")
    print(f"  Shape: {arr.shape}")
    print(f"  dtype: {arr.dtype}")
    if names:
        print(f"  Feature cols: {names[:10]}{'  ...' if len(names)>10 else ''}")
    if obs:
        print(f"  Observation: {obs}")
    print(THIN)
    top3 = pd.DataFrame(arr[:3], columns=names[:arr.shape[1]] if names and len(names)>=arr.shape[1] else None)
    print(top3.to_string(index=True))
    print(SEP)


# =====================================================================
# PHASE 0: GENERATE SAMPLE DATA (same as pipeline_run "sample" mode)
# =====================================================================
print("\n" + "★" * 100)
print("  V24 STEP-BY-STEP DATAFRAME TRACE — TOP 3 RECORDS AT EACH STAGE")
print("★" * 100)

from utils.data_gen import DataGenerator
dg = DataGenerator(seed=42)
schema = dg.generate_full_schema(num_customers=50)  # 50 customers for speed

# Show the raw source tables
print(f"\n{'#'*100}")
print(f"  PHASE 0: RAW SOURCE TABLES (Data Sources Page Output)")
print(f"{'#'*100}")

for tname in ["BASE", "transactions", "customer_party", "accounts", "alerts", "cases", "kyc",
              "watchlist", "relationships_edges", "relationships_nodes", "temporal_long", "temporal_wide"]:
    if tname in schema:
        df = schema[tname]
        show(f"Source Table: {tname}", df,
             f"This is one of 12 source tables uploaded/generated in Data Sources page")

# =====================================================================
# PHASE 1: BUILD MERGED DF (what Data Sources page saves to vault)
# =====================================================================
print(f"\n{'#'*100}")
print(f"  PHASE 1: MERGED MASTER (Data Sources → vault/current.parquet)")
print(f"{'#'*100}")

# Simulate what pipeline_run.py does: merge BASE with other tables on primary key
df_base = schema["BASE"].copy()
# The pipeline merges ALL tables onto BASE via left join on the resolved primary key
# In practice, BASE already has aggregated features from transactions/accounts/alerts/cases
# Additional tables join via party_id/cust_id

show("1A. BASE Table (★ This IS the final output of Data Sources page)",
     df_base,
     "BASE = pre-aggregated customer-level table. "
     "It has party metrics (txn counts, amounts, balances, alert/case counts). "
     "This is what gets saved as vault/current.parquet AND vault/sources/MASTER.parquet")

# For pipeline, merged_df = df_base (the BASE table IS the master)
merged_df = df_base.copy()

show("1B. merged_df (passed to pipeline.run() as merged_df=)",
     merged_df,
     "Same as BASE — this is the input DataFrame `df` inside pipeline.run()")


# =====================================================================
# PHASE 2: PIPELINE STEP-BY-STEP
# =====================================================================
print(f"\n{'#'*100}")
print(f"  PHASE 2: PIPELINE EXECUTION — STEP BY STEP")
print(f"{'#'*100}")

from config import PATHS, LAYERS, APP, COLUMNS
from layers.l1_l2_ingestion import IngestPipeline
from layers.l3_feature_engineering import Layer3FeatureEngineering
from utils.customer_aggregation import CustomerAggregator
from utils.column_resolver import resolve, resolve_many
from utils.schema_detector import SchemaDetector
from utils.dq_validation import DQValidationEngine
from utils.dq_processing import DQProcessingEngine
from utils.preprocessing_engine import PreprocessingEngine
from utils.scaling_engine import ScalingEngine
from utils.reduction_engine import ReductionEngine


# ── Step L1-2: Ingest + DQ ──
ingest = IngestPipeline()
df = merged_df.copy()
dq_report = ingest.dq.assess_quality(df)
df = ingest.dq.cleanse(df, "moderate")

show("L1-2: df after Ingest + DQ Cleanse",
     df,
     f"DQ Score: {dq_report.overall_score:.2%}. "
     f"Same shape as merged_df but with DQ cleansing applied (nulls handled, types fixed)")


# ── Step M1: DQ Validation ──
dq_validator = DQValidationEngine()
try:
    dq_val_result = dq_validator.validate(df)
    dq_validation_dict = dq_validator.scorecard_to_dict(dq_val_result)
    print(f"\n  M1 DQ Validation → Score: {dq_val_result.dq_score:.1%}, Passed: {dq_val_result.passed}")
    print(f"  (No shape change — M1 only validates, does NOT modify df)")
except Exception as e:
    print(f"\n  M1 DQ Validation failed: {e}")
    dq_validation_dict = {}

show("M1: df after DQ Validation (UNCHANGED — validation only)",
     df,
     "M1 produces a scorecard but does NOT modify the DataFrame. Shape unchanged.")


# ── Step V6: Customer Aggregation ──
resolved = resolve_many(df, ["primary_key", "amount", "timestamp"])
customer_col = resolved.get("primary_key")
amount_col = resolved.get("amount")
timestamp_col = resolved.get("timestamp")

if APP.CUSTOMER_LEVEL_PROCESSING and customer_col and customer_col in df.columns:
    aggregator = CustomerAggregator(customer_col=customer_col)
    df = aggregator.aggregate(
        df_transactions=df,
        amount_col=amount_col if amount_col and amount_col in df.columns else None,
        timestamp_col=timestamp_col if timestamp_col and timestamp_col in df.columns else None,
    )
    show("V6: df after Customer Aggregation",
         df,
         f"Grouped by '{customer_col}'. May reduce rows (if was txn-level) and add agg features. "
         f"Since BASE is already customer-level, shape may stay similar.")
else:
    print(f"\n  V6: Customer Aggregation SKIPPED (APP.CUSTOMER_LEVEL_PROCESSING={APP.CUSTOMER_LEVEL_PROCESSING}, "
          f"customer_col={customer_col})")


# ── Step L3: Feature Engineering ──
features = Layer3FeatureEngineering()
try:
    df = features.engineer_features(
        df,
        customer_col=customer_col if customer_col and customer_col in df.columns else None,
        amount_col=amount_col if amount_col and amount_col in df.columns else None,
        timestamp_col=timestamp_col if timestamp_col and timestamp_col in df.columns else None,
    )
except TypeError:
    df = features.engineer_features(df)

show("L3: df after Feature Engineering",
     df,
     f"Added ~25 feature columns (vel_*, agg_*, ratio_*, flag_*, temp_*, behav_*). "
     f"Same rows, many more columns.")


# ── Step V8: Schema Detection ──
schema_detector = SchemaDetector()
schema_profiles = schema_detector.detect_schema(df)
usable_cols = schema_detector.get_usable_columns(schema_profiles)
print(f"\n  V8: Schema Detection → {len(usable_cols)} usable / {len(schema_profiles)} total columns")
print(f"  (No shape change — profiling only)")


# ── Step M2: DQ Processing (12-step cleanse) ──
dq_processor = DQProcessingEngine()
m2_result = dq_processor.process(df)
df_cleaned = m2_result.cleaned_df if m2_result.cleaned_df is not None else df

show("M2: df_cleaned after DQ Processing",
     df_cleaned,
     f"12-step cleanse: {m2_result.shape_before} → {m2_result.shape_after}. "
     f"Dropped {len(m2_result.columns_dropped)} cols: {m2_result.columns_dropped[:5]}... "
     f"Renamed {len(m2_result.columns_renamed)} cols. PII/constants/high-null removed.")


# ── Step M3: Preprocessing / Encoding ──
preprocessing_engine = PreprocessingEngine(
    missing_strategy="ZERO",
    datetime_cols=m2_result.datetime_cols_extracted,
)
m3_result = preprocessing_engine.preprocess(df_cleaned, m2_result.data_type_map)
encoded_master = m3_result.encoded_master

show("M3: encoded_master after Preprocessing",
     encoded_master,
     f"100% FLOAT matrix. {m3_result.shape_before} → {m3_result.shape_after}. "
     f"All categoricals OneHot-encoded, ordinals label-encoded, missing filled with ZERO strategy. "
     f"This is the ENCODED MASTER — fully numeric, ready for scaling.")


# ── Step M4: 6-Way Scaling ──
scaling_engine = ScalingEngine()
m4_result = scaling_engine.scale(encoded_master)

print(f"\n  M4: 6-Way Scaling → {len(m4_result.scaled_matrices)} scaler versions created")
print(f"  Input shape: {m4_result.input_shape}")
print(f"  Scalers: {list(m4_result.scaled_matrices.keys())}")

for sname, smat in m4_result.scaled_matrices.items():
    show_matrix(f"M4: scaled_matrices['{sname}']",
                smat if isinstance(smat, np.ndarray) else smat.values,
                m4_result.feature_names,
                f"Scaler: {sname}. Same shape as encoded_master but values transformed.")
    break  # Show just the first one (StandardScaler) to save space

# Show one more for comparison
for sname in ["MinMaxScaler", "Original"]:
    if sname in m4_result.scaled_matrices:
        smat = m4_result.scaled_matrices[sname]
        show_matrix(f"M4: scaled_matrices['{sname}']",
                    smat if isinstance(smat, np.ndarray) else smat.values,
                    m4_result.feature_names,
                    f"Compare with StandardScaler — different value ranges.")
        break


# ── Step M5: Dimension Reduction ──
reduction_engine = ReductionEngine()
X_for_reduction = m4_result.scaled_matrices.get("StandardScaler")
if X_for_reduction is None:
    X_for_reduction = next(iter(m4_result.scaled_matrices.values()))
if not isinstance(X_for_reduction, np.ndarray):
    X_for_reduction = X_for_reduction.values

m5_result = reduction_engine.reduce(
    X_for_reduction,
    feature_names=m4_result.feature_names,
    path=1,  # Path 1 = no reduction (pass-through)
    encoding_map=m3_result.encoding_map,
)

X = m5_result.premaster.values if m5_result.premaster is not None and not m5_result.premaster.empty else X_for_reduction

show("M5: X (PreMaster) after Dimension Reduction",
     m5_result.premaster if m5_result.premaster is not None and not m5_result.premaster.empty else pd.DataFrame(X),
     f"Path {m5_result.path_used} ({m5_result.path_name}): {m5_result.dims_before} → {m5_result.dims_after} dims. "
     f"This is the FINAL NUMERIC INPUT to L5 Detection — called 'X' or 'PreMaster'.")


# ── Summary: DataFrame Sequence ──
print(f"\n{'#'*100}")
print(f"  SUMMARY: COMPLETE DATAFRAME SEQUENCE")
print(f"{'#'*100}")

print("""
┌──────────────────────────────────────────────────────────────────────────────┐
│  STEP          │ VARIABLE        │ SHAPE          │ DESCRIPTION             │
├──────────────────────────────────────────────────────────────────────────────┤
│  Data Sources  │ BASE            │ {base_shape}    │ ★ FINAL output of      │
│  Page Output   │                 │                │   Data Sources page     │
│                │                 │                │   (= vault/current.parq)│
├──────────────────────────────────────────────────────────────────────────────┤
│  L1-2 Ingest   │ df              │ {l12_shape}    │ Merged + DQ cleansed    │
│  M1 DQ Valid   │ df (unchanged)  │ {m1_shape}    │ Scorecard only          │
│  V6 Cust Agg   │ df              │ {v6_shape}    │ Customer-level agg      │
│  L3 Features   │ df              │ {l3_shape}    │ +25 feature cols        │
│  V8 Schema     │ df (unchanged)  │ {v8_shape}    │ Profiling only          │
├──────────────────────────────────────────────────────────────────────────────┤
│  M2 DQ Proc    │ df_cleaned      │ {m2_shape}    │ 12-step cleanse         │
│  M3 Preproc    │ encoded_master  │ {m3_shape}    │ 100% float matrix       │
│  M4 Scaling    │ scaled_matrices │ 6×{m4_shape}    │ 6 scaler versions     │
│  M5 Reduction  │ X (PreMaster)   │ {m5_shape}    │ Reduced dims → L5       │
├──────────────────────────────────────────────────────────────────────────────┤
│  L5 Detection  │ score_matrix    │ N × M          │ 26 method scores        │
│  L6 Ensemble   │ final_scores    │ [N]            │ Fused risk scores       │
│  L7 Output     │ df_scored       │ N×(K'+M+2)     │ + anomaly_score +       │
│                │                 │                │   risk_tier + score_*   │
└──────────────────────────────────────────────────────────────────────────────┘
""".format(
    base_shape=f"{schema['BASE'].shape[0]}×{schema['BASE'].shape[1]}",
    l12_shape=f"{merged_df.shape[0]}×{merged_df.shape[1]}",
    m1_shape=f"{merged_df.shape[0]}×{merged_df.shape[1]}",
    v6_shape=f"{df.shape[0]}×{df.shape[1]}" if 'df' in dir() else "?",
    l3_shape=f"{df.shape[0]}×{df.shape[1]}" if 'df' in dir() else "?",
    v8_shape=f"{df.shape[0]}×{df.shape[1]}" if 'df' in dir() else "?",
    m2_shape=f"{df_cleaned.shape[0]}×{df_cleaned.shape[1]}",
    m3_shape=f"{encoded_master.shape[0]}×{encoded_master.shape[1]}",
    m4_shape=f"{m4_result.input_shape[0]}×{m4_result.input_shape[1]}",
    m5_shape=f"{X.shape[0]}×{X.shape[1]}",
))


# =====================================================================
# ANSWER TO QUESTION 2: What is the FINAL output of Data Sources page?
# =====================================================================
print(f"{'#'*100}")
print(f"  ANSWER: FINAL OUTPUT OF DATA SOURCES PAGE")
print(f"{'#'*100}")
print("""
★ The Data Sources page produces TWO persisted outputs:

  1. vault/sources/MASTER.parquet  ← RollupEngine output (spec-driven rollup + LEFT JOIN)
  2. vault/current.parquet         ← Simple merged BASE table (naive LEFT JOIN)

★ What pipeline_run.py READS:
  - merged_df = data_vault.get_data()  → reads vault/current.parquet
  - sources   = data_vault.load_sources() → reads vault/sources/*.parquet

★ Inside pipeline.run():
  - When merged_df is provided → df = merged_df (the BASE table from vault/current.parquet)
  - The individual sources dict is effectively IGNORED for the main data flow

★ So the FINAL usable output is:
  ┌──────────────────────────────────────────────────────────────────────┐
  │  vault/current.parquet = BASE TABLE (customer-level, pre-aggregated)│
  │  This is the MASTER file — the starting point of the pipeline.      │
  │  It is NOT df_cleaned, NOT encoded_master, NOT customer_aggregate.  │
  │  It IS the BASE table with party info + txn/account/alert/case aggs.│
  └──────────────────────────────────────────────────────────────────────┘

★ The pipeline then transforms it through:
  BASE → (L1-2 DQ) → (M1 validate) → (V6 cust agg) → (L3 features) → 
  df_cleaned (M2) → encoded_master (M3) → scaled_matrices (M4) →
  X/PreMaster (M5) → score_matrix (L5) → final_scores (L6) → df_scored (L7)
""")

print("\n✅ Trace complete.")
