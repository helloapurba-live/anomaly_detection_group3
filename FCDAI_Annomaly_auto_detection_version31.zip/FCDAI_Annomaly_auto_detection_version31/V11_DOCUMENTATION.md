# AIM AI Vault — FCDAI V11 Enhancement Documentation

## Version 11.0.0 — Enhancement Release

**System**: AIM AI Vault — FCDAI Anomaly Auto Detection  
**Platform**: Windows 11, Local Air-Gapped Deployment  
**Framework**: Dash + Dash Mantine Components 2.5.1 + AG Grid + Plotly  
**Python**: 3.11.13 (Anaconda `ai311` environment)  
**Port**: 8071 (http://127.0.0.1:8071)  

---

## Compliance & Constraints

| Constraint | Implementation |
|---|---|
| **Zero PII Leakage** | SHA-256 hashed entity IDs in all reports, masked columns in exports |
| **Air-Gapped** | No network calls, no cloud APIs, `serve_locally=True`, blocked CDN patterns |
| **Bank Audit-Proof** | All config changes logged to `config_snapshots` table, all backups logged to `db_backups` table |
| **No "SAR" Terminology** | Replaced with "narrative" throughout all UI and reports |
| **Offline Only** | Cron parsing done locally (no croniter), HTML reports via string templates (no Jinja2) |
| **Windows 11 Compatible** | File paths use `pathlib`, disk checks handle Windows drives |

---

## Enhancement Summary

### Skipped (per user request)
- **#1–#4**: Security Hardening (not requested)
- **#10**: Webhook Integration (requires network — violates air-gapped)

### Implemented (15 Enhancements)

---

### #5 — Live Customer Aggregate Table (Pipeline Run Page)

**File**: `pages/pipeline_run.py`  
**Route**: `/pipeline`

Converted static layout to dynamic `def layout(**kwargs)` with:
- `_load_aggregate()` — builds customer-level aggregate from available data sources
- `_build_grid()` — AG Grid preview of customer data
- Smart default: selects "actual" data if available, falls back to "sample"
- 3 badges: "7 Layers", "26 Methods", "8 Categories"

---

### #6 — Pipeline Run History

**File**: `pages/run_history.py` (NEW)  
**Route**: `/run-history`

- AG Grid showing all pipeline runs with status, duration, anomaly counts
- Reads from `pipeline_runs` SQLite table via SQLAlchemy

---

### #7 — Scheduled Pipeline Runs

**File**: `pages/run_history.py` (shared with #6)

- Schedule creation form: name, cron expression, data source
- `_parse_simple_cron()` — offline cron parser (no external library)
- Stores schedules in `scheduled_runs` table
- Schedules display in AG Grid with enable/disable capability

---

### #8 — Pipeline Run Export (CSV)

**File**: `pages/run_history.py` (shared with #6)

- "Export Last Run" — downloads anomalies from most recent run as CSV
- "Export All Runs" — downloads all run metadata as CSV
- Uses `dcc.Download` for browser-side file download
- PII-safe: entity IDs can be masked in config

---

### #9 — On-Screen Alert Center

**File**: `pages/alert_center.py` (NEW)  
**Route**: `/alerts`

- 4 tier stat cards: CRITICAL/HIGH/MEDIUM/LOW alert counts
- Alert event AG Grid with selection checkboxes
- Acknowledge button: marks selected alerts as acknowledged in DB
- 30-second auto-refresh interval
- New DB table: `alert_events`

---

### #11 — HTML Report Generator

**File**: `pages/report_generator.py` (NEW)  
**Route**: `/reports`

- Offline HTML report generation using pure string formatting (no Jinja2)
- Run selection, tier filtering, report type selection
- SHA-256 file integrity hash computed and stored
- Reports saved to `data/reports/` directory
- Report metadata logged to `investigation_reports` table
- Download button for generated reports
- Past reports archive in AG Grid

---

### #12 — Narrative Compliance Template

**File**: `pages/report_generator.py` (shared with #11)

- "Narrative" report type (NOT "SAR" — per user requirement)
- Includes methodology description section
- Entity detail tables with masked IDs
- Tier summary statistics
- Classification banner: "CONFIDENTIAL — INTERNAL USE ONLY"

---

### #13 — Regulatory Dashboard

**File**: `pages/regulatory_dashboard.py` (NEW)  
**Route**: `/regulatory`

7 KPI cards:
- Total Entities Screened
- CRITICAL/HIGH Detections
- Confirmed Anomalies + Confirmation Rate
- Pipeline Runs count
- Audit Log Entries

3 Charts:
- Risk Tier Distribution (horizontal bar)
- Anomalies per Run Timeline (scatter)
- Unconfirmed Alert Aging Analysis (bucketed bar: <1d, 1-7d, 7-30d, 30-90d, 90d+)

---

### #14 — Graph Network Visualization

**File**: `pages/graph_network.py` (NEW)  
**Route**: `/graph`

- Entity relationship graph using pure Plotly scatter (no Cytoscape dependency)
- Nodes = entities flagged by pipeline; edges = ≥2 shared detection methods
- Simple force-directed layout (spring embedding + repulsion)
- Node color = risk tier; node size = vote count
- 3 stat cards: entities in graph, relationships, avg methods/entity
- Color-coded legend for risk tiers
- Limited to 500 entities for performance

---

### #15 — Real-Time Config Editor

**File**: `pages/config_panel.py` (MODIFIED)  
**Route**: `/config`

New "EDIT (V11)" tab added with:
- 9 editable runtime parameters:
  - Ensemble Flag Threshold, Investigation Capacity, Contamination Rate
  - PII Masking Enabled, PII Visible Characters
  - Alert CRITICAL/HIGH Thresholds
  - Drift PSI Threshold
  - Max Customers per Report
- Mandatory "reason" field for audit compliance
- Changes applied to runtime config objects (not persisted to disk — air-gapped safety)
- All changes logged to `config_snapshots` table with old/new values + reason
- Change history displayed in the panel

---

### #16 — Database Backup/Restore UI

**File**: `pages/admin.py` (MODIFIED)  
**Route**: `/admin` → "Backup / Restore (V11)" tab

- One-click "Create Backup" button
- SQLite file copy to `data/backups/` with timestamp
- SHA-256 integrity hash computed and stored
- Optional notes field
- All backup events logged to `db_backups` table
- Backup history AG Grid showing: action, file, hash, size, timestamp, notes

---

### #17 — Dark/Light Mode Auto-Detect

**File**: `app.py` (MODIFIED)

- Clientside callback detects OS `prefers-color-scheme` preference
- First-visit users automatically get `premium_white` theme on light OS, `system` (Sentinel Dark) on dark OS
- Subsequent visits honor stored theme preference
- No performance impact (runs client-side in browser)

---

### #18 — Model Drift Monitoring

**File**: `pages/drift_monitor.py` (NEW)  
**Route**: `/drift`

- Score distribution tracking across pipeline runs
- KPI cards: snapshots count, methods tracked, runs compared
- PSI (Population Stability Index) calculation — offline implementation
- KS-test (Kolmogorov-Smirnov) statistic — offline implementation (no scipy)
- Baseline vs Current run comparison tool
- Drift status indicators: Stable / Warning / DRIFT DETECTED
- Mean score trend chart by detection method
- Score standard deviation trend chart
- Uses `drift_snapshots` table for persistent tracking
- Configurable thresholds via `DriftConfig` (PSI: 0.20, KS alpha: 0.05)

---

### #19 — Feature Importance Trends

**File**: `pages/feature_trends.py` (NEW)  
**Route**: `/feature-trends`

- Analyzes method "firing rates" (fraction of anomalies flagged by each method per run)
- KPI cards: runs analyzed, methods tracked, most active method
- Top-10 method fire rate trend line chart
- Configured method weights bar chart (from `config.py`)
- Method-vs-Run heatmap of firing rates
- Reads from `anomalies` table, parses `method_flags` JSON

---

### #20 — What-If Simulator

**File**: `pages/what_if.py` (NEW)  
**Route**: `/what-if`

10 adjustable scenario parameters:
- Transaction Volume, Average Amount, Max Amount
- Unique Counterparties, Round Amount %, Cross-Border %
- High-Risk Jurisdiction %
- Rapid Movement, Structuring Pattern, Dormancy Reactivation (boolean flags)

Real-time risk calculation:
- Heuristic scoring for each detection method category
- Weighted ensemble using configured `METHOD_WEIGHTS`
- Risk tier assignment using configured `RISK_TIERS`
- Plotly gauge chart for ensemble score
- Per-method horizontal bar chart with color coding
- Vote count display
- No data persisted — purely exploratory tool

---

## New Database Tables (V11)

| Table | Purpose |
|---|---|
| `scheduled_runs` | Recurring pipeline schedules (offline cron) |
| `alert_events` | On-screen critical alert history |
| `investigation_reports` | Generated narrative/report metadata |
| `drift_snapshots` | Per-run score distribution snapshots |
| `config_snapshots` | Config editor audit trail |
| `db_backups` | Backup/restore event log |

---

## New Configuration Classes (V11)

| Class | Key Settings |
|---|---|
| `SchedulerConfig` | ENABLED, CHECK_INTERVAL_SEC=60, MAX_CONCURRENT_RUNS=1 |
| `AlertConfig` | CRITICAL_THRESHOLD=0.95, HIGH_THRESHOLD=0.85, PERSIST_ALERTS=True |
| `ReportConfig` | OUTPUT_DIR="data/reports", INCLUDE_PII=False, RETENTION_DAYS=365 |
| `DriftConfig` | MIN_RUNS_FOR_DRIFT=3, KS_TEST_ALPHA=0.05, PSI_THRESHOLD=0.20 |

---

## Updated Sidebar Navigation

### WORKFLOW
- Dashboard `/`
- Data Sources `/sources`
- Execution Engine `/pipeline`
- Layer View `/layers`
- **Run History** `/run-history` (NEW)
- **Alert Center** `/alerts` (NEW)

### RESULTS
- Investigation Queue `/queue`
- Narratives `/narratives`
- **Report Generator** `/reports` (NEW)
- Audit Trail `/audit`
- **Regulatory Dashboard** `/regulatory` (NEW)

### ADVANCED ANALYTICS
- Audit Vault (AG Grid) `/audit-vault`
- Model Diagnostics `/diagnostics`
- Explainability `/explainability`
- **Graph Network** `/graph` (NEW)
- **Drift Monitor** `/drift` (NEW)
- **Feature Trends** `/feature-trends` (NEW)
- **What-If Simulator** `/what-if` (NEW)

### ADMIN
- Task Manager `/tasks`
- Admin Panel `/admin` (backup/restore added)
- **Configuration** `/config` (editor added)

---

## Files Modified/Created

### Modified
1. `config.py` — V11 version bump, 4 new config dataclasses
2. `database/models.py` — 6 new ORM tables
3. `pages/pipeline_run.py` — Dynamic layout with live aggregate (#5)
4. `pages/config_panel.py` — Real-time config editor with audit trail (#15)
5. `pages/admin.py` — Backup/restore tab (#16)
6. `app.py` — V11 sidebar, dark/light auto-detect (#17), startup banner

### Created (NEW)
7. `pages/run_history.py` — Run history + scheduler + export (#6,7,8)
8. `pages/alert_center.py` — Alert center (#9)
9. `pages/report_generator.py` — Report generator + narrative (#11,12)
10. `pages/regulatory_dashboard.py` — Regulatory dashboard (#13)
11. `pages/graph_network.py` — Graph network visualization (#14)
12. `pages/drift_monitor.py` — Model drift monitoring (#18)
13. `pages/feature_trends.py` — Feature importance trends (#19)
14. `pages/what_if.py` — What-if simulator (#20)
15. `V11_DOCUMENTATION.md` — This documentation file

---

## Default Login Credentials

| Username | Password | Role |
|---|---|---|
| admin | admin123 | Full access |
| investigator | invest123 | Run & review |
| viewer | view123 | Read-only |

---

## Running the Application

```bash
cd FCDAI_Annomaly_auto_detection_version11
C:\ProgramData\anaconda3\envs\ai311\python.exe app.py
```

Open browser: http://127.0.0.1:8071
