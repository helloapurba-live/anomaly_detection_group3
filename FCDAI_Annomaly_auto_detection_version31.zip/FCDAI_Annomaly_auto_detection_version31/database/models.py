"""
FCDAI V27 — SQLAlchemy ORM Models (Bank Audit Hardened)
==========================================================
Persistent relational schema for AIM AI Vault.

V27 Enhancements:
  - feature_importances    — Per-method feature importance per run (C1)
  - data_quality_metrics   — DQ stats per column per run (C2)
  - model_performances     — Model performance metrics per run (C3)
  - anomaly_method_scores  — Normalized per-anomaly-per-method scores (C4)
  - entity_graph_metrics   — Graph centrality metrics per entity per run (C5)
  - method_execution_logs  — Method-level execution telemetry per run (C6)

V16 Enhancements (retained):
  - pii_access_logs  — Audit every PII column access (A4 / FM-006)
  - hash_verifications — Hash chain integrity check results (A6 / FM-007)
  - Enhanced audit_logs with pii_columns_accessed field

V13 Fixes:
  - S-6: audit_logs table has created_at index for efficient archival
  - Added archive_audit_logs() utility for partitioned cleanup

Tables (V27: 19 total)
------
  users                  – Authentication & RBAC
  audit_logs             – Tamper-evident action log (hash-chained)
  anomalies              – Detection results flagged by the pipeline
  pipeline_runs          – Execution history with status tracking
  data_imports           – Provenance for every uploaded / generated dataset
  scheduled_runs         – Recurring pipeline schedules (offline cron)
  alert_events           – On-screen critical alert history
  investigation_reports  – Generated narrative/report metadata
  drift_snapshots        – Per-run score distribution snapshots for drift detection
  config_snapshots       – Config editor save history (audit-proof)
  db_backups             – Backup/restore event log
  pii_access_logs        – PII column access audit (A4)
  hash_verifications     – Hash chain integrity check results (A6)
  V27 NEW:
  feature_importances    – Per-method feature importance per run (C1)
  data_quality_metrics   – DQ column-level stats per run (C2)
  model_performances     – Model performance metrics per run (C3)
  anomaly_method_scores  – Normalized per-method scores per anomaly (C4)
  entity_graph_metrics   – Graph centrality per entity per run (C5)
  method_execution_logs  – Method-level telemetry per run (C6)
"""

from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Float, Boolean, Text, DateTime,
    ForeignKey, Index,
)
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


# ═══════════════════════════════════════════════════════════════════════
# USERS
# ═══════════════════════════════════════════════════════════════════════
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(64), unique=True, nullable=False, index=True)
    password_hash = Column(String(256), nullable=False)
    full_name = Column(String(128))
    role = Column(String(20), nullable=False, default="investigator")  # admin | investigator | viewer
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime)

    # Flask-Login integration
    @property
    def is_authenticated(self):
        return True

    @property
    def is_anonymous(self):
        return False

    def get_id(self):
        return str(self.id)

    def __repr__(self):
        return f"<User {self.username} ({self.role})>"


# ═══════════════════════════════════════════════════════════════════════
# AUDIT LOGS
# ═══════════════════════════════════════════════════════════════════════
class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    username = Column(String(64), default="system")
    action = Column(String(128), nullable=False)
    status = Column(String(20), default="SUCCESS")
    details = Column(Text)
    metadata_json = Column(Text)
    hash_chain = Column(String(64))
    client_ip = Column(String(45), default="127.0.0.1")   # V10: IPv4/IPv6
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    user = relationship("User", backref="audit_logs", lazy="select")

    __table_args__ = (
        Index("ix_audit_action", "action"),
    )


# ═══════════════════════════════════════════════════════════════════════
# ANOMALIES  (scored rows flagged by the pipeline)
# ═══════════════════════════════════════════════════════════════════════
class Anomaly(Base):
    __tablename__ = "anomalies"

    id = Column(Integer, primary_key=True, autoincrement=True)
    run_id = Column(String(16), nullable=False, index=True)
    row_index = Column(Integer)
    entity_id = Column(String(64))
    anomaly_score = Column(Float)
    risk_tier = Column(String(20))
    method_flags = Column(Text)          # JSON list of flagging methods
    ensemble_score = Column(Float)
    vote_count = Column(Integer)
    is_confirmed = Column(Boolean, default=False)
    confirmed_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    confirmed_at = Column(DateTime, nullable=True)
    notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

    confirmer = relationship("User", backref="confirmed_anomalies", lazy="select")

    __table_args__ = (
        Index("ix_anomaly_tier", "risk_tier"),
        Index("ix_anomaly_confirmed", "is_confirmed"),
    )


# ═══════════════════════════════════════════════════════════════════════
# PIPELINE RUNS
# ═══════════════════════════════════════════════════════════════════════
class PipelineRun(Base):
    __tablename__ = "pipeline_runs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    run_id = Column(String(16), unique=True, nullable=False, index=True)
    status = Column(String(20), default="pending")  # pending | running | completed | failed
    progress = Column(Integer, default=0)
    total_steps = Column(Integer, default=7)
    current_step = Column(String(128))
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    started_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    config_json = Column(Text)
    result_json = Column(Text)
    error_message = Column(Text)
    input_hash = Column(String(128))
    n_anomalies = Column(Integer, default=0)
    duration_sec = Column(Float)

    starter = relationship("User", backref="pipeline_runs", lazy="select")


# ═══════════════════════════════════════════════════════════════════════
# DATA IMPORTS
# ═══════════════════════════════════════════════════════════════════════
class DataImport(Base):
    __tablename__ = "data_imports"

    id = Column(Integer, primary_key=True, autoincrement=True)
    filename = Column(String(256))
    table_slot = Column(String(64))
    row_count = Column(Integer)
    col_count = Column(Integer)
    file_hash = Column(String(128))
    imported_at = Column(DateTime, default=datetime.utcnow)
    imported_by = Column(Integer, ForeignKey("users.id"), nullable=True)

    importer = relationship("User", backref="data_imports", lazy="select")


# ═══════════════════════════════════════════════════════════════════════
# V11: SCHEDULED RUNS  (offline cron-style recurring pipeline)
# ═══════════════════════════════════════════════════════════════════════
class ScheduledRun(Base):
    __tablename__ = "scheduled_runs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(128), nullable=False)
    cron_expression = Column(String(64), nullable=False)   # e.g. "0 2 * * *"
    data_source = Column(String(20), default="actual")     # actual | sample
    ensemble_method = Column(String(64), default="weighted_average")
    categories_json = Column(Text)                          # JSON list of categories
    is_active = Column(Boolean, default=True)
    last_run_at = Column(DateTime, nullable=True)
    next_run_at = Column(DateTime, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    total_runs = Column(Integer, default=0)

    creator = relationship("User", backref="scheduled_runs", lazy="select")


# ═══════════════════════════════════════════════════════════════════════
# V11: ALERT EVENTS  (on-screen critical detection alerts)
# ═══════════════════════════════════════════════════════════════════════
class AlertEvent(Base):
    __tablename__ = "alert_events"

    id = Column(Integer, primary_key=True, autoincrement=True)
    run_id = Column(String(16), nullable=False, index=True)
    entity_id = Column(String(64))
    risk_tier = Column(String(20), nullable=False)
    anomaly_score = Column(Float)
    alert_type = Column(String(64), default="CRITICAL_DETECTION")
    message = Column(Text)
    is_acknowledged = Column(Boolean, default=False)
    acknowledged_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    acknowledged_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    acknowledger = relationship("User", backref="acknowledged_alerts", lazy="select")

    __table_args__ = (
        Index("ix_alert_tier", "risk_tier"),
        Index("ix_alert_ack", "is_acknowledged"),
    )


# ═══════════════════════════════════════════════════════════════════════
# V11: INVESTIGATION REPORTS  (generated narrative/compliance reports)
# ═══════════════════════════════════════════════════════════════════════
class InvestigationReport(Base):
    __tablename__ = "investigation_reports"

    id = Column(Integer, primary_key=True, autoincrement=True)
    report_id = Column(String(32), unique=True, nullable=False, index=True)
    report_type = Column(String(64), default="narrative")  # narrative | compliance | regulatory
    run_id = Column(String(16), nullable=True)
    entity_ids_json = Column(Text)              # JSON list of entity IDs covered
    n_entities = Column(Integer, default=0)
    file_path = Column(String(512))             # Local path to generated file
    file_format = Column(String(10), default="html")  # html | pdf
    file_hash = Column(String(128))             # SHA-256 of generated file
    classification = Column(String(128), default="CONFIDENTIAL")
    generated_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    generated_at = Column(DateTime, default=datetime.utcnow)
    notes = Column(Text)

    generator = relationship("User", backref="generated_reports", lazy="select")


# ═══════════════════════════════════════════════════════════════════════
# V11: DRIFT SNAPSHOTS  (score distributions per run for drift detection)
# ═══════════════════════════════════════════════════════════════════════
class DriftSnapshot(Base):
    __tablename__ = "drift_snapshots"

    id = Column(Integer, primary_key=True, autoincrement=True)
    run_id = Column(String(16), nullable=False, index=True)
    method_name = Column(String(64), nullable=False)
    n_scores = Column(Integer)
    mean_score = Column(Float)
    std_score = Column(Float)
    median_score = Column(Float)
    p25 = Column(Float)
    p75 = Column(Float)
    histogram_json = Column(Text)    # JSON: [bin_edges, counts]
    created_at = Column(DateTime, default=datetime.utcnow)


# ═══════════════════════════════════════════════════════════════════════
# V11: CONFIG SNAPSHOTS  (audit-proof config editor history)
# ═══════════════════════════════════════════════════════════════════════
class ConfigSnapshot(Base):
    __tablename__ = "config_snapshots"

    id = Column(Integer, primary_key=True, autoincrement=True)
    section = Column(String(64), nullable=False)   # e.g. "LAYERS", "PII", "AUDIT"
    key = Column(String(128), nullable=False)
    old_value = Column(Text)
    new_value = Column(Text)
    changed_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    changed_at = Column(DateTime, default=datetime.utcnow)
    reason = Column(Text)

    changer = relationship("User", backref="config_changes", lazy="select")


# ═══════════════════════════════════════════════════════════════════════
# V11: DB BACKUP LOG  (backup/restore event tracking)
# ═══════════════════════════════════════════════════════════════════════
class DbBackup(Base):
    __tablename__ = "db_backups"

    id = Column(Integer, primary_key=True, autoincrement=True)
    action = Column(String(20), nullable=False)   # backup | restore
    file_path = Column(String(512))
    file_hash = Column(String(128))
    file_size_bytes = Column(Integer)
    db_tables_json = Column(Text)          # JSON list of tables included
    performed_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    performed_at = Column(DateTime, default=datetime.utcnow)
    notes = Column(Text)

    performer = relationship("User", backref="db_backups", lazy="select")


# ═══════════════════════════════════════════════════════════════════════
# V16: PII ACCESS LOG  (A4: audit every PII column access)
# ═══════════════════════════════════════════════════════════════════════
class PIIAccessLog(Base):
    """V16: Records every access to PII-flagged columns for regulatory audit.
    
    Tracks which function accessed which PII columns, how many rows were
    exposed, and whether masking was applied. Required by bank MRM policy
    for data sovereignty compliance.
    """
    __tablename__ = "pii_access_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    caller = Column(String(128), nullable=False)       # Calling function/module
    columns_accessed = Column(Text, nullable=False)     # JSON list of PII columns
    n_rows = Column(Integer, default=0)                 # Rows in DataFrame
    masking_applied = Column(Boolean, default=True)     # Was masking active?
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    username = Column(String(64), default="system")
    client_ip = Column(String(45), default="127.0.0.1")
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    user = relationship("User", backref="pii_access_logs", lazy="select")

    __table_args__ = (
        Index("ix_pii_access_caller", "caller"),
        Index("ix_pii_access_created", "created_at"),
    )


# ═══════════════════════════════════════════════════════════════════════
# V16: HASH CHAIN VERIFICATION LOG  (A6: integrity check results)
# ═══════════════════════════════════════════════════════════════════════
class HashVerification(Base):
    """V16: Records hash chain integrity verification results.
    
    Stores the result of verify_hash_chain() calls (manual or scheduled)
    so auditors can confirm tamper-evidence continuity over time.
    """
    __tablename__ = "hash_verifications"

    id = Column(Integer, primary_key=True, autoincrement=True)
    status = Column(String(20), nullable=False)         # PASS / FAIL / DEGRADED / ERROR
    entries_checked = Column(Integer, default=0)
    mismatches = Column(Integer, default=0)              # Count of mismatched entries
    mismatch_lines = Column(Text)                        # JSON list of line numbers
    current_hash = Column(String(64))                    # In-memory hash at check time
    disk_hash = Column(String(64))                       # Hash on disk at check time
    triggered_by = Column(String(64), default="manual")  # manual | scheduled | startup
    verified_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    verified_at = Column(DateTime, default=datetime.utcnow, index=True)
    notes = Column(Text)

    verifier = relationship("User", backref="hash_verifications", lazy="select")

    __table_args__ = (
        Index("ix_hashver_status", "status"),
    )


# ═══════════════════════════════════════════════════════════════════════
# V27 C1: FEATURE IMPORTANCES  (per-method feature importance per run)
# ═══════════════════════════════════════════════════════════════════════
class FeatureImportance(Base):
    """V27 C1: Stores per-method mean|SHAP| or permutation importance per feature per run.

    Enables cross-run comparison of which features drive each detection method.
    """
    __tablename__ = "feature_importances"

    id = Column(Integer, primary_key=True, autoincrement=True)
    run_id = Column(String(16), nullable=False, index=True)
    method_name = Column(String(64), nullable=False)
    feature_name = Column(String(128), nullable=False)
    importance_score = Column(Float, nullable=False)
    rank = Column(Integer)
    explainer_type = Column(String(32))   # tree | kernel | permutation_fallback
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("ix_featimp_run_method", "run_id", "method_name"),
    )


# ═══════════════════════════════════════════════════════════════════════
# V27 C2: DATA QUALITY METRICS  (column-level DQ stats per run)
# ═══════════════════════════════════════════════════════════════════════
class DataQualityMetric(Base):
    """V27 C2: Persists column-level DQ statistics per pipeline run.

    Completeness, uniqueness, basic stats, outlier counts — enables
    DQ trend tracking across runs.
    """
    __tablename__ = "data_quality_metrics"

    id = Column(Integer, primary_key=True, autoincrement=True)
    run_id = Column(String(16), nullable=False, index=True)
    column_name = Column(String(128), nullable=False)
    completeness = Column(Float)          # 1.0 - missing_pct
    uniqueness = Column(Float)            # n_unique / n_rows
    mean_value = Column(Float)
    std_value = Column(Float)
    min_value = Column(Float)
    max_value = Column(Float)
    skewness = Column(Float)
    kurtosis = Column(Float)
    n_outliers = Column(Integer)           # Count > 3σ
    n_zeros = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("ix_dqmetric_run", "run_id"),
    )


# ═══════════════════════════════════════════════════════════════════════
# V27 C3: MODEL PERFORMANCES  (per-method performance per run)
# ═══════════════════════════════════════════════════════════════════════
class ModelPerformance(Base):
    """V27 C3: Tracks model performance metrics per method per run.

    Since anomaly detection is unsupervised, stores proxy metrics:
    anomaly rate, score spread, ensemble agreement, etc.
    """
    __tablename__ = "model_performances"

    id = Column(Integer, primary_key=True, autoincrement=True)
    run_id = Column(String(16), nullable=False, index=True)
    method_name = Column(String(64), nullable=False)
    n_flagged = Column(Integer)            # Entities flagged by this method
    anomaly_rate = Column(Float)           # n_flagged / n_total
    mean_score = Column(Float)
    std_score = Column(Float)
    max_score = Column(Float)
    score_p95 = Column(Float)
    ensemble_agreement = Column(Float)     # Fraction where this method agrees with ensemble
    silhouette_proxy = Column(Float)       # Cluster quality proxy (if available)
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("ix_modperf_run_method", "run_id", "method_name"),
    )


# ═══════════════════════════════════════════════════════════════════════
# V27 C4: ANOMALY METHOD SCORES  (normalized per-anomaly per-method)
# ═══════════════════════════════════════════════════════════════════════
class AnomalyMethodScore(Base):
    """V27 C4: Replaces opaque method_flags JSON with relational per-method scores.

    Each row = one anomaly × one detection method. Enables filter/sort
    by individual method contribution to final risk.
    """
    __tablename__ = "anomaly_method_scores"

    id = Column(Integer, primary_key=True, autoincrement=True)
    anomaly_id = Column(Integer, ForeignKey("anomalies.id"), nullable=False, index=True)
    run_id = Column(String(16), nullable=False, index=True)
    method_name = Column(String(64), nullable=False)
    raw_score = Column(Float)
    normalized_score = Column(Float)       # 0-1 scaled
    is_flagged = Column(Boolean, default=False)
    rank_in_method = Column(Integer)       # Rank of this entity within this method's scores
    created_at = Column(DateTime, default=datetime.utcnow)

    anomaly = relationship("Anomaly", backref="method_scores", lazy="select")

    __table_args__ = (
        Index("ix_ams_run_method", "run_id", "method_name"),
    )


# ═══════════════════════════════════════════════════════════════════════
# V27 C5: ENTITY GRAPH METRICS  (graph centrality per entity per run)
# ═══════════════════════════════════════════════════════════════════════
class EntityGraphMetric(Base):
    """V27 C5: Persists graph-based centrality metrics per entity per run.

    PageRank, betweenness, closeness, eigenvector centrality, community ID.
    Enables network analysis dashboards and cross-run graph evolution.
    """
    __tablename__ = "entity_graph_metrics"

    id = Column(Integer, primary_key=True, autoincrement=True)
    run_id = Column(String(16), nullable=False, index=True)
    entity_id = Column(String(64), nullable=False)
    entity_index = Column(Integer)
    pagerank = Column(Float)
    betweenness = Column(Float)
    closeness = Column(Float)
    eigenvector = Column(Float)
    degree = Column(Integer)
    community_id = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("ix_graphmetric_run_entity", "run_id", "entity_id"),
    )


# ═══════════════════════════════════════════════════════════════════════
# V27 C6: METHOD EXECUTION LOGS  (telemetry per method per run)
# ═══════════════════════════════════════════════════════════════════════
class MethodExecutionLog(Base):
    """V27 C6: Records execution telemetry for each detection method per run.

    Duration, status, sample counts, skip reasons, circuit breaker state,
    and memory usage. Enables performance regression tracking.
    """
    __tablename__ = "method_execution_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    run_id = Column(String(16), nullable=False, index=True)
    method_name = Column(String(64), nullable=False)
    status = Column(String(20), nullable=False)   # success | failed | skipped | cb_open
    duration_ms = Column(Float)
    n_input_rows = Column(Integer)
    n_flags = Column(Integer)                      # Entities flagged
    skip_reason = Column(String(128))              # Why skipped (circuit_breaker, data_too_small, etc.)
    circuit_breaker_state = Column(String(20))     # closed | open | half_open
    memory_peak_mb = Column(Float)
    error_type = Column(String(128))               # Exception class name if failed
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("ix_methodexec_run", "run_id"),
        Index("ix_methodexec_status", "status"),
    )


# ═══════════════════════════════════════════════════════════════════════
# V13 S-6: AUDIT LOG ARCHIVAL
# ═══════════════════════════════════════════════════════════════════════
def archive_audit_logs(retention_days: int = 365):
    """
    V13 S-6: Archive (delete) audit_logs older than retention_days.

    Call periodically from admin panel or scheduled task.
    Returns the number of rows archived.
    """
    from database.engine import get_session
    from datetime import timedelta

    cutoff = datetime.utcnow() - timedelta(days=retention_days)
    session = get_session()
    try:
        count = session.query(AuditLog).filter(AuditLog.created_at < cutoff).delete()
        session.commit()
        return count
    except Exception:
        session.rollback()
        return 0
    finally:
        session.close()
