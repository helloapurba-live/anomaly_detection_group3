"""
FCDAI V14 — Database Module
==============================
Persistent SQLite backend with SQLAlchemy ORM.
WAL mode enabled for concurrent read/write.

Tables:
  - users          (authentication + RBAC)
  - audit_logs     (tamper-evident action log)
  - anomalies      (flagged detection results)
  - pipeline_runs  (run history + status tracking)
  - data_imports   (import provenance)
"""

from database.engine import get_engine, get_session, init_db
from database.models import User, AuditLog, Anomaly, PipelineRun, DataImport

__all__ = [
    "get_engine", "get_session", "init_db",
    "User", "AuditLog", "Anomaly", "PipelineRun", "DataImport",
]
