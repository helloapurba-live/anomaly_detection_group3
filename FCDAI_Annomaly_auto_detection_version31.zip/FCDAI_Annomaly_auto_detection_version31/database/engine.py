"""
FCDAI V14 — SQLAlchemy Engine + Session Factory
=================================================
SQLite with WAL mode for concurrent read/write.
Thread-safe scoped session for Dash multi-callback environment.

V13 Fixes:
  - F-1: Context-manager session pattern (auto-close on exit)
  - S-1: Write serialization with threading.Lock + retry/backoff for SQLITE_BUSY
  - Connection pool size limits for memory safety
"""

import sys
import time
import threading
import logging
from contextlib import contextmanager
from pathlib import Path
from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import sessionmaker, scoped_session

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PATHS

_db_logger = logging.getLogger("apurbadas.db")

# ---------------------------------------------------------------------------
# Database path
# ---------------------------------------------------------------------------
DB_PATH = PATHS.DATA / "sentinel_vault.db"
DB_URL = f"sqlite:///{DB_PATH}"

# ---------------------------------------------------------------------------
# S-1: Write serialization lock — prevents concurrent SQLITE_BUSY errors
# ---------------------------------------------------------------------------
_write_lock = threading.Lock()

# ---------------------------------------------------------------------------
# Engine — singleton
# ---------------------------------------------------------------------------
_engine = None


def get_engine():
    """Return (and lazily create) the global SQLAlchemy engine."""
    global _engine
    if _engine is None:
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        _engine = create_engine(
            DB_URL,
            echo=False,
            connect_args={"check_same_thread": False},  # Required for Dash
            pool_pre_ping=True,
            pool_size=5,           # V13: Limit connection pool
            max_overflow=3,        # V13: Max overflow connections
            pool_recycle=1800,     # V13: Recycle connections after 30 min
        )
        # Enable WAL mode for concurrent reads/writes
        @event.listens_for(_engine, "connect")
        def _set_sqlite_pragma(dbapi_conn, connection_record):
            cursor = dbapi_conn.cursor()
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA synchronous=NORMAL")
            cursor.execute("PRAGMA busy_timeout=10000")   # V13: 10s busy timeout (was 5s)
            cursor.execute("PRAGMA cache_size=-64000")     # 64 MB page cache
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()

    return _engine


# ---------------------------------------------------------------------------
# Session factory — thread-safe scoped session
# ---------------------------------------------------------------------------
_SessionFactory = None


def get_session():
    """Return a new scoped session bound to the engine."""
    global _SessionFactory
    if _SessionFactory is None:
        engine = get_engine()
        factory = sessionmaker(bind=engine, expire_on_commit=False)
        _SessionFactory = scoped_session(factory)
    return _SessionFactory()


@contextmanager
def safe_session():
    """
    V13 F-1 FIX: Context-manager session that guarantees cleanup.

    Usage:
        with safe_session() as session:
            rows = session.query(Model).all()
            session.commit()  # if writing

    On exit the session is always closed (even on exception).
    On exception the session is rolled back first.
    """
    session = get_session()
    try:
        yield session
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


@contextmanager
def write_session():
    """
    V13 S-1 FIX: Serialized write session with retry/backoff.

    Acquires _write_lock so only one writer at a time.
    On SQLITE_BUSY, retries up to 3 times with exponential backoff.

    Usage:
        with write_session() as session:
            session.add(record)
            # commit is called automatically on clean exit
    """
    max_retries = 3
    for attempt in range(max_retries + 1):
        with _write_lock:
            session = get_session()
            try:
                yield session
                session.commit()
                return
            except Exception as exc:
                session.rollback()
                exc_str = str(exc).lower()
                if "database is locked" in exc_str or "busy" in exc_str:
                    if attempt < max_retries:
                        delay = 0.5 * (2 ** attempt)
                        _db_logger.warning(
                            f"SQLITE_BUSY — retry {attempt + 1}/{max_retries} in {delay:.1f}s"
                        )
                        time.sleep(delay)
                        continue
                raise
            finally:
                session.close()


# ---------------------------------------------------------------------------
# Init DB (create tables + seed admin)
# ---------------------------------------------------------------------------
def init_db():
    """Create all tables and seed the default admin user."""
    from database.models import Base, User
    engine = get_engine()
    Base.metadata.create_all(engine)

    # Seed default users if no users exist
    # V13: Passwords read from environment variables with fallback defaults
    # In production, set VAULT_ADMIN_PASS, VAULT_INVEST_PASS, VAULT_VIEWER_PASS
    session = get_session()
    try:
        if session.query(User).count() == 0:
            import os as _os
            from auth.manager import hash_password
            admin = User(
                username="admin",
                password_hash=hash_password(_os.environ.get("VAULT_ADMIN_PASS", "admin123")),
                full_name="System Administrator",
                role="admin",
                is_active=True,
            )
            investigator = User(
                username="investigator",
                password_hash=hash_password(_os.environ.get("VAULT_INVEST_PASS", "invest123")),
                full_name="Default Investigator",
                role="investigator",
                is_active=True,
            )
            viewer = User(
                username="viewer",
                password_hash=hash_password(_os.environ.get("VAULT_VIEWER_PASS", "view123")),
                full_name="Read-Only Viewer",
                role="viewer",
                is_active=True,
            )
            session.add_all([admin, investigator, viewer])
            session.commit()
    except Exception:
        session.rollback()
    finally:
        session.close()
