"""
AIM AI Vault V15 — API Test Suite
====================================
Tests for all 14+ REST API endpoints.

Run:
  python -m pytest tests/test_api.py -v
  make test

Requires: httpx (pip install httpx)

Author: AIM AI Vault Team
"""

import hashlib
import json
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))


# =============================================================================
# AUTH MODULE TESTS (no FastAPI needed)
# =============================================================================
class TestJWTAuth:
    """Test JWT token creation and verification."""

    def setup_method(self):
        from api.auth import init_api_auth
        init_api_auth("test_secret_key_for_unit_tests_only", 60)

    def test_create_jwt_returns_token(self):
        from api.auth import create_jwt
        token, expires_in = create_jwt("testuser", "admin")
        assert isinstance(token, str)
        assert len(token) > 0
        assert expires_in == 3600

    def test_verify_valid_jwt(self):
        from api.auth import create_jwt, verify_jwt
        token, _ = create_jwt("testuser", "investigator")
        payload = verify_jwt(token)
        assert payload is not None
        assert payload["sub"] == "testuser"
        assert payload["role"] == "investigator"

    def test_verify_invalid_jwt(self):
        from api.auth import verify_jwt
        result = verify_jwt("invalid.token.here")
        assert result is None

    def test_verify_tampered_jwt(self):
        from api.auth import create_jwt, verify_jwt
        token, _ = create_jwt("testuser", "admin")
        # Tamper with the token
        parts = token.split(".")
        if len(parts) == 3:
            tampered = parts[0] + "." + parts[1] + ".tampered_signature"
            result = verify_jwt(tampered)
            assert result is None

    def test_revoke_jwt(self):
        from api.auth import create_jwt, revoke_jwt, verify_jwt
        token, _ = create_jwt("testuser", "admin")
        assert verify_jwt(token) is not None
        revoke_jwt(token)
        assert verify_jwt(token) is None

    def test_jwt_contains_role(self):
        from api.auth import create_jwt, verify_jwt
        for role in ["admin", "investigator", "viewer"]:
            token, _ = create_jwt("user", role)
            payload = verify_jwt(token)
            assert payload["role"] == role


class TestAPIKeyAuth:
    """Test API key generation and verification."""

    def setup_method(self):
        from api.auth import init_api_auth
        init_api_auth("test_secret_key_for_api_key_tests", 60)

    def test_generate_api_key(self):
        from api.auth import generate_api_key
        plaintext, key_hash = generate_api_key("test_key", "viewer", 90)
        assert plaintext.startswith("aim_v15_")
        assert len(key_hash) == 64  # SHA-256 hex

    def test_verify_api_key(self):
        from api.auth import generate_api_key, verify_api_key
        plaintext, _ = generate_api_key("test_verify", "investigator", 90)
        result = verify_api_key(plaintext)
        assert result is not None
        assert result["role"] == "investigator"
        assert result["label"] == "test_verify"

    def test_verify_invalid_api_key(self):
        from api.auth import verify_api_key
        result = verify_api_key("aim_v15_nonexistent_key")
        assert result is None

    def test_revoke_api_key(self):
        from api.auth import generate_api_key, revoke_api_key, verify_api_key
        plaintext, key_hash = generate_api_key("revoke_test", "viewer", 90)
        assert verify_api_key(plaintext) is not None
        revoke_api_key(key_hash)
        assert verify_api_key(plaintext) is None

    def test_list_api_keys(self):
        from api.auth import generate_api_key, list_api_keys
        generate_api_key("list_test", "viewer", 90)
        keys = list_api_keys()
        assert isinstance(keys, list)
        assert len(keys) >= 1


# =============================================================================
# MIDDLEWARE TESTS
# =============================================================================
class TestPIIMasking:
    """Test PII auto-masking in responses."""

    def test_mask_pii_admin_gets_hash(self):
        from api.middleware import mask_pii_in_dict
        data = {"customer_name": "John Doe", "amount": 1000}
        masked = mask_pii_in_dict(data, "admin")
        assert masked["customer_name"] != "John Doe"
        assert masked["amount"] == 1000  # Non-PII unchanged

    def test_mask_pii_investigator_gets_partial(self):
        from api.middleware import mask_pii_in_dict
        data = {"sender_name": "Alice", "score": 0.95}
        masked = mask_pii_in_dict(data, "investigator")
        assert "***" in str(masked["sender_name"]) or masked["sender_name"] != "Alice"
        assert masked["score"] == 0.95

    def test_mask_pii_viewer_gets_redacted(self):
        from api.middleware import mask_pii_in_dict
        data = {"customer_name": "Bob Smith", "risk_tier": "HIGH"}
        masked = mask_pii_in_dict(data, "viewer")
        assert "REDACTED" in str(masked["customer_name"])
        assert masked["risk_tier"] == "HIGH"

    def test_non_pii_fields_unchanged(self):
        from api.middleware import mask_pii_in_dict
        data = {"anomaly_score": 0.87, "risk_tier": "HIGH", "layer": "L2"}
        for role in ["admin", "investigator", "viewer"]:
            masked = mask_pii_in_dict(data, role)
            assert masked["anomaly_score"] == 0.87
            assert masked["risk_tier"] == "HIGH"

    def test_nested_pii_masking(self):
        from api.middleware import mask_pii_in_dict
        data = {
            "entity": {
                "customer_name": "Jane",
                "score": 0.5,
            }
        }
        masked = mask_pii_in_dict(data, "viewer")
        assert "REDACTED" in str(masked["entity"]["customer_name"])


class TestRateLimiter:
    """Test rate limiting."""

    def test_rate_limiter_allows_within_limit(self):
        from api.middleware import RateLimiter
        rl = RateLimiter(max_requests=10, window_seconds=60)
        for _ in range(10):
            assert rl.check("test_client") is True

    def test_rate_limiter_blocks_over_limit(self):
        from api.middleware import RateLimiter
        rl = RateLimiter(max_requests=5, window_seconds=60)
        for _ in range(5):
            rl.check("over_client")
        assert rl.check("over_client") is False

    def test_rate_limiter_separate_clients(self):
        from api.middleware import RateLimiter
        rl = RateLimiter(max_requests=2, window_seconds=60)
        assert rl.check("client_a") is True
        assert rl.check("client_a") is True
        assert rl.check("client_a") is False
        assert rl.check("client_b") is True  # Different client OK


class TestRBAC:
    """Test role-based access control."""

    def test_admin_has_all_permissions(self):
        from api.middleware import check_permission
        permissions = [
            "pipeline:run", "results:scored", "audit:log",
            "system:health", "auth:revoke",
        ]
        for perm in permissions:
            assert check_permission("admin", perm) is True

    def test_viewer_limited_permissions(self):
        from api.middleware import check_permission
        # Viewer should have these
        assert check_permission("viewer", "system:health") is True
        assert check_permission("viewer", "results:risk_tiers") is True
        # Viewer should NOT have these
        assert check_permission("viewer", "pipeline:run") is False
        assert check_permission("viewer", "audit:log") is False

    def test_investigator_middle_permissions(self):
        from api.middleware import check_permission
        assert check_permission("investigator", "results:scored") is True
        assert check_permission("investigator", "results:alerts") is True
        assert check_permission("investigator", "pipeline:run") is False


# =============================================================================
# SCHEMA TESTS
# =============================================================================
class TestSchemas:
    """Test Pydantic schema validation."""

    def test_token_request_valid(self):
        from api.schemas import TokenRequest
        req = TokenRequest(username="analyst", password="secret123")
        assert req.username == "analyst"

    def test_token_request_missing_field(self):
        from api.schemas import TokenRequest
        with pytest.raises(Exception):
            TokenRequest(username="analyst")  # Missing password

    def test_risk_tier_enum(self):
        from api.schemas import RiskTier
        assert RiskTier.CRITICAL.value == "CRITICAL"
        assert RiskTier.NORMAL.value == "NORMAL"

    def test_api_response_defaults(self):
        from api.schemas import APIResponse
        resp = APIResponse()
        assert resp.success is True
        assert resp.error is None

    def test_health_response(self):
        from api.schemas import HealthResponse
        h = HealthResponse(
            status="healthy",
            version="15.0.0",
            version_tag="V15",
            uptime_seconds=3600.0,
        )
        assert h.status == "healthy"
        assert h.version == "15.0.0"


# =============================================================================
# INTEGRATION TESTS (require FastAPI test client)
# =============================================================================
class TestAPIIntegration:
    """Integration tests using FastAPI TestClient.

    These tests require httpx and a running project context.
    They are marked to be skipped if httpx is not available.
    """

    @pytest.fixture(autouse=True)
    def setup_client(self):
        try:
            from httpx import ASGITransport, AsyncClient
            from api.server import create_api_app
            self.app = create_api_app()
            self.has_httpx = True
        except ImportError:
            self.has_httpx = False

    @pytest.mark.skipif(
        not hasattr(pytest, "_httpx_available"),
        reason="httpx not available or project context not initialized",
    )
    def test_openapi_schema_accessible(self):
        """Verify /openapi.json is accessible."""
        if not self.has_httpx:
            pytest.skip("httpx not available")
        from fastapi.testclient import TestClient
        client = TestClient(self.app)
        response = client.get("/openapi.json")
        assert response.status_code == 200
        data = response.json()
        assert data["info"]["version"] == "15.0.0"

    @pytest.mark.skipif(
        not hasattr(pytest, "_httpx_available"),
        reason="httpx not available",
    )
    def test_unauthenticated_request_rejected(self):
        """Verify endpoints reject unauthenticated requests."""
        if not self.has_httpx:
            pytest.skip("httpx not available")
        from fastapi.testclient import TestClient
        client = TestClient(self.app)
        response = client.get("/api/v1/system/health")
        assert response.status_code in (401, 403)


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
