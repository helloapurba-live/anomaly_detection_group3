# Architecture

> **AIM AI Vault V15 — System Architecture**

---

## High-Level Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    USERS (Bank AML Team)                     │
├────────────────────┬────────────────────────────────────────┤
│   Web Dashboard    │         REST API                       │
│   (Port 8078)      │         (Port 8079)                    │
│   Dash + Mantine   │         FastAPI + Swagger              │
│   Flask-Login      │         JWT + API Key                  │
├────────────────────┴────────────────────────────────────────┤
│                    SERVICE LAYER                             │
│    PipelineService  │  DataService  │  AuthService           │
├─────────────────────────────────────────────────────────────┤
│                 7-LAYER DETECTION ENGINE                     │
│  L1: Statistical  │  L2: ML  │  L3: Deep  │  L4: Graph     │
│  L5: Temporal     │  L6: Ensemble         │  L7: Network    │
├─────────────────────────────────────────────────────────────┤
│                    DATA LAYER                                │
│  SQLite (WAL)  │  DataVault  │  Diskcache  │  CSV/Excel     │
├─────────────────────────────────────────────────────────────┤
│                INFRASTRUCTURE                                │
│  Waitress WSGI │ Uvicorn ASGI │ Watchdog │ Circuit Breaker  │
│  Structured Logging  │  Audit Hash-Chain  │  PII Masking    │
└─────────────────────────────────────────────────────────────┘
```

---

## Component Architecture

### 1. Presentation Layer

#### Web Dashboard (Port 8078)
- **Framework**: Dash 2.14+ with Mantine Components
- **Server**: Waitress WSGI (production, Windows-native)
- **Authentication**: Flask-Login with session cookies
- **Features**: 12 themes, AG Grid tables, Plotly charts, multi-page

#### REST API (Port 8079)
- **Framework**: FastAPI with Pydantic v2
- **Server**: Uvicorn ASGI
- **Authentication**: JWT (HMAC-SHA256) + API Key (SHA-256 hashed)
- **Documentation**: Swagger UI (/docs), ReDoc (/redoc), OpenAPI 3.0
- **Features**: 14 endpoints, RBAC, PII auto-masking, rate limiting

### 2. Service Layer

| Service | Responsibility |
|---------|---------------|
| `PipelineService` | Orchestrates 7-layer detection pipeline execution |
| `DataService` | Data access patterns, caching, validation |
| `AuthService` | User authentication, token management |

### 3. Detection Engine (7 Layers)

| Layer | File | Methods | Purpose |
|-------|------|---------|---------|
| **L1** | `L1_statistical.py` | Z-score, Benford's Law, IQR, Grubbs, Dixon | Statistical outlier detection |
| **L2** | `L2_ml.py` | Isolation Forest, LOF, One-Class SVM, DBSCAN | ML-based anomaly detection |
| **L3** | `L3_deep.py` | Autoencoder, reconstruction error | Deep learning anomaly scores |
| **L4** | `L4_graph.py` | PageRank, centrality, connected components | Network topology analysis |
| **L5** | `L5_temporal.py` | Velocity, acceleration, seasonality, burst | Time-series pattern detection |
| **L6** | `L6_ensemble.py` | Weighted voting, rank fusion, stacking | Multi-method aggregation |
| **L7** | `L7_network.py` | Community detection, flow analysis, hub/auth | Graph community patterns |

Each layer produces per-entity anomaly scores (0.0–1.0) that feed into L6 ensemble.

### 4. Data Layer

| Component | Technology | Purpose |
|-----------|-----------|---------|
| **Database** | SQLite + SQLAlchemy | Users, audit, API keys, pipeline history |
| **WAL Mode** | SQLite WAL | Concurrent reads during writes |
| **DataVault** | Custom class | Centralized data load/save/cache |
| **Diskcache** | diskcache library | Background task queue + result caching |
| **File I/O** | Polars + Pandas | CSV/Excel ingestion (Polars preferred) |

### 5. Infrastructure

| Component | Purpose |
|-----------|---------|
| **Waitress** | Production WSGI server for Dash (Windows-native) |
| **Uvicorn** | ASGI server for FastAPI |
| **SystemWatchdog** | CPU/memory/disk monitoring with thresholds |
| **Circuit Breaker** | Fault isolation for external dependencies |
| **Structured Logging** | JSON log format with correlation IDs |
| **Audit Hash-Chain** | SHA-256 linked audit entries for tamper detection |
| **PII Masker** | Auto-detect and redact PII in logs and responses |

---

## Data Flow

### Pipeline Execution Flow

```
User triggers pipeline (Dashboard or API)
    │
    ▼
PipelineService.execute_pipeline()
    │
    ├─→ DataVault.load_sources()        # Load CSV/Excel data
    │
    ├─→ L1_statistical.run()            # Z-score, Benford, IQR
    ├─→ L2_ml.run()                     # Isolation Forest, LOF
    ├─→ L3_deep.run()                   # Autoencoder
    ├─→ L4_graph.run()                  # PageRank, centrality
    ├─→ L5_temporal.run()               # Velocity, seasonality
    │
    ├─→ L6_ensemble.run()              # Combine L1-L5 scores
    │       │
    │       ├─→ Weighted voting
    │       ├─→ Rank fusion
    │       └─→ Final anomaly_score (0.0 - 1.0)
    │
    ├─→ L7_network.run()               # Community analysis
    │
    ├─→ Risk Tiering                    # CRITICAL/HIGH/MED/LOW/NORMAL
    │
    ├─→ DataVault.save_results()        # Persist scored data
    │
    └─→ Audit log entry                 # Hash-chained record
```

### API Request Flow

```
Client Request (JWT or API Key)
    │
    ▼
FastAPI Router
    │
    ├─→ Rate Limiter (sliding window check)
    ├─→ Authentication (JWT verify or API Key lookup)
    ├─→ RBAC Permission Check
    │
    ├─→ Route Handler (business logic)
    │       │
    │       └─→ Service Layer → Data Layer
    │
    ├─→ PII Masking (role-based response filtering)
    ├─→ Audit Logging (hash-chain entry)
    │
    └─→ JSON Response
```

---

## Security Architecture

See [SECURITY.md](../SECURITY.md) for complete security documentation.

### Key Principles

1. **Air-Gap First** — No network calls leave the machine
2. **PII Never Exposed** — Masked in all outputs by default
3. **Defence in Depth** — Auth + RBAC + Rate Limit + Audit + Encryption
4. **Audit Everything** — Hash chain ensures tamper detection
5. **Fail Secure** — Errors never expose internal state or PII

---

## Deployment Topology

```
┌──────────────────────────────────────────┐
│            Windows 11 Workstation         │
│            (Air-Gapped Network)           │
│                                           │
│  ┌─────────────────┐  ┌───────────────┐  │
│  │   Dash + Waitress│  │FastAPI+Uvicorn│  │
│  │   Port 8078      │  │Port 8079      │  │
│  └────────┬─────────┘  └──────┬────────┘  │
│           │                    │           │
│           └──────┬─────────────┘           │
│                  │                         │
│           ┌──────┴──────┐                  │
│           │ SQLite (WAL)│                  │
│           │ vault.db    │                  │
│           └─────────────┘                  │
│                                           │
│  data/  ← CSV/Excel files                 │
│  logs/  ← Application logs                │
│  cache/ ← Diskcache temp                  │
└──────────────────────────────────────────┘
```

---

*AIM AI Vault V15 Architecture — Internal Documentation*
