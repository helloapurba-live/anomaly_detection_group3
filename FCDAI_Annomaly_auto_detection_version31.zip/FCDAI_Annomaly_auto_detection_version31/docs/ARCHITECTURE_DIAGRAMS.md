# FCDAI Architecture Diagrams

**Visual representations of system architecture across versions**

**Document Date**: February 15, 2026  
**Purpose**: Mermaid diagrams showing architectural evolution from V1 to V17

---

## Table of Contents

1. [7-Layer Pipeline Architecture](#1-7-layer-pipeline-architecture)
2. [V1 Streamlit Architecture](#2-v1-streamlit-architecture)
3. [V2 Dash Migration](#3-v2-dash-migration)
4. [V6 Customer-Level Paradigm](#4-v6-customer-level-paradigm)
5. [V7 Schema Detection Flow](#5-v7-schema-detection-flow)
6. [V10 System Architecture](#6-v10-system-architecture)
7. [V15 API Integration](#7-v15-api-integration)
8. [V16/V17 Enhanced Security](#8-v16v17-enhanced-security)
9. [Data Flow Complete](#9-data-flow-complete)

---

## 1. 7-Layer Pipeline Architecture

**Core Detection Engine (All Versions)**

```mermaid
graph TB
    Start[Raw Transaction Data] --> L1[Layer 1: Data Prep & Cleaning]
    L1 --> L2[Layer 2: Feature Engineering]
    L2 --> L3[Layer 3: Isolation Forest Methods]
    L3 --> L4[Layer 4: Density-Based Methods]
    L4 --> L5[Layer 5: Statistical Methods]
    L5 --> L6[Layer 6: Network Analysis]
    L6 --> L7[Layer 7: Ensemble & Scoring]
    L7 --> Results[Composite Risk Scores]
    
    L3 -.-> IF[IsolationForest]
    L3 -.-> EIF[ExtendedIsolationForest]
    L3 -.-> LODA[LODA]
    
    L4 -.-> HDBSCAN[HDBSCAN]
    L4 -.-> LOF[LocalOutlierFactor]
    L4 -.-> KNN[KNN]
    L4 -.-> CBLOF[CBLOF]
    
    L5 -.-> PCA[PCA]
    L5 -.-> KDE[KDE]
    L5 -.-> OCSVM[OCSVM]
    L5 -.-> MCD[MCD]
    L5 -.-> COPOD[COPOD]
    
    L6 -.-> GNN[Graph Network Analysis]
    L6 -.-> Community[Community Detection]
    
    L7 -.-> Weighted[Weighted Ensemble]
    L7 -.-> Threshold[Dynamic Thresholding]
    
    style L1 fill:#e1f5ff
    style L2 fill:#ffe1f5
    style L3 fill:#fff4e1
    style L4 fill:#f0e1ff
    style L5 fill:#e1ffe4
    style L6 fill:#ffe1e1
    style L7 fill:#fff9e1
```

**Key**: 26 detection methods across 7 layers with weighted ensemble consensus.

---

## 2. V1 Streamlit Architecture

**Simple Script Execution Model**

```mermaid
graph LR
    User[User] -->|Upload CSV| Upload[st.file_uploader]
    Upload --> SessionState[st.session_state]
    SessionState --> Button[st.button Run]
    Button --> Pipeline[AnomalyPipeline]
    Pipeline --> L1[Layer 1]
    L1 --> L2[Layer 2]
    L2 --> L3[Layer 3]
    L3 --> L4[Layer 4]
    L4 --> L5[Layer 5]
    L5 --> L6[Layer 6]
    L6 --> L7[Layer 7]
    L7 --> Results[pd.DataFrame]
    Results --> Display[st.dataframe]
    Results --> Download[st.download_button]
    Download --> User
    
    Button -.->|Full Page Reload| Upload
    
    style Upload fill:#ff6b6b
    style SessionState fill:#feca57
    style Pipeline fill:#48dbfb
    style Display fill:#1dd1a1
```

**Limitations**: 
- Full page reload on every interaction
- No state persistence between sessions
- Single-user only
- No authentication

---

## 3. V2 Dash Migration

**Reactive Callback Architecture**

```mermaid
graph TB
    subgraph "Client Browser"
        UI[Dash Components]
        Store1[dcc.Store data]
        Store2[dcc.Store config]
        Grid[AG Grid]
        Charts[Plotly Charts]
    end
    
    subgraph "Dash Server"
        CB1[Callback: Load Data]
        CB2[Callback: Run Pipeline]
        CB3[Callback: Update Grid]
        CB4[Callback: Update Charts]
        CB5[Clientside: Theme Toggle]
    end
    
    subgraph "Processing"
        Pipeline[AnomalyPipeline]
        Cache[Diskcache]
    end
    
    UI -->|Upload| CB1
    CB1 --> Store1
    Store1 --> CB2
    CB2 --> Pipeline
    Pipeline --> Cache
    Cache --> CB2
    CB2 --> Store2
    Store2 --> CB3
    CB3 --> Grid
    Store2 --> CB4
    CB4 --> Charts
    
    UI -->|Theme Change| CB5
    CB5 -.->|No Server Trip| UI
    
    style CB5 fill:#00d2d3
    style Cache fill:#ff6348
    style Store1 fill:#feca57
    style Store2 fill:#feca57
```

**Improvements**:
- No page reloads
- Reactive state management
- Clientside callbacks for instant updates
- Diskcache for result persistence

---

## 4. V6 Customer-Level Paradigm

**Transaction → Customer Transformation**

```mermaid
graph TB
    subgraph "Input"
        TXN[100,000 Transactions]
    end
    
    subgraph "Layer 1-6 Processing"
        Pipeline[Traditional Pipeline]
        TXN --> Pipeline
        Pipeline --> TXN_Scored[100K Scored Transactions]
    end
    
    subgraph "V6 Customer Aggregation"
        TXN_Scored --> Agg[CustomerAggregator]
        Agg --> Features[80+ Features per Customer]
        Features --> Customers[10,000 Customers]
    end
    
    subgraph "Customer-Level Detection"
        Customers --> L3C[Layer 3: Customer Methods]
        L3C --> L4C[Layer 4: Customer Methods]
        L4C --> L5C[Layer 5: Customer Methods]
        L5C --> L6C[Layer 6: Customer Network]
        L6C --> L7C[Layer 7: Tiered Consensus]
    end
    
    subgraph "Output"
        L7C --> Results[Customer Risk Scores]
        Results --> Top[Top 100 Alerts]
    end
    
    TXN -.->|90% Reduction| Customers
    
    style Agg fill:#00d2d3
    style Customers fill:#1dd1a1
    style L7C fill:#feca57
```

**Performance Boost**:
- 90% fewer records to score
- 17% faster execution
- More meaningful risk attribution
- Better false positive reduction

---

## 5. V7 Schema Detection Flow

**Zero-Assumption Architecture**

```mermaid
graph TB
    Input[ANY CSV File] --> Detector[SchemaDetector]
    
    Detector --> Match1{MASTER_ID<br/>Pattern Match?}
    Match1 -->|Yes| Detected1[Map to MASTER_ID]
    Match1 -->|No| Config1[Check Config File]
    Config1 --> User1{User<br/>Override?}
    User1 -->|Yes| Override1[Use User Mapping]
    User1 -->|No| Error1[Require Manual Map]
    
    Detector --> Match2{AMOUNT<br/>Pattern Match?}
    Match2 -->|Yes| Detected2[Map to MASTER_AMOUNT]
    Match2 -->|No| Config2[Check Config File]
    
    Detector --> Match3{DATE<br/>Pattern Match?}
    Match3 -->|Yes| Detected3[Map to MASTER_DATE]
    Match3 -->|No| Config3[Check Config File]
    
    Detected1 --> Validate[Validate Required Roles]
    Detected2 --> Validate
    Detected3 --> Validate
    Override1 --> Validate
    
    Validate --> Valid{All<br/>Required<br/>Present?}
    Valid -->|Yes| Transform[Transform to MASTER Schema]
    Valid -->|No| Error2[Missing Required Columns]
    
    Transform --> Pipeline[Run Pipeline]
    
    style Detector fill:#00d2d3
    style Transform fill:#1dd1a1
    style Valid fill:#feca57
```

**Flexibility**: Supports ANY schema with customer_id/account_id/entity_id, amount, date columns.

---

## 6. V10 System Architecture

**Enterprise Infrastructure**

```mermaid
graph TB
    subgraph "Client Layer"
        Browser[Web Browser]
        API_Client[API Client]
    end
    
    subgraph "Authentication"
        Login[Flask-Login]
        RBAC[Role-Based Access]
        Session[8-Hour Sessions]
    end
    
    subgraph "Web Application"
        Dash[Dash App :8070]
        Pages[21 Pages]
        Callbacks[150+ Callbacks]
    end
    
    subgraph "Data Layer"
        SQLite[(SQLite + WAL)]
        ORM[SQLAlchemy ORM]
        Models[12 Tables]
    end
    
    subgraph "Security Layer"
        Fernet[Fernet Encryption]
        Hash[SHA-256 Hashing]
        PBKDF2[PBKDF2 Password Hash]
    end
    
    subgraph "Processing"
        Pipeline[7-Layer Pipeline]
        Tasks[Background Tasks]
        Cache[Diskcache]
    end
    
    subgraph "Storage"
        Vault[Data Vault<br/>Parquet Files]
        Logs[Audit Logs]
        Reports[Generated Reports]
    end
    
    Browser --> Login
    Login --> Session
    Session --> RBAC
    RBAC --> Dash
    Dash --> Pages
    Pages --> Callbacks
    Callbacks --> Pipeline
    Pipeline --> Cache
    Callbacks --> ORM
    ORM --> SQLite
    SQLite --> Models
    
    Fernet -.->|Encrypt| SQLite
    Hash -.->|Hash IDs| SQLite
    PBKDF2 -.->|Password| ORM
    
    Pipeline --> Vault
    Callbacks --> Logs
    Tasks --> Reports
    
    API_Client -.->|V15+| Dash
    
    style Login fill:#ff6348
    style RBAC fill:#ff6348
    style Fernet fill:#ff6348
    style SQLite fill:#1dd1a1
    style Pipeline fill:#00d2d3
```

**Key Changes**:
- SQLite replaces Parquet for structured data
- Multi-user authentication
- Role-based access control (3 roles)
- Fernet encryption for sensitive data
- Hash chain audit logging

---

## 7. V15 API Integration

**Dual Interface Architecture**

```mermaid
graph TB
    subgraph "Clients"
        Browser[Web Browser]
        PostmanAPI[Postman/Scripts]
        External[External Systems]
    end
    
    subgraph "Web Interface"
        Dash[Dash App<br/>:8070]
        DashAuth[Flask-Login Auth]
    end
    
    subgraph "API Interface"
        FastAPI[FastAPI<br/>:8079]
        JWTAuth[JWT Authentication]
        APIKeyAuth[API Key Authentication]
        Swagger[/docs - Swagger UI]
    end
    
    subgraph "Shared Core"
        Pipeline[7-Layer Pipeline]
        Database[(SQLite)]
        Vault[Data Vault]
    end
    
    subgraph "API Endpoints"
        E1[POST /detect]
        E2[GET /customers]
        E3[GET /alerts]
        E4[POST /reports]
        E5[GET /health]
    end
    
    Browser --> DashAuth
    DashAuth --> Dash
    Dash --> Pipeline
    
    PostmanAPI --> JWTAuth
    External --> APIKeyAuth
    JWTAuth --> FastAPI
    APIKeyAuth --> FastAPI
    
    FastAPI --> E1
    FastAPI --> E2
    FastAPI --> E3
    FastAPI --> E4
    FastAPI --> E5
    
    E1 --> Pipeline
    E2 --> Database
    E3 --> Database
    E4 --> Vault
    
    Dash --> Database
    Pipeline --> Database
    Pipeline --> Vault
    
    FastAPI -.->|Auto-Generated| Swagger
    
    style JWTAuth fill:#ff6348
    style APIKeyAuth fill:#ff6348
    style Swagger fill:#1dd1a1
    style FastAPI fill:#00d2d3
```

**Dual Authentication**:
- **Web UI**: Flask-Login sessions
- **API**: JWT tokens OR API keys

**14 API Endpoints**:
- Detection: `/detect`, `/batch-detect`
- Query: `/customers`, `/alerts`, `/reports`
- Management: `/users`, `/roles`, `/tasks`
- Monitoring: `/health`, `/metrics`, `/logs`

---

## 8. V16/V17 Enhanced Security

**Bank Audit Compliance (A4/A5/A6)**

```mermaid
graph TB
    subgraph "User Request"
        Request[Data Access Request]
    end
    
    subgraph "A4: PII Safety Lock"
        Lock[PIISafetyLock]
        Check{PII<br/>Columns<br/>Requested?}
        RoleCheck{User<br/>Role?}
    end
    
    subgraph "A5: Epsilon Tolerance"
        FloatCalc[Float Calculations]
        Epsilon[ε = 1e-9]
        Compare{Within<br/>Tolerance?}
    end
    
    subgraph "A6: Hash Chain Verify"
        HashLoad[Load Hash Chain]
        Recompute[Recompute Hashes]
        Verify{Chain<br/>Valid?}
    end
    
    subgraph "Audit Trail"
        Log[Audit Logger]
        Alert[Alert on Failure]
    end
    
    Request --> Lock
    Lock --> Check
    Check -->|No PII| Approve1[Grant Access]
    Check -->|PII Present| RoleCheck
    RoleCheck -->|Admin| Approve2[Grant Full Access]
    RoleCheck -->|Viewer/Inv| Mask[Apply Masking]
    RoleCheck -->|Unauthorized| Deny1[Access Denied]
    
    FloatCalc --> Epsilon
    Epsilon --> Compare
    Compare -->|Yes| Pass1[Accept]
    Compare -->|No| Fail1[Flag Drift]
    
    HashLoad --> Recompute
    Recompute --> Verify
    Verify -->|Valid| Pass2[Trust Data]
    Verify -->|Invalid| Fail2[Data Compromised]
    
    Deny1 --> Log
    Fail1 --> Log
    Fail2 --> Log
    Log --> Alert
    
    style Lock fill:#ff6348
    style Epsilon fill:#feca57
    style Verify fill:#00d2d3
    style Alert fill:#e74c3c
```

**Enhancement A4**: Prevents accidental PII exposure via safety lock.  
**Enhancement A5**: Handles float comparison with epsilon tolerance.  
**Enhancement A6**: Continuous hash chain verification.

---

## 9. Data Flow Complete

**End-to-End V17 Architecture**

```mermaid
graph TB
    subgraph "Data Ingestion"
        Upload[CSV Upload<br/>100K Transactions]
        Polars[Polars Fast Read]
        Validate[Schema Validation]
    end
    
    subgraph "Layer 1: Prep"
        Clean[Data Cleaning]
        PII[PII Auto-Detection]
        Mask[Auto-Masking]
    end
    
    subgraph "Layer 2: Features"
        TxnFeatures[Transaction Features<br/>40+ columns]
        Safe[Safety Lock Check]
    end
    
    subgraph "Layers 3-6: Detection"
        Methods[26 Detection Methods]
        TxnScores[Transaction Scores]
    end
    
    subgraph "V6+ Customer Aggregation"
        Agg[Aggregate to Customer]
        CustomerFeatures[80+ Customer Features]
        CustomerMethods[Customer-Level Detection]
    end
    
    subgraph "Layer 7: Ensemble"
        Consensus[Tiered Consensus]
        Normalize[Percentile Normalization]
        Weight[Domain Weights]
        Threshold[Dynamic Threshold]
    end
    
    subgraph "Persistence"
        Encrypt[Fernet Encryption]
        Hash[SHA-256 ID Hashing]
        SQLite[(SQLite Database)]
        Vault[Parquet Vault]
    end
    
    subgraph "Audit"
        HashChain[Hash Chain]
        Verify[Continuous Verification]
        AuditLog[Audit Logs]
    end
    
    subgraph "Output"
        Dashboard[Web Dashboard]
        API[REST API]
        Reports[PDF Reports]
        Alerts[Alert Queue]
    end
    
    Upload --> Polars
    Polars --> Validate
    Validate --> Clean
    Clean --> PII
    PII --> Mask
    Mask --> TxnFeatures
    TxnFeatures --> Safe
    Safe --> Methods
    Methods --> TxnScores
    TxnScores --> Agg
    Agg --> CustomerFeatures
    CustomerFeatures --> CustomerMethods
    CustomerMethods --> Consensus
    Consensus --> Normalize
    Normalize --> Weight
    Weight --> Threshold
    
    Threshold --> Encrypt
    Encrypt --> Hash
    Hash --> SQLite
    Hash --> Vault
    
    SQLite --> HashChain
    HashChain --> Verify
    Verify --> AuditLog
    
    SQLite --> Dashboard
    SQLite --> API
    SQLite --> Reports
    SQLite --> Alerts
    
    style PII fill:#ff6348
    style Mask fill:#ff6348
    style Safe fill:#ff6348
    style Encrypt fill:#ff6348
    style Verify fill:#00d2d3
    style Dashboard fill:#1dd1a1
```

**Complete V17 Flow**:
1. **Ingest**: Polars fast read → Schema validation
2. **Secure**: Auto-PII detection → Auto-masking → Safety lock
3. **Process**: 7-layer pipeline → 26 methods → Customer aggregation
4. **Ensemble**: Tiered consensus → Normalization → Weighting
5. **Persist**: Encryption → Hashing → SQLite + Vault
6. **Audit**: Hash chain → Continuous verification → Logs
7. **Output**: Dashboard + API + Reports + Alerts

---

**Return to**: [Version History V1-V10](../VERSION_HISTORY_V1_TO_V10.md) | [Comparison Tables](COMPARISON_TABLES.md) | [Code Examples](CODE_EXAMPLES.md)
