# FCDAI Code Examples & Implementation Patterns

**Real code snippets demonstrating key patterns from each version**

**Document Date**: February 15, 2026  
**Purpose**: Show actual implementation approaches across the evolution from V1 to V17

---

## Table of Contents

1. [Version 1: Streamlit Script Pattern](#1-version-1-streamlit-script-pattern)
2. [Version 2: Dash Callback Architecture](#2-version-2-dash-callback-architecture)
3. [Version 3: PII Masking](#3-version-3-pii-masking)
4. [Version 4: Pipeline Runner CLI](#4-version-4-pipeline-runner-cli)
5. [Version 5: Clientside Callbacks](#5-version-5-clientside-callbacks)
6. [Version 6: Customer Aggregation](#6-version-6-customer-aggregation)
7. [Version 7: Schema Detection](#7-version-7-schema-detection)
8. [Version 8: Column Role Resolution](#8-version-8-column-role-resolution)
9. [Version 9: FMEA Integration](#9-version-9-fmea-integration)
10. [Version 10: SQLite + RBAC](#10-version-10-sqlite--rbac)
11. [Version 11-17: Advanced Features](#11-version-11-17-advanced-features)

---

## 1. Version 1: Streamlit Script Pattern

### Basic Pipeline Execution (V1)

```python
# app.py (Streamlit)
import streamlit as st
import pandas as pd
from src.pipeline import AnomalyPipeline

st.set_page_config(page_title="FCDAI AML", layout="wide")

# Session state initialization
if 'pipeline' not in st.session_state:
    st.session_state.pipeline = None

# File uploader
uploaded = st.file_uploader("Upload Transaction CSV", type=['csv'])
if uploaded:
    df = pd.read_csv(uploaded)
    st.write(f"Loaded {len(df):,} transactions")
    
    # Configuration sidebar
    st.sidebar.header("Detection Settings")
    threshold = st.sidebar.slider("Alert Threshold", 0.5, 1.0, 0.85)
    
    # Run pipeline
    if st.button("Run Detection"):
        with st.spinner("Processing..."):
            pipeline = AnomalyPipeline(threshold=threshold)
            results = pipeline.run(df)
            st.session_state.pipeline = pipeline
            st.session_state.results = results
        
        # Display results
        st.subheader("Results")
        st.dataframe(results)
        
        # Download
        st.download_button(
            "Download Results",
            data=results.to_csv(index=False),
            file_name="anomalies.csv",
            mime="text/csv"
        )
```

**Pattern**: Linear script execution, full page reloads, simple state management.

---

## 2. Version 2: Dash Callback Architecture

### Reactive Data Flow (V2)

```python
# app.py (Dash)
from dash import Dash, html, dcc, Input, Output, State, callback
import dash_mantine_components as dmc
import dash_ag_grid as dag

app = Dash(__name__, use_pages=True)

app.layout = dmc.MantineProvider([
    dcc.Store(id="store-data"),
    dcc.Store(id="store-config"),
    dmc.AppShell(
        navbar=create_navbar(),
        children=[dash.page_container]
    )
])

@callback(
    Output("store-data", "data"),
    Input("upload", "contents"),
    State("upload", "filename")
)
def load_data(contents, filename):
    if contents is None:
        return None
    
    content_type, content_string = contents.split(',')
    decoded = base64.b64decode(content_string)
    df = pd.read_csv(io.BytesIO(decoded))
    
    return df.to_dict('records')

@callback(
    Output("grid", "rowData"),
    Output("status", "children"),
    Input("btn-run", "n_clicks"),
    State("store-data", "data"),
    State("threshold-slider", "value"),
    prevent_initial_call=True
)
def run_pipeline(n_clicks, data, threshold):
    if not data:
        return [], "No data loaded"
    
    df = pd.DataFrame(data)
    pipeline = AnomalyPipeline(threshold=threshold)
    results = pipeline.run(df)
    
    return results.to_dict('records'), f"✓ Processed {len(df):,} records"
```

**Pattern**: Component-driven callbacks, reactive state management, no page reloads.

---

## 3. Version 3: PII Masking

### Show-Edges Pattern (V3)

```python
# src/utils/pii_handler.py
import re

class PIIHandler:
    """Masks PII while showing edge characters for verification."""
    
    def __init__(self, show_prefix: int = 2, show_suffix: int = 2):
        self.show_prefix = show_prefix
        self.show_suffix = show_suffix
        
        self.patterns = {
            'ACCOUNT': re.compile(r'\b\d{8,20}\b'),
            'SSN': re.compile(r'\b\d{3}-\d{2}-\d{4}\b'),
            'EMAIL': re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'),
            'PHONE': re.compile(r'\b\d{3}-\d{3}-\d{4}\b')
        }
    
    def mask(self, value: str, pii_type: str = 'ACCOUNT') -> str:
        """Mask PII showing only edge characters."""
        if pd.isna(value):
            return value
        
        s = str(value)
        if len(s) <= self.show_prefix + self.show_suffix:
            return '*' * len(s)
        
        prefix = s[:self.show_prefix]
        suffix = s[-self.show_suffix:]
        masked_middle = '*' * (len(s) - self.show_prefix - self.show_suffix)
        
        return f"{prefix}{masked_middle}{suffix}"
    
    def mask_dataframe(self, df: pd.DataFrame, pii_columns: list) -> pd.DataFrame:
        """Apply masking to specified columns."""
        masked_df = df.copy()
        for col in pii_columns:
            if col in masked_df.columns:
                masked_df[col] = masked_df[col].apply(
                    lambda x: self.mask(x) if not pd.isna(x) else x
                )
        return masked_df

# Usage in pipeline
from src.config import PIIConfig

pii_config = PIIConfig()
pii_handler = PIIHandler(
    show_prefix=pii_config.show_prefix,
    show_suffix=pii_config.show_suffix
)

# Mask before display
display_df = pii_handler.mask_dataframe(df, pii_config.pii_columns)
```

**Pattern**: In-memory masking, show-edges verification, configurable sensitivity.

---

## 4. Version 4: Pipeline Runner CLI

### Standalone Runner (V4)

```python
# pipeline_runner.py
import argparse
import pandas as pd
from pathlib import Path
from src.pipeline import AnomalyPipeline
from src.config import PathConfig, LayerConfig

def run_pipeline_cli():
    """CLI for batch pipeline execution."""
    parser = argparse.ArgumentParser(description="FCDAI Batch Runner")
    parser.add_argument(
        '--input', 
        required=True, 
        help='Input CSV file path'
    )
    parser.add_argument(
        '--output', 
        required=True, 
        help='Output directory'
    )
    parser.add_argument(
        '--threshold', 
        type=float, 
        default=0.85,
        help='Alert threshold (0.0-1.0)'
    )
    parser.add_argument(
        '--skip-layers',
        nargs='*',
        default=[],
        help='Layers to skip (e.g., 1 3 5)'
    )
    
    args = parser.parse_args()
    
    # Load data
    print(f"Loading data from {args.input}...")
    df = pd.read_csv(args.input)
    print(f"✓ Loaded {len(df):,} records")
    
    # Configure pipeline
    config = LayerConfig()
    for layer_num in args.skip_layers:
        setattr(config, f'enable_layer{layer_num}', False)
    
    # Run
    print("Running pipeline...")
    pipeline = AnomalyPipeline(threshold=args.threshold, config=config)
    results = pipeline.run(df)
    
    # Save
    output_dir = Path(args.output)
    output_dir.mkdir(exist_ok=True, parents=True)
    
    results_path = output_dir / "results.parquet"
    results.to_parquet(results_path, index=False)
    print(f"✓ Saved results to {results_path}")
    
    # Summary
    anomalies = results[results['alert_flag'] == 1]
    print(f"\nSummary:")
    print(f"  Total: {len(results):,}")
    print(f"  Alerts: {len(anomalies):,} ({len(anomalies)/len(results)*100:.1f}%)")

if __name__ == '__main__':
    run_pipeline_cli()
```

**Usage**:
```bash
python pipeline_runner.py \
    --input data/transactions.csv \
    --output results/ \
    --threshold 0.9 \
    --skip-layers 2 6
```

**Pattern**: Headless execution, argument parsing, batch processing.

---

## 5. Version 5: Clientside Callbacks

### Theme Toggle (V5)

```python
# app.py (clientside callback)
from dash import clientside_callback, ClientsideFunction

# Server-side: Define themes
app.layout = dmc.MantineProvider(
    id="theme-provider",
    theme={
        "colorScheme": "dark",
        "primaryColor": "blue"
    },
    children=[
        dcc.Store(id="store-theme", data="dark"),
        dmc.SegmentedControl(
            id="theme-toggle",
            data=[
                {"value": "light", "label": "Light"},
                {"value": "dark", "label": "Dark"}
            ],
            value="dark"
        ),
        html.Div(id="app-content")
    ]
)

# Clientside callback (runs in browser)
clientside_callback(
    """
    function(theme) {
        // Update localStorage
        localStorage.setItem('fcdai-theme', theme);
        
        // Update MantineProvider
        return {
            colorScheme: theme,
            primaryColor: theme === 'dark' ? 'blue' : 'teal'
        };
    }
    """,
    Output("theme-provider", "theme"),
    Input("theme-toggle", "value")
)

# Initialize theme from localStorage
app.clientside_callback(
    """
    function() {
        const saved = localStorage.getItem('fcdai-theme');
        return saved || 'dark';
    }
    """,
    Output("theme-toggle", "value"),
    Input("app-content", "id")  # Dummy input to trigger on load
)
```

**Pattern**: Browser-side execution, localStorage persistence, zero server roundtrip.

---

## 6. Version 6: Customer Aggregation

### Transaction → Customer Paradigm (V6)

```python
# src/layers/customer_aggregation.py
import pandas as pd
import numpy as np

class CustomerAggregator:
    """Aggregate transaction-level to customer-level."""
    
    def aggregate(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Transform 100K transactions → 10K customers.
        Generate 80+ statistical features per customer.
        """
        customer_groups = df.groupby('customer_id')
        
        features = []
        for customer_id, group in customer_groups:
            # Volume features
            txn_count = len(group)
            total_amount = group['amount'].sum()
            avg_amount = group['amount'].mean()
            std_amount = group['amount'].std()
            
            # Time features
            days_active = (group['date'].max() - group['date'].min()).days
            avg_daily_txns = txn_count / max(days_active, 1)
            
            # Pattern features
            unique_counterparties = group['counterparty_id'].nunique()
            unique_channels = group['channel'].nunique()
            
            # Risk features (from layer scores)
            max_alert_score = group['composite_risk'].max()
            avg_alert_score = group['composite_risk'].mean()
            
            # Percentile features
            amount_p25 = group['amount'].quantile(0.25)
            amount_p50 = group['amount'].quantile(0.50)
            amount_p75 = group['amount'].quantile(0.75)
            amount_p95 = group['amount'].quantile(0.95)
            
            features.append({
                'customer_id': customer_id,
                'txn_count': txn_count,
                'total_amount': total_amount,
                'avg_amount': avg_amount,
                'std_amount': std_amount,
                'days_active': days_active,
                'avg_daily_txns': avg_daily_txns,
                'unique_counterparties': unique_counterparties,
                'unique_channels': unique_channels,
                'max_alert_score': max_alert_score,
                'avg_alert_score': avg_alert_score,
                'amount_p25': amount_p25,
                'amount_p50': amount_p50,
                'amount_p75': amount_p75,
                'amount_p95': amount_p95,
                # ...65 more features
            })
        
        return pd.DataFrame(features)
    
    def apply_tiered_consensus(self, customer_df: pd.DataFrame) -> pd.DataFrame:
        """
        Tiered consensus: Combine 26 customer-level scores.
        Weights vary by tier based on historical performance.
        """
        tier1_methods = ['hdbscan', 'lof', 'iforest']  # High precision
        tier2_methods = ['knn', 'cblof', 'copod']      # Medium precision
        tier3_methods = ['pca', 'ocsvm', 'mcd']        # Broad coverage
        
        tier1_scores = customer_df[[f'score_{m}' for m in tier1_methods]].mean(axis=1)
        tier2_scores = customer_df[[f'score_{m}' for m in tier2_methods]].mean(axis=1)
        tier3_scores = customer_df[[f'score_{m}' for m in tier3_methods]].mean(axis=1)
        
        # Weighted combination
        customer_df['composite_score'] = (
            0.5 * tier1_scores +
            0.3 * tier2_scores +
            0.2 * tier3_scores
        )
        
        return customer_df
```

**Pattern**: 90% data reduction, 80+ features per customer, tiered consensus ensemble.

---

## 7. Version 7: Schema Detection

### ANY Schema Support (V7)

```python
# src/utils/schema_detector.py
import pandas as pd
from typing import Dict, List, Optional

class SchemaDetector:
    """Detect column types without hardcoded assumptions."""
    
    DETECTORS = {
        'MASTER_ID': [
            r'customer[_\s]?id',
            r'client[_\s]?id',
            r'account[_\s]?holder',
            r'entity[_\s]?id'
        ],
        'AMOUNT': [
            r'amount',
            r'value',
            r'transaction[_\s]?amount',
            r'txn[_\s]?amt'
        ],
        'DATE': [
            r'date',
            r'timestamp',
            r'time',
            r'txn[_\s]?date',
            r'transaction[_\s]?date'
        ],
        'COUNTERPARTY': [
            r'counterparty',
            r'beneficiary',
            r'recipient',
            r'payee'
        ],
        'CHANNEL': [
            r'channel',
            r'source',
            r'type',
            r'method'
        ],
        'CURRENCY': [
            r'currency',
            r'ccy',
            r'curr'
        ],
        'LOCATION': [
            r'country',
            r'location',
            r'region',
            r'jurisdiction'
        ],
        'CATEGORY': [
            r'category',
            r'industry',
            r'sector',
            r'mcc'
        ]
    }
    
    def detect(self, df: pd.DataFrame) -> Dict[str, str]:
        """
        Auto-detect column roles from ANY schema.
        Returns mapping: role → actual_column_name
        """
        detected = {}
        
        for role, patterns in self.DETECTORS.items():
            matched = self._match_column(df.columns, patterns)
            if matched:
                detected[role] = matched
        
        return detected
    
    def _match_column(self, columns: List[str], patterns: List[str]) -> Optional[str]:
        """Find first column matching any pattern."""
        for col in columns:
            col_lower = col.lower()
            for pattern in patterns:
                if re.search(pattern, col_lower):
                    return col
        return None
    
    def validate(self, detected: Dict[str, str]) -> Dict[str, bool]:
        """Validate detected schema has required roles."""
        required = ['MASTER_ID', 'AMOUNT', 'DATE']
        validation = {}
        
        for role in required:
            validation[role] = role in detected
        
        return validation

# Usage
detector = SchemaDetector()
schema = detector.detect(df)
validation = detector.validate(schema)

if not all(validation.values()):
    missing = [k for k, v in validation.items() if not v]
    raise ValueError(f"Missing required columns: {missing}")

# Map to MASTER columns
df_master = pd.DataFrame({
    'MASTER_ID': df[schema['MASTER_ID']],
    'MASTER_AMOUNT': df[schema.get('AMOUNT', 'amount')],
    'MASTER_DATE': pd.to_datetime(df[schema['DATE']]),
    # ... other MASTER_* columns
})
```

**Pattern**: Zero hardcoded assumptions, regex-based detection, fallback to config.

---

## 8. Version 8: Column Role Resolution

### 3-Step Resolution (V8)

```python
# src/utils/column_resolver.py
import yaml
from pathlib import Path

class ColumnRoleResolver:
    """Resolve column roles: config → auto-detect → user override."""
    
    def __init__(self, config_path: Optional[Path] = None):
        self.config_path = config_path
        self.role_map = {}
    
    def resolve(self, df: pd.DataFrame) -> Dict[str, str]:
        """
        3-step resolution:
        1. Try config file (columns.yaml)
        2. Auto-detect if config missing
        3. Apply user overrides
        """
        # Step 1: Config file
        if self.config_path and self.config_path.exists():
            self.role_map = self._load_config()
            if self._validate_mapping(df, self.role_map):
                return self.role_map
        
        # Step 2: Auto-detect
        detector = SchemaDetector()
        self.role_map = detector.detect(df)
        
        if not self._validate_mapping(df, self.role_map):
            raise ValueError("Auto-detection failed and no valid config found")
        
        return self.role_map
    
    def _load_config(self) -> Dict[str, str]:
        """Load column mapping from YAML."""
        with open(self.config_path, 'r') as f:
            config = yaml.safe_load(f)
        return config.get('column_mapping', {})
    
    def _validate_mapping(self, df: pd.DataFrame, mapping: Dict[str, str]) -> bool:
        """Check if mapping points to real columns."""
        for role, col in mapping.items():
            if col not in df.columns:
                return False
        
        required = ['MASTER_ID', 'AMOUNT', 'DATE']
        return all(role in mapping for role in required)
    
    def save_mapping(self, output_path: Path):
        """Save detected mapping for future use."""
        with open(output_path, 'w') as f:
            yaml.dump({'column_mapping': self.role_map}, f)

# Usage
resolver = ColumnRoleResolver(config_path=Path('config/columns.yaml'))
mapping = resolver.resolve(df)

# Save for next run
resolver.save_mapping(Path('config/detected_columns.yaml'))
```

**columns.yaml example**:
```yaml
column_mapping:
  MASTER_ID: customer_id
  AMOUNT: transaction_amount
  DATE: txn_date
  COUNTERPARTY: beneficiary_name
  CHANNEL: payment_type
```

**Pattern**: Fallback chain, explicit config > auto-detect > user override.

---

## 9. Version 9: FMEA Integration

### Critical Fix: PII Default Masking (FM-006)

```python
# src/config.py (V9 fix)
from dataclasses import dataclass

@dataclass
class PIIConfig:
    """PII masking configuration with safe defaults."""
    
    # CRITICAL: Changed default from False to True (FM-006 fix)
    enable_pii_masking: bool = True  # WAS: False
    
    show_prefix: int = 2
    show_suffix: int = 2
    
    pii_columns: list = None
    
    def __post_init__(self):
        if self.pii_columns is None:
            # Default sensitive columns
            self.pii_columns = [
                'customer_id',
                'account_number',
                'ssn',
                'email',
                'phone',
                'name',
                'address'
            ]

# Verification in pipeline
from src.utils.pii_handler import PIIHandler

config = PIIConfig()
assert config.enable_pii_masking == True, "FM-006: PII masking MUST be enabled by default"

pii_handler = PIIHandler(config)
masked_df = pii_handler.mask_dataframe(df, config.pii_columns)
```

### Critical Fix: Hash Persistence (FM-007)

```python
# src/utils/audit_logger.py (V9 fix)
import hashlib
import json
from pathlib import Path

class AuditLogger:
    """Audit logger with persistent hash chain."""
    
    def __init__(self, state_file: Path = Path('audit/hash_state.json')):
        self.state_file = state_file
        self.state_file.parent.mkdir(exist_ok=True, parents=True)
        
        # CRITICAL: Load previous hash on init (FM-007 fix)
        self.previous_hash = self._load_previous_hash()
    
    def _load_previous_hash(self) -> str:
        """Load last hash from persistent storage."""
        if self.state_file.exists():
            with open(self.state_file, 'r') as f:
                state = json.load(f)
                return state.get('last_hash', '0' * 64)
        return '0' * 64  # Genesis hash
    
    def _save_hash(self, current_hash: str):
        """Persist current hash for next run."""
        with open(self.state_file, 'w') as f:
            json.dump({'last_hash': current_hash}, f)
    
    def log_event(self, event: dict) -> str:
        """Log event with hash chain."""
        # Create hash chain: hash(previous_hash + event_data)
        event_str = json.dumps(event, sort_keys=True)
        chain_input = f"{self.previous_hash}{event_str}"
        current_hash = hashlib.sha256(chain_input.encode()).hexdigest()
        
        # Save to log
        log_entry = {
            **event,
            'previous_hash': self.previous_hash,
            'current_hash': current_hash,
            'timestamp': pd.Timestamp.now().isoformat()
        }
        
        # Persist hash (FM-007 fix)
        self._save_hash(current_hash)
        self.previous_hash = current_hash
        
        return current_hash
```

**Pattern**: FMEA-driven fixes, safe defaults, persistent state.

---

## 10. Version 10: SQLite + RBAC

### SQLAlchemy Models (V10)

```python
# src/models/database.py
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(100), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(50), nullable=False)  # admin, investigator, viewer
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime)
    is_active = Column(Boolean, default=True)

class Anomaly(Base):
    __tablename__ = 'anomalies'
    
    id = Column(Integer, primary_key=True)
    customer_id_hash = Column(String(64), nullable=False)
    composite_score = Column(Float, nullable=False)
    alert_flag = Column(Boolean, nullable=False)
    detected_at = Column(DateTime, default=datetime.utcnow)
    investigated_by = Column(String(100))
    status = Column(String(50), default='pending')  # pending, investigating, closed
    narrative = Column(String(5000))

class AuditLog(Base):
    __tablename__ = 'audit_logs'
    
    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False)
    user = Column(String(100), nullable=False)
    action = Column(String(100), nullable=False)
    details = Column(String(1000))
    previous_hash = Column(String(64), nullable=False)
    current_hash = Column(String(64), nullable=False)

# Database initialization
def init_db(db_path: str = 'data/fcdai.db'):
    engine = create_engine(f'sqlite:///{db_path}', echo=False)
    Base.metadata.create_all(engine)
    return engine

engine = init_db()
SessionLocal = sessionmaker(bind=engine)
```

### Flask-Login Integration (V10)

```python
# app.py (authentication setup)
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from passlib.hash import pbkdf2_sha256

login_manager = LoginManager()
login_manager.init_app(server)  # server = app.server
login_manager.login_view = '/login'

class User(UserMixin):
    def __init__(self, id, username, role):
        self.id = id
        self.username = username
        self.role = role

@login_manager.user_loader
def load_user(user_id):
    session = SessionLocal()
    try:
        user = session.query(UserModel).filter_by(id=int(user_id)).first()
        if user:
            return User(user.id, user.username, user.role)
    finally:
        session.close()
    return None

# Login callback
@callback(
    Output("url", "pathname"),
    Output("login-error", "children"),
    Input("btn-login", "n_clicks"),
    State("input-username", "value"),
    State("input-password", "value"),
    prevent_initial_call=True
)
def handle_login(n_clicks, username, password):
    if not username or not password:
        return dash.no_update, "Enter credentials"
    
    session = SessionLocal()
    try:
        user = session.query(UserModel).filter_by(username=username).first()
        
        if user and pbkdf2_sha256.verify(password, user.password_hash):
            # Update last login
            user.last_login = datetime.utcnow()
            session.commit()
            
            # Create Flask-Login user
            user_obj = User(user.id, user.username, user.role)
            login_user(user_obj, remember=True, duration=timedelta(hours=8))
            
            return "/", ""
        else:
            return dash.no_update, "Invalid credentials"
    finally:
        session.close()
```

### RBAC Decorator (V10)

```python
# src/utils/auth.py
from functools import wraps
from flask_login import current_user
from dash import html

def require_role(*allowed_roles):
    """Decorator to restrict page access by role."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if not current_user.is_authenticated:
                return html.Div([
                    html.H3("Access Denied"),
                    html.P("Please log in to view this page."),
                    dmc.Button("Go to Login", href="/login")
                ])
            
            if current_user.role not in allowed_roles:
                return html.Div([
                    html.H3("Insufficient Permissions"),
                    html.P(f"This page requires one of: {', '.join(allowed_roles)}"),
                    html.P(f"Your role: {current_user.role}"),
                    dmc.Button("Go to Dashboard", href="/")
                ])
            
            return func(*args, **kwargs)
        return wrapper
    return decorator

# Usage in pages
@require_role('admin', 'investigator')
def layout():
    return html.Div([
        html.H2("Data Sources"),
        # ... page content
    ])
```

**Pattern**: SQLite + SQLAlchemy ORM, Flask-Login sessions, role-based decorators.

---

## 11. Version 11-17: Advanced Features

### FastAPI Endpoint (V15)

```python
# api/main.py
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import List, Optional
import jwt
import pandas as pd

app = FastAPI(
    title="FCDAI API",
    description="AML Detection API",
    version="1.0.0"
)

security = HTTPBearer()

# Models
class DetectionRequest(BaseModel):
    data: List[dict]
    threshold: Optional[float] = 0.85
    customer_level: Optional[bool] = True

class DetectionResponse(BaseModel):
    results: List[dict]
    summary: dict

# JWT verification
def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(
            credentials.credentials,
            SECRET_KEY,
            algorithms=['HS256']
        )
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

# Endpoint
@app.post("/detect", response_model=DetectionResponse)
async def run_detection(
    request: DetectionRequest,
    user: dict = Depends(verify_token)
):
    """Run AML detection on provided data."""
    # Convert to DataFrame
    df = pd.DataFrame(request.data)
    
    # Run pipeline
    pipeline = AnomalyPipeline(
        threshold=request.threshold,
        customer_level=request.customer_level
    )
    results = pipeline.run(df)
    
    # Build response
    anomalies = results[results['alert_flag'] == 1]
    
    return DetectionResponse(
        results=results.to_dict('records'),
        summary={
            'total': len(results),
            'alerts': len(anomalies),
            'alert_rate': len(anomalies) / len(results),
            'executed_by': user['username']
        }
    )

# Health check
@app.get("/health")
async def health():
    return {"status": "healthy", "version": "1.0.0"}
```

**Pattern**: RESTful API, JWT auth, Pydantic validation, OpenAPI docs.

### PII Safety Lock (V16 Enhancement A4)

```python
# src/utils/pii_safety_lock.py
import hashlib
from typing import Set

class PIISafetyLock:
    """Prevent accidental PII exposure with safety lock."""
    
    def __init__(self):
        self.pii_columns: Set[str] = set()
        self.locked = False
    
    def register_pii_columns(self, columns: List[str]):
        """Register columns containing PII."""
        self.pii_columns.update(columns)
        self.locked = True
    
    def check_access(self, columns: List[str], user_role: str) -> bool:
        """Check if user can access requested columns."""
        if not self.locked:
            return True  # No PII registered, allow
        
        # Check for PII columns in request
        pii_requested = set(columns) & self.pii_columns
        
        if not pii_requested:
            return True  # No PII in request
        
        # Only admin can access raw PII
        if user_role != 'admin':
            raise PermissionError(
                f"PII columns {pii_requested} require admin role. "
                f"Your role: {user_role}"
            )
        
        return True
    
    def get_masked_dataframe(
        self, 
        df: pd.DataFrame, 
        user_role: str, 
        requested_columns: List[str]
    ) -> pd.DataFrame:
        """Return masked or full DataFrame based on role."""
        # Check access
        self.check_access(requested_columns, user_role)
        
        # If viewer/investigator, mask PII
        if user_role in ['viewer', 'investigator']:
            pii_handler = PIIHandler()
            df_masked = pii_handler.mask_dataframe(df, list(self.pii_columns))
            return df_masked[requested_columns]
        
        # Admin gets raw access
        return df[requested_columns]

# Usage
safety_lock = PIISafetyLock()
safety_lock.register_pii_columns([
    'customer_id', 
    'account_number', 
    'ssn', 
    'email'
])

# In API/UI
try:
    df_display = safety_lock.get_masked_dataframe(
        df=results,
        user_role=current_user.role,
        requested_columns=['customer_id', 'composite_score']
    )
except PermissionError as e:
    # Log attempt
    audit_logger.log_event({
        'action': 'PII_ACCESS_DENIED',
        'user': current_user.username,
        'columns': ['customer_id'],
        'reason': str(e)
    })
    raise
```

**Pattern**: Explicit registration, role-based access, audit logging on denial.

---

**Return to**: [Version History V1-V10](../VERSION_HISTORY_V1_TO_V10.md) | [Comparison Tables](COMPARISON_TABLES.md)
