# Version 2.0 — Dash Migration

**Directory**: `fcdai_7layer_dash/`  
**Framework**: Dash + Dash Mantine Components  
**Version**: 2.0.0  
**Port**: 8071  
**Date**: January 2025

---

## Overview

Version 2 was a **complete rewrite** from Streamlit to Dash — migrating the 7-layer pipeline into a proper callback-driven web application with premium UI components. This version established the foundation for all subsequent versions through V17.

## What Changed from V1

### Framework Migration

| Aspect | V1 (Streamlit) | V2 (Dash) |
|--------|----------------|-----------|
| **Framework** | Streamlit | Dash + DMC + AG Grid |
| **Execution Model** | Script re-run | Callback-driven (reactive) |
| **Components** | Basic Streamlit widgets | Mantine premium components |
| **Data Grid** | `st.dataframe()` | AG Grid (sort, filter, pagination) |
| **Charts** | `st.plotly_chart()` | Native Plotly (full control) |
| **Routing** | `pages/` folder | `use_pages=True` with `dcc.Location` |
| **State** | `st.session_state` | `dcc.Store` + callback State |
| **Air-gap** | Partial | `serve_locally=True` (full) |
| **Port** | 8501 (default) | 8071 |

## Key Enhancements

### 1. Premium UI Components

**Dash Mantine Components (DMC)**:
- Dark mode support
- Paper, Card, Button, Select components
- NavLink for sidebar navigation
- ThemeIcon for icon rendering

**DashIconify**:
- Icon library for navigation
- Examples: `mdi:shield-lock`, `mdi:database`, `mdi:chart-line`

**AG Grid**:
- Enterprise-grade data grid
- Sort, filter, pagination, column resize
- Row selection for investigation queue

### 2. Callback Architecture

```python
@app.callback(
    Output("queue-table", "rowData"),
    Input("risk-tier-filter", "value"),
    State("data-vault", "data")
)
def filter_queue(tier, vault_data):
    # Reactive updates without full page reload
    return filtered_data
```

### 3. Multi-Page Routing

```python
app = Dash(__name__, use_pages=True, serve_locally=True)

# pages/ directory auto-discovered:
# - pages/dashboard.py (dash.register_page with path="/")
# - pages/sources.py
# - pages/pipeline.py
# ... etc
```

### 4. Air-Gap Compliance

```python
@dataclass
class AppConfig:
    SERVE_LOCALLY: bool = True  # No CDN dependencies
    SUPPRESS_CALLBACK_EXCEPTIONS: bool = True
    PREVENT_INITIAL_CALLBACKS: bool = False
```

## File Structure

```
fcdai_7layer_dash/
├── app.py              # Dash app initialization + sidebar (200 lines)
├── config.py           # Configuration (147 lines, VERSION: "2.0.0")
├── pipeline.py         # Pipeline orchestrator (280 lines)
├── layers/             # L1-L7 detection modules (7 files)
│   ├── l1_l2_ingestion.py
│   ├── l3_feature_engineering.py
│   ├── l4_preprocessing.py
│   ├── l5_detection.py      # 26 methods
│   ├── l6_ensemble.py
│   ├── l7_output.py
│   └── __init__.py
├── pages/              # UI pages (9 pages)
│   ├── dashboard.py
│   ├── data_sources.py
│   ├── pipeline_run.py
│   ├── layer_view.py
│   ├── explainability.py
│   ├── investigation_queue.py
│   ├── narratives.py
│   ├── audit_trail.py
│   └── model_diagnostics.py
├── utils/              # Utilities (5 files)
│   ├── data_io.py
│   ├── explainability.py
│   ├── generate_data.py
│   ├── logger.py
│   └── __init__.py
├── assets/             # CSS/JS (served locally)
│   └── custom.css
├── cache/              # Diskcache storage
├── data/               # Data vault
├── logs/               # Audit logs
├── models/             # Saved ML models
├── README.md
└── requirements.txt
```

**Total Files**: ~25

## Configuration

```python
@dataclass
class AppConfig:
    TITLE: str = "FCDAI Anomaly Auto Detection Tool"
    VERSION: str = "2.0.0"
    PORT: int = 8071
    SERVE_LOCALLY: bool = True
    SUPPRESS_CALLBACK_EXCEPTIONS: bool = True

@dataclass
class PathConfig:
    # Same as V1

@dataclass
class ThemeConfig:
    PRIMARY_COLOR: str = "cyan"
    COLOR_SCHEME: str = "dark"

@dataclass
class LayerConfig:
    DETECTION_METHODS: 26 methods across 8 categories
    ENSEMBLE_METHOD: str = "weighted_average"
    RISK_TIERS: Dict = {
        "CRITICAL": (0.9, 1.0),
        "HIGH": (0.7, 0.9),
        "MEDIUM": (0.5, 0.7),
        "LOW": (0.0, 0.5)
    }

@dataclass
class DataSourceConfig:
    SOURCES: Dict = {
        "kyc": {"key_column": "customer_id"},
        "transactions": {"key_column": "txn_id"},
        "alerts": {"key_column": "alert_id"},
        "cases": {"key_column": "case_id"}
    }
```

**Total Config Classes**: 5 (added AppConfig, DataSourceConfig)

## UI Pages

| Page | Route | Purpose |
|------|-------|---------|
| **Dashboard** | `/` | Risk distribution overview, key metrics |
| **Data Sources** | `/sources` | Upload KYC, TXN, Alerts, Cases |
| **Pipeline Run** | `/pipeline` | Execute 7-layer detection pipeline |
| **Layer View** | `/layers` | Inspect individual layer outputs (L1-L7) |
| **Explainability** | `/explainability` | Method contribution analysis |
| **Investigation Queue** | `/queue` | Prioritized alert investigation (AG Grid) |
| **Narratives** | `/narratives` | Auto-generated suspect narratives |
| **Audit Trail** | `/audit` | Tamper-evident log viewer |
| **Model Diagnostics** | `/diagnostics` | Method performance metrics |

## Dependencies

New dependencies added in V2:

```
dash>=2.10.0
dash-mantine-components>=0.12.0
dash-iconify>=0.1.2
dash-ag-grid>=2.0.0
plotly>=5.0.0
pandas>=1.5.0
numpy>=1.23.0
scikit-learn>=1.2.0
scipy>=1.10.0
hdbscan>=0.8.29
pyod>=1.1.0
diskcache>=5.6.0
pyarrow>=12.0.0   # Parquet support
openpyxl>=3.1.0   # Excel support
psutil>=5.9.0     # System monitoring
```

**All Licenses**: MIT, BSD, Apache (commercial-friendly)

## Architecture Improvements

### Callback Pattern

**Problem in V1**: Every interaction re-ran entire script  
**Solution in V2**: Targeted component updates via callbacks

```python
# Example: Update queue table without reloading entire page
@app.callback(
    Output("queue-table", "rowData"),
    Input("refresh-button", "n_clicks")
)
def refresh_queue(n_clicks):
    return load_queue_data()
```

### State Management

**Problem in V1**: State lost on navigation  
**Solution in V2**: `dcc.Store` components persist data across pages

```python
dcc.Store(id="data-vault", storage_type="session")  # Browser session
dcc.Store(id="config-store", storage_type="local")  # LocalStorage
```

### Performance

- **Diskcache**: Cache expensive computations (pipeline outputs, scored data)
- **Lazy loading**: Load data only when page is accessed
- **Parquet format**: Fast read/write for large datasets

## Detection Methods (Same 26 as V1)

No changes to detection logic — pure framework migration.

## What Worked Well

1. **Callback model**: Dramatically faster than Streamlit's script re-run
2. **AG Grid**: Professional data grid with sorting, filtering, pagination
3. **DMC components**: Beautiful dark-mode UI out-of-box
4. **Serve locally**: Full air-gap compliance achieved
5. **Multi-page routing**: Clean URL structure, shareable links

## Remaining Challenges (Addressed in V3+)

1. **No PII masking**: All data shown in clear text
2. **No vault system**: No encrypted storage for sensitive data
3. **Single theme**: Only dark cyan theme available
4. **No scalability testing**: Unknown performance at 100K+ customers
5. **No background tasks**: Pipeline runs block UI

---

**Previous Version**: [VERSION 1 — Streamlit Prototype](VERSION_1_STREAMLIT.md)  
**Next Version**: [VERSION 3 — PII Vault](VERSION_3_PII_VAULT.md)  
**Return to**: [Version History V1-V10](../VERSION_HISTORY_V1_TO_V10.md)
