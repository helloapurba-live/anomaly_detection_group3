# Compliance Guide

> **AIM AI Vault V15 — Regulatory Compliance Reference**

---

## Applicable Regulations

This system is designed to support compliance with the following regulatory frameworks:

### U.S. Federal Regulations

| Regulation | Authority | Relevance |
|-----------|-----------|-----------|
| **Bank Secrecy Act (BSA)** | FinCEN | Core AML detection requirement |
| **USA PATRIOT Act** | Congress | Sections 314(a), 314(b), 326 — CIP/CDD |
| **FinCEN SAR Requirements** | FinCEN | Suspicious Activity Report generation support |
| **FinCEN CTR Requirements** | FinCEN | Currency Transaction Report threshold monitoring |
| **FFIEC BSA/AML Manual** | FFIEC | Examination procedures compliance |

### Data Protection

| Regulation | Jurisdiction | Relevance |
|-----------|-------------|-----------|
| **GLBA** (Gramm-Leach-Bliley) | U.S. | Customer financial data protection |
| **GDPR** | EU | Data minimization, purpose limitation |
| **CCPA/CPRA** | California | Consumer data rights |
| **SOX** | U.S. | Audit trail requirements for financial systems |
| **PCI DSS** | Global | Payment card data security |

---

## How AIM AI Vault Supports Compliance

### 1. BSA/AML Detection (31 CFR 1020)

| Requirement | Implementation |
|------------|----------------|
| Transaction monitoring | 26 detection methods across 7 layers |
| Risk-based approach | Automatic 5-tier risk classification |
| Alert generation | Priority-based investigation queue |
| Case management support | Entity detail view with full analysis |
| Reporting support | Exportable reports for SAR filing |

### 2. Customer Due Diligence (CDD/EDD)

| Requirement | Implementation |
|------------|----------------|
| Risk scoring | Ensemble anomaly scoring (0.0–1.0) |
| Enhanced monitoring | CRITICAL/HIGH tier triggers enhanced review |
| Pattern detection | Temporal, network, and behavioral analysis |
| Ongoing monitoring | Pipeline can be run periodically |

### 3. Data Protection

| Principle | Implementation |
|-----------|----------------|
| **Data minimization** | Only necessary fields processed; PII masked by default |
| **Purpose limitation** | AML detection only; no secondary uses |
| **Access control** | RBAC with 3 roles; principle of least privilege |
| **Encryption at rest** | Fernet (AES-128-CBC) for PII fields |
| **PII masking** | Role-based masking in all API responses and logs |
| **Air-gap** | No data leaves the local machine |
| **No cloud** | Zero external network calls |

### 4. Audit Trail (SOX Section 302/404)

| Requirement | Implementation |
|------------|----------------|
| Complete audit trail | Every action logged with timestamp, user, IP |
| Tamper evidence | SHA-256 hash chain links all audit entries |
| Integrity verification | `/api/v1/audit/verify` endpoint checks chain |
| Retention | All audit logs persisted in SQLite (indefinite) |
| Access controls | Audit log viewable by admin role only |

### 5. PCI DSS (v4.0)

| Requirement | Implementation |
|------------|----------------|
| Req 3: Protect stored data | Fernet encryption for PII at rest |
| Req 7: Restrict access | RBAC with role-based permissions |
| Req 8: Authenticate users | Flask-Login + JWT + API Key |
| Req 10: Track access | Hash-chain audit logging |
| Req 12: Security policy | SECURITY.md documents all policies |

---

## Examiner Guidance

For BSA/AML examination preparation:

### Evidence Available

| Evidence Type | Location |
|--------------|----------|
| Detection methodology | docs/ARCHITECTURE.md (7-layer design) |
| Risk scoring | docs/DATA_DICTIONARY.md (score ranges) |
| Data fields | docs/DATA_DICTIONARY.md (input/output) |
| Access controls | SECURITY.md (RBAC matrix) |
| Audit trail | `/api/v1/audit/log` endpoint |
| Integrity proof | `/api/v1/audit/verify` endpoint |
| System health | `/api/v1/system/health` endpoint |
| Configuration | config.toml (secrets excluded) |

### Common Examiner Questions

| Question | Answer |
|----------|--------|
| How is PII protected? | Fernet encryption at rest + role-based masking in transit |
| Where is data stored? | Local SQLite DB + local filesystem (air-gapped) |
| Who has access? | 3 roles: Admin, Investigator, Viewer (RBAC enforced) |
| How are changes tracked? | SHA-256 hash-chain audit log on all actions |
| Can logs be tampered? | Hash chain provides tamper evidence |
| What detection methods are used? | 26 methods across 7 layers (documented in ARCHITECTURE.md) |
| Is the system connected to the internet? | No — fully air-gapped, zero external calls |

---

## Data Classification

| Category | Classification | Handling |
|----------|---------------|----------|
| Transaction data | **Confidential** | Encrypted at rest, masked in transit |
| Customer PII | **Restricted** | Encrypted, masked, access-controlled |
| Anomaly scores | **Internal** | Access-controlled, not PII |
| Audit logs | **Internal** | Tamper-evident, admin-only access |
| Configuration | **Internal** | Secrets in env vars, not in VCS |
| Source code | **Proprietary** | Internal use only, no distribution |

---

## Retention Policy

| Data Type | Minimum Retention | Authority |
|-----------|------------------|-----------|
| SAR-related records | 5 years from filing | 31 CFR 1020.320 |
| CTR records | 5 years | 31 CFR 1010.306 |
| Transaction records | 5 years | BSA General |
| Audit logs | 7 years recommended | SOX / best practice |
| System logs | 1 year minimum | Internal policy |

---

## Disclaimer

This system is a **detection tool** that supports human investigators. It does not make filing decisions. All SAR/CTR filing decisions must be made by qualified BSA officers in accordance with regulatory requirements.

---

*AIM AI Vault V15 Compliance Guide — Internal Documentation*
