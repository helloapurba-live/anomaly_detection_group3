# API Reference

> **AIM AI Vault V15 — Complete REST API Documentation**  
> Base URL: `http://127.0.0.1:8079/api/v1`

---

## Authentication

All endpoints (except `POST /auth/token`) require authentication via one of:

| Method | Header | Format |
|--------|--------|--------|
| JWT Bearer | `Authorization` | `Bearer <token>` |
| API Key | `X-API-Key` | `<key>` |

### Get a JWT Token

```bash
curl -X POST http://127.0.0.1:8079/api/v1/auth/token \
  -H "Content-Type: application/json" \
  -d '{"username": "analyst", "password": "your_password"}'
```

Response:
```json
{
  "access_token": "eyJ0eXAiOi...",
  "token_type": "bearer",
  "expires_in": 3600,
  "role": "investigator"
}
```

### Use the Token

```bash
curl -H "Authorization: Bearer eyJ0eXAiOi..." \
  http://127.0.0.1:8079/api/v1/system/health
```

### Use an API Key

```bash
curl -H "X-API-Key: aim_v15_abc123..." \
  http://127.0.0.1:8079/api/v1/system/health
```

---

## Rate Limiting

- **Limit**: 100 requests per minute per IP (configurable)
- **Algorithm**: Sliding window
- **Response on limit**: HTTP 429 with `Retry-After` guidance

---

## PII Masking

All responses automatically mask PII fields based on the caller's role:

| Role | Masking Behaviour | Example |
|------|------------------|---------|
| Admin | SHA-256 hash | `a1b2c3d4e5...` |
| Investigator | Partial mask | `J***n` |
| Viewer | Full redaction | `[REDACTED]` |

---

## Endpoints

### Authentication

#### `POST /api/v1/auth/token`
Issue a JWT access token.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| username | string | Yes | Login username |
| password | string | Yes | Login password |

**Permissions**: None (public endpoint)

**Response**: `TokenResponse`
```json
{
  "access_token": "string",
  "token_type": "bearer",
  "expires_in": 3600,
  "role": "investigator"
}
```

---

#### `DELETE /api/v1/auth/revoke`
Revoke the current JWT token (blacklist it for remaining lifetime).

**Permissions**: `auth:revoke` (admin, investigator)

**Response**:
```json
{"success": true, "data": {"revoked": true}}
```

---

### Pipeline

#### `POST /api/v1/pipeline/run`
Start a new detection pipeline execution.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| description | string | No | Run description |

**Permissions**: `pipeline:run` (admin only)

**Response**: `PipelineRunResponse`
```json
{
  "run_id": "uuid-string",
  "status": "PENDING",
  "message": "Pipeline queued for execution",
  "started_at": "2025-01-15T10:30:00"
}
```

---

#### `GET /api/v1/pipeline/status/{run_id}`
Get the current status of a specific pipeline run.

| Parameter | Type | Location | Description |
|-----------|------|----------|-------------|
| run_id | string | path | The pipeline run UUID |

**Permissions**: `pipeline:status` (admin, investigator)

**Response**:
```json
{
  "success": true,
  "data": {"run_id": "uuid", "status": "COMPLETED"}
}
```

---

#### `GET /api/v1/pipeline/history`
List past pipeline runs with pagination.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| page | int | 1 | Page number (1-based) |
| page_size | int | 20 | Items per page (max 100) |

**Permissions**: `pipeline:history` (admin, investigator)

**Response**: `PaginatedResponse` with `PipelineHistoryItem` items.

---

### Results

#### `GET /api/v1/results/scored/{run_id}`
Get scored entities for a pipeline run. PII auto-masked.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| run_id | string | — | Pipeline run UUID |
| page | int | 1 | Page number |
| page_size | int | 50 | Items per page (max 500) |
| min_score | float | 0.0 | Minimum anomaly score filter |
| tier | string | null | Risk tier filter (CRITICAL, HIGH, MEDIUM, LOW, NORMAL) |

**Permissions**: `results:scored` (admin, investigator)

---

#### `GET /api/v1/results/alerts`
Get investigation queue alerts (high-risk entities).

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| status | string | null | Filter: OPEN, INVESTIGATING, CLOSED, ESCALATED |
| tier | string | null | Risk tier filter |
| page | int | 1 | Page number |
| page_size | int | 50 | Items per page (max 200) |

**Permissions**: `results:alerts` (admin, investigator)

---

#### `GET /api/v1/results/risk-tiers`
Get aggregate statistics by risk tier.

**Permissions**: `results:risk_tiers` (admin, investigator, viewer)

**Response**:
```json
{
  "success": true,
  "data": [
    {
      "tier": "CRITICAL",
      "count": 15,
      "percentage": 1.5,
      "avg_score": 0.9523,
      "min_score": 0.9001,
      "max_score": 0.9987
    }
  ]
}
```

---

#### `GET /api/v1/results/entity/{entity_id}`
Get detailed analysis for a single entity by hashed ID.

| Parameter | Type | Location | Description |
|-----------|------|----------|-------------|
| entity_id | string | path | SHA-256 hashed entity identifier |

**Permissions**: `results:entity` (admin, investigator)

---

### Data

#### `GET /api/v1/data/sources`
List loaded data sources with row/column counts.

**Permissions**: `data:sources` (admin, investigator)

**Response**:
```json
{
  "success": true,
  "data": [
    {"name": "transactions.csv", "row_count": 50000, "column_count": 24}
  ]
}
```

---

### Audit

#### `GET /api/v1/audit/log`
Retrieve audit trail entries.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| page | int | 1 | Page number |
| page_size | int | 50 | Items per page (max 200) |
| action | string | null | Filter by action type |
| user | string | null | Filter by username |

**Permissions**: `audit:log` (admin only)

---

#### `GET /api/v1/audit/verify`
Verify hash-chain integrity of the audit trail.

**Permissions**: `audit:verify` (admin only)

**Response**:
```json
{
  "success": true,
  "data": {
    "valid": true,
    "total_entries": 1520,
    "verified_entries": 1520,
    "message": "Hash chain integrity verified"
  }
}
```

---

### System

#### `GET /api/v1/system/health`
Liveness check with component health statuses.

**Permissions**: `system:health` (all roles)

**Response**: `HealthResponse`

---

#### `GET /api/v1/system/metrics`
Current system resource metrics from watchdog.

**Permissions**: `system:metrics` (admin, investigator)

**Response**:
```json
{
  "success": true,
  "data": {
    "cpu_percent": 23.5,
    "memory_percent": 45.2,
    "memory_rss_mb": 512,
    "disk_percent": 68.0,
    "disk_free_gb": 120.5,
    "db_size_mb": 2.3,
    "thread_count": 12
  }
}
```

---

#### `GET /api/v1/system/circuit-breakers`
Get status of all circuit breakers.

**Permissions**: `system:circuit_breakers` (admin only)

---

## Error Responses

All errors follow a consistent format:

```json
{
  "success": false,
  "error": "Human-readable error message",
  "error_type": "ExceptionClassName"
}
```

| Status Code | Meaning |
|------------|---------|
| 401 | Missing or invalid authentication |
| 403 | Insufficient permissions for this endpoint |
| 404 | Resource not found |
| 429 | Rate limit exceeded |
| 500 | Internal server error (details in logs, never PII) |

---

## Interactive Documentation

- **Swagger UI**: http://127.0.0.1:8079/docs
- **ReDoc**: http://127.0.0.1:8079/redoc
- **OpenAPI JSON**: http://127.0.0.1:8079/openapi.json

---

*AIM AI Vault V15 API Reference — Internal Documentation*
