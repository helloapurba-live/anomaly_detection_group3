# Version 8.0 — Role-Based Column Resolution & Audit Lineage

**Directory**: `FCDAI_Annomaly_auto_detection_version8/`  
**Version**: 8.0.0  
**Port**: 8070  
**Date**: February 2026

---

## Overview

Version 8 was a **production-readiness release** focused on eliminating ALL hardcoded column names via role-based resolution, adding enterprise audit trail infrastructure, and enforcing memory safety for 8 GB RAM environments.

## What Changed from V7

### Zero Hardcoded Column Names

**V7 Problem**: SchemaDetector auto-detected types, but code still assumed specific column names in places

**V8 Solution**: **Column Role Configuration** — resolve columns by semantic role, never by name

##Key Enhancements

### 1. Column Role Configuration (`ColumnRoleConfig`)

```python
# config.py — V8

@dataclass
class ColumnRoleConfig:
    """
    Map semantic roles to possible column name aliases.
    System resolves columns by role, never by hardcoded name.
    """
    ROLE_ALIASES: Dict[str, List[str]] = field(default_factory=lambda: {
        # Identity roles
        "primary_key": ["cust_id", "customer_id", "party_id", "client_id", "entity_id"],
        "entity_name": ["cust_name", "customer_name", "party_name", "full_name"],
        
        # Transaction roles
        "amount": ["amount", "txn_amount", "transaction_amount", "value", "amt"],
        "timestamp": ["timestamp", "txn_date", "transaction_date", "date", "datetime"],
        "account_key": ["account_id", "acct_id", "account_number", "account"],
        "txn_key": ["txn_id", "transaction_id", "trans_id", "id"],
        "txn_type": ["txn_type", "transaction_type", "type", "category"],
        
        # Geo/context roles
        "currency": ["currency", "ccy", "currency_code", "cur"],
        "country": ["country", "country_code", "jurisdiction", "nation"],
        "channel": ["channel", "txn_channel", "payment_method", "method"],
        
        # Network roles
        "counterparty": ["counterparty_id", "beneficiary_id", "recipient_id", "to_id"],
        "originator": ["originator_id", "sender_id", "from_id", "source_id"],
        
        # Risk roles
        "risk_score": ["risk_score", "score", "risk_rating", "rating"],
        "risk_tier": ["risk_tier", "tier", "risk_level", "level", "priority"]
    })
    
    # User overrides (highest priority)
    USER_OVERRIDES: Dict[str, str] = field(default_factory=dict)
    # Example: {"primary_key": "my_custom_id_column"}
```

### 2. Column Resolution Engine

New utility: `utils/column_resolver.py`

**3-Step Resolution Logic**:

```python
# utils/column_resolver.py

class ColumnResolver:
    def resolve_role(self, df: pd.DataFrame, role: str) -> Optional[str]:
        """
        Resolve column name for a semantic role:
        
        Priority:
        1. User overrides (if specified)
        2. Exact alias match (case-sensitive)
        3. Partial match (case-insensitive substring)
        
        Returns: Column name or None
        """
        # Step 1: Check user overrides
        if role in self.config.USER_OVERRIDES:
            override = self.config.USER_OVERRIDES[role]
            if override in df.columns:
                return override
        
        # Step 2: Exact alias match
        aliases = self.config.ROLE_ALIASES.get(role, [])
        for alias in aliases:
            if alias in df.columns:
                return alias
        
        # Step 3: Partial match (case-insensitive)
        for alias in aliases:
            for col in df.columns:
                if alias.lower() in col.lower():
                    return col
        
        # Not found
        return None
```

**Usage Throughout Codebase**:
```python
# Before V8 (hardcoded)
customer_id = df["customer_id"]  # Crashes if column name differs

# After V8 (role-based)
resolver = ColumnResolver()
primary_key_col = resolver.resolve_role(df, "primary_key")
if primary_key_col:
    customer_id = df[primary_key_col]
else:
    raise ValueError("No primary_key column found")
```

### 3. Resource Configuration (`ResourceConfig`)

Memory-safe limits for 8 GB CPU-only environments:

```python
@dataclass
class ResourceConfig:
    """
    Memory safety guardrails for resource-constrained environments.
    """
    MAX_ROWS_FOR_HEAVY_METHODS: int = 5000    # LOF, HDBSCAN, Spectral limit
    MAX_FEATURES_FOR_PCA: int = 100            # PCA n_components limit
    MAX_MEMORY_MB: int = 4096                  # 4 GB memory ceiling
    MAX_METHOD_TIMEOUT_SECONDS: int = 300      # 5 min per method max
    ENABLE_MEMORY_MONITORING: bool = True      # Track memory usage per method
    
    # Heavy method list (triggers row limit)
    HEAVY_METHODS: List[str] = field(default_factory=lambda: [
        "lof",              # O(n²) distance computation
        "hdbscan",          # O(n²) clustering
        "spectral",         # O(n²) eigenvector computation
        "som",              # O(n²) self-organizing map
        "dbscan",           # O(n²) density computation
    ])
```

**Usage in Detection Layer**:
```python
# layers/l5_detection.py — V8

def execute_lof(X, config):
    n_samples = X.shape[0]
    
    # Memory safety check
    if n_samples > config.RESOURCE.MAX_ROWS_FOR_HEAVY_METHODS:
        logger.warning(f"LOF: {n_samples} samples exceeds limit {config.RESOURCE.MAX_ROWS_FOR_HEAVY_METHODS}")
        logger.warning("LOF: Downsampling to limit...")
        X = X.sample(n=config.RESOURCE.MAX_ROWS_FOR_HEAVY_METHODS, random_state=42)
    
    # Execute with timeout
    with timeout(config.RESOURCE.MAX_METHOD_TIMEOUT_SECONDS):
        scores = LOF().fit_predict(X)
    
    return scores
```

### 4. Audit & Data Lineage Configuration

```python
@dataclass
class AuditConfig:
    """
    Enterprise-grade audit trail and data lineage tracking.
    """
    ENABLE_DATA_LINEAGE: bool = True           # Track data transformations
    ENABLE_RUN_VERSIONING: bool = True         # Version each pipeline run
    ENABLE_HASH_CHAIN_LOGS: bool = True        # Tamper-evident audit logs
    LOG_ROTATION_MAX_BYTES: int = 10_000_000   # 10 MB per log file
    LOG_RETENTION_DAYS: int = 365              # 1 year retention
    
    HASH_ALGORITHM: str = "sha256"             # SHA-256 for audit chain
    CAPTURE_CONFIG_SNAPSHOT: bool = True       # Save config with each run
    RECORD_METHOD_TIMINGS: bool = True         # Track execution time per method
    RECORD_DATA_PROVENANCE: bool = True        # Track source → output lineage
```

**Audit Entry Structure**:
```python
# Logged for every action
{
    "timestamp": "2026-02-15T14:30:22.123Z",
    "user": "admin",
    "action": "pipeline_run",
    "run_id": "RUN-20260215-143022",
    "config_snapshot": {...},
    "data_sources": ["MASTER.csv", "transactions.csv"],
    "n_customers": 1000,
    "methods_executed": ["isolation_forest", "lof", ...],
    "execution_time_sec": 245.67,
    "prev_hash": "sha256:abc123...",
    "current_hash": "sha256:def456..."
}
```

### 5. New UI Pages

| Page | Route | Purpose |
|------|-------|---------|
| **Admin** | `/admin` | User management, system settings |
| **Config Panel** | `/config` | Runtime configuration editor |

**Total pages**: 12 (up from 11 in V7)

### 6. New Utilities (4 Files)

| Utility | Lines | Purpose |
|---------|-------|---------|
| `utils/column_resolver.py` | 180 | Column role resolution engine |
| `utils/type_specific_imputer.py` | 220 | Type-aware missing data imputation |
| `utils/method_config_generator.py` | 150 | Auto-generate method configurations |
| `utils/data_gen.py` | 320 | Enhanced synthetic data generator |

### 7. Type-Specific Imputation

```python
# utils/type_specific_imputer.py

class TypeSpecificImputer:
    """
    Impute missing values based on detected column type.
    """
    def impute(self, series: pd.Series, col_type: str) -> pd.Series:
        if col_type == "CONTINUOUS":
            # Median imputation for continuous
            return series.fillna(series.median())
        
        elif col_type == "CATEGORICAL":
            # Mode imputation for categorical
            return series.fillna(series.mode()[0] if len(series.mode()) > 0 else "UNKNOWN")
        
        elif col_type == "BINARY":
            # Mode or majority class
            return series.fillna(series.mode()[0])
        
        elif col_type == "ORDINAL":
            # Median (preserves order)
            return series.fillna(series.median())
        
        elif col_type == "DATETIME":
            # Forward fill for datetime
            return series.fillna(method='ffill')
        
        else:
            # Default: drop or fill with sentinel
            return series.fillna("MISSING")
```

## File Structure

```
FCDAI_Annomaly_auto_detection_version8/
├── app.py                              # 445 lines (+9 from V7)
├── config.py                           # 326 lines (+61 from V7, 3 new configs)
├── pipeline.py                         # 318 lines (column resolver integration)
├── pipeline_runner.py
├── verify_scalability.py
├── diagnostic_trace.py
├── _patch_ds.py
├── README.md
├── requirements.txt
│
├── layers/                             # 7 files
│   ├── l5_detection.py                 # Memory safety checks added
├── pages/                              # 12 pages (+2 new)
│   ├── admin.py                        # NEW: User/system management
│   ├── config_panel.py                 # NEW: Runtime config editor
│   ├── data_sources.py
│   ├── ... (10 existing pages)
├── utils/                              # 14 files (+4 new)
│   ├── column_resolver.py              # NEW (180 lines)
│   ├── type_specific_imputer.py        # NEW (220 lines)
│   ├── method_config_generator.py      # NEW (150 lines)
│   ├── data_gen.py                     # NEW (320 lines)
│   ├── schema_detector.py
│   ├── auto_params.py
│   ├── ... (8 existing utils)
│
├── assets/
├── cache/
├── data/
├── logs/
│   └── .hash_state                     # NEW: Hash chain persistence (V9)
└── models/
```

**Total Files**: ~47 (+4 utils, +2 pages from V7)

## Configuration Classes Growth

| Config Class | V7 | V8 |
|--------------|----|----|
| AppConfig | ✓ | ✓ |
| PathConfig | ✓ | ✓ |
| ThemeConfig | ✓ | ✓ |
| LayerConfig | ✓ | ✓ |
| DataSourceConfig | ✓ | ✓ |
| PIIConfig | ✓ | ✓ |
| **ColumnRoleConfig** | — | **✓** |
| **ResourceConfig** | — | **✓** |
| **AuditConfig** | — | **✓** |

**Total Config Classes**: 9 (+3 from V7)

## Admin Page Features

### User Management
- View all users
- Add/remove users
- Assign roles (admin, investigator, viewer)
- Reset passwords
- View user activity logs

### System Settings
- Configure resource limits
- Set audit retention policies
- Enable/disable features
- View system health metrics

## Config Panel Features

### Runtime Configuration Editor
- Edit config values without code changes
- Validate config changes before applying
- Preview impact of changes
- Rollback to previous config
- Export/import config files

### Config Categories
1. **Detection**: Method weights, thresholds
2. **Resources**: Memory limits, timeouts
3. **Audit**: Logging, retention, hash chain
4. **UI**: Themes, page access, defaults

## What Worked Well

1. **Column role resolution**: Eliminated 100+ hardcoded column references
2. **Memory safety**: HEAVY_METHODS limit prevents OOM crashes
3. **Audit lineage**: Every action traceable with hash chain
4. **Admin page**: Enables runtime system management
5. **Type-specific imputation**: Better missing data handling

## Remaining Challenges (Addressed in V9+)

1. **PII masking disabled by default**: Should be enabled (→ V9)
2. **No hash chain persistence**: _prev_hash lost on restart (→ V9)
3. **No epsilon tolerance**: Float boundary issues in tier assignment (→ V9)
4. **No upload size validation**: Can upload arbitrarily large files (→ V9)
5. **VAE KL divergence bug**: Gradient not backpropagating (→ V9)

---

**Previous Version**: [VERSION 7 — Flexible Architecture](VERSION_7_FLEXIBLE_ARCHITECTURE.md)  
**Next Version**: [VERSION 9 — VAT & FMEA](VERSION_9_VAT_FMEA.md)  
**Return to**: [Version History V1-V10](../VERSION_HISTORY_V1_TO_V10.md)
