# Version 6.0 — Customer-Level Detection

**Directory**: `FCDAI_Annomaly_auto_detection_version6/`  
**Version**: 6.0.0  
**Port**: 8109  
**Release Date**: February 2026

---

## Overview

Version 6 was the **most significant architectural shift** in the project — moving from transaction-level to **customer-level** anomaly detection. This fundamentally changed how the system processes and scores data, resulting in 10x reduction in records processed while improving detection accuracy.

## What Changed from V5

### Paradigm Shift: Transaction → Customer

**V5 Approach**:
```
10,000 transactions → L5 processes 10,000 records → 10,000 scores
```

**V6 Approach**:
```
10,000 transactions → Roll up to 1,000 customers → L5 processes 1,000 records → 1,000 scores
```

**Impact**: 90% reduction in records processed, 20% faster execution, 28% less memory.

## Key Enhancements

### 1. Customer Aggregation Engine

New module: `utils/customer_aggregation.py`

**Integration Point**: Between L1-2 and L3

```python
# utils/customer_aggregation.py

def aggregate_to_customer_level(transactions_df, kyc_df):
    """
    Roll up all transactions to customer level:
    - Volume features: txn_count, amount_total, amount_mean
    - Temporal features: first_txn_date, last_txn_date, account_age_days
    - Behavioral features: amount_gini, amount_entropy, amount_cv
    - Structuring indicators: count_just_below_10k, pct_just_below_10k
    - Network features: unique_counterparties, unique_accounts
    """
    customer_features = transactions_df.groupby('customer_id').agg({
        # Volume metrics
        'txn_id': 'count',                    # txn_count
        'amount': ['sum', 'mean', 'median', 'std', 'min', 'max'],
        
        # Temporal metrics
        'timestamp': ['min', 'max'],          # first_txn, last_txn
        
        # Network metrics
        'counterparty_id': 'nunique',         # unique_counterparties
        'account_id': 'nunique',              # unique_accounts
        
        # Behavioral metrics (computed separately)
        # - Gini coefficient of amounts
        # - Entropy of amounts
        # - Coefficient of variation
    })
    
    # Merge with KYC data
    customer_data = customer_features.merge(kyc_df, on='customer_id')
    
    return customer_data
```

**Configuration**:
```python
@dataclass
class AppConfig:
    CUSTOMER_LEVEL_PROCESSING: bool = True  # NEW in V6
```

### 2. Enhanced Customer Features (80+)

**V5**: ~50 transaction-level features  
**V6**: 80+ customer-level features

#### Volume Features (8)
- `txn_count`
- `txn_frequency` (txn per day)
- `amount_total`
- `amount_mean`
- `amount_median`
- `amount_std`
- `amount_min`, `amount_max`

#### Structuring Indicators (4)
- `count_just_below_10k` (amount in $9,000-$9,999)
- `pct_just_below_10k` (% of transactions)
- `count_round_amounts` (multiples of $1,000)
- `pct_round_amounts`

#### Temporal Features (6)
- `first_txn_date`
- `last_txn_date`
- `account_age_days`
- `night_txn_count` (10pm-6am)
- `night_txn_pct`
- `weekend_txn_count`, `weekend_txn_pct`

#### Behavioral Features (8)
- `amount_gini` (inequality measure, 0-1)
- `amount_entropy` (Shannon entropy of amount distribution)
- `amount_skew` (asymmetry of distribution)
- `amount_kurtosis` (tail heaviness)
- `amount_cv` (coefficient of variation)
- `velocity_7d`, `velocity_30d` (txn/week, txn/month)

#### Network Features (4)
- `unique_counterparties`
- `unique_accounts`
- `avg_counterparty_per_txn`
- `account_diversity_ratio`

### 3. Tiered Consensus Ensemble (Layer 6 Rewrite)

**Problem in V5**: Score-only thresholds miss high-consensus anomalies

**Example Failure Case**:
- Customer has score 0.68 (below HIGH threshold of 0.70)
- BUT 22 out of 25 methods flagged as anomaly (88% consensus)
- V5: Classified as MEDIUM
- V6: Classified as HIGH (high consensus override)

**V6 Solution**: Dual threshold logic

```python
# layers/l6_ensemble.py — V6

def assign_risk_tier(score, vote_count, total_methods=25):
    """
    Tier assignment with dual thresholds:
    Trigger if EITHER score OR votes meets threshold
    """
    tiers = [
        ("CRITICAL", 0.95, 23),  # score ≥ 0.95 OR votes ≥ 23/25
        ("HIGH", 0.85, 18),       # score ≥ 0.85 OR votes ≥ 18/25
        ("MEDIUM", 0.70, 12),     # score ≥ 0.70 OR votes ≥ 12/25
        ("LOW", 0.50, 8)          # score ≥ 0.50 OR votes ≥ 8/25
    ]
    
    for tier_name, score_threshold, vote_threshold in tiers:
        if score >= score_threshold or vote_count >= vote_threshold:
            return tier_name
    
    return "LOW"
```

### 4. Percentile Rank Normalization

**Problem in V5**: Min-max scaling sensitive to outliers

**V6 Solution**: Rank-based normalization

```python
# layers/l6_ensemble.py

def normalize_scores_percentile(scores):
    """
    Convert each score to 0-1 based on its rank position:
    normalized_score[i] = rank(score[i]) / n
    
    Benefits:
    - Outlier-robust
    - Equal distribution across 0-1 range
    - Preserves relative ordering
    """
    from scipy.stats import rankdata
    ranks = rankdata(scores, method='average')
    normalized = ranks / len(scores)
    return normalized
```

### 5. Domain-Driven Method Weights

Not all methods are equally reliable for financial crime:

```python
METHOD_WEIGHTS = {
    # Structuring-specific (highest weight)
    "benford": 2.0,              # Benford's Law — structuring gold standard
    
    # Production-proven (high weight)
    "isolation_forest": 1.5,
    "lof": 1.5,                  # Local Outlier Factor — density specialist
    "extended_if": 1.3,
    "hdbscan": 1.2,
    "community": 1.2,            # Network community detection
    
    # Standard methods (weight 1.0)
    "z_score": 1.0,
    "iqr": 1.0,
    "mahalanobis": 1.0,
    # ... 10 more at 1.0
    
    # Experimental (lower weight)
    "autoencoder": 0.8,
    "vae": 0.8,
    "lstm_ae": 0.5,              # LSTM Autoencoder — most experimental
}
```

**Weighted Fusion**:
```python
final_score = sum(score[i] * weight[i] for i in methods) / sum(weights)
```

## Performance Impact

### V5 vs V6 Comparison

| Metric | V5 | V6 | Change |
|--------|----|----|--------|
| **Processing Level** | Transaction | Customer | Paradigm shift |
| **Records Processed** | 10,000 | 1,000 | **-90%** |
| **Features Generated** | 50 | 80+ | **+60%** |
| **Execution Time** | ~5 min | ~4 min | **-20%** |
| **Memory Usage** | 250 MB | 180 MB | **-28%** |
| **Ensemble Strategy** | Score-only | Tiered Consensus | Upgraded |
| **Normalization** | Min-max | Percentile rank | Outlier-robust |
| **Method Weights** | Equal (1.0) | Domain-driven (0.5-2.0) | Context-aware |

## New Files

| File | Purpose | Lines |
|------|---------|-------|
| `utils/customer_aggregation.py` | Customer roll-up engine | ~180 |
| `VERSION_6_RELEASE_NOTES.md` | Customer-level detection docs | 339 |
| `DIAGNOSTIC_REPORT.md` | "100 vs 75 customers" investigation | 285 |
| `diagnostic_trace.py` | Data flow diagnostic utility | ~120 |

## Bug Fixes Documented

### Issue 1: "100 vs 75 customers" Data Loss Scare

**Symptom**: Pipeline showed 75 customers, expected 100  
**Investigation**: Created diagnostic_trace.py to trace data flow  
**Root Cause**: Source data had 75 unique customers, not 100 (sample data issue)  
**Resolution**: Confirmed zero data loss; added diagnostic script for future validation

### Issue 2: Risk-by-Family Table BLANK

**Symptom**: AG Grid table on investigation page showed blank rows  
**Root Cause**: AG Grid field names != pipeline output field names  
**Fix**: Aligned field names in `pipeline_run.py` output with AG Grid `columnDefs`

## Configuration

```python
@dataclass
class AppConfig:
    VERSION: str = "6.0.0"
    PORT: int = 8109
    CUSTOMER_LEVEL_PROCESSING: bool = True  # NEW
```

**Total Config Classes**: 6 (same as V5)

## File Structure

```
FCDAI_Annomaly_auto_detection_version6/
├── app.py                          # 437 lines (-7 from V5)
├── config.py                       # 265 lines (+37 from V5)
├── pipeline.py                     # 292 lines (customer-level logic)
├── pipeline_runner.py
├── verify_scalability.py
├── diagnostic_trace.py             # NEW
├── VERSION_6_RELEASE_NOTES.md      # NEW (339 lines)
├── DIAGNOSTIC_REPORT.md            # NEW (285 lines)
├── README.md
├── requirements.txt
│
├── layers/                         # 7 files
│   ├── l6_ensemble.py              # REWRITTEN (tiered consensus)
├── pages/                          # 11 pages
├── utils/                          # 8 files (+1 new)
│   ├── customer_aggregation.py     # NEW
│
├── assets/
├── cache/
├── data/
├── logs/
└── models/
```

**Total Files**: ~34 (+3 from V5)

## What Worked Well

1. **Customer aggregation**: Dramatically reduced processing overhead
2. **Tiered consensus**: Catches high-agreement anomalies missed by score thresholds
3. **Percentile normalization**: Outlier-robust, equal distribution
4. **Domain weights**: Benford's Law now has 2x influence (correct for AML)
5. **80+ customer features**: Rich feature set improves detection quality

## Remaining Challenges (Addressed in V7+)

1. **Hardcoded table names**: System expects specific table names (→ V7)
2. **No schema flexibility**: Adding new data sources requires code changes (→ V7)
3. **No auto-detection**: Column types manually specified (→ V7)
4. **No column role resolution**: Hardcoded column names (→ V8)

---

**Previous Version**: [VERSION 5 — Production Hardening](VERSION_5_PRODUCTION_HARDENING.md)  
**Next Version**: [VERSION 7 — Flexible Architecture](VERSION_7_FLEXIBLE_ARCHITECTURE.md)  
**Return to**: [Version History V1-V10](../VERSION_HISTORY_V1_TO_V10.md)
