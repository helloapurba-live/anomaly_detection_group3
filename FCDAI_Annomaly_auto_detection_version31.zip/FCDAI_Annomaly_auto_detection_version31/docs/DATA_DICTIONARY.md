# Data Dictionary

> **AIM AI Vault V15 — Data Field Reference**

---

## Input Data Fields

These fields are expected in uploaded transaction data (CSV/Excel):

### Transaction Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `transaction_id` | string | Yes | Unique transaction identifier |
| `cust_id` / `customer_id` | string | Yes | Customer identifier (PII — masked in API) |
| `transaction_amount` | float | Yes | Transaction amount in local currency |
| `transaction_date` | datetime | Yes | Transaction date/time |
| `transaction_type` | string | No | Type: WIRE, ACH, CHECK, CASH, CARD |
| `sender_account` | string | No | Originator account (PII) |
| `receiver_account` | string | No | Beneficiary account (PII) |
| `sender_name` | string | No | Originator name (PII) |
| `receiver_name` | string | No | Beneficiary name (PII) |
| `currency` | string | No | ISO currency code (USD, EUR, etc.) |
| `country_code` | string | No | ISO country code |
| `branch_id` | string | No | Branch identifier |
| `channel` | string | No | Channel: ONLINE, BRANCH, ATM, MOBILE |

### Customer Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `cust_id` | string | Yes | Customer identifier (PII) |
| `account_type` | string | No | INDIVIDUAL, BUSINESS, JOINT |
| `account_open_date` | date | No | Account opening date |
| `kyc_status` | string | No | KYC verification status |
| `risk_rating` | string | No | Pre-existing risk rating |

---

## Output / Scored Fields

These fields are produced by the detection pipeline:

### Per-Entity Scores

| Field | Type | Range | Description |
|-------|------|-------|-------------|
| `entity_id` | string | — | SHA-256 hashed customer identifier |
| `anomaly_score` | float | 0.0–1.0 | Final ensemble anomaly score |
| `risk_tier` | enum | 5 values | Risk classification (see below) |

### Layer-Specific Scores

| Field | Layer | Description |
|-------|-------|-------------|
| `l1_zscore` | L1 | Z-score normalized anomaly |
| `l1_benford` | L1 | Benford's law deviation |
| `l1_iqr` | L1 | Interquartile range outlier score |
| `l2_iforest` | L2 | Isolation Forest anomaly score |
| `l2_lof` | L2 | Local Outlier Factor score |
| `l2_ocsvm` | L2 | One-Class SVM decision score |
| `l3_autoencoder` | L3 | Reconstruction error score |
| `l4_pagerank` | L4 | PageRank centrality score |
| `l4_degree` | L4 | Degree centrality |
| `l5_velocity` | L5 | Transaction velocity score |
| `l5_burst` | L5 | Burst detection score |
| `l5_seasonal` | L5 | Seasonality deviation |
| `l6_ensemble` | L6 | Weighted ensemble score |
| `l7_community` | L7 | Community anomaly score |

### Risk Tier Classification

| Tier | Score Range | Action |
|------|-------------|--------|
| **CRITICAL** | 0.90–1.00 | Immediate investigation required |
| **HIGH** | 0.75–0.89 | Priority investigation |
| **MEDIUM** | 0.50–0.74 | Enhanced monitoring |
| **LOW** | 0.25–0.49 | Standard monitoring |
| **NORMAL** | 0.00–0.24 | No action required |

---

## PII Fields

These fields are automatically detected and masked in API responses:

| Pattern | Examples | Detection Method |
|---------|----------|-----------------|
| Name fields | `sender_name`, `receiver_name`, `customer_name` | Field name matching |
| Account fields | `sender_account`, `receiver_account`, `account_number` | Field name matching |
| ID fields | `cust_id`, `customer_id`, `ssn`, `tax_id` | Field name matching |
| Address fields | `address`, `city`, `zip_code` | Field name matching |
| Contact fields | `email`, `phone`, `phone_number` | Field name matching |

### Masking Rules by Role

| Field | Admin | Investigator | Viewer |
|-------|-------|-------------|--------|
| `cust_id` | `a1b2c3...` (SHA-256) | `C***5` | `[REDACTED]` |
| `sender_name` | `8f3a2b...` (SHA-256) | `J***n` | `[REDACTED]` |
| `account_number` | `c7d8e9...` (SHA-256) | `1***7` | `[REDACTED]` |

---

## Database Tables

### `users`

| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | Primary key |
| username | TEXT | Login username |
| password_hash | TEXT | scrypt password hash |
| role | TEXT | admin / investigator / viewer |
| created_at | TEXT | Account creation timestamp |

### `audit_log`

| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | Primary key |
| timestamp | TEXT | ISO 8601 timestamp |
| action | TEXT | Action performed |
| username | TEXT | Acting user |
| details | TEXT | Action details |
| client_ip | TEXT | Client IP address |
| hash_chain | TEXT | SHA-256 chain hash |

### `api_keys`

| Column | Type | Description |
|--------|------|-------------|
| key_hash | TEXT | SHA-256 hash (primary key) |
| label | TEXT | Human-readable label |
| role | TEXT | Assigned role |
| created_at | TEXT | Creation timestamp |
| expires_at | TEXT | Expiration timestamp |
| revoked | INTEGER | 0 = active, 1 = revoked |

---

## API Response Schemas

See [API_REFERENCE.md](API_REFERENCE.md) for complete response schema documentation.

---

*AIM AI Vault V15 Data Dictionary — Internal Documentation*
