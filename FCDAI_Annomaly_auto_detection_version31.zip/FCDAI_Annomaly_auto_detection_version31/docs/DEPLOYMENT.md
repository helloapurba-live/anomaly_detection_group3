# Deployment Guide

> **AIM AI Vault V15 — Installation & Deployment**

---

## Requirements

### Hardware

| Resource | Minimum | Recommended |
|----------|---------|-------------|
| CPU | 4 cores | 8+ cores |
| RAM | 8 GB | 16+ GB |
| Disk | 10 GB free | 50+ GB free |
| OS | Windows 10 | Windows 11 |

### Software

| Software | Version | Purpose |
|----------|---------|---------|
| Python | 3.11+ | Runtime |
| Anaconda/Miniconda | Latest | Environment management |
| Git | 2.40+ | Version control (optional) |

### Network

- **Air-gapped** — No internet required after initial setup
- Ports 8078 (Dashboard) and 8079 (API) must be available on localhost
- No firewall rules needed (localhost only by default)

---

## Installation

### Step 1: Transfer Files

Transfer the project directory to the air-gapped workstation via approved media (USB, secure file transfer).

```
FCDAI_Annomaly_auto_detection_version15/
```

### Step 2: Create Python Environment

```bash
conda create -n ai311 python=3.11 -y
conda activate ai311
```

### Step 3: Install Dependencies

If on air-gapped machine, pre-download wheels on a connected machine first:

```bash
# On connected machine:
pip download -r requirements.txt -d ./wheels/

# Transfer wheels/ to air-gapped machine, then:
pip install --no-index --find-links=./wheels/ -r requirements.txt
```

Or if network is available during setup:

```bash
pip install -r requirements.txt
```

### Step 4: Configure

```bash
cp config.toml.example config.toml
```

Edit `config.toml`:

```toml
[app]
host = "127.0.0.1"
port = 8078

[api]
host = "127.0.0.1"
port = 8079
jwt_secret = "CHANGE_ME_use_64_char_random_hex_string"
jwt_token_expiry_minutes = 60
rate_limit_per_minute = 100
```

**Generate a secure JWT secret:**
```python
python -c "import secrets; print(secrets.token_hex(32))"
```

### Step 5: Initialize Database

The database is automatically created on first run. To verify:

```bash
python -c "from database.engine import init_db; init_db(); print('DB OK')"
```

### Step 6: Load Data

Place transaction data files in the `data/` directory:

```
data/
├── transactions.csv
├── customers.xlsx
└── wire_transfers.csv
```

**Supported formats**: CSV, Excel (.xlsx), Parquet

### Step 7: Start Application

```bash
python app.py
```

Or using the Makefile:

```bash
make run          # Dashboard only
make run-api      # API only
make run-both     # Both services
```

### Step 8: Verify

| Check | Command | Expected |
|-------|---------|----------|
| Dashboard | Open http://127.0.0.1:8078 | Login page |
| Health | `curl http://127.0.0.1:8078/health` | `{"status":"healthy"}` |
| API Docs | Open http://127.0.0.1:8079/docs | Swagger UI |
| API Health | `curl -H "Authorization: Bearer TOKEN" http://127.0.0.1:8079/api/v1/system/health` | Health JSON |

---

## Configuration Reference

See `config.toml.example` for all configurable options.

| Section | Key | Default | Description |
|---------|-----|---------|-------------|
| `[app]` | port | 8078 | Dashboard port |
| `[api]` | port | 8079 | API port |
| `[api]` | jwt_secret | auto-generated | JWT signing key |
| `[api]` | jwt_token_expiry_minutes | 60 | Token lifetime |
| `[api]` | rate_limit_per_minute | 100 | API rate limit |
| `[waitress]` | threads | 8 | WSGI server threads |
| `[watchdog]` | check_interval_seconds | 30 | Health check interval |
| `[logging]` | level | INFO | Log verbosity |
| `[circuit_breaker]` | failure_threshold | 5 | Failures before open |

---

## Running as a Windows Service

For production deployments, run as a Windows service using NSSM:

```bash
# Download NSSM (Non-Sucking Service Manager)
# Transfer to air-gapped machine

nssm install AIM_AI_Vault "C:\ProgramData\anaconda3\envs\ai311\python.exe"
nssm set AIM_AI_Vault AppDirectory "C:\path\to\FCDAI_Annomaly_auto_detection_version15"
nssm set AIM_AI_Vault AppParameters "app.py"
nssm set AIM_AI_Vault DisplayName "AIM AI Vault - AML Detection"
nssm set AIM_AI_Vault Description "Anti-Money Laundering Detection Platform"
nssm set AIM_AI_Vault Start SERVICE_AUTO_START

# Start the service
nssm start AIM_AI_Vault
```

---

## Backup & Recovery

### Database Backup

```bash
# Stop application first, then copy:
copy vault.db vault.db.backup.YYYYMMDD

# Or use SQLite .backup command:
sqlite3 vault.db ".backup vault.db.backup"
```

### Configuration Backup

```bash
copy config.toml config.toml.backup.YYYYMMDD
```

### Data Backup

Follow your organization's data backup policies. Data files in `data/` contain PII and must be handled per bank data classification requirements.

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Port in use | Change port in config.toml or kill existing process |
| Import error | Verify conda environment activated: `conda activate ai311` |
| Database locked | Stop all processes, delete WAL files: `rm vault.db-wal vault.db-shm` |
| API 401 errors | Check JWT secret matches between sessions; tokens are short-lived |
| High memory | Reduce `page_size` in API queries; check watchdog metrics |
| Slow startup | Normal on first run (DB creation). Subsequent starts are faster |

---

## Upgrading

1. Back up current version (database + config)
2. Transfer new version to workstation
3. Stop running services
4. Copy `config.toml` and `vault.db` from old version
5. Install new dependencies: `pip install -r requirements.txt`
6. Start new version: `python app.py`
7. Verify: `make check`

---

*AIM AI Vault V15 Deployment Guide — Internal Documentation*
