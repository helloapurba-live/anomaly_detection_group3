# Version 10.0 — Production Core (SQLite, Auth, RBAC, Fernet)

**Directory**: `FCDAI_Annomaly_auto_detection_version10/`  
**Version**: 10.0.0  
**Port**: 8070  
**Date**: February 2026

---

## Overview

Version 10 was the **most significant infrastructure upgrade** — transforming the system from a single-user file-based application to a **multi-user enterprise platform** with persistent database storage, authentication, role-based access control, encryption, and background task execution.

## What Changed from V9

### Infrastructure Transformation

| Layer | V9 | V10 |
|-------|----|----|
| **Storage** | Parquet files | SQLite + WAL mode |
| **ORM** | None | SQLAlchemy 2.0 |
| **Auth** | None | Flask-Login + sessions |
| **Access Control** | None | RBAC (3 roles) |
| **Encryption** | None | Fernet (PII at rest) |
| **Task Queue** | None | Diskcache background |
| **Fast Ingest** | pandas | Polars (optional) |
| **Users** | Single | Multi-user |
| **Sessions** | None | 8-hour sessions |
| **Themes** | 6 | **12** (7 dark + 3 light + 2 premium) |

## Key Enhancements

### 1. SQLite + SQLAlchemy Backend

```python
@dataclass
class DatabaseConfig:
    DB_NAME: str = "sentinel_vault.db"
    WAL_MODE: bool = True                  # Write-Ahead Logging (concurrency)
    ECHO_SQL: bool = False                 # SQL query logging
    POOL_PRE_PING: bool = True             # Connection health check
    BUSY_TIMEOUT_MS: int = 5000            # 5-second lock wait
    CACHE_SIZE_KB: int = 64000             # 64 MB page cache
    JOURNAL_MODE: str = "WAL"              # Write-Ahead Log
    SYNC_MODE: str = "NORMAL"              # Balance safety/performance
    
    # Sync settings
    SYNC_ANOMALIES_TO_DB: bool = True      # Write scored data to DB
    SYNC_AUDIT_TO_DB: bool = True          # Write audit logs to DB
    AUTO_VACUUM: bool = True               # Reclaim space
```

**WAL Mode Benefits**:
- Readers don't block writers
- Writers don't block readers
- Better concurrency for multi-user
- Atomic commits

### 2. Database Schema (ORM Models)

New directory: `database/`

**`database/engine.py`** — SQLAlchemy engine initialization

```python
# database/engine.py

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

def init_db(config):
    """
    Initialize SQLite database with WAL mode.
    """
    db_path = config.PATH.BASE / config.DATABASE.DB_NAME
    engine = create_engine(
        f"sqlite:///{db_path}",
        echo=config.DATABASE.ECHO_SQL,
        pool_pre_ping=config.DATABASE.POOL_PRE_PING
    )
    
    # Enable WAL mode
    with engine.connect() as conn:
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute(f"PRAGMA busy_timeout={config.DATABASE.BUSY_TIMEOUT_MS};")
        conn.execute(f"PRAGMA cache_size=-{config.DATABASE.CACHE_SIZE_KB};")
    
    Session = sessionmaker(bind=engine)
    return engine, Session
```

**`database/models.py`** — ORM models

```python
# database/models.py

from sqlalchemy import Column, Integer, String, Float, DateTime, Text, Boolean
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False)  # admin, investigator, viewer
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime)
    is_active = Column(Boolean, default=True)

class AnomalyRecord(Base):
    __tablename__ = 'anomalies'
    
    id = Column(Integer, primary_key=True)
    customer_id_hash = Column(String(64), index=True)  # SHA-256 hashed
    risk_score = Column(Float, nullable=False)
    risk_tier = Column(String(10), nullable=False)
    method_scores = Column(Text)  # JSON: {"isolation_forest": 0.85, ...}
    vote_count = Column(Integer)
    detected_at = Column(DateTime, default=datetime.utcnow)
    run_id = Column(String(50))

class AuditEntry(Base):
    __tablename__ = 'audit_logs'
    
    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    user = Column(String(50), nullable=False)
    action = Column(String(100), nullable=False)
    details = Column(Text)  # JSON
    prev_hash = Column(String(64))
    current_hash = Column(String(64), index=True)

class AlertEvent(Base):
    __tablename__ = 'alert_events'
    
    id = Column(Integer, primary_key=True)
    alert_id = Column(String(50), unique=True)
    customer_id_hash = Column(String(64), index=True)
    alert_type = Column(String(50))
    severity = Column(String(10))
    created_at = Column(DateTime, default=datetime.utcnow)
    resolved_at = Column(DateTime, nullable=True)
    resolution_notes = Column(Text, nullable=True)
 
# ... 2 more tables (V16+): pii_access_logs, hash_verifications
```

**Total Tables (V10)**: 4 (users, anomalies, audit_logs, alert_events)

### 3. Flask-Login Multi-User Authentication

```python
@dataclass
class AuthConfig:
    ENABLED: bool = True
    SESSION_LIFETIME_MINUTES: int = 480    # 8 hours
    PASSWORD_HASH_METHOD: str = "pbkdf2:sha256"
    SALT_LENGTH: int = 16
    HASH_ITERATIONS: int = 600_000         # OWASP recommendation (2023)
    
    # Default admin account
    DEFAULT_ADMIN_USER: str = "admin"
    DEFAULT_ADMIN_PASS: str = "admin123"   # Must change on first login
    
    # Roles
    ROLES: List[str] = field(default_factory=lambda: ["admin", "investigator", "viewer"])
```

**Auth Integration**:

New directory: `auth/`

**`auth/manager.py`** — Flask-Login initialization

```python
# auth/manager.py

from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required
from passlib.hash import pbkdf2_sha256

login_manager = LoginManager()

class AuthUser(UserMixin):
    def __init__(self, user_id, username, role):
        self.id = user_id
        self.username = username
        self.role = role

@login_manager.user_loader
def load_user(user_id):
    # Query database for user
    session = Session()
    user = session.query(User).filter_by(id=int(user_id)).first()
    if user and user.is_active:
        return AuthUser(user.id, user.username, user.role)
    return None

def verify_password(username, password):
    session = Session()
    user = session.query(User).filter_by(username=username).first()
    if user and pbkdf2_sha256.verify(password, user.password_hash):
        return user
    return None

def create_user(username, password, role="viewer"):
    password_hash = pbkdf2_sha256.hash(password)
    user = User(username=username, password_hash=password_hash, role=role)
    session = Session()
    session.add(user)
    session.commit()
    return user
```

### 4. Role-Based Access Control (RBAC)

```python
# app.py — V10 RBAC implementation

ROLE_PERMISSIONS = {
    "admin": ["*"],  # All pages
    
    "investigator": [
        "/",                    # Dashboard
        "/sources",             # Data Sources
        "/pipeline",            # Pipeline Run
        "/layers",              # Layer View
        "/queue",               # Investigation Queue
        "/narratives",          # Narratives
        "/audit",               # Audit Trail
        "/vault",               # Audit Vault
        "/diagnostics",         # Model Diagnostics
        "/explainability"       # Explainability
    ],
    
    "viewer": [
        "/",                    # Dashboard
        "/layers",              # Layer View (read-only)
        "/audit",               # Audit Trail (read-only)
        "/diagnostics",         # Model Diagnostics
        "/explainability"       # Explainability
    ]
}

def has_permission(user_role, page_path):
    """
    Check if user role has access to page.
    """
    if user_role == "admin":
        return True
    
    allowed_pages = ROLE_PERMISSIONS.get(user_role, [])
    return page_path in allowed_pages

# RBAC callback for page access
@app.callback(
    Output("page-content", "children"),
    Input("url", "pathname"),
    State("user-store", "data")
)
def render_page_with_rbac(pathname, user_data):
    if not user_data:
        return dcc.Location(pathname="/login", id="redirect-login")
    
    user_role = user_data.get("role")
    
    if not has_permission(user_role, pathname):
        return dmc.Alert(
            "Access Denied: You do not have permission to view this page.",
            color="red",
            title="403 Forbidden"
        )
    
    # Render page
    return render_page(pathname)
```

### 5. Fernet Encryption for PII at Rest

```python
@dataclass
class CryptoConfig:
    ENCRYPT_PII_AT_REST: bool = True       # Fernet-encrypt PII columns
    HASH_ENTITY_IDS: bool = True           # SHA-256 hash entity_id
    KEY_FILE: str = ".vault_key"           # Fernet key file (256-bit)
    HASH_SALT: str = "aim-ai-vault-v10"    # Salt for hashing
    AUTO_ROTATE_DAYS: int = 90             # Key rotation reminder
    ALGORITHM: str = "Fernet"              # Fernet (symmetric AES-128-CBC)
```

New utility: `utils/crypto.py`

```python
# utils/crypto.py

from cryptography.fernet import Fernet
import hashlib
import base64

class CryptoManager:
    def __init__(self, config):
        self.config = config
        self.key = self._load_or_create_key()
        self.fernet = Fernet(self.key)
    
    def _load_or_create_key(self):
        """
        Load encryption key from file or generate new one.
        """
        key_path = Path(self.config.CRYPTO.KEY_FILE)
        if key_path.exists():
            with open(key_path, 'rb') as f:
                return f.read()
        else:
            key = Fernet.generate_key()
            with open(key_path, 'wb') as f:
                f.write(key)
            return key
    
    def encrypt(self, plaintext: str) -> str:
        """
        Encrypt plaintext with Fernet (AES-128-CBC).
        Returns base64-encoded ciphertext.
        """
        return self.fernet.encrypt(plaintext.encode()).decode()
    
    def decrypt(self, ciphertext: str) -> str:
        """
        Decrypt Fernet ciphertext.
        """
        return self.fernet.decrypt(ciphertext.encode()).decode()
    
    def hash_entity_id(self, entity_id: str) -> str:
        """
        SHA-256 hash of entity ID with salt.
        One-way (cannot reverse).
        """
        salted = f"{self.config.CRYPTO.HASH_SALT}|{entity_id}"
        return hashlib.sha256(salted.encode()).hexdigest()
```

**Usage**:
```python
# Hash customer IDs (one-way, for DB storage)
customer_id_hash = crypto.hash_entity_id("CUST-12345")  # → abc123def...

# Encrypt PII (two-way, for vault storage)
encrypted_ssn = crypto.encrypt("123-45-6789")  # → gAAAAAB...
decrypted_ssn = crypto.decrypt(encrypted_ssn)   # → "123-45-6789"
```

### 6. Diskcache Background Task Queue

```python
@dataclass
class TaskConfig:
    CACHE_DIR: str = "cache/task_queue"
    EXPIRE_SECONDS: int = 3600             # 1 hour TTL
    MAX_RETRIES: int = 2
    POLL_INTERVAL_MS: int = 2000           # UI polling interval (2 seconds)
    ENABLE_BACKGROUND: bool = True         # Execute pipelines in background
```

**Background Pipeline Execution**:

```python
# app.py — Background task queue

from diskcache import Cache

task_queue = Cache(config.TASK.CACHE_DIR)

@app.callback(
    Output("pipeline-status", "data"),
    Input("run-pipeline-button", "n_clicks"),
    prevent_initial_call=True
)
def run_pipeline_background(n_clicks):
    """
    Execute pipeline in background thread.
    UI remains responsive — poll for status.
    """
    import threading
    
    task_id = f"PIPELINE-{int(time.time())}"
    
    # Set initial status
    task_queue[task_id] = {"status": "RUNNING", "progress": 0}
    
    # Launch background thread
    def execute():
        try:
            results = pipeline.run()
            task_queue[task_id] = {"status": "SUCCESS", "results": results}
        except Exception as e:
            task_queue[task_id] = {"status": "FAILED", "error": str(e)}
    
    thread = threading.Thread(target=execute)
    thread.start()
    
    return {"task_id": task_id}

# Polling callback (UI checks status every 2 seconds)
@app.callback(
    Output("progress-bar", "value"),
    Input("interval-component", "n_intervals"),
    State("pipeline-status", "data")
)
def poll_status(n_intervals, status_data):
    task_id = status_data.get("task_id")
    status = task_queue.get(task_id, {})
    return status.get("progress", 0)
```

### 7. Polars Fast Data Ingestion

```python
# utils/data_io.py — V10

try:
    import polars as pl
    POLARS_AVAILABLE = True
except ImportError:
    POLARS_AVAILABLE = False

def load_csv_fast(filepath):
    """
    Load CSV with Polars (10x faster than pandas).
    Falls back to pandas if Polars not installed.
    """
    if POLARS_AVAILABLE:
        df_pl = pl.read_csv(filepath)
        df = df_pl.to_pandas()  # Convert to pandas for compatibility
        logger.info(f"Loaded {filepath} with Polars (fast mode)")
    else:
        df = pd.read_csv(filepath)
        logger.info(f"Loaded {filepath} with pandas (fallback)")
    
    return df
```

**Performance**: Polars is 5-10x faster for large CSVs (>1 GB)

### 8. Enhanced Theme System (12 Themes)

Extended from 6 to **12 premium themes**:

#### Dark Themes (7)
1. **Sentinel Dark** (system default) — Cyan/dark
2. **Midnight Blue** — Deep indigo
3. **Emerald Dark** — Forest green
4. **Rose Gold** — Pink tones
5. **Sunset Amber** — Warm orange
6. **Ocean Deep** — Teal/cyan
7. **Lavender** — Purple haze

#### Light Themes (3)
8. **Arctic Light** — Cool blue
9. **Cream Light** — Warm neutral
10. **Silver Light** — Professional gray

#### Premium Themes (2)
11. **Neon** — Electric accents (dark)
12. **Matrix** — Green terminal (dark)

**Theme Structure** (expanded):
```python
THEMES = {
    "sentinel": {
        "label": "Sentinel Dark",
        "primaryColor": "cyan",
        "colorScheme": "dark",
        "bgColor": "#0F1729",
        "cardBg": "#1A2332",
        "paperBg": "#151E2D",
        "borderColor": "#2E3A4A",
        "textPrimary": "#E5E7EB",
        "textSecondary": "#9CA3AF",
        "accentGradient": "linear-gradient(135deg, #00D4FF 0%, #0099CC 100%)",
        "plotlyTemplate": "plotly_dark",
        "agGridClass": "ag-theme-alpine-dark",
        "sidebarText": "#E5E7EB"
    },
    # ... 11 more themes
}
```

### 9. New UI Pages (2 Pages)

| Page | Route | Purpose | Role Access |
|------|-------|---------|-------------|
| **Login** | `/login` | Authentication gate | Public |
| **Task Manager** | `/tasks` | Background pipeline monitoring | Admin, Investigator |

**Total Pages**: 14 (up from 12 in V9)

### 10. Zero-Leakage Network Protection

```python
# app.py — V10

import os

# Disable all external renderers
os.environ["PLOTLY_RENDERER"] = "notebook_connected"

import plotly.io as pio
pio.renderers.default = "browser"
plotly.io.orca.config.use_xvfb = False  # No X11 display calls

# Assets ignore pattern (reject CDN requests)
app = Dash(
    __name__,
    use_pages=True,
    serve_locally=True,
    assets_ignore=r'.*external.*|.*cdn.*|.*googleapis.*|.*gstatic.*'
)
```

## New Dependencies (V10)

| Package | Version | License | Purpose |
|---------|---------|---------|---------|
| `SQLAlchemy` | ≥2.0.0 | MIT | ORM + SQLite backend |
| `Flask-Login` | ≥0.6.0 | MIT | Session auth + RBAC |
| `passlib` | ≥1.7.4 | BSD | Password hashing (pbkdf2) |
| `cryptography` | ≥41.0.0 | Apache/BSD | Fernet PII encryption |
| `polars` | ≥0.20.0 | MIT | Fast CSV ingest |

**All Licenses**: Commercial-friendly (MIT, BSD, Apache)

## App.py Growth

```
V3/V4: 216 lines 
→ V5/V6/V7: ~440 lines 
→ V8/V9: 445 lines
→ V10: 793 lines (+78% from V9)
```

**New in V10**:
- Flask-Login initialization (50 lines)
- RBAC permission checking (80 lines)
- Login page callback (40 lines)
- Background task queue (60 lines)
- 6 new themes (90 lines)

## Complete Directory Structure (V10)

```
FCDAI_Annomaly_auto_detection_version10/
├── app.py                              # 793 lines (Flask-Login, RBAC, 12 themes)
├── config.py                           # 431 lines (13 config classes)
├── pipeline.py                         # 318 lines
├── pipeline_runner.py
├── verify_scalability.py              
├── diagnostic_trace.py
├── _patch_ds.py
├── README.md
├── requirements.txt                    # 23 packages
│
├── auth/                               # NEW directory
│   ├── manager.py                      # Flask-Login + RBAC (280 lines)
│   └── __init__.py
│
├── database/                           # NEW directory
│   ├── engine.py                       # SQLAlchemy engine (120 lines)
│   ├── models.py                       # ORM models (350 lines)
│   └── __init__.py
│
├── layers/                             # 7 files
├── pages/                              # 14 pages (+2 new)
│   ├── login.py                        # NEW (180 lines)
│   ├── task_manager.py                 # NEW (200 lines)
│   ├── ... (12 existing pages)
│
├── utils/                              # 15 files (+1 new)
│   ├── crypto.py                       # NEW (250 lines)
│   ├── ... (14 existing utils)
│
├── tests/
│   └── test_vat_suite.py
│
├── assets/
├── cache/
│   └── task_queue/                     # NEW: Background tasks
├── data/
│   └── vault/
│       └── .vault_key                  # NEW: Fernet key (256-bit)
├── logs/
│   └── .hash_state
└── models/
```

**Total Files**: ~55 (+5 from V9)

## Configuration Classes (13 Total)

| Config Class | Introduced | Purpose |
|--------------|-----------|---------|
| AppConfig | V2 | App-level settings |
| PathConfig | V1 | Directory paths |
| ThemeConfig | V1 | UI theming |
| LayerConfig | V1 | Pipeline layer config |
| DataSourceConfig | V2 | Data source definitions |
| PIIConfig | V3 | PII masking rules |
| ColumnRoleConfig | V8 | Column role resolution |
| ResourceConfig | V8 | Memory safety limits |
| AuditConfig | V8 | Audit trail settings |
| **DatabaseConfig** | **V10** | SQLite + ORM config |
| **AuthConfig** | **V10** | Auth + sessions |
| **TaskConfig** | **V10** | Background tasks |
| **CryptoConfig** | **V10** | Encryption + hashing |

## What Worked Well

1. **SQLite + WAL**: Excellent concurrency, zero-config, embeddable
2. **Flask-Login**: Mature auth library, well-documented
3. **SQLAlchemy 2.0**: Type-safe ORM, async-ready
4. **Fernet encryption**: Simple symmetric encryption for PII
5. **RBAC**: Clean role-permission mapping
6. **Background tasks**: UI stays responsive during long pipelines
7. **Polars ingest**: 10x speedup on large CSV files

## Migration from V9 → V10

### Data Migration

```python
# Migrate V9 Parquet vault to V10 SQLite

import pandas as pd
from database.engine import init_db
from database.models import AnomalyRecord

# Load V9 data
df = pd.read_parquet("data/vault/scored.parquet")

# Initialize V10 database
engine, Session = init_db(config)

# Migrate records
session = Session()
for _, row in df.iterrows():
    record = AnomalyRecord(
        customer_id_hash=crypto.hash_entity_id(row['customer_id']),
        risk_score=row['risk_score'],
        risk_tier=row['risk_tier'],
        method_scores=row.to_json(),
        vote_count=row['vote_count']
    )
    session.add(record)

session.commit()
```

### User Creation

```bash
# Create default admin user
python -c "from auth.manager import create_user; create_user('admin', 'admin123', 'admin')"
```

## Remaining Challenges (Addressed in V11+)

1. **Limited features**: V10 is core infrastructure — V11 adds reports, alerts, drift detection
2. **No bank audit compliance**: V12 adds CRITICAL/HIGH bank audit fixes
3. **No health monitoring**: V13 adds 26 health audit fixes
4. **No enterprise hardening**: V14 adds Waitress WSGI, circuit breaker, watchdog
5. **No REST API**: V15 adds FastAPI with 14 endpoints

---

**Previous Version**: [VERSION 9 — VAT & FMEA](VERSION_9_VAT_FMEA.md)  
**Next Version**: [VERSION 11 — Feature Expansion](../VERSION_HISTORY_COMPLETE.md#3-version-11--feature-expansion-110) (see V10-V17 doc)  
**Return to**: [Version History V1-V10](../VERSION_HISTORY_V1_TO_V10.md)
