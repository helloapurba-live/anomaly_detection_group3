# Version 1.0 — Streamlit Prototype

**Directory**: `fcdai_7layer_streamlit/`  
**Framework**: Streamlit  
**Version**: 1.0.0 (implicit)  
**Port**: 8501 (default)  
**Status**: Proof-of-concept / archived  
**Date**: Early 2025

---

## Overview

Version 1 was the **initial proof-of-concept** built with Streamlit — a script-based Python web framework that re-runs top-to-bottom on every user interaction. This version established the foundational 7-layer pipeline architecture that would remain the core of all future versions.

## Key Characteristics

### Technical Foundation
- **Framework**: Streamlit (script-based execution model)
- **Architecture**: 7-layer pipeline conceived and implemented
- **UI**: Basic Streamlit pages with `.streamlit/` config directory
- **Data Flow**: Sequential — load → process → detect → display
- **Port**: Default Streamlit port (8501)
- **Theme**: Basic dark theme via Streamlit config

### Detection System
- **26 anomaly detection methods** across 8 categories
- **7-layer pipeline**: Ingest → DQ → Feature Engineering → Preprocessing → Detection → Ensemble → Output

## File Structure

```
fcdai_7layer_streamlit/
├── .streamlit/         # Streamlit config (theme, server settings)
├── app.py              # Main Streamlit entry point
├── config.py           # Centralized configuration (dataclasses)
├── pipeline.py         # Pipeline orchestrator
├── layers/             # L1-L7 detection modules
│   ├── l1_l2_ingestion.py
│   ├── l3_feature_engineering.py
│   ├── l4_preprocessing.py
│   ├── l5_detection.py
│   ├── l6_ensemble.py
│   └── l7_output.py
├── pages/              # Streamlit multi-page UI (~8 pages)
├── utils/              # Data I/O, logging (~4 files)
├── data/               # Data storage
├── logs/               # Log files
├── output/             # Pipeline outputs
├── models/             # Saved ML models
├── README.md
└── requirements.txt
```

**Total Files**: ~25

## Configuration Architecture

```python
# config.py — V1 Streamlit Edition
@dataclass
class PathConfig:
    BASE: Path
    DATA: Path
    DATA_SOURCES: Path
    MODELS: Path
    LOGS: Path
    OUTPUT: Path

@dataclass
class ThemeConfig:
    PRIMARY: str = "#00D4FF"   # Cyan accent
    DARK_BG: str = "#0F0F23"   # Deep dark background

@dataclass
class LayerConfig:
    DQ_COMPLETENESS_THRESHOLD: float = 0.95
    DQ_VALIDITY_THRESHOLD: float = 0.90
    FEATURE_CATEGORIES: List[str] = ["velocity", "aggregate", "ratio", "flag", "temporal", "behavioral"]
```

**Total Config Classes**: 3

## Detection Methods (26 Methods)

### By Category

| Category | Methods | Count |
|----------|---------|-------|
| **Statistical** | Z-Score, IQR, Grubbs, Dixon, ESD | 5 |
| **Distance** | KNN, Mahalanobis, LOF | 3 |
| **Density** | DBSCAN, OPTICS, HDBSCAN, CBLOF | 4 |
| **Clustering** | K-Means Anomaly, GMM, Spectral | 3 |
| **Trees** | Isolation Forest, Extended IF | 2 |
| **Time-Series** | STL, ARIMA Residual, Prophet | 3 |
| **Graph** | PageRank, HITS, Community, Centrality | 4 |
| **Deep Learning** | Autoencoder, VAE | 2 |

## Core Dependencies

```
streamlit>=1.20.0
plotly>=5.0.0
pandas>=1.5.0
numpy>=1.23.0
scikit-learn>=1.2.0
scipy>=1.10.0
```

## Limitations & Pain Points

These limitations drove the complete rewrite to Dash in Version 2:

1. **Script re-execution**: Streamlit re-runs entire script on every interaction → slow for complex pipelines
2. **No callback model**: Cannot have fine-grained interactivity (click button → update one component only)
3. **Limited component library**: No AG Grid, no Mantine components, limited charting control
4. **State management**: Streamlit session state is fragile and resets on page navigation
5. **No multi-page routing**: Early Streamlit had poor multi-page support (later improved in Streamlit 1.10+)
6. **Air-gap difficulty**: Streamlit CDN dependencies harder to fully air-gap

## What Worked Well

- **Rapid prototyping**: Streamlit enabled quick validation of the 7-layer concept
- **Python-first**: Pure Python with minimal JavaScript knowledge required
- **Built-in components**: Sidebar, file uploader, charts available out-of-box

## Architecture Decisions

### Why 7 Layers?

The 7-layer architecture was designed to separate concerns:

1. **L1-L2 (Ingest + DQ)**: Data loading and quality validation
2. **L3 (Feature Engineering)**: Generate 50+ derived features
3. **L4 (Preprocessing)**: Create 4 matrix versions (raw, scaled, PCA, encoded)
4. **L5 (Detection)**: Run 26 methods in parallel
5. **L6 (Ensemble)**: Fuse scores → single risk score
6. **L7 (Output)**: Investigation queue + audit trail

### Why 26 Methods?

- **Statistical diversity**: Cover z-score, IQR, Benford's law, Mahalanobis distance
- **Machine learning**: Tree-based (Isolation Forest), density-based (LOF), clustering (HDBSCAN)
- **Deep learning**: Reconstruction error from autoencoders
- **Graph analytics**: Community detection for network patterns
- **Time-series**: STL decomposition for temporal anomalies

## Migration Path

**V1 → V2**: Complete rewrite to Dash framework while preserving the 7-layer pipeline logic.

## Lessons Learned

1. **Architecture first**: The 7-layer design proved sound and persisted through all versions
2. **Framework choice matters**: Streamlit's script model was too limiting for production
3. **Detection diversity**: 26 methods provided comprehensive coverage but needed performance tuning
4. **Configuration classes**: Dataclass-based config worked well and was retained in all versions

---

**Next Version**: [VERSION 2 — Dash Migration](VERSION_2_DASH_MIGRATION.md)

**Return to**: [Version History V1-V10](../VERSION_HISTORY_V1_TO_V10.md)
