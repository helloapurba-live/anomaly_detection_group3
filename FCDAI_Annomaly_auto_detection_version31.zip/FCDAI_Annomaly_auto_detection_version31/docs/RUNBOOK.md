# Operations Runbook

> **AIM AI Vault V15 — Operations & Troubleshooting Guide**

---

## Daily Operations

### Morning Checklist

| Step | Command / Action | Expected |
|------|-----------------|----------|
| 1. Verify services running | Check Task Manager for python.exe | 2 processes (Dash + API) |
| 2. Health check | `curl http://127.0.0.1:8078/health` | `{"status":"healthy"}` |
| 3. API health | `curl -H "Auth..." http://127.0.0.1:8079/api/v1/system/health` | Healthy response |
| 4. Check disk space | `wmic logicaldisk get size,freespace` | >10 GB free |
| 5. Review audit log | Dashboard → System Health page | No anomalies |

### Running the Detection Pipeline

**Via Dashboard:**
1. Log in as Admin or Investigator
2. Navigate to Dashboard page
3. Click "Run Pipeline" button
4. Monitor progress in real-time

**Via API:**
```bash
curl -X POST http://127.0.0.1:8079/api/v1/pipeline/run \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"description": "Daily run 2025-01-15"}'
```

---

## Service Management

### Starting Services

```bash
# Activate environment
conda activate ai311

# Change to project directory
cd C:\path\to\FCDAI_Annomaly_auto_detection_version15

# Start both services
python app.py

# OR start individually:
# Dashboard only
python app.py  # without API if api/ import fails

# API only
python -m api.server --port 8079
```

### Stopping Services

Press `Ctrl+C` in the terminal, or:

```bash
# Find process IDs
netstat -ano | findstr :8078
netstat -ano | findstr :8079

# Kill by PID
taskkill /PID <pid> /F
```

### Restarting Services

```bash
# Stop then start
taskkill /IM python.exe /F
conda activate ai311
cd C:\path\to\project
python app.py
```

---

## Monitoring

### System Metrics

**Via API:**
```bash
curl -H "Authorization: Bearer <token>" \
  http://127.0.0.1:8079/api/v1/system/metrics
```

**Response fields to monitor:**

| Metric | Warning Threshold | Critical Threshold |
|--------|------------------|-------------------|
| cpu_percent | >80% | >95% |
| memory_percent | >80% | >90% |
| disk_percent | >80% | >95% |
| thread_count | >50 | >100 |

### Circuit Breakers

```bash
curl -H "Authorization: Bearer <token>" \
  http://127.0.0.1:8079/api/v1/system/circuit-breakers
```

| State | Meaning | Action |
|-------|---------|--------|
| CLOSED | Normal operation | None |
| OPEN | Failures exceeded threshold | Investigate root cause |
| HALF_OPEN | Testing recovery | Monitor closely |

### Audit Trail Integrity

```bash
curl -H "Authorization: Bearer <token>" \
  http://127.0.0.1:8079/api/v1/audit/verify
```

If `valid: false` — **CRITICAL**: Possible tampering. Escalate to security team immediately.

---

## Troubleshooting

### Common Issues

#### Port Already in Use

```
Error: [Errno address already in use]
```

**Fix:**
```bash
netstat -ano | findstr :8078
taskkill /PID <pid> /F
```

#### Database Locked

```
Error: database is locked
```

**Fix:**
1. Stop all processes accessing the database
2. Delete WAL files: `del vault.db-wal vault.db-shm`
3. Restart application

#### Import Errors

```
ModuleNotFoundError: No module named 'fastapi'
```

**Fix:**
```bash
conda activate ai311
pip install -r requirements.txt
```

#### JWT Token Expired

```
{"detail": "Invalid or missing authentication"}
```

**Fix:** Request a new token via `POST /api/v1/auth/token`

#### Rate Limit Exceeded

```
HTTP 429: Rate limit exceeded
```

**Fix:** Wait 60 seconds, or increase `rate_limit_per_minute` in config.toml

#### High Memory Usage

**Fix:**
1. Check `system/metrics` for current usage
2. Reduce `page_size` in API queries
3. Clear diskcache: `make clean`
4. Restart application

#### Diskcache Corruption

```
Error: Diskcache creation failed
```

**Fix:**
```bash
rmdir /s /q cache
mkdir cache
python app.py
```

---

## Backup Procedures

### Daily Backup Schedule

| What | When | How |
|------|------|-----|
| Database | Daily 2:00 AM | Copy vault.db |
| Config | After changes | Copy config.toml |
| Logs | Weekly | Archive logs/ directory |

### Backup Script

Create `backup.bat`:

```batch
@echo off
set BACKUP_DIR=C:\backups\aim_vault\%date:~-4,4%%date:~-7,2%%date:~-10,2%
mkdir %BACKUP_DIR%
copy vault.db %BACKUP_DIR%\vault.db
copy config.toml %BACKUP_DIR%\config.toml
xcopy /s /i logs %BACKUP_DIR%\logs
echo Backup completed to %BACKUP_DIR%
```

### Restore Procedure

1. Stop application
2. Copy backed-up `vault.db` to project directory
3. Copy backed-up `config.toml` to project directory
4. Start application
5. Verify: `make check`

---

## User Management

### Creating Users

Via the dashboard admin panel, or:

```python
python -c "
from database.engine import init_db, safe_session
from auth.manager import create_user
init_db()
create_user('new_analyst', 'secure_password_here', 'investigator')
print('User created')
"
```

### Resetting Passwords

Contact system administrator. Passwords are scrypt-hashed and cannot be recovered.

### API Key Management

```bash
# Create API key (admin only)
curl -X POST http://127.0.0.1:8079/api/v1/auth/keys \
  -H "Authorization: Bearer <admin_token>" \
  -H "Content-Type: application/json" \
  -d '{"label": "analyst_script", "role": "investigator", "expires_days": 90}'

# List API keys
curl -H "Authorization: Bearer <admin_token>" \
  http://127.0.0.1:8079/api/v1/auth/keys

# Revoke via dashboard or direct DB update
```

---

## Emergency Procedures

### PII Data Exposure Suspected

1. **IMMEDIATELY** stop all services: `taskkill /IM python.exe /F`
2. Preserve logs: `copy logs\* C:\incident\`
3. Preserve audit trail: `copy vault.db C:\incident\`
4. Contact security team and BSA officer
5. Document the incident with timestamps

### Database Corruption

1. Stop services
2. Attempt recovery: `sqlite3 vault.db ".recover" | sqlite3 vault_recovered.db`
3. If recovery fails, restore from last backup
4. Verify audit chain: `/api/v1/audit/verify`

### Unauthorized Access Detected

1. Review audit log for suspicious entries
2. Revoke compromised tokens/API keys
3. Reset affected user passwords
4. Document and escalate per incident response policy

---

## Contact

| Role | Responsibility |
|------|---------------|
| AML Technology Lead | System administration, upgrades |
| BSA Officer | Compliance decisions, SAR filing |
| Security Team | Incident response, access control |
| Data Team | Data loading, quality issues |

---

*AIM AI Vault V15 Operations Runbook — Internal Documentation*
