# FCDAI Version Comparison Tables

**Comprehensive feature and metric comparisons across V1-V17**

**Document Date**: February 15, 2026  
**Scope**: All versions from V1 (Streamlit prototype) through V17 (Full wiring)

---

## Table of Contents

1. [Version Timeline Summary](#1-version-timeline-summary)
2. [Framework & Architecture](#2-framework--architecture)
3. [Feature Matrix](#3-feature-matrix)
4. [Performance Metrics](#4-performance-metrics)
5. [Security & Compliance](#5-security--compliance)
6. [Configuration Evolution](#6-configuration-evolution)
7. [Dependencies & Licenses](#7-dependencies--licenses)
8. [File & Code Metrics](#8-file--code-metrics)
9. [Database Schema Evolution](#9-database-schema-evolution)
10. [UI Pages & Functionality](#10-ui-pages--functionality)

---

## 1. Version Timeline Summary

| Version | Name | Release Date | Key Focus | Paradigm Shift? |
|---------|------|--------------|-----------|-----------------|
| **V1** | Streamlit Prototype | Early 2025 | Proof-of-concept, 7-layer pipeline | ✓ Architecture established |
| **V2** | Dash Migration | Jan 2025 | Framework rewrite, callbacks | ✓ Script → Reactive |
| **V3** | PII Vault | Jan 2025 | Security foundation, data vault | — |
| **V4** | Scalability | Jan 2025 | 100K stress test, CLI runner | — |
| **V5** | Production Hardening | Jan-Feb 2025 | 6 themes, clientside callbacks | — |
| **V6** | Customer-Level | Feb 2026 | Transaction → Customer processing | ✓ Detection paradigm |
| **V7** | Flexible Architecture | Feb 12, 2026 | ANY schema, auto-detection | ✓ Zero assumptions |
| **V8** | RBAC & Audit | Feb 2026 | Column roles, audit lineage | — |
| **V9** | VAT & FMEA | Feb 2026 | Quality assurance, 20 failure modes | — |
| **V10** | Production Core | Feb 2026 | SQLite, auth, RBAC, Fernet | ✓ Infrastructure |
| **V11** | Feature Expansion | Feb 2026 | 15 features (reports, alerts, drift) | — |
| **V12** | Bank Audit | Feb 2026 | 16 compliance fixes, RBAC on 21 pages | — |
| **V13** | Health Audit | Feb 2026 | 26 audit fixes, 12 themes | — |
| **V14** | Enterprise Hardening | Feb 2026 | Waitress, circuit breaker, watchdog | — |
| **V15** | REST API | Feb 2026 | FastAPI 14 endpoints, JWT, full docs | — |
| **V16** | Bank Audit A4/A5/A6 | Feb 2026 | PII safety lock, epsilon, hash verify | — |
| **V17** | Full Wiring | Feb 2026 | All 9 enhancements E1-E9 wired | — |

---

## 2. Framework & Architecture

| Aspect | V1 | V2-V9 | V10-V17 |
|--------|----|----|---------|
| **Web Framework** | Streamlit | Dash | Dash + FastAPI (V15+) |
| **UI Components** | Streamlit widgets | Dash Mantine Components (DMC) | DMC + AG Grid |
| **Execution Model** | Script re-run | Callback-driven | Callback + RESTful |
| **State Management** | `st.session_state` | `dcc.Store` | `dcc.Store` + JWT sessions |
| **Data Grid** | `st.dataframe()` | AG Grid | AG Grid (enterprise) |
| **Routing** | `pages/` folder | `dash.page_registry` | `dash.page_registry` + API routes |
| **Database** | None | None (V1-V9), SQLite (V10+) | SQLite + WAL mode |
| **ORM** | None | None | SQLAlchemy 2.0 |
| **Authentication** | None | None | Flask-Login (V10+) |
| **Access Control** | None | None | RBAC (V10+) |
| **Encryption** | None | None | Fernet (V10+) |
| **WSGI Server** | Built-in | Built-in | Waitress (V14+) |
| **API Server** | None | None | FastAPI + Uvicorn (V15+) |

---

## 3. Feature Matrix

### Core Features

| Feature | V1 | V2 | V3 | V4 | V5 | V6 | V7 | V8 | V9 | V10 | V11 | V12 | V13 | V14 | V15 | V16 | V17 |
|---------|----|----|----|----|----|----|----|----|----|----|-----|-----|-----|-----|-----|-----|-----|
| 7-Layer Pipeline | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 26 Detection Methods | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| PII Masking | — | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Data Vault | — | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Multi-Theme | — | — | — | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Customer-Level | — | — | — | — | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Flexible Schema | — | — | — | — | — | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Column Roles | — | — | — | — | — | — | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| SQLite Backend | — | — | — | — | — | — | — | — | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Multi-User Auth | — | — | — | — | — | — | — | — | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| RBAC | — | — | — | — | — | — | — | — | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Fernet Encryption | — | — | — | — | — | — | — | — | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |

### Advanced Features (V11+)

| Feature | V11 | V12 | V13 | V14 | V15 | V16 | V17 |
|---------|-----|-----|-----|-----|-----|-----|-----|
| Reports | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Alerts | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | 
| Drift Detection | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Graph Analysis | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Scheduler | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| What-If | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Waitress WSGI | — | — | — | ✓ | ✓ | ✓ | ✓ |
| Circuit Breaker | — | — | — | ✓ | ✓ | ✓ | ✓ |
| Watchdog | — | — | — | ✓ | ✓ | ✓ | ✓ |
| FastAPI | — | — | — | — | ✓ | ✓ | ✓ |
| JWT Auth | — | — | — | — | ✓ | ✓ | ✓ |
| API Key Auth | — | — | — | — | ✓ | ✓ | ✓ |
| PII Auto-Mask | — | — | — | — | ✓ | ✓ | ✓ |
| Safety Lock (A4) | — | — | — | — | — | ✓ | ✓ |
| Epsilon Tolerance (A5) | — | — | — | — | — | ✓ | ✓ |
| Hash Chain Verify (A6) | — | — | — | — | — | ✓ | ✓ |

---

## 4. Performance Metrics

### Execution Performance (100K Customer Test)

| Metric | V4 | V5 | V6 | V7-V17 |
|--------|----|----|----|----|
| **Records Processed** | 100,000 txn | 100,000 txn | 10,000 cust | 10,000 cust |
| **Execution Time** | 12 min | ~12 min | ~10 min | ~10 min |
| **Memory Peak** | 2.5 GB | 2.6 GB | 1.8 GB | 1.8 GB |
| **Memory Average** | 1.8 GB | 1.9 GB | 1.3 GB | 1.3 GB |
| **CPU Usage (Avg)** | 85% | 85% | 82% | 82% |
| **Throughput** | 139/sec (txn) | ~140/sec | ~17/sec (cust) | ~17/sec |

**Key Insight**: V6 customer-level shift reduced records by 90% while improving execution time by 17%.

### File Size Growth (app.py)

| Version | app.py Lines | % Growth |
|---------|--------------|----------|
| V1 | ~150 | Baseline |
| V2 | ~200 | +33% |
| V3-V4 | 216 | +44% |
| V5-V7 | ~440 | +193% |
| V8-V9 | 445 | +197% |
| V10 | 793 | +429% |
| V11-V17 | ~800 | +433% |

### Database Performance (V10+)

| Metric | SQLite (WAL) | Parquet (V9) |
|--------|--------------|--------------|
| **Write Speed** | 5,000 rows/sec | 20,000 rows/sec |
| **Read Speed** | 50,000 rows/sec | 100,000 rows/sec |
| **Concurrent Readers** | Unlimited | 1 (file lock) |
| **Concurrent Writers** | 1 | 1 |
| **Query Capability** | SQL (flexible) | None (full scan) |
| **Indexing** | Yes (B-tree) | No |
| **ACID Compliance** | Yes | No |

---

## 5. Security & Compliance

### Security Features

| Feature | V1-V2 | V3-V9 | V10-V17 |
|---------|-------|-------|---------|
| **PII Masking** | None | Show-edges | Full + in-memory |
| **Encryption at Rest** | None | None | Fernet (V10+) |
| **Entity ID Hashing** | None | None | SHA-256 (V10+) |
| **Hash Chain Audit** | None | Basic | Persistent (V9+) |
| **Authentication** | None | None | Flask-Login (V10+) |
| **Password Hashing** | None | None | PBKDF2-SHA256 (V10+) |
| **Session Management** | None | None | 8-hour sessions (V10+) |
| **RBAC** | None | None | 3 roles (V10+) |
| **API Authentication** | None | None | JWT + API Key (V15+) |
| **Network Isolation** | Partial | Full | Full + verified |
| **Formula Injection Protection** | None | None | Sanitization (V9+) |
| **Upload Size Limit** | None | None | 100 MB (V9+) |

### Bank Audit Compliance

| Finding | Severity | Fixed In | Fix Description |
|---------|----------|----------|-----------------|
| FM-006: PII exposure | CRITICAL (RPN 240) | V9 | PII masking enabled by default |
| FM-007: Hash chain reset | HIGH (RPN 128) | V9 | Hash state persistence |
| FM-003: Float boundaries | HIGH (RPN 140) | V9 | Epsilon tolerance |
| V12-CRITICAL-001 | CRITICAL | V12 | Access control on auth module |
| V12-CRITICAL-002 | CRITICAL | V12 | Session fixation protection |
| V12-HIGH-003 | HIGH | V12 | Password complexity enforcement |
| V12-HIGH-004 | HIGH | V12 | SQL injection prevention |

---

## 6. Configuration Evolution

### Config Classes Growth

| Version | Config Classes | New Classes Added |
|---------|----------------|-------------------|
| V1 | 3 | PathConfig, ThemeConfig, LayerConfig |
| V2 | 5 | +AppConfig, +DataSourceConfig |
| V3 | 6 | +PIIConfig |
| V4-V7 | 6 | None |
| V8 | 9 | +ColumnRoleConfig, +ResourceConfig, +AuditConfig |
| V9 | 9 | None (3 fields added to AuditConfig) |
| V10 | 13 | +DatabaseConfig, +AuthConfig, +TaskConfig, +CryptoConfig |
| V11-V17 | 13 | None |

### Port Assignment History

| Version | Port | Reason |
|---------|------|--------|
| V1 | 8501 | Streamlit default |
| V2 | 8071 | First Dash port |
| V3 | 8085 | Avoid V2 conflict |
| V4 | 8090 | Avoid V3 conflict |
| V5 | 8097 | — |
| V6 | 8109 | — |
| V7 | 8055 | — |
| V8-V17 | 8070 | Stabilized (Dashboard) |
| V15-V17 | 8079 | API port (FastAPI) |

---

## 7. Dependencies & Licenses

### Core Dependencies (All Versions)

| Package | License | Introduced | Purpose |
|---------|---------|------------|---------|
| dash | MIT | V2 | Web framework |
| dash-mantine-components | MIT | V2 | UI components |
| dash-iconify | MIT | V2 | Icon library |
| dash-ag-grid | MIT | V2 | Data grid |
| plotly | MIT | V1 | Charting |
| pandas | BSD | V1 | Data processing |
| numpy | BSD | V1 | Numerical computing |
| scikit-learn | BSD | V1 | ML algorithms |
| scipy | BSD | V1 | Scientific computing |
| hdbscan | BSD | V2 | Clustering |
| pyod | BSD | V2 | Outlier detection |
| diskcache | Apache 2.0 | V2 | Caching |
| pyarrow | Apache 2.0 | V2 | Parquet support |
| openpyxl | MIT | V2 | Excel support |
| psutil | BSD | V2 | System monitoring |

### V10+ Dependencies (Infrastructure)

| Package | License | Purpose |
|---------|---------|---------|
| SQLAlchemy | MIT | ORM + SQLite |
| Flask-Login | MIT | Authentication |
| passlib | BSD | Password hashing |
| cryptography | Apache/BSD | Fernet encryption |
| polars | MIT | Fast CSV ingest |

### V14+ Dependencies (Enterprise)

| Package | License | Purpose |
|---------|---------|---------|
| waitress | ZPL 2.1 | Production WSGI server |
| watchdog | Apache 2.0 | File system monitoring |

### V15+ Dependencies (REST API)

| Package | License | Purpose |
|---------|---------|---------|
| fastapi | MIT | REST API framework |
| uvicorn | BSD | ASGI server |
| pydantic | MIT | Data validation |
| python-jose | MIT | JWT encoding/decoding |

**Total Dependencies**: V1=6, V2=15, V10=20, V15=24

---

## 8. File & Code Metrics

### File Count Evolution

| Version | Total Files | Python Files | Pages | Utils | Layers | Tests |
|---------|-------------|--------------|-------|-------|--------|-------|
| V1 | ~25 | ~18 | ~8 | ~4 | 6 | 0 |
| V2 | ~25 | ~18 | 9 | 5 | 7 | 0 |
| V3 | ~29 | ~22 | 11 | 7 | 7 | 0 |
| V4 | ~31 | ~24 | 11 | 7 | 7 | 0 |
| V5 | ~31 | ~24 | 11 | 7 | 7 | 0 |
| V6 | ~34 | ~26 | 11 | 8 | 7 | 0 |
| V7 | ~43 | ~28 | 11 | 9 | 7 | 0 |
| V8 | ~47 | ~32 | 12 | 14 | 7 | 0 |
| V9 | ~50 | ~32 | 12 | 14 | 7 | 1 |
| V10 | ~55 | ~37 | 14 | 15 | 7 | 1 |
| V11 | ~60 | ~42 | 19 | 15 | 7 | 1 |
| V12 | ~62 | ~43 | 21 | 15 | 7 | 1 |
| V13-V17 | ~65 | ~45 | 21 | 16 | 7 | 1 |

### Code Volume (Key Files)

| File | V1 | V5 | V10 | V15 | V17 |
|------|----|----|-----|-----|-----|
| app.py | 150 | 444 | 793 | ~800 | ~800 |
| config.py | 107 | 228 | 431 | ~450 | ~470 |
| pipeline.py | ~200 | ~280 | ~318 | ~340 | ~350 |

---

## 9. Database Schema Evolution

### Tables Added by Version

| Version | Tables | Total Tables |
|---------|--------|--------------|
| V1-V9 | None | 0 (Parquet only) |
| V10 | users, anomalies, audit_logs, alert_events | 4 |
| V11 | reports, scheduled_tasks | 6 |
| V12 | compliance_checks, role_assignments | 8 |
| V13 | health_checks, performance_metrics | 10 |
| V16 | pii_access_logs, hash_verifications | 12 |

### Schema Details (V17)

| Table | Columns | Primary Key | Indexes | Purpose |
|-------|---------|-------------|---------|---------|
| users | 7 | id | username, role | Authentication |
| anomalies | 9 | id | customer_id_hash, detected_at | Scored customers |
| audit_logs | 7 | id | timestamp, user, current_hash | Audit trail |
| alert_events | 8 | id | alert_id, customer_id_hash | Alert management |
| reports | 10 | id | user_id, created_at | Report storage |
| scheduled_tasks | 9 | id | schedule_time, status | Task scheduler |
| compliance_checks | 6 | id | check_date, status | Compliance tracking |
| role_assignments | 5 | id | user_id, page | RBAC mapping |
| health_checks | 8 | id | check_time, component | System health |
| performance_metrics | 7 | id | timestamp, metric_name | Performance log |
| pii_access_logs | 8 | id | user, timestamp, masked_status | PII access audit |
| hash_verifications | 6 | id | verified_at, is_valid | Hash chain integrity |

---

## 10. UI Pages & Functionality

### Page Count Evolution

| Version | Total Pages | New Pages |
|---------|-------------|-----------|
| V1 | ~8 | Initial |
| V2 | 9 | +pipeline_run |
| V3 | 11 | +audit_vault, +system_health |
| V4-V7 | 11 | None |
| V8 | 12 | +admin, +config_panel (removed system_health) |
| V9 | 12 | None |
| V10 | 14 | +login, +task_manager |
| V11 | 19 | +reports, +alerts, +drift, +graph, +scheduler |
| V12 | 21 | +compliance, +role_manager |
| V13-V17 | 21 | None |

### Page Access by Role (V10+)

| Page | Admin | Investigator | Viewer |
|------|-------|--------------|--------|
| Dashboard | ✓ | ✓ | ✓ |
| Data Sources | ✓ | ✓ | — |
| Pipeline Run | ✓ | ✓ | — |
| Layer View | ✓ | ✓ | ✓ |
| Investigation Queue | ✓ | ✓ | — |
| Narratives | ✓ | ✓ | — |
| Audit Trail | ✓ | ✓ | ✓ |
| Audit Vault | ✓ | ✓ | — |
| Model Diagnostics | ✓ | ✓ | ✓ |
| Explainability | ✓ | ✓ | ✓ |
| Reports | ✓ | ✓ | ✓ |
| Alerts | ✓ | ✓ | — |
| Graph Analysis | ✓ | ✓ | ✓ |
| Scheduler | ✓ | — | — |
| Admin | ✓ | — | — |
| Config Panel | ✓ | — | — |
| Task Manager | ✓ | ✓ | — |
| Compliance | ✓ | ✓ | — |
| Role Manager | ✓ | — | — |
| Drift Detection | ✓ | ✓ | ✓ |
| What-If Analysis | ✓ | ✓ | — |

---

**Return to**: [Version History V1-V10](../VERSION_HISTORY_V1_TO_V10.md) | [Version History V10-V17](../VERSION_HISTORY_COMPLETE.md)
