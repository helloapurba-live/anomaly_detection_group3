# Version 3.0 — PII Vault & Data Security

**Directory**: `FCDAI_Annomaly_auto_detection_version3/`  
**Version**: 3.0.0  
**Port**: 8085  
**Date**: January 2025

---

## Overview

Version 3 was the first version in the standardized naming convention (`FCDAI_Annomaly_auto_detection_versionN`). It introduced foundational **PII masking**, **data vault architecture**, and **forensic export** capabilities — critical for bank audit compliance.

## What Changed from V2

### Security Foundation

1. **PII Masking Configuration**
2. **Data Vault Architecture** (encrypted storage)
3. **Forensic Export System** (audit-ready exports)
4. **Extended Detection Methods** (35+ methods configured)
5. **System Health Monitoring**

## Key Enhancements

### 1. PII Masking (`PIIConfig`)

```python
@dataclass
class PIIConfig:
    ENABLED_BY_DEFAULT: bool = False  # Later changed to True in V9
    MASK_COLUMNS: List[str] = [
        "customer_id",      # Partial mask: keep first 4 + last 4 digits
        "account_number",   # Full mask: ****-****-****-1234
        "ssn",              # Full mask: ***-**-****
        "name",             # Partial mask: J*** D**
        "email",            # Partial mask: j***@example.com
        "phone"             # Partial mask: +1-***-***-1234
    ]
    MASK_CHAR: str = "*"
    PARTIAL_MASK_STRATEGY: str = "show_edges"  # show_edges | show_start | full
```

**Masking Patterns**:
- **customer_id**: `CUST-1234-5678` → `CUST-****-5678`
- **SSN**: `123-45-6789` → `***-**-6789`
- **Name**: `John Doe` → `J*** D**`
- **Email**: `john.doe@bank.com` → `j***@bank.com`

### 2. Data Vault Architecture

```
data/
├── vault/           # Encrypted scored data (Parquet)
│   ├── current.parquet
│   └── scored.parquet
├── sources/         # Uploaded source files
│   ├── kyc.csv
│   ├── transactions.csv
│   ├── alerts.csv
│   └── cases.csv
└── exports/         # Forensic exports (encrypted)
    └── export_2026-01-15_143022.zip
```

**Features**:
- Parquet format for compression and speed
- PII columns encrypted at rest (later versions)
- SHA-256 file integrity hashing (later versions)

### 3. Forensic Export System

```python
# utils/forensic_export.py

def create_forensic_export(customer_id, include_source_data=True):
    """
    Create tamper-evident export package:
    - Customer risk profile
    - All 26 method scores
    - Source transactions (if requested)
    - Data lineage metadata
    - SHA-256 manifest
    """
    export_path = f"exports/forensic_{customer_id}_{timestamp}.zip"
    # ... implementation
```

**Export Contents**:
1. `customer_profile.json` — Risk score, tier, demographics
2. `method_scores.csv` — All 26 method outputs
3. `transactions.csv` — Source data (if included)
4. `lineage.json` — Data processing trail
5. `manifest.sha256` — File integrity hashes

### 4. Extended Detection Methods

**V2**: 26 methods  
**V3**: 35+ methods configured (superset — not all active per run)

**New Methods Added**:
| Category | Method | Purpose |
|----------|--------|---------|
| Statistical | COPOD | Copula-based outlier detection |
| Statistical | ECOD | Empirical cumulative outlier detection |
| Statistical | HBOS | Histogram-based outlier score |
| Statistical | MCD | Minimum covariance determinant |
| SVM | One-Class SVM | Support vector novelty detection |
| Time-Series | Matrix Profile | Time-series motif/discord detection |
| Deep Learning | SOM | Self-organizing maps |

### 5. System Health Monitoring

New page: **System Health** (`pages/system_health.py`)

**Monitors**:
- CPU usage (%)
- Memory usage (MB, %)
- Disk usage (GB, %)
- Process count
- Uptime
- Log file sizes

## File Structure

```
FCDAI_Annomaly_auto_detection_version3/
├── app.py              # Dash app (216 lines)
├── config.py           # Config with PIIConfig (217 lines)
├── pipeline.py         # Pipeline orchestrator (280 lines)
├── README.md           # Architecture diagram + file list (109 lines)
├── requirements.txt
│
├── layers/             # 7 files
├── pages/              # 11 pages (+2 new)
│   ├── dashboard.py
│   ├── data_sources.py
│   ├── pipeline_run.py
│   ├── layer_view.py
│   ├── explainability.py
│   ├── investigation_queue.py
│   ├── narratives.py
│   ├── audit_trail.py
│   ├── audit_vault.py         # NEW: Vault viewer
│   ├── model_diagnostics.py
│   └── system_health.py       # NEW: System monitoring
│
├── utils/              # 7 files (+2 new)
│   ├── data_io.py
│   ├── explainability.py
│   ├── forensic_export.py     # NEW: Audit exports
│   ├── generate_data.py
│   ├── logger.py
│   ├── pii_masking.py         # NEW: PII masking engine
│   └── __init__.py
│
├── assets/
├── cache/
├── data/
│   ├── vault/          # NEW: Encrypted storage
│   ├── sources/        # NEW: Upload staging
│   └── exports/        # NEW: Forensic exports
├── logs/
└── models/
```

**Total Files**: ~29 (+4 from V2)

## Configuration

```python
# config.py additions

@dataclass
class PIIConfig:
    ENABLED_BY_DEFAULT: bool = False
    MASK_COLUMNS: List[str] = ["customer_id", "account_number", "ssn", "name", "email", "phone"]
    MASK_CHAR: str = "*"
    PARTIAL_MASK_STRATEGY: str = "show_edges"
```

**Total Config Classes**: 6 (added PIIConfig)

## New UI Pages

| Page | Route | Purpose |
|------|-------|---------|
| **Audit Vault** | `/vault` | View vault contents, file sizes, encryption status |
| **System Health** | `/health` | CPU, memory, disk monitoring |

## PII Masking Logic

```python
# utils/pii_masking.py

def mask_column(value: str, strategy: str = "show_edges") -> str:
    if strategy == "show_edges":
        # Keep first 4 and last 4 characters
        if len(value) <= 8:
            return "*" * len(value)
        return value[:4] + "*" * (len(value) - 8) + value[-4:]
    
    elif strategy == "show_start":
        # Keep first 4 characters only
        return value[:4] + "*" * (len(value) - 4)
    
    elif strategy == "full":
        # Full mask
        return "*" * len(value)
```

## Data Source Configuration

```python
@dataclass
class DataSourceConfig:
    SOURCES: Dict = {
        "kyc": {
            "key_column": "customer_id",
            "expected_rows": 100
        },
        "transactions": {
            "key_column": "txn_id",
            "expected_rows": 700
        },
        "alerts": {
            "key_column": "alert_id",
            "expected_rows": 50
        },
        "cases": {
            "key_column": "case_id",
            "expected_rows": 20
        }
    }
```

## Dependencies

No new dependencies — same as V2.

## What Worked Well

1. **PIIConfig**: Clean separation of masking logic from business logic
2. **Vault architecture**: Organized storage (vault/sources/exports)
3. **Forensic exports**: Audit-ready packages with integrity hashes
4. **System health page**: Real-time resource monitoring useful for debugging

## Remaining Challenges (Addressed in V4+)

1. **No scalability testing**: Still unknown performance at 100K+ customers
2. **No background tasks**: Pipeline runs still block UI
3. **No encryption at rest**: Vault files not encrypted (added in V10)
4. **No user authentication**: Single-user system (added in V10)
5. **No hash chain**: Audit logs not tamper-evident (added in V10)

---

**Previous Version**: [VERSION 2 — Dash Migration](VERSION_2_DASH_MIGRATION.md)  
**Next Version**: [VERSION 4 — Scalability](VERSION_4_SCALABILITY.md)  
**Return to**: [Version History V1-V10](../VERSION_HISTORY_V1_TO_V10.md)
