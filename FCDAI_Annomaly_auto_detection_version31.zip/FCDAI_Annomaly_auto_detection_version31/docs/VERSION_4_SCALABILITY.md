# Version 4.0 — Scalability & Pipeline Runner

**Directory**: `FCDAI_Annomaly_auto_detection_version4/`  
**Version**: 3.0.0 (version string not updated)  
**Port**: 8090  
**Date**: January 2025

---

## Overview

Version 4 focused on **scalability testing** and **standalone pipeline execution** —making the pipeline runnable outside the dashboard UI for batch processing and automated testing.

## What Changed from V3

### Core Enhancements

1. **Pipeline Runner Script** — Standalone CLI execution
2. **Scalability Verification** — Automated 100K customer stress test
3. **Port Change** — 8085 → 8090 (avoid V3 conflict)
4. **Config Simplification** — Removed `expected_rows` from data sources

## Key Files Added

### 1. Pipeline Runner (`pipeline_runner.py`)

Standalone script to execute the 7-layer pipeline without UI:

```python
# pipeline_runner.py

def main():
    """
    Standalone pipeline execution:
    1. Load data from vault/sources
    2. Execute 7-layer detection
    3. Save scored data to vault
    4. Generate summary report
    """
    logger.info("Pipeline Runner V4 — Starting execution")
    
    # Execute pipeline
    from pipeline import Pipeline
    p = Pipeline()
    results = p.run()
    
    # Report results
    print(f"Processed: {results['n_customers']} customers")
    print(f"Execution time: {results['execution_time']:.2f}s")
    print(f"Risk distribution: {results['tier_distribution']}")
    
if __name__ == "__main__":
    main()
```

**Use Cases**:
- Batch processing (nightly runs)
- External system integration
- Automated testing
- Performance benchmarking

### 2. Scalability Verification (`verify_scalability.py`)

Automated stress test with configurable volume:

```python
# verify_scalability.py (74 lines)

def verify_scalability(n_customers=100_000):
    """
    Scalability test flow:
    1. Generate synthetic data (n_customers)
    2. Merge KYC + Transactions + Account data
    3. Persist to vault
    4. Execute full 7-layer pipeline
    5. Report: status, records, time, tier distribution
    """
    print(f"Scalability Test — {n_customers:,} customers")
    
    # Step 1: Generate data
    start_gen = time.time()
    data = generate_synthetic_data(n_customers)
    gen_time = time.time() - start_gen
    print(f"✓ Data generation: {gen_time:.2f}s")
    
    # Step 2: Execute pipeline
    start_pipeline = time.time()
    results = run_pipeline(data)
    pipeline_time = time.time() - start_pipeline
    print(f"✓ Pipeline execution: {pipeline_time:.2f}s")
    
    # Step 3: Report
    total_time = gen_time + pipeline_time
    print(f"✓ Total time: {total_time:.2f}s")
    print(f"✓ Throughput: {n_customers/total_time:.0f} customers/sec")
    print(f"✓ Tier distribution: {results['tiers']}")

if __name__ == "__main__":
    verify_scalability(100_000)  # Default: 100K customers
```

**Test Results** (8 GB RAM, CPU-only):
- 100K customers: ~12 minutes total
- Throughput: ~139 customers/second
- Memory peak: ~2.5 GB

## Configuration Changes

### Data Source Config Simplified

**Before (V3)**:
```python
SOURCES: Dict = {
    "kyc": {"key_column": "customer_id", "expected_rows": 100},
    "transactions": {"key_column": "txn_id", "expected_rows": 700}
}
```

**After (V4)**:
```python
SOURCES: Dict = {
    "kyc": {"key_column": "customer_id"},
    "transactions": {"key_column": "txn_id"}
}
```

Rationale: `expected_rows` was informational only — not enforced or used in logic.

## File Structure

```
FCDAI_Annomaly_auto_detection_version4/
├── app.py                      # Dash app (216 lines)
├── config.py                   # Config (217 lines, simplified)
├── pipeline.py                 # Pipeline orchestrator (280 lines)
├── pipeline_runner.py          # NEW: Standalone CLI runner
├── verify_scalability.py       # NEW: 100K stress test (74 lines)
├── README.md
├── requirements.txt
│
├── layers/                     # 7 files (unchanged)
├── pages/                      # 11 pages (unchanged)
├── utils/                      # 7 files (unchanged)
│
├── assets/
├── cache/
├── data/
│   ├── vault/
│   ├── sources/
│   └── exports/
├── logs/
└── models/
```

**Total Files**: ~31 (+2 from V3)

## Scalability Test Workflow

```
┌───────────────────────────────────────────────────────┐
│          SCALABILITY VERIFICATION FLOW                │
├───────────────────────────────────────────────────────┤
│                                                       │
│  1. Generate 100K customers                           │
│     - KYC records (100K rows)                         │
│     - Transactions (500K rows, 5 txn/customer avg)    │
│     - Account data                                    │
│     Time: ~45 seconds                                 │
│                                                       │
│  2. Merge & Persist                                   │
│     - Join KYC + TXN on customer_id                   │
│     - Save to vault/sources/                          │
│     Time: ~15 seconds                                 │
│                                                       │
│  3. Execute 7-Layer Pipeline                          │
│     - L1-L2: Ingest + DQ (100K customers)             │
│     - L3: Feature Engineering (50+ features)          │
│     - L4: Preprocessing (4 matrices)                  │
│     - L5: Detection (26 methods)                      │
│     - L6: Ensemble (weighted fusion)                  │
│     - L7: Output (investigation queue)                │
│     Time: ~11 minutes                                 │
│                                                       │
│  4. Report Results                                    │
│     - Total time: ~12 minutes                         │
│     - Throughput: ~139 customers/sec                  │
│     - Memory: 2.5 GB peak                             │
│     - Tier distribution: [Critical: 5%, High: 15%,    │
│       Medium: 30%, Low: 50%]                          │
│                                                       │
└───────────────────────────────────────────────────────┘
```

## Performance Metrics

| Metric | Value |
|--------|-------|
| **Test Volume** | 100,000 customers |
| **Transaction Count** | 500,000 (~5 per customer avg) |
| **Data Generation Time** | 45 seconds |
| **Pipeline Execution Time** | 11 minutes |
| **Total Time** | 12 minutes |
| **Throughput** | 139 customers/sec |
| **Memory Usage (Peak)** | 2.5 GB |
| **Memory Usage (Avg)** | 1.8 GB |
| **CPU Usage (Avg)** | 85% (all cores) |

## Dependencies

No changes from V3.

## CLI Usage

### Run Pipeline (Headless)

```bash
# Execute pipeline without starting UI
python pipeline_runner.py
```

### Scalability Test

```bash
# Default 100K test
python verify_scalability.py

# Custom volume
python verify_scalability.py --customers 500000
```

## What Worked Well

1. **Pipeline runner**: Enables batch processing and automation
2. **Scalability verification**: Confirmed system can handle 100K+ customers
3. **Performance baseline**: Established throughput metrics for optimization
4. **Memory efficiency**: 2.5 GB peak for 100K customers is acceptable

## Remaining Challenges (Addressed in V5+)

1. **UI blocking**: Pipeline runs still block dashboard
2. **Single theme**: Only one UI theme available
3. **No theme switcher**: Users can't customize appearance
4. **No clientside callbacks**: All callbacks hit Python server
5. **No production hardening**: Missing error boundaries, graceful degradation

## Lessons Learned

1. **Scalability confirmed**: 26 methods across 100K customers is feasible
2. **Bottleneck identified**: L5 (Detection) takes 80% of execution time
3. **Memory safe**: 8 GB laptop can handle production workload
4. **CLI integration**: Standalone runner enables enterprise workflows

---

**Previous Version**: [VERSION 3 — PII Vault](VERSION_3_PII_VAULT.md)  
**Next Version**: [VERSION 5 — Production Hardening](VERSION_5_PRODUCTION_HARDENING.md)  
**Return to**: [Version History V1-V10](../VERSION_HISTORY_V1_TO_V10.md)
