"""V23 Stability & Sync Test — Run once, then delete."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

errors = []

def test(label, fn):
    try:
        fn()
        print(f"  [OK] {label}")
    except Exception as e:
        print(f"  [ERR] {label}: {e}")
        errors.append((label, str(e)))

# ── 1. Module Imports ────────────────────────────────────────────
print("=" * 60)
print("SECTION 1: MODULE IMPORTS")
print("=" * 60)

def t_config():
    from config import AppConfig, DQPipelineConfig
    cfg = AppConfig()
    dqp = DQPipelineConfig()
    assert cfg.VERSION == "23.0.0", f"VERSION={cfg.VERSION}"
    assert cfg.PORT == 8099, f"PORT={cfg.PORT}"
    assert dqp.DQ_PASS_THRESHOLD == 0.95
    assert dqp.DQ_ALLOW_OVERRIDE is True
    assert len(dqp.SCALER_TYPES) == 6
    assert len(dqp.REDUCTION_PATHS) == 8
    print(f"       VERSION={cfg.VERSION}, PORT={cfg.PORT}, THRESHOLD={dqp.DQ_PASS_THRESHOLD}")

def t_dq_validation():
    from utils.dq_validation import DQValidationEngine, DQValidationResult
    eng = DQValidationEngine()
    assert hasattr(eng, '_step1_schema')
    assert hasattr(eng, '_step2_completeness')
    assert hasattr(eng, '_step3_validity')
    assert hasattr(eng, '_step4_referential')
    assert hasattr(eng, '_step5_uniqueness')
    assert hasattr(eng, '_step6_score')
    assert hasattr(eng, 'validate')
    assert hasattr(eng, 'scorecard_to_dict')

def t_dq_processing():
    from utils.dq_processing import DQProcessingEngine, DQProcessingResult
    eng = DQProcessingEngine()
    for i in range(1, 13):
        methods = [m for m in dir(eng) if m.startswith(f"_step{i:02d}")]
        assert len(methods) >= 1, f"Missing step {i:02d}"

def t_preprocessing():
    from utils.preprocessing_engine import PreprocessingEngine, PreprocessingResult
    eng = PreprocessingEngine()
    assert hasattr(eng, 'preprocess')
    assert hasattr(eng, '_missing_values')
    assert hasattr(eng, '_encode_features')
    assert hasattr(eng, '_final_audit')

def t_scaling():
    from utils.scaling_engine import ScalingEngine, ScalingResult
    from utils.scaling_engine import SCALER_STANDARD, SCALER_MINMAX, SCALER_ROBUST
    from utils.scaling_engine import SCALER_MAXABS, SCALER_POWER, SCALER_ORIGINAL
    eng = ScalingEngine()
    assert hasattr(eng, 'scale')
    assert SCALER_STANDARD == "StandardScaler"
    assert SCALER_MINMAX == "MinMaxScaler"
    assert SCALER_ROBUST == "RobustScaler"
    assert SCALER_MAXABS == "MaxAbsScaler"
    assert SCALER_POWER == "PowerTransformer"
    assert SCALER_ORIGINAL == "Original"

def t_reduction():
    from utils.reduction_engine import ReductionEngine, ReductionResult
    eng = ReductionEngine()
    assert hasattr(eng, 'reduce')
    for p in ['_path_none', '_path_mixed_pca', '_path_famd', '_path_umap_mixed',
              '_path_umap_full', '_path_sdae', '_path_agent_quick', '_path_agent_think']:
        assert hasattr(eng, p), f"Missing {p}"

def t_routing():
    from utils.algorithm_routing import get_route, get_all_routes, routing_summary_df
    routes = get_all_routes()
    assert len(routes) == 20, f"Expected 20 routes, got {len(routes)}"
    # Spot-check specific algorithms (class-name scaler values)
    iqr = get_route("IQR")
    assert iqr is not None, "IQR route missing"
    assert iqr.scaler == "RobustScaler", f"IQR scaler={iqr.scaler}"
    vae = get_route("VAE")
    assert vae is not None, "VAE route missing"
    assert vae.scaler == "MinMaxScaler", f"VAE scaler={vae.scaler}"
    pr = get_route("PAGERANK")
    assert pr is not None, "PAGERANK route missing"
    assert pr.never_scale is True
    df = routing_summary_df()
    assert len(df) == 20
    print(f"       {len(routes)} algorithms, routing_summary_df shape={df.shape}")

test("config (AppConfig + DQPipelineConfig)", t_config)
test("dq_validation (6 steps)", t_dq_validation)
test("dq_processing (12 steps)", t_dq_processing)
test("preprocessing_engine", t_preprocessing)
test("scaling_engine (6 scalers)", t_scaling)
test("reduction_engine (8 paths)", t_reduction)
test("algorithm_routing (20 algos)", t_routing)

# ── 2. Functional Test: Run Modules on Synthetic Data ─────────
print()
print("=" * 60)
print("SECTION 2: FUNCTIONAL TEST (synthetic data)")
print("=" * 60)

import pandas as pd
import numpy as np

def t_pipeline_run():
    np.random.seed(42)
    n = 200
    df = pd.DataFrame({
        "cust_id": range(1, n + 1),
        "txn_amount": np.random.exponential(5000, n),
        "txn_count": np.random.randint(1, 100, n),
        "balance": np.random.normal(50000, 15000, n),
        "age": np.random.randint(20, 70, n),
        "risk_score": np.random.uniform(0, 100, n),
        "category": np.random.choice(["A", "B", "C", "D"], n),
        "is_flagged": np.random.choice([0, 1], n),
        "txn_date": pd.date_range("2025-01-01", periods=n, freq="h"),
    })
    # Inject some nulls
    df.loc[5:10, "txn_amount"] = np.nan
    df.loc[50:55, "balance"] = np.nan

    # Module 1: DQ Validation
    from utils.dq_validation import DQValidationEngine
    dq_eng = DQValidationEngine(base_key="cust_id")
    dq_result = dq_eng.validate(df)
    print(f"       M1 DQ Score: {dq_result.dq_score:.1%} ({'PASS' if dq_result.passed else 'FAIL'})")
    assert dq_result.dq_score > 0, "DQ score should be > 0"
    assert dq_result.schema_report is not None
    assert dq_result.completeness_matrix is not None

    # Module 2: DQ Processing
    from utils.dq_processing import DQProcessingEngine
    proc_eng = DQProcessingEngine(base_key="cust_id")
    proc_result = proc_eng.process(df.copy())
    print(f"       M2 Shape: {proc_result.shape_before} -> {proc_result.shape_after}")
    assert proc_result.cleaned_df is not None
    assert len(proc_result.step_log) == 12

    # Module 3: Preprocessing
    from utils.preprocessing_engine import PreprocessingEngine
    pre_eng = PreprocessingEngine()
    pre_result = pre_eng.preprocess(proc_result.cleaned_df.copy(), proc_result.data_type_map)
    em = pre_result.encoded_master
    is_all_numeric = em.select_dtypes(exclude=[np.number]).empty
    is_zero_nan = int(em.isnull().sum().sum()) == 0
    print(f"       M3 EncodedMaster: {em.shape}, all numeric={is_all_numeric}, zero_nan={is_zero_nan}")
    assert is_all_numeric, "EncodedMaster must be 100% numeric"
    assert is_zero_nan, "EncodedMaster must have zero NaN"

    # Module 4: Scaling (keys use class names: "StandardScaler", etc.)
    from utils.scaling_engine import ScalingEngine, SCALER_STANDARD
    sc_eng = ScalingEngine()
    sc_result = sc_eng.scale(pre_result.encoded_master)
    print(f"       M4 Scaled matrices: {list(sc_result.scaled_matrices.keys())}")
    assert len(sc_result.scaled_matrices) == 6, "Should have 6 scaled matrices"

    # Module 5: Reduction (using path 7 = Agent Quick)
    from utils.reduction_engine import ReductionEngine
    red_eng = ReductionEngine()
    std_matrix = sc_result.scaled_matrices[SCALER_STANDARD]
    red_result = red_eng.reduce(std_matrix, feature_names=list(pre_result.encoded_master.columns), path=7)
    print(f"       M5 PreMaster: {red_result.premaster.shape}, path={red_result.path_name}, dims {red_result.dims_before}->{red_result.dims_after}")
    assert red_result.premaster is not None

    # Module 6: Routing check
    from utils.algorithm_routing import get_route
    route = get_route("HDBSCAN")
    print(f"       M6 HDBSCAN route: scaler={route.scaler}, default_reduction={route.default_reduction}")
    assert route.scaler == "StandardScaler"

test("Full 5-Module Pipeline on synthetic data", t_pipeline_run)

# ── 3. Page/Callback Cross-Reference ────────────────────────────
print()
print("=" * 60)
print("SECTION 3: PAGE & CALLBACK CROSS-REFERENCE")
print("=" * 60)

def t_layer_view_refs():
    content = open("pages/layer_view.py", encoding="utf-8").read()
    # Check new tab value IDs (actual Dash tab values)
    for tab_val in ["dq_score", "dq_proc", "enc_master", "scaling", "reduction", "routing"]:
        assert tab_val in content, f"Missing tab value: {tab_val}"
    # Check content div IDs
    for div_id in ["layer-dq-score-content", "layer-dq-proc-content",
                    "layer-enc-master-content", "layer-scaling-content",
                    "layer-reduction-content", "layer-routing-content"]:
        assert div_id in content, f"Missing div ID: {div_id}"
    # Check key module references (some via data_vault dict keys,
    # others via direct imports inside callbacks)
    for mod in ["dq_validation", "dq_processing", "preprocessing",
                "scaling", "reduction_engine", "algorithm_routing"]:
        assert mod in content, f"Missing import ref: {mod}"

def t_pipeline_run_refs():
    content = open("pages/pipeline_run.py", encoding="utf-8").read()
    assert "pipeline-reduction-path" in content, "Missing reduction path dropdown"
    assert "pipeline-missing-strategy" in content, "Missing missing strategy dropdown"
    assert "Agent Quick" in content, "Missing Agent Quick option"
    assert "V23" in content, "Missing V23 marker"

def t_app_pages():
    content = open("app.py", encoding="utf-8").read()
    # V23 uses Dash auto-discovery (use_pages=True, pages_folder='pages')
    assert "use_pages=True" in content or "use_pages = True" in content, \
        "app.py missing use_pages=True for auto-discovery"
    assert "pages_folder" in content, "app.py missing pages_folder config"
    # Verify nav link to layers exists
    assert "layers" in content.lower() or "layer" in content.lower(), \
        "app.py missing layer nav link"

test("layer_view.py: tab IDs & module imports", t_layer_view_refs)
test("pipeline_run.py: dropdown IDs & options", t_pipeline_run_refs)
test("app.py: page registry (auto-discovery)", t_app_pages)

# ── 4. Config Sync ──────────────────────────────────────────────
print()
print("=" * 60)
print("SECTION 4: CONFIG ↔ MODULE SYNC")
print("=" * 60)

def t_config_sync():
    from config import DQPipelineConfig
    dqp = DQPipelineConfig()
    from utils.scaling_engine import (SCALER_STANDARD, SCALER_MINMAX, SCALER_ROBUST,
                                      SCALER_MAXABS, SCALER_POWER, SCALER_ORIGINAL)
    config_scalers = set(dqp.SCALER_TYPES)
    code_scalers = {SCALER_STANDARD, SCALER_MINMAX, SCALER_ROBUST,
                    SCALER_MAXABS, SCALER_POWER, SCALER_ORIGINAL}
    assert config_scalers == code_scalers, \
        f"Scaler mismatch: config={config_scalers} vs code={code_scalers}"

    config_paths = dqp.REDUCTION_PATHS
    assert len(config_paths) == 8, f"Expected 8 reduction paths, got {len(config_paths)}"

    from utils.algorithm_routing import get_all_routes
    routes = get_all_routes()
    for key, route in routes.items():
        if not route.never_scale:
            assert route.scaler in config_scalers, \
                f"{key}: scaler '{route.scaler}' not in config scalers"
        if not route.never_reduce:
            assert 1 <= route.default_reduction <= 8, \
                f"{key}: default_reduction={route.default_reduction} out of range"

    print(f"       6 scalers synced, 8 paths synced, 20 algo routes validated")

test("Config ↔ Module sync (scalers, paths, routing)", t_config_sync)

# ── SUMMARY ─────────────────────────────────────────────────────
print()
print("=" * 60)
total = 11
passed = total - len(errors)
if errors:
    print(f"RESULT: {passed}/{total} PASSED — {len(errors)} FAILED")
    for name, err in errors:
        print(f"  FAIL: {name}")
        print(f"        {err}")
else:
    print(f"RESULT: {passed}/{total} ALL PASSED — V23 is stable and synced!")
print("=" * 60)
