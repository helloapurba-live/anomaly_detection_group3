# AIM AI Vault — FCDAI Anomaly Auto Detection V15

> **Internal Use Only** — Bank AML Investigation Team  
> Proprietary Software — See [LICENSE](LICENSE) for terms

---

## Overview

AIM AI Vault is an **air-gapped, on-premise** Anti-Money Laundering (AML) detection platform built for bank financial crime investigation teams. It combines **26 statistical and machine-learning methods** across a **7-layer detection architecture** with a **production-grade web dashboard** and **RESTful API**.

### Key Capabilities

| Feature | Description |
|---------|-------------|
| **26 Detection Methods** | Statistical, ML, deep learning, graph, temporal, ensemble, and network analysis |
| **7-Layer Architecture** | L1: Statistical → L2: ML → L3: Deep → L4: Graph → L5: Temporal → L6: Ensemble → L7: Network |
| **Risk Tiering** | Automatic CRITICAL / HIGH / MEDIUM / LOW / NORMAL classification |
| **Interactive Dashboard** | Dash + Mantine Components, 12 premium themes, AG Grid tables |
| **REST API** | FastAPI with Swagger UI, 14 endpoints, JWT + API Key auth |
| **PII Protection** | Auto-masking in UI and API, Fernet encryption at rest, role-based redaction |
| **Audit Trail** | Hash-chain integrity, every action logged, tamper detection |
| **RBAC** | Admin / Investigator / Viewer role-based access control |

---

## Quick Start

### Prerequisites

- **Python 3.11+** (Anaconda/Miniconda recommended)
- **Windows 11** (air-gapped workstation)
- No internet connection required after initial setup

### 1. Create Environment

```bash
conda create -n ai311 python=3.11 -y
conda activate ai311
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure

```bash
# Copy the example config and edit as needed
cp config.toml.example config.toml
```

Edit `config.toml` to set:
- `jwt_secret` — a long random string (64+ hex chars)
- Ports if different from defaults (Dashboard: 8078, API: 8079)

### 4. Load Data

Place your transaction CSV/Excel files in the `data/` directory.  
**Never commit data files to version control.**

### 5. Run

```bash
# Start both Dashboard + API server
python app.py

# Or use the Makefile
make run-both
```

| Service | URL | Purpose |
|---------|-----|---------|
| Dashboard | http://127.0.0.1:8078 | Interactive UI |
| API Swagger | http://127.0.0.1:8079/docs | API documentation |
| API ReDoc | http://127.0.0.1:8079/redoc | Alternative API docs |
| Health Check | http://127.0.0.1:8078/health | System health probe |

### 6. Default Login

Contact your system administrator for credentials.  
First-run creates an admin account — change the password immediately.

---

## Project Structure

```
FCDAI_Annomaly_auto_detection_version15/
├── app.py                  # Main application entry point
├── config.py               # Centralized configuration (dataclasses)
├── config.toml.example     # Configuration template
├── requirements.txt        # Python dependencies
├── pyproject.toml          # Project metadata + tool config
├── Makefile                # Common dev commands
├── LICENSE                 # Proprietary license
│
├── api/                    # V15: FastAPI REST API
│   ├── __init__.py
│   ├── server.py           # FastAPI app creation + Uvicorn launcher
│   ├── routes.py           # 14 API endpoints (5 groups)
│   ├── schemas.py          # Pydantic v2 request/response models
│   ├── auth.py             # JWT + API Key authentication
│   └── middleware.py       # Rate limiting, PII masking, RBAC, audit
│
├── auth/                   # Dashboard authentication (Flask-Login)
│   └── manager.py
│
├── database/               # SQLite + SQLAlchemy engine
│   └── engine.py
│
├── layers/                 # 7-Layer detection architecture
│   ├── L1_statistical.py   # Z-score, Benford, IQR, etc.
│   ├── L2_ml.py            # Isolation Forest, LOF, OCSVM
│   ├── L3_deep.py          # Autoencoder anomaly detection
│   ├── L4_graph.py         # Network centrality, PageRank
│   ├── L5_temporal.py      # Time-series, velocity, seasonality
│   ├── L6_ensemble.py      # Weighted voting, stacking
│   └── L7_network.py       # Community detection, flow analysis
│
├── pages/                  # Dash multi-page views
│   ├── dashboard.py        # Main overview
│   ├── analysis.py         # Layer-by-layer analysis
│   ├── alerts.py           # Investigation queue
│   ├── reports.py          # Exportable reports
│   ├── system_health.py    # V14: System monitoring
│   └── help_page.py        # V14: Help & documentation
│
├── services/               # Business logic layer
│   ├── pipeline_service.py # Pipeline orchestration
│   └── data_service.py     # Data access patterns
│
├── utils/                  # Shared utilities
│   ├── data_io.py          # DataVault: load/save data
│   ├── health.py           # Health check endpoints
│   ├── watchdog.py         # System resource monitoring
│   ├── circuit_breaker.py  # Circuit breaker pattern
│   └── pii_masker.py       # PII detection & masking
│
├── docs/                   # Documentation
│   ├── ARCHITECTURE.md     # System architecture
│   ├── API_REFERENCE.md    # Full API endpoint docs
│   ├── DEPLOYMENT.md       # Deployment guide
│   ├── DATA_DICTIONARY.md  # Data field reference
│   ├── COMPLIANCE.md       # Regulatory compliance
│   └── RUNBOOK.md          # Operations runbook
│
├── tests/                  # Test suite
│   └── test_api.py         # API endpoint tests
│
├── data/                   # Transaction data (NEVER committed)
├── logs/                   # Application logs (NEVER committed)
└── cache/                  # Diskcache working dir (NEVER committed)
```

---

## API Overview

The REST API exposes 14 endpoints across 5 groups:

| Group | Endpoints | Description |
|-------|-----------|-------------|
| **Auth** | `POST /auth/token`, `DELETE /auth/revoke` | JWT token issuance and revocation |
| **Pipeline** | `POST /pipeline/run`, `GET /pipeline/status/{id}`, `GET /pipeline/history` | Pipeline execution and monitoring |
| **Results** | `GET /results/scored/{id}`, `GET /results/alerts`, `GET /results/risk-tiers`, `GET /results/entity/{id}` | Scored data, alerts, risk tiers |
| **Audit** | `GET /audit/log`, `GET /audit/verify` | Audit trail and hash-chain verification |
| **System** | `GET /system/health`, `GET /system/metrics`, `GET /system/circuit-breakers` | Health, metrics, circuit breakers |

Full endpoint documentation: [docs/API_REFERENCE.md](docs/API_REFERENCE.md)

---

## Security

- **Air-Gapped** — Zero external network calls, no CDN, no telemetry
- **PII Protection** — Auto-mask in API responses based on role
- **Encryption** — Fernet symmetric encryption for PII at rest
- **Authentication** — Flask-Login (dashboard) + JWT/API Key (API)
- **RBAC** — Admin / Investigator / Viewer permissions per endpoint
- **Audit Trail** — Hash-chain integrity on every action
- **Rate Limiting** — Sliding window (100 req/min default)

See [SECURITY.md](SECURITY.md) for full security details.

---

## Development

```bash
make dev     # Install dev dependencies
make lint    # Run linter
make test    # Run tests
make check   # Full health check
```

See [CONTRIBUTING.md](CONTRIBUTING.md) for contribution guidelines.

---

## Documentation

| Document | Description |
|----------|-------------|
| [ARCHITECTURE.md](docs/ARCHITECTURE.md) | System architecture and 7-layer design |
| [API_REFERENCE.md](docs/API_REFERENCE.md) | Complete API endpoint reference |
| [DEPLOYMENT.md](docs/DEPLOYMENT.md) | Installation and deployment guide |
| [DATA_DICTIONARY.md](docs/DATA_DICTIONARY.md) | Data field definitions |
| [COMPLIANCE.md](docs/COMPLIANCE.md) | BSA/AML regulatory compliance |
| [RUNBOOK.md](docs/RUNBOOK.md) | Operations and troubleshooting |
| [CHANGELOG.md](CHANGELOG.md) | Version history |

---

## License

**Proprietary** — Internal bank AML investigation team use only.  
See [LICENSE](LICENSE) for full terms.

---

*AIM AI Vault V15.0.0 — Built for bank financial crime detection teams*
