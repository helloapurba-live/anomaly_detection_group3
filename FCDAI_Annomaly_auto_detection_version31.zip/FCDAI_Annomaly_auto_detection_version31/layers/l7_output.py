"""
L14 — Output & Alerts (formerly Layer 7)
=================================
Investigation queue, narrative generation, and audit trail.

Components:
- Investigation Queue: Prioritized alert triage
- Narrative System: SHAP-based explanations
- Audit Trail: Decision logging
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Any
from pathlib import Path
from dataclasses import dataclass, field
from datetime import datetime
import json
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PATHS, LAYERS


@dataclass
class Alert:
    """Single investigation alert."""
    alert_id: str
    record_index: int
    risk_score: float
    risk_tier: str
    top_contributors: List[Dict[str, Any]]
    narrative: str
    status: str = "Open"
    assigned_to: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class AuditEntry:
    """Audit trail entry."""
    timestamp: str
    action: str
    user: str
    details: Dict[str, Any]


class InvestigationQueue:
    """
    Investigation Queue Management.
    
    Manages prioritized alert queue for analyst triage.
    """
    
    def __init__(self, capacity: int = None):
        self.capacity = capacity or LAYERS.INVESTIGATION_CAPACITY
        self.alerts: Dict[str, Alert] = {}
        self._id_counter = 0
    
    def generate_alerts(
        self,
        df: pd.DataFrame,
        final_scores: np.ndarray,
        risk_tiers: np.ndarray,
        score_matrix: np.ndarray,
        method_names: List[str],
        limit: int = None
    ) -> List[Alert]:
        """
        Generate alerts from detection results.
        
        Args:
            df: Original dataframe with records
            final_scores: Ensemble scores
            risk_tiers: Risk tier assignments
            score_matrix: Individual method scores
            method_names: Names of detection methods
            limit: Max alerts to generate
            
        Returns:
            List of generated Alert objects
        """
        limit = limit or self.capacity
        
        # Get indices sorted by score (highest first)
        sorted_indices = np.argsort(final_scores)[::-1][:limit]
        
        generated = []
        for idx in sorted_indices:
            # Get top contributing methods
            method_scores = score_matrix[idx] if idx < len(score_matrix) else np.zeros(len(method_names))
            top_indices = np.argsort(method_scores)[::-1][:5]
            
            top_contributors = [
                {"method": method_names[i], "score": float(method_scores[i])}
                for i in top_indices if i < len(method_names)
            ]
            
            # Generate narrative
            narrative = self._generate_narrative(
                risk_tiers[idx],
                final_scores[idx],
                top_contributors
            )
            
            # Create alert
            self._id_counter += 1
            alert_id = f"ALT-{self._id_counter:06d}"
            
            alert = Alert(
                alert_id=alert_id,
                record_index=int(idx),
                risk_score=float(final_scores[idx]),
                risk_tier=str(risk_tiers[idx]),
                top_contributors=top_contributors,
                narrative=narrative
            )
            
            self.alerts[alert_id] = alert
            generated.append(alert)
        
        return generated
    
    def _generate_narrative(
        self,
        tier: str,
        score: float,
        contributors: List[Dict]
    ) -> str:
        """Generate human-readable explanation."""
        narrative = f"This record has been flagged as **{tier}** risk "
        narrative += f"with an anomaly score of **{score:.2%}**.\n\n"
        
        if contributors:
            narrative += "**Key Detection Signals:**\n"
            for i, c in enumerate(contributors[:3], 1):
                method = c['method'].replace('_', ' ').title()
                s = c['score']
                if s > 0.8:
                    narrative += f"{i}. {method}: Very High ({s:.0%})\n"
                elif s > 0.6:
                    narrative += f"{i}. {method}: High ({s:.0%})\n"
                elif s > 0.4:
                    narrative += f"{i}. {method}: Elevated ({s:.0%})\n"
                else:
                    narrative += f"{i}. {method}: Moderate ({s:.0%})\n"
        
        return narrative
    
    def get_queue(
        self, 
        status: str = None, 
        tier: str = None
    ) -> List[Alert]:
        """Get alerts with optional filtering."""
        alerts = list(self.alerts.values())
        
        if status:
            alerts = [a for a in alerts if a.status == status]
        if tier:
            alerts = [a for a in alerts if a.risk_tier == tier]
        
        return sorted(alerts, key=lambda a: a.risk_score, reverse=True)
    
    def update_status(
        self, 
        alert_id: str, 
        status: str,
        assigned_to: str = None
    ) -> bool:
        """Update alert status."""
        if alert_id not in self.alerts:
            return False
        
        self.alerts[alert_id].status = status
        if assigned_to:
            self.alerts[alert_id].assigned_to = assigned_to
        
        return True
    
    def get_summary(self) -> Dict:
        """Get queue summary."""
        alerts = list(self.alerts.values())
        
        tier_counts = {}
        status_counts = {}
        
        for a in alerts:
            tier_counts[a.risk_tier] = tier_counts.get(a.risk_tier, 0) + 1
            status_counts[a.status] = status_counts.get(a.status, 0) + 1
        
        return {
            "total_alerts": len(alerts),
            "by_tier": tier_counts,
            "by_status": status_counts,
            "average_score": float(np.mean([a.risk_score for a in alerts])) if alerts else 0
        }


class NarrativeSystem:
    """
    Narrative Generation System.
    
    Generates SHAP-style explanations for alerts.
    """
    
    def __init__(self):
        self.templates = {
            "Critical": "🚨 **CRITICAL ALERT**: This transaction shows extreme deviation from normal patterns.",
            "High": "⚠️ **HIGH RISK**: Multiple anomaly indicators triggered.",
            "Medium": "📊 **MEDIUM RISK**: Some unusual patterns detected.",
            "Low": "ℹ️ **LOW RISK**: Minor deviations observed."
        }
    
    def generate_explanation(
        self,
        record: Dict[str, Any],
        score: float,
        tier: str,
        contributors: List[Dict],
        feature_values: Dict[str, float] = None
    ) -> str:
        """
        Generate full SHAP-style explanation.
        
        Args:
            record: Original record data
            score: Final risk score
            tier: Risk tier
            contributors: Top contributing methods
            feature_values: Feature contributions (SHAP values)
            
        Returns:
            Markdown formatted explanation
        """
        explanation = []
        
        # Header
        explanation.append(self.templates.get(tier, "Alert generated."))
        explanation.append(f"\n**Risk Score:** {score:.2%}")
        explanation.append(f"**Risk Tier:** {tier}\n")
        
        # Detection breakdown
        explanation.append("### Detection Method Breakdown\n")
        for c in contributors[:5]:
            bar = "█" * int(c['score'] * 10)
            explanation.append(f"- **{c['method']}**: {bar} {c['score']:.0%}")
        
        # Feature contributions if available
        if feature_values:
            explanation.append("\n### Top Feature Contributions\n")
            sorted_features = sorted(
                feature_values.items(), 
                key=lambda x: abs(x[1]), 
                reverse=True
            )[:5]
            for feat, val in sorted_features:
                direction = "↑" if val > 0 else "↓"
                explanation.append(f"- {feat}: {direction} {abs(val):.3f}")
        
        # Recommendation
        explanation.append("\n### Recommended Actions\n")
        if tier == "Critical":
            explanation.append("1. **Immediate review required**")
            explanation.append("2. Escalate to senior analyst")
            explanation.append("3. Consider regulatory filing")
        elif tier == "High":
            explanation.append("1. Priority review within 24 hours")
            explanation.append("2. Gather additional context")
        else:
            explanation.append("1. Review during normal queue processing")
        
        return "\n".join(explanation)
    
    def batch_generate(
        self,
        alerts: List[Alert]
    ) -> Dict[str, str]:
        """Generate explanations for multiple alerts."""
        explanations = {}
        for alert in alerts:
            explanations[alert.alert_id] = self.generate_explanation(
                record={},
                score=alert.risk_score,
                tier=alert.risk_tier,
                contributors=alert.top_contributors
            )
        return explanations


class AuditTrail:
    """
    Audit Trail Database.
    
    Logs all decisions and actions for compliance.
    """
    
    def __init__(self, log_path: Path = None):
        self.log_path = log_path or PATHS.LOGS / "audit_trail.jsonl"
        self.entries: List[AuditEntry] = []
        self._load_existing()
    
    def _load_existing(self):
        """Load existing audit entries."""
        if self.log_path.exists():
            try:
                with open(self.log_path, 'r') as f:
                    for line in f:
                        data = json.loads(line.strip())
                        self.entries.append(AuditEntry(**data))
            except Exception:
                pass
    
    def log(
        self, 
        action: str, 
        user: str = "system",
        details: Dict[str, Any] = None
    ):
        """Log an action."""
        entry = AuditEntry(
            timestamp=datetime.now().isoformat(),
            action=action,
            user=user,
            details=details or {}
        )
        
        self.entries.append(entry)
        
        # Persist
        with open(self.log_path, 'a') as f:
            f.write(json.dumps({
                "timestamp": entry.timestamp,
                "action": entry.action,
                "user": entry.user,
                "details": entry.details
            }) + "\n")
    
    def log_alert_action(
        self,
        alert_id: str,
        action: str,
        user: str,
        notes: str = ""
    ):
        """Log alert-specific action."""
        self.log(
            action=f"ALERT_{action.upper()}",
            user=user,
            details={
                "alert_id": alert_id,
                "notes": notes
            }
        )
    
    def log_pipeline_run(
        self,
        n_records: int,
        n_alerts: int,
        methods_used: List[str]
    ):
        """Log pipeline execution."""
        self.log(
            action="PIPELINE_RUN",
            user="system",
            details={
                "records_processed": n_records,
                "alerts_generated": n_alerts,
                "methods": methods_used
            }
        )
    
    def get_entries(
        self, 
        action_filter: str = None,
        user_filter: str = None,
        limit: int = 100
    ) -> List[AuditEntry]:
        """Get audit entries with filtering."""
        entries = self.entries
        
        if action_filter:
            entries = [e for e in entries if action_filter in e.action]
        if user_filter:
            entries = [e for e in entries if e.user == user_filter]
        
        return entries[-limit:]
    
    def get_summary(self) -> Dict:
        """Get audit summary."""
        action_counts = {}
        for e in self.entries:
            action_counts[e.action] = action_counts.get(e.action, 0) + 1
        
        return {
            "total_entries": len(self.entries),
            "by_action": action_counts,
            "earliest": self.entries[0].timestamp if self.entries else None,
            "latest": self.entries[-1].timestamp if self.entries else None
        }


class Layer7Output:
    """
    Layer 7: Orchestrate output components.
    """
    
    def __init__(self):
        self.queue = InvestigationQueue()
        self.narrative = NarrativeSystem()
        self.audit = AuditTrail()
    
    def process(
        self,
        df: pd.DataFrame,
        final_scores: np.ndarray,
        risk_tiers: np.ndarray,
        score_matrix: np.ndarray,
        method_names: List[str]
    ) -> Dict:
        """
        Full Layer 7 processing.
        
        Args:
            df: Original dataframe
            final_scores: Ensemble scores
            risk_tiers: Risk tiers
            score_matrix: Method scores
            method_names: Method names
            
        Returns:
            Summary of output processing
        """
        # Generate alerts
        alerts = self.queue.generate_alerts(
            df, final_scores, risk_tiers, 
            score_matrix, method_names
        )
        
        # Generate narratives for top alerts
        top_alerts = alerts[:50]
        explanations = self.narrative.batch_generate(top_alerts)
        
        # Log pipeline run
        self.audit.log_pipeline_run(
            n_records=len(df),
            n_alerts=len(alerts),
            methods_used=method_names
        )
        
        return {
            "alerts_generated": len(alerts),
            "queue_summary": self.queue.get_summary(),
            "audit_summary": self.audit.get_summary(),
            "sample_explanations": list(explanations.values())[:3]
        }
