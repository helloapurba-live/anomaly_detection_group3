"""
Rollup Engine — V19 Spec-Driven Grain Normalization
=====================================================
Implements 4 rollup strategies per TABLE_GRAIN_DETECTION config:
  DIRECT      — 1:1 relationship, join as-is
  AGGREGATE   — many:1, auto-aggregate by column type
  TAKE_LATEST — keep most recent record per BASE_KEY
  AUTO_DETECT — agent decides based on row count per key

Handles:
  - Completely missing tables (graceful skip)
  - Completely blank columns (auto-drop 100% null / zero-variance)
  - Separate GRAPH_DATA / TEMPORAL_DATA extraction (NOT joined to MASTER)
  - Config-driven join keys (TABLE_MAP) or auto-discovery
  - Key alias matching (exact → alias → suffix → skip)

Author: ApurbaDas Pipeline — V19 Spec Implementation
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from datetime import datetime
import logging
import json

logger = logging.getLogger("apurbadas.rollup_engine")


# =============================================================================
# DATA CLASSES
# =============================================================================
@dataclass
class RollupResult:
    """Result of rolling up a single table to BASE grain."""
    table_name: str
    strategy: str
    success: bool
    rolled_df: Optional[pd.DataFrame] = None
    join_key: Optional[str] = None
    n_rows_before: int = 0
    n_rows_after: int = 0
    n_cols_added: int = 0
    message: str = ""
    dropped_cols: List[str] = field(default_factory=list)


@dataclass
class GraphData:
    """Extracted graph data from RELATIONSHIPS table."""
    nodes_df: Optional[pd.DataFrame] = None
    edges_df: Optional[pd.DataFrame] = None
    entity_node_map: Optional[pd.DataFrame] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    available: bool = False


@dataclass
class TemporalData:
    """Extracted temporal data from TEMPORAL table."""
    long_df: Optional[pd.DataFrame] = None
    wide_df: Optional[pd.DataFrame] = None
    entity_period_map: Optional[pd.DataFrame] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    available: bool = False


@dataclass
class MasterBuildResult:
    """Complete result of building MASTER table."""
    master_df: Optional[pd.DataFrame] = None
    graph_data: Optional[GraphData] = None
    temporal_data: Optional[TemporalData] = None
    rollup_results: List[RollupResult] = field(default_factory=list)
    processing_log: List[Dict[str, Any]] = field(default_factory=list)
    data_quality: List[Dict[str, Any]] = field(default_factory=list)
    data_availability: Dict[str, bool] = field(default_factory=dict)
    base_key: str = "cust_id"
    success: bool = False
    error: str = ""


# =============================================================================
# DEFAULT CONFIG
# =============================================================================
DEFAULT_GRAIN_CONFIG = {
    "transactions":   {"native_grain": "transaction",  "rollup_strategy": "AGGREGATE"},
    "customer_party": {"native_grain": "customer",     "rollup_strategy": "DIRECT"},
    "accounts":       {"native_grain": "account",      "rollup_strategy": "AGGREGATE"},
    "alerts":         {"native_grain": "alert",        "rollup_strategy": "AGGREGATE"},
    "cases":          {"native_grain": "case",         "rollup_strategy": "AGGREGATE"},
    "kyc":            {"native_grain": "kyc_record",   "rollup_strategy": "TAKE_LATEST"},
    "watchlist":      {"native_grain": "match",        "rollup_strategy": "AGGREGATE"},
    "others1":        {"native_grain": "custom",       "rollup_strategy": "AUTO_DETECT"},
    "others2":        {"native_grain": "custom",       "rollup_strategy": "AUTO_DETECT"},
}

DEFAULT_BASE_KEY = "cust_id"
DEFAULT_BASE_KEY_ALIASES = [
    "customer_id", "customerid", "cust", "customer",
    "custid", "cust_identifier", "party_id", "partyid",
    "client_id", "entity_id",
]

# Tables that join to MASTER (tabular)
TABULAR_TABLES = [
    "transactions", "customer_party", "accounts", "alerts",
    "cases", "kyc", "watchlist", "others1", "others2",
]

# Tables extracted separately (NOT joined to MASTER)
EXTRACT_TABLES = ["relationships_edges", "relationships_nodes", "temporal_long", "temporal_wide"]


# =============================================================================
# ROLLUP ENGINE
# =============================================================================
class RollupEngine:
    """
    Core engine for rolling up tables to BASE grain per spec.
    
    Strategies:
      DIRECT      — 1:1, join directly
      AGGREGATE   — many:1, apply SUM/AVG/MAX/MIN/STD/COUNT for numeric,
                    COUNT/NUNIQUE/MODE for categorical
      TAKE_LATEST — sort by date DESC, keep first per key
      AUTO_DETECT — decide based on rows_per_key ratio
    """

    def __init__(
        self,
        base_key: str = DEFAULT_BASE_KEY,
        base_key_aliases: Optional[List[str]] = None,
        grain_config: Optional[Dict] = None,
        table_map: Optional[pd.DataFrame] = None,
        exclude_config: Optional[pd.DataFrame] = None,
    ):
        self.base_key = base_key
        self.base_key_aliases = base_key_aliases or DEFAULT_BASE_KEY_ALIASES
        self.grain_config = grain_config or DEFAULT_GRAIN_CONFIG
        self.table_map = table_map
        self.exclude_config = exclude_config
        self.log: List[Dict[str, Any]] = []

    def _log(self, level: str, table: str, message: str):
        """Add entry to processing log."""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "level": level,
            "table": table,
            "message": message,
        }
        self.log.append(entry)
        getattr(logger, level.lower(), logger.info)(f"[{table}] {message}")

    # ─── KEY DISCOVERY ───────────────────────────────────────────────
    def discover_join_key(
        self, df: pd.DataFrame, table_name: str
    ) -> Optional[str]:
        """
        Discover join key in df that maps to BASE_KEY.
        
        Priority:
          1. TABLE_MAP config (if provided)
          2. Exact match: base_key column name
          3. Alias match: any base_key_alias
          4. Suffix match: *_{base_key}, *_{alias}
          5. NOT FOUND → skip table
        """
        # 1. Check TABLE_MAP config
        if self.table_map is not None and len(self.table_map) > 0:
            # Support both column naming conventions: target_table/target_key and table_name/join_key
            tm_cols = {c.lower(): c for c in self.table_map.columns}
            tbl_col = tm_cols.get("target_table", tm_cols.get("table_name"))
            key_col = tm_cols.get("target_key", tm_cols.get("join_key"))
            if tbl_col and key_col:
                row = self.table_map[
                    self.table_map[tbl_col].str.lower() == table_name.lower()
                ]
                if len(row) > 0:
                    target_key = str(row.iloc[0].get(key_col, ""))
                    if target_key and target_key in df.columns:
                        self._log("INFO", table_name, f"Join key from TABLE_MAP: {target_key}")
                        return target_key

        cols_lower = {c.lower(): c for c in df.columns}

        # 2. Exact match
        if self.base_key.lower() in cols_lower:
            return cols_lower[self.base_key.lower()]

        # 3. Alias match
        for alias in self.base_key_aliases:
            if alias.lower() in cols_lower:
                return cols_lower[alias.lower()]

        # 4. Suffix match
        for col_lower, col_orig in cols_lower.items():
            if col_lower.endswith(f"_{self.base_key.lower()}"):
                return col_orig
            for alias in self.base_key_aliases:
                if col_lower.endswith(f"_{alias.lower()}"):
                    return col_orig

        # 5. Not found
        self._log("WARN", table_name, "No join key found — skipping table")
        return None

    # ─── BLANK COLUMN CLEANUP ────────────────────────────────────────
    def clean_blank_columns(
        self, df: pd.DataFrame, table_name: str
    ) -> Tuple[pd.DataFrame, List[str]]:
        """
        Remove 100% null columns and zero-variance columns.
        Returns cleaned df and list of dropped column names.
        """
        dropped = []
        for col in df.columns:
            # 100% null
            if df[col].isnull().all():
                dropped.append(col)
                continue
            # Zero-variance (non-null values)
            non_null = df[col].dropna()
            if len(non_null) > 0 and non_null.nunique() == 1:
                # Keep if it's the join key
                if col.lower() != self.base_key.lower() and col.lower() not in [a.lower() for a in self.base_key_aliases]:
                    dropped.append(col)

        if dropped:
            df = df.drop(columns=dropped, errors="ignore")
            self._log("INFO", table_name, f"Dropped {len(dropped)} blank/zero-variance columns: {dropped[:5]}{'...' if len(dropped)>5 else ''}")

        return df, dropped

    # ─── ROLLUP: AGGREGATE ───────────────────────────────────────────
    def _rollup_aggregate(
        self, df: pd.DataFrame, join_key: str, table_name: str
    ) -> pd.DataFrame:
        """
        AGGREGATE strategy: group by join_key, aggregate by column type.
        
        Numeric:     {col}_sum, {col}_avg, {col}_max, {col}_min, {col}_std, {col}_count
        Categorical: {col}_count, {col}_nunique, {col}_mode
        Binary:      {col}_sum (count of 1s), {col}_avg (proportion)
        Datetime:    {col}_min (first), {col}_max (last), {col}_count, {col}_span_days
        """
        agg_dict = {}
        prefix = table_name[:4].lower()

        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        cat_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()
        date_cols = df.select_dtypes(include=["datetime", "datetime64"]).columns.tolist()

        # Also try to detect datetime from object columns
        for col in cat_cols[:]:
            try:
                sample = df[col].dropna().head(20)
                if len(sample) > 0:
                    pd.to_datetime(sample)
                    date_cols.append(col)
                    cat_cols.remove(col)
            except (ValueError, TypeError):
                pass

        for col in numeric_cols:
            if col == join_key:
                continue
            clean = col.replace(" ", "_").lower()
            # Detect binary (only 0/1 values)
            unique_vals = df[col].dropna().unique()
            if set(unique_vals).issubset({0, 1, 0.0, 1.0, True, False}):
                # Binary
                agg_dict[f"{prefix}_{clean}_sum"] = pd.NamedAgg(column=col, aggfunc="sum")
                agg_dict[f"{prefix}_{clean}_avg"] = pd.NamedAgg(column=col, aggfunc="mean")
            else:
                # Numeric
                agg_dict[f"{prefix}_{clean}_sum"] = pd.NamedAgg(column=col, aggfunc="sum")
                agg_dict[f"{prefix}_{clean}_avg"] = pd.NamedAgg(column=col, aggfunc="mean")
                agg_dict[f"{prefix}_{clean}_max"] = pd.NamedAgg(column=col, aggfunc="max")
                agg_dict[f"{prefix}_{clean}_min"] = pd.NamedAgg(column=col, aggfunc="min")
                agg_dict[f"{prefix}_{clean}_std"] = pd.NamedAgg(column=col, aggfunc="std")
                agg_dict[f"{prefix}_{clean}_count"] = pd.NamedAgg(column=col, aggfunc="count")

        for col in cat_cols:
            if col == join_key:
                continue
            clean = col.replace(" ", "_").lower()
            agg_dict[f"{prefix}_{clean}_count"] = pd.NamedAgg(column=col, aggfunc="count")
            agg_dict[f"{prefix}_{clean}_nunique"] = pd.NamedAgg(column=col, aggfunc="nunique")
            # Mode requires special handling
            # We'll do it post-groupby

        for col in date_cols:
            if col == join_key:
                continue
            clean = col.replace(" ", "_").lower()
            try:
                df[col] = pd.to_datetime(df[col], errors="coerce")
                agg_dict[f"{prefix}_{clean}_first"] = pd.NamedAgg(column=col, aggfunc="min")
                agg_dict[f"{prefix}_{clean}_last"] = pd.NamedAgg(column=col, aggfunc="max")
                agg_dict[f"{prefix}_{clean}_count"] = pd.NamedAgg(column=col, aggfunc="count")
            except Exception:
                pass

        if not agg_dict:
            # Fallback: just count rows per key
            agg_dict[f"{prefix}_row_count"] = pd.NamedAgg(column=join_key, aggfunc="count")

        result = df.groupby(join_key).agg(**agg_dict).reset_index()

        # Add mode for categorical columns
        for col in cat_cols:
            if col == join_key:
                continue
            clean = col.replace(" ", "_").lower()
            try:
                mode_series = df.groupby(join_key)[col].agg(
                    lambda x: x.mode().iloc[0] if len(x.mode()) > 0 else None
                )
                result[f"{prefix}_{clean}_mode"] = result[join_key].map(mode_series)
            except Exception:
                pass

        # Add span_days for datetime columns
        for col in date_cols:
            if col == join_key:
                continue
            clean = col.replace(" ", "_").lower()
            first_col = f"{prefix}_{clean}_first"
            last_col = f"{prefix}_{clean}_last"
            if first_col in result.columns and last_col in result.columns:
                try:
                    result[f"{prefix}_{clean}_span_days"] = (
                        pd.to_datetime(result[last_col]) - pd.to_datetime(result[first_col])
                    ).dt.days
                except Exception:
                    pass

        self._log("INFO", table_name,
                  f"AGGREGATE: {len(df)} rows → {len(result)} rows, {len(result.columns)-1} features")
        return result

    # ─── ROLLUP: TAKE_LATEST ────────────────────────────────────────
    def _rollup_take_latest(
        self, df: pd.DataFrame, join_key: str, table_name: str
    ) -> pd.DataFrame:
        """
        TAKE_LATEST strategy: sort by date DESC, keep most recent per key.
        Auto-detects date column.
        """
        # Find date column
        date_col = None
        for col in df.columns:
            col_lower = col.lower()
            if any(kw in col_lower for kw in ["date", "timestamp", "time", "created", "updated", "review"]):
                try:
                    pd.to_datetime(df[col].dropna().head(10))
                    date_col = col
                    break
                except (ValueError, TypeError):
                    continue

        if date_col is None:
            # Try all columns for datetime
            for col in df.columns:
                if col == join_key:
                    continue
                try:
                    pd.to_datetime(df[col].dropna().head(10))
                    date_col = col
                    break
                except (ValueError, TypeError):
                    continue

        if date_col:
            df = df.copy()
            df[date_col] = pd.to_datetime(df[date_col], errors="coerce")
            result = df.sort_values(date_col, ascending=False).drop_duplicates(subset=[join_key], keep="first")
            self._log("INFO", table_name,
                      f"TAKE_LATEST by '{date_col}': {len(df)} rows → {len(result)} rows")
        else:
            # Fallback: keep last occurrence
            result = df.drop_duplicates(subset=[join_key], keep="last")
            self._log("WARN", table_name,
                      f"TAKE_LATEST: no date column found, keeping last occurrence. {len(df)} → {len(result)} rows")

        # Drop the key column since it will be the join key
        prefix = table_name[:3].lower()
        rename_map = {}
        for col in result.columns:
            if col == join_key:
                continue
            rename_map[col] = f"{prefix}_{col}" if not col.startswith(f"{prefix}_") else col
        result = result.rename(columns=rename_map)

        return result

    # ─── ROLLUP: DIRECT ──────────────────────────────────────────────
    def _rollup_direct(
        self, df: pd.DataFrame, join_key: str, table_name: str
    ) -> pd.DataFrame:
        """DIRECT strategy: 1:1, dedup by key, join as-is."""
        result = df.drop_duplicates(subset=[join_key], keep="first")
        prefix = table_name[:4].lower()
        rename_map = {}
        for col in result.columns:
            if col == join_key:
                continue
            rename_map[col] = f"{prefix}_{col}" if not col.startswith(f"{prefix}_") else col
        result = result.rename(columns=rename_map)
        self._log("INFO", table_name,
                  f"DIRECT: {len(df)} rows → {len(result)} rows (dedup), {len(result.columns)-1} features")
        return result

    # ─── ROLLUP: AUTO_DETECT ────────────────────────────────────────
    def _rollup_auto_detect(
        self, df: pd.DataFrame, join_key: str, table_name: str
    ) -> pd.DataFrame:
        """
        AUTO_DETECT: decide strategy based on rows per key.
        If avg rows/key ≈ 1 → DIRECT, else → AGGREGATE.
        """
        rows_per_key = df.groupby(join_key).size()
        avg_rows = rows_per_key.mean()

        if avg_rows <= 1.1:
            self._log("INFO", table_name, f"AUTO_DETECT → DIRECT (avg {avg_rows:.1f} rows/key)")
            return self._rollup_direct(df, join_key, table_name)
        else:
            self._log("INFO", table_name, f"AUTO_DETECT → AGGREGATE (avg {avg_rows:.1f} rows/key)")
            return self._rollup_aggregate(df, join_key, table_name)

    # ─── MAIN ROLLUP DISPATCH ────────────────────────────────────────
    def rollup_table(
        self, df: pd.DataFrame, table_name: str, strategy: Optional[str] = None
    ) -> RollupResult:
        """
        Roll up a single table to BASE grain.
        
        Args:
            df: Source DataFrame
            table_name: Name of the table
            strategy: Override strategy (DIRECT/AGGREGATE/TAKE_LATEST/AUTO_DETECT)
        
        Returns:
            RollupResult with rolled-up DataFrame
        """
        result = RollupResult(table_name=table_name, strategy="", success=False)

        if df is None or len(df) == 0:
            result.message = f"Table '{table_name}' is empty — skipping"
            self._log("WARN", table_name, result.message)
            return result

        result.n_rows_before = len(df)

        # Clean blank columns first
        df, dropped = self.clean_blank_columns(df, table_name)
        result.dropped_cols = dropped

        # Discover join key
        join_key = self.discover_join_key(df, table_name)
        if join_key is None:
            result.message = f"No join key found in '{table_name}' — skipping"
            return result
        result.join_key = join_key

        # Determine strategy
        if strategy is None:
            cfg = self.grain_config.get(table_name.lower(), {})
            strategy = cfg.get("rollup_strategy", "AUTO_DETECT")
        result.strategy = strategy

        # Execute rollup
        try:
            if strategy == "DIRECT":
                rolled = self._rollup_direct(df, join_key, table_name)
            elif strategy == "AGGREGATE":
                rolled = self._rollup_aggregate(df, join_key, table_name)
            elif strategy == "TAKE_LATEST":
                rolled = self._rollup_take_latest(df, join_key, table_name)
            elif strategy == "AUTO_DETECT":
                rolled = self._rollup_auto_detect(df, join_key, table_name)
            else:
                self._log("WARN", table_name, f"Unknown strategy '{strategy}', falling back to AUTO_DETECT")
                rolled = self._rollup_auto_detect(df, join_key, table_name)

            result.rolled_df = rolled
            result.n_rows_after = len(rolled)
            result.n_cols_added = len(rolled.columns) - 1  # minus join key
            result.success = True
            result.message = f"Rolled up '{table_name}' ({strategy}): {result.n_rows_before} → {result.n_rows_after} rows, +{result.n_cols_added} cols"

        except Exception as e:
            result.message = f"Rollup error for '{table_name}': {str(e)}"
            self._log("ERROR", table_name, result.message)

        return result

    # ─── GRAPH DATA EXTRACTION ───────────────────────────────────────
    def extract_graph_data(
        self, df: pd.DataFrame, base_key: str
    ) -> GraphData:
        """
        Extract GRAPH_DATA from RELATIONSHIPS table.
        NOT joined to MASTER — separate output.
        """
        gd = GraphData()

        if df is None or len(df) == 0:
            self._log("INFO", "relationships", "No relationships data — GRAPH_DATA = None")
            return gd

        try:
            # Detect edge columns (from/to patterns)
            from_col = None
            to_col = None
            for col in df.columns:
                cl = col.lower()
                if "from" in cl and ("party" in cl or "node" in cl or "id" in cl):
                    from_col = col
                elif "to" in cl and ("party" in cl or "node" in cl or "id" in cl):
                    to_col = col
                elif "source" in cl:
                    from_col = from_col or col
                elif "target" in cl:
                    to_col = to_col or col

            if from_col is None or to_col is None:
                # Try first two columns as from/to
                if len(df.columns) >= 2:
                    from_col = df.columns[0]
                    to_col = df.columns[1]

            # Build edges
            edge_cols = [c for c in df.columns]
            gd.edges_df = df[edge_cols].copy()

            # Build unique nodes
            if from_col and to_col:
                all_nodes = set(df[from_col].dropna().unique()) | set(df[to_col].dropna().unique())
                nodes_list = []
                for i, node_id in enumerate(sorted(all_nodes)):
                    nodes_list.append({
                        "node_id": f"N_{i:06d}",
                        "entity_id": node_id,
                        "node_type": "entity",
                    })
                gd.nodes_df = pd.DataFrame(nodes_list)

                # Entity-node mapping
                gd.entity_node_map = gd.nodes_df[["entity_id", "node_id"]].copy()

            gd.metadata = {
                "node_count": len(gd.nodes_df) if gd.nodes_df is not None else 0,
                "edge_count": len(gd.edges_df) if gd.edges_df is not None else 0,
                "is_directed": True,
                "from_column": from_col,
                "to_column": to_col,
                "extracted_at": datetime.now().isoformat(),
            }
            gd.available = True
            self._log("INFO", "relationships",
                      f"GRAPH_DATA extracted: {gd.metadata['node_count']} nodes, {gd.metadata['edge_count']} edges")

        except Exception as e:
            self._log("ERROR", "relationships", f"Graph extraction error: {str(e)}")

        return gd

    # ─── TEMPORAL DATA EXTRACTION ────────────────────────────────────
    def extract_temporal_data(
        self, df: pd.DataFrame, base_key: str
    ) -> TemporalData:
        """
        Extract TEMPORAL_DATA from TEMPORAL table.
        NOT joined to MASTER — separate output.
        Standardizes to long and wide formats.
        """
        td = TemporalData()

        if df is None or len(df) == 0:
            self._log("INFO", "temporal", "No temporal data — TEMPORAL_DATA = None")
            return td

        try:
            # Find key column
            key_col = None
            cols_lower = {c.lower(): c for c in df.columns}
            for candidate in [base_key] + self.base_key_aliases:
                if candidate.lower() in cols_lower:
                    key_col = cols_lower[candidate.lower()]
                    break
            if key_col is None:
                key_col = df.columns[0]

            # Detect period/date column
            period_col = None
            for col in df.columns:
                cl = col.lower()
                if any(kw in cl for kw in ["month", "period", "date", "time", "quarter", "year"]):
                    period_col = col
                    break
            if period_col is None and len(df.columns) > 1:
                period_col = df.columns[1]

            # Detect if already long or wide format
            numeric_cols = [c for c in df.select_dtypes(include=[np.number]).columns if c != key_col]

            # Assume long format: key_col, period_col, metric columns
            td.long_df = df.copy()

            # Build wide format (pivot by period)
            if period_col and len(numeric_cols) > 0:
                try:
                    first_metric = numeric_cols[0]
                    wide = df.pivot_table(
                        index=key_col, columns=period_col,
                        values=first_metric, aggfunc="sum"
                    ).reset_index()
                    wide.columns = [str(c) for c in wide.columns]
                    td.wide_df = wide
                except Exception:
                    td.wide_df = df.copy()
            else:
                td.wide_df = df.copy()

            # Entity-period map
            if period_col:
                try:
                    period_vals = pd.to_datetime(df[period_col], errors="coerce")
                    entity_map = df.groupby(key_col).agg(
                        min_period=(period_col, "min"),
                        max_period=(period_col, "max"),
                        period_count=(period_col, "count"),
                    ).reset_index()
                    td.entity_period_map = entity_map
                except Exception:
                    pass

            td.metadata = {
                "key_column": key_col,
                "period_column": period_col,
                "total_records": len(df),
                "unique_entities": df[key_col].nunique() if key_col else 0,
                "metric_columns": numeric_cols,
                "extracted_at": datetime.now().isoformat(),
            }
            td.available = True
            self._log("INFO", "temporal",
                      f"TEMPORAL_DATA extracted: {td.metadata['total_records']} records, "
                      f"{td.metadata['unique_entities']} entities")

        except Exception as e:
            self._log("ERROR", "temporal", f"Temporal extraction error: {str(e)}")

        return td

    # ─── APPLY EXCLUSIONS ────────────────────────────────────────────
    def apply_exclusions(
        self, df: pd.DataFrame, base_key: str
    ) -> Tuple[pd.DataFrame, List[str]]:
        """
        Apply exclusion rules:
        1. EXCLUDE config (if provided)
        2. Auto-detect PII patterns (*name*, *ssn*, *phone*)
        3. Drop ID columns (*_id except base_key)
        4. Drop 100% null columns
        5. Drop zero-variance columns
        """
        excluded = []
        protected = {base_key.lower()}

        # Auto-detect PII
        pii_patterns = ["name", "ssn", "phone", "email", "address", "dob", "birth"]
        for col in df.columns:
            cl = col.lower()
            if any(p in cl for p in pii_patterns) and cl not in protected:
                excluded.append(col)

        # Config-driven exclusions
        if self.exclude_config is not None and len(self.exclude_config) > 0:
            # Support both column conventions: feature_name and variable
            ex_cols = {c.lower(): c for c in self.exclude_config.columns}
            name_col = ex_cols.get("feature_name", ex_cols.get("variable"))
            if name_col:
                config_excludes = self.exclude_config[name_col].tolist()
                for col in df.columns:
                    if col in config_excludes and col.lower() not in protected:
                        if col not in excluded:
                            excluded.append(col)

        # Drop 100% null
        for col in df.columns:
            if df[col].isnull().all() and col not in excluded:
                excluded.append(col)

        # Drop zero-variance
        for col in df.columns:
            if col in excluded or col.lower() in protected:
                continue
            non_null = df[col].dropna()
            if len(non_null) > 0 and non_null.nunique() <= 1:
                excluded.append(col)

        # Apply
        if excluded:
            df = df.drop(columns=[c for c in excluded if c in df.columns], errors="ignore")
            self._log("INFO", "MASTER", f"Excluded {len(excluded)} columns: {excluded[:8]}{'...' if len(excluded)>8 else ''}")

        return df, excluded

    # ─── MASTER TABLE BUILD ──────────────────────────────────────────
    def build_master(
        self, sources: Dict[str, pd.DataFrame]
    ) -> MasterBuildResult:
        """
        Build MASTER table from all sources per spec.
        
        7-Step Pipeline:
          1. Load BASE → MASTER_DF
          2. Scan & classify tables
          3. Process & join tabular tables (with rollup)
          4. Extract GRAPH_DATA (separate)
          5. Extract TEMPORAL_DATA (separate)
          6. Apply exclusions
          7. Generate outputs
        
        Args:
            sources: Dict of {table_name: DataFrame}
        
        Returns:
            MasterBuildResult with all outputs
        """
        result = MasterBuildResult(base_key=self.base_key)
        self.log = []

        # ── STEP 1: Load BASE ────────────────────────────────────────
        self._log("INFO", "PIPELINE", "Step 1: Loading BASE table")

        if "BASE" not in sources or sources["BASE"] is None or len(sources["BASE"]) == 0:
            result.error = "BASE table is MANDATORY but missing or empty. System cannot proceed."
            self._log("ERROR", "BASE", result.error)
            result.processing_log = self.log
            return result

        base_df = sources["BASE"].copy()

        # Validate BASE_KEY exists
        base_key_col = None
        cols_lower = {c.lower(): c for c in base_df.columns}
        for candidate in [self.base_key] + self.base_key_aliases:
            if candidate.lower() in cols_lower:
                base_key_col = cols_lower[candidate.lower()]
                break

        if base_key_col is None:
            result.error = f"BASE_KEY '{self.base_key}' not found in BASE table. Columns: {list(base_df.columns)[:10]}"
            self._log("ERROR", "BASE", result.error)
            result.processing_log = self.log
            return result

        # Normalize base_key name if needed
        actual_base_key = base_key_col
        result.base_key = actual_base_key

        master_df = base_df.drop_duplicates(subset=[actual_base_key]).copy()
        self._log("INFO", "BASE",
                  f"BASE loaded: {len(master_df)} entities, {len(master_df.columns)} columns, key='{actual_base_key}'")

        # ── STEP 2: Scan & classify ──────────────────────────────────
        self._log("INFO", "PIPELINE", "Step 2: Scanning & classifying tables")

        available = {}
        missing = []
        for table_name in TABULAR_TABLES + EXTRACT_TABLES:
            if table_name in sources and sources[table_name] is not None and len(sources[table_name]) > 0:
                available[table_name] = "TABULAR" if table_name in TABULAR_TABLES else "EXTRACT"
            else:
                missing.append(table_name)

        self._log("INFO", "PIPELINE",
                  f"Found {len(available)} tables, Missing {len(missing)} tables ({', '.join(missing[:5])}{'...' if len(missing)>5 else ''})")

        result.data_availability = {
            "base_loaded": True,
            "tables_found": list(available.keys()),
            "tables_missing": missing,
            "graph_available": "relationships_edges" in available,
            "temporal_available": "temporal_long" in available,
        }

        # ── STEP 3: Process & join tabular ───────────────────────────
        self._log("INFO", "PIPELINE", "Step 3: Processing & joining tabular tables")

        for table_name in TABULAR_TABLES:
            if table_name not in available:
                self._log("INFO", table_name, f"Skipping '{table_name}': not found")
                result.rollup_results.append(RollupResult(
                    table_name=table_name, strategy="SKIPPED", success=False,
                    message=f"Table not found — graceful skip"
                ))
                continue

            df = sources[table_name]
            rollup_result = self.rollup_table(df, table_name)
            result.rollup_results.append(rollup_result)

            if rollup_result.success and rollup_result.rolled_df is not None:
                # LEFT JOIN to MASTER
                rolled = rollup_result.rolled_df
                join_key = rollup_result.join_key

                n_before = len(master_df.columns)
                try:
                    # Remove columns from rolled that already exist in master (except join key)
                    existing = set(master_df.columns) - {actual_base_key}
                    keep_cols = [join_key] + [c for c in rolled.columns if c != join_key and c not in existing]
                    rolled_clean = rolled[keep_cols]

                    master_df = master_df.merge(
                        rolled_clean,
                        left_on=actual_base_key,
                        right_on=join_key,
                        how="left",
                        suffixes=("", f"_{table_name[:3]}")
                    )
                    # Drop duplicate join key column if different from base_key
                    if join_key != actual_base_key and join_key in master_df.columns:
                        master_df.drop(columns=[join_key], inplace=True, errors="ignore")

                    n_added = len(master_df.columns) - n_before
                    self._log("INFO", table_name, f"Joined to MASTER: +{n_added} columns")
                except Exception as e:
                    self._log("ERROR", table_name, f"Join error: {str(e)}")

        # ── STEP 4: Extract GRAPH_DATA ───────────────────────────────
        self._log("INFO", "PIPELINE", "Step 4: Extracting GRAPH_DATA")
        edges_key = "relationships_edges"
        nodes_key = "relationships_nodes"
        if edges_key in sources and sources[edges_key] is not None:
            result.graph_data = self.extract_graph_data(sources[edges_key], actual_base_key)
            # V20: If pre-built nodes table exists, use it directly
            if nodes_key in sources and sources[nodes_key] is not None and len(sources[nodes_key]) > 0:
                result.graph_data.nodes_df = sources[nodes_key].copy()
                result.graph_data.metadata["node_count"] = len(result.graph_data.nodes_df)
        else:
            result.graph_data = GraphData()
            self._log("INFO", "relationships", "GRAPH_DATA = None (not found)")

        # ── STEP 5: Extract TEMPORAL_DATA ────────────────────────────
        self._log("INFO", "PIPELINE", "Step 5: Extracting TEMPORAL_DATA")
        long_key = "temporal_long"
        wide_key = "temporal_wide"
        if long_key in sources and sources[long_key] is not None:
            result.temporal_data = self.extract_temporal_data(sources[long_key], actual_base_key)
            # V20: If pre-built wide table exists, use it directly
            if wide_key in sources and sources[wide_key] is not None and len(sources[wide_key]) > 0:
                result.temporal_data.wide_df = sources[wide_key].copy()
        else:
            result.temporal_data = TemporalData()
            self._log("INFO", "temporal", "TEMPORAL_DATA = None (not found)")

        # ── STEP 6: Apply exclusions ─────────────────────────────────
        self._log("INFO", "PIPELINE", "Step 6: Applying exclusions")
        master_df, excluded_cols = self.apply_exclusions(master_df, actual_base_key)

        # Fill NaN numeric with 0, round floats
        for col in master_df.columns:
            if master_df[col].dtype in [np.float64, np.float32, np.int64, np.int32]:
                master_df[col] = master_df[col].fillna(0)
        for col in master_df.select_dtypes(include=[np.floating]).columns:
            master_df[col] = master_df[col].round(2)

        # ── STEP 7: Generate outputs ─────────────────────────────────
        self._log("INFO", "PIPELINE", "Step 7: Generating outputs")

        result.master_df = master_df
        result.success = True

        # Data quality report
        for col in master_df.columns:
            null_pct = round(master_df[col].isnull().sum() / max(len(master_df), 1) * 100, 2)
            unique_count = master_df[col].nunique()
            dtype = str(master_df[col].dtype)

            # Detect source table
            source = "BASE"
            for t in TABULAR_TABLES:
                prefix = t[:4].lower()
                if col.startswith(f"{prefix}_"):
                    source = t
                    break

            result.data_quality.append({
                "feature": col,
                "dtype": dtype,
                "null_pct": null_pct,
                "unique_count": unique_count,
                "source_table": source,
            })

        result.processing_log = self.log

        self._log("INFO", "PIPELINE",
                  f"MASTER table complete: {len(master_df)} rows × {len(master_df.columns)} columns | "
                  f"Graph: {'Yes' if result.graph_data and result.graph_data.available else 'No'} | "
                  f"Temporal: {'Yes' if result.temporal_data and result.temporal_data.available else 'No'}")

        return result
