"""
L01 — Ingest & Merge (formerly Layer 1 & 2) — V19 Spec-Driven
============================================================
Multi-source data ingestion with validation, DQ scoring,
and spec-driven rollup-before-join pipeline.

V19 Enhancements:
  - RollupEngine integration for 4 strategies (DIRECT/AGGREGATE/TAKE_LATEST/AUTO_DETECT)
  - Config-driven join keys (TABLE_MAP) or auto-discovery with alias matching
  - Separate GRAPH_DATA & TEMPORAL_DATA extraction (NOT joined to MASTER)
  - 10 optional config file support with intelligent defaults
  - Handle completely missing tables and blank columns gracefully
  - BASE_KEY configurable (default: cust_id)

Sources: 12 tables (BASE mandatory + 11 optional)
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, Optional, Tuple, List, Any
from dataclasses import dataclass
from datetime import datetime
import json
import sys
import logging

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PATHS, LAYERS, DATA_SOURCES
from utils.memory import downcast_floats
from layers.rollup_engine import (
    RollupEngine, MasterBuildResult, GraphData, TemporalData,
    DEFAULT_BASE_KEY, DEFAULT_BASE_KEY_ALIASES, DEFAULT_GRAIN_CONFIG,
    TABULAR_TABLES, EXTRACT_TABLES,
)

logger = logging.getLogger("apurbadas.l1_l2_ingestion")


@dataclass
class DataQualityReport:
    """Data quality assessment results."""
    completeness: float
    consistency: float  
    validity: float
    overall_score: float
    issues: List[str]
    timestamp: str


class Layer1Ingestion:
    """
    Layer 1: Multi-source data ingestion — V19 Spec-Driven.
    
    Handles 12 table slots (BASE mandatory + 11 optional).
    Supports config-driven rollup-before-join pipeline.
    Extracts GRAPH_DATA and TEMPORAL_DATA separately.
    """
    
    def __init__(self):
        self.sources: Dict[str, pd.DataFrame] = {}
        self.configs: Dict[str, pd.DataFrame] = {}
        self.metadata: Dict[str, Dict] = {}
        self.base_df: Optional[pd.DataFrame] = None
        self.join_log: List[str] = []
        self.skip_log: List[str] = []
        self.base_key: str = DEFAULT_BASE_KEY
        self.base_key_aliases: List[str] = list(DEFAULT_BASE_KEY_ALIASES)
        self.grain_config: Dict = dict(DEFAULT_GRAIN_CONFIG)
        self._rollup_engine: Optional[RollupEngine] = None

    def load_config(self, config_name: str, data: pd.DataFrame) -> Tuple[bool, str]:
        """
        Load an optional config file.
        
        Supported configs: EXCLUDE, FEATURE_MAP, TABLE_MAP, METHOD_CONFIG,
        ALGO_FEATURE_MAP, FEATURE_STORE, METADATA, CUSTOM_CONFIG,
        TABLE_GRAIN_DETECTION, FEATURE_ENGINEERING
        """
        self.configs[config_name] = data
        
        # Parse TABLE_GRAIN_DETECTION to update grain config and base_key
        if config_name.upper() == "TABLE_GRAIN_DETECTION":
            self._parse_grain_detection(data)
        
        return True, f"Config '{config_name}' loaded: {len(data)} rows"

    def _parse_grain_detection(self, df: pd.DataFrame):
        """Parse TABLE_GRAIN_DETECTION config to extract grain and level settings."""
        cols_lower = {c.lower(): c for c in df.columns}
        
        # Check if it's the "level" sheet format (parameter/value)
        if "parameter" in cols_lower and "value" in cols_lower:
            param_col = cols_lower["parameter"]
            val_col = cols_lower["value"]
            for _, row in df.iterrows():
                param = str(row[param_col]).lower().strip()
                val = str(row[val_col]).strip()
                if param == "base_key":
                    self.base_key = val
                elif param == "base_key_alias":
                    self.base_key_aliases = [a.strip() for a in val.split(",")]
                elif param == "target_grain":
                    pass  # informational only
        
        # Check if it's the "grain" sheet format (table_name/rollup_strategy)
        if "table_name" in cols_lower and "rollup_strategy" in cols_lower:
            tn_col = cols_lower["table_name"]
            rs_col = cols_lower["rollup_strategy"]
            for _, row in df.iterrows():
                table = str(row[tn_col]).lower().strip()
                strategy = str(row[rs_col]).upper().strip()
                if table in self.grain_config:
                    self.grain_config[table]["rollup_strategy"] = strategy

    def _get_rollup_engine(self) -> RollupEngine:
        """Get or create the rollup engine with current config."""
        table_map = self.configs.get("TABLE_MAP")
        exclude_config = self.configs.get("EXCLUDE")
        
        self._rollup_engine = RollupEngine(
            base_key=self.base_key,
            base_key_aliases=self.base_key_aliases,
            grain_config=self.grain_config,
            table_map=table_map,
            exclude_config=exclude_config,
        )
        return self._rollup_engine
    
    def ingest_source(
        self, 
        source_name: str, 
        data: pd.DataFrame,
        validate: bool = True
    ) -> Tuple[bool, str]:
        """
        Ingest a single data source.
        
        Args:
            source_name: Name of source (kyc, transactions, alerts, cases)
            data: DataFrame to ingest
            validate: Whether to validate against schema
            
        Returns:
            Tuple of (success, message)
        """
        # Validate source config if it exists, otherwise allow dynamically
        key_column = None
        if source_name in DATA_SOURCES.SOURCES:
            config = DATA_SOURCES.SOURCES[source_name]
            key_column = config["key_column"]
            # Validate key column exists
            if validate and key_column not in data.columns:
                return False, f"Missing key column: {key_column}"
        
        # Store data
        self.sources[source_name] = data
        self.metadata[source_name] = {
            "rows": len(data),
            "columns": len(data.columns),
            "ingested_at": datetime.now().isoformat(),
            "key_column": key_column
        }
        
        return True, f"Ingested {len(data)} rows from {source_name}"
    
    def ingest_from_file(
        self, 
        source_name: str, 
        filepath: Path
    ) -> Tuple[bool, str]:
        """Ingest from file (CSV, Parquet, Excel)."""
        try:
            if filepath.suffix == '.csv':
                df = pd.read_csv(filepath)
            elif filepath.suffix == '.parquet':
                df = pd.read_parquet(filepath)
            elif filepath.suffix in ['.xlsx', '.xls']:
                df = pd.read_excel(filepath)
            else:
                return False, f"Unsupported format: {filepath.suffix}"
            
            # V15: float32 downcast — 50% memory reduction
            df = downcast_floats(df)
            
            return self.ingest_source(source_name, df)
            
        except Exception as e:
            return False, f"Ingestion error: {str(e)}"
    
    def merge_sources(self) -> pd.DataFrame:
        """
        Merge all ingested sources into unified dataset.
        
        Returns:
            Merged DataFrame with source indicators
        """
        if not self.sources:
            raise ValueError("No sources ingested")
        
        merged_parts = []
        
        for name, df in self.sources.items():
            # V15: Use assign() instead of copy() — avoids full DataFrame duplication
            merged_parts.append(df.assign(_source=name))
        
        # Concatenate all sources
        merged = pd.concat(merged_parts, ignore_index=True, sort=False)
        
        return merged
    
    def get_summary(self) -> Dict[str, Any]:
        """Get ingestion summary."""
        return {
            "sources_ingested": list(self.sources.keys()),
            "total_rows": sum(len(df) for df in self.sources.values()),
            "metadata": self.metadata,
            "tables_joined": self.join_log,
            "tables_skipped": self.skip_log
        }
    
    def auto_discover_and_join(
        self,
        data_directory: Path,
        base_df: pd.DataFrame,
        base_key: str = "cust_id"
    ) -> pd.DataFrame:
        """
        Auto-discover and join additional tables to BASE.
        
        V19: Uses RollupEngine for spec-driven rollup-before-join.
        
        Args:
            data_directory: Directory to scan for data files
            base_df: BASE DataFrame
            base_key: Key column in base (default: cust_id)
            
        Returns:
            Joined DataFrame (MASTER)
        """
        self.base_df = base_df.copy()
        self.base_key = base_key
        self.join_log = []
        self.skip_log = []
        
        engine = self._get_rollup_engine()
        
        # Scan directory for all data files
        supported_extensions = ['.csv', '.parquet', '.xlsx', '.xls']
        data_files = []
        
        for ext in supported_extensions:
            data_files.extend(data_directory.glob(f'*{ext}'))
        
        # Process each file
        for filepath in data_files:
            # Skip BASE file
            if 'base' in filepath.stem.lower():
                continue
                
            try:
                # Read file
                if filepath.suffix == '.csv':
                    full_df = pd.read_csv(filepath)
                elif filepath.suffix == '.parquet':
                    full_df = pd.read_parquet(filepath)
                elif filepath.suffix in ['.xlsx', '.xls']:
                    full_df = pd.read_excel(filepath)
                else:
                    continue
                
                # V15: float32 downcast
                full_df = downcast_floats(full_df)
                
                # Classify table
                table_name = filepath.stem.lower()
                
                # Check if it's an EXTRACT table (relationships/temporal)
                if any(kw in table_name for kw in ["relationship", "network", "graph"]):
                    log_msg = f"Extracted {filepath.name} to GRAPH_DATA (not joining to MASTER)"
                    self.skip_log.append(log_msg)
                    logger.info(log_msg)
                    continue
                    
                if any(kw in table_name for kw in ["temporal", "timeseries", "time_series"]):
                    log_msg = f"Extracted {filepath.name} to TEMPORAL_DATA (not joining to MASTER)"
                    self.skip_log.append(log_msg)
                    logger.info(log_msg)
                    continue
                
                # Rollup and join
                rollup_result = engine.rollup_table(full_df, table_name)
                
                if rollup_result.success and rollup_result.rolled_df is not None:
                    rolled = rollup_result.rolled_df
                    join_key = rollup_result.join_key
                    
                    n_cols_before = len(self.base_df.columns)
                    
                    # Remove columns from rolled that already exist in base
                    existing = set(self.base_df.columns) - {base_key}
                    keep_cols = [join_key] + [c for c in rolled.columns if c != join_key and c not in existing]
                    rolled_clean = rolled[keep_cols]
                    
                    self.base_df = self.base_df.merge(
                        rolled_clean,
                        left_on=base_key,
                        right_on=join_key,
                        how='left',
                        suffixes=('', f'_{filepath.stem}')
                    )
                    if join_key != base_key and join_key in self.base_df.columns:
                        self.base_df.drop(columns=[join_key], inplace=True, errors="ignore")
                    
                    n_new_cols = len(self.base_df.columns) - n_cols_before
                    log_msg = f"Joined {filepath.name} ({rollup_result.strategy}): +{n_new_cols} columns"
                    self.join_log.append(log_msg)
                    logger.info(log_msg)
                else:
                    log_msg = f"Skipping {filepath.name}: {rollup_result.message}"
                    self.skip_log.append(log_msg)
                    logger.warning(log_msg)
                    
            except Exception as e:
                log_msg = f"Error processing {filepath.name}: {str(e)}"
                self.skip_log.append(log_msg)
                logger.error(log_msg)
        
        return self.base_df

    def build_master_pipeline(
        self,
        sources: Dict[str, pd.DataFrame]
    ) -> MasterBuildResult:
        """
        V19: Full spec-driven MASTER build pipeline.
        
        7-Step Pipeline:
          1. Load configs & BASE
          2. Scan & classify tables
          3. Process & join tabular (with rollup)
          4. Extract GRAPH_DATA
          5. Extract TEMPORAL_DATA
          6. Apply exclusions
          7. Generate outputs
        
        Args:
            sources: Dict of {table_name: DataFrame}
        
        Returns:
            MasterBuildResult with MASTER_DF, GRAPH_DATA, TEMPORAL_DATA, logs
        """
        engine = self._get_rollup_engine()
        return engine.build_master(sources)
    
    def _detect_join_key(self, df: pd.DataFrame, base_key: str) -> Optional[str]:
        """
        Detect potential join key in DataFrame.
        
        V19: Delegates to RollupEngine's key discovery with full alias support.
        
        Priority:
        1. Exact match: "{base_key}" (e.g., "cust_id")
        2. Alias match: Any value in base_key_alias
        3. Suffix match: "*_{base_key}", "*_customer_id"
        4. NOT FOUND: Skip table with warning
        
        Args:
            df: DataFrame to inspect
            base_key: Key column to match against
            
        Returns:
            Detected column name or None
        """
        engine = self._get_rollup_engine()
        return engine.discover_join_key(df, "auto_detect")


class Layer2DataQuality:
    """
    Layer 2: Data Quality Assessment and Cleansing.
    
    Scores data on completeness, consistency, and validity.
    """
    
    def __init__(self):
        self.thresholds = LAYERS.DQ_THRESHOLDS
    
    def assess_quality(self, df: pd.DataFrame) -> DataQualityReport:
        """
        Perform comprehensive data quality assessment.
        
        Args:
            df: DataFrame to assess
            
        Returns:
            DataQualityReport with scores and issues
        """
        issues = []
        
        # Completeness: % of non-null values
        completeness = 1 - (df.isnull().sum().sum() / df.size)
        if completeness < self.thresholds["completeness"]:
            null_cols = df.columns[df.isnull().sum() > 0].tolist()
            issues.append(f"Low completeness in: {null_cols[:5]}")
        
        # Consistency: Check for duplicate keys and type consistency
        consistency = self._assess_consistency(df, issues)
        
        # Validity: Check for valid ranges and formats
        validity = self._assess_validity(df, issues)
        
        # Overall score (weighted average)
        overall = (completeness * 0.4 + consistency * 0.3 + validity * 0.3)
        
        return DataQualityReport(
            completeness=round(completeness, 4),
            consistency=round(consistency, 4),
            validity=round(validity, 4),
            overall_score=round(overall, 4),
            issues=issues,
            timestamp=datetime.now().isoformat()
        )
    
    def _assess_consistency(
        self, 
        df: pd.DataFrame, 
        issues: List[str]
    ) -> float:
        """Assess data consistency."""
        score = 1.0
        
        # Check for duplicates
        dup_ratio = df.duplicated().sum() / len(df) if len(df) > 0 else 0
        if dup_ratio > 0.01:
            issues.append(f"Duplicate rows: {dup_ratio:.1%}")
            score -= dup_ratio
        
        # Check mixed types in columns
        for col in df.columns:
            n_types = df[col].apply(type).nunique()
            if n_types > 2:  # Allow NaN + one type
                issues.append(f"Mixed types in {col}")
                score -= 0.05
        
        return max(0, score)
    
    def _assess_validity(
        self, 
        df: pd.DataFrame, 
        issues: List[str]
    ) -> float:
        """Assess data validity."""
        score = 1.0
        
        # Check numeric columns for outliers/invalid values
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        
        for col in numeric_cols:
            # Check for negative values in columns that shouldn't have them
            if 'amount' in col.lower() or 'count' in col.lower():
                neg_count = (df[col] < 0).sum()
                if neg_count > 0:
                    issues.append(f"Negative values in {col}: {neg_count}")
                    score -= 0.02
            
            # Check for infinity values
            if np.isinf(df[col].values).any():
                issues.append(f"Infinite values in {col}")
                score -= 0.05
        
        return max(0, score)
    
    def cleanse(
        self, 
        df: pd.DataFrame, 
        strategy: str = "moderate"
    ) -> pd.DataFrame:
        """
        Cleanse data based on DQ issues.
        
        Args:
            df: DataFrame to cleanse
            strategy: "minimal", "moderate", or "aggressive"
            
        Returns:
            Cleansed DataFrame
        """
        # V15: drop_duplicates directly (avoids redundant .copy())
        df_clean = df.drop_duplicates()
        
        # Handle missing values
        numeric_cols = df_clean.select_dtypes(include=[np.number]).columns
        
        if strategy == "minimal":
            # Only fill with column mean
            df_clean[numeric_cols] = df_clean[numeric_cols].fillna(
                df_clean[numeric_cols].mean()
            )
        elif strategy == "moderate":
            # Fill numeric with median, categorical with mode
            df_clean[numeric_cols] = df_clean[numeric_cols].fillna(
                df_clean[numeric_cols].median()
            )
            cat_cols = df_clean.select_dtypes(include=['object']).columns
            for col in cat_cols:
                mode = df_clean[col].mode()
                if len(mode) > 0:
                    df_clean[col] = df_clean[col].fillna(mode[0])
        else:  # aggressive
            # Drop rows with any nulls
            df_clean = df_clean.dropna()
        
        # Replace infinity with NaN then fill
        df_clean = df_clean.replace([np.inf, -np.inf], np.nan)
        df_clean = df_clean.fillna(df_clean.median(numeric_only=True))
        
        return df_clean


class IngestPipeline:
    """
    Combined Layer 1 + 2 pipeline.
    """
    
    def __init__(self):
        self.ingestion = Layer1Ingestion()
        self.dq = Layer2DataQuality()
        self.report: Optional[DataQualityReport] = None
    
    def run(
        self, 
        sources: Dict[str, pd.DataFrame],
        cleanse: bool = True,
        cleanse_strategy: str = "moderate"
    ) -> Tuple[pd.DataFrame, DataQualityReport]:
        """
        Run full ingestion pipeline.
        
        Args:
            sources: Dict of source_name -> DataFrame
            cleanse: Whether to cleanse data
            cleanse_strategy: Cleansing aggressiveness
            
        Returns:
            Tuple of (processed_df, dq_report)
        """
        # Ingest all sources
        for name, df in sources.items():
            success, msg = self.ingestion.ingest_source(name, df)
            if not success:
                raise ValueError(msg)
        
        # Merge sources
        merged = self.ingestion.merge_sources()
        
        # Assess quality
        self.report = self.dq.assess_quality(merged)
        
        # Cleanse if requested
        if cleanse:
            merged = self.dq.cleanse(merged, cleanse_strategy)
        
        return merged, self.report
