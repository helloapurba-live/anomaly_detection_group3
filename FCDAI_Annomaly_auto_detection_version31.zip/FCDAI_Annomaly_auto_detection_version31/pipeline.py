"""
AIM AI Vault — V30 Pipeline (L01–L14 Unified)
===============================================
Orchestrates 14 sequential layers (L01–L14) for end-to-end AML detection.

V27 Enhancements:
  - Global random seed (APP.RANDOM_SEED=42) for full reproducibility
  - Binary-column-aware scaling (skip StandardScaler on 0/1 columns)
  - Real SHAP explanations via TreeExplainer / KernelExplainer
  - Tier-2 persistence: feature importance, DQ metrics, model perf,
    method scores, graph centrality, method telemetry per run
  - What-If simulator connected to actual trained models

V26 Enhancements (retained):
  - Naming alignment: df_agg throughout pipeline.py, df_master in UI pages
  - Renamed fallback variable: df_fallback in pipeline_run.py

V14 Enhancements (retained):
  - Circuit breaker per detection method (graceful degradation)
  - Failed methods excluded from ensemble (not zero-filled)
  - cProfile pipeline profiling (optional)
  - Service layer integration (PipelineService façade)
  - Data contract validation on results

V13 Fixes (retained):
  - F-2: Sanitized error messages (no raw exception leak to UI/DB)
  - F-7: Pipeline status write safety
  - B-2/S-5: Parallel detection via ThreadPoolExecutor
  - B-5: Chunked _hash_dataframe (no O(n×m) memory spike)
  - B-6/S-2: Reduced DataFrame copies (memory optimized)

V13 (retained):
  - Role-based column resolution (zero hardcoded column names)
  - SchemaDetector wired before L4 (type-aware preprocessing)
  - AutoParamGenerator wired before L5 (data-driven parameters)
  - Per-method checkpointing (partial results saved)
  - Data lineage hashing + run versioning
  - Configurable ensemble flag threshold

Author: AIM AI Vault Team
"""

import pandas as pd
import numpy as np
import random
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
from dataclasses import dataclass, field
from datetime import datetime
import json
import time
import hashlib
import re
import sys
import gc
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.path.insert(0, str(Path(__file__).parent))

from config import PATHS, LAYERS, APP, RESOURCES, AUDIT, COLUMNS, CIRCUIT_BREAKER, DQ_PIPELINE, SCORING
from layers.l1_l2_ingestion import IngestPipeline, DataQualityReport
from layers.l3_feature_engineering import Layer3FeatureEngineering
from layers.l4_preprocessing import Layer4Preprocessing
from layers.l5_detection import Layer5Detection
from layers.l6_ensemble import Layer6Ensemble, EnsembleResult
from layers.l7_output import Layer7Output
from utils.customer_aggregation import CustomerAggregator
from utils.column_resolver import resolve, resolve_many
from utils.schema_detector import SchemaDetector
from utils.auto_params import AutoParamGenerator
from utils.circuit_breaker import cb_registry
from utils.shap_explainer import SHAPExplainer  # V27: Real SHAP explanations

# L02/L06–L10: DQ Pipeline engines
from utils.dq_validation import DQValidationEngine, DQValidationResult
from utils.dq_processing import DQProcessingEngine, DQProcessingResult
from utils.preprocessing_engine import PreprocessingEngine, PreprocessingResult
from utils.scaling_engine import ScalingEngine, ScalingResult
from utils.reduction_engine import ReductionEngine, ReductionResult
from utils.transformation_engine import TransformationEngine, TransformResult  # V28: Conditional transforms

import logging
_pipeline_logger = logging.getLogger('pipeline')


@dataclass
class PipelineResult:
    """Complete pipeline execution result."""
    success: bool
    timestamp: str
    records_processed: int
    dq_score: float
    features_generated: int
    methods_run: int
    alerts_generated: int
    tier_distribution: Dict[str, int]
    execution_time_ms: float
    df_scored: Optional[pd.DataFrame]
    ensemble_result: Optional[EnsembleResult]
    layer_timings: Dict[str, float] = field(default_factory=dict)
    error: Optional[str] = None
    run_id: Optional[str] = None           # V8: Run versioning
    input_hash: Optional[str] = None       # V8: Data lineage
    failed_methods: List[str] = field(default_factory=list)  # V14: Track failed methods
    circuit_breaker_skipped: List[str] = field(default_factory=list)  # V14: CB-skipped methods
    # L02/L06–L10: Pipeline results (serializable dicts for UI)
    dq_validation_dict: Dict[str, Any] = field(default_factory=dict)
    dq_processing_dict: Dict[str, Any] = field(default_factory=dict)
    preprocessing_dict: Dict[str, Any] = field(default_factory=dict)
    transform_dict: Dict[str, Any] = field(default_factory=dict)      # V28: Transform step
    scaling_dict: Dict[str, Any] = field(default_factory=dict)
    reduction_dict: Dict[str, Any] = field(default_factory=dict)


class ApurbaDasPipeline:
    """
    Main L01–L14 Pipeline Orchestrator.

    V14 pipeline features:
    - Circuit breaker per detection method (graceful degradation)
    - Failed methods excluded from ensemble (not zero-filled)
    - cProfile pipeline profiling (optional via PipelineService)
    - Data contracts on results

    V13 features (retained):
    - Column resolution via COLUMNS.resolve(), no COLUMN_ALIASES dict
    - SchemaDetector profiling before L4
    - AutoParamGenerator before L5
    - Checkpointing: save partial L5 results per-method
    - Data lineage: hash inputs, UUID per run
    - Parallel L5 detection (ThreadPoolExecutor)
    - Sanitized error messages (zero-leakage)
    - Memory-optimized DataFrame handling
    """

    def __init__(self):
        self.ingest = IngestPipeline()
        self.features = Layer3FeatureEngineering()
        self.preprocess = Layer4Preprocessing()
        self.detection = Layer5Detection()
        self.ensemble = Layer6Ensemble()
        self.output = Layer7Output()
        self.schema_detector = SchemaDetector()       # V8

        # L02/L06–L10 DQ Pipeline engines
        self.dq_validator = DQValidationEngine()
        self.dq_processor = DQProcessingEngine()
        self.preprocessing_engine = PreprocessingEngine()
        self.scaling_engine = ScalingEngine()
        self.reduction_engine = ReductionEngine()
        self.transformation_engine = TransformationEngine(
            skew_threshold=DQ_PIPELINE.SKEW_THRESHOLD
        )  # V28: Conditional transforms

        self.last_result: Optional[PipelineResult] = None
        self.df_processed: Optional[pd.DataFrame] = None

    @staticmethod
    def _sanitize_error(error_msg: str) -> str:
        """V13 F-2: Sanitize error message — strip paths, tracebacks, internals."""
        if not error_msg:
            return error_msg
        # Strip file paths (Windows/Linux)

        sanitized = re.sub(r'[A-Za-z]:\\[^\s"\']+',' [path-redacted] ', error_msg)
        sanitized = re.sub(r'/[\w/.-]+\.py', ' [path-redacted] ', sanitized)
        # Strip line numbers from tracebacks
        sanitized = re.sub(r', line \d+', '', sanitized)
        # Truncate to 200 chars max
        if len(sanitized) > 200:
            sanitized = sanitized[:200] + '...'
        return sanitized.strip()

    def _update_status(self, progress: int, stage: str, status: str = "running", error: str = None):
        """Update pipeline status file for UI polling. V13 F-7: Safe write."""
        # V13 F-2: Sanitize error before writing to disk
        safe_error = self._sanitize_error(error) if error else None
        status_data = {
            "status": status,
            "progress": progress,
            "stage": stage,
            "timestamp": datetime.now().isoformat(),
            "error": safe_error,
        }
        try:
            status_path = PATHS.DATA_VAULT / "pipeline_status.json"
            tmp_path = status_path.with_suffix('.tmp')
            with open(tmp_path, "w") as f:
                json.dump(status_data, f)
            tmp_path.replace(status_path)  # Atomic rename
        except Exception as exc:
            _pipeline_logger.warning(f"Status write failed: {type(exc).__name__}")

    # V13 B-5 FIX: Chunked hashing — avoids O(n×m) memory spike
    @staticmethod
    def _hash_dataframe(df: pd.DataFrame, chunk_size: int = 50_000) -> str:
        """Hash DataFrame in chunks to avoid memory spike on large datasets."""
        h = hashlib.new(AUDIT.HASH_ALGORITHM)
        n_rows = len(df)
        for start in range(0, n_rows, chunk_size):
            chunk = df.iloc[start:start + chunk_size]
            chunk_bytes = pd.util.hash_pandas_object(chunk).values.tobytes()
            h.update(chunk_bytes)
        return h.hexdigest()[:16]

    def run(
        self,
        sources: Dict[str, pd.DataFrame],
        detection_methods: List[str] = None,
        ensemble_method: str = "weighted_average",
        id_columns: List[str] = None,
        customer_col: str = None,
        amount_col: str = None,
        timestamp_col: str = None,
        merged_df: pd.DataFrame = None,
        reduction_path: int = None,
        missing_strategy: str = None,
        transform_mode: str = None,    # V28: auto/log/power/none
        target_dims: int = None,       # V28: Target dimensions for reduction
        primary_scaler: str = None,    # V28: Which scaler feeds reduction
        score_normalization: str = None,  # V31: Normalization method (auto default)
        score_fusion: str = None,         # V31: Fusion strategy (auto default)
        threshold_method: str = None,     # V31: Threshold calibration (auto default)
    ) -> PipelineResult:
        """
        Execute full L01–L14 pipeline.

        Column names are resolved via ColumnRoleConfig — callers no longer
        need to pass customer_col / amount_col / timestamp_col unless they
        want explicit overrides.
        """
        start_time = datetime.now()
        id_columns = id_columns or []
        layer_timings = {}
        input_hash = None

        # ── V27: Global reproducibility seed ──
        seed = APP.RANDOM_SEED
        np.random.seed(seed)
        random.seed(seed)
        try:
            import torch
            torch.manual_seed(seed)
        except ImportError:
            pass
        _pipeline_logger.info(f"[V27] Random seed set to {seed} for reproducibility")

        try:
            self._update_status(0, "Initializing", "running")

            # Filter out empty source DataFrames
            sources = {k: v for k, v in sources.items() if v is not None and not v.empty}
            if not sources and merged_df is None:
                raise ValueError("No non-empty source tables provided")

            # ============== L01: INGEST & MERGE ==============
            _pipeline_logger.info("[L01] Ingest & Merge...")
            self._update_status(10, "L01 — Ingest & Merge")
            t0 = time.time()

            if merged_df is not None and not merged_df.empty:
                # V13 B-6: Avoid unnecessary copy — ingest operates on the DF directly
                df_raw = merged_df
                dq_report = self.ingest.dq.assess_quality(df_raw)
                df_raw = self.ingest.dq.cleanse(df_raw, "moderate")
            else:
                df_raw, dq_report = self.ingest.run(sources)
            layer_timings["L01"] = time.time() - t0
            gc.collect()  # V15: Free ingestion intermediates

            # ============== L02: DQ VALIDATION ==============
            _pipeline_logger.info("[L02] DQ Validation (6-step gate)...")
            self._update_status(15, "L02 — DQ Validation")
            t0_m1 = time.time()
            dq_validation_dict = {}
            try:
                dq_val_result = self.dq_validator.validate(df_raw)
                dq_validation_dict = self.dq_validator.scorecard_to_dict(dq_val_result)
                _pipeline_logger.info(f"   [L02] DQ Score: {dq_val_result.dq_score:.1%} — {'PASS' if dq_val_result.passed else 'FAIL (override allowed)'}")
            except Exception as m1_err:
                _pipeline_logger.warning(f"   [L02] DQ Validation failed: {type(m1_err).__name__}: {m1_err}")
            layer_timings["L02"] = time.time() - t0_m1

            # V8: Data lineage — hash the input
            if AUDIT.ENABLE_DATA_LINEAGE:
                input_hash = self._hash_dataframe(df_raw)
                _pipeline_logger.info(f"   [LINEAGE] Input hash: {input_hash}")

            # ── V8: Role-based column resolution ──
            resolved = resolve_many(df_raw, ["primary_key", "amount", "timestamp"])
            customer_col = customer_col or resolved.get("primary_key")
            amount_col = amount_col or resolved.get("amount")
            timestamp_col = timestamp_col or resolved.get("timestamp")

            _pipeline_logger.info(f"   [RESOLVE] customer={customer_col}, amount={amount_col}, timestamp={timestamp_col}")

            # ============== V6: CUSTOMER AGGREGATION ==============
            # V25: df_raw → df_agg (aggregated to customer level)
            df_agg = df_raw  # Default: no aggregation, pass through
            if APP.CUSTOMER_LEVEL_PROCESSING and customer_col and customer_col in df_raw.columns:
                _pipeline_logger.info("[L03] Customer-Level Aggregation...")
                self._update_status(20, "L03 — Customer Aggregation")
                t0 = time.time()

                aggregator = CustomerAggregator(customer_col=customer_col)
                df_agg = aggregator.aggregate(
                    df_transactions=df_raw,
                    amount_col=amount_col if amount_col and amount_col in df_raw.columns else None,
                    timestamp_col=timestamp_col if timestamp_col and timestamp_col in df_raw.columns else None,
                    type_col=resolve(df_raw, "txn_type"),
                )

                layer_timings["L03"] = time.time() - t0
                _pipeline_logger.info(f"   [INFO] Aggregated to {len(df_agg)} customers with {len(aggregator.aggregation_features)} features")

            # ============== L04: FEATURE ENGINEERING ==============
            # df_agg → df_features (+20 engineered features)
            _pipeline_logger.info("[L04] Feature Engineering...")
            self._update_status(30, "L04 — Feature Engineering")
            t0 = time.time()
            try:
                df_features = self.features.engineer_features(
                    df_agg,
                    customer_col=customer_col if customer_col and customer_col in df_agg.columns else None,
                    amount_col=amount_col if amount_col and amount_col in df_agg.columns else None,
                    timestamp_col=timestamp_col if timestamp_col and timestamp_col in df_agg.columns else None,
                )
            except TypeError:
                df_features = self.features.engineer_features(df_agg)
            layer_timings["L04"] = time.time() - t0
            gc.collect()  # V15: Free feature engineering intermediates

            # ── Load exclude variables (if configured via Data Sources) ──
            exclude_path = PATHS.DATA_VAULT / "exclude_vars.json"
            if exclude_path.exists():
                try:
                    with open(exclude_path, "r") as f:
                        exclude_vars = json.load(f)
                    cols_to_drop = [c for c in exclude_vars if c in df_features.columns]
                    if cols_to_drop:
                        df_features = df_features.drop(columns=cols_to_drop)
                        _pipeline_logger.info(f"   [INFO] Excluded {len(cols_to_drop)} variables: {cols_to_drop[:5]}...")
                except Exception:
                    pass

            # ============== L05: SCHEMA DETECTION + AUTO-PARAMETERS ==============
            _pipeline_logger.info("[L05] Schema Detection...")
            self._update_status(40, "L05 — Schema Detection")
            t0 = time.time()
            schema_profiles = self.schema_detector.detect_schema(df_features)
            usable_cols = self.schema_detector.get_usable_columns(schema_profiles)
            _pipeline_logger.info(f"   [SCHEMA] {len(usable_cols)} usable / {len(schema_profiles)} total columns")
            layer_timings["L05"] = time.time() - t0

            # ============== L06–L10: DQ → ENCODE → TRANSFORM → SCALE → REDUCE ==============
            # L06 DQ Processing → L07 Encoding → L08 Transformation → L09 Scaling → L10 Reduction
            # Falls back to legacy preprocessing if any layer fails.
            dq_processing_dict = {}
            preprocessing_dict = {}
            transform_dict = {}       # V28
            scaling_dict = {}
            reduction_dict = {}
            v24_pipeline_ok = False

            try:
                # --- L06: DQ PROCESSING (12-step cleanse) ---
                # df_features → df_cleaned (12-step DQ cleanse)
                _pipeline_logger.info("[L06] DQ Processing (12-step cleanse)...")
                self._update_status(42, "L06 — DQ Processing")
                t0_m2 = time.time()
                m2_result = self.dq_processor.process(df_features)
                df_cleaned = m2_result.cleaned_df if m2_result.cleaned_df is not None else df_features
                dq_processing_dict = {
                    "step_log": m2_result.step_log,
                    "columns_dropped": m2_result.columns_dropped,
                    "columns_renamed": m2_result.columns_renamed,
                    "shape_before": list(m2_result.shape_before),
                    "shape_after": list(m2_result.shape_after),
                    "summary": m2_result.summary.to_dict("records") if m2_result.summary is not None and hasattr(m2_result.summary, 'to_dict') else [],
                    "data_type_map": m2_result.data_type_map,
                }
                layer_timings["L06"] = time.time() - t0_m2
                _pipeline_logger.info(f"   [L06] {m2_result.shape_before} → {m2_result.shape_after}, dropped {len(m2_result.columns_dropped)} cols")

                # --- L07: ENCODING ENGINE (encode to numeric) ---
                # df_cleaned → df_encoded (100% float, all-numeric)
                _pipeline_logger.info("[L07] Encoding Engine (encode to numeric)...")
                self._update_status(46, "L07 — Encoding")
                t0_m3 = time.time()
                strategy = missing_strategy or "ZERO"
                self.preprocessing_engine = PreprocessingEngine(
                    missing_strategy=strategy,
                    datetime_cols=m2_result.datetime_cols_extracted,
                )
                m3_result = self.preprocessing_engine.preprocess(df_cleaned, m2_result.data_type_map)
                df_encoded = m3_result.encoded_master
                preprocessing_dict = {
                    "shape_before": list(m3_result.shape_before),
                    "shape_after": list(m3_result.shape_after),
                    "encoding_map": m3_result.encoding_map,
                    "missing_treatment": m3_result.missing_treatment,
                    "step_log": m3_result.step_log,
                    "columns_before": m3_result.columns_before_encode,
                    "columns_after": m3_result.columns_after_encode,
                }
                layer_timings["L07"] = time.time() - t0_m3
                _pipeline_logger.info(f"   [L07] EncodedMaster: {m3_result.shape_after}, {len(m3_result.encoding_map)} cols encoded")

                if df_encoded is None or df_encoded.empty:
                    raise ValueError("L07 Encoding produced empty EncodedMaster")

                # --- L08: CONDITIONAL TRANSFORMATION ---
                # df_encoded → df_transformed (conditional log/power per column)
                _pipeline_logger.info("[L08] Conditional Transformation Engine...")
                self._update_status(47, "L08 — Transformation")
                t0_m35 = time.time()
                t_mode = transform_mode or DQ_PIPELINE.TRANSFORM_DEFAULT
                m35_result = self.transformation_engine.transform(df_encoded, mode=t_mode)
                df_transformed = m35_result.df_transformed
                transform_dict = {
                    "mode": t_mode,
                    "shape_before": list(df_encoded.shape),
                    "shape_after": list(df_transformed.shape),
                    "columns_log_transformed": m35_result.columns_log_transformed,
                    "columns_power_transformed": m35_result.columns_power_transformed,
                    "skew_before": {k: round(v, 3) for k, v in list(m35_result.skew_before.items())[:20]},
                    "skew_after": {k: round(v, 3) for k, v in list(m35_result.skew_after.items())[:20]},
                    "step_log": m35_result.step_log,
                }
                layer_timings["L08"] = time.time() - t0_m35
                _pipeline_logger.info(
                    f"   [L08] Transform mode={t_mode}: "
                    f"{len(m35_result.columns_log_transformed)} log, "
                    f"{len(m35_result.columns_power_transformed)} power"
                )

                # --- L09: 6-WAY SCALING ---
                # df_transformed → X_scaled (6 scaled numpy matrices)
                _pipeline_logger.info("[L09] 6-Way Scaling Engine...")
                self._update_status(48, "L09 — Scaling")
                t0_m4 = time.time()
                m4_result = self.scaling_engine.scale(df_transformed)  # V28: scale transformed data
                scaling_dict = {
                    "step_log": m4_result.step_log,
                    "scaler_stats": m4_result.scaler_stats,
                    "input_shape": list(m4_result.input_shape),
                    "feature_names": m4_result.feature_names,
                }
                layer_timings["L09"] = time.time() - t0_m4
                _pipeline_logger.info(f"   [L09] {len(m4_result.scaled_matrices)} scalers applied, input {m4_result.input_shape}")

                # --- L10: DIMENSION REDUCTION ---
                # X_scaled → X_reduced (dimensionally reduced numpy array)
                _pipeline_logger.info("[L10] Dimension Reduction Engine...")
                self._update_status(50, "L10 — Reduction")
                t0_m5 = time.time()
                red_path = int(reduction_path) if reduction_path else 1  # Default: no reduction
                # Use selected scaler matrix for reduction (V28: user-configurable)
                # When "Auto", use StandardScaler for reduction (most common base)
                scaler_key = "StandardScaler" if (primary_scaler or "Auto") == "Auto" else primary_scaler
                X_scaled = m4_result.scaled_matrices.get(scaler_key)
                if X_scaled is None:
                    # Fallback: try StandardScaler, then first available
                    X_scaled = m4_result.scaled_matrices.get("StandardScaler")
                    if X_scaled is None:
                        X_scaled = next(iter(m4_result.scaled_matrices.values()))
                    _pipeline_logger.warning(f"   [L10] Scaler '{scaler_key}' not found, fell back")
                m5_result = self.reduction_engine.reduce(
                    X_scaled,
                    feature_names=m4_result.feature_names,
                    path=red_path,
                    encoding_map=m3_result.encoding_map,
                    target_dims=target_dims,  # V28: User-specified target dimensions
                )
                reduction_dict = {
                    "path_used": m5_result.path_used,
                    "path_name": m5_result.path_name,
                    "dims_before": m5_result.dims_before,
                    "dims_after": m5_result.dims_after,
                    "explained_variance": m5_result.explained_variance,
                    "agent_selection": m5_result.agent_selection,
                    "step_log": m5_result.step_log,
                }
                # Use PreMaster as the detection input
                if m5_result.premaster is not None and not m5_result.premaster.empty:
                    X_reduced = m5_result.premaster.values
                else:
                    X_reduced = X_scaled
                layer_timings["L10"] = time.time() - t0_m5
                _pipeline_logger.info(f"   [L10] Path {m5_result.path_used} ({m5_result.path_name}): {m5_result.dims_before}→{m5_result.dims_after} dims")

                v24_pipeline_ok = True
                layer_timings["L06_L10"] = sum(layer_timings.get(k, 0) for k in ["L06", "L07", "L08", "L09", "L10"])
                gc.collect()

            except Exception as v24_err:
                _pipeline_logger.warning(f"   [L06-L10] Pipeline failed ({type(v24_err).__name__}: {v24_err}), falling back to legacy preprocessing")
                # FALLBACK: Use legacy preprocessing
                self._update_status(50, "Preprocessing (fallback)")
                t0 = time.time()
                all_id_cols = id_columns.copy()
                if '_source' in df_features.columns:
                    all_id_cols.append('_source')
                for col in df_features.columns:
                    if col not in usable_cols and col not in all_id_cols:
                        all_id_cols.append(col)
                matrices = self.preprocess.preprocess(df_features, id_columns=all_id_cols)
                X_reduced = matrices.get('scaled', matrices.get('raw'))
                layer_timings["L06_L10"] = time.time() - t0
                gc.collect()

            if detection_methods is None:
                detection_methods = []
                for methods in LAYERS.DETECTION_METHODS.values():
                    detection_methods.extend(methods)

            # Smart Algorithm Selection: Disable heavy methods for large datasets
            rows = len(df_features)
            max_heavy = RESOURCES.MAX_ROWS_FOR_HEAVY_METHODS
            if rows > max_heavy:
                original_count = len(detection_methods)
                detection_methods = [
                    m for m in detection_methods
                    if m not in LAYERS.HEAVY_METHODS
                ]
                new_count = len(detection_methods)
                if original_count > new_count:
                    msg = f"Data size ({rows}) > {max_heavy}. Disabled {original_count - new_count} heavy algorithms."
                    _pipeline_logger.warning(f"   [WARN] {msg}")

            # ============== L05b: AUTO-PARAMETER GENERATION ==============
            _pipeline_logger.info("[L05b] Auto-Parameter Generation...")
            self._update_status(60, "L05b — Auto-Parameters")
            t0 = time.time()
            n_samples, n_features = X_reduced.shape
            auto_params = AutoParamGenerator.generate_all(n_samples, n_features)
            layer_timings["L05b"] = time.time() - t0
            _pipeline_logger.info(f"   [PARAMS] Generated params for {len(auto_params)} methods (n={n_samples}, f={n_features})")

            # ============== L11: DETECTION (Circuit Breaker + Parallel) ==============
            _pipeline_logger.info(f"[L11] Detection ({len(detection_methods)} methods)...")
            self._update_status(70, f"L11 — Detection ({len(detection_methods)} methods)")
            t0 = time.time()

            # V14: Filter out circuit-breaker-OPEN methods
            cb_skipped = []
            active_methods = []
            if CIRCUIT_BREAKER.ENABLED:
                for m in detection_methods:
                    cb = cb_registry.get(f"l5_{m}")
                    if cb.can_execute():
                        active_methods.append(m)
                    else:
                        cb_skipped.append(m)
                        _pipeline_logger.info(f"   [CB] {m}: circuit OPEN — skipped")
            else:
                active_methods = detection_methods

            # V13 B-2/S-5: Use ThreadPoolExecutor for parallel method execution
            # Note: GIL-limited but NumPy releases GIL for C-level ops
            max_workers = min(4, max(1, len(active_methods) // 4))

            # ── V28 AUTO-ROUTING: per-algorithm scaler selection ─────────
            if primary_scaler == "Auto":
                from utils.algorithm_routing import get_preprocessing_config as _get_pp

                # Scale the ORIGINAL (pre-transform) data so that no-transform
                # algorithms get a matrix that was never LOG'd.
                _pipeline_logger.info("   [V28-AUTO] Scaling original (pre-transform) data for routing…")
                df_original_for_scaling = pd.DataFrame(
                    m35_result.df_original.values,
                    columns=m4_result.feature_names,
                )
                m4_raw = ScalingEngine().scale(df_original_for_scaling)

                # Group methods by (needs_transform?, scaler_key)
                method_groups: Dict[tuple, list] = {}
                for _m in active_methods:
                    _pp = _get_pp(_m)
                    _key = (_pp["transform"] is not None, _pp["scaler"] or "Original")
                    method_groups.setdefault(_key, []).append(_m)

                group_summary = ", ".join(
                    f"{sk}({'LOG' if tf else 'RAW'})={len(ms)}"
                    for (tf, sk), ms in method_groups.items()
                )
                _pipeline_logger.info(f"   [V28-AUTO] {len(method_groups)} scaler groups: {group_summary}")

                self.detection.results = {}
                self.detection.models = {}

                for (needs_tf, scaler_key), group_methods in method_groups.items():
                    # Pick the right pre-computed matrix
                    if needs_tf:
                        # LOG + Scale  →  use m4_result (scaled on df_transformed)
                        if scaler_key == "StandardScaler" and m5_result.premaster is not None and not m5_result.premaster.empty:
                            # StandardScaler group can benefit from M5 reduction
                            X_group = m5_result.premaster.values
                        else:
                            X_group = m4_result.scaled_matrices.get(
                                scaler_key,
                                m4_result.scaled_matrices.get("StandardScaler", X_reduced),
                            )
                    else:
                        # No transform  →  use m4_raw (scaled on df_original)
                        X_group = m4_raw.scaled_matrices.get(
                            scaler_key,
                            m4_raw.scaled_matrices.get("Original", X_reduced),
                        )

                    X_group = np.nan_to_num(
                        np.asarray(X_group, dtype=np.float32), nan=0.0, posinf=0.0, neginf=0.0
                    )
                    _pipeline_logger.info(
                        f"   [V28-AUTO]  → {scaler_key}({'LOG' if needs_tf else 'RAW'}): "
                        f"{len(group_methods)} methods, shape={X_group.shape}"
                    )
                    self.detection.detect_all(X_group, methods=group_methods)

                results = self.detection.results

            else:
                # ── Original single-scaler flow ──
                if max_workers > 1 and len(active_methods) >= 8:
                    _pipeline_logger.info(f"   [L11] Parallel execution with {max_workers} workers")
                    results = self.detection.detect_all_parallel(
                        X_reduced, methods=active_methods, max_workers=max_workers
                    )
                else:
                    results = self.detection.detect_all(X_reduced, methods=active_methods)

            # V14: Record circuit breaker outcomes
            failed_methods = []
            for method_name, det_result in self.detection.results.items():
                cb = cb_registry.get(f"l5_{method_name}")
                if det_result.scores.max() < 1e-10 and det_result.labels.sum() == 0:
                    # Likely a failure (all zeros) — record failure
                    cb.record_failure("zero-output")
                    failed_methods.append(method_name)
                else:
                    cb.record_success()

            # V14: Exclude failed methods from ensemble if configured
            if CIRCUIT_BREAKER.EXCLUDE_FROM_ENSEMBLE and failed_methods:
                for fm in failed_methods:
                    if fm in self.detection.results:
                        del self.detection.results[fm]
                _pipeline_logger.info(f"   [CB] Excluded {len(failed_methods)} failed methods from ensemble")

            score_matrix, method_names = self.detection.get_score_matrix()
            # V27: Store for Tier 2 persistence access
            self._last_score_matrix = score_matrix
            self._last_method_names = method_names
            layer_timings["L11"] = time.time() - t0
            gc.collect()  # V15: Free detection intermediates (26 detector objects)

            # V8: Checkpoint — save partial L5 results
            try:
                checkpoint_path = PATHS.DATA_VAULT / "l5_checkpoint.json"
                checkpoint = {
                    "methods_run": method_names,
                    "n_samples": int(n_samples),
                    "timestamp": datetime.now().isoformat(),
                }
                with open(checkpoint_path, "w") as f:
                    json.dump(checkpoint, f, indent=2, default=str)
            except Exception:
                pass

            # ============== L12: SHAP EXPLANATIONS ==============
            _pipeline_logger.info("[L12] Computing SHAP explanations...")
            self._update_status(82, "L12 — SHAP Explanations")
            t0_shap = time.time()
            try:
                shap_explainer = SHAPExplainer(max_samples=200)
                feature_names_shap = list(self.features.feature_columns) if hasattr(self.features, 'feature_columns') else None
                shap_results = shap_explainer.explain_all_methods(
                    detection_layer=self.detection,
                    X=X_reduced,
                    feature_names=feature_names_shap,
                )
                # Serialize and save to data vault
                shap_output = {}
                for m_name, s_result in shap_results.items():
                    shap_output[m_name] = s_result.to_dict()
                    # Add summary plot data
                    shap_output[m_name]["summary_plot"] = shap_explainer.get_summary_plot_data(m_name)
                shap_path = PATHS.DATA_VAULT / "shap_results.json"
                with open(shap_path, "w") as f:
                    json.dump(shap_output, f, indent=2, default=str)
                _pipeline_logger.info(f"   [SHAP] Computed for {len(shap_results)} methods, saved to {shap_path}")
            except Exception as e:
                _pipeline_logger.warning(f"   [SHAP] Non-fatal error: {type(e).__name__}: {e}")
            layer_timings["L12"] = time.time() - t0_shap

            # ============== L13: ENSEMBLE FUSION (V31: 3-stage scoring) ==============
            _pipeline_logger.info("[L13] Ensemble Fusion (V31 Scoring Pipeline)...")
            self._update_status(85, "L13 — Ensemble Fusion")
            t0 = time.time()
            self.ensemble.method = ensemble_method
            # V31: Use 3-stage scoring pipeline when available
            _norm = score_normalization or "auto"
            _fuse = score_fusion or "auto"
            _thresh = threshold_method or "auto"
            _pipeline_logger.info(f"   V31 scoring: norm={_norm}, fusion={_fuse}, threshold={_thresh}")
            ensemble_result = self.ensemble.fuse_v31(
                score_matrix, method_names,
                normalization=_norm,
                fusion=_fuse,
                threshold=_thresh,
            )
            layer_timings["L13"] = time.time() - t0
            gc.collect()  # V15: Free ensemble intermediates

            # ============== L14: OUTPUT & ALERTS ==============
            _pipeline_logger.info("[L14] Output & Alerts...")
            self._update_status(95, "L14 — Output & Alerts")
            t0 = time.time()
            output_summary = self.output.process(
                df_features,
                ensemble_result.final_scores,
                ensemble_result.risk_tiers,
                score_matrix,
                method_names,
            )
            layer_timings["L14"] = time.time() - t0

            # ============== CREATE SCORED DATAFRAME (V25: Explicit copy) ==============
            # V25: df_features → df_scored (final output with anomaly scores + risk tiers)
            df_scored = df_features.copy()
            df_scored['anomaly_score'] = ensemble_result.final_scores
            df_scored['risk_tier'] = ensemble_result.risk_tiers

            for i, method in enumerate(method_names):
                df_scored[f'score_{method}'] = score_matrix[:, i]

            self.df_processed = df_scored

            execution_time = (datetime.now() - start_time).total_seconds() * 1000

            self.last_result = PipelineResult(
                success=True,
                timestamp=start_time.isoformat(),
                records_processed=len(df_features),
                dq_score=dq_report.overall_score,
                features_generated=len(self.features.feature_columns),
                methods_run=len(method_names),
                alerts_generated=output_summary['alerts_generated'],
                tier_distribution=ensemble_result.tier_counts,
                execution_time_ms=execution_time,
                df_scored=df_scored,
                ensemble_result=ensemble_result,
                layer_timings=layer_timings,
                run_id=None,
                input_hash=input_hash,
                failed_methods=failed_methods,
                circuit_breaker_skipped=cb_skipped,
                dq_validation_dict=dq_validation_dict,
                dq_processing_dict=dq_processing_dict,
                preprocessing_dict=preprocessing_dict,
                transform_dict=transform_dict,
                scaling_dict=scaling_dict,
                reduction_dict=reduction_dict,
            )

            _pipeline_logger.info(f"\n=== Pipeline complete in {execution_time:.0f}ms ===")
            _pipeline_logger.info(f"   Records: {len(df_features):,}")
            _pipeline_logger.info(f"   Alerts: {output_summary['alerts_generated']:,}")
            for layer, elapsed in layer_timings.items():
                _pipeline_logger.info(f"   {layer}: {elapsed:.2f}s")

            self._update_status(100, "Pipeline Complete", "completed")
            return self.last_result

        except Exception as e:
            # V13 F-2: Sanitize error — only expose error TYPE, not raw internals
            safe_error = self._sanitize_error(f"{type(e).__name__}: {str(e)}")
            self._update_status(0, "Failed", "failed", safe_error)
            _pipeline_logger.error(f"Pipeline failed: {type(e).__name__}: {e}", exc_info=True)
            execution_time = (datetime.now() - start_time).total_seconds() * 1000

            return PipelineResult(
                success=False,
                timestamp=start_time.isoformat(),
                records_processed=0,
                dq_score=0.0,
                features_generated=0,
                methods_run=0,
                alerts_generated=0,
                tier_distribution={},
                execution_time_ms=execution_time,
                df_scored=None,
                ensemble_result=None,
                layer_timings=layer_timings,
                error=safe_error,
            )

    def run_single_source(
        self,
        df: pd.DataFrame,
        source_name: str = "transactions",
        **kwargs,
    ) -> PipelineResult:
        """Convenience method for single source."""
        return self.run({source_name: df}, **kwargs)

    def get_alerts(
        self,
        tier: str = None,
        limit: int = 100,
    ) -> List[Dict]:
        """Get generated alerts."""
        alerts = self.output.queue.get_queue(tier=tier)[:limit]
        return [
            {
                "alert_id": a.alert_id,
                "record_index": a.record_index,
                "risk_score": a.risk_score,
                "risk_tier": a.risk_tier,
                "status": a.status,
                "narrative": a.narrative,
            }
            for a in alerts
        ]

    def get_layer_summaries(self) -> Dict:
        """Get summary from each layer."""
        return {
            "L01": self.ingest.ingestion.get_summary() if hasattr(self.ingest, 'ingestion') else {},
            "L04": self.features.get_feature_summary(),
            "L06_L10": self.preprocess.get_summary(),
            "L11": self.detection.get_summary(),
            "L13": self.ensemble.get_summary(self.last_result.ensemble_result) if self.last_result else {},
            "L14": {
                "queue": self.output.queue.get_summary(),
                "audit": self.output.audit.get_summary(),
            },
        }

    def save_results(self, path: Path = None):
        """Save scored results to parquet."""
        if self.df_processed is None:
            return None

        path = path or PATHS.DATA_VAULT / "scored.parquet"
        self.df_processed.to_parquet(path, index=False)
        return path

    def export_alerts_excel(self, path: Path = None):
        """Export alerts to Excel."""
        if not self.output.queue.alerts:
            return None

        path = path or PATHS.EXPORTS / f"alerts_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"

        alerts_data = []
        for a in self.output.queue.alerts.values():
            alerts_data.append({
                "Alert ID": a.alert_id,
                "Record Index": a.record_index,
                "Risk Score": a.risk_score,
                "Risk Tier": a.risk_tier,
                "Status": a.status,
                "Created": a.created_at,
                "Top Method 1": a.top_contributors[0]['method'] if a.top_contributors else "",
                "Top Method 1 Score": a.top_contributors[0]['score'] if a.top_contributors else 0,
            })

        df_alerts = pd.DataFrame(alerts_data)
        df_alerts.to_excel(path, index=False)

        return path


# Quick run function
def run_pipeline(df: pd.DataFrame, **kwargs) -> PipelineResult:
    """Quick run of the full pipeline."""
    pipeline = ApurbaDasPipeline()
    return pipeline.run_single_source(df, **kwargs)
