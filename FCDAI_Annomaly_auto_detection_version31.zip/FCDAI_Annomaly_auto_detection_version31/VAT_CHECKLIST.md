# Project ApurbaDas V9 — Comprehensive VAT Plan
## Validation · Audit · Testing

> **Generated**: Pre-release audit for FCDAI Anomaly Auto-Detection V9  
> **Scope**: 7-Layer Pipeline, 26 Detection Methods, 13 Pages, 12 Table Slots  
> **Framework**: Dash 3.4.0 + DMC 2.5.1 + AG Grid 33.3.3 (air-gapped, CPU-only)

---

## Section 1: Functional & UI/UX Validation

### 1.1 Multi-Page Routing & Navigation

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 1.1.1 | All 13 pages load without blank render | ☐ | Prior MATCH→ALL fix; re-verify after V9 changes |
| 1.1.2 | `dcc.Location` URL routing: `/`, `/sources`, `/pipeline`, `/explainability`, `/audit`, `/investigation`, `/admin`, `/config`, `/layers`, `/diagnostics`, `/narratives`, `/audit-vault` all resolve | ☐ | `use_pages=True` in app.py |
| 1.1.3 | Nav sidebar links correctly navigate (no 404) | ☐ | |
| 1.1.4 | Browser back/forward retains correct page state | ☐ | |
| 1.1.5 | Deep-linking (paste URL directly) loads correct page | ☐ | |
| 1.1.6 | Cross-page navigation links (Dashboard → Sources, Pipeline → Sources) work | ☐ | `dcc.Link(href="/sources")` in dashboard.py, pipeline_run.py |

### 1.2 State Persistence & Cross-Page Sync

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 1.2.1 | DataVault `reload_from_disk()` syncs across pages | ☐ | Singleton `data_vault` instance in data_io.py |
| 1.2.2 | Generated data persists after page navigation | ☐ | vault/sources/*.parquet |
| 1.2.3 | Pipeline results persist after refresh (`pipeline_result.json`) | ☐ | |
| 1.2.4 | Scored data loads correctly on Dashboard after pipeline run | ☐ | `scored.parquet` |
| 1.2.5 | metadata.json import_time and column_list survive refresh | ☐ | |
| 1.2.6 | `dcc.Store` data does NOT exceed 5MB JSON limit per store | ☐ | Critical for large datasets |
| 1.2.7 | Clear Cache on Dashboard removes vault files AND UI reflects empty | ☐ | `clear_data()` in data_io.py |

### 1.3 Callback Efficiency & Correctness

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 1.3.1 | NO `MATCH` pattern callbacks anywhere (Dash 3.4.0 bug) | ☐ | grep for `MATCH` — must be zero results |
| 1.3.2 | `suppress_callback_exceptions=True` — verify no hidden callback errors | ☐ | **RISK**: silently swallows errors; test each callback manually |
| 1.3.3 | Pipeline run callback does NOT block the UI thread | ☐ | Check if `@callback(background=True)` or `dcc.Interval` polling used |
| 1.3.4 | Interval-based refresh (5000ms) on dashboard doesn't cause memory leak | ☐ | `dcc.Interval` + DataVault reload |
| 1.3.5 | File upload callback (`dcc.Upload`) handles malformed files gracefully | ☐ | `_validate_data()` in data_io.py |
| 1.3.6 | Confirm button only enables when actual data sources exist | ☐ | `update_execution_info` callback |
| 1.3.7 | Data generation → auto-switch to sample mode works end-to-end | ☐ | |

### 1.4 Component Interactivity

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 1.4.1 | AG Grid pagination works (10, 20, 50, 100 rows per page) | ☐ | `paginationPageSizeSelector: [10, 20, 50, 100]` |
| 1.4.2 | AG Grid column sort and filter function | ☐ | |
| 1.4.3 | AG Grid exports match filtered/sorted view | ☐ | Per-table export button |
| 1.4.4 | Theme switcher (9 themes) applies globally | ☐ | MantineProvider theme parameter |
| 1.4.5 | Plotly charts respond to data changes | ☐ | Dashboard charts, explainability charts |
| 1.4.6 | RadioGroup pipeline-data-source toggles correctly between actual/sample | ☐ | |
| 1.4.7 | MultiSelect pipeline-categories reflects in methods executed | ☐ | Detection category filter |
| 1.4.8 | Per-table delete button removes data from vault AND UI | ☐ | `handle_slot_delete` |
| 1.4.9 | Customer search on Explainability page returns correct results | ☐ | `customer-search` TextInput |
| 1.4.10 | Investigation queue filters by tier and status | ☐ | `get_queue(status, tier)` |

### 1.5 Data Sources Page Specific

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 1.5.1 | All 12 TABLE_SLOTS render (MASTER, transactions, customer_party, accounts, alerts, cases, kyc, watchlist, relationships, temporal, others1, others2) | ☐ | |
| 1.5.2 | Quick Start "Generate Sample Data" populates all 12 tables | ☐ | |
| 1.5.3 | Customer Aggregate table combines ALL MASTER columns + temporal + customer_party + relationships + others1/others2 | ☐ | `_build_customer_aggregate()` |
| 1.5.4 | Cross-table consistency check shows PK presence, overlap, shared columns, DQ summary | ☐ | `_build_consistency_check()` |
| 1.5.5 | Configuration tables (DETECTION_METHODS, RISK_TIERS, etc.) render correctly | ☐ | |
| 1.5.6 | Loaded Summary section shows accurate row/column counts | ☐ | |
| 1.5.7 | Duplicate table names impossible (TABLE_SLOTS keys are unique) | ☐ | |

---

## Section 2: Anomaly Detection Integrity (Unsupervised / Unlabeled Data)

### 2.1 Synthetic Injection Testing

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 2.1.1 | **Inject 5% known outliers** (3σ+ values) into clean data → verify detection rate ≥ 80% for Z-Score, IQR, Grubbs | ☐ | Statistical family |
| 2.1.2 | **Inject cluster outliers** (isolated points far from clusters) → verify IF, LOF, DBSCAN detect ≥ 70% | ☐ | Tree/Distance/Density families |
| 2.1.3 | **Inject temporal spikes** (sudden amount 10× mean at random timestamps) → verify STL, ARIMA, Prophet flag them | ☐ | Time-Series family (requires temporal data) |
| 2.1.4 | **Inject structurally anomalous rows** (benford violation, round amounts only) → verify Benford/flag detectors catch them | ☐ | Flag features in L3 |
| 2.1.5 | **Inject a single known-anomaly row** → verify it appears in investigation queue with CRITICAL/HIGH tier | ☐ | End-to-end test |
| 2.1.6 | **Inject 0% anomaly data** (all identical rows) → verify system doesn't hallucinate anomalies > 5% | ☐ | False positive control |

### 2.2 Distribution Shift Robustness

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 2.2.1 | **Mean shift**: Shift all amounts by +2σ → verify anomaly scores re-calibrate (not flag everything) | ☐ | z-score recalculates mean |
| 2.2.2 | **Variance shift**: Double variance of key feature → verify percentile-rank normalization handles it | ☐ | `_normalize_scores()` uses percentile rank |
| 2.2.3 | **Concept drift simulation**: Train on month-1 distribution, score month-2 with different distribution → check false-positive rate | ☐ | |
| 2.2.4 | **Sparse data**: Run pipeline on dataset with 80% nulls → verify imputation (median) doesn't corrupt scores | ☐ | L4 `SimpleImputer(strategy='median')` |
| 2.2.5 | **Single-feature datasets**: Run with only 1 numeric column → verify statistical detectors still work, distance/density gracefully skip (min_f=3) | ☐ | MethodExecutionEngine `check_requirements()` |

### 2.3 Model Stability & Reproducibility

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 2.3.1 | **Same data → same scores**: Run pipeline twice on identical data → scores must be bitwise identical | ☐ | `random_state=42` in IF, KMeans, GMM, etc. |
| 2.3.2 | **Threshold sensitivity**: Vary `CONTAMINATION_RATE` (0.01, 0.05, 0.10) → verify monotonic increase in flagged % | ☐ | Static contamination in config.py |
| 2.3.3 | **Ensemble weight stability**: Run 3× → `_compute_concordance_weights` produces identical weight vectors | ☐ | Deterministic percentile-rank |
| 2.3.4 | **Risk tier boundary**: Verify a record scoring exactly at `score_min` threshold for CRITICAL is correctly assigned CRITICAL (not HIGH) | ☐ | `>=` operator in `_assign_risk_tiers_v6` |
| 2.3.5 | **Method weight config vs runtime**: Verify METHOD_WEIGHTS in config.py override concordance-based weights where specified | ☐ | `fuse()` uses config weights |
| 2.3.6 | **STATIC thresholds audit** — all 26 detectors use fixed thresholds (not adaptive to data distribution) — document risk | ☐ | **FINDING**: Z-Score=3.0, IQR=1.5, Grubbs=alpha 0.05, ESD=Grubbs-based — none are adaptive |

### 2.4 XAI / Explainability Integrity

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 2.4.1 | `LocalExplainer._permutation_importance` produces non-zero importances for features that drive the anomaly | ☐ | Requires IsolationForest `.decision_function()` |
| 2.4.2 | `FeatureContributionAnalyzer.fit()` aggregates global importance correctly | ☐ | Mean absolute importance across samples |
| 2.4.3 | Explanation text generation (`_generate_explanation_text`) is human-readable | ☐ | |
| 2.4.4 | Narrative system (L7) correctly identifies top 3 contributing methods per alert | ☐ | `_generate_narrative()` in l7_output.py |
| 2.4.5 | **No SHAP library dependency** — module is permutation-based (model-agnostic) — document limitation vs true SHAP values | ☐ | `utils/explainability.py` — custom implementation, NOT shap library |
| 2.4.6 | Explainability page correctly loads scored data and displays customer-level explanations | ☐ | |

---

## Section 3: Performance & Stress Testing

### 3.1 Data Throughput

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 3.1.1 | **N=500 rows, F=15 features**: Pipeline completes in < 30 seconds | ☐ | Baseline performance |
| 3.1.2 | **N=5,000 rows, F=30 features**: Pipeline completes in < 120 seconds | ☐ | At MAX_ROWS_FOR_HEAVY_METHODS boundary |
| 3.1.3 | **N=10,000 rows, F=50 features**: Heavy methods auto-disabled, pipeline completes | ☐ | Smart algorithm selection kicks in |
| 3.1.4 | **N=50,000 rows**: Memory stays under MAX_MEMORY_MB (4096 MB) | ☐ | `ResourceConfig.MAX_MEMORY_MB` |
| 3.1.5 | **F=100+ features**: PCA reduces dimensionality correctly, AG Grid renders without lag | ☐ | `PCA_COMPONENTS=10`, `MAX_AG_GRID_PREVIEW=500` |

### 3.2 Rendering Performance

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 3.2.1 | Dashboard page loads in < 3 seconds with pipeline results | ☐ | |
| 3.2.2 | Data Sources page with 12 populated tables loads in < 5 seconds | ☐ | |
| 3.2.3 | AG Grid with 500 rows renders in < 2 seconds | ☐ | `MAX_AG_GRID_PREVIEW=500` |
| 3.2.4 | Plotly charts (6+ charts on dashboard) render without browser freeze | ☐ | |
| 3.2.5 | 9-theme switch applies without layout re-render stutter | ☐ | |

### 3.3 Detection Engine Profiling

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 3.3.1 | **Autoencoder training time**: < 10 seconds for N=5000, F=30 | ☐ | 100 epochs, batch_size=256, early stopping (patience=10) |
| 3.3.2 | **VAE training time**: < 10 seconds for N=5000, F=30 | ☐ | 80 epochs, batch_size=256, reparameterization trick |
| 3.3.3 | **Graph detectors (4)**: k-NN graph build < 5 seconds for N=5000 | ☐ | `_build_knn_graph` O(N·k·logN) |
| 3.3.4 | **KNN detector**: sklearn NearestNeighbors with n_jobs=-1 | ☐ | V5 Speed optimization |
| 3.3.5 | **LOF detector**: n_jobs=-1 parallel processing | ☐ | |
| 3.3.6 | **IsolationForest**: max_samples=min(N, 10000) + n_jobs=-1 | ☐ | Subsample for large N |
| 3.3.7 | **HEAVY_METHODS list**: Verify correct methods are disabled for N>5000 | ☐ | `pipeline.py` smart algorithm selection |
| 3.3.8 | L5 checkpoint saves mid-pipeline for recovery | ☐ | `l5_checkpoint.json` |

### 3.4 Memory & Resource Limits

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 3.4.1 | **float32 downcast**: L5 detection casts to float32 (50% memory reduction) | ☐ | `X.astype(np.float32)` |
| 3.4.2 | **Parquet storage**: Vault stores as Parquet (not CSV) for compression | ☐ | `to_parquet()` everywhere |
| 3.4.3 | **Graph memory**: k-NN graph is O(N×k) not O(N²) | ☐ | V5 sparse k-NN graph |
| 3.4.4 | **MiniBatchKMeans**: Used instead of full KMeans for clustering + community | ☐ | `batch_size=min(1024, len(X))` |
| 3.4.5 | **PCA reduction**: Reduces to `PCA_COMPONENTS=10` before heavy methods | ☐ | Pipeline sends reduced matrix |
| 3.4.6 | **Matrix version lazy creation**: X_MINMAX only created when `LAZY_MATRIX_CREATION=True` | ☐ | L4 preprocessing |
| 3.4.7 | **k-NN graph caching**: Single build shared across PageRank, HITS, Centrality | ☐ | `_knn_graph_cache` in Layer5Detection |

---

## Section 4: Security & Compliance Audit

### 4.1 PII Protection

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 4.1.1 | **CRITICAL**: `PIIConfig.ENABLED_BY_DEFAULT = False` — PII masking is OFF by default | ☐ | **RISK**: Must be enabled in production |
| 4.1.2 | `MASK_AT_STORAGE = True` — verify masking applied before `to_parquet()` in `save_sources()` | ☐ | data_io.py `save_sources()` |
| 4.1.3 | `MASK_IN_EXPORTS = True` — verify masking in `export_scorecard()` | ☐ | data_io.py `export_scorecard()` |
| 4.1.4 | MASKED_COLUMNS list covers all PII fields: customer_id, account_number, ssn, name, email, phone, cust_id, cust_name, party_name, client_name | ☐ | |
| 4.1.5 | `detect_pii_columns()` auto-detects additional PII columns | ☐ | Keyword matching: customer, account, name, email, phone, ssn, address, etc. |
| 4.1.6 | Masking functions correct: `mask_email()` keeps first 2 chars + domain, `mask_phone()` keeps last 4 digits, `mask_account()` keeps last 4 digits | ☐ | |
| 4.1.7 | **Masking reversibility**: Verify masked values CANNOT be reverse-engineered (check `visible_chars=4` — is 4 sufficient?) | ☐ | |
| 4.1.8 | ForensicExporter `include_pii=False` by default | ☐ | forensic_export.py |
| 4.1.9 | **In-memory PII**: `data_vault._sources` stores UNMASKED data in memory — document risk | ☐ | data_io.py: "Keep unmasked in memory" |

### 4.2 Data Injection & Input Validation

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 4.2.1 | `dcc.Upload` accepts only CSV, Parquet, Excel (no executable formats) | ☐ | `import_data()` validates extension |
| 4.2.2 | `_validate_data()` rejects: < 10 rows, 0 numeric columns, all-null columns | ☐ | data_io.py |
| 4.2.3 | **Missing**: No file size limit on upload — potential DoS | ☐ | **GAP**: Should add `max_size` to dcc.Upload |
| 4.2.4 | **Missing**: No check for CSV formula injection (=CMD, +CMD) | ☐ | **GAP**: Excel exports could execute formulas |
| 4.2.5 | base64 decode in `import_data()` — verify no buffer overflow for corrupted content | ☐ | try/except wraps decode |
| 4.2.6 | Column names sanitized (no SQL/path injection in column names) | ☐ | Parquet stores as-is |
| 4.2.7 | **Missing**: No rate-limiting on file uploads | ☐ | |

### 4.3 Audit Trail & Compliance

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 4.3.1 | **Hash-chain logging**: `ENABLE_HASH_CHAIN_LOGS = True` — each log entry chains to previous via SHA256 | ☐ | logger.py `_prev_hash` → `new_hash` |
| 4.3.2 | **Hash chain integrity**: Verify chain is tamper-evident (modifying one entry breaks all subsequent hashes) | ☐ | |
| 4.3.3 | **FINDING**: Hash chain seed is `"GENESIS"` hardcoded — restarts reset the chain | ☐ | **GAP**: Should persist last hash to disk |
| 4.3.4 | **Run versioning**: `create_run_record()` generates UUID run_id + config snapshot | ☐ | data_io.py |
| 4.3.5 | **Data lineage**: `input_hash` computed via `sha256(csv_bytes)` for each run | ☐ | Matches `_hash_dataframe()` in pipeline.py |
| 4.3.6 | Pipeline start, completion, failure all logged with metadata | ☐ | `log_pipeline_start()`, `log_pipeline_complete()` |
| 4.3.7 | Data import, export, generation logged | ☐ | `log_data_import()`, `log_export()` |
| 4.3.8 | **Rotating log files**: 10MB max, 10 backups — verify rotation happens | ☐ | `RotatingFileHandler` |
| 4.3.9 | Audit trail page reads actual log entries (not stale) | ☐ | audit_trail.py reads vault + logger |
| 4.3.10 | Audit vault page shows run history with artifacts | ☐ | `list_runs()` from data_io.py |
| 4.3.11 | **Missing**: No user authentication — all actions logged as "system" | ☐ | `user="system"` default |
| 4.3.12 | **Missing**: No role-based access control (RBAC) | ☐ | admin.py exists but no auth gate |

### 4.4 Application Security

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 4.4.1 | `serve_locally=True` — no CDN calls (air-gapped compliant) | ☐ | app.py |
| 4.4.2 | `DEBUG=False` in AppConfig (no debug mode in production) | ☐ | config.py |
| 4.4.3 | `suppress_callback_exceptions=True` — hides error tracebacks from UI (good for security, bad for debugging) | ☐ | **Trade-off**: Disable for dev, enable for prod |
| 4.4.4 | No secrets or API keys in config.py | ☐ | Config only has paths and thresholds |
| 4.4.5 | `pipeline_status.json` written to disk — verify no sensitive data in status | ☐ | Contains: progress, stage, status, error |
| 4.4.6 | Vault directory permissions — verify only app user can read/write | ☐ | OS-level check |
| 4.4.7 | diskcache backend — verify cache directory doesn't store PII | ☐ | app.py uses diskcache |
| 4.4.8 | No hardcoded passwords or tokens anywhere in codebase | ☐ | Full grep check |

---

## Critical Findings Summary

| Finding | Severity | Location | Recommendation |
|---------|----------|----------|----------------|
| PII masking OFF by default | **CRITICAL** | config.py `ENABLED_BY_DEFAULT=False` | Change to `True` for production builds |
| No file size limit on upload | **HIGH** | data_io.py `import_data()` | Add `max_size` parameter (e.g., 100MB) |
| Hash chain resets on restart | **HIGH** | logger.py `_prev_hash="GENESIS"` | Persist last hash to disk; reload on start |
| No user authentication | **HIGH** | All pages | Add basic auth or SSO for production |
| In-memory unmasked PII | **MEDIUM** | data_io.py `save_sources()` | Mask in-memory copies or use secure memory |
| CSV formula injection | **MEDIUM** | data_io.py exports | Prefix cells with `'` in CSV exports |
| Static detection thresholds | **MEDIUM** | All 26 detectors | Document limitation; add adaptive option |
| `suppress_callback_exceptions` | **LOW** | app.py | Set to `False` in development; `True` in prod |
| No RBAC | **LOW** | admin.py | Implement role-based views for production |
| CONTAMINATION_RATE fixed at 0.05 | **LOW** | config.py | Make configurable per-run via UI |

---

## Quick Verification Commands

```bash
# 1. Check for MATCH pattern callbacks (must return 0 results)
grep -rn "MATCH" pages/ --include="*.py"

# 2. Check for hardcoded secrets
grep -rn "password\|secret\|api_key\|token" . --include="*.py" -i

# 3. Verify PII masking config
grep -n "ENABLED_BY_DEFAULT" config.py

# 4. Verify air-gapped mode
grep -n "serve_locally" app.py

# 5. Verify debug mode off
grep -n "DEBUG" config.py

# 6. Count all callbacks
grep -rn "@callback" pages/ --include="*.py" | wc -l

# 7. Verify no MATCH in callbacks
grep -rn "dash.dependencies.MATCH\|from dash import.*MATCH" pages/ --include="*.py"
```
