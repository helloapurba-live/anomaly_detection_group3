# Contributing to AIM AI Vault

> **Internal contributors only** — Bank AML Investigation Technology Team

---

## Getting Started

### 1. Clone the Repository

```bash
git clone <internal-repo-url>
cd FCDAI_Annomaly_auto_detection_version15
```

### 2. Set Up Environment

```bash
conda create -n ai311 python=3.11 -y
conda activate ai311
pip install -r requirements.txt
pip install ruff pytest httpx  # Dev tools
```

### 3. Configure

```bash
cp config.toml.example config.toml
# Edit config.toml with your local settings
```

### 4. Verify Setup

```bash
make check
```

---

## Development Workflow

### Branch Naming

| Type | Format | Example |
|------|--------|---------|
| Feature | `feature/<ticket>-<short-desc>` | `feature/AML-123-add-velocity-layer` |
| Bugfix | `fix/<ticket>-<short-desc>` | `fix/AML-456-scoring-overflow` |
| Hotfix | `hotfix/<desc>` | `hotfix/pii-leak-in-export` |
| Release | `release/v<version>` | `release/v15.1.0` |

### Commit Messages

Follow [Conventional Commits](https://www.conventionalcommits.org/):

```
<type>(<scope>): <description>

[optional body]

[optional footer]
```

**Types**: `feat`, `fix`, `docs`, `refactor`, `test`, `chore`, `security`

**Examples**:
```
feat(api): add entity detail endpoint with PII masking
fix(L2): correct Isolation Forest contamination parameter
security(auth): enforce rate limit on token endpoint
docs(readme): update API endpoint table for V15
```

### Pull Request Process

1. Create a feature branch from `main`
2. Make changes, commit with conventional messages
3. Run `make check` (lint + test + syntax)
4. Open a pull request with:
   - Description of changes
   - Test coverage notes
   - PII impact assessment (if data-touching)
   - Compliance notes (if rule-affecting)
5. Request review from at least 1 team member
6. Squash-merge after approval

---

## Code Standards

### Python Style

- **Line length**: 120 characters max
- **Formatter**: ruff (configured in pyproject.toml)
- **Target**: Python 3.11
- **Type hints**: Required for all public functions
- **Docstrings**: Required for all modules, classes, and public functions

### Security Rules (MANDATORY)

| Rule | Description |
|------|-------------|
| **No PII in logs** | Use `pii_masker` utility for any logged data |
| **No PII in errors** | Generic error messages only in API responses |
| **No plaintext secrets** | Use environment variables or encrypted config |
| **No external calls** | Air-gapped — no HTTP, no DNS, no telemetry |
| **No data in VCS** | All data files blocked by .gitignore |
| **RBAC enforcement** | Every new endpoint needs permission mapping |
| **Audit logging** | Every new action needs audit trail entry |
| **Hash-chain** | Audit entries linked via SHA-256 chain |

### Adding a New API Endpoint

1. Add Pydantic schema to `api/schemas.py`
2. Add permission mapping to `api/middleware.py` → `ENDPOINT_PERMISSIONS`
3. Add route function to `api/routes.py` with:
   - Authentication dependency (`get_current_user` or `require_permission`)
   - PII masking call (`mask_pii_in_dict`)
   - Audit logging call (`audit_api_request`)
4. Update `api/__init__.py` docstring
5. Update [docs/API_REFERENCE.md](docs/API_REFERENCE.md)
6. Add test to `tests/test_api.py`

### Adding a New Detection Method

1. Add method to appropriate layer file (`layers/L{N}_*.py`)
2. Register in `config.py` → detection method registry
3. Add weight configuration
4. Update [docs/DATA_DICTIONARY.md](docs/DATA_DICTIONARY.md) with new score columns
5. Add unit test
6. Document in CHANGELOG.md

---

## Testing

```bash
# Run all tests
make test

# Run specific test file
python -m pytest tests/test_api.py -v

# Run with coverage
python -m pytest --cov=api tests/
```

### Test Requirements

- All API endpoints must have corresponding tests
- PII masking tests must verify no leakage in all roles
- Authentication tests must verify rejection of invalid tokens
- Rate limit tests must verify 429 responses

---

## Documentation

Update these when making changes:

| Change Type | Update |
|-------------|--------|
| New endpoint | API_REFERENCE.md, openapi.yaml |
| New detection method | DATA_DICTIONARY.md, ARCHITECTURE.md |
| Config change | config.toml.example, DEPLOYMENT.md |
| Security change | SECURITY.md, COMPLIANCE.md |
| Bug fix | CHANGELOG.md |
| New feature | CHANGELOG.md, README.md |

---

## Code Review Checklist

- [ ] No PII in logs, errors, or responses (unless properly masked)
- [ ] RBAC enforced on new endpoints
- [ ] Audit logging added for new actions
- [ ] Type hints on all public functions
- [ ] Docstrings on modules, classes, public functions
- [ ] Tests added/updated
- [ ] Documentation updated
- [ ] `make check` passes
- [ ] No new external dependencies without team approval
- [ ] License compatibility verified (BSD/MIT/Apache only)

---

*AIM AI Vault V15 — Internal Development Guidelines*
