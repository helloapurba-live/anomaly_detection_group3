# FCDAI Anomaly Auto Detection — Version History V1 to V10

## Comprehensive Documentation for Review

**Project**: FCDAI (Financial Crime Detection AI) Anomaly Auto Detection  
**Scope**: Versions 1.0.0 through 10.0.0  
**Author**: Project ApurbaDas Team  
**Generated**: February 2026  
**Environment**: Air-gapped Windows 11, Python 3.11, CPU-only (8 GB RAM)

---

## Table of Contents

1. [Project Origin & Architecture](#1-project-origin--architecture)
2. [Version 1 — Streamlit Prototype](#2-version-1--streamlit-prototype)
3. [Version 2 — Dash Migration](#3-version-2--dash-migration)
4. [Version 3 — ApurbaDas Consolidation](#4-version-3--apurbadas-consolidation)
5. [Version 4 — Scalability & Pipeline Runner](#5-version-4--scalability--pipeline-runner)
6. [Version 5 — Production Hardening](#6-version-5--production-hardening)
7. [Version 6 — Customer-Level Detection](#7-version-6--customer-level-detection)
8. [Version 7 — Flexible Architecture](#8-version-7--flexible-architecture)
9. [Version 8 — Role-Based Column Resolution & Audit](#9-version-8--role-based-column-resolution--audit)
10. [Version 9 — VAT Audit & FMEA Fixes](#10-version-9--vat-audit--fmea-fixes)
11. [Version 10 — Production Core (SQLite, Auth, RBAC)](#11-version-10--production-core-sqlite-auth-rbac)
12. [Evolution Summary: V1 → V10](#12-evolution-summary-v1--v10)
13. [Directory & File Inventory](#13-directory--file-inventory)
14. [Detection Methods Evolution](#14-detection-methods-evolution)
15. [Configuration Evolution](#15-configuration-evolution)
16. [Port Assignment History](#16-port-assignment-history)
17. [Dependencies Evolution](#17-dependencies-evolution)

---

## 1. Project Origin & Architecture

### What Is FCDAI?

FCDAI (Financial Crime Detection AI) is an **unsupervised anomaly detection platform** designed for Anti-Money Laundering (AML) compliance in banking environments. It operates entirely **air-gapped** (zero internet connectivity, zero telemetry) on a local Windows 11 machine.

### Core Architecture (7-Layer Pipeline)

The system implements a 7-layer detection pipeline that has remained consistent from V2 onwards:

```
┌─────────────────────────────────────────────────────────────────┐
│                      END-TO-END DATA FLOW                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   ┌────────┐  ┌────────┐  ┌────────┐  ┌────────┐               │
│   │  KYC   │  │  TXN   │  │ ALERTS │  │ CASES  │               │
│   └───┬────┘  └───┬────┘  └───┬────┘  └───┬────┘               │
│       └───────────┴───────────┴───────────┘                     │
│                          │                                      │
│              ┌───────────▼───────────┐                          │
│              │   LAYER 1 & 2         │                          │
│              │   Ingest + DQ         │                          │
│              └───────────┬───────────┘                          │
│              ┌───────────▼───────────┐                          │
│              │   LAYER 3             │                          │
│              │   Feature Engineering │                          │
│              └───────────┬───────────┘                          │
│              ┌───────────▼───────────┐                          │
│              │   LAYER 4             │                          │
│              │   Preprocessing       │                          │
│              └───────────┬───────────┘                          │
│     ┌────────────────────┼────────────────────┐                 │
│     ▼         ▼          ▼          ▼         ▼                 │
│ ┌───────┐ ┌───────┐ ┌───────┐ ┌───────┐ ┌───────┐              │
│ │STAT   │ │DIST   │ │DENS   │ │CLUST  │ │TREE   │              │
│ └───┬───┘ └───┬───┘ └───┬───┘ └───┬───┘ └───┬───┘              │
│     │    ┌────┴────┐ ┌──┴───┐ ┌───┴───┐     │                  │
│     │    │TS       │ │GRAPH │ │DEEP   │     │                  │
│     │    └────┬────┘ └──┬───┘ └───┬───┘     │                  │
│     └─────────┴─────────┴─────────┴─────────┘                  │
│                          │                                      │
│              ┌───────────▼───────────┐                          │
│              │   LAYER 6             │                          │
│              │   Ensemble Fusion     │                          │
│              └───────────┬───────────┘                          │
│              ┌───────────▼───────────┐                          │
│              │   LAYER 7             │                          │
│              │   Output/Investigation│                          │
│              └───────────────────────┘                          │
└─────────────────────────────────────────────────────────────────┘
```

### Layer Responsibilities

| Layer | Name | Purpose |
|-------|------|---------|
| L1-L2 | Ingest + Data Quality | Load multi-source data, validate completeness/consistency/validity |
| L3 | Feature Engineering | Generate 50-80+ features (velocity, aggregates, ratios, temporal, behavioral) |
| L4 | Preprocessing | Create 4 matrix versions: raw, scaled, PCA, encoded |
| L5 | Detection | Run 26 unsupervised anomaly detection methods across 8 categories |
| L6 | Ensemble Fusion | Combine 26 scores → single risk score + risk tier assignment |
| L7 | Output/Investigation | Investigation queue, narratives, audit trail |

### Detection Method Categories (26 Methods)

| Category | Methods | Count |
|----------|---------|-------|
| Statistical | Z-Score, IQR, Grubbs, Dixon, ESD | 5 |
| Distance | KNN, Mahalanobis, LOF | 3 |
| Density | DBSCAN, OPTICS, HDBSCAN, CBLOF | 4 |
| Clustering | K-Means Anomaly, GMM, Spectral | 3 |
| Trees | Isolation Forest, Extended IF | 2 |
| Time-Series | STL, ARIMA Residual, Prophet | 3 |
| Graph | PageRank, HITS, Community, Centrality | 4 |
| Deep Learning | Autoencoder, VAE | 2 |
| **Total** | | **26** |

---

## 2. Version 1 — Streamlit Prototype

**Directory**: `fcdai_7layer_streamlit/`  
**Framework**: Streamlit  
**Version**: 1.0.0 (implicit)  
**Status**: Proof-of-concept / archived

### What Was Built

V1 was the **initial proof-of-concept** built with Streamlit — a script-based Python web framework that re-runs top-to-bottom on every user interaction.

### Key Characteristics

- **Framework**: Streamlit (script-based execution model)
- **Architecture**: 7-layer pipeline conceived and implemented
- **UI**: Basic Streamlit pages with `.streamlit/` config directory
- **Data Flow**: Sequential — load → process → detect → display
- **Port**: Default Streamlit port (8501)
- **Theme**: Basic dark theme via Streamlit config

### File Structure

```
fcdai_7layer_streamlit/
├── .streamlit/         # Streamlit config (theme, server settings)
├── app.py              # Main Streamlit entry point
├── config.py           # Centralized configuration (dataclasses)
├── pipeline.py         # Pipeline orchestrator
├── layers/             # L1-L7 detection modules
├── pages/              # Streamlit multi-page UI
├── utils/              # Data I/O, logging
├── data/               # Data storage
├── logs/               # Log files
├── output/             # Pipeline outputs
├── README.md
└── requirements.txt
```

### Configuration

```python
# config.py — V1 Streamlit Edition
@dataclass
class PathConfig:
    BASE, DATA, DATA_SOURCES, MODELS, LOGS, OUTPUT

@dataclass
class ThemeConfig:
    PRIMARY: "#00D4FF"   # Cyan accent
    DARK_BG: "#0F0F23"   # Deep dark background

@dataclass
class LayerConfig:
    DQ_COMPLETENESS_THRESHOLD: 0.95
    DQ_VALIDITY_THRESHOLD: 0.90
    FEATURE_CATEGORIES: velocity, aggregate, ratio, flag, temporal, behavioral
```

### Limitations That Drove V2

1. **Script re-execution**: Streamlit re-runs entire script on every interaction → slow for complex pipelines
2. **No callback model**: Cannot have fine-grained interactivity (click button → update one component)
3. **Limited component library**: No AG Grid, no Mantine components, limited charting control
4. **State management**: Streamlit session state is fragile and resets on page navigation
5. **No multi-page routing**: Early Streamlit had poor multi-page support (later improved)
6. **Air-gap difficulty**: Streamlit CDN dependencies harder to fully air-gap

---

## 3. Version 2 — Dash Migration

**Directory**: `fcdai_7layer_dash/`  
**Framework**: Dash + Dash Mantine Components  
**Version**: 2.0.0  
**Port**: 8071

### What Changed from V1

V2 was a **complete rewrite** from Streamlit to Dash — migrating the 7-layer pipeline into a proper callback-driven web application with premium UI components.

### Key Enhancements

| Feature | V1 (Streamlit) | V2 (Dash) |
|---------|----------------|-----------|
| **Framework** | Streamlit | Dash + DMC + AG Grid |
| **Execution Model** | Script re-run | Callback-driven (reactive) |
| **Components** | Basic Streamlit widgets | Mantine premium components |
| **Data Grid** | `st.dataframe()` | AG Grid (sort, filter, pagination) |
| **Charts** | `st.plotly_chart()` | Native Plotly (full control) |
| **Routing** | `pages/` folder | `use_pages=True` with `dcc.Location` |
| **State** | `st.session_state` | `dcc.Store` + callback State |
| **Air-gap** | Partial | `serve_locally=True` |
| **Port** | 8501 (default) | 8071 |

### Architecture Decisions

- **Dash Mantine Components (DMC)**: Premium UI library with dark mode, Paper, Card, NavLink, ThemeIcon
- **DashIconify**: Icon library for navigation icons (e.g., `mdi:shield-lock`)
- **AG Grid**: Enterprise-grade data grid for investigation queues and data tables
- **Diskcache**: Client-side caching for performance
- **Multi-page**: `use_pages=True` with `pages/` folder convention

### File Structure

```
fcdai_7layer_dash/
├── app.py              # Dash app initialization + sidebar layout
├── config.py           # Configuration (VERSION: "2.0.0", PORT: 8071)
├── pipeline.py         # Pipeline orchestrator
├── layers/             # L1-L7 detection modules
│   ├── l1_l2_ingestion.py
│   ├── l3_feature_engineering.py
│   ├── l4_preprocessing.py
│   ├── l5_detection.py
│   ├── l6_ensemble.py
│   └── l7_output.py
├── pages/              # UI pages
├── utils/              # Utilities
├── assets/             # CSS/JS (served locally)
├── data/               # Data vault
├── cache/              # Diskcache
├── logs/               # Logs
├── models/             # Saved models
├── README.md
└── requirements.txt
```

### Configuration

```python
@dataclass
class AppConfig:
    TITLE: str = "FCDAI Anomaly Auto Detection Tool"
    VERSION: str = "2.0.0"
    PORT: int = 8071
    SERVE_LOCALLY: bool = True  # Air-gapped

@dataclass
class LayerConfig:
    DETECTION_METHODS: 26 methods across 8 categories
    ENSEMBLE_METHOD: "weighted_average"
    RISK_TIERS: Critical (0.9-1.0), High (0.7-0.9), Medium (0.5-0.7), Low (0.0-0.5)

@dataclass
class DataSourceConfig:
    SOURCES: kyc, transactions, alerts, cases (with expected_rows)
```

### UI Pages (V2)

| Page | Route | Purpose |
|------|-------|---------|
| Dashboard | `/` | Overview with risk distribution charts |
| Data Sources | `/sources` | Upload KYC, TXN, Alerts, Cases |
| Pipeline Run | `/pipeline` | Execute 7-layer detection pipeline |
| Layer View | `/layers` | Inspect individual layer outputs |
| Explainability | `/explainability` | Method contribution analysis |
| Investigation Queue | `/queue` | Prioritized alert investigation |
| Narratives | `/narratives` | Auto-generated suspect narratives |
| Audit Trail | `/audit` | Tamper-evident log viewer |
| Model Diagnostics | `/diagnostics` | Method performance metrics |

---

## 4. Version 3 — ApurbaDas Consolidation

**Directory**: `FCDAI_Annomaly_auto_detection_version3/`  
**Version**: 3.0.0  
**Port**: 8085

### What Changed from V2

V3 was the first version in the `FCDAI_Annomaly_auto_detection_versionN` naming convention. It **consolidated** the Dash app with the "Project ApurbaDas Apex" branding and added several foundational features.

### Key Enhancements

1. **PII Masking Configuration**
   - New `PIIConfig` dataclass in config.py
   - `ENABLED_BY_DEFAULT: False` (later changed to True in V9)
   - Column masking patterns: customer_id, account_number, SSN, name, email, phone
   - Regex-based partial masking (e.g., keep first 4 + last 4 of customer_id)

2. **Extended Detection Methods**
   - Added: COPOD, ECOD, HBOS, MCD (statistical category expanded from 5 to 9)
   - Added: One-Class SVM category
   - Added: Matrix Profile (time-series)
   - Added: SOM (deep learning / Self-Organizing Maps)
   - Config shows 35+ methods now configured (superset — not all active per run)

3. **Mantine Theme Enhancement**
   - Full `get_mantine_theme()` method returning complete theme dict
   - Grape color palette added alongside cyan
   - Paper and Card component styling

4. **Data Vault Architecture**
   - `data/vault/` for persistent scored data
   - `data/sources/` for uploaded source files
   - `data/exports/` for forensic exports
   - `utils/pii_masking.py` utility added
   - `utils/forensic_export.py` for audit-ready exports

5. **Multi-Source Data Config**
   - 4 sources: KYC (100 rows), TXN (700 rows), Alerts (50 rows), Cases (20 rows)
   - Key column mapping per source

### File Inventory

```
FCDAI_Annomaly_auto_detection_version3/
├── app.py              # Dash app (216 lines)
├── config.py           # Config with PIIConfig (217 lines)
├── pipeline.py         # Pipeline orchestrator (280 lines)
├── README.md           # Architecture diagram + file list
├── requirements.txt    # Core deps (dash, pandas, scikit-learn, hdbscan, pyod)
├── layers/             # 7 files (l1_l2 through l7 + __init__)
├── pages/              # 11 pages
│   ├── dashboard.py
│   ├── data_sources.py
│   ├── pipeline_run.py
│   ├── explainability.py
│   ├── investigation_queue.py
│   ├── audit_trail.py
│   ├── audit_vault.py
│   ├── layer_view.py
│   ├── model_diagnostics.py
│   ├── narratives.py
│   └── system_health.py
├── utils/              # 7 files
│   ├── data_io.py
│   ├── explainability.py
│   ├── forensic_export.py
│   ├── generate_data.py
│   ├── logger.py
│   ├── pii_masking.py
│   └── __init__.py
├── assets/             # CSS/JS
├── cache/              # Diskcache
├── data/               # vault/, sources/, exports/
├── logs/
└── models/
```

### Pages (11 Pages)

| Page | New in V3? | Purpose |
|------|-----------|---------|
| Dashboard | No | Risk overview |
| Data Sources | No | Multi-source upload |
| Pipeline Run | No | Execute pipeline |
| Layer View | No | Layer inspection |
| Explainability | No | Method contributions |
| Investigation Queue | No | Alert management |
| Narratives | No | Auto-generated narratives |
| Audit Trail | No | Log viewer |
| **Audit Vault** | **YES** | Encrypted data vault viewer |
| Model Diagnostics | No | Method performance |
| **System Health** | **YES** | System resource monitoring (CPU, memory, disk) |

---

## 5. Version 4 — Scalability & Pipeline Runner

**Directory**: `FCDAI_Annomaly_auto_detection_version4/`  
**Version**: 3.0.0 (version string not updated in config)  
**Port**: 8090

### What Changed from V3

V4 focused on **scalability testing** and **standalone pipeline execution** — making the pipeline runnable outside the dashboard UI.

### Key Enhancements

1. **Pipeline Runner Script** (`pipeline_runner.py`)
   - Standalone CLI to execute the pipeline without starting the Dash UI
   - Importable by external systems for batch processing
   - Direct pipeline orchestration without UI overhead

2. **Scalability Verification** (`verify_scalability.py`)
   - Automated scalability test harness
   - Tests with configurable customer count (default: 100,000)
   - Generates synthetic data → runs full pipeline → reports timing
   - Measures: data generation time, pipeline execution time, total time
   - Validates pipeline succeeds at scale

3. **Port Change**: 8085 → 8090 (avoiding conflict with V3)

4. **Data Source Config Simplified**
   - Removed `expected_rows` from source definitions
   - Sources now only define `key_column` per source

### New Files

| File | Purpose |
|------|---------|
| `pipeline_runner.py` | Standalone pipeline execution script |
| `verify_scalability.py` | Automated 100K customer stress test (74 lines) |

### Scalability Test Flow

```
1. Generate 100K customers of synthetic data
2. Merge KYC + Transactions + Account data
3. Persist to data vault
4. Execute full 7-layer pipeline
5. Report: status, records processed, execution time, tier distribution
```

---

## 6. Version 5 — Production Hardening

**Directory**: `FCDAI_Annomaly_auto_detection_version5/`  
**Version**: 5.0.0  
**Port**: 8097

### What Changed from V4

V5 was a **major production-hardening release** that introduced multiple UI themes, clientside callbacks, and statistical rigor improvements.

### Key Enhancements

1. **Multi-Theme System (6+ Themes)**
   - System Default (Cyan/Dark)
   - Midnight Blue (Indigo/Dark)
   - Emerald Dark (Teal/Dark)
   - Rose Gold (Pink/Dark)
   - Sunset Amber (Orange/Dark)
   - Arctic Light (Blue/Light)

   Each theme provides: primaryColor, colorScheme, bgColor, cardBg, borderColor, accentGradient

2. **Clientside Callbacks**
   - `clientside_callback` for theme switching (no server round-trip)
   - Faster UI responsiveness for visual-only operations
   - `dcc.Store` for theme persistence across page navigation

3. **Production Configuration**
   - Docstring updated: "Statistically rigorous, scalable, and production-hardened"
   - Config structure unchanged but version bumped to 5.0.0
   - Same 4 data sources: KYC, Transactions, Alerts, Cases

4. **App.py Expansion**
   - 216 lines (V3/V4) → 444 lines (V5)
   - Theme definitions dictionary with full color palettes
   - Dynamic theme application via callbacks

### Theme Architecture

```python
THEMES = {
    "system":   {"label": "System Default",  "primaryColor": "cyan",   "colorScheme": "dark"},
    "midnight": {"label": "Midnight Blue",   "primaryColor": "indigo", "colorScheme": "dark"},
    "emerald":  {"label": "Emerald Dark",    "primaryColor": "teal",   "colorScheme": "dark"},
    "rose":     {"label": "Rose Gold",       "primaryColor": "pink",   "colorScheme": "dark"},
    "sunset":   {"label": "Sunset Amber",    "primaryColor": "orange", "colorScheme": "dark"},
    "arctic":   {"label": "Arctic Light",    "primaryColor": "blue",   "colorScheme": "light"},
}
```

---

## 7. Version 6 — Customer-Level Detection

**Directory**: `FCDAI_Annomaly_auto_detection_version6/`  
**Version**: 6.0.0  
**Port**: 8109  
**Release Date**: February 2026

### What Changed from V5

V6 was a **major architectural shift** — moving from transaction-level to **customer-level** anomaly detection. This was the most significant detection methodology change in the project's history.

### Key Enhancements

#### 1. Customer-Level Processing Architecture

**Problem**: V5 processed transactions individually, leading to fragmented entity views.

**Solution**: All transactions roll up to customer level before Layer 3.

```
V5: 10,000 transactions → 10,000 detection records
V6: 10,000 transactions → 1,000 customers (10x reduction)
```

- New module: `utils/customer_aggregation.py`
- Integration: Between L1-2 and L3
- Config: `APP.CUSTOMER_LEVEL_PROCESSING = True`

#### 2. Tiered Consensus Ensemble (Layer 6)

**Problem**: V5 used score-only thresholds, missing high-consensus anomalies.

**Solution**: Dual threshold logic — `(score >= threshold) OR (votes >= threshold)`

| Tier | Score ≥ | Votes ≥ | Logic |
|------|---------|---------|-------|
| CRITICAL | 0.95 | 23/25 | Either triggers |
| HIGH | 0.85 | 18/25 | Either triggers |
| MEDIUM | 0.70 | 12/25 | Either triggers |
| LOW | 0.50 | 8/25 | Either triggers |

#### 3. Percentile Rank Normalization

**Problem**: V5 min-max scaling was sensitive to outliers.

**Solution**: Every score converted to 0-1 based on its rank:
```
normalized_score = rank(score) / n
```

#### 4. Domain-Driven Method Weights

```python
METHOD_WEIGHTS = {
    "benford": 2.0,           # Structuring-specific (highest weight)
    "isolation_forest": 1.5,  # Production-proven
    "lof": 1.5,               # Density anomaly specialist
    "extended_if": 1.3,
    "hdbscan": 1.2,
    "community": 1.2,
    "autoencoder": 0.8,       # Experimental (lower)
    "vae": 0.8,
    "lstm_ae": 0.5,           # Most experimental
}
```

#### 5. Enhanced Customer Features (80+)

| Category | New Features |
|----------|-------------|
| Volume | `txn_count`, `txn_frequency`, velocity indicators |
| Amounts | `amount_total/mean/median/std/min/max/range/cv` |
| Structuring | `count_just_below_10k`, `pct_just_below_10k` |
| Temporal | `night_txn_count/pct`, `weekend_txn_count/pct`, `account_age_days` |
| Behavioral | `amount_gini`, `amount_entropy`, `amount_skew`, `amount_kurtosis` |

### Performance Comparison: V5 vs V6

| Metric | V5 | V6 | Change |
|--------|----|----|--------|
| Processing Level | Transaction | Customer | Fundamental shift |
| Records Processed | 10,000 | 1,000 | **-90%** |
| Features Generated | 50 | 80+ | **+60%** |
| Execution Time | ~5 min | ~4 min | **-20%** |
| Memory Usage | 250 MB | 180 MB | **-28%** |
| Ensemble Strategy | Concordance | Tiered Consensus | Upgraded |

### New Files in V6

| File | Purpose |
|------|---------|
| `VERSION_6_RELEASE_NOTES.md` | Comprehensive release notes (339 lines) |
| `DIAGNOSTIC_REPORT.md` | Issue investigation report (285 lines) |
| `diagnostic_trace.py` | Data flow diagnostic utility |

### Bug Fixes Documented in V6

| Issue | Root Cause | Fix |
|-------|-----------|-----|
| "100 vs 75 customers" data loss scare | Source data had 75 unique customers, not 100 | Verified — zero data loss; added diagnostic script |
| Risk-by-Family table BLANK | AG Grid field names mismatched pipeline output field names | Aligned field names in `pipeline_run.py` |

---

## 8. Version 7 — Flexible Architecture

**Directory**: `FCDAI_Annomaly_auto_detection_version7/`  
**Version**: 7.0.0  
**Port**: 8055  
**Release Date**: February 12, 2026

### What Changed from V6

V7 was a **complete data architecture rewrite** — implementing TRUE flexibility where the system works with **ANY data structure** without hardcoded table or column names.

### Core Principles

#### Principle 1: MASTER Table Is the Only Mandatory Input

```
V6: System expected 11 predefined tables (transactions, party, account, alert, etc.)
V7: Only MASTER table required (2 mandatory columns: cust_id, cust_name)
```

Any additional columns are auto-detected and processed. From 2-column MASTER to 100+ columns — all valid.

#### Principle 2: Unlimited Extensibility

```
V6: Hardcoded TABLE_CONFIG dictionary with 11 fixed table names
V7: ANY table name accepted at runtime — no code changes needed
```

System auto-discovers tables with `cust_id` → auto-joins to MASTER → assigns dynamic icons.

#### Principle 3: Auto-Detection of Data Types

New `SchemaDetector` class (380 lines) with 8 column type detections:

| Type | Detection Rule | Action |
|------|---------------|--------|
| CONTINUOUS | Float or large-range integers | Normalization/scaling |
| ORDINAL | Integer with 2-10 unique values | Ordinal encoding |
| BINARY | Exactly 2 unique values | Binary encoding (0/1) |
| CATEGORICAL | String with <20 unique values | One-hot / label encoding |
| HIGH_CARDINALITY | String with >20 unique values | **Excluded** |
| ID_FIELD | >95% unique + 'id' keyword | **Excluded** (except cust_id) |
| DATETIME | Datetime dtype | Temporal features |
| TEXT | Free-text columns | **Excluded** |

#### Principle 4: All Configuration Tables Optional

```
V6: Some methods expected specific config tables
V7: All config tables optional — system uses intelligent defaults
```

### Key New Components

| Component | File | Lines | Purpose |
|-----------|------|-------|---------|
| SchemaDetector | `utils/schema_detector.py` | 380 | Auto data type detection engine |
| AutoParamGenerator | `utils/auto_params.py` | 350 | Data-adaptive parameter generation for 26 methods |
| MethodExecutionEngine | `layers/l5_detection.py` | +200 | Conditional execution with graceful degradation |
| `detect_all_robust()` | `layers/l5_detection.py` | New | Main robust execution (replaces legacy `detect_all()`) |
| `fuse_robust()` | `layers/l6_ensemble.py` | +50 | Fusion method for robust execution output |

### Adaptive Detection System

26 methods execute **conditionally** based on:
- Data volume (n_samples, n_features)
- Data structures available (temporal, graph)
- Method-specific requirements (e.g., LOF needs ≥5 samples)
- Memory limits

Methods that can't run are **gracefully skipped** with logged reasons — pipeline never crashes.

### Data Sources Page Rewrite

**Before (V6)**: 11 fixed table cards with hardcoded names  
**After (V7)**: MASTER upload (mandatory) + unlimited additional tables (any name)

### V6 vs V7 Comparison

| Feature | V6 | V7 |
|---------|----|----|
| Mandatory Tables | None (but expected 11) | Only MASTER |
| Table Names | Hardcoded (11 fixed) | ANY name accepted |
| Column Detection | Partial (aliases) | Full auto-detection |
| Extensibility | Limited | Unlimited (runtime) |
| Configuration | Some required | All optional |
| Data Types | Manual/partial | 100% automatic |
| Flexibility Score | 6/10 | **10/10** |

### New Files in V7

| File | Purpose |
|------|---------|
| `VERSION_7_RELEASE_NOTES.md` | Complete flexible architecture docs (291 lines) |
| `VERSION7_ENHANCEMENT_SUMMARY.md` | 26-method robust detection summary (400 lines) |
| `VERSION_7_IMPLEMENTATION_SUMMARY.md` | Implementation details (500 lines) |
| `DETECTION_METHODS_SPECIFICATION.md` | Complete 26-method specification |
| `ROBUST_EXECUTION_GUIDE.md` | Implementation guide with examples |
| `DATA_PROCESSING_ENHANCEMENTS.md` | 9-step pipeline enhancement docs |
| `_patch_ds.py` | Data sources page patcher |

---

## 9. Version 8 — Role-Based Column Resolution & Audit

**Directory**: `FCDAI_Annomaly_auto_detection_version8/`  
**Version**: 8.0.0  
**Port**: 8070

### What Changed from V7

V8 was a **production-readiness release** focused on eliminating ALL hardcoded column names, adding enterprise audit trail infrastructure, and enforcing memory safety.

### Key Enhancements

#### 1. Role-Based Column Configuration (`ColumnRoleConfig`)

Completely eliminated hardcoded column names. The system resolves columns by **semantic role**, never by name.

```python
ROLE_ALIASES = {
    "primary_key":  ["cust_id", "customer_id", "party_id", "client_id", "entity_id"],
    "entity_name":  ["cust_name", "customer_name", "party_name", "full_name"],
    "amount":       ["amount", "txn_amount", "transaction_amount", "value", "amt"],
    "timestamp":    ["timestamp", "txn_date", "transaction_date", "date"],
    "account_key":  ["account_id", "acct_id", "account_number"],
    "txn_key":      ["txn_id", "transaction_id", "trans_id"],
    "txn_type":     ["txn_type", "transaction_type", "type"],
    "currency":     ["currency", "ccy", "currency_code"],
    "country":      ["country", "country_code", "jurisdiction"],
    "channel":      ["channel", "txn_channel", "payment_method"],
}
```

3-step resolution: (1) User overrides → (2) Exact alias match → (3) Partial match (case-insensitive)

#### 2. Resource Configuration (`ResourceConfig`)

Memory-safe limits for 8 GB CPU-only environments:

```python
@dataclass
class ResourceConfig:
    MAX_ROWS_FOR_HEAVY_METHODS: int = 5000   # LOF, HDBSCAN, Spectral limit
    MAX_FEATURES_FOR_PCA: int = 100
    MAX_MEMORY_MB: int = 4096
```

#### 3. Audit & Data Lineage Configuration

```python
@dataclass
class AuditConfig:
    ENABLE_DATA_LINEAGE: bool = True
    ENABLE_RUN_VERSIONING: bool = True
    ENABLE_HASH_CHAIN_LOGS: bool = True
    LOG_ROTATION_MAX_BYTES: int = 10_000_000  # 10MB
    HASH_ALGORITHM: str = "sha256"
    CAPTURE_CONFIG_SNAPSHOT: bool = True
```

#### 4. New UI Pages

| Page | Route | Purpose |
|------|-------|---------|
| **Admin** | `/admin` | User management (new) |
| **Config Panel** | `/config` | Runtime configuration (new) |

Total pages: 12 (up from 11)

#### 5. New Utilities

| Utility | Purpose |
|---------|---------|
| `utils/column_resolver.py` | Column role resolution engine |
| `utils/type_specific_imputer.py` | Type-aware missing data imputation |
| `utils/method_config_generator.py` | Auto-generate method configurations |
| `utils/data_gen.py` | Enhanced synthetic data generator |

#### 6. Air-Gap Enforcement

- PII masking at storage and export levels
- Hash-chain tamper-evident audit logging
- Run versioning with data lineage
- Zero-telemetry enforcement in app.py

### File Inventory Growth

```
V7 utils/: 7 files → V8 utils/: 14 files (+7 new)
V7 pages/: 11 pages → V8 pages/: 12 pages (+admin, +config_panel, -system_health)
```

---

## 10. Version 9 — VAT Audit & FMEA Fixes

**Directory**: `FCDAI_Annomaly_auto_detection_version9/`  
**Version**: 9.0.0  
**Port**: 8070

### What Changed from V8

V9 was a **quality assurance release** driven by a comprehensive **FMEA (Failure Mode and Effects Analysis)** audit. It addressed the highest-risk findings from the FMEA table and introduced formal testing.

### FMEA Analysis (IEC 60812 / AIAG FMEA 4th Edition)

20 failure modes were documented with RPN (Risk Priority Number) analysis:

| Priority | RPN Range | Count | Top Items |
|----------|-----------|-------|-----------|
| **CRITICAL** | ≥ 150 | 3 | FM-006 (PII exposure, RPN 240), FM-015 (hardcoded contamination, RPN 180), FM-001 (static thresholds, RPN 135) |
| **HIGH** | 100-149 | 4 | FM-020 (VAE KL fix, 144), FM-003 (tier boundary, 140), FM-007 (hash chain reset, 128), FM-008 (in-memory PII, 126) |
| **MEDIUM** | 50-99 | 5 | FM-004, FM-005, FM-010, FM-013, FM-009 |
| **LOW** | < 50 | 8 | FM-002, FM-018, FM-016, FM-011, FM-012, FM-019, FM-014, FM-017 |

### V9 Fixes (Addressing Top FMEA Findings)

| FMEA ID | RPN | Fix Applied |
|---------|-----|------------|
| **FM-006** | 240 | **PII masking enabled by default** — changed `ENABLED_BY_DEFAULT = True` in config.py |
| **FM-007** | 128 | **Hash chain persistence** — persist `_prev_hash` to `logs/.hash_state`; reload on restart |
| **FM-003** | 140 | **Risk tier ε-tolerance** — added `RISK_TIER_EPSILON: float = 1e-9` for float boundary protection |
| **FM-010** | 90 | **CSV formula injection protection** — prefix cells starting with `=+@-` with `'` character |
| **FM-009** | 84 | **Upload size validation** — added `MAX_UPLOAD_SIZE_MB: int = 100` |
| **FM-020** | 144 | **VAE KL divergence backprop fix** — KL gradient now included in training loss |
| **FM-008** | 126 | **In-memory PII masking** — mask in-memory copies in data vault, not just disk |

### New Audit Config Fields (V9)

```python
@dataclass
class AuditConfig:
    # ... V8 fields retained ...
    PERSIST_HASH_CHAIN: bool = True       # FM-007: persist hash state across restarts
    MAX_UPLOAD_SIZE_MB: int = 100          # FM-009: upload size limit
    RISK_TIER_EPSILON: float = 1e-9        # FM-003: float boundary tolerance
```

### VAT Checklist (273 Lines)

Comprehensive Validation · Audit · Testing plan covering:

| Section | Checks |
|---------|--------|
| 1.1 Multi-Page Routing | 6 checks (all pages load, URL routing, nav links, back/forward) |
| 1.2 State Persistence | 7 checks (DataVault sync, data persistence, dcc.Store limits) |
| 1.3 Callback Efficiency | 7 checks (no MATCH patterns, no blocking, no memory leaks) |
| 1.4 Component Interactivity | 10 checks (AG Grid, theme switcher, Plotly, search, filters) |
| 1.5 Data Sources | 7 checks (12 table slots, sample data, cross-table consistency) |
| 2.x Anomaly Detection | Synthetic injection testing, score validation |
| 3.x Security | PII masking, hash chain, upload validation |

### Formal Testing Added

| File | Purpose |
|------|---------|
| `tests/test_vat_suite.py` | Automated VAT test suite |
| `FMEA_TABLE.md` | Full FMEA analysis (92 lines, 20 failure modes) |
| `VAT_CHECKLIST.md` | Comprehensive VAT plan (273 lines) |

---

## 11. Version 10 — Production Core (SQLite, Auth, RBAC)

**Directory**: `FCDAI_Annomaly_auto_detection_version10/`  
**Version**: 10.0.0  
**Port**: 8070

### What Changed from V9

V10 was the **most significant infrastructure upgrade** — adding persistent database storage, multi-user authentication, role-based access control, encryption, and background task execution.

### Key Enhancements

#### 1. SQLite + SQLAlchemy Backend

```python
@dataclass
class DatabaseConfig:
    DB_NAME: str = "sentinel_vault.db"
    WAL_MODE: bool = True                 # Write-Ahead Logging for concurrency
    ECHO_SQL: bool = False
    POOL_PRE_PING: bool = True
    BUSY_TIMEOUT_MS: int = 5000
    CACHE_SIZE_KB: int = 64000            # 64 MB page cache
    SYNC_ANOMALIES_TO_DB: bool = True     # Write scored data to anomalies table
    SYNC_AUDIT_TO_DB: bool = True         # Write audit entries to DB
```

New `database/` directory:
- `engine.py` — SQLAlchemy engine initialization with WAL mode
- `models.py` — ORM models (User, AnomalyRecord, AuditEntry, etc.)

#### 2. Flask-Login Multi-User Authentication

```python
@dataclass
class AuthConfig:
    ENABLED: bool = True
    SESSION_LIFETIME_MINUTES: int = 480   # 8 hours
    PASSWORD_HASH_METHOD: str = "pbkdf2:sha256"
    DEFAULT_ADMIN_USER: str = "admin"
    DEFAULT_ADMIN_PASS: str = "admin123"
    ROLES: ["admin", "investigator", "viewer"]
```

New `auth/` directory:
- `manager.py` — Flask-Login initialization and login manager

#### 3. Role-Based Access Control (RBAC)

| Role | Accessible Pages |
|------|-----------------|
| **admin** | All pages (`*`) |
| **investigator** | Dashboard, Sources, Pipeline, Layers, Queue, Narratives, Audit, Vault, Diagnostics, Explainability |
| **viewer** | Dashboard, Layers, Audit, Diagnostics, Explainability |

#### 4. Fernet Encryption for PII at Rest

```python
@dataclass
class CryptoConfig:
    ENCRYPT_PII_AT_REST: bool = True       # Fernet-encrypt PII columns
    HASH_ENTITY_IDS: bool = True           # SHA-256 hash entity_id
    KEY_FILE: str = ".vault_key"           # Fernet key file
    HASH_SALT: str = "aim-ai-vault-v10"    # Salt for hashing
    AUTO_ROTATE_DAYS: int = 90             # Key rotation reminder
```

New utility: `utils/crypto.py` — Fernet encryption and SHA-256 hashing

#### 5. Diskcache Background Task Queue

```python
@dataclass
class TaskConfig:
    CACHE_DIR: str = "cache/task_queue"
    EXPIRE_SECONDS: int = 3600             # 1 hour TTL
    MAX_RETRIES: int = 2
    POLL_INTERVAL_MS: int = 2000           # UI polling interval
```

Pipeline runs execute in background → UI remains responsive → poll for status.

#### 6. Polars Fast Data Ingestion

Added `polars>=0.20.0` to requirements — optional fast CSV ingest with fallback to pandas.

#### 7. Zero-Leakage Network Protection

```python
# app.py — V10
os.environ["PLOTLY_RENDERER"] = "notebook_connected"
import plotly.io as pio
pio.renderers.default = "browser"
plotly.io.orca.config.use_xvfb = False  # No external calls

# Assets ignore pattern
assets_ignore=r'.*external.*|.*cdn.*|.*googleapis.*|.*gstatic.*'
```

#### 8. Enhanced Theme System (12 Themes)

Extended from 6 to **12 premium themes** (7 dark + 3 light + 2 premium):

| Theme | Style | Color Scheme |
|-------|-------|-------------|
| Sentinel Dark | System default | Dark |
| Midnight Blue | Deep indigo | Dark |
| Emerald Dark | Forest green | Dark |
| Rose Gold | Pink tones | Dark |
| Sunset Amber | Warm orange | Dark |
| Ocean Deep | Teal/cyan | Dark |
| Lavender | Purple haze | Dark |
| Arctic Light | Cool blue | Light |
| Cream Light | Warm neutral | Light |
| Silver Light | Professional gray | Light |
| Neon | Electric accents | Dark |
| Matrix | Green terminal | Dark |

Each theme includes: primaryColor, colorScheme, bgColor, cardBg, paperBg, borderColor, textPrimary, textSecondary, accentGradient, plotlyTemplate, agGridClass, sidebarText.

### New UI Pages in V10

| Page | Route | Purpose |
|------|-------|---------|
| **Login** | `/login` | Authentication gate |
| **Task Manager** | `/tasks` | Background pipeline task monitoring |

Total pages: 14

### New Dependencies (V10)

| Package | License | Purpose |
|---------|---------|---------|
| `SQLAlchemy>=2.0.0` | MIT | ORM + SQLite WAL backend |
| `Flask-Login>=0.6.0` | MIT | Session auth + RBAC |
| `passlib>=1.7.4` | BSD | Password hashing (pbkdf2) |
| `cryptography>=41.0.0` | Apache/BSD | Fernet PII encryption |
| `polars>=0.20.0` | MIT | Fast CSV ingest |

### App.py Growth

```
V3/V4: 216 lines → V5/V6/V7: ~440 lines → V10: 793 lines
```

### Complete Directory Structure (V10)

```
FCDAI_Annomaly_auto_detection_version10/
├── app.py                    # Main application (793 lines, 12 themes, login gating)
├── config.py                 # Configuration (431 lines, 13 dataclass configs)
├── pipeline.py               # Pipeline orchestrator
├── pipeline_runner.py        # CLI pipeline runner
├── verify_scalability.py     # Scalability test
├── diagnostic_trace.py       # Data flow diagnostics
├── README.md
├── requirements.txt          # 18+ packages
│
├── auth/                     # NEW: Authentication
│   ├── __init__.py
│   └── manager.py            # Flask-Login setup
│
├── database/                 # NEW: Persistent storage
│   ├── __init__.py
│   ├── engine.py             # SQLAlchemy engine (WAL mode)
│   └── models.py             # ORM models
│
├── layers/                   # 7-layer pipeline modules
│   ├── l1_l2_ingestion.py
│   ├── l3_feature_engineering.py
│   ├── l4_preprocessing.py
│   ├── l5_detection.py
│   ├── l6_ensemble.py
│   ├── l7_output.py
│   └── __init__.py
│
├── pages/                    # 14 UI pages
│   ├── admin.py              # User management
│   ├── audit_trail.py        # Log viewer
│   ├── audit_vault.py        # Encrypted vault viewer
│   ├── config_panel.py       # Runtime config
│   ├── dashboard.py          # Risk overview
│   ├── data_sources.py       # Multi-source upload
│   ├── explainability.py     # Method contributions
│   ├── investigation_queue.py # Alert management
│   ├── layer_view.py         # Layer inspection
│   ├── login.py              # NEW: Authentication page
│   ├── model_diagnostics.py  # Method performance
│   ├── narratives.py         # Auto narratives
│   ├── pipeline_run.py       # Execute pipeline
│   └── task_manager.py       # NEW: Background tasks
│
├── utils/                    # 15 utility modules
│   ├── auto_params.py        # Adaptive parameters
│   ├── column_resolver.py    # Role-based column resolution
│   ├── crypto.py             # NEW: Fernet + SHA-256
│   ├── customer_aggregation.py
│   ├── data_gen.py           # Synthetic data generator
│   ├── data_io.py            # Data vault I/O
│   ├── explainability.py     # Feature importance
│   ├── forensic_export.py    # Audit exports
│   ├── generate_data.py      # Legacy data generator
│   ├── logger.py             # Hash-chain audit logger
│   ├── method_config_generator.py
│   ├── pii_masking.py        # PII protection
│   ├── schema_detector.py    # Auto type detection
│   ├── type_specific_imputer.py
│   └── __init__.py
│
├── tests/                    # VAT test suite
│   └── test_vat_suite.py
│
├── assets/                   # CSS/JS (served locally)
├── cache/                    # Diskcache + task queue
├── data/                     # vault/, sources/, exports/
├── logs/                     # Audit logs + .hash_state
└── models/                   # Saved ML models
```

---

## 12. Evolution Summary: V1 → V10

### Version Timeline

```
V1  ──▶  V2  ──▶  V3  ──▶  V4  ──▶  V5  ──▶  V6  ──▶  V7  ──▶  V8  ──▶  V9  ──▶  V10
│        │        │        │        │        │        │        │        │        │
Proto    Dash     PII      Scale    Themes   Customer Flexible Roles    FMEA     SQLite
type     Migr.    Masking  Testing  +Prod    Level    Arch     Column   Audit    Auth
Strmlt   DMC      Vault    Runner   Harden   Detect   Schema   Resolve  Fixes    RBAC
         AG Grid  Export   CLI      6 Theme  Tiered   Auto     Memory   VAT      Fernet
                                    Client   Consens  Detect   SafetyAudit      12Theme
                                             80+feat  Config   Lineage  Test     BgTask
```

### Key Metrics Growth

| Metric | V1 | V2 | V3 | V4 | V5 | V6 | V7 | V8 | V9 | V10 |
|--------|----|----|----|----|----|----|----|----|----|----|
| Framework | Streamlit | Dash | Dash | Dash | Dash | Dash | Dash | Dash | Dash | Dash |
| Detection Methods | 26 | 26 | 35+ | 35+ | 35+ | 25 | 26 | 26 | 26 | 26 |
| UI Pages | ~8 | ~9 | 11 | 11 | 11 | 11 | 11 | 12 | 12 | 14 |
| Themes | 1 | 1 | 1 | 1 | 6 | 6 | 6 | 6 | 6 | 12 |
| app.py Lines | ~150 | ~200 | 216 | 216 | 444 | 437 | 436 | 445 | 445 | 793 |
| config.py Lines | ~107 | ~147 | 217 | 228 | 228 | 265 | 265 | 326 | 338 | 431 |
| Utils Files | ~4 | ~5 | 7 | 7 | 7 | 8 | 9 | 14 | 14 | 15 |
| Auth/RBAC | No | No | No | No | No | No | No | No | No | **Yes** |
| Database | None | None | None | None | None | None | None | None | None | **SQLite** |
| Encryption | No | No | No | No | No | No | No | No | No | **Fernet** |
| Background Tasks | No | No | No | No | No | No | No | No | No | **Yes** |
| Testing | No | No | No | No | No | No | No | No | **VAT** | VAT |
| Processing Level | Txn | Txn | Txn | Txn | Txn | **Customer** | Customer | Customer | Customer | Customer |

### Architectural Milestones

| Version | Milestone |
|---------|-----------|
| V1 → V2 | **Framework migration**: Streamlit → Dash (callback-driven) |
| V2 → V3 | **Security foundation**: PII masking, data vault, forensic exports |
| V3 → V4 | **Testability**: Standalone pipeline runner, scalability verification |
| V4 → V5 | **UX maturity**: Multi-theme, clientside callbacks, production hardening |
| V5 → V6 | **Detection paradigm shift**: Transaction → Customer-level processing |
| V6 → V7 | **Data flexibility**: Any schema, auto-detection, zero hardcoded names |
| V7 → V8 | **Enterprise readiness**: Role-based columns, audit lineage, memory safety |
| V8 → V9 | **Quality assurance**: FMEA analysis, VAT checklist, formal testing |
| V9 → V10 | **Production infrastructure**: SQLite, Flask-Login, RBAC, Fernet, Polars |

---

## 13. Directory & File Inventory

### Directory Locations

| Version | Directory | Exists |
|---------|-----------|--------|
| V1 | `fcdai_7layer_streamlit/` | Yes |
| V2 | `fcdai_7layer_dash/` | Yes |
| V3 | `FCDAI_Annomaly_auto_detection_version3/` | Yes |
| V4 | `FCDAI_Annomaly_auto_detection_version4/` | Yes |
| V5 | `FCDAI_Annomaly_auto_detection_version5/` | Yes |
| V6 | `FCDAI_Annomaly_auto_detection_version6/` | Yes |
| V7 | `FCDAI_Annomaly_auto_detection_version7/` | Yes |
| V8 | `FCDAI_Annomaly_auto_detection_version8/` | Yes |
| V9 | `FCDAI_Annomaly_auto_detection_version9/` | Yes |
| V10 | `FCDAI_Annomaly_auto_detection_version10/` | Yes |

**Note**: V1 and V2 directories do not follow the `FCDAI_Annomaly_auto_detection_versionN` naming convention. The versioned naming started at V3.

### Files Added Per Version

| Version | New Files |
|---------|-----------|
| V1 | `app.py`, `config.py`, `pipeline.py`, `requirements.txt`, `README.md`, layers/ (6), pages/ (~8), utils/ (~4) = **~25 files** |
| V2 | Rewritten from V1: same structure, new framework code, added `assets/`, `cache/` = **~25 files** |
| V3 | `utils/pii_masking.py`, `utils/forensic_export.py`, `pages/audit_vault.py`, `pages/system_health.py` = **+4 files** |
| V4 | `pipeline_runner.py`, `verify_scalability.py` = **+2 files** |
| V5 | Theme expansion in `app.py` (no new files, major rewrite of existing) |
| V6 | `VERSION_6_RELEASE_NOTES.md`, `DIAGNOSTIC_REPORT.md`, `diagnostic_trace.py` = **+3 files** |
| V7 | `utils/schema_detector.py`, `utils/auto_params.py`, `_patch_ds.py`, 6 markdown docs = **+9 files** |
| V8 | `pages/admin.py`, `pages/config_panel.py`, `utils/column_resolver.py`, `utils/type_specific_imputer.py`, `utils/method_config_generator.py`, `utils/data_gen.py` = **+6 files** |
| V9 | `tests/test_vat_suite.py`, `FMEA_TABLE.md`, `VAT_CHECKLIST.md` = **+3 files** |
| V10 | `auth/manager.py`, `database/engine.py`, `database/models.py`, `utils/crypto.py`, `pages/login.py`, `pages/task_manager.py` = **+6 files** |

---

## 14. Detection Methods Evolution

### Method Count by Version

| Version | Statistical | Distance | Density | Clustering | Trees | Time-Series | Graph | Deep Learning | SVM | Total |
|---------|------------|----------|---------|------------|-------|------------|-------|--------------|-----|-------|
| V1-V2 | 5 | 3 | 4 | 3 | 2 | 3 | 4 | 2 | — | **26** |
| V3-V4 | 9* | 3 | 4 | 3 | 2 | 4* | 4 | 3* | 1* | **33+*** |
| V5 | 9 | 3 | 4 | 3 | 2 | 4 | 4 | 3 | 1 | **33+** |
| V6 | 5 | 3 | 4 | 3 | 2 | 3 | 4 | 2 | — | **25**† |
| V7-V10 | 5 | 3 | 4 | 3 | 2 | 3 | 4 | 2 | — | **26** |

*V3 expanded config to include COPOD, ECOD, HBOS, MCD, SOM, Matrix Profile, One-Class SVM — superset defined in config but not all executed per run*  
†V6 reduced by 1 due to cleanup of rarely-used method

### Ensemble Evolution

| Version | Ensemble Method | Risk Tier Logic |
|---------|----------------|-----------------|
| V1-V5 | Weighted Average | Score-only thresholds: Critical(0.9-1.0), High(0.7-0.9), Medium(0.5-0.7), Low(0-0.5) |
| V6-V10 | **Tiered Consensus** | Score OR Votes: Critical(≥0.95 OR ≥23), High(≥0.85 OR ≥18), Medium(≥0.70 OR ≥12), Low(≥0.50 OR ≥8) |

### Method Weights (Introduced V6)

| Method | Weight | Rationale |
|--------|--------|-----------|
| benford | 2.0 | Structuring-specific — highest AML relevance |
| isolation_forest | 1.5 | Production-proven reliable detector |
| lof | 1.5 | Effective density-based anomaly detection |
| extended_if | 1.3 | Enhanced isolated forest variant |
| hdbscan | 1.2 | Robust clustering detector |
| community | 1.2 | Network structure detector |
| autoencoder | 0.8 | Experimental — lower confidence |
| vae | 0.8 | Experimental — lower confidence |
| lstm_ae | 0.5 | Most experimental — lowest weight |
| *others* | 1.0 | Baseline weight |

---

## 15. Configuration Evolution

### Config Dataclasses by Version

| Dataclass | V1 | V2 | V3 | V4 | V5 | V6 | V7 | V8 | V9 | V10 |
|-----------|----|----|----|----|----|----|----|----|----|----|
| PathConfig | Y | Y | Y | Y | Y | Y | Y | Y | Y | Y |
| ThemeConfig | Y | Y | Y | Y | Y | Y | Y | Y | Y | Y |
| LayerConfig | Y | Y | Y | Y | Y | Y | Y | Y | Y | Y |
| AppConfig | — | Y | Y | Y | Y | Y | Y | Y | Y | Y |
| DataSourceConfig | — | Y | Y | Y | Y | Y | Y | Y | Y | Y |
| PIIConfig | — | — | **Y** | Y | Y | Y | Y | Y | Y | Y |
| ColumnRoleConfig | — | — | — | — | — | — | — | **Y** | Y | Y |
| ResourceConfig | — | — | — | — | — | — | — | **Y** | Y | Y |
| AuditConfig | — | — | — | — | — | — | — | **Y** | Y | Y |
| DatabaseConfig | — | — | — | — | — | — | — | — | — | **Y** |
| AuthConfig | — | — | — | — | — | — | — | — | — | **Y** |
| TaskConfig | — | — | — | — | — | — | — | — | — | **Y** |
| CryptoConfig | — | — | — | — | — | — | — | — | — | **Y** |

**Total config dataclasses**: V1=3 → V2=5 → V3=6 → V8=9 → V10=**13**

---

## 16. Port Assignment History

| Version | Port | Notes |
|---------|------|-------|
| V1 | 8501 | Streamlit default |
| V2 | 8071 | First Dash port |
| V3 | 8085 | — |
| V4 | 8090 | Avoided V3 conflict |
| V5 | 8097 | — |
| V6 | 8109 | — |
| V7 | 8055 | — |
| V8 | 8070 | Stabilized |
| V9 | 8070 | Same as V8 |
| V10 | 8070 | Same as V8/V9 |

**Note**: From V8 onwards, port stabilized at 8070. Each version can be run simultaneously by changing the port in config.py.

---

## 17. Dependencies Evolution

### Core Dependencies (Present Since V2)

| Package | Purpose | License |
|---------|---------|---------|
| dash | Web framework | MIT |
| dash-mantine-components | UI components | MIT |
| dash-iconify | Icon library | MIT |
| dash-ag-grid | Data grid | MIT |
| plotly | Charting | MIT |
| pandas | Data processing | BSD |
| numpy | Numerical computing | BSD |
| pyarrow | Parquet support | Apache |
| openpyxl | Excel support | MIT |
| scikit-learn | ML algorithms | BSD |
| scipy | Scientific computing | BSD |
| hdbscan | Clustering | BSD |
| pyod | Outlier detection | BSD |
| psutil | System monitoring | BSD |
| diskcache | Caching | Apache |

### Dependencies Added Per Version

| Version | New Dependencies |
|---------|-----------------|
| V1 | streamlit, plotly, pandas, numpy, scikit-learn, scipy |
| V2 | dash, dash-mantine-components, dash-iconify, dash-ag-grid, diskcache, pyarrow, openpyxl, hdbscan, pyod, psutil |
| V3-V9 | No new dependencies (code-only changes) |
| V10 | **SQLAlchemy** (ORM), **Flask-Login** (auth), **passlib** (password hashing), **cryptography** (Fernet), **polars** (fast ingest) |

### License Compliance

All dependencies use **commercial-friendly licenses** (BSD, MIT, Apache) — no GPL, no copyleft restrictions. This is critical for the air-gapped bank deployment.

---

## Appendix: Existing Documentation Files by Version

### V3-V5
- `README.md` — Architecture diagram + file list (109 lines each)

### V6
- `README.md` — Same architecture diagram
- `VERSION_6_RELEASE_NOTES.md` — Customer-level detection release notes (339 lines)
- `DIAGNOSTIC_REPORT.md` — Issue investigation report (285 lines)

### V7
- `README.md`
- `VERSION_6_RELEASE_NOTES.md` (carried forward)
- `VERSION_7_RELEASE_NOTES.md` — Flexible architecture release notes (291 lines)
- `VERSION7_ENHANCEMENT_SUMMARY.md` — 26-method robust detection (400 lines)
- `VERSION_7_IMPLEMENTATION_SUMMARY.md` — Implementation details (500 lines)
- `DETECTION_METHODS_SPECIFICATION.md` — Complete 26-method spec
- `ROBUST_EXECUTION_GUIDE.md` — Execution guide with examples
- `DATA_PROCESSING_ENHANCEMENTS.md` — 9-step pipeline enhancements
- `DIAGNOSTIC_REPORT.md` (carried forward)

### V8
- Same docs as V7 (carried forward from copy)

### V9
- Same docs as V8 plus:
- `FMEA_TABLE.md` — Failure Mode and Effects Analysis (92 lines, 20 failure modes)
- `VAT_CHECKLIST.md` — Validation Audit Testing plan (273 lines)

### V10
- All V9 docs carried forward plus database/auth docs embedded in code

### Root-Level Documentation (Project-Wide)

| File | Content | Lines |
|------|---------|-------|
| `FCDAI_DOCUMENTATION.md` | Project structure guide (Apex + 7-Layer) | 446 |
| `FCDAI_LAYER_REFERENCE.md` | Layer-by-layer technical reference | 473 |
| `FCDAI_TECHNICAL_LEARNINGS.md` | Technical mastery guide (paradigms, graph analysis, web dev) | 149 |
| `FCDAI_ANNOTATED_CODE.md` | Annotated code walkthrough | — |
| `COMPREHENSIVE_BANK_PIPELINES_LANDSCAPE.md` | AML pipelines landscape document | — |
| `BRANDING_GUIDE.md` | UI branding standards | — |
| `ENTERPRISE_INTEGRATION_GUIDE.md` | Enterprise integration patterns | — |
| `FRAMEWORK_COMPARISON.md` | Dash vs Streamlit vs Reflex comparison | — |
| `TUTORIAL.md` | User tutorial | — |

---

**End of V1-V10 Documentation**

*This document covers the complete evolution of FCDAI from the initial Streamlit prototype (V1) through the production-ready core (V10). For V10-V17 documentation, see `VERSION_HISTORY_COMPLETE.md`.*
