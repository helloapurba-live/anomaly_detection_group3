# FCDAI AML Detection System — Complete Evolution V1 to V17

## Master Documentation: 17 Versions, 7 Paradigm Shifts, Enterprise Production System

**Project**: FCDAI (Financial Crime Detection AI) Anomaly Auto Detection  
**Document Date**: February 15, 2026  
**Scope**: Complete evolution from V1 (Streamlit prototype) through V17 (Full enterprise deployment)  
**Environment**: Air-gapped Windows 11, Python 3.11, CPU-only  
**Classification**: CONFIDENTIAL — INTERNAL BANK USE ONLY

---

## Executive Summary

This document chronicles the complete evolution of the FCDAI AML Detection System across **17 major versions** spanning 13 months of development. The system evolved from a simple Streamlit prototype (V1, 150 lines) to a production-grade enterprise platform (V17, 800+ lines main app) with:

- **7-layer detection pipeline** — 26 unsupervised anomaly detection methods
- **Customer-level processing** — 90% data reduction, 17% faster execution
- **ANY schema support** — Flexible detection without hardcoded column names
- **Enterprise security** — SQLite + RBAC + Fernet encryption + audit trails
- **Dual interface** — Web dashboard (Dash) + REST API (FastAPI)
- **Bank audit compliance** — 42+ critical fixes across V9, V12, V16
- **100K scalability** — Validated on 100,000 transaction stress tests

---

## Table of Contents

### Part 1: Foundation (V1-V5)
1. [V1 — Streamlit Prototype](#v1--streamlit-prototype)
2. [V2 — Dash Migration](#v2--dash-migration)
3. [V3 — PII Vault](#v3--pii-vault)
4. [V4 — Scalability](#v4--scalability)
5. [V5 — Production Hardening](#v5--production-hardening)

### Part 2: Paradigm Shifts (V6-V10)
6. [V6 — Customer-Level Processing](#v6--customer-level-processing)
7. [V7 — Schema Flexibility](#v7--schema-flexibility)
8. [V8 — Column Roles & Audit](#v8--column-roles--audit)
9. [V9 — VAT & FMEA](#v9--vat--fmea)
10. [V10 — Production Core (SQLite + Auth)](#v10--production-core)

### Part 3: Enterprise Features (V11-V17)
11. [V11 — Feature Expansion](#v11--feature-expansion)
12. [V12 — Bank Audit Compliance](#v12--bank-audit-compliance)
13. [V13 — Health Audit](#v13--health-audit)
14. [V14 — Enterprise Hardening](#v14--enterprise-hardening)
15. [V15 — REST API](#v15--rest-api)
16. [V16 — Enhanced Security (A4/A5/A6)](#v16--enhanced-security)
17. [V17 — Full Wiring](#v17--full-wiring)

### Part 4: Reference
18. [Evolution Metrics](#evolution-metrics)
19. [Architecture Diagrams](#architecture-diagrams)
20. [Database Schema](#database-schema)
21. [Configuration Reference](#configuration-reference)
22. [Comparison Tables](#comparison-tables)
23. [Code Examples](#code-examples)
24. [Migration Guides](#migration-guides)

---

## Quick Version Comparison

| Version | Date | Key Focus | Lines (app.py) | Paradigm Shift? |
|---------|------|-----------|----------------|-----------------|
| V1 | Jan 2025 | Streamlit prototype | 150 | ✓ Architecture |
| V2 | Jan 2025 | Dash migration | 200 | ✓ Framework |
| V3 | Jan 2025 | PII vault | 216 | — |
| V4 | Jan 2025 | 100K scalability | 216 | — |
| V5 | Jan-Feb 2025 | 6 themes | 444 | — |
| V6 | Feb 2026 | Customer-level | 444 | ✓ Processing |
| V7 | Feb 2026 | ANY schema | 444 | ✓ Flexibility |
| V8 | Feb 2026 | Column roles | 445 | — |
| V9 | Feb 2026 | FMEA fixes | 445 | — |
| V10 | Feb 2026 | SQLite + Auth | 793 | ✓ Infrastructure |
| V11-V17 | Feb 2026 | Enterprise features | ~800 | — |

---

# Part 1: Foundation (V1-V5)

## V1 — Streamlit Prototype

**Release**: January 15, 2025  
**Status**: ✓ Complete (superseded by V2)

### Purpose

Prove the 7-layer detection architecture concept with a functional prototype built in Streamlit.

### Key Features

- **Framework**: Streamlit (single-user script model)
- **Pipeline**: 7 layers × 26 detection methods established
- **UI**: 8 pages (Dashboard, Data Sources, Layer View, Investigation, Narratives, Audit, Diagnostics, Explainability)
- **Configuration**: 3 config classes (PathConfig, ThemeConfig, LayerConfig)
- **Data**: CSV upload + Parquet storage
- **Output**: CSV download
- **Port**: 8501 (Streamlit default)

### Architecture

```
┌─────────┐
│ User    │
└────┬────┘
     │ Upload CSV
┌────▼────────────┐
│ st.file_uploader│
└────┬────────────┘
     │
┌────▼────────────┐
│ AnomalyPipeline │
│ (26 methods)    │
└────┬────────────┘
     │
┌────▼────────────┐
│ st.dataframe()  │
│ st.download_btn │
└─────────────────┘
```

**Limitation**: Full page reload on every interaction.

### Performance Baseline

- **Test**: 10,000 transactions
- **Time**: ~2 minutes
- **Memory**: 800 MB

### What Worked Well

- Proved 7-layer architecture viable
- Fast prototyping with Streamlit
- All 26 methods operational

### What Didn't Work

- ❌ Full page reloads slow user experience
- ❌ No state persistence between sessions
- ❌ Single-user only (no auth)
- ❌ Limited UI customization

### Migration Path to V2

→ See [CHANGELOG.md](CHANGELOG.md#from-v1-to-v2-streamlit-to-dash)

---

## V2 — Dash Migration

**Release**: January 20, 2025  
**Status**: ✓ Complete

### Purpose

Rewrite from Streamlit to Dash for reactive UI without page reloads.

### Key Changes

**Framework**:
- ✓ Dash + Dash Mantine Components (DMC)
- ✓ AG Grid for high-performance data tables
- ✓ Callback-driven reactive architecture
- ✓ `dcc.Store` for client-side state management
- ✓ Diskcache for result persistence

**Performance**:
- 10x faster UI updates (no page reload)
- AG Grid handles 100K+ rows smoothly
- Clientside callbacks for instant responses

**Port**: 8071

### Callback Pattern Example

```python
@callback(
    Output("grid", "rowData"),
    Input("btn-run", "n_clicks"),
    State("store-data", "data"),
    prevent_initial_call=True
)
def run_pipeline(n_clicks, data):
    df = pd.DataFrame(data)
    pipeline = AnomalyPipeline()
    results = pipeline.run(df)
    return results.to_dict('records')
```

### What Worked Well

- ✓ Reactive UI eliminated page reloads
- ✓ DMC components modern and consistent
- ✓ AG Grid performance excellent
- ✓ Diskcache reliable for result persistence

### What Didn't Work

- Limited theme customization (fixed in V5)
- No PII masking (fixed in V3)

---

## V3 — PII Vault

**Release**: January 25, 2025  
**Status**: ✓ Complete

### Purpose

Add PII masking, data vault directory structure, forensic exports.

### Key Additions

**PIIConfig Class**:
```python
@dataclass
class PIIConfig:
    enable_pii_masking: bool = False  # ⚠️ Changed to True in V9
    show_prefix: int = 2
    show_suffix: int = 2
    pii_columns: list = ['customer_id', 'account_number', 'ssn']
```

**Show-Edges Masking**:
- Input: `"1234567890"`
- Output: `"12****90"` (show 2 prefix, 2 suffix)

**Data Vault Structure**:
```
data/
  vault/
    current.parquet       # Current run scored data
    scored.parquet        # Historical scored data
    forensic/
      2025-01-25_export.parquet
      2025-01-26_export.parquet
```

**Port**: 8085

### What Worked Well

- ✓ PII masking prevents full exposure
- ✓ Show-edges allow verification
- ✓ Vault structure supports forensics

### What Didn't Work

- ⚠️ PII masking **disabled by default** (security issue fixed in V9)

---

## V4 — Scalability

**Release**: February 1, 2025  
**Status**: ✓ Complete

### Purpose

Validate 100K transaction scalability, add CLI runner.

### Key Additions

**pipeline_runner.py** — CLI for batch execution:
```bash
python pipeline_runner.py \
    --input data/transactions.csv \
    --output results/ \
    --threshold 0.9 \
    --skip-layers 2 6
```

**verify_scalability.py** — Stress test script:
```python
# Generate 100,000 synthetic transactions
df = generate_test_data(n=100000)

# Run pipeline
pipeline = AnomalyPipeline()
results = pipeline.run(df)

# Measure
print(f"Time: {elapsed:.1f}s")
print(f"Memory: {memory_peak:.1f} MB")
```

### Performance Validation

| Metric | Value |
|--------|-------|
| **Records** | 100,000 transactions |
| **Time** | 12 minutes |
| **Throughput** | 139 txn/sec |
| **Memory Peak** | 2.5 GB |
| **Memory Avg** | 1.8 GB |
| **CPU Avg** | 85% |

✓ **PASSED**: System handles 100K transactions within acceptable limits on 8 GB RAM.

**Port**: 8090

### What Worked Well

- ✓ 100K scalability validated
- ✓ CLI runner enables automation
- ✓ Performance metrics documented

---

## V5 — Production Hardening

**Release**: February 5, 2025  
**Status**: ✓ Complete

### Purpose

Add 6-theme system, clientside callbacks, production polish.

### Key Additions

**6 Themes** (3 dark, 3 light):
- Dark: Default, Blue, Green
- Light: Default, Blue, Green

**Clientside Callback** for theme toggle:
```python
app.clientside_callback(
    """
    function(theme) {
        localStorage.setItem('fcdai-theme', theme);
        return {colorScheme: theme};
    }
    """,
    Output("theme-provider", "theme"),
    Input("theme-toggle", "value")
)
```

**Benefits**:
- ✓ Instant theme switching (0ms server latency)
- ✓ Theme persisted in localStorage
- ✓ No network roundtrip

**app.py Growth**: 216 lines → 444 lines (+106%)

**Port**: 8097

### What Worked Well

- ✓ Clientside callbacks eliminated lag
- ✓ localStorage persistence seamless
- ✓ Theme customization improved UX

---

# Part 2: Paradigm Shifts (V6-V10)

## V6 — Customer-Level Processing

**Release**: February 8, 2026  
**Status**: ✓ Complete  
**🔴 PARADIGM SHIFT**: Transaction → Customer detection

### Purpose

Transform processing from transaction-level to customer-level to reduce false positives and improve risk attribution.

### The Problem

- **V1-V5 approach**: Score 100,000 transactions individually
- **Issue**: 100K alerts impossible to investigate
- **Need**: Aggregate to customer level for meaningful risk assessment

### The Solution

**CustomerAggregator**:
```python
# Before V6: 100K transactions
txn_df = pipeline.run(transactions)  # 100K rows

# V6+: Customer aggregation
customer_df = aggregator.aggregate(txn_df)  # 10K customers
customer_df = pipeline.run(customer_df)  # Score 10K
```

**80+ Customer Features**:
- Volume: txn_count, total_amount, avg_amount, std_amount
- Time: days_active, avg_daily_txns, first_txn_date, last_txn_date
- Patterns: unique_counterparties, unique_channels, unique_countries
- Risk: max_alert_score, avg_alert_score, p95_alert_score
- Percentiles: amount_p25, amount_p50, amount_p75, amount_p95
- ...65 more features

### Performance Impact

| Metric | V5 (Txn) | V6 (Customer) | Change |
|--------|----------|---------------|--------|
| Records Processed | 100,000 | 10,000 | -90% |
| Execution Time | 12 min | 10 min | -17% |
| Memory Avg | 1.8 GB | 1.3 GB | -28% |
| Throughput | 139 txn/sec | 17 cust/sec | 10x per entity |

**Port**: 8109

### Tiered Consensus Ensemble

Instead of simple averaging, V6 introduces weighted tiers:

```python
# Tier 1: High precision methods (50% weight)
tier1 = ['hdbscan', 'lof', 'iforest']

# Tier 2: Medium precision methods (30% weight)
tier2 = ['knn', 'cblof', 'copod']

# Tier 3: Broad coverage methods (20% weight)
tier3 = ['pca', 'ocsvm', 'mcd']

composite_score = (
    0.5 * tier1_scores.mean() +
    0.3 * tier2_scores.mean() +
    0.2 * tier3_scores.mean()
)
```

### What Worked Well

- ✓ 90% data reduction improved performance
- ✓ Customer-level risk more meaningful
- ✓ False positive rate decreased
- ✓ Investigation queue manageable

### What Didn't Work

- Schema still assumed specific column names (fixed in V7)

---

## V7 — Schema Flexibility

**Release**: February 9, 2026  
**Status**: ✓ Complete  
**🔴 PARADIGM SHIFT**: ANY schema support

### Purpose

Remove all hardcoded column name assumptions, support ANY CSV schema with customer_id, amount, date columns.

### The Problem

- **V1-V6**: Hardcoded column names (`customer_id`, `amount`, `date`)
- **Issue**: Different banks use different schemas
- **Need**: Auto-detect column roles from ANY schema

### The Solution

**4 Core Principles**:
1. **MASTER-only**: Pipeline accepts only MASTER_* columns
2. **Unlimited extensibility**: Any number of columns supported
3. **Auto-detection**: SchemaDetector finds roles automatically
4. **Optional config**: Override with config file if needed

**SchemaDetector**:
```python
DETECTORS = {
    'MASTER_ID': [
        r'customer[_\s]?id',
        r'client[_\s]?id',
        r'account[_\s]?holder',
        r'entity[_\s]?id'
    ],
    'AMOUNT': [
        r'amount',
        r'value',
        r'transaction[_\s]?amount'
    ],
    'DATE': [
        r'date',
        r'timestamp',
        r'time',
        r'txn[_\s]?date'
    ],
    # ...5 more column types
}
```

**Usage**:
```python
detector = SchemaDetector()
schema = detector.detect(df)
# {'MASTER_ID': 'CustomerID',
#  'AMOUNT': 'TransactionAmount',
#  'DATE': 'TxnDate'}

df_master = transform_to_master_schema(df, schema)
```

**Port**: 8055

### What Worked Well

- ✓ Zero hardcoded assumptions
- ✓ Works with ANY bank schema
- ✓ Auto-detection reliable (8 column types)
- ✓ Config file override available

### What Didn't Work

- Column role resolution logic scattered (consolidated in V8)

---

## V8 — Column Roles & Audit

**Release**: February 9, 2026  
**Status**: ✓ Complete

### Purpose

Consolidate column role resolution into ColumnRoleConfig, add ResourceConfig and AuditConfig.

### Key Additions

**ColumnRoleConfig** — 3-step resolution:
1. Try config file (`columns.yaml`)
2. Auto-detect if config missing
3. Apply user overrides

```python
resolver = ColumnRoleResolver(
    config_path=Path('config/columns.yaml')
)
mapping = resolver.resolve(df)
```

**ResourceConfig** — Memory/CPU limits:
```python
@dataclass
class ResourceConfig:
    max_memory_mb: int = 4096
    max_cpu_percent: int = 95
    timeout_seconds: int = 1800
```

**AuditConfig** — Hash chain:
```python
@dataclass
class AuditConfig:
    enable_audit: bool = True
    hash_algorithm: str = 'sha256'
    persist_hash_state: bool = False  # ⚠️ Changed to True in V9
```

**config.py Growth**: 228 lines → 431 lines (+89%)

**Port**: 8070 (stabilized, used through V17)

### What Worked Well

- ✓ Column role resolution consolidated
- ✓ Resource limits prevent crashes
- ✓ Audit trail with hash chain

### What Didn't Work

- ⚠️ Hash chain state reset on restart (fixed in V9)

---

## V9 — VAT & FMEA

**Release**: February 10, 2026  
**Status**: ✓ Complete

### Purpose

Apply V1 Audit Tool (VAT) findings and Failure Mode Effects Analysis (FMEA) to fix 20 identified failure modes.

### FMEA Critical Fixes

**FM-006: PII Masking OFF by Default** (RPN 240, CRITICAL):
```python
# V8 and earlier
@dataclass
class PIIConfig:
    enable_pii_masking: bool = False  # ❌ SECURITY ISSUE

# V9 fix
@dataclass
class PIIConfig:
    enable_pii_masking: bool = True  # ✓ SAFE DEFAULT
```

**FM-007: Hash Chain Reset** (RPN 128, HIGH):
```python
# V8: Hash reset on restart
self.previous_hash = '0' * 64  # ❌ Lost audit trail

# V9 fix: Persistent state
def _load_previous_hash(self):
    if Path('audit/hash_state.json').exists():
        with open('audit/hash_state.json') as f:
            state = json.load(f)
            return state['last_hash']
    return '0' * 64
```

**FM-003: Float Comparison** (RPN 140, HIGH):
```python
# V8: Strict equality
if score1 == score2:  # ❌ Float precision issues

# V9 fix: Epsilon tolerance
if np.isclose(score1, score2, atol=1e-9):  # ✓ Robust
```

### VAT Checklist

**273 lines, 108 verification checks** covering:
- Data quality (48 checks)
- Pipeline execution (26 checks)
- Results validation (18 checks)
- Security compliance (16 checks)

### All 20 Failure Modes

| ID | Mode | Severity | RPN | Fix |
|----|------|----------|-----|-----|
| FM-006 | PII exposure | CRITICAL | 240 | Default mask ON |
| FM-007 | Hash reset | HIGH | 128 | Persistent state |
| FM-003 | Float boundary | HIGH | 140 | Epsilon tolerance |
| FM-001 | Upload size | MEDIUM | 108 | 100 MB limit |
| FM-002 | File type | MEDIUM | 90 | CSV/Excel only |
| FM-004 | Division by zero | MEDIUM | 96 | Safe division |
| FM-005 | Formula injection | MEDIUM | 84 | CSV sanitization |
| ...13 more | ... | LOW-MEDIUM | <80 | Various |

**Port**: 8070

### What Worked Well

- ✓ FMEA identified critical security gaps
- ✓ VAT checklist comprehensive
- ✓ All 20 failure modes addressed

---

## V10 — Production Core

**Release**: February 10, 2026  
**Status**: ✓ Complete  
**🔴 PARADIGM SHIFT**: Infrastructure transformation

### Purpose

Transform from prototype to production-ready platform with SQLite, authentication, RBAC, encryption.

### Key Additions

#### SQLite + SQLAlchemy

**4 Core Tables**:
- `users` — Authentication (username, password_hash, role, created_at)
- `anomalies` — Scored customers (customer_id_hash, composite_score, alert_flag)
- `audit_logs` — Hash chain (timestamp, user, action, previous_hash, current_hash)
- `alert_events` — Alerts (customer_id_hash, status, investigated_by, narrative)

**SQLAlchemy Models**:
```python
class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    username = Column(String(100), unique=True)
    password_hash = Column(String(255))
    role = Column(String(50))  # admin, investigator, viewer
    created_at = Column(DateTime, default=datetime.utcnow)
```

**WAL Mode**: Write-Ahead Logging for concurrent reads.

#### Flask-Login Authentication

```python
login_manager = LoginManager()
login_manager.init_app(server)
login_manager.login_view = '/login'

@login_manager.user_loader
def load_user(user_id):
    session = SessionLocal()
    user = session.query(UserModel).filter_by(id=int(user_id)).first()
    if user:
        return User(user.id, user.username, user.role)
    return None
```

**8-Hour Sessions**: Automatic timeout after 8 hours of inactivity.

#### RBAC (3 Roles)

| Role | Access |
|------|--------|
| **Admin** | All pages, user management, config changes |
| **Investigator** | Data analysis, investigation queue, narratives |
| **Viewer** | Read-only dashboards, reports, audit logs |

**RBAC Decorator**:
```python
@require_role('admin', 'investigator')
def layout():
    return html.Div([...])
```

#### Fernet Encryption

**256-bit AES-128-CBC** for sensitive data at rest:
```python
from cryptography.fernet import Fernet

cipher = Fernet(key)
encrypted_id = cipher.encrypt(customer_id.encode())
```

#### Dependencies Added

- SQLAlchemy (ORM)
- Flask-Login (auth)
- passlib (password hashing)
- cryptography (Fernet)
- polars (fast CSV ingest, 5x faster than pandas)

### 12 Theme Catalog

Expanded from 6 themes (V5) to 12 themes:

**Dark**: Default, Blue, Green, Purple, Orange, Red  
**Light**: Default, Blue, Green, Purple, Orange, Red

### Breaking Changes

- **Parquet → SQLite**: Main data moved from Parquet to SQLite
- **No anonymous access**: Login required for all pages
- **Port change**: 8070 (from 8055)

**app.py Growth**: 445 lines → 793 lines (+78%)

**config.py**: Added 4 new config classes (DatabaseConfig, AuthConfig, TaskConfig, CryptoConfig)

**Port**: 8070

### What Worked Well

- ✓ SQLite reliable for structured data
- ✓ Flask-Login smooth authentication
- ✓ RBAC enforced consistently
- ✓ Fernet encryption transparent

### What Didn't Work

- Limited advanced features (added in V11)

---

# Part 3: Enterprise Features (V11-V17)

## V11 — Feature Expansion

**Release**: February 11, 2026  
**Status**: ✓ Complete

### Purpose

Add 15 advanced features: reports, alerts, drift, graph, scheduler, what-if.

### New Features

1. **Reports Generation** — PDF, Excel, CSV exports
2. **Alert Management** — Escalation workflows
3. **Drift Detection** — Model monitoring
4. **Graph Analysis** — Network visualization
5. **Scheduler** — Automated task execution
6. **What-If Analysis** — Scenario testing
7. **Task Manager** — Background job queue

### New Pages (5)

- Reports
- Alerts
- Drift Detection
- Graph Analysis
- Scheduler

**Page Count**: 14 → 19

### Database Schema Expansion

**2 New Tables**:
- `reports` — Generated report metadata
- `scheduled_tasks` — Task schedule and status

**Total Tables**: 4 → 6

**Port**: 8070

### What Worked Well

- ✓ Feature set now comprehensive
- ✓ Task scheduler reliable
- ✓ What-if analysis valuable

---

## V12 — Bank Audit Compliance

**Release**: February 12, 2026  
**Status**: ✓ Complete

### Purpose

Fix 16 critical/high severity findings from bank security audit.

### Critical Fixes (2)

**V12-CRITICAL-001**: Unauthenticated access to auth module  
→ **Fix**: RBAC enforced on all auth endpoints

**V12-CRITICAL-002**: Session fixation vulnerability  
→ **Fix**: Session ID regeneration on login

### High Severity Fixes (2)

**V12-HIGH-003**: Weak password requirements  
→ **Fix**: Min 12 chars, uppercase, lowercase, digit, special

**V12-HIGH-004**: SQL injection risk  
→ **Fix**: All queries use parameterized statements

### Medium/Low Fixes (12)

- CSRF token validation
- Input sanitization
- Rate limiting preparation
- Upload file validation
- ...8 more

### New Features

- **Compliance Checking Module**
- **Role Assignment Manager**

**Page Count**: 19 → 21

**Database**: +2 tables (compliance_checks, role_assignments)

**Port**: 8070

### What Worked Well

- ✓ All 16 findings addressed
- ✓ RBAC fully enforced on 21 pages
- ✓ Security posture significantly improved

---

## V13 — Health Audit

**Release**: February 12, 2026  
**Status**: ✓ Complete

### Purpose

Fix 26 health audit findings: performance, stability, UX.

### Fixes Applied

**Performance** (12 fixes):
- AG Grid rendering optimized for 100K+ rows
- Callback memoization added
- Stale cache cleared on startup
- Interval bottleneck guidance

**Stability** (8 fixes):
- Safe Diskcache creation (no crash on disk full)
- Resource monitoring improved
- Graceful degradation added

**UX** (6 fixes):
- Theme persistence fixed
- UI responsiveness improved
- Help documentation added

### 12 Theme Catalog

**Themes**: Material, Dracula, Nord, Solarized, Monokai, Gruvbox, ...6 more

**Port**: 8070

### What Worked Well

- ✓ All 26 findings addressed
- ✓ UI smooth on large datasets
- ✓ Theme catalog polished

---

## V14 — Enterprise Hardening

**Release**: February 13, 2026  
**Status**: ✓ Complete

### Purpose

Add production-grade WSGI server, circuit breaker, watchdog monitoring.

### Key Additions

**Waitress WSGI Server**:
- Pure-Python, Windows-native
- Production-grade request handling
- Graceful shutdown

**Circuit Breaker**:
- Fault isolation for external services
- Configurable thresholds
- Auto-recovery

**SystemWatchdog**:
- CPU, memory, disk, thread monitoring
- Configurable thresholds
- Real-time alerts

**Port**: 8070

### What Worked Well

- ✓ Waitress stable in production
- ✓ Circuit breaker prevented cascading failures
- ✓ Watchdog early warning system

---

## V15 — REST API

**Release**: February 14, 2026  
**Status**: ✓ Complete

### Purpose

Add FastAPI REST API with 14 endpoints for machine-to-machine integration.

### API Architecture

**Dual Interface**:
- **Dash App** — Web UI on port 8070
- **FastAPI** — REST API on port 8079

**Authentication**:
- **JWT tokens** for session-based auth
- **API keys** for external systems

### 14 API Endpoints

**Pipeline**:
- `POST /detect` — Run detection
- `GET /status` — Check pipeline status
- `GET /history` — Run history

**Results**:
- `GET /customers` — Scored customers
- `GET /alerts` — Active alerts
- `GET /reports` — Generated reports

**Audit**:
- `GET /audit-logs` — Audit trail
- `POST /verify-hash` — Hash chain verification

**System**:
- `GET /health` — Health check
- `GET /metrics` — System metrics

### Swagger Documentation

Auto-generated OpenAPI docs at `/docs`.

**Port**: 8070 (Dash), 8079 (API)

### What Worked Well

- ✓ Dual interface seamless
- ✓ JWT auth robust
- ✓ Swagger docs comprehensive

---

## V16 — Enhanced Security

**Release**: February 15, 2026  
**Status**: ✓ Complete

### Purpose

Fix 3 additional bank audit findings (A4, A5, A6).

### Enhancements

**A4: PII Safety Lock**:
- Prevents accidental raw PII exposure
- Role-based access enforcement
- Audit logging on denial

```python
safety_lock = PIISafetyLock()
safety_lock.register_pii_columns([
    'customer_id', 'account_number', 'ssn'
])

try:
    df = safety_lock.get_masked_dataframe(
        df=results,
        user_role=current_user.role,
        requested_columns=['customer_id']
    )
except PermissionError:
    audit_logger.log_event({
        'action': 'PII_ACCESS_DENIED',
        'user': current_user.username
    })
```

**A5: Epsilon Tolerance**:
- Float comparison with epsilon=1e-9
- Handles float boundary cases
- Prevents false flagging

```python
if np.isclose(score1, score2, atol=1e-9):
    pass  # Within tolerance
```

**A6: Hash Chain Verification**:
- Continuous audit trail integrity checks
- Recomputation verification
- Alert on tampering detection

```python
def verify_hash_chain():
    logs = session.query(AuditLog).order_by('timestamp').all()
    for i, log in enumerate(logs):
        expected = compute_hash(logs[i-1].current_hash, log.action)
        if log.current_hash != expected:
            raise IntegrityError("Hash chain broken!")
```

**Database**: +2 tables (pii_access_logs, hash_verifications)

**Port**: 8070 (Dash), 8079 (API)

### What Worked Well

- ✓ PII safety lock effective
- ✓ Epsilon tolerance robust
- ✓ Hash verification continuous

---

## V17 — Full Wiring

**Release**: February 15, 2026  
**Status**: ✓ CURRENT

### Purpose

Full wiring and integration testing of all 9 enhancements (E1-E9).

### Key Activities

- ✓ All E1-E9 enhancements wired into application
- ✓ Syntax validation on all Python files
- ✓ Integration test suite passing
- ✓ Performance optimization (customer-level processing)

### System Status

**Lines of Code**:
- app.py: ~800 lines
- config.py: ~470 lines
- Total Python files: ~45

**Database**: 12 tables

**Pages**: 21

**Themes**: 12

**Detection Methods**: 26

**Layers**: 7

**Port**: 8070 (Dash), 8079 (API)

### What Works

- ✓ All features operational
- ✓ Bank audit compliant
- ✓ 100K scalability validated
- ✓ Dual interface (web + API)
- ✓ Enterprise security (encryption, RBAC, audit)

---

# Part 4: Reference

## Evolution Metrics

### Code Growth

| Metric | V1 | V5 | V10 | V17 |
|--------|----|----|-----|-----|
| app.py lines | 150 | 444 | 793 | ~800 |
| config.py lines | 107 | 228 | 431 | ~470 |
| Total Python files | ~18 | ~24 | ~37 | ~45 |
| Pages | 8 | 11 | 14 | 21 |
| Themes | 1 | 6 | 12 | 12 |

### Performance Evolution

| Metric | V4 | V6 | V17 |
|--------|----|----|-----|
| Records | 100K txn | 10K cust | 10K cust |
| Time | 12 min | 10 min | ~10 min |
| Memory | 2.5 GB | 1.8 GB | ~1.8 GB |
| Throughput | 139/sec | 17/sec | ~17/sec |

### Paradigm Shifts

1. **V1**: 7-layer architecture established
2. **V2**: Streamlit → Dash (reactive UI)
3. **V6**: Transaction → Customer processing
4. **V7**: ANY schema flexibility
5. **V10**: Infrastructure (SQLite + Auth + RBAC)

---

## Documentation Suite

This master document is part of a comprehensive documentation suite:

### Core Documents
- **[VERSION_HISTORY_V1_TO_V10.md](VERSION_HISTORY_V1_TO_V10.md)** — Detailed V1-V10 evolution (1,320 lines)
- **[VERSION_HISTORY_COMPLETE.md](VERSION_HISTORY_COMPLETE.md)** — Detailed V10-V17 evolution (~750 lines)
- **[CHANGELOG.md](CHANGELOG.md)** — GitHub-style changelog with migration guides

### Detailed Version Docs
- **[docs/VERSION_1_STREAMLIT.md](docs/VERSION_1_STREAMLIT.md)** — V1 detailed documentation
- **[docs/VERSION_2_DASH_MIGRATION.md](docs/VERSION_2_DASH_MIGRATION.md)** — V2 framework migration
- **[docs/VERSION_3_PII_VAULT.md](docs/VERSION_3_PII_VAULT.md)** — V3 security foundations
- **[docs/VERSION_4_SCALABILITY.md](docs/VERSION_4_SCALABILITY.md)** — V4 stress testing
- **[docs/VERSION_5_PRODUCTION_HARDENING.md](docs/VERSION_5_PRODUCTION_HARDENING.md)** — V5 production polish
- **[docs/VERSION_6_CUSTOMER_LEVEL.md](docs/VERSION_6_CUSTOMER_LEVEL.md)** — V6 paradigm shift
- **[docs/VERSION_7_FLEXIBLE_ARCHITECTURE.md](docs/VERSION_7_FLEXIBLE_ARCHITECTURE.md)** — V7 schema flexibility
- **[docs/VERSION_8_RBAC_AUDIT.md](docs/VERSION_8_RBAC_AUDIT.md)** — V8 access control
- **[docs/VERSION_9_VAT_FMEA.md](docs/VERSION_9_VAT_FMEA.md)** — V9 quality assurance
- **[docs/VERSION_10_PRODUCTION_CORE.md](docs/VERSION_10_PRODUCTION_CORE.md)** — V10 infrastructure

### Reference Documents
- **[docs/COMPARISON_TABLES.md](docs/COMPARISON_TABLES.md)** — Feature matrices, performance benchmarks
- **[docs/CODE_EXAMPLES.md](docs/CODE_EXAMPLES.md)** — Implementation patterns from each version
- **[docs/ARCHITECTURE_DIAGRAMS.md](docs/ARCHITECTURE_DIAGRAMS.md)** — Mermaid diagrams

---

## Running the Application

### V17 (Current)

```bash
# Activate environment
conda activate ai311

# Start dashboard (port 8070)
python app.py

# Start API separately (port 8079)
cd api
python main.py
```

### First-Time Setup

```bash
# Initialize database
python init_db.py

# Create admin user
python create_user.py --username admin --password <secure_password> --role admin

# Run migrations (if any)
python migrations/migrate.py
```

### Environment Variables

Create `.env` file:
```
FCDAI_SECRET_KEY=<generate_secure_key>
FCDAI_DATABASE_URL=sqlite:///data/fcdai.db
FCDAI_FERNET_KEY=<generate_fernet_key>
```

---

## Conclusion

The FCDAI system has evolved from a 150-line Streamlit prototype to an 800+ line enterprise platform across **17 versions**, featuring:

- ✓ **7-layer pipeline** with 26 detection methods
- ✓ **Customer-level processing** (90% data reduction)
- ✓ **ANY schema support** (zero hardcoded assumptions)
- ✓ **Enterprise infrastructure** (SQLite, Auth, RBAC, Encryption)
- ✓ **Dual interface** (Web dashboard + REST API)
- ✓ **Bank audit compliance** (42+ critical fixes)
- ✓ **100K scalability** validated

The system is production-ready for air-gapped bank AML deployment.

---

**Last Updated**: February 15, 2026  
**Status**: PRODUCTION  
**Version**: 17.0.0

**For support**: Contact internal AML team
