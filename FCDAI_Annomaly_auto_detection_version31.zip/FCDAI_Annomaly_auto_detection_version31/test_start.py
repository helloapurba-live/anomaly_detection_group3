"""Quick diagnostic: check if the app can start."""
import sys, os, traceback

LOG = os.path.join(os.path.dirname(__file__), "startup_log.txt")

with open(LOG, "w") as f:
    try:
        f.write("Step 1: importing config...\n")
        from config import APP
        f.write(f"  PORT={APP.PORT}  HOST={APP.HOST}  DEBUG={APP.DEBUG}\n")
        f.write(f"  VERSION={APP.VERSION}  VERSION_TAG={APP.VERSION_TAG}\n")

        f.write("Step 2: importing app...\n")
        from app import app, server
        f.write("  app and server imported OK\n")

        f.write("Step 3: checking serve_layout...\n")
        layout = app.layout
        f.write(f"  layout type: {type(layout)}\n")

        f.write("Step 4: checking port availability...\n")
        import socket
        for p in [APP.PORT, APP.PORT + 1]:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                s.bind((APP.HOST, p))
                f.write(f"  port {p}: AVAILABLE\n")
            except OSError as e:
                f.write(f"  port {p}: OCCUPIED ({e})\n")
            finally:
                s.close()

        f.write("\nALL CHECKS PASSED. Ready to start.\n")

    except Exception:
        f.write(f"\nERROR:\n{traceback.format_exc()}\n")

print(f"Log written to: {LOG}")
