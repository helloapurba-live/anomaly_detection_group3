# Changelog

All notable changes to the FCDAI AML Detection System are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [V17] - 2026-02-15

### Added
- Full wiring of all 9 enhancements (E1-E9) from bank audit
- Complete integration test suite passing all scenarios

### Changed
- All V17 code verified with syntax validation tools
- Performance optimizations for customer-level processing

### Security
- Enhanced PII safety lock enforcement (A4)
- Improved epsilon tolerance handling (A5)
- Reinforced hash chain verification (A6)

---

## [V16] - 2026-02-15

### Added
- Enhancement A4: PII Safety Lock - prevents accidental raw PII exposure
- Enhancement A5: Epsilon Tolerance - handles float comparison boundaries
- Enhancement A6: Hash Chain Verification - continuous audit trail integrity

### Fixed
- Bank audit finding: PII access control gaps
- Float comparison edge cases in statistical methods
- Hash chain recomputation on audit log replay

### Security
- Automated PII column detection with safety lock
- Role-based PII access enforcement
- Audit logging for all PII access attempts

---

## [V15] - 2026-02-14

### Added
- FastAPI REST API server on port 8079
- 14 REST endpoints for detection, query, and management
---

## [V14] - 2026-02-13

### Added
- Waitress WSGI server for production deployment
- Circuit breaker pattern for external API calls
- Watchdog file system monitoring
- Resource usage alerts
- Graceful shutdown handlers

### Changed
- Replaced built-in development server with Waitress
- Improved error recovery mechanisms
- Enhanced logging with structured format

### Fixed
- Memory leak in long-running sessions
- Connection pool exhaustion under load

---

## [V13] - 2026-02-12

### Added
- 12 theme catalog (6 dark, 6 light)
- Health monitoring dashboard
- Performance metrics tracking

### Fixed
- 26 health audit findings addressed
- UI responsiveness issues on large datasets
- Theme persistence across sessions

### Changed
- Optimized AG Grid rendering for 100K+ rows
- Improved callback performance with memoization

---

## [V12] - 2026-02-12

### Added
- RBAC enforcement on all 21 pages
- Compliance checking module
- Role assignment manager

### Fixed
- **CRITICAL**: Access control on auth module (V12-CRITICAL-001)
- **CRITICAL**: Session fixation protection (V12-CRITICAL-002)
- **HIGH**: Password complexity enforcement (V12-HIGH-003)
- **HIGH**: SQL injection prevention (V12-HIGH-004)
- 12 additional medium/low severity findings

### Security
- Session regeneration on login
- CSRF token validation
- Input sanitization on all forms
- SQL parameterized queries enforced

---

## [V11] - 2026-02-11

### Added
- Reports generation (PDF, Excel, CSV)
- Alert management system with escalation
- Drift detection for model monitoring
- Graph analysis for network visualization
- Scheduler for automated tasks
- What-if analysis for scenario testing
- Task manager with background job queue
- 5 new pages (Reports, Alerts, Drift, Graph, Scheduler)

### Changed
- Page count increased from 14 to 19
- Extended SQLite schema with 2 new tables (reports, scheduled_tasks)

---

## [V10] - 2026-02-10

### Added
- **SQLite database** with Write-Ahead Logging (WAL)
- **SQLAlchemy ORM** with 4 core tables (users, anomalies, audit_logs, alert_events)
- **Flask-Login authentication** with 8-hour sessions
- **RBAC** with 3 roles (admin, investigator, viewer)
- **Fernet encryption** for sensitive data at rest
- **PBKDF2-SHA256** password hashing
- **Polars** for fast CSV ingestion (5x faster than pandas)
- **Diskcache** for background task management
- 12 theme catalog (6 dark, 6 light)
- Login page and user management
- Task manager page

### Changed
- **BREAKING**: Replaced Parquet files with SQLite for structured data
- Port changed from 8055 to 8070 (stabilized)
- app.py expanded from 445 lines to 793 lines (+78%)
- config.py expanded with 4 new config classes

### Deprecated
- Parquet files for transactional data (kept only for vault/forensics)

### Removed
- Anonymous access (authentication now required)

### Security
- Multi-user authentication with role-based access
- Encrypted storage for customer IDs and sensitive fields
- Audit trail with hash chain verification
- Session management with automatic timeout

---

## [V9] - 2026-02-10

### Added
- **FMEA analysis** covering 20 failure modes with RPN scoring
- **VAT checklist** (273 lines, 108 verification checks)
- Hash chain state persistence across runs

### Fixed
- **CRITICAL** (FM-006): PII masking now **enabled by default** (was: disabled)
- **HIGH** (FM-007): Hash chain persistence (was: reset on restart)
- **HIGH** (FM-003): Float comparison epsilon tolerance (was: strict equality)
- FM-001: Upload size validation (100 MB limit)
- FM-002: File type validation (CSV/Excel only)
- FM-004: Division by zero in statistical methods
- FM-005: Formula injection in CSV exports

### Changed
- PIIConfig default: `enable_pii_masking = True` (was: False)
- AuditLogger: Added `hash_state.json` persistence
- Float comparisons: Use `np.isclose()` with epsilon=1e-9

### Security
- Default PII masking prevents accidental exposure
- Upload file sanitization
- CSV export formula injection protection

---

## [V8] - 2026-02-09

### Added
- **ColumnRoleConfig**: 3-step resolution (config → auto-detect → user override)
- **ResourceConfig**: Memory limits, CPU throttling, timeout controls
- **AuditConfig**: Hash chain audit trail with lineage tracking
- Type-specific data imputation (mean for numeric, mode for categorical)
- Admin configuration panel
- System health monitoring page (later moved to V10+)

### Changed
- Column role resolution now flexible (no hardcoded column names)
- config.py expanded from 228 to 431 lines (+89%)
- Removed hardcoded assumptions about column names

### Fixed
- Schema flexibility issues with non-standard datasets
- Resource contention under heavy load

---

## [V7] - 2026-02-09

### Added
- **Schema flexibility revolution**: Support for ANY CSV schema
- **SchemaDetector**: Regex-based auto-detection of 8 column types
- **AutoParamGenerator**: Generate pipeline params from detected schema
- **Robust execution**: Error recovery with fallback strategies
- 4 core principles: MASTER-only, unlimited extensibility, auto-detection, optional config

### Changed
- **BREAKING**: Move from hardcoded column names to detected roles
- Pipeline now accepts MASTER_* columns (e.g., MASTER_ID, MASTER_AMOUNT)
- Port changed from 8109 to 8055

### Removed
- Hardcoded column name assumptions (customer_id, amount, date)

---

## [V6] - 2026-02-08

### Added
- **Customer-level processing**: Transform 100K transactions → 10K customers
- **CustomerAggregator**: Generate 80+ features per customer
- **Tiered consensus ensemble**: Weight methods by historical performance
- **Percentile normalization**: Robust to outliers
- **Domain weights**: Customize scoring by business domain

### Changed
- **PARADIGM SHIFT**: Detection moved from transaction → customer level
- 90% reduction in records processed
- 17% faster execution time (12 min → 10 min)
- 28% memory reduction (1.8 GB → 1.3 GB avg)
- Port changed from 8097 to 8109

### Performance
- Throughput: 139 txn/sec → 17 customer/sec (effective 10x improvement per entity)
- Memory peak: 2.5 GB → 1.8 GB
- CPU usage: 85% → 82% average

---

## [V5] - 2026-02-07

### Added
- **6 theme system** (3 dark, 3 light)
- **Clientside callbacks** for instant theme switching
- **localStorage persistence** for theme preference
- Theme toggle component

### Changed
- app.py expanded from 216 to 444 lines (+106%)
- Theme state managed in browser (no server roundtrip)
- Port changed from 8090 to 8097

### Performance
- Instant theme switching (0ms server latency)
- Improved user experience with persistent preferences

---

## [V4] - 2026-02-06

### Added
- **pipeline_runner.py**: CLI for batch execution
- **verify_scalability.py**: 100K transaction stress test
- Argument parsing for threshold, skip-layers, output directory

### Performance
- **100K scalability test** passed
- Execution time: 12 minutes
- Throughput: 139 transactions/second
- Memory peak: 2.5 GB, average: 1.8 GB
- CPU average: 85%

### Changed
- Port changed from 8085 to 8090

---

## [V3] - 2026-02-05

### Added
- **PII masking** with show-edges pattern (e.g., "12****89")
- **Data vault** directory structure for forensic exports
- **PIIConfig** class with configurable masking parameters
- Audit vault page for forensic evidence management
- System health page (later moved)

### Security
- PII masking prevents full exposure of sensitive data
- Configurable show_prefix and show_suffix for verification
- Segregated vault storage for audit compliance

### Changed
- Port changed from 8071 to 8085

---

## [V2] - 2026-02-04

### Added
- **Dash framework** replacing Streamlit
- **Dash Mantine Components (DMC)** for modern UI
- **AG Grid** for high-performance data tables
- **Callback architecture** for reactive updates
- **dcc.Store** for client-side state management
- **Diskcache** for result persistence
- Pipeline run page for manual execution

### Changed
- **BREAKING**: Complete framework migration from Streamlit to Dash
- Port changed from 8501 (Streamlit) to 8071 (Dash)
- app.py restructured from linear script to callback-driven
- No more full page reloads

### Removed
- Streamlit dependency and all st.* calls

### Performance
- 10x faster UI updates (no page reload)
- AG Grid handles 100K+ rows smoothly

---

## [V1] - 2025-01-15

### Added
- **Initial release**: Streamlit prototype
- **7-layer pipeline architecture** established
- **26 detection methods** across 8 categories:
  - Isolation-based (3 methods)
  - Density-based (4 methods)
  - Distance-based (3 methods)
  - Statistical (5 methods)
  - Probabilistic (3 methods)
  - Network (2 methods)
  - Linear (3 methods)
  - Ensemble (3 methods)
- **8 pages**:
  - Dashboard
  - Data Sources
  - Layer View
  - Investigation Queue
  - Narratives
  - Audit Trail
  - Model Diagnostics
  - Explainability
- **Basic configuration**: PathConfig, ThemeConfig, LayerConfig
- CSV file upload
- Result download (CSV)
- Single theme (dark mode)

### Performance
- Tested on 10K transactions
- Execution time: ~2 minutes
- Memory usage: ~800 MB

---

## Version Categories

### Major Releases (Paradigm Shifts)
- **V1**: Architecture foundation (7-layer pipeline)
- **V2**: Framework rewrite (Streamlit → Dash)
- **V6**: Processing paradigm (Transaction → Customer)
- **V7**: Schema flexibility (ANY schema support)
- **V10**: Infrastructure transformation (SQLite + Auth + RBAC)

### Security Releases
- **V3**: PII masking and data vault
- **V9**: FMEA critical fixes (FM-006, FM-007, FM-003)
- **V10**: Multi-user auth + encryption
- **V12**: Bank audit compliance (16 fixes)
- **V16**: Enhanced PII safety (A4/A5/A6)

### Performance Releases
- **V4**: 100K scalability validation
- **V5**: Clientside callbacks optimization
- **V6**: 90% data reduction, 17% speed improvement

### Feature Releases
- **V11**: Advanced features (reports, alerts, drift, graph)
- **V13**: 12 themes, health monitoring
- **V14**: Enterprise hardening (Waitress, watchdog)
- **V15**: REST API integration

### Quality Releases
- **V8**: Resource safety and column flexibility
- **V9**: FMEA analysis and VAT checklist
- **V12**: Compliance and RBAC enforcement
- **V13**: Health audit fixes
- **V17**: Full wiring and integration testing

---

## Migration Guide

### From V9 to V10 (SQLite Migration)

**Breaking Changes:**
- Parquet files replaced by SQLite for main data
- Authentication now required (no anonymous access)
- Port change: 8070 (was: 8055)

**Migration Steps:**
1. **Backup data**: Copy `data/` directory
2. **Initialize database**: Run `python init_db.py`
3. **Create admin user**: Use `python create_user.py --role admin`
4. **Import historical data**: Run `python import_parquet_to_sqlite.py`
5. **Update config**: Review `config.py` for new settings
6. **Test**: Access `http://localhost:8070` and login

### From V1 to V2 (Streamlit to Dash)

**Breaking Changes:**
- Complete framework rewrite
- Port change: 8071 (was: 8501)
- All page code restructured

**Migration Steps:**
1. **Export data**: Use V1 download button to save results
2. **Switch to V2**: Navigate to V2 directory
3. **Install deps**: `pip install -r requirements.txt`
4. **Import data**: Use V2 upload feature
5. **Verify**: Compare results with V1 exports

---

## Deprecation Notices

### Deprecated in V10
- **Parquet files for transactional data**: Use SQLite instead (Parquet kept for vault/forensics)

### Deprecated in V7
- **Hardcoded column names**: Use schema detection or config file mapping

### Removed in V2
- **Streamlit framework**: Fully replaced by Dash

---

## Security Advisories

### SA-2026-001 (V9, FM-006)
**Severity**: CRITICAL  
**Issue**: PII masking disabled by default, risking exposure  
**Fixed in**: V9  
**Action**: Update to V9+, verify `PIIConfig.enable_pii_masking = True`

### SA-2026-002 (V9, FM-007)
**Severity**: HIGH  
**Issue**: Hash chain reset on restart, breaking audit trail  
**Fixed in**: V9  
**Action**: Update to V9+, verify `hash_state.json` persistence

### SA-2026-003 (V12, CRITICAL-001)
**Severity**: CRITICAL  
**Issue**: Unauthenticated access to auth module  
**Fixed in**: V12  
**Action**: Update to V12+, verify RBAC enforcement

---

**For detailed documentation, see**:
- [Individual Version Docs](docs/)
- [Comparison Tables](docs/COMPARISON_TABLES.md)
- [Code Examples](docs/CODE_EXAMPLES.md)
- [Architecture Diagrams](docs/ARCHITECTURE_DIAGRAMS.md)
- [Master Version History](MASTER_VERSION_HISTORY_V1_V17.md)
