# AIM AI Vault V16 — TOML Configuration Independence Guide
# ===========================================================
# This guide lets you change ANY parameter WITHOUT developer help.
# All changes are made in ONE file: `config.toml` (same folder as app.py)
#
# Author: AIM AI Vault Team
# Version: 16.0.0

## How It Works

The application reads Python dataclass defaults from `config.py`.
If `config.toml` exists, it **overrides** any matching parameters.

```
Python default (config.py)  ←  overridden by  ←  config.toml
```

You NEVER need to edit `.py` files. Just edit `config.toml` and restart.

---

## Quick Start

1. Open `config.toml` in any text editor (Notepad, VS Code, etc.)
2. Uncomment the section and parameter you want to change
3. Set the new value
4. Save the file
5. Restart the application (`python app.py` or the batch file)

---

## Common Tasks

### Change PII Masking Behavior (A4)

**Show more characters in masked values:**
```toml
[pii]
VISIBLE_CHARS = 6          # Show last 6 chars instead of 4
MASK_PATTERN = "****"      # Use asterisks instead of XXXX
```

**Disable PII masking (DANGEROUS — requires safety unlock):**
```toml
[pii]
ENABLED_BY_DEFAULT = false
ALLOW_PII_DISABLE = true   # BOTH must be set
```

**Disable PII masking for API only (keep masking in UI/exports):**
```toml
[pii]
MASK_IN_API = false
```

**Add new PII columns to mask:**
Edit the `MASKED_COLUMNS` list in `config.py` (this is the one parameter
that requires a Python edit because TOML doesn't override list fields).

---

### Change Risk Tier Thresholds (A5)

**Make "CRITICAL" easier to trigger:**
```toml
[audit]
RISK_TIER_EPSILON = 0.01   # Wider tolerance (was 1e-9)
```

**Change tier score boundaries:**
Edit `RISK_TIERS` in `config.py` `LayerConfig`. The tier dict structure
is not TOML-overridable (nested dict), but ALL scalar params are.

---

### Tune Hash Chain Persistence (A6)

**Write hash state more frequently:**
```toml
[audit]
HASH_CHAIN_BATCH_INTERVAL = 5   # Every 5 actions instead of 10
```

**Keep more backup copies of hash state:**
```toml
[audit]
HASH_CHAIN_BACKUP_COUNT = 5     # 5 backups instead of 3
```

**Use SHA-512 instead of SHA-256:**
```toml
[audit]
HASH_ALGORITHM = "sha512"
```

---

### Change Server Settings

**Run on a different port:**
```toml
[app]
PORT = 9000

[waitress]
THREADS = 16        # More threads for higher load
```

**Change memory limits (if you have more RAM):**
```toml
[resources]
MAX_MEMORY_MB = 8192            # 8GB instead of 4GB
MAX_ROWS_FOR_HEAVY_METHODS = 10000
```

---

### Logging and Monitoring

**Increase log detail:**
```toml
[logging]
LOG_LEVEL = "DEBUG"
```

**Adjust monitoring thresholds:**
```toml
[watchdog]
MEMORY_WARN_PERCENT = 70.0
DISK_WARN_PERCENT = 75.0
CHECK_INTERVAL_SEC = 15
```

---

### Authentication

**Change session timeout:**
```toml
[auth]
SESSION_LIFETIME_HOURS = 4
```

---

## Parameter Reference

| Section          | Parameter                  | Type    | Default    | Description                              |
|------------------|---------------------------|---------|------------|------------------------------------------|
| `[pii]`          | `ENABLED_BY_DEFAULT`      | bool    | true       | Master PII masking switch                |
| `[pii]`          | `ALLOW_PII_DISABLE`       | bool    | false      | Safety lock for disabling PII            |
| `[pii]`          | `MASK_AT_STORAGE`         | bool    | true       | Mask before writing to disk              |
| `[pii]`          | `MASK_IN_EXPORTS`         | bool    | true       | Mask in CSV/Excel exports                |
| `[pii]`          | `MASK_IN_MEMORY`          | bool    | true       | Mask in DataVault memory views           |
| `[pii]`          | `MASK_IN_API`             | bool    | true       | Mask in REST API responses               |
| `[pii]`          | `LOG_PII_ACCESS`          | bool    | true       | Audit-log PII column access              |
| `[pii]`          | `VISIBLE_CHARS`           | int     | 4          | Trailing visible chars in masked values  |
| `[audit]`        | `RISK_TIER_EPSILON`       | float   | 1e-9       | Float boundary tolerance for tiers       |
| `[audit]`        | `HASH_CHAIN_BATCH_INTERVAL`| int    | 10         | Persist hash every N actions             |
| `[audit]`        | `HASH_CHAIN_BACKUP_COUNT` | int     | 3          | Number of hash state backup files        |
| `[audit]`        | `HASH_CHAIN_VERIFY_ON_LOAD`| bool   | true       | Verify integrity on startup              |
| `[audit]`        | `HASH_ALGORITHM`          | str     | "sha256"   | Hash algorithm for audit chain           |
| `[audit]`        | `MAX_UPLOAD_SIZE_MB`      | int     | 100        | Max file upload size (MB)                |
| `[audit]`        | `LOG_ROTATION_MAX_BYTES`  | int     | 10000000   | Max log file size before rotation        |
| `[app]`          | `HOST`                    | str     | "127.0.0.1"| Bind address                             |
| `[app]`          | `PORT`                    | int     | 8078       | Dashboard port                           |
| `[app]`          | `DEBUG`                   | bool    | false      | Debug mode (NEVER true in production)    |
| `[resources]`    | `MAX_MEMORY_MB`           | int     | 4096       | Max pipeline memory (MB)                 |
| `[resources]`    | `MAX_ROWS_FOR_HEAVY_METHODS`| int   | 5000       | Row limit for O(n²) methods              |
| `[waitress]`     | `THREADS`                 | int     | 8          | WSGI worker threads                      |
| `[waitress]`     | `CONNECTION_LIMIT`        | int     | 100        | Max simultaneous connections             |
| `[watchdog]`     | `MEMORY_WARN_PERCENT`     | float   | 80.0       | Memory warning threshold (%)             |
| `[logging]`      | `LOG_LEVEL`               | str     | "INFO"     | Global minimum log level                 |
| `[circuit_breaker]`| `FAILURE_THRESHOLD`     | int     | 3          | Failures before opening circuit          |

---

## Rules

1. **TOML syntax**: Use `true`/`false` (lowercase), not `True`/`False`
2. **Strings**: Must be quoted: `HASH_ALGORITHM = "sha512"`
3. **Numbers**: No quotes: `PORT = 9000`, `RISK_TIER_EPSILON = 0.001`
4. **Changes require restart** — no hot-reload
5. **Comments**: Lines starting with `#` are ignored
6. **Missing file**: If `config.toml` doesn't exist, all Python defaults apply

---

## Troubleshooting

**Changes not taking effect?**
- Verify file is named exactly `config.toml` (not `.txt`)
- Check it's in the same folder as `app.py`
- Look for `TOML overrides applied` in logs
- Look for `TOML override failed` warnings

**Invalid TOML syntax?**
- Run: `python -c "import tomllib; tomllib.load(open('config.toml','rb'))"`
- Fix any syntax errors reported

**Need to override a list/dict parameter?**
- `MASKED_COLUMNS`, `RISK_TIERS`, `DETECTION_METHODS` are complex structures
- These must be edited in `config.py` directly
- All scalar parameters (bool, int, float, str) are TOML-overridable
