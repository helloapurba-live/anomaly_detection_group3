"""
AIM AI Vault — V30 Main Application (L01–L14 Unified Pipeline)
===============================================================
V27 Enhancements:
  - A2: Global random seed (RANDOM_SEED=42) for full reproducibility
  - B1: EDA profiling page with distributions, missing-value heatmap,
         skewness/kurtosis scatter, and correlation matrix
  - B5: Binary column scaling fix (0/1 columns pass through unscaled)
  - B7: Real SHAP explanations via TreeExplainer / KernelExplainer
  - C1-C6: Tier 2 persistence — feature importance, DQ metrics,
            model performance, method scores, graph centrality, telemetry
  - C7: What-If simulator uses actual trained models when available
  - Port: 8103

V26 Enhancements (retained):
  - Cross-file naming alignment: df_agg in pipeline, df_master in UI, df_fallback in pipeline_run
  - DataFrame variable name labels in UI for traceability

V16 Enhancements (inherited):
  - A4: PII masking enforced-by-default with TOML override
  - A5: Risk tier epsilon tolerance wired into L6 ensemble
  - A6: Hash-chain persistence hardened with verification
  - Modular TOML-parameterized config — change ANYTHING via config.toml
  - Bank audit table enhancements (PII access log, hash verification)
  - Air-gapped reinforcement with network interface check

V15 (retained):
  - FastAPI REST API (14 endpoints) on port 8079
  - JWT + API Key dual authentication
  - PII auto-masking in all API responses
  - OpenAPI 3.0 specification

V14 (retained):
  - Waitress WSGI production server
  - Health probes (/health, /ready)
  - SystemWatchdog resource monitoring
  - Circuit breaker for external calls
  - Service layer + data contracts
  - Structured logging (JSON)

V13 (retained):
  - All 12 premium themes
  - Run history, alerts, reports
  - 26 health audit fixes

V10 Core (retained):
  - SQLite + SQLAlchemy (WAL mode)
  - Flask-Login RBAC
  - Diskcache background tasks
  - Polars-accelerated ingestion

Author: AIM AI Vault Team
"""

import dash
from dash import html, dcc, page_registry, page_container, callback, Input, Output, State, clientside_callback, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import diskcache
from pathlib import Path
import sys
import os

# =============================================================================
# V15 ZERO-LEAKAGE: Block ALL telemetry, CDN, and external network calls
# =============================================================================
# Must be set BEFORE any plotly/dash import touches the network
os.environ["PLOTLY_OFFLINE_ONLY"] = "1"           # Force offline-only mode
os.environ["PLOTLY_DISABLE_TELEMETRY"] = "1"       # Plotly 5.x telemetry kill
os.environ["DASH_DISABLE_TELEMETRY"] = "1"         # Dash usage-stats kill
os.environ["PLOTLY_RENDERER"] = "json"             # No CDN renderer
os.environ["DASH_SERVE_LOCALLY"] = "1"             # Force local asset serving
import plotly.io as pio
pio.renderers.default = "browser"                  # Local browser only

sys.path.insert(0, str(Path(__file__).parent))

from config import APP, THEME, PATHS, TASKS, WAITRESS, WATCHDOG as WATCHDOG_CFG

# =============================================================================
# V17 E6: AIR-GAPPED NETWORK INTERFACE CHECK (TOML-toggleable)
# =============================================================================
# Warn operator if non-loopback network interfaces are detected.
# Bank air-gapped systems must have NO external connectivity.
# V17: Controlled by APP.AIRGAP_CHECK — set to false in config.toml to skip.
def _check_airgap_compliance():
    """V17 E6: Verify no unexpected network interfaces are active.
    
    Controlled by APP.AIRGAP_CHECK (default True).
    Set [app] AIRGAP_CHECK = false in config.toml to disable.
    
    Private IPs (10.x, 172.16-31.x, 192.168.x) are INFO-level only —
    they indicate a LAN adapter, not internet access.
    Public IPs trigger a WARNING — they may indicate external connectivity.
    """
    import logging as _alog
    _air_logger = _alog.getLogger("apurbadas.airgap")

    # V17 E6: Check if air-gap check is enabled via config
    if not APP.AIRGAP_CHECK:
        _air_logger.info("Air-gap check DISABLED via config (APP.AIRGAP_CHECK=False)")
        return

    try:
        import socket, ipaddress
        hostname = socket.gethostname()
        local_ips = socket.getaddrinfo(hostname, None, socket.AF_INET)
        non_loopback = [
            addr[4][0] for addr in local_ips
            if not addr[4][0].startswith("127.") and addr[4][0] != "0.0.0.0"
        ]
        if not non_loopback:
            _air_logger.info("Air-gap compliance OK: only loopback interfaces detected.")
            return
        
        # Separate private vs public IPs
        public_ips = []
        private_ips = []
        for ip in non_loopback:
            try:
                if ipaddress.ip_address(ip).is_private:
                    private_ips.append(ip)
                else:
                    public_ips.append(ip)
            except ValueError:
                private_ips.append(ip)
        
        if private_ips:
            _air_logger.info(
                f"Air-gap check: private/LAN interfaces detected: {private_ips} "
                "(normal for local network — no internet implied)"
            )
        if public_ips:
            _air_logger.warning(
                f"AIR-GAP WARNING: Public interfaces detected: {public_ips}. "
                "Bank policy requires air-gapped operation. Verify network isolation."
            )
    except Exception as exc:
        _air_logger.warning(f"Air-gap check inconclusive: {type(exc).__name__}")

_check_airgap_compliance()

# =============================================================================
# V10: DATABASE INITIALIZATION (must happen before app creation)
# =============================================================================
from database.engine import init_db
init_db()

# =============================================================================
# V10: DISKCACHE BACKGROUND CALLBACK MANAGER — V13 F-6: Safe creation
# =============================================================================
try:
    cache_dir = PATHS.BASE / TASKS.CACHE_DIR
    cache_dir.mkdir(parents=True, exist_ok=True)
    background_cache = diskcache.Cache(str(cache_dir))
    # V13 C-1: Clear stale results on startup to avoid serving old data
    background_cache.clear()
    background_callback_manager = dash.DiskcacheManager(background_cache)
except Exception as _cache_exc:
    import logging as _log
    _log.getLogger("apurbadas.cache").error(
        f"Diskcache creation failed ({type(_cache_exc).__name__}). "
        "Background callbacks will be synchronous."
    )
    background_callback_manager = None


# =============================================================================
# DASH APPLICATION INITIALIZATION
# =============================================================================
app = dash.Dash(
    __name__,
    use_pages=True,
    pages_folder='pages',
    suppress_callback_exceptions=True,
    assets_folder='assets',
    serve_locally=True,  # Air-gapped: ALL JS/CSS from local assets
    assets_ignore=r'.*external.*|.*cdn.*|.*googleapis.*|.*gstatic.*',  # Block external resource patterns
    title=APP.TITLE,
    update_title=None,
    background_callback_manager=background_callback_manager,
)

server = app.server

# V15: Content-Security-Policy — belt-and-suspenders telemetry block
@server.after_request
def _add_security_headers(response):
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' 'unsafe-eval'; "
        "style-src 'self' 'unsafe-inline'; "
        "connect-src 'self'; "                  # Block ALL external XHR/fetch
        "img-src 'self' data:; "
        "font-src 'self' data:; "
        "frame-src 'none'; "
        "object-src 'none'"
    )
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    return response


# =============================================================================
# V10: FLASK-LOGIN INITIALIZATION
# =============================================================================
from auth.manager import init_login_manager
init_login_manager(server)

# =============================================================================
# V14: HEALTH ENDPOINTS — /health (liveness) + /ready (readiness)
# =============================================================================
try:
    from utils.health import register_health_routes
    register_health_routes(server)
except Exception as _health_exc:
    import logging as _hlog
    _hlog.getLogger("apurbadas.health").warning(f"Health routes failed: {_health_exc}")

# =============================================================================
# V14: SYSTEM WATCHDOG — background daemon monitoring resources
# =============================================================================
try:
    from utils.watchdog import SystemWatchdog
    _watchdog = SystemWatchdog()
    _watchdog.start()
except Exception as _wd_exc:
    import logging as _wdlog
    _wdlog.getLogger("apurbadas.watchdog").warning(f"Watchdog start failed: {_wd_exc}")


# =============================================================================
# THEME DEFINITIONS — 12 Premium Themes (7 dark + 3 light + 2 premium)
# Each theme provides full color palette for body, sidebar, cards, text,
# borders, accent gradients, and Plotly figure template name.
# =============================================================================
THEMES = {
    # ── DARK THEMES ──────────────────────────────────────────────────────────
    "system": {
        "label": "Sentinel Dark",
        "icon": "mdi:shield-lock",
        "primaryColor": "cyan",
        "accentHex": "#15aabf",
        "colorScheme": "dark",
        "bgColor": "#0D1117",
        "cardBg": "#161B22",
        "paperBg": "#1C2333",
        "borderColor": "#30363D",
        "textPrimary": "#E6EDF3",
        "textSecondary": "#8B949E",
        "accentGradient": {"from": "cyan", "to": "indigo"},
        "plotlyTemplate": "plotly_dark",
        "agGridClass": "ag-theme-alpine-dark",
        "sidebarText": "#E6EDF3",
    },
    "midnight": {
        "label": "Midnight Blue",
        "icon": "mdi:moon-waxing-crescent",
        "primaryColor": "indigo",
        "accentHex": "#4c6ef5",
        "colorScheme": "dark",
        "bgColor": "#080818",
        "cardBg": "#141430",
        "paperBg": "#1A1A40",
        "borderColor": "#2A2A5E",
        "textPrimary": "#D4D4F8",
        "textSecondary": "#8888BB",
        "accentGradient": {"from": "indigo", "to": "violet"},
        "plotlyTemplate": "plotly_dark",
        "agGridClass": "ag-theme-alpine-dark",
        "sidebarText": "#D4D4F8",
    },
    "ocean": {
        "label": "Ocean Deep",
        "icon": "mdi:waves",
        "primaryColor": "cyan",
        "accentHex": "#15aabf",
        "colorScheme": "dark",
        "bgColor": "#051620",
        "cardBg": "#0A2A3C",
        "paperBg": "#0E3550",
        "borderColor": "#164058",
        "textPrimary": "#D0F0FF",
        "textSecondary": "#7CB8D4",
        "accentGradient": {"from": "cyan", "to": "teal"},
        "plotlyTemplate": "plotly_dark",
        "agGridClass": "ag-theme-alpine-dark",
        "sidebarText": "#D0F0FF",
    },
    "emerald": {
        "label": "Emerald Night",
        "icon": "mdi:leaf",
        "primaryColor": "teal",
        "accentHex": "#20c997",
        "colorScheme": "dark",
        "bgColor": "#071210",
        "cardBg": "#0E2420",
        "paperBg": "#143530",
        "borderColor": "#1E4D40",
        "textPrimary": "#C8F0E8",
        "textSecondary": "#70B8A0",
        "accentGradient": {"from": "teal", "to": "green"},
        "plotlyTemplate": "plotly_dark",
        "agGridClass": "ag-theme-alpine-dark",
        "sidebarText": "#C8F0E8",
    },
    "rose": {
        "label": "Rose Gold",
        "icon": "mdi:flower-tulip",
        "primaryColor": "pink",
        "accentHex": "#e64980",
        "colorScheme": "dark",
        "bgColor": "#120A10",
        "cardBg": "#241520",
        "paperBg": "#301E2A",
        "borderColor": "#4A2840",
        "textPrimary": "#F8D8E8",
        "textSecondary": "#C088A8",
        "accentGradient": {"from": "pink", "to": "grape"},
        "plotlyTemplate": "plotly_dark",
        "agGridClass": "ag-theme-alpine-dark",
        "sidebarText": "#F8D8E8",
    },
    "crimson": {
        "label": "Crimson Night",
        "icon": "mdi:fire",
        "primaryColor": "red",
        "accentHex": "#fa5252",
        "colorScheme": "dark",
        "bgColor": "#100808",
        "cardBg": "#201010",
        "paperBg": "#2D1515",
        "borderColor": "#4A1E1E",
        "textPrimary": "#F8D0D0",
        "textSecondary": "#C88080",
        "accentGradient": {"from": "red", "to": "orange"},
        "plotlyTemplate": "plotly_dark",
        "agGridClass": "ag-theme-alpine-dark",
        "sidebarText": "#F8D0D0",
    },
    "sunset": {
        "label": "Sunset Amber",
        "icon": "mdi:weather-sunset",
        "primaryColor": "orange",
        "accentHex": "#ff922b",
        "colorScheme": "dark",
        "bgColor": "#10100A",
        "cardBg": "#201E10",
        "paperBg": "#302A15",
        "borderColor": "#4A3820",
        "textPrimary": "#F8E8C8",
        "textSecondary": "#C8A870",
        "accentGradient": {"from": "orange", "to": "yellow"},
        "plotlyTemplate": "plotly_dark",
        "agGridClass": "ag-theme-alpine-dark",
        "sidebarText": "#F8E8C8",
    },
    # ── LIGHT THEMES ─────────────────────────────────────────────────────────
    "premium_white": {
        "label": "Premium White",
        "icon": "mdi:diamond-stone",
        "primaryColor": "blue",
        "accentHex": "#4c6ef5",
        "colorScheme": "light",
        "bgColor": "#FAFBFC",
        "cardBg": "#FFFFFF",
        "paperBg": "#FFFFFF",
        "borderColor": "#E1E4E8",
        "textPrimary": "#1F2328",
        "textSecondary": "#57606A",
        "accentGradient": {"from": "blue", "to": "indigo"},
        "plotlyTemplate": "plotly_white",
        "agGridClass": "ag-theme-alpine",
        "sidebarText": "#1F2328",
    },
    "arctic": {
        "label": "Arctic Frost",
        "icon": "mdi:snowflake",
        "primaryColor": "cyan",
        "accentHex": "#15aabf",
        "colorScheme": "light",
        "bgColor": "#EFF6FC",
        "cardBg": "#FFFFFF",
        "paperBg": "#F5FAFF",
        "borderColor": "#C8DDF0",
        "textPrimary": "#1A3050",
        "textSecondary": "#506880",
        "accentGradient": {"from": "cyan", "to": "blue"},
        "plotlyTemplate": "plotly_white",
        "agGridClass": "ag-theme-alpine",
        "sidebarText": "#1A3050",
    },
    "lavender": {
        "label": "Lavender Mist",
        "icon": "mdi:flower",
        "primaryColor": "violet",
        "accentHex": "#7950f2",
        "colorScheme": "light",
        "bgColor": "#F4F0FA",
        "cardBg": "#FDFAFF",
        "paperBg": "#F8F4FF",
        "borderColor": "#D8C8F0",
        "textPrimary": "#2A1848",
        "textSecondary": "#685088",
        "accentGradient": {"from": "violet", "to": "grape"},
        "plotlyTemplate": "plotly_white",
        "agGridClass": "ag-theme-alpine",
        "sidebarText": "#2A1848",
    },
    # ── HYBRID / PREMIUM ─────────────────────────────────────────────────────
    "forest": {
        "label": "Forest Shadow",
        "icon": "mdi:pine-tree",
        "primaryColor": "green",
        "accentHex": "#40c057",
        "colorScheme": "dark",
        "bgColor": "#080E08",
        "cardBg": "#101E10",
        "paperBg": "#162816",
        "borderColor": "#1E3E1E",
        "textPrimary": "#C8F0C8",
        "textSecondary": "#70B870",
        "accentGradient": {"from": "green", "to": "lime"},
        "plotlyTemplate": "plotly_dark",
        "agGridClass": "ag-theme-alpine-dark",
        "sidebarText": "#C8F0C8",
    },
    "platinum": {
        "label": "Platinum Executive",
        "icon": "mdi:crown",
        "primaryColor": "gray",
        "accentHex": "#868e96",
        "colorScheme": "light",
        "bgColor": "#F5F5F5",
        "cardBg": "#FFFFFF",
        "paperBg": "#FAFAFA",
        "borderColor": "#D0D0D0",
        "textPrimary": "#2C2C2C",
        "textSecondary": "#6E6E6E",
        "accentGradient": {"from": "gray", "to": "dark"},
        "plotlyTemplate": "plotly_white",
        "agGridClass": "ag-theme-alpine",
        "sidebarText": "#2C2C2C",
    },
}


# =============================================================================
# NAVIGATION LINK COMPONENT
# =============================================================================
def create_nav_link(icon: str, label: str, href: str) -> dmc.NavLink:
    """Create a styled navigation link."""
    return dmc.NavLink(
        label=label,
        href=href,
        leftSection=DashIconify(icon=icon, width=20),
        active="exact",
        style={"borderRadius": "6px", "marginBottom": "4px"},
    )


# =============================================================================
# THEME SELECTOR COMPONENT
# =============================================================================
def build_theme_selector():
    """Build the theme selector dropdown for the sidebar with grouped dark/light."""
    dark_themes = []
    light_themes = []
    for k, t in THEMES.items():
        entry = {"value": k, "label": t["label"]}
        if t["colorScheme"] == "light":
            light_themes.append(entry)
        else:
            dark_themes.append(entry)
    theme_data = (
        [{"group": "Dark Themes", "items": dark_themes}]
        + [{"group": "Light Themes", "items": light_themes}]
    )

    return dmc.Paper(
        [
            dmc.Text("THEME", size="xs", c="dimmed", fw=500, mb="xs"),
            dmc.Select(
                id="theme-selector",
                data=theme_data,
                value="system",
                placeholder="Select theme...",
                searchable=False,
                clearable=False,
                size="xs",
            ),
        ],
        p="sm", mx="sm", radius="md",
        style={"backgroundColor": "rgba(0,0,0,0.2)"},
    )


# =============================================================================
# SIDEBAR LAYOUT
# =============================================================================
def build_sidebar():
    """Build the sidebar with navigation links, version info, and server status."""
    return dmc.Paper(
        [
            # Logo + Version
            dmc.Group(
                [
                    dmc.ThemeIcon(
                        DashIconify(icon="mdi:shield-lock", width=28),
                        size="xl",
                        radius="md",
                        variant="gradient",
                        gradient={"from": "cyan", "to": "indigo"},
                        id="sidebar-logo-icon",
                    ),
                    dmc.Stack(
                        [
                            dmc.Text("AIM AI", size="lg", fw=700),
                            dmc.Group([
                                dmc.Badge(f"{APP.VERSION_TAG}", color="cyan", variant="light", size="xs"),
                                dmc.Badge(f"v{APP.VERSION}", color="gray", variant="light", size="xs"),
                            ], gap=4),
                        ],
                        gap=0,
                    ),
                ],
                gap="sm",
                px="md",
                py="lg",
            ),

            dmc.Divider(id="sidebar-divider"),

            # V10: User info bar (populated by callback)
            html.Div(id="sidebar-user-info"),

            # Navigation - Pipeline Layers
            dmc.Stack(
                [
                    dmc.Text("WORKFLOW", size="xs", c="dimmed", fw=500, px="md", pt="md"),
                    create_nav_link("mdi:view-dashboard", "Dashboard", "/"),
                    create_nav_link("mdi:database-import", "Data Sources", "/sources"),
                    create_nav_link("mdi:rocket-launch", "Execution Engine", "/pipeline"),
                    create_nav_link("mdi:layers-triple", "Layer View", "/layers"),
                    create_nav_link("mdi:history", "Run History", "/run-history"),
                    create_nav_link("mdi:calendar-clock", "Alert Center", "/alerts"),
                ],
                gap=2,
                px="sm",
            ),

            # Navigation - Results
            dmc.Stack(
                [
                    dmc.Text("RESULTS", size="xs", c="dimmed", fw=500, px="md", pt="md"),
                    create_nav_link("mdi:alert-circle", "Investigation Queue", "/queue"),
                    create_nav_link("mdi:file-document", "Narratives", "/narratives"),
                    create_nav_link("mdi:file-chart", "Report Generator", "/reports"),
                    create_nav_link("mdi:clipboard-check", "Audit Trail", "/audit"),
                    create_nav_link("mdi:gavel", "Regulatory Dashboard", "/regulatory"),
                ],
                gap=2,
                px="sm",
            ),

            # Navigation - Advanced Analytics
            dmc.Stack(
                [
                    dmc.Text("ADVANCED ANALYTICS", size="xs", c="dimmed", fw=500, px="md", pt="md"),
                    create_nav_link("mdi:table-search", "Audit Vault (AG Grid)", "/audit-vault"),
                    create_nav_link("mdi:chart-sankey", "Model Diagnostics", "/diagnostics"),
                    create_nav_link("mdi:brain", "Explainability", "/explainability"),
                    create_nav_link("mdi:graph-outline", "Graph Network", "/graph"),
                    create_nav_link("mdi:chart-bell-curve", "Drift Monitor", "/drift"),
                    create_nav_link("mdi:chart-areaspline-variant", "Feature Trends", "/feature-trends"),
                    create_nav_link("mdi:tune-vertical-variant", "What-If Simulator", "/what-if"),
                    create_nav_link("mdi:chart-waterfall", "SHAP Explanations", "/shap"),
                    create_nav_link("mdi:chart-histogram", "EDA Profiling", "/eda"),
                ],
                gap=2,
                px="sm",
            ),

            # Navigation - Admin
            dmc.Stack(
                [
                    dmc.Text("ADMIN", size="xs", c="dimmed", fw=500, px="md", pt="md"),
                    create_nav_link("mdi:clipboard-list", "Task Manager", "/tasks"),
                    create_nav_link("mdi:shield-account", "Admin Panel", "/admin"),
                    create_nav_link("mdi:cog", "Configuration", "/config"),
                ],
                gap=2,
                px="sm",
            ),

            # Navigation - V14: System
            dmc.Stack(
                [
                    dmc.Text("SYSTEM", size="xs", c="dimmed", fw=500, px="md", pt="md"),
                    create_nav_link("mdi:monitor-dashboard", "System Health", "/system-health"),
                    create_nav_link("mdi:help-circle", "Help", "/help"),
                ],
                gap=2,
                px="sm",
            ),

            # Spacer to push info to bottom
            html.Div(style={"flex": "1"}),

            # Theme Selector
            build_theme_selector(),

            # V20: Server Info Footer (version, port, status)
            dmc.Paper(
                dmc.Stack([
                    dmc.Divider(color="dark"),
                    dmc.Group([
                        DashIconify(icon="mdi:server", width=14, color="#51cf66"),
                        dmc.Text("Server", size="xs", fw=600, c="dimmed"),
                        dmc.Badge("LOCAL", color="green", variant="dot", size="xs"),
                    ], gap=4),
                    dmc.Group([
                        dmc.Text(f"Port: {APP.PORT}", size="10px", c="dimmed"),
                        dmc.Text("|", size="10px", c="dimmed"),
                        dmc.Text(f"{APP.VERSION_TAG} v{APP.VERSION}", size="10px", c="dimmed"),
                    ], gap=4),
                    dmc.Group([
                        DashIconify(icon="mdi:shield-check", width=12, color="#22b8cf"),
                        dmc.Text("Air-Gapped | No Cloud | PII Protected", size="9px", c="dimmed"),
                    ], gap=4),
                ], gap=4),
                p="xs", mx="sm", mb="sm", radius="md",
                style={"backgroundColor": "rgba(0,0,0,0.1)"},
            ),

            dmc.Space(h="sm"),
        ],
        id="sidebar",
        style={
            "width": "260px",
            "height": "100vh",
            "position": "fixed",
            "top": 0,
            "left": 0,
            "backgroundColor": THEME.DARK_BG_CARD,
            "borderRight": f"1px solid {THEME.DARK_BORDER}",
            "overflowY": "auto",
            "display": "flex",
            "flexDirection": "column",
        },
        radius=0,
    )


# =============================================================================
# MAIN LAYOUT — served as a function for per-request auth check
# =============================================================================
def serve_layout():
    """
    Called on every page load.  Returns login page if not authenticated,
    or the full app layout if the user has a valid session.
    V30: Login gate re-enabled.
    """
    from flask_login import current_user

    if not current_user.is_authenticated:
        from pages.login import get_login_layout
        return html.Div([
            dcc.Location(id="url", refresh=True),
            dcc.Store(id="store-theme", data="system", storage_type="local"),
            dcc.Store(id="store-pipeline-complete", data=None, storage_type="memory"),
            dcc.Store(id="theme-css-store", data="", storage_type="memory"),
            get_login_layout(),
        ])

    # Authenticated -> full app
    return dmc.MantineProvider(
        [
            dmc.NotificationProvider(position="top-right"),
            html.Div(id="notification-container"),

            dcc.Location(id="url", refresh=True),

            # Stores for state management
            dcc.Store(id="store-theme", data="system", storage_type="local"),
            dcc.Store(id="store-pipeline-complete", data=None, storage_type="memory"),

            # V13 FIX: Theme CSS Store (was missing — root cause of broken themes)
            dcc.Store(id="theme-css-store", data="", storage_type="memory"),

            # CSS variables injector for theme
            html.Div(id="theme-css-injector"),

            # V20: Sidebar state store (persisted in localStorage)
            dcc.Store(id="store-sidebar-collapsed", data=False, storage_type="local"),

            dmc.Box(
                [
                    build_sidebar(),
                    # V20: Sidebar toggle button — prominent, always visible top-left
                    dmc.ActionIcon(
                        DashIconify(icon="mdi:menu", width=22, id="sidebar-toggle-icon"),
                        id="btn-sidebar-toggle",
                        variant="filled", color="cyan", size="xl", radius="md",
                        style={
                            "position": "fixed", "top": "10px", "left": "268px",
                            "zIndex": 1200, "transition": "left 0.25s ease",
                            "boxShadow": "0 2px 8px rgba(0,0,0,0.4)",
                        },
                    ),
                    dmc.Box(
                        [
                            # V10: Task status bar (background pipeline indicator)
                            html.Div(id="task-status-bar"),
                            page_container,
                        ],
                        id="page-content",
                        style={
                            "marginLeft": "260px",
                            "padding": "24px 32px",
                            "minHeight": "100vh",
                            "backgroundColor": THEME.DARK_BG,
                            "transition": "margin-left 0.25s ease",
                        }
                    ),
                ],
                id="app-container",
            ),
        ],
        id="mantine-provider",
        forceColorScheme="dark",  # default; overridden by switch_theme callback
        theme=THEME.get_mantine_theme(),
    )


app.layout = serve_layout


# =============================================================================
# V11: Dark/Light Auto-Detect (#17)
# Detect OS color scheme on first visit and suggest matching theme.
# =============================================================================
app.clientside_callback(
    """
    function(storedTheme) {
        // Only auto-detect if no theme was previously stored
        if (storedTheme && storedTheme !== "system") {
            return window.dash_clientside.no_update;
        }
        // Check OS preference
        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) {
            return "premium_white";
        }
        return "system";
    }
    """,
    Output("theme-selector", "value"),
    Input("store-theme", "data"),
)


# =============================================================================
# V20: SIDEBAR COLLAPSE / EXPAND TOGGLE (improved visibility)
# =============================================================================
app.clientside_callback(
    """
    function(n_clicks, collapsed) {
        if (n_clicks === undefined || n_clicks === null) {
            var isCollapsed = collapsed || false;
        } else {
            var isCollapsed = !collapsed;
        }
        var sidebar = document.getElementById('sidebar');
        var content = document.getElementById('page-content');
        var toggleBtn = document.getElementById('btn-sidebar-toggle');
        var toggleIcon = document.getElementById('sidebar-toggle-icon');
        if (sidebar && content && toggleBtn) {
            if (isCollapsed) {
                sidebar.style.transform = 'translateX(-260px)';
                sidebar.style.transition = 'transform 0.25s ease';
                content.style.marginLeft = '0px';
                toggleBtn.style.left = '10px';
            } else {
                sidebar.style.transform = 'translateX(0px)';
                sidebar.style.transition = 'transform 0.25s ease';
                content.style.marginLeft = '260px';
                toggleBtn.style.left = '268px';
            }
        }
        return isCollapsed;
    }
    """,
    Output("store-sidebar-collapsed", "data"),
    Input("btn-sidebar-toggle", "n_clicks"),
    State("store-sidebar-collapsed", "data"),
)


# =============================================================================
# V14: KEYBOARD SHORTCUT NAVIGATION (Alt+key)
# =============================================================================
app.clientside_callback(
    """
    function(url) {
        if (window._v14_kb_registered) return window.dash_clientside.no_update;
        window._v14_kb_registered = true;
        document.addEventListener('keydown', function(e) {
            if (!e.altKey) return;
            var routes = {
                'd': '/',          // Dashboard
                's': '/sources',   // Data Sources
                'p': '/pipeline',  // Pipeline Execution
                'l': '/layers',    // Layer View
                'q': '/queue',     // Investigation Queue
                'h': '/system-health',  // System Health
                '/': '/help',      // Help (Alt+?)
            };
            var key = e.key.toLowerCase();
            if (key === '?' || key === '/') key = '/';
            if (routes[key]) {
                e.preventDefault();
                window.location.href = routes[key];
            }
        });
        return window.dash_clientside.no_update;
    }
    """,
    Output("url", "pathname"),
    Input("url", "pathname"),
)


# =============================================================================
# V10: LOGIN CALLBACK (V30: Re-enabled)
# =============================================================================
@callback(
    Output("login-error", "children"),
    Output("url", "href", allow_duplicate=True),
    Input("login-btn", "n_clicks"),
    State("login-username", "value"),
    State("login-password", "value"),
    prevent_initial_call=True,
)
def handle_login(n_clicks, username, password):
    """Authenticate user and redirect on success."""
    if not n_clicks:
        return no_update, no_update

    if not username or not password:
        return dmc.Alert(
            "Please enter both username and password.",
            color="yellow",
            withCloseButton=True,
        ), no_update

    from auth.manager import authenticate
    user = authenticate(username, password)
    if user is None:
        return dmc.Alert(
            "Invalid username or password.",
            title="Authentication Failed",
            color="red",
            icon=DashIconify(icon="mdi:alert-circle", width=20),
            withCloseButton=True,
        ), no_update

    # Success -> redirect to dashboard (forces layout re-evaluation)
    return "", "/"


# =============================================================================
# V10: LOGOUT CALLBACK (V30: Re-enabled)
# =============================================================================
@callback(
    Output("url", "href", allow_duplicate=True),
    Input("logout-btn", "n_clicks"),
    prevent_initial_call=True,
)
def handle_logout(n_clicks):
    """Log out user and redirect to login page."""
    if not n_clicks:
        return no_update
    # Audit the logout event
    try:
        from flask_login import current_user as _cu
        _uname = _cu.username if _cu.is_authenticated else "unknown"
        from utils.logger import logger
        logger.log_action("USER_LOGOUT", user=_uname, metadata={"client_ip": logger._get_client_ip()})
    except Exception:
        pass
    from auth.manager import do_logout
    do_logout()
    return "/"


# =============================================================================
# V10: SIDEBAR USER INFO CALLBACK
# =============================================================================
@callback(
    Output("sidebar-user-info", "children"),
    Input("url", "pathname"),
)
def update_user_info(_pathname):
    """Show current user info and logout button in sidebar."""
    from flask_login import current_user
    if not current_user.is_authenticated:
        return ""

    role_colors = {"admin": "red", "investigator": "cyan", "viewer": "gray"}
    role_color = role_colors.get(current_user.role, "gray")

    return dmc.Paper(
        dmc.Group(
            [
                dmc.Avatar(
                    current_user.username[0].upper(),
                    radius="xl", color=role_color, variant="filled", size="sm",
                ),
                dmc.Stack(
                    [
                        dmc.Text(current_user.full_name or current_user.username, size="sm", fw=600),
                        dmc.Badge(current_user.role.upper(), size="xs", color=role_color, variant="light"),
                    ],
                    gap=0,
                ),
                dmc.ActionIcon(
                    DashIconify(icon="mdi:logout", width=18),
                    id="logout-btn",
                    variant="subtle",
                    color="gray",
                    size="sm",
                ),
            ],
            gap="xs",
            justify="space-between",
        ),
        p="xs", mx="sm", my="xs", radius="md",
        style={"backgroundColor": "rgba(0,0,0,0.15)"},
    )


# =============================================================================
# V13: CLIENTSIDE CSS INJECTION — reliable <style> element in <head>
# Replaces dcc.Markdown approach for guaranteed CSS application.
# =============================================================================
app.clientside_callback(
    """
    function(cssText) {
        var el = document.getElementById('dynamic-theme-css');
        if (!el) {
            el = document.createElement('style');
            el.id = 'dynamic-theme-css';
            document.head.appendChild(el);
        }
        el.textContent = cssText || '';
        return '';
    }
    """,
    Output("theme-css-injector", "children"),
    Input("theme-css-store", "data"),
)


# =============================================================================
# THEME SWITCHER CALLBACK
# =============================================================================
@callback(
    Output("mantine-provider", "forceColorScheme"),
    Output("mantine-provider", "theme"),
    Output("page-content", "style"),
    Output("sidebar", "style"),
    Output("sidebar-divider", "color"),
    Output("sidebar-logo-icon", "gradient"),
    Output("theme-css-store", "data"),
    Output("store-theme", "data"),
    Input("theme-selector", "value"),
    State("store-theme", "data"),
)
def switch_theme(selected, stored_theme):
    """Apply the selected theme across the entire application.
    V13: Uses clientside callback for reliable CSS injection.
    Python 3.10/3.11 compatible — no nested f-strings."""
    theme_key = selected or stored_theme or "system"
    t = THEMES.get(theme_key, THEMES["system"])

    color_scheme = t["colorScheme"]
    is_light = color_scheme == "light"
    text_pr = t.get("textPrimary", "#E6EDF3" if not is_light else "#1F2328")
    text_se = t.get("textSecondary", "#8B949E" if not is_light else "#57606A")
    paper_bg = t.get("paperBg", t["cardBg"])
    sidebar_txt = t.get("sidebarText", text_pr)
    accent_hex = t.get("accentHex", "#15aabf")
    ag_class = t.get("agGridClass", "ag-theme-alpine-dark")

    # Build Mantine theme dict — match card/paper bg to selected theme
    mantine_theme = THEME.get_mantine_theme()
    mantine_theme["primaryColor"] = t["primaryColor"]
    mantine_theme["components"] = {
        "Paper": {"styles": {"root": {"backgroundColor": paper_bg}}},
        "Card": {"styles": {"root": {"backgroundColor": t["cardBg"]}}},
    }

    # Page content area
    page_style = {
        "marginLeft": "260px",
        "padding": "24px 32px",
        "minHeight": "100vh",
        "backgroundColor": t["bgColor"],
        "color": text_pr,
    }

    # Sidebar
    sidebar_style = {
        "width": "260px",
        "height": "100vh",
        "position": "fixed",
        "top": 0,
        "left": 0,
        "backgroundColor": t["cardBg"],
        "borderRight": "1px solid " + t["borderColor"],
        "overflowY": "auto",
        "display": "flex",
        "flexDirection": "column",
        "color": sidebar_txt,
    }

    # --- V13: Comprehensive CSS variable override ---
    # Raw CSS string — injected via clientside callback into <head>
    hover_bg = "#F0F0F4" if is_light else "#222244"
    # Per-theme glass colors (tinted to match theme)
    if is_light:
        glass_bg = "rgba(255,255,255,0.85)"
        glass_border = "rgba(0,0,0,0.06)"
        input_bg = "#F8F9FA"
        badge_bg = "rgba(0,0,0,0.04)"
    else:
        # Derive glass from card bg with transparency
        glass_bg = t["cardBg"] + "cc"  # ~80% opacity hex
        glass_border = "rgba(255,255,255,0.08)"
        input_bg = t["bgColor"]
        badge_bg = "rgba(255,255,255,0.06)"
    # Accent with alpha for hover backgrounds
    accent_alpha = accent_hex + "1a"  # ~10% opacity
    accent_glow = accent_hex + "26"   # ~15% opacity

    lines = []
    # CSS custom properties override
    lines.append(":root {")
    lines.append("  --bg-primary: " + t["bgColor"] + ";")
    lines.append("  --bg-secondary: " + t["cardBg"] + ";")
    lines.append("  --bg-paper: " + paper_bg + ";")
    lines.append("  --bg-card: " + t["cardBg"] + ";")
    lines.append("  --bg-surface: " + paper_bg + ";")
    lines.append("  --bg-hover: " + hover_bg + ";")
    lines.append("  --border-default: " + t["borderColor"] + ";")
    lines.append("  --text-primary: " + text_pr + ";")
    lines.append("  --text-secondary: " + text_se + ";")
    lines.append("  --glass-bg: " + glass_bg + ";")
    lines.append("  --glass-border: " + glass_border + ";")
    lines.append("  --accent-primary: " + accent_hex + ";")
    lines.append("  --border-accent: " + accent_hex + "33;")
    lines.append("  --shadow-glow-accent: 0 0 20px " + accent_glow + ";")
    lines.append("}")

    # ── Paper/Card — solid color overrides any inline style ──
    lines.append(".mantine-Paper-root {")
    lines.append("  background-color: " + paper_bg + " !important;")
    lines.append("  border-color: " + t["borderColor"] + " !important;")
    lines.append("  color: " + text_pr + " !important;")
    lines.append("}")

    # ── Sidebar ──
    lines.append("#sidebar .mantine-NavLink-label,")
    lines.append("#sidebar .mantine-Text-root {")
    lines.append("  color: " + sidebar_txt + " !important;")
    lines.append("}")
    lines.append("#sidebar .mantine-NavLink-root[data-active] {")
    lines.append("  background-color: " + accent_alpha + " !important;")
    lines.append("  color: " + accent_hex + " !important;")
    lines.append("}")
    lines.append("#sidebar .mantine-NavLink-root[data-active] .mantine-NavLink-label {")
    lines.append("  color: " + accent_hex + " !important;")
    lines.append("}")
    lines.append("#sidebar .mantine-NavLink-root:hover {")
    lines.append("  background-color: " + hover_bg + " !important;")
    lines.append("}")
    lines.append("#sidebar .mantine-Paper-root {")
    lines.append("  background-color: " + t["bgColor"] + " !important;")
    lines.append("}")
    lines.append("#sidebar .mantine-Divider-root {")
    lines.append("  border-color: " + t["borderColor"] + " !important;")
    lines.append("}")

    # ── Tabs accent ──
    lines.append(".mantine-Tabs-tab[data-active] {")
    lines.append("  color: " + accent_hex + " !important;")
    lines.append("  border-bottom-color: " + accent_hex + " !important;")
    lines.append("}")
    lines.append(".mantine-Tabs-tab { color: " + text_se + " !important; }")
    lines.append(".mantine-Tabs-tab:hover { color: " + text_pr + " !important; background: " + hover_bg + " !important; }")
    lines.append(".mantine-Tabs-list { border-bottom-color: " + t["borderColor"] + " !important; }")

    # ── AG Grid (covers both light and dark classes) ──
    lines.append(".ag-theme-alpine-dark, .ag-theme-alpine {")
    lines.append("  --ag-background-color: " + t["cardBg"] + " !important;")
    lines.append("  --ag-header-background-color: " + t["bgColor"] + " !important;")
    lines.append("  --ag-odd-row-background-color: " + t["bgColor"] + " !important;")
    lines.append("  --ag-border-color: " + t["borderColor"] + " !important;")
    lines.append("  --ag-foreground-color: " + text_pr + " !important;")
    lines.append("  --ag-header-foreground-color: " + text_se + " !important;")
    lines.append("  --ag-row-hover-color: " + hover_bg + " !important;")
    lines.append("  --ag-selected-row-background-color: " + accent_alpha + " !important;")
    lines.append("}")

    # ── Plotly charts — transparent bg, themed text/grid ──
    lines.append(".js-plotly-plot .main-svg { background: transparent !important; }")
    lines.append(".js-plotly-plot .bg { fill: transparent !important; }")
    lines.append(".js-plotly-plot .gridlayer line { stroke: " + t["borderColor"] + " !important; }")
    lines.append(".js-plotly-plot .zerolinelayer line { stroke: " + t["borderColor"] + " !important; }")
    lines.append(".js-plotly-plot text { fill: " + text_pr + " !important; }")
    lines.append(".js-plotly-plot .modebar-btn { fill: " + text_se + " !important; }")
    lines.append(".js-plotly-plot .legendtext { fill: " + text_pr + " !important; }")
    lines.append(".js-plotly-plot .modebar-btn:hover { fill: " + accent_hex + " !important; }")

    # ── Inputs ──
    lines.append(".mantine-Input-input, .mantine-Select-input, .mantine-TextInput-input,")
    lines.append(".mantine-NumberInput-input, .mantine-Textarea-input, .mantine-DateInput-input,")
    lines.append(".mantine-PasswordInput-input, .mantine-MultiSelect-input {")
    lines.append("  background: " + input_bg + " !important;")
    lines.append("  border-color: " + t["borderColor"] + " !important;")
    lines.append("  color: " + text_pr + " !important;")
    lines.append("}")
    lines.append(".mantine-Input-input:focus, .mantine-Select-input:focus,")
    lines.append(".mantine-TextInput-input:focus, .mantine-NumberInput-input:focus {")
    lines.append("  border-color: " + accent_hex + " !important;")
    lines.append("  box-shadow: 0 0 0 2px " + accent_glow + " !important;")
    lines.append("}")

    # ── Text colors (global) ──
    lines.append(".mantine-Text-root { color: " + text_pr + "; }")
    lines.append(".mantine-Title-root { color: " + text_pr + " !important; }")
    lines.append(".mantine-Text-root[data-c='dimmed'] { color: " + text_se + " !important; }")

    # ── Body and main containers ──
    lines.append("body { background-color: " + t["bgColor"] + "; color: " + text_pr + "; }")
    lines.append("#page-content { background-color: " + t["bgColor"] + " !important; color: " + text_pr + " !important; }")

    # ── Scrollbar ──
    scroll_thumb = t["borderColor"]
    lines.append("::-webkit-scrollbar-track { background: " + t["bgColor"] + "; }")
    lines.append("::-webkit-scrollbar-thumb { background: " + scroll_thumb + "; border-radius: 4px; }")
    lines.append("::-webkit-scrollbar-thumb:hover { background: " + text_se + "; }")

    # ── Tooltips ──
    lines.append(".mantine-Tooltip-tooltip {")
    lines.append("  background: " + t["cardBg"] + " !important;")
    lines.append("  border: 1px solid " + t["borderColor"] + " !important;")
    lines.append("  color: " + text_pr + " !important;")
    lines.append("  box-shadow: 0 8px 24px rgba(0,0,0,0.3) !important;")
    lines.append("}")

    # ── Modals ──
    lines.append(".mantine-Modal-content { background: " + paper_bg + " !important; color: " + text_pr + " !important; }")
    lines.append(".mantine-Modal-header { background: " + t["cardBg"] + " !important; border-bottom: 1px solid " + t["borderColor"] + " !important; }")
    lines.append(".mantine-Modal-overlay { background: rgba(0,0,0,0.5) !important; }")

    # ── Select / Dropdown ──
    lines.append(".mantine-Select-dropdown, .mantine-MultiSelect-dropdown {")
    lines.append("  background: " + t["cardBg"] + " !important;")
    lines.append("  border: 1px solid " + t["borderColor"] + " !important;")
    lines.append("}")
    lines.append(".mantine-Select-option, .mantine-MultiSelect-option { color: " + text_pr + " !important; }")
    lines.append(".mantine-Select-option:hover, .mantine-MultiSelect-option:hover { background: " + hover_bg + " !important; }")
    lines.append(".mantine-Select-option[data-checked] { background: " + accent_alpha + " !important; color: " + accent_hex + " !important; }")

    # ── Notifications ──
    lines.append(".mantine-Notification-root {")
    lines.append("  background: " + t["cardBg"] + " !important;")
    lines.append("  border: 1px solid " + t["borderColor"] + " !important;")
    lines.append("  color: " + text_pr + " !important;")
    lines.append("}")

    # ── Dividers ──
    lines.append(".mantine-Divider-root { border-color: " + t["borderColor"] + " !important; }")

    # ── Badges ──
    lines.append(".mantine-Badge-root { transition: background-color 0.3s ease, color 0.3s ease; }")

    # ── Accordion ──
    lines.append(".mantine-Accordion-control { color: " + text_pr + " !important; }")
    lines.append(".mantine-Accordion-content { color: " + text_pr + " !important; background: " + paper_bg + " !important; }")
    lines.append(".mantine-Accordion-item { border-color: " + t["borderColor"] + " !important; }")

    # ── Table ──
    lines.append(".mantine-Table-root { color: " + text_pr + " !important; }")
    lines.append(".mantine-Table-root th { color: " + text_se + " !important; border-color: " + t["borderColor"] + " !important; }")
    lines.append(".mantine-Table-root td { border-color: " + t["borderColor"] + " !important; }")
    lines.append(".mantine-Table-root tr:hover { background: " + hover_bg + " !important; }")

    # ── Alert ──
    lines.append(".mantine-Alert-root { color: " + text_pr + " !important; }")

    # ── Popover ──
    lines.append(".mantine-Popover-dropdown { background: " + t["cardBg"] + " !important; border-color: " + t["borderColor"] + " !important; }")

    # ── Premium accent glow on cards w/ data ──
    lines.append(".mantine-Paper-root:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.15), 0 0 0 1px " + accent_hex + "1a !important; }")

    css_content = "\n".join(lines)

    return color_scheme, mantine_theme, page_style, sidebar_style, t["borderColor"], t["accentGradient"], css_content, theme_key


# =============================================================================
# SERVER
# =============================================================================
if __name__ == "__main__":
    _api_port = APP.PORT + 1  # API on next port
    banner = """
===========================================================
  AIM AI VAULT -- {tag}
  {tag}: L11 Detection | 20-Algo 8-Family Pipeline | SUOD Optimized
  Air-Gapped | No Cloud | No External Connections
  PII Masking: Enabled | Bank Compliance: Active
===========================================================
  Dashboard        : http://{host}:{port}/
  Health Endpoint  : http://{host}:{port}/health
  REST API         : http://{host}:{api_port}/docs
  Press Ctrl+C to stop the server
===========================================================""".format(tag=APP.VERSION_TAG, host=APP.HOST, port=APP.PORT, api_port=_api_port)

    try:
        print(banner)
    except UnicodeEncodeError:
        print("=" * 60)
        print(f"  AIM AI VAULT - {APP.VERSION_TAG} (port {APP.PORT})")
        print(f"  Dashboard: http://{APP.HOST}:{APP.PORT}")
        print(f"  REST API:  http://{APP.HOST}:{_api_port}/docs")
        print("  Press Ctrl+C to stop the server")
        print("=" * 60)

    # V15: Start FastAPI REST API in background thread
    try:
        from api.server import start_api_in_background
        api_thread = start_api_in_background(host=APP.HOST, port=_api_port)
        print(f"  [API] REST API server starting on http://{APP.HOST}:{_api_port}")
    except Exception as _api_exc:
        import logging as _log
        _log.getLogger("apurbadas.api").error(
            f"API server failed to start ({type(_api_exc).__name__}: {_api_exc}). "
            "Dashboard will continue without REST API."
        )

    # V14: Use Waitress production WSGI server (pure-Python, Windows-native)
    try:
        from waitress import serve
        serve(
            server,
            host=APP.HOST,
            port=APP.PORT,
            threads=WAITRESS.THREADS,
            connection_limit=WAITRESS.CONNECTION_LIMIT,
            channel_timeout=WAITRESS.CHANNEL_TIMEOUT,
            url_scheme="http",
        )
    except ImportError:
        print("  [WARN] waitress not installed — falling back to dev server")
        print("         pip install waitress  for production mode")
        app.run(debug=APP.DEBUG, host=APP.HOST, port=APP.PORT)
