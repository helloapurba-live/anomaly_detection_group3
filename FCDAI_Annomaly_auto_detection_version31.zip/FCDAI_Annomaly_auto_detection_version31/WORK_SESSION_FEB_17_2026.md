# Work Session — February 17, 2026 (Midnight)
## V31 Preprocessing Audit & Mathematical Conflict Analysis

---

## 1. WHAT WE DID TODAY

### Task 1: Combinatorial Explosion Investigation
**Question:** Does selecting 4 missing × 4 transform × 7 scaler × 9 reduction × 20 algorithms create 1,008+ combinations?

**Answer: NO.** Pipeline takes SINGLE values per run — one missing, one transform, one scaler, one reduction path. Not combinatorial. One run = one preprocessing path applied to all algorithms.

### Task 2: Mathematical Poison Combinations Identified
Deep-read of 6 core files to find all dangerous user selections:
- `pipeline.py` (880 lines) — L01-L14 orchestrator
- `preprocessing_engine.py` (362 lines) — 4 missing strategies
- `transformation_engine.py` (234 lines) — auto/log/power/none
- `scaling_engine.py` (275 lines) — 6 scalers always computed
- `algorithm_routing.py` (558 lines) — master routing table
- `algo_execution_engine.py` (1238 lines) — per-algorithm runners

**8+ conflicts found** (e.g., log(0) dead dimensions, Benford gets scaled, VAE gets unbounded input).

### Task 3: Table 1 Verification (User Caught Error)
I originally claimed "Reduction: Any" for most algorithms. **User correctly challenged this.** Re-read ALL 20 algorithm registrations in `algorithm_routing.py`. Found Table 1 was WRONG.

### Task 4: Two Solution Approaches Evaluated
- **Solution A (Lock/Fix):** Force AUTO for everything, remove user choice
- **Solution B (Smart Override):** User picks, pipeline validates per algorithm, overrides if incompatible, logs overrides
- **Recommendation:** Solution B

---

## 2. VERIFIED REDUCTION PATHS PER ALGORITHM

Path legend: 1=None, 2=MixedPCA, 3=FAMD, 4=UMAPMixed, 5=UMAPFull, 6=SDAE, 7=AgentQuick, 8=AgentThink, 9=AgentDecide(meta)

| Algorithm | Scaler | Transform | Allowed Paths | Default | never_scale | never_reduce |
|-----------|--------|-----------|---------------|---------|-------------|-------------|
| IQR | RobustScaler | None | 1,2,7 | 1 | No | No |
| MOD_ZSCORE | RobustScaler | None | 1,2,7 | 1 | No | No |
| MAHALANOBIS | PowerTransformer | None | 2,3,7,8 | 2 | No | No |
| BENFORD | Original | None | 1 only | 1 | YES | YES |
| EXT_IF | Original | None | 1,2,3,4,5,7,8 | 1 | No | No |
| HBOS | StandardScaler | log | 1,2,7 | 1 | No | No |
| LOF | StandardScaler | log | 1,2,3,4,7,8 | 2 | No | No |
| ECOD | Original | None | 1,2,7 | 1 | No | No |
| COPOD | Original | None | 1,2,7 | 1 | No | No |
| KNN | StandardScaler | log | 1,2,4,5,7,8 | 2 | No | No |
| GMM | PowerTransformer | None | 2,3,5,7,8 | 2 | No | No |
| HDBSCAN | StandardScaler | log | 2,4,5,7,8 | 4 | No | No |
| BIRCH | StandardScaler | (missing) | 1,2,7 | 2 | No | No |
| PAGERANK | Original | None | 1 only | 1 | YES | YES |
| LEIDEN | Original | None | 1 only | 1 | YES | YES |
| ODDBALL | Original | None | 1 only | 1 | YES | YES |
| BETWEENNESS | Original | None | 1 only | 1 | YES | YES |
| CHANGEPOINT | Original | None | 1 only | 1 | YES | YES |
| MATRIXPROFILE | Original | None | 1 only | 1 | No | YES |
| VAE | MinMaxScaler | log | 1,2,6,7,8 | 1 | No | No |

**Key findings:**
- NO algorithm supports all 9 paths (max = ExtIF with 7)
- Path 6 (SDAE) only supported by VAE
- HDBSCAN, GMM, Mahalanobis do NOT support path 1 (None) — they REQUIRE reduction
- Path 9 (Agent Decide) is a meta-path that delegates to 1-6, not listed in any algo's paths

---

## 3. BUGS FOUND (DUE FOR TOMORROW)

### CRITICAL
| # | Bug | File | Line | Impact |
|---|-----|------|------|--------|
| 1 | Non-Auto scaler path: ALL algos get same X_reduced | pipeline.py | ~625 | Benford gets scaled, VAE gets unbounded, ECOD/COPOD CDF wrong |

### HIGH
| # | Bug | File | Line | Impact |
|---|-----|------|------|--------|
| 2 | EXT_IF key mismatch in ALGO_PREPROCESS_MAP | algorithm_routing.py | ~484 | Auto mode gives ExtIF log+StandardScaler instead of None+Original |
| 3 | MOD_ZSCORE key mismatch in ALGO_PREPROCESS_MAP | algorithm_routing.py | ~480 | Auto mode gives wrong preprocessing |
| 4 | No per-algorithm reduction validation | pipeline.py | L10-L11 | User can pick path 6 for IQR (not supported) |

### MEDIUM
| # | Bug | File | Line | Impact |
|---|-----|------|------|--------|
| 5 | BIRCH missing from ALGO_PREPROCESS_MAP | algorithm_routing.py | ~480 | Falls to default (happens to be OK) |
| 6 | Default missing=ZERO is unsafe for all algos | pipeline_run.py | ~203 | MEDIAN is universally safer |

### LOW
| # | Bug | File | Line | Impact |
|---|-----|------|------|--------|
| 7 | Path 9 not in any algo's reduction_paths list | algorithm_routing.py | all | Works via delegation, but inconsistent |

---

## 4. RECOMMENDED FIX: SOLUTION B (Smart Override)

**Concept:** User picks any combination → pipeline validates per algorithm → overrides incompatible choices → logs what was overridden.

**4 changes needed:**
1. Fix ALGO_PREPROCESS_MAP key names (ext_if, mod_zscore, birch) — `algorithm_routing.py`
2. Add per-algorithm reduction validation function — `pipeline.py`
3. Rewrite L11 non-Auto path to route per algorithm — `pipeline.py` ~line 625
4. Add override report to results — `pipeline.py`

**Bonus:** Change default missing from ZERO to MEDIAN in `pipeline_run.py` dropdown.

---

## 5. FILES READ TODAY (for reference)

| File | Lines | What was checked |
|------|-------|-----------------|
| pipeline.py | 1-880 (full) | L06-L11 flow, Auto vs non-Auto paths |
| utils/algorithm_routing.py | 1-558 (full) | All 20 ALGORITHM_ROUTES, ALGO_PREPROCESS_MAP |
| utils/algo_execution_engine.py | 100-470 | ALGO_INPUT_ROUTING, all runners |
| utils/preprocessing_engine.py | 1-362 (full) | 4 missing strategies |
| utils/transformation_engine.py | 1-234 (full) | auto/log/power/none, log1p behavior |
| utils/scaling_engine.py | 1-275 (full) | 6 scalers, binary exclusion |
| utils/reduction_engine.py | 1-735 (full) | All 9 path implementations |
| pages/pipeline_run.py | 200-310 | Dropdown definitions |

---

## 6. MATHEMATICAL CONFLICT SUMMARY

| User Choice | What Breaks | Why |
|-------------|-------------|-----|
| Missing=ZERO + Transform=log | log1p(0)=0 → dead dimensions | Distance/density algos see false cluster at origin |
| Missing=ZERO + Mahalanobis | Near-singular covariance matrix | Zero-filled columns have zero variance |
| Any scaler + Benford (non-Auto) | Digit distribution destroyed | Benford needs raw transaction amounts |
| Any scaler ≠ MinMax + VAE (non-Auto) | BCE loss NaN / poor reconstruction | VAE needs [0,1] bounded input |
| StandardScaler + ECOD/COPOD (non-Auto) | Empirical CDF changed | These are scale-invariant, need Original |
| Transform=log + ExtIF | Outlier isolation ratio compressed 1000x → 2x | Trees split on value magnitude |
| Reduction=None + HDBSCAN | Curse of dimensionality | Needs UMAP pre-reduction (default=path 4) |
| Reduction=None + GMM | EM singularity risk | Needs PCA (default=path 2) |
| Missing=ZERO + Benford | Digit 0 undefined in Benford's law | Need DROP or MEDIAN with positive values |
| DROP cumulative | 150 cols × 3% → 50%+ row loss | Per-column 5% guard but no cumulative guard |

---

**Status:** Analysis complete. Implementation starts tomorrow.
**V31 app:** Running on port 8117. No code changes made today for preprocessing bugs.
**Previous completed work:** V31 scoring enhancement (79/79 audit passed).
