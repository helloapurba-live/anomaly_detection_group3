# AIM AI Vault — Complete Version History & Technical Documentation
## FCDAI Anomaly Auto Detection System — V10 through V17
### Internal Bank AML Team — Air-Gapped Deployment

> **Classification**: CONFIDENTIAL — INTERNAL USE ONLY  
> **Document Date**: February 14, 2026  
> **System**: AIM AI Vault — 7-Layer AML Anomaly Detection Engine  
> **Platform**: Windows 11 (air-gapped workstation, zero cloud dependency)  
> **Framework**: Dash + Dash Mantine Components + AG Grid + Plotly + FastAPI  
> **Python**: 3.11 (Conda environment `ai311`)  
> **Database**: SQLite + SQLAlchemy (WAL mode)  
> **Encryption**: Fernet 256-bit AES-128-CBC  

---

## Table of Contents

1. [Architecture Overview](#1-architecture-overview)
2. [Version 10 — Production Core](#2-version-10--production-core-100)
3. [Version 11 — Feature Expansion](#3-version-11--feature-expansion-110)
4. [Version 12 — Bank Audit Compliance](#4-version-12--bank-audit-compliance-120)
5. [Version 13 — Health Audit Fixes](#5-version-13--health-audit-fixes-130)
6. [Version 14 — Enterprise Hardening](#6-version-14--enterprise-hardening-140)
7. [Version 15 — REST API & Documentation](#7-version-15--rest-api--documentation-150)
8. [Version 16 — Bank Audit Hardening (A4/A5/A6)](#8-version-16--bank-audit-hardening-a4a5a6-160)
9. [Version 17 — Full Wiring & Privacy Enforcement](#9-version-17--full-wiring--privacy-enforcement-170)
10. [Database Schema Evolution](#10-database-schema-evolution)
11. [File Inventory & Modification Log](#11-file-inventory--modification-log)
12. [Configuration Reference](#12-configuration-reference)
13. [Security Controls Summary](#13-security-controls-summary)
14. [Running the Application](#14-running-the-application)

---

## 1. Architecture Overview

### 7-Layer Detection Pipeline

```
┌─────────────────────────────────────────────────────────┐
│                    AIM AI VAULT V17                       │
│              26 Methods · 8 Categories · 7 Layers        │
├─────────────────────────────────────────────────────────┤
│  L1: STATISTICAL     │ Z-Score, IQR, Benford's Law,     │
│                       │ Mahalanobis Distance              │
├───────────────────────┼──────────────────────────────────┤
│  L2: MACHINE LEARNING │ Isolation Forest, Extended IF,    │
│                       │ LOF, KNN                          │
├───────────────────────┼──────────────────────────────────┤
│  L3: DEEP LEARNING    │ Autoencoder, VAE, LSTM-AE         │
├───────────────────────┼──────────────────────────────────┤
│  L4: GRAPH ANALYTICS  │ Community Detection, PageRank,    │
│                       │ HDBSCAN, DBSCAN                   │
├───────────────────────┼──────────────────────────────────┤
│  L5: TEMPORAL         │ Rolling stats, velocity,          │
│                       │ structural break, seasonality     │
├───────────────────────┼──────────────────────────────────┤
│  L6: ENSEMBLE         │ Weighted voting, risk tiering,    │
│                       │ score normalization, epsilon-tol   │
├───────────────────────┼──────────────────────────────────┤
│  L7: NETWORK          │ Cross-entity link analysis,       │
│                       │ flow pattern detection             │
└─────────────────────────────────────────────────────────┘
```

### System Architecture

```
┌─────────────────────────────────────────────────┐
│                   CLIENTS                        │
│     Browser (Dash UI)    REST API Consumers      │
│     Port 8078            Port 8079               │
├────────────────┬────────────────────────────────┤
│   DASH APP     │     FASTAPI SERVER              │
│  (Waitress     │    (Uvicorn, JWT/API Key auth)  │
│   WSGI)        │    14 RESTful endpoints          │
├────────────────┴────────────────────────────────┤
│              SERVICE LAYER                       │
│   PipelineService    DataService    AuthService   │
├─────────────────────────────────────────────────┤
│             DATA VAULT (Parquet)                  │
│   current.parquet  scored.parquet  sources/       │
├─────────────────────────────────────────────────┤
│        SQLite + SQLAlchemy (WAL mode)            │
│   users  anomalies  audit_logs  alert_events     │
│   pii_access_logs  hash_verifications            │
├─────────────────────────────────────────────────┤
│            SECURITY LAYER                        │
│   Fernet encryption · SHA-256 hash chain         │
│   PII masking · RBAC · Flask-Login sessions      │
└─────────────────────────────────────────────────┘
```

### Air-Gapped Constraints

| Constraint | Implementation |
|------------|----------------|
| Zero PII Leakage | SHA-256 hashed entity IDs, masked columns in all views |
| Air-Gapped | No network calls, no cloud APIs, `serve_locally=True` |
| Bank Audit-Proof | All config changes logged, all actions hash-chained |
| No "SAR" Terminology | Replaced with "narrative" throughout |
| Offline Only | Cron parsing local, HTML reports via string templates |
| Windows 11 Compatible | `pathlib` paths, Windows drive handling |

---

## 2. Version 10 — Production Core (10.0.0)

**Focus**: Foundation — SQLite backend, authentication, and core pipeline

### What Was Built

| Component | Description |
|-----------|-------------|
| **SQLite + SQLAlchemy** | Persistent backend with WAL mode for concurrent reads |
| **Flask-Login Auth** | Multi-user authentication with session management |
| **RBAC** | Admin / Investigator / Viewer three-tier role hierarchy |
| **Diskcache** | Background task queue for pipeline execution |
| **Polars Ingestion** | Fast data loading (Polars → Pandas handoff) |
| **26 Detection Methods** | Full 7-layer pipeline operational |
| **PII Masking** | Base `mask_dataframe()` utility with column detection |
| **Fernet Encryption** | AES-128-CBC via `cryptography` library for data at rest |
| **Dual Audit Logging** | File-based + SQLite audit trail with hash chain |
| **Dashboard** | Dash + Mantine Components with AG Grid tables |

### Key Files Created

| File | Purpose |
|------|---------|
| `app.py` | Main application entry point |
| `config.py` | Centralized configuration (dataclasses) |
| `pipeline.py` | 7-layer detection engine |
| `database/engine.py` | SQLAlchemy engine + session management |
| `database/models.py` | ORM models (users, anomalies, audit_logs) |
| `auth/manager.py` | Flask-Login integration, RBAC decorator |
| `utils/data_io.py` | DataVault — Parquet persistence layer |
| `utils/pii_masking.py` | PII detection and masking functions |
| `utils/crypto.py` | Fernet encryption + entity ID hashing |
| `utils/logger.py` | Audit logger with hash chain integrity |

### Database Tables (Initial)

| Table | Purpose |
|-------|---------|
| `users` | Authentication — username, password_hash, role |
| `anomalies` | Scored records from pipeline runs |
| `audit_logs` | Tamper-evident audit trail with hash chain |
| `pipeline_runs` | Pipeline execution metadata |

### Dashboard Port: 8071

---

## 3. Version 11 — Feature Expansion (11.0.0)

**Focus**: 15 new features — pages, reports, monitoring, scheduler

### Enhancements Implemented

| # | Feature | File | Route |
|---|---------|------|-------|
| #5 | Live Customer Aggregate Table | `pages/pipeline_run.py` | `/pipeline` |
| #6 | Pipeline Run History | `pages/run_history.py` (NEW) | `/run-history` |
| #7 | Scheduled Pipeline Runs | `pages/run_history.py` | `/run-history` |
| #8 | Pipeline Run Export (CSV) | `pages/run_history.py` | `/run-history` |
| #9 | On-Screen Alert Center | `pages/alert_center.py` (NEW) | `/alerts` |
| #11 | HTML Report Generator | `pages/report_generator.py` (NEW) | `/reports` |
| #12 | Narrative Compliance Template | `pages/report_generator.py` | `/reports` |
| #13 | Regulatory Dashboard | `pages/regulatory_dashboard.py` (NEW) | `/regulatory` |
| #14 | Graph Network Visualization | `pages/graph_network.py` (NEW) | `/graph` |
| #15 | Real-Time Config Editor | `pages/config_panel.py` (MOD) | `/config` |
| #16 | Database Backup/Restore UI | `pages/admin.py` (MOD) | `/admin` |
| #17 | Dark/Light Mode Auto-Detect | `app.py` (MOD) | — |
| #18 | Model Drift Monitoring | `pages/drift_monitor.py` (NEW) | `/drift` |
| #19 | Feature Importance Trends | `pages/feature_trends.py` (NEW) | `/feature-trends` |
| #20 | What-If Simulator | `pages/what_if.py` (NEW) | `/what-if` |

### New Database Tables

| Table | Purpose |
|-------|---------|
| `scheduled_runs` | Recurring pipeline schedules (offline cron) |
| `alert_events` | On-screen critical alert history |
| `investigation_reports` | Generated narrative/report metadata |
| `drift_snapshots` | Per-run score distribution snapshots |
| `config_snapshots` | Config editor audit trail |
| `db_backups` | Backup/restore event log |

### New Configuration Classes

| Class | Key Settings |
|-------|-------------|
| `SchedulerConfig` | ENABLED, CHECK_INTERVAL_SEC=60, MAX_CONCURRENT_RUNS=1 |
| `AlertConfig` | CRITICAL_THRESHOLD=0.95, HIGH_THRESHOLD=0.85 |
| `ReportConfig` | OUTPUT_DIR="data/reports", INCLUDE_PII=False |
| `DriftConfig` | PSI_THRESHOLD=0.20, KS_TEST_ALPHA=0.05 |

### Skipped Features
- #1–#4: Security Hardening (not requested)
- #10: Webhook Integration (requires network — violates air-gap)

### Dashboard Port: 8071

### Files Modified: 6 | Files Created: 8 | Total: 14

---

## 4. Version 12 — Bank Audit Compliance (12.0.0)

**Focus**: Comprehensive bank security audit — 16 CRITICAL/HIGH/MEDIUM findings remediated

### Audit Outcome

| Severity | Found | Remediated | Remaining |
|----------|-------|------------|-----------|
| CRITICAL | 5 | 5 | 0 |
| HIGH | 4 | 4 | 0 |
| MEDIUM | 7 | 7 | 0 |
| LOW | 3 | 0 | 3 (accepted risk) |
| INFO | 22 | — | — (positive confirmations) |

### Key Fixes Applied

#### PII Protection
- Export PII masking enforced in slot export and bulk ZIP export
- Investigation Queue customer cards show `XXXX` + last 4 only
- CSV formula injection protection (`=`, `+`, `-`, `@`, `\t`, `\r` prefixes sanitized)
- MASK_COLUMNS synced with centralized `PIIConfig.MASKED_COLUMNS`

#### Access Control
- `SESSION_COOKIE_HTTPONLY = True` — prevents JavaScript session cookie access
- `SESSION_COOKIE_SAMESITE = "Lax"` — CSRF protection
- Custom cookie name `aim_vault_session` (no framework fingerprint)
- Session timeout set to 8 hours (28800 seconds)
- All 21 pages enforced with `@require_role()` decorator

#### Credential Management
- Seed passwords via environment variables (`VAULT_ADMIN_PASS`, etc.)
- No credentials in startup banner — shows "Contact your system administrator"
- No plaintext passwords in source code

#### Error Handling
- 32 instances of `str(e)` in user-facing UI sanitized to generic messages
- 20 `print()` replaced with structured `_pipeline_logger`
- `DEBUG = False` enforced

#### Cryptography
- `cryptography` package made MANDATORY — `SystemExit` if missing

### 20/20 Bank Compliance Controls Verified

### Dashboard Port: 8072  
### Files Modified: 27

---

## 5. Version 13 — Health Audit Fixes (13.0.0)

**Focus**: 26 health audit fixes — stability, performance, consistency, and safety

### Fix Categories

#### Fixes (F) — Crash Prevention
| Fix | Description | File |
|-----|-------------|------|
| F-1 | `safe_session` / `write_session` context managers | `database/engine.py` |
| F-2 | Sanitized error messages in pipeline | `pipeline.py` |
| F-3 | Safe `load_user` int() conversion | `auth/manager.py` |
| F-4 | Logged corrupt Parquet errors in DataVault | `utils/data_io.py` |
| F-6 | Safe Diskcache creation (no crash on disk full) | `app.py` |
| F-7 | Atomic pipeline status write | `pipeline.py` |

#### Bottleneck (B) — Performance
| Fix | Description | File |
|-----|-------------|------|
| B-1/B-3 | Reduced polling intervals (30s/15s) | Multiple pages |
| B-2/S-5 | Parallel L5 detection (ThreadPoolExecutor) | `pipeline.py` |
| B-4/S-4 | Lazy Parquet loading in DataVault | `utils/data_io.py` |
| B-5 | Chunked DataFrame hashing | `utils/data_io.py` |
| B-6/S-2 | Reduced DataFrame copies | Multiple |
| B-7/C-4 | Batched hash chain persistence | `utils/logger.py` |

#### Consistency (C) — State Management
| Fix | Description | File |
|-----|-------------|------|
| C-1 | Diskcache cleared on startup | `app.py` |
| C-2 | Memory release on vault reload | `utils/data_io.py` |
| C-3 | Fernet key rotation age warning | `utils/crypto.py` |

#### Safety (S) — Thread Safety & Data Integrity
| Fix | Description | File |
|-----|-------------|------|
| S-1 | DB write serialization (threading.Lock + retry) | `database/engine.py` |
| S-6 | Audit log archival | `database/models.py` |

### Also Added
- 12 premium themes (Material, Dracula, Nord, Solarized, Tokyo Night, etc.)
- Theme config via `ThemeConfig` dataclass

### Dashboard Port: 8072

---

## 6. Version 14 — Enterprise Hardening (14.0.0)

**Focus**: Production-grade infrastructure — WSGI, observability, fault tolerance

### Enhancement Categories

#### 1. Scalability
| Feature | Description |
|---------|-------------|
| **Waitress WSGI** | Pure-Python, Windows-native production server (replaces dev server) |
| **ProcessPoolExecutor** | Parallel execution for L5 temporal methods |
| **TOML Config Override** | `config.toml` overrides dataclass defaults without code edits |

#### 2. Robustness
| Feature | Description |
|---------|-------------|
| **Circuit Breaker** | Fault isolation for pipeline layers (failure threshold, recovery timeout) |
| **Graceful Degradation** | Failed layers excluded from ensemble, pipeline continues |
| **SystemWatchdog** | Background thread monitoring CPU, memory, disk, thread count |

#### 3. Consistency
| Feature | Description |
|---------|-------------|
| **Data Contracts** | Input/output schema validation for pipeline stages |
| **Error Codes** | Standardized error codes for all failure modes |
| **Service Layer** | `PipelineService` and `DataService` abstraction |

#### 4. Persistence
| Feature | Description |
|---------|-------------|
| **Run Partitioning** | Parquet files partitioned by `run_id` |
| **Backup Automation** | Automated WAL checkpoint + file copy |

#### 5. Observability
| Feature | Description |
|---------|-------------|
| **Structured JSON Logging** | Machine-parseable log format with correlation IDs |
| **System Health Page** | `/health` — real-time CPU/memory/disk/thread metrics |
| **Help Page** | `/help` — in-app documentation and guidance |
| **cProfile Integration** | Optional per-run profiling with top-N function analysis |

#### 7. UX / Frontend
| Feature | Description |
|---------|-------------|
| **Loading States** | Visual feedback during long operations |
| **Keyboard Shortcuts** | Ctrl+R refresh, Ctrl+H help |
| **Offline Help** | All help content bundled with application |

### New Configuration Classes

| Class | Key Settings |
|-------|-------------|
| `WaitressConfig` | THREADS=4, CHANNEL_TIMEOUT=120, MAX_REQUEST_BODY_SIZE=104857600 |
| `WatchdogConfig` | INTERVAL_SEC=30, CPU_THRESHOLD=90, MEMORY_THRESHOLD_MB=7000 |
| `LoggingConfig` | FORMAT="json", MAX_MESSAGE_LENGTH=1000, ERROR_AGGREGATION=True |
| `HealthConfig` | ENDPOINT_ENABLED=True, DB_CHECK_TIMEOUT_SEC=5 |
| `ProfilingConfig` | ENABLED=False, TOP_N_FUNCTIONS=30 |
| `CircuitBreakerConfig` | FAILURE_THRESHOLD=3, RECOVERY_TIMEOUT_SEC=300 |

### Dashboard Port: 8078

---

## 7. Version 15 — REST API & Documentation (15.0.0)

**Focus**: FastAPI REST API for machine-to-machine integration + full documentation suite

### API Endpoints (14 Total)

| Category | Endpoint | Method | Description |
|----------|----------|--------|-------------|
| **Auth** | `/api/v1/auth/token` | POST | Get JWT token |
| **Auth** | `/api/v1/auth/api-key` | POST | Create API key |
| **Auth** | `/api/v1/auth/api-keys` | GET | List API keys |
| **Pipeline** | `/api/v1/pipeline/run` | POST | Trigger pipeline run |
| **Pipeline** | `/api/v1/pipeline/status` | GET | Current pipeline status |
| **Pipeline** | `/api/v1/pipeline/history` | GET | Run history |
| **Results** | `/api/v1/results/scored` | GET | Scored data (paginated) |
| **Results** | `/api/v1/results/alerts` | GET | Alert queue |
| **Results** | `/api/v1/results/risk-tiers` | GET | Risk tier summary |
| **Results** | `/api/v1/results/entity/{id}` | GET | Entity detail |
| **Data** | `/api/v1/data/sources` | GET | Source listing |
| **Audit** | `/api/v1/audit/log` | GET | Audit entries |
| **Audit** | `/api/v1/audit/verify` | GET | Hash chain verification |
| **System** | `/api/v1/system/health` | GET | System health |

### Authentication

| Method | Description |
|--------|-------------|
| **JWT** | HMAC-SHA256 tokens, 24-hour expiry, stdlib-only (no PyJWT) |
| **API Key** | SHA-256 hashed, stored in SQLite, revocable |
| **Dual Auth** | Both `Authorization: Bearer <JWT>` and `X-API-Key: <key>` accepted |

### API Security

| Feature | Implementation |
|---------|----------------|
| RBAC | Endpoint-level permission enforcement by role |
| Rate Limiting | Sliding window, 100 requests/min per client |
| PII Masking | Role-based response masking (Admin: hash, Investigator: partial, Viewer: redacted) |
| Audit Logging | Every API call hash-chain logged |
| Request IDs | UUID correlation for tracing |

### Documentation Suite Created

| File | Content |
|------|---------|
| `ARCHITECTURE.md` | System architecture and layer descriptions |
| `API_REFERENCE.md` | Complete API endpoint documentation |
| `DEPLOYMENT.md` | Installation and deployment guide |
| `DATA_DICTIONARY.md` | Column definitions and data types |
| `COMPLIANCE.md` | Regulatory compliance mapping |
| `RUNBOOK.md` | Operational procedures and troubleshooting |
| `SECURITY.md` | Security controls and threat model |
| `CONTRIBUTING.md` | Development guidelines |
| `README.md` | Project overview and quick start |
| `CHANGELOG.md` | Version history in Keep a Changelog format |
| `config.toml.example` | Documented configuration template |
| `pyproject.toml` | Python project metadata |
| `Makefile` | Build and development commands |
| `.gitignore` | VCS ignore rules |
| `LICENSE` | Proprietary license — internal bank use only |

### V15 Optimization (23 Fixes)
After initial V15 creation, 23 optimizations applied across 11 files:
- Reduced redundant imports
- Fixed callback registration ordering
- Improved error handling in API routes
- Standardized response schemas

### Ports: Dashboard 8078 | API 8079

---

## 8. Version 16 — Bank Audit Hardening: A4/A5/A6 (16.0.0)

**Focus**: Three bank audit hardening actions + config independence + air-gap reinforcement

### A4: PII Masking Enforcement with Safety Lock

| Feature | Description |
|---------|-------------|
| `ENABLED_BY_DEFAULT = True` | PII masking is ON by default |
| `ALLOW_PII_DISABLE = False` | Safety lock — cannot be disabled without explicit TOML dual-flag |
| `MASK_IN_MEMORY = True` | In-memory DataVault views are masked |
| `MASK_IN_API = True` | API responses are masked |
| `LOG_PII_ACCESS = True` | Every PII column access is audit-logged |

**Safety Lock Mechanism**: To disable PII masking, the operator must set **BOTH**:
```toml
[pii]
ENABLED_BY_DEFAULT = false
ALLOW_PII_DISABLE = true
```
Setting only one flag has no effect — the safety lock prevents accidental exposure.

### A5: Epsilon Tolerance for Risk Tiers

| Feature | Description |
|---------|-------------|
| `RISK_TIER_EPSILON = 1e-9` | Float boundary tolerance for tier classification |
| Wired into L6 ensemble | Score comparisons use `>=` with epsilon adjustment |

### A6: Hash Chain Hardening

| Feature | Description |
|---------|-------------|
| `HASH_CHAIN_VERIFY_ON_LOAD = True` | Auto-verify integrity when loading persisted state |
| `HASH_CHAIN_BACKUP_COUNT = 3` | Keep N rotating backup copies of hash state file |
| `HASH_CHAIN_BATCH_INTERVAL = 10` | Persist every N actions (TOML-configurable) |
| `verify_hash_chain()` method | On-demand integrity check callable from UI/API |
| Corruption recovery | Auto-restores from backup if primary state file is corrupted |

### New Database Tables

| Table | Columns | Purpose |
|-------|---------|---------|
| `pii_access_logs` | caller, columns_accessed, n_rows, masking_applied, user_id, username, client_ip, created_at | Regulatory audit of PII column access |
| `hash_verifications` | status, entries_checked, mismatches, mismatch_lines, current_hash, disk_hash, triggered_by, verified_by, verified_at, notes | Hash chain integrity check results |

### New PII Wrapper Functions (Declared but NOT Wired in V16)

| Function | Purpose |
|----------|---------|
| `mask_for_memory(df)` | PII masking for in-memory DataVault views |
| `mask_for_api(df)` | PII masking for REST API DataFrame responses |
| `mask_for_storage(df)` | PII masking for on-disk Parquet files |
| `mask_for_export(df)` | PII masking for data exports |

### Air-Gap Network Check

New `_check_airgap_compliance()` function in `app.py`:
- Scans all network interfaces on startup
- Private IPs (RFC 1918: 10.x, 172.16-31.x, 192.168.x) → INFO level
- Public IPs → WARNING level (may indicate external connectivity)

### CONFIG_INDEPENDENCE_GUIDE.md Created
Complete guide for changing any parameter via `config.toml` without code edits.

### V16 Gap Analysis (Found During Audit)
A thorough code audit of V16 revealed **9 gaps** where features were declared in config/models but NOT wired into execution code:

| Gap | Description | Severity |
|-----|-------------|----------|
| E1 | `mask_for_memory()` never called | HIGH |
| E2 | `mask_for_api()` never called | HIGH |
| E3 | `PIIAccessLog` table never written to | HIGH |
| E4 | `HashVerification` table never written to | HIGH |
| E5 | `DataService` returns unmasked data | HIGH |
| E6 | `AIRGAP_CHECK` not in AppConfig | HIGH |
| E7 | `mask_for_storage()`/`mask_for_export()` wrappers never called (inline code used) | MEDIUM |
| E8 | No hash chain verify button in Dash UI | MEDIUM |
| E9 | `ALLOW_PII_DISABLE` safety lock not enforced in data_io.py | MEDIUM |

**These 9 gaps are the direct motivation for V17.**

### Files Modified: 6

---

## 9. Version 17 — Full Wiring & Privacy Enforcement (17.0.0)

**Focus**: Wire ALL V16 declared features into execution code — close all 9 gaps

**Context**: Internal bank team, air-gapped deployment, maximum privacy enforcement

### All 9 Enhancements — Implementation Details

---

#### E1: `mask_for_memory()` Wired Into All Data-Load Paths

**File**: `utils/data_io.py`  
**Severity**: HIGH → RESOLVED

**Problem**: DataVault loaded Parquet files into memory without PII masking. Any page reading from the vault saw raw PII data.

**Solution**: Added `mask_for_memory()` calls at every data-load entry point:

| Function | Line | What Changed |
|----------|------|-------------|
| `_load_persisted_data()` | After `pd.read_parquet(current.parquet)` | Apply `mask_for_memory()` to `self._current_data` |
| `_load_persisted_data()` | After `pd.read_parquet(scored.parquet)` | Apply `mask_for_memory()` to `self._scored_data` |
| `_load_persisted_data()` | Source tables loop | Each source DataFrame masked after Parquet load |
| `load_sources()` | Lazy load loop | Each source DataFrame masked after Parquet load |

**Code Pattern**:
```python
# BEFORE (V16):
self._current_data = pd.read_parquet(vault_path)

# AFTER (V17 E1):
self._current_data = pd.read_parquet(vault_path)
from utils.pii_masking import mask_for_memory
self._current_data = mask_for_memory(self._current_data)
```

**Behavior**: `mask_for_memory()` checks `PII.MASK_IN_MEMORY` — if True, detects PII columns and masks them. Original Parquet files on disk remain unchanged.

---

#### E2: `mask_for_api()` Wired Into REST API DataFrame Endpoints

**File**: `api/routes.py`  
**Severity**: HIGH → RESOLVED

**Problem**: API endpoints used `mask_pii_in_dict()` (dict-level masking from middleware) but never applied `mask_for_api()` (DataFrame-level masking from pii_masking.py). This meant PII columns not in the middleware's hardcoded `PII_FIELD_NAMES` set were leaked.

**Solution**: Apply `mask_for_api()` on DataFrames **before** converting to dicts, keeping `mask_pii_in_dict()` as defense-in-depth:

| Endpoint | What Changed |
|----------|-------------|
| `GET /results/scored` | `page_df = mask_for_api(page_df)` before `.to_dict(orient="records")` |
| `GET /results/alerts` | `page_df = mask_for_api(page_df)` before `.to_dict(orient="records")` |
| `GET /results/entity/{id}` | Single-row DataFrame created, `mask_for_api()` applied |

**Code Pattern**:
```python
# V17 E2: DataFrame-level PII masking first, then dict-level as defense-in-depth
from utils.pii_masking import mask_for_api
page_df = mask_for_api(page_df)
items = [
    mask_pii_in_dict(row, user["role"])  # Second layer — role-based
    for row in page_df.to_dict(orient="records")
]
```

**Defense-in-Depth Strategy**:
1. **Layer 1 (DataFrame)**: `mask_for_api()` — uses `PII.MASKED_COLUMNS` config + auto-detection
2. **Layer 2 (Dict)**: `mask_pii_in_dict()` — uses hardcoded `PII_FIELD_NAMES` set, role-based masking style

---

#### E3: `PIIAccessLog` Table Now Populated

**File**: `utils/pii_masking.py`  
**Severity**: HIGH → RESOLVED

**Problem**: The `PIIAccessLog` SQLAlchemy model existed in `database/models.py` but `_log_pii_access()` only wrote to the audit_logs table (via `logger.log_action()`), never to the dedicated `pii_access_logs` table.

**Solution**: Added SQLAlchemy write to `_log_pii_access()`:

```python
# V17 E3: Write to PIIAccessLog SQLAlchemy table for regulatory audit
try:
    from database.engine import write_session
    from database.models import PIIAccessLog
    with write_session() as session:
        session.add(PIIAccessLog(
            caller=caller[:128],
            columns_accessed=json.dumps(columns),
            n_rows=n_rows,
            masking_applied=True,
            username="system",
            client_ip="127.0.0.1",
        ))
except Exception:
    pass  # non-blocking — best-effort audit
```

**Writes are non-blocking**: If the DB write fails, the masking operation still completes. The audit trail in `audit_logs` is the primary record; `pii_access_logs` provides the structured regulatory view.

---

#### E4: `HashVerification` Table Now Populated

**Files**: `api/routes.py`, `pages/audit_trail.py`  
**Severity**: HIGH → RESOLVED

**Problem**: The `HashVerification` SQLAlchemy model existed but was never written to. The API `/audit/verify` endpoint reimplemented hash chain verification with raw SQL instead of using `logger.verify_hash_chain()`.

**Solution (two write points)**:

| Location | Triggered By | `triggered_by` Value |
|----------|-------------|---------------------|
| `api/routes.py` — `/audit/verify` endpoint | API call | `"api"` |
| `pages/audit_trail.py` — Verify button callback | UI button click | `"ui"` |

**API endpoint rewritten** to use `logger.verify_hash_chain()`:
```python
# V17 E4: Use the V16 logger.verify_hash_chain() method
from utils.logger import logger as audit_logger
result = audit_logger.verify_hash_chain()

# Persist result to HashVerification DB table
from database.models import HashVerification as HVModel
with write_session() as session:
    session.add(HVModel(
        status=result.get("status", "UNKNOWN"),
        entries_checked=result.get("entries_checked", 0),
        mismatches=len(result.get("mismatches", [])),
        mismatch_lines=json.dumps(result.get("mismatches", [])),
        ...
    ))
```

---

#### E5: DataService PII Gate — All Getters Mask Before Returning

**File**: `services/data_service.py`  
**Severity**: HIGH → RESOLVED

**Problem**: `DataService.get_current_data()`, `get_scored_data()`, and `get_source()` returned raw DataFrames from the vault with no PII masking. Any page calling these methods got unmasked data.

**Solution**: Added `mask_for_memory()` gate to all three getters:

| Method | What Changed |
|--------|-------------|
| `get_current_data()` | `df = mask_for_memory(df)` before return |
| `get_scored_data()` | `df = mask_for_memory(df)` before return |
| `get_source(name)` | `df = mask_for_memory(df)` before return |

**Code Pattern**:
```python
def get_current_data(self) -> Optional[pd.DataFrame]:
    """V17 E5: PII gate — applies mask_for_memory() before returning."""
    try:
        df = self._vault.get_current_data()
        if df is not None:
            from utils.pii_masking import mask_for_memory
            df = mask_for_memory(df)
        return df
    except Exception as exc:
        return None
```

**Double protection**: The vault already masks on load (E1), and the service layer masks again on access (E5). This is intentional — defense-in-depth for PII.

---

#### E6: `AIRGAP_CHECK` Config Parameter — TOML-Toggleable

**Files**: `config.py`, `app.py`, `config.toml`  
**Severity**: HIGH → RESOLVED

**Problem**: The air-gap network check was hardcoded to always run on startup. On machines with multiple NICs (common in enterprise setups), operators had no way to suppress the check.

**Solution**:

| File | What Changed |
|------|-------------|
| `config.py` | Added `AIRGAP_CHECK: bool = True` to `AppConfig` dataclass |
| `app.py` | `_check_airgap_compliance()` checks `APP.AIRGAP_CHECK` before running |
| `config.toml` | Added `# AIRGAP_CHECK = true` entry under `[app]` section |

**To disable** (in config.toml):
```toml
[app]
AIRGAP_CHECK = false
```

---

#### E7: Inline `mask_dataframe()` Replaced With V16 Wrappers

**File**: `utils/data_io.py`  
**Severity**: MEDIUM → RESOLVED

**Problem**: `save_sources()` and `export_scorecard()` used inline calls to `mask_dataframe()` + `detect_pii_columns()`, bypassing the V16 wrapper functions that enforce the safety lock.

**Solution**:

| Function | Before (V16) | After (V17) |
|----------|-------------|-------------|
| `save_sources()` | `from utils.pii_masking import mask_dataframe, detect_pii_columns` → manual call | `from utils.pii_masking import mask_for_storage` → `df_to_save = mask_for_storage(df_to_save)` |
| `export_scorecard()` | `from utils.pii_masking import mask_dataframe, detect_pii_columns` → manual call | `from utils.pii_masking import mask_for_export` → `df = mask_for_export(df)` |

---

#### E8: Hash Chain Verify Button in Dash Audit Trail Page

**File**: `pages/audit_trail.py`  
**Severity**: MEDIUM → RESOLVED

**Problem**: The audit trail page had no UI for hash chain verification. Users had to use the API endpoint or check logs manually.

**Solution**: Added a dedicated verification panel with button and result display:

**Layout Addition**:
- Teal shield icon with "Hash Chain Integrity" header
- "Verify Hash Chain" button (teal, filled variant)
- Result div (`hashchain-verify-result`) for displaying outcome

**Callback**: New `verify_hash_chain(n_clicks)` callback:
1. Calls `logger.verify_hash_chain()` from `utils/logger.py`
2. Persists result to `HashVerification` table (E4 integration)
3. Displays color-coded result alert:
   - **Green**: PASS — chain is intact
   - **Yellow**: DEGRADED — minor mismatches (≤3 lines)
   - **Red**: FAIL — integrity compromised
4. Shows: status, entries checked, current hash, disk hash, mismatches, timestamp

---

#### E9: `ALLOW_PII_DISABLE` Safety Lock Enforced Via Wrappers

**File**: `utils/data_io.py` (via E7 changes)  
**Severity**: MEDIUM → RESOLVED

**Problem**: `save_sources()` and `export_scorecard()` called `mask_dataframe()` directly with `enabled=True`, bypassing the safety lock check that only exists in the `mask_for_*()` wrappers.

**Solution**: By routing all masking through `mask_for_storage()`, `mask_for_export()`, `mask_for_memory()`, and `mask_for_api()` (E7), the safety lock is now enforced everywhere:

```python
# Inside mask_dataframe() — called by all wrappers:
if PII.ENABLED_BY_DEFAULT and not PII.ALLOW_PII_DISABLE:
    effective_enabled = True  # Cannot be disabled without explicit TOML override
```

**Result**: All data paths now flow through wrappers → `mask_dataframe()` → safety lock check. There is no code path that can bypass the safety lock.

---

### V17 Files Modified Summary

| # | File | Changes | Enhancement |
|---|------|---------|-------------|
| 1 | `config.py` | Version 17.0.0, V17 tag, AIRGAP_CHECK field, updated docstring | E6 |
| 2 | `app.py` | `_check_airgap_compliance()` reads `APP.AIRGAP_CHECK`, skips if False | E6 |
| 3 | `utils/data_io.py` | `_load_persisted_data()`, `load_sources()` → `mask_for_memory()`; `save_sources()` → `mask_for_storage()`; `export_scorecard()` → `mask_for_export()` | E1, E7, E9 |
| 4 | `utils/pii_masking.py` | `_log_pii_access()` writes to `PIIAccessLog` table via SQLAlchemy | E3 |
| 5 | `services/data_service.py` | `get_current_data()`, `get_scored_data()`, `get_source()` → `mask_for_memory()` gate | E5 |
| 6 | `api/routes.py` | 3 endpoints get `mask_for_api()` call; `/audit/verify` uses `logger.verify_hash_chain()` + writes `HashVerification` | E2, E4 |
| 7 | `pages/audit_trail.py` | Hash chain verify button + callback + `HashVerification` DB write | E8, E4 |
| 8 | `config.toml` | Version 17.0.0, `AIRGAP_CHECK = true` entry | E6 |

### Syntax Verification: 7/7 files pass `py_compile`

---

## 10. Database Schema Evolution

### Tables by Version

| Table | Added In | Purpose |
|-------|----------|---------|
| `users` | V10 | Authentication — username, password_hash, role |
| `anomalies` | V10 | Scored records from pipeline runs |
| `audit_logs` | V10 | Tamper-evident audit trail with hash chain |
| `pipeline_runs` | V10 | Pipeline execution metadata |
| `scheduled_runs` | V11 | Recurring pipeline schedules |
| `alert_events` | V11 | On-screen alert history |
| `investigation_reports` | V11 | Generated report metadata |
| `drift_snapshots` | V11 | Score distribution tracking |
| `config_snapshots` | V11 | Config change audit trail |
| `db_backups` | V11 | Backup/restore event log |
| `pii_access_logs` | V16 | PII column access regulatory audit |
| `hash_verifications` | V16 | Hash chain integrity check results |

### V16 Tables — Wiring Status

| Table | V16 Status | V17 Status |
|-------|-----------|-----------|
| `pii_access_logs` | Schema declared, NEVER written to | **ACTIVE** — written by `_log_pii_access()` |
| `hash_verifications` | Schema declared, NEVER written to | **ACTIVE** — written by API `/audit/verify` and Dash UI verify button |

---

## 11. File Inventory & Modification Log

### Core Application Files

| File | Created | Last Modified | Purpose |
|------|---------|---------------|---------|
| `app.py` | V10 | V17 | Main Dash application + air-gap check |
| `config.py` | V10 | V17 | Centralized configuration (25+ dataclasses) |
| `config.toml` | V16 | V17 | TOML override template |
| `pipeline.py` | V10 | V14 | 7-layer detection engine |

### Database Layer

| File | Created | Last Modified | Purpose |
|------|---------|---------------|---------|
| `database/engine.py` | V10 | V13 | SQLAlchemy engine, session management, write locks |
| `database/models.py` | V10 | V16 | ORM models (12 tables) |

### Utilities

| File | Created | Last Modified | Purpose |
|------|---------|---------------|---------|
| `utils/data_io.py` | V10 | V17 | DataVault — Parquet persistence |
| `utils/pii_masking.py` | V10 | V17 | PII detection and masking |
| `utils/logger.py` | V10 | V16 | Audit logger with hash chain |
| `utils/crypto.py` | V10 | V12 | Fernet encryption + hashing |

### Services

| File | Created | Last Modified | Purpose |
|------|---------|---------------|---------|
| `services/data_service.py` | V14 | V17 | Data access abstraction |
| `services/pipeline_service.py` | V14 | V14 | Pipeline execution abstraction |

### API

| File | Created | Last Modified | Purpose |
|------|---------|---------------|---------|
| `api/routes.py` | V15 | V17 | 14 RESTful endpoints |
| `api/middleware.py` | V15 | V15 | Auth, RBAC, rate limiting, PII masking |
| `api/auth.py` | V15 | V15 | JWT + API Key authentication |
| `api/schemas.py` | V15 | V15 | Pydantic response models |

### Authentication

| File | Created | Last Modified | Purpose |
|------|---------|---------------|---------|
| `auth/manager.py` | V10 | V13 | Flask-Login + RBAC decorator |

### Dashboard Pages (21 Total)

| File | Created | Route | Required Role |
|------|---------|-------|---------------|
| `pages/dashboard.py` | V10 | `/` | viewer |
| `pages/data_sources.py` | V10 | `/sources` | investigator |
| `pages/pipeline_run.py` | V10 | `/pipeline` | investigator |
| `pages/layer_view.py` | V10 | `/layers` | viewer |
| `pages/investigation_queue.py` | V10 | `/queue` | investigator |
| `pages/narratives.py` | V10 | `/narratives` | investigator |
| `pages/audit_trail.py` | V10 | `/audit` | viewer |
| `pages/audit_vault.py` | V10 | `/audit-vault` | viewer |
| `pages/model_diagnostics.py` | V10 | `/diagnostics` | viewer |
| `pages/explainability.py` | V10 | `/explainability` | viewer |
| `pages/run_history.py` | V11 | `/run-history` | investigator |
| `pages/alert_center.py` | V11 | `/alerts` | investigator |
| `pages/report_generator.py` | V11 | `/reports` | investigator |
| `pages/regulatory_dashboard.py` | V11 | `/regulatory` | viewer |
| `pages/graph_network.py` | V11 | `/graph` | viewer |
| `pages/drift_monitor.py` | V11 | `/drift` | viewer |
| `pages/feature_trends.py` | V11 | `/feature-trends` | viewer |
| `pages/what_if.py` | V11 | `/what-if` | viewer |
| `pages/config_panel.py` | V10 | `/config` | admin |
| `pages/admin.py` | V10 | `/admin` | admin |
| `pages/task_manager.py` | V10 | `/tasks` | admin |

---

## 12. Configuration Reference

### TOML Override Map

All parameters can be overridden via `config.toml` without editing Python code.

```toml
# ── Application ──────────────────────────────────────────
[app]
# BRAND = "AIM AI Vault"
# VERSION = "17.0.0"
# HOST = "127.0.0.1"
# PORT = 8078
# DEBUG = false
# SERVE_LOCALLY = true
# AIRGAP_CHECK = true          # V17 E6: Network interface check

# ── PII Masking (A4) ────────────────────────────────────
[pii]
# ENABLED_BY_DEFAULT = true     # MUST be true for bank compliance
# ALLOW_PII_DISABLE = false     # Safety lock — requires BOTH flags
# MASK_AT_STORAGE = true        # Mask before writing to Parquet
# MASK_IN_EXPORTS = true        # Mask in CSV/Excel exports
# MASK_IN_MEMORY = true         # Mask in-memory DataVault views
# MASK_IN_API = true            # Mask in API responses
# LOG_PII_ACCESS = true         # Log every PII column access
# VISIBLE_CHARS = 4             # Characters to keep visible
# MASK_PATTERN = "XXXX"         # Replacement pattern

# ── Audit & Hash Chain (A6) ─────────────────────────────
[audit]
# ENABLE_HASH_CHAIN_LOGS = true
# HASH_CHAIN_VERIFY_ON_LOAD = true   # Auto-verify on startup
# HASH_CHAIN_BACKUP_COUNT = 3        # Backup copies of state
# HASH_CHAIN_BATCH_INTERVAL = 10     # Persist every N actions
# RISK_TIER_EPSILON = 1e-9           # Float boundary tolerance (A5)

# ── Database ─────────────────────────────────────────────
[database]
# WAL_MODE = true
# BUSY_TIMEOUT_MS = 5000
# CACHE_SIZE_KB = 64000

# ── Waitress WSGI ────────────────────────────────────────
[waitress]
# THREADS = 4
# CHANNEL_TIMEOUT = 120

# ── Watchdog ─────────────────────────────────────────────
[watchdog]
# INTERVAL_SEC = 30
# CPU_THRESHOLD = 90
# MEMORY_THRESHOLD_MB = 7000

# ── Circuit Breaker ──────────────────────────────────────
[circuit_breaker]
# FAILURE_THRESHOLD = 3
# RECOVERY_TIMEOUT_SEC = 300

# ── Logging ──────────────────────────────────────────────
[logging]
# FORMAT = "json"
# ERROR_AGGREGATION = true
```

---

## 13. Security Controls Summary

### V17 Complete Security Posture

| # | Control | Status | Enforcement Point |
|---|---------|--------|-------------------|
| 1 | PII masking enabled by default | ✅ | `config.py: PII.ENABLED_BY_DEFAULT = True` |
| 2 | Safety lock prevents disabling PII | ✅ | `pii_masking.py: mask_dataframe()` checks both flags |
| 3 | PII masked at storage (Parquet) | ✅ | `data_io.py: save_sources()` → `mask_for_storage()` |
| 4 | PII masked in exports | ✅ | `data_io.py: export_scorecard()` → `mask_for_export()` |
| 5 | PII masked in memory | ✅ | `data_io.py: _load_persisted_data()` → `mask_for_memory()` |
| 6 | PII masked in API responses | ✅ | `routes.py` → `mask_for_api()` + `mask_pii_in_dict()` |
| 7 | PII masked in DataService | ✅ | `data_service.py` → `mask_for_memory()` gate |
| 8 | PII access audit-logged (file) | ✅ | `pii_masking.py: _log_pii_access()` → `logger.log_action()` |
| 9 | PII access audit-logged (DB) | ✅ | `pii_masking.py: _log_pii_access()` → `PIIAccessLog` table |
| 10 | Hash chain tamper evidence | ✅ | `logger.py: AuditLogger` SHA-256 chain |
| 11 | Hash chain verification (API) | ✅ | `routes.py: /audit/verify` → `logger.verify_hash_chain()` |
| 12 | Hash chain verification (UI) | ✅ | `audit_trail.py` → Verify button + callback |
| 13 | Hash verification results persisted | ✅ | Both API and UI write to `HashVerification` table |
| 14 | Air-gap network check | ✅ | `app.py: _check_airgap_compliance()` |
| 15 | Air-gap check configurable | ✅ | `config.py: APP.AIRGAP_CHECK` (TOML-overridable) |
| 16 | Fernet encryption at rest | ✅ | `utils/crypto.py` — mandatory (SystemExit if missing) |
| 17 | RBAC on all 21 pages | ✅ | `@require_role()` decorator |
| 18 | RBAC on all 14 API endpoints | ✅ | `require_permission()` dependency |
| 19 | JWT + API Key dual auth | ✅ | `api/auth.py` |
| 20 | Rate limiting | ✅ | `api/middleware.py` — 100 req/min sliding window |
| 21 | Secure session cookies | ✅ | HTTPOnly, SameSite=Lax, custom name |
| 22 | Scrypt password hashing | ✅ | Memory-hard, GPU-resistant |
| 23 | Error messages sanitized | ✅ | No `str(e)` in user-facing UI |
| 24 | Structured JSON logging | ✅ | Machine-parseable, correlation IDs |
| 25 | Zero outbound network calls | ✅ | No HTTP clients, no CDN, no telemetry |

---

## 14. Running the Application

### Prerequisites
- Python 3.11+ (Anaconda `ai311` environment)
- Windows 11 (air-gapped workstation)
- No internet connection required after initial setup

### Start Commands

```bash
# Activate environment
conda activate ai311

# Navigate to V17
cd FCDAI_Annomaly_auto_detection_version17

# Run application
python app.py
```

### Access Points

| Service | URL | Purpose |
|---------|-----|---------|
| Dashboard | http://127.0.0.1:8078 | Web UI (Dash + Mantine) |
| API | http://127.0.0.1:8079 | REST API (FastAPI) |
| Swagger UI | http://127.0.0.1:8079/docs | Interactive API documentation |
| ReDoc | http://127.0.0.1:8079/redoc | Alternative API docs |

### Default Credentials

| Username | Password | Role |
|----------|----------|------|
| admin | (set via `VAULT_ADMIN_PASS` env var) | Full access |
| investigator | (set via `VAULT_INVEST_PASS` env var) | Run & review |
| viewer | (set via `VAULT_VIEWER_PASS` env var) | Read-only |

---

## Version Timeline Summary

```
V10 (Foundation)
 │  SQLite, Flask-Login, RBAC, 26 methods, Fernet, hash chain
 │
V11 (Feature Expansion)
 │  15 new features: reports, alerts, drift, graph, scheduler, what-if
 │
V12 (Bank Audit)
 │  16 CRITICAL/HIGH/MEDIUM fixes, RBAC on all 21 pages, PII hardened
 │
V13 (Health Audit)
 │  26 fixes: stability, performance, thread safety, 12 themes
 │
V14 (Enterprise)
 │  Waitress WSGI, circuit breaker, watchdog, service layer, JSON logging
 │
V15 (REST API)
 │  FastAPI (14 endpoints), JWT + API Key, Swagger, full doc suite
 │
V16 (Bank Hardening: A4/A5/A6)
 │  PII safety lock, epsilon tolerance, hash chain verification
 │  ⚠️ Features declared but NOT wired into execution code
 │
V17 (Full Wiring) ← CURRENT
    All 9 gaps closed: mask_for_memory, mask_for_api, PIIAccessLog,
    HashVerification, DataService gate, AIRGAP_CHECK, wrappers,
    audit trail verify button, safety lock enforced
```

---

*Document generated: February 14, 2026*  
*AIM AI Vault V17.0.0 — Internal Bank AML Team*  
*Classification: CONFIDENTIAL — INTERNAL USE ONLY*
