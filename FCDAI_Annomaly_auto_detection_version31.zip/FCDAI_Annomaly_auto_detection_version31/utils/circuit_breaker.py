"""
AIM AI Vault V14 — Circuit Breaker Pattern
============================================
Implements the circuit breaker pattern for pipeline layer fault tolerance.
Prevents cascading failures by temporarily disabling layers/methods that
repeatedly fail, allowing graceful degradation.

States:
  CLOSED  → Normal operation; failures counted
  OPEN    → Calls blocked; returns fallback immediately
  HALF_OPEN → Probing; allows limited calls to test recovery

Thread-safe for Dash multi-callback environment.

Author: AIM AI Vault Team
"""

import sys
import time
import threading
import logging
from enum import Enum
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, Optional, Callable, Any

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import CIRCUIT_BREAKER

_cb_logger = logging.getLogger("apurbadas.circuit_breaker")


class CircuitState(Enum):
    CLOSED = "CLOSED"
    OPEN = "OPEN"
    HALF_OPEN = "HALF_OPEN"


@dataclass
class CircuitStats:
    """Per-circuit statistics for monitoring."""
    total_calls: int = 0
    total_failures: int = 0
    total_successes: int = 0
    consecutive_failures: int = 0
    last_failure_time: float = 0.0
    last_failure_error: str = ""
    state_changes: int = 0
    last_state_change: float = 0.0


class CircuitBreaker:
    """
    Thread-safe circuit breaker for a single pipeline component.

    Usage:
        cb = CircuitBreaker("l5_isolation_forest")
        if cb.can_execute():
            try:
                result = run_detection(...)
                cb.record_success()
            except Exception as e:
                cb.record_failure(str(e))
        else:
            # Circuit is open — use fallback
            result = fallback_result(...)
    """

    def __init__(
        self,
        name: str,
        failure_threshold: int = None,
        recovery_timeout: float = None,
        half_open_max: int = None,
    ):
        self.name = name
        self.failure_threshold = failure_threshold or CIRCUIT_BREAKER.FAILURE_THRESHOLD
        self.recovery_timeout = recovery_timeout or CIRCUIT_BREAKER.RECOVERY_TIMEOUT_SEC
        self.half_open_max = half_open_max or CIRCUIT_BREAKER.HALF_OPEN_MAX_CALLS

        self._state = CircuitState.CLOSED
        self._lock = threading.Lock()
        self._stats = CircuitStats()
        self._half_open_calls = 0

    @property
    def state(self) -> CircuitState:
        with self._lock:
            return self._state

    @property
    def stats(self) -> CircuitStats:
        with self._lock:
            return CircuitStats(**self._stats.__dict__)

    def can_execute(self) -> bool:
        """Check if the circuit allows execution."""
        if not CIRCUIT_BREAKER.ENABLED:
            return True

        with self._lock:
            if self._state == CircuitState.CLOSED:
                return True

            if self._state == CircuitState.OPEN:
                # Check if recovery timeout has elapsed
                elapsed = time.time() - self._stats.last_failure_time
                if elapsed >= self.recovery_timeout:
                    self._transition_to(CircuitState.HALF_OPEN)
                    self._half_open_calls = 0
                    return True
                return False

            if self._state == CircuitState.HALF_OPEN:
                return self._half_open_calls < self.half_open_max

        return False

    def record_success(self):
        """Record a successful execution."""
        with self._lock:
            self._stats.total_calls += 1
            self._stats.total_successes += 1
            self._stats.consecutive_failures = 0

            if self._state == CircuitState.HALF_OPEN:
                _cb_logger.info(f"[CB] {self.name}: HALF_OPEN → CLOSED (recovery confirmed)")
                self._transition_to(CircuitState.CLOSED)

    def record_failure(self, error_msg: str = ""):
        """Record a failed execution."""
        with self._lock:
            self._stats.total_calls += 1
            self._stats.total_failures += 1
            self._stats.consecutive_failures += 1
            self._stats.last_failure_time = time.time()
            self._stats.last_failure_error = error_msg[:200]

            if self._state == CircuitState.HALF_OPEN:
                _cb_logger.warning(f"[CB] {self.name}: HALF_OPEN → OPEN (probe failed)")
                self._transition_to(CircuitState.OPEN)

            elif (self._state == CircuitState.CLOSED
                  and self._stats.consecutive_failures >= self.failure_threshold):
                _cb_logger.warning(
                    f"[CB] {self.name}: CLOSED → OPEN "
                    f"({self._stats.consecutive_failures} consecutive failures)"
                )
                self._transition_to(CircuitState.OPEN)

    def reset(self):
        """Manually reset the circuit to CLOSED state."""
        with self._lock:
            self._transition_to(CircuitState.CLOSED)
            self._stats.consecutive_failures = 0
            _cb_logger.info(f"[CB] {self.name}: Manual reset to CLOSED")

    def _transition_to(self, new_state: CircuitState):
        """Internal state transition (must hold lock)."""
        self._state = new_state
        self._stats.state_changes += 1
        self._stats.last_state_change = time.time()

    def get_status(self) -> Dict:
        """Return circuit breaker status as dict for health/monitoring."""
        with self._lock:
            return {
                "name": self.name,
                "state": self._state.value,
                "consecutive_failures": self._stats.consecutive_failures,
                "total_calls": self._stats.total_calls,
                "total_failures": self._stats.total_failures,
                "total_successes": self._stats.total_successes,
                "last_failure_error": self._stats.last_failure_error,
                "state_changes": self._stats.state_changes,
            }


# =============================================================================
# CIRCUIT BREAKER REGISTRY — singleton per component
# =============================================================================
class CircuitBreakerRegistry:
    """
    Global registry of circuit breakers.
    One breaker per pipeline layer or detection method.
    """
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._breakers: Dict[str, CircuitBreaker] = {}
        return cls._instance

    def get(self, name: str) -> CircuitBreaker:
        """Get or create a circuit breaker by name."""
        if name not in self._breakers:
            self._breakers[name] = CircuitBreaker(name)
        return self._breakers[name]

    def get_all_status(self) -> Dict[str, Dict]:
        """Return status of all circuit breakers."""
        return {name: cb.get_status() for name, cb in self._breakers.items()}

    def reset_all(self):
        """Reset all circuit breakers to CLOSED."""
        for cb in self._breakers.values():
            cb.reset()

    def get_open_circuits(self) -> list:
        """Return names of all circuits currently in OPEN state."""
        return [
            name for name, cb in self._breakers.items()
            if cb.state == CircuitState.OPEN
        ]


# Module-level singleton
cb_registry = CircuitBreakerRegistry()
