"""
V27 — Real SHAP Explanations
================================
Provides actual Shapley-value explanations using the `shap` library.
Supports TreeExplainer (Isolation Forest), KernelExplainer (general),
and LinearExplainer (Mahalanobis/PCA).

Falls back gracefully to permutation importance if shap is not installed.

Usage:
    from utils.shap_explainer import SHAPExplainer
    explainer = SHAPExplainer()
    result = explainer.explain(model, X, method_name="isolation_forest")
    # result.shap_values  → np.ndarray (N, K)
    # result.global_importance → pd.DataFrame
    # result.summary_plot_data → dict for Plotly charting

Author: AIM AI Vault V27
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime
import logging

logger = logging.getLogger("apurbadas.shap_explainer")

# ─────────────────────────────────────────────────────────────────────────────
# Check for SHAP availability
# ─────────────────────────────────────────────────────────────────────────────
_SHAP_AVAILABLE = False
try:
    import shap
    _SHAP_AVAILABLE = True
except ImportError:
    logger.warning("shap package not installed. Install via: pip install shap")


# ─────────────────────────────────────────────────────────────────────────────
# RESULT DATACLASS
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class SHAPResult:
    """Result from SHAP explanation."""
    method_name: str = ""
    explainer_type: str = ""                 # "tree" | "kernel" | "linear" | "permutation_fallback"
    shap_values: Optional[np.ndarray] = None  # shape (N, K)
    base_value: float = 0.0
    feature_names: List[str] = field(default_factory=list)
    # Global importance: mean(|SHAP|) per feature
    global_importance: Optional[pd.DataFrame] = None
    # Per-entity top contributors
    top_features_per_entity: Optional[pd.DataFrame] = None
    n_samples: int = 0
    n_features: int = 0
    computation_time_ms: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dict (for DB/UI)."""
        return {
            "method_name": self.method_name,
            "explainer_type": self.explainer_type,
            "n_samples": self.n_samples,
            "n_features": self.n_features,
            "computation_time_ms": self.computation_time_ms,
            "base_value": float(self.base_value),
            "global_importance": self.global_importance.to_dict("records") if self.global_importance is not None else [],
            "timestamp": self.timestamp,
            "error": self.error,
        }


# ─────────────────────────────────────────────────────────────────────────────
# TREE-BASED METHODS (fast path)
# ─────────────────────────────────────────────────────────────────────────────
TREE_METHODS = {
    "isolation_forest", "extended_isolation_forest",
    "random_forest", "xgboost", "lightgbm",
}

# Methods that have sklearn-compatible models
SKLEARN_METHODS = {
    "isolation_forest", "lof", "knn", "birch",
    "hdbscan", "dbscan", "optics",
    "gmm", "bgmm",
}


class SHAPExplainer:
    """
    V27: Real SHAP explanations for anomaly detection models.
    
    Selects the appropriate SHAP explainer based on model type:
    - TreeExplainer for tree-based (Isolation Forest, etc.)
    - KernelExplainer for general models (LOF, kNN, etc.)
    - Permutation fallback if shap is not installed
    """

    def __init__(self, max_samples: int = 200, max_features_display: int = 20):
        self.max_samples = max_samples
        self.max_features_display = max_features_display
        self._cache: Dict[str, SHAPResult] = {}

    def explain(
        self,
        model: Any,
        X: np.ndarray,
        feature_names: List[str] = None,
        method_name: str = "unknown",
        scores: np.ndarray = None,
    ) -> SHAPResult:
        """
        Compute SHAP values for a detection model.

        Args:
            model: Fitted sklearn-compatible model (or None for score-based)
            X: Input matrix (N, K)
            feature_names: Column names
            method_name: Name of the detection method
            scores: Anomaly scores (N,) — used for KernelExplainer predict function

        Returns:
            SHAPResult with shap_values, global_importance, etc.
        """
        import time
        t0 = time.time()

        n_samples, n_features = X.shape
        if feature_names is None:
            feature_names = [f"feature_{i}" for i in range(n_features)]

        # Subsample for efficiency
        if n_samples > self.max_samples:
            idx = np.random.choice(n_samples, self.max_samples, replace=False)
            X_sample = X[idx]
            scores_sample = scores[idx] if scores is not None else None
        else:
            X_sample = X
            scores_sample = scores
            idx = np.arange(n_samples)

        result = SHAPResult(
            method_name=method_name,
            feature_names=feature_names,
            n_samples=len(X_sample),
            n_features=n_features,
        )

        try:
            if _SHAP_AVAILABLE:
                result = self._explain_with_shap(model, X_sample, feature_names,
                                                  method_name, scores_sample, result)
            else:
                result = self._explain_permutation_fallback(
                    model, X_sample, feature_names, method_name, scores_sample, result)
        except Exception as e:
            logger.warning(f"SHAP explanation failed for {method_name}: {e}")
            result.error = str(e)
            result.explainer_type = "failed"
            # Try permutation fallback
            try:
                result = self._explain_permutation_fallback(
                    model, X_sample, feature_names, method_name, scores_sample, result)
            except Exception as e2:
                result.error = f"Both SHAP and permutation failed: {e}; {e2}"

        result.computation_time_ms = (time.time() - t0) * 1000

        # Compute global importance from SHAP values
        if result.shap_values is not None:
            mean_abs_shap = np.abs(result.shap_values).mean(axis=0)
            result.global_importance = pd.DataFrame({
                "feature": feature_names,
                "mean_abs_shap": mean_abs_shap,
                "rank": np.argsort(-mean_abs_shap) + 1,
            }).sort_values("mean_abs_shap", ascending=False).reset_index(drop=True)

            # Top features per entity
            top_features = []
            for i in range(min(len(X_sample), 50)):  # top 50 entities
                sv = result.shap_values[i]
                top_idx = np.argsort(-np.abs(sv))[:5]
                for rank, fi in enumerate(top_idx):
                    top_features.append({
                        "sample_idx": int(idx[i]) if i < len(idx) else i,
                        "rank": rank + 1,
                        "feature": feature_names[fi],
                        "shap_value": float(sv[fi]),
                        "feature_value": float(X_sample[i, fi]),
                    })
            result.top_features_per_entity = pd.DataFrame(top_features)

        self._cache[method_name] = result
        logger.info(f"SHAP [{method_name}]: {result.explainer_type}, "
                     f"{result.n_samples} samples, {result.computation_time_ms:.0f}ms")
        return result

    def _explain_with_shap(
        self, model, X_sample, feature_names, method_name, scores_sample, result
    ) -> SHAPResult:
        """Use actual SHAP library."""
        import shap

        # TreeExplainer path
        if method_name in TREE_METHODS and model is not None:
            try:
                explainer = shap.TreeExplainer(model)
                shap_values = explainer.shap_values(X_sample)
                if isinstance(shap_values, list):
                    shap_values = shap_values[0]
                result.shap_values = shap_values
                result.base_value = float(explainer.expected_value) if np.isscalar(explainer.expected_value) else float(explainer.expected_value[0])
                result.explainer_type = "tree"
                return result
            except Exception as e:
                logger.info(f"TreeExplainer failed for {method_name}, falling back to Kernel: {e}")

        # KernelExplainer path — works for any model
        if model is not None and hasattr(model, 'decision_function'):
            try:
                background = shap.sample(X_sample, min(50, len(X_sample)))
                explainer = shap.KernelExplainer(model.decision_function, background)
                shap_values = explainer.shap_values(X_sample[:min(100, len(X_sample))], nsamples=100)
                result.shap_values = shap_values
                result.base_value = float(explainer.expected_value) if np.isscalar(explainer.expected_value) else float(explainer.expected_value[0])
                result.explainer_type = "kernel"
                return result
            except Exception as e:
                logger.info(f"KernelExplainer (decision_function) failed: {e}")

        if model is not None and hasattr(model, 'score_samples'):
            try:
                background = shap.sample(X_sample, min(50, len(X_sample)))
                explainer = shap.KernelExplainer(model.score_samples, background)
                shap_values = explainer.shap_values(X_sample[:min(100, len(X_sample))], nsamples=100)
                result.shap_values = shap_values
                result.base_value = float(explainer.expected_value) if np.isscalar(explainer.expected_value) else float(explainer.expected_value[0])
                result.explainer_type = "kernel_score"
                return result
            except Exception as e:
                logger.info(f"KernelExplainer (score_samples) failed: {e}")

        # Score-based KernelExplainer — use scores as pseudo-predictions
        if scores_sample is not None:
            try:
                from sklearn.neighbors import KNeighborsRegressor
                surrogate = KNeighborsRegressor(n_neighbors=min(5, len(X_sample)))
                surrogate.fit(X_sample, scores_sample)
                background = shap.sample(X_sample, min(50, len(X_sample)))
                explainer = shap.KernelExplainer(surrogate.predict, background)
                shap_values = explainer.shap_values(X_sample[:min(100, len(X_sample))], nsamples=80)
                result.shap_values = shap_values
                result.base_value = float(explainer.expected_value) if np.isscalar(explainer.expected_value) else 0.0
                result.explainer_type = "kernel_surrogate"
                return result
            except Exception as e:
                logger.info(f"Surrogate KernelExplainer failed: {e}")

        # Fallback to permutation
        return self._explain_permutation_fallback(
            model, X_sample, feature_names, method_name, scores_sample, result)

    def _explain_permutation_fallback(
        self, model, X_sample, feature_names, method_name, scores_sample, result
    ) -> SHAPResult:
        """Permutation-based importance as fallback."""
        result.explainer_type = "permutation_fallback"

        if scores_sample is None:
            result.error = "No scores available for permutation importance"
            return result

        n_samples, n_features = X_sample.shape
        base_scores = scores_sample.copy()
        importance = np.zeros(n_features)

        for j in range(n_features):
            X_perm = X_sample.copy()
            X_perm[:, j] = np.random.permutation(X_perm[:, j])

            if model is not None and hasattr(model, 'decision_function'):
                perm_scores = -model.decision_function(X_perm)
            elif model is not None and hasattr(model, 'score_samples'):
                perm_scores = -model.score_samples(X_perm)
            else:
                # Can't compute permutation without model
                importance[j] = 0
                continue

            importance[j] = np.mean(np.abs(perm_scores - base_scores))

        # Convert to pseudo-SHAP values (importance spread per sample)
        shap_values = np.zeros_like(X_sample)
        for j in range(n_features):
            deviation = X_sample[:, j] - X_sample[:, j].mean()
            shap_values[:, j] = importance[j] * np.sign(deviation) * (np.abs(deviation) / (np.abs(deviation).max() + 1e-10))

        result.shap_values = shap_values
        return result

    def get_summary_plot_data(self, method_name: str = None) -> Dict[str, Any]:
        """Get data for a SHAP summary plot (for Plotly rendering in UI)."""
        result = self._cache.get(method_name)
        if result is None or result.shap_values is None:
            return {"error": "No SHAP data available"}

        sv = result.shap_values
        importance = np.abs(sv).mean(axis=0)
        top_idx = np.argsort(-importance)[:self.max_features_display]

        return {
            "method_name": method_name,
            "explainer_type": result.explainer_type,
            "features": [result.feature_names[i] for i in top_idx],
            "importance": importance[top_idx].tolist(),
            "shap_values_top": sv[:, top_idx].tolist(),
            "base_value": result.base_value,
            "n_samples": result.n_samples,
        }

    def get_entity_explanation(
        self, entity_idx: int, method_name: str = None
    ) -> Dict[str, Any]:
        """Get SHAP explanation for a single entity."""
        result = self._cache.get(method_name)
        if result is None or result.shap_values is None:
            return {"error": "No SHAP data available"}

        if entity_idx >= result.shap_values.shape[0]:
            return {"error": f"Entity index {entity_idx} out of range"}

        sv = result.shap_values[entity_idx]
        top_idx = np.argsort(-np.abs(sv))[:10]

        return {
            "entity_idx": entity_idx,
            "method_name": method_name,
            "base_value": result.base_value,
            "contributions": [
                {
                    "feature": result.feature_names[i],
                    "shap_value": float(sv[i]),
                    "direction": "risk_increasing" if sv[i] > 0 else "risk_decreasing",
                }
                for i in top_idx
            ],
        }

    def explain_all_methods(
        self,
        detection_layer,
        X: np.ndarray,
        feature_names: List[str] = None,
    ) -> Dict[str, SHAPResult]:
        """
        Run SHAP explanations for all methods that were executed in L5.

        Args:
            detection_layer: Layer5Detection instance (has .results dict and .models dict)
            X: Detection input matrix
            feature_names: Column names

        Returns:
            Dict mapping method_name → SHAPResult
        """
        all_results = {}

        if not hasattr(detection_layer, 'results'):
            return all_results

        for method_name, det_result in detection_layer.results.items():
            model = None
            if hasattr(detection_layer, 'models') and method_name in detection_layer.models:
                model = detection_layer.models[method_name]

            scores = det_result.scores if hasattr(det_result, 'scores') else None
            try:
                shap_result = self.explain(
                    model=model,
                    X=X,
                    feature_names=feature_names,
                    method_name=method_name,
                    scores=scores,
                )
                all_results[method_name] = shap_result
            except Exception as e:
                logger.warning(f"SHAP failed for {method_name}: {e}")

        return all_results
