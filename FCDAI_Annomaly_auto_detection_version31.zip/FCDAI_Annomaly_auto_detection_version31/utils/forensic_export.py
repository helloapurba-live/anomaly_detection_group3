"""
AIM AI Vault V14 — Forensic Export Module
===============================================
One-click export of anomaly scorecards with full
metadata for audit and compliance purposes.

Author: AIM AI Vault Team
"""

import pandas as pd
import numpy as np
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any
import json
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import PATHS, APP
from utils.logger import logger


class ForensicExporter:
    """
    Export anomaly detection results with full forensic metadata.
    Ensures reproducibility and audit compliance.
    """
    
    def __init__(self, output_dir: Optional[Path] = None):
        self.output_dir = output_dir or PATHS.EXPORTS
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def export_scorecard(
        self,
        df: pd.DataFrame,
        algorithm_config: Optional[Dict[str, Any]] = None,
        include_pii: bool = False,
        format: str = "xlsx"
    ) -> Path:
        """
        Export full anomaly scorecard with metadata.
        
        Args:
            df: Scored DataFrame with anomaly results
            algorithm_config: Configuration used for detection
            include_pii: Whether to include PII fields
            format: Output format (xlsx, csv, parquet)
            
        Returns:
            Path to exported file
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Prepare export DataFrame
        export_df = df.copy()
        
        # Apply PII masking if needed
        if not include_pii:
            pii_columns = ['customer_id', 'account_number', 'ip_address', 'device_id']
            for col in pii_columns:
                if col in export_df.columns:
                    export_df[col] = export_df[col].apply(self._mask_value)
        
        # Add export metadata columns
        export_df['export_timestamp'] = timestamp
        export_df['export_version'] = APP.VERSION
        
        # Generate filename
        n_anomalies = (df['anomaly_score'] > 0.5).sum() if 'anomaly_score' in df.columns else 0
        filename = f"anomaly_scorecard_{timestamp}_{n_anomalies}alerts"
        
        # Export based on format
        if format == "xlsx":
            filepath = self.output_dir / f"{filename}.xlsx"
            self._export_excel(export_df, filepath, algorithm_config)
        elif format == "csv":
            filepath = self.output_dir / f"{filename}.csv"
            export_df.to_csv(filepath, index=False)
        else:  # parquet
            filepath = self.output_dir / f"{filename}.parquet"
            export_df.to_parquet(filepath, index=False)
        
        # Create metadata sidecar
        self._create_metadata_file(filepath, df, algorithm_config)
        
        # Log export action
        logger.log_action("Forensic Export", metadata={
            "filepath": str(filepath),
            "records": len(df),
            "anomalies": int(n_anomalies),
            "format": format,
            "pii_included": include_pii
        })
        
        return filepath
    
    def _export_excel(
        self,
        df: pd.DataFrame,
        filepath: Path,
        config: Optional[Dict]
    ):
        """Export to Excel with multiple sheets."""
        try:
            import openpyxl
            
            with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
                # Main data sheet
                df.to_excel(writer, sheet_name='Scorecard', index=False)
                
                # Summary sheet
                summary = self._generate_summary(df)
                summary.to_excel(writer, sheet_name='Summary', index=False)
                
                # High-risk alerts sheet
                if 'anomaly_score' in df.columns:
                    high_risk = df[df['anomaly_score'] > 0.8]
                    high_risk.to_excel(writer, sheet_name='High Risk Alerts', index=False)
                
                # Algorithm scores breakdown
                score_cols = [c for c in df.columns if c.startswith('score_')]
                if score_cols:
                    algo_scores = df[['anomaly_score'] + score_cols].describe()
                    algo_scores.to_excel(writer, sheet_name='Algorithm Stats')
                
        except ImportError:
            # Fallback to CSV if openpyxl not available
            df.to_csv(filepath.with_suffix('.csv'), index=False)
    
    def _generate_summary(self, df: pd.DataFrame) -> pd.DataFrame:
        """Generate summary statistics."""
        summary_data = []
        
        summary_data.append({'Metric': 'Total Records', 'Value': len(df)})
        
        if 'anomaly_score' in df.columns:
            summary_data.append({
                'Metric': 'Anomalies Detected (score > 0.5)',
                'Value': (df['anomaly_score'] > 0.5).sum()
            })
            summary_data.append({
                'Metric': 'High Risk (score > 0.8)',
                'Value': (df['anomaly_score'] > 0.8).sum()
            })
            summary_data.append({
                'Metric': 'Mean Anomaly Score',
                'Value': f"{df['anomaly_score'].mean():.4f}"
            })
            summary_data.append({
                'Metric': 'Max Anomaly Score',
                'Value': f"{df['anomaly_score'].max():.4f}"
            })
        
        if 'risk_level' in df.columns:
            for level in ['High', 'Medium-High', 'Medium', 'Low-Medium', 'Low']:
                count = (df['risk_level'] == level).sum()
                summary_data.append({'Metric': f'Risk Level: {level}', 'Value': count})
        
        # Score columns
        score_cols = [c for c in df.columns if c.startswith('score_')]
        summary_data.append({'Metric': 'Algorithms Used', 'Value': len(score_cols)})
        
        return pd.DataFrame(summary_data)
    
    def _create_metadata_file(
        self,
        filepath: Path,
        df: pd.DataFrame,
        config: Optional[Dict]
    ):
        """Create JSON metadata sidecar file."""
        metadata = {
            "export_info": {
                "timestamp": datetime.now().isoformat(),
                "filename": filepath.name,
                "format": filepath.suffix[1:],
                "version": APP.VERSION
            },
            "data_info": {
                "total_records": len(df),
                "columns": list(df.columns),
                "anomalies_detected": int((df['anomaly_score'] > 0.5).sum()) if 'anomaly_score' in df.columns else 0
            },
            "algorithm_config": config or {},
            "reproducibility": {
                "score_columns": [c for c in df.columns if c.startswith('score_')],
                "feature_columns": [c for c in df.columns if not c.startswith('score_') and c not in ['anomaly_score', 'anomaly_label', 'risk_level']]
            }
        }
        
        meta_path = filepath.with_suffix('.meta.json')
        with open(meta_path, 'w') as f:
            json.dump(metadata, f, indent=2, default=str)
    
    def _mask_value(self, value: Any) -> str:
        """Mask PII value."""
        if pd.isna(value):
            return value
        
        val_str = str(value)
        if len(val_str) <= 4:
            return '*' * len(val_str)
        
        return val_str[:2] + '*' * (len(val_str) - 4) + val_str[-2:]


# Convenience function
def export_scorecard(
    df: pd.DataFrame,
    format: str = "xlsx",
    include_pii: bool = False
) -> Path:
    """Quick export of anomaly scorecard."""
    exporter = ForensicExporter()
    return exporter.export_scorecard(df, format=format, include_pii=include_pii)
