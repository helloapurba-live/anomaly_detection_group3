"""
Module 3.5: Conditional Transformation Engine (V28)
====================================================
Sits between Module 3 (Preprocessing/Encoding) and Module 4 (Scaling).
Applies conditional log1p / PowerTransform / sqrt per-column based on
skewness analysis and the algorithm routing matrix.

Transformation Rules
────────────────────
  ✅ LOG if skew > threshold : LOF, k-thNN, HDBSCAN, BIRCH, VAE
  ✅ PowerTransform          : Mahalanobis, GMM (Yeo-Johnson)
  ⚠️ Optional                : HBOS, Matrix Profile
  ❌ NEVER                   : Benford, IQR, Z-Score, ECOD, COPOD, ExtIF, Graph, CPD

Input:
  - df_encoded  (100% numeric DataFrame from Module 3)
  - skew_threshold (float, default 2.0)

Output:
  - TransformResult with X_transformed + X_original + per-column log

Author: AIM AI Vault V28 — Transform → Scale → Reduce Pipeline
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging

logger = logging.getLogger("apurbadas.transformation_engine")


# ─────────────────────────────────────────────────────────────────────────────
# ALGORITHM → TRANSFORM ROUTING (from specification)
# ─────────────────────────────────────────────────────────────────────────────
ALGO_TRANSFORM_MAP = {
    # LOG if skew > threshold
    "LOG": [
        "lof", "knn", "k-thnn", "kthnn", "hdbscan", "birch", "vae",
    ],
    # PowerTransformer (Yeo-Johnson)
    "POWER": [
        "mahalanobis", "gmm",
    ],
    # Optional (transform helps but not required)
    "OPTIONAL": [
        "hbos", "matrix_profile",
    ],
    # NEVER transform — destroys signal
    "NEVER": [
        "benford", "iqr", "modified_zscore", "z_score", "zscore",
        "ecod", "copod", "extended_if", "extif",
        "pagerank", "leiden", "oddball", "betweenness",
        "change_point", "cpd",
    ],
}


@dataclass
class TransformResult:
    """Result from the Transformation Engine."""
    df_transformed: Optional[pd.DataFrame] = None   # LOG/Power transformed
    df_original: Optional[pd.DataFrame] = None       # Untouched copy
    columns_log_transformed: List[str] = field(default_factory=list)
    columns_power_transformed: List[str] = field(default_factory=list)
    columns_skipped: List[str] = field(default_factory=list)
    skew_before: Dict[str, float] = field(default_factory=dict)
    skew_after: Dict[str, float] = field(default_factory=dict)
    step_log: List[Dict[str, Any]] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


class TransformationEngine:
    """
    V28: Conditional per-column transformation engine.

    Applies log1p or Yeo-Johnson PowerTransform on skewed columns,
    respecting the algorithm routing matrix (some algos NEVER transform).
    """

    def __init__(self, skew_threshold: float = 2.0, random_state: int = 42):
        self.skew_threshold = skew_threshold
        self.random_state = random_state

    def transform(
        self,
        df_encoded: pd.DataFrame,
        mode: str = "auto",
    ) -> TransformResult:
        """
        Apply conditional per-column transformation.

        Args:
            df_encoded:  100% numeric DataFrame from Module 3.
            mode:        "auto"  — LOG on skew > threshold (default)
                         "log"   — Force LOG on all skewed columns
                         "power" — Force Yeo-Johnson on all columns
                         "none"  — No transformation (passthrough)

        Returns:
            TransformResult with df_transformed (modified) and df_original (copy).
        """
        result = TransformResult()
        result.df_original = df_encoded.copy()

        if df_encoded is None or df_encoded.empty:
            logger.warning("TransformationEngine: Empty input, passthrough")
            result.df_transformed = df_encoded.copy()
            result.step_log.append({"step": "GUARD", "warning": "Empty input"})
            return result

        if mode == "none":
            result.df_transformed = df_encoded.copy()
            result.step_log.append({"step": "PASSTHROUGH", "mode": "none"})
            logger.info("[TRANSFORM] Mode=none — passthrough")
            return result

        df_work = df_encoded.copy()
        n_rows, n_cols = df_work.shape

        # ── Compute skewness for all numeric columns ──
        from scipy import stats as sp_stats

        skew_dict = {}
        for col in df_work.columns:
            try:
                col_data = df_work[col].dropna()
                if len(col_data) > 2 and col_data.std() > 0:
                    skew_dict[col] = float(sp_stats.skew(col_data, nan_policy="omit"))
                else:
                    skew_dict[col] = 0.0
            except Exception:
                skew_dict[col] = 0.0

        result.skew_before = skew_dict.copy()

        # ── Identify binary columns (0/1 only) — NEVER transform ──
        binary_cols = set()
        for col in df_work.columns:
            uniq = df_work[col].dropna().unique()
            if len(uniq) <= 2 and set(uniq).issubset({0, 1, 0.0, 1.0}):
                binary_cols.add(col)

        log_cols = []
        power_cols = []
        skipped_cols = []

        if mode in ("auto", "log"):
            # ── LOG Transform: log1p on columns with skew > threshold ──
            for col in df_work.columns:
                if col in binary_cols:
                    skipped_cols.append(col)
                    continue

                skew_val = skew_dict.get(col, 0.0)
                if abs(skew_val) > self.skew_threshold:
                    # Check if column has negative values — log1p needs non-negative
                    col_min = df_work[col].min()
                    if col_min < 0:
                        # Shift to make non-negative before log1p
                        shift = abs(col_min) + 1
                        df_work[col] = np.log1p(df_work[col] + shift)
                    else:
                        df_work[col] = np.log1p(df_work[col])
                    log_cols.append(col)
                else:
                    skipped_cols.append(col)

        elif mode == "power":
            # ── Yeo-Johnson PowerTransformer on all non-binary columns ──
            try:
                from sklearn.preprocessing import PowerTransformer

                non_binary_cols = [c for c in df_work.columns if c not in binary_cols]
                if non_binary_cols:
                    pt = PowerTransformer(method="yeo-johnson", standardize=False)
                    df_work[non_binary_cols] = pt.fit_transform(df_work[non_binary_cols])
                    power_cols = non_binary_cols
                    skipped_cols = list(binary_cols)
            except Exception as e:
                logger.warning(f"PowerTransformer failed: {e}, falling back to log")
                # Fall back to log mode
                for col in df_work.columns:
                    if col not in binary_cols:
                        skew_val = skew_dict.get(col, 0.0)
                        if abs(skew_val) > self.skew_threshold:
                            col_min = df_work[col].min()
                            if col_min < 0:
                                shift = abs(col_min) + 1
                                df_work[col] = np.log1p(df_work[col] + shift)
                            else:
                                df_work[col] = np.log1p(df_work[col])
                            log_cols.append(col)
                        else:
                            skipped_cols.append(col)

        # ── Compute post-transform skewness ──
        skew_after = {}
        for col in df_work.columns:
            try:
                col_data = df_work[col].dropna()
                if len(col_data) > 2 and col_data.std() > 0:
                    skew_after[col] = float(sp_stats.skew(col_data, nan_policy="omit"))
                else:
                    skew_after[col] = 0.0
            except Exception:
                skew_after[col] = 0.0

        result.df_transformed = df_work
        result.columns_log_transformed = log_cols
        result.columns_power_transformed = power_cols
        result.columns_skipped = skipped_cols
        result.skew_after = skew_after
        result.step_log.append({
            "step": "TRANSFORM",
            "mode": mode,
            "skew_threshold": self.skew_threshold,
            "total_columns": n_cols,
            "log_transformed": len(log_cols),
            "power_transformed": len(power_cols),
            "binary_skipped": len(binary_cols),
            "below_threshold_skipped": len(skipped_cols) - len(binary_cols),
        })

        logger.info(
            f"[TRANSFORM] mode={mode}, threshold={self.skew_threshold}: "
            f"{len(log_cols)} log, {len(power_cols)} power, "
            f"{len(skipped_cols)} skipped (of {n_cols} cols)"
        )

        return result
