"""
Module 3: Preprocessing Engine — Missing → Transform → Encode → EncodedMaster
===============================================================================
Takes the DQ-Processed DataFrame and produces ENCODED_MASTER:
a fully numeric (N × K) matrix, zero NaNs, ready for scaling.

Sub-steps:
   A. Missing Value Treatment (strategy: ZERO, MEDIAN, MODE, or DROP)
   B. Datetime Decomposition  (hour, day_of_week, month, is_weekend)
   C. Feature Encoding:
       - Continuous  → float64 as-is
       - Discrete    → int32 as-is
       - Ordinal     → LabelEncoder (preserves order)
       - Binary      → 0 / 1  int8
       - Categorical → OneHotEncoder (drop_first=True)
   D. Final Audit — verify 100% numeric, zero NaN

Output : EncodedMaster DataFrame  (N × K, 100 % float64)

Author: AIM AI Vault V23 — 5-Module Pipeline
"""

import pandas as pd
import numpy as np
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
import logging

logger = logging.getLogger("apurbadas.preprocessing_engine")


# ─────────────────────────────────────────────────────────────────────────────
# RESULT DATACLASS
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class PreprocessingResult:
    """Complete result from Module 3: Preprocessing Engine."""
    encoded_master: Optional[pd.DataFrame] = None         # N × K, 100% float
    base_key_series: Optional[pd.Series] = None           # preserved separately
    datetime_features: Optional[pd.DataFrame] = None      # decomposed dt cols

    # Encoding metadata
    encoding_map: Dict[str, str] = field(default_factory=dict)  # col → method
    label_encoders: Dict[str, Dict] = field(default_factory=dict)  # col → {val: int}
    onehot_columns_created: List[str] = field(default_factory=list)
    columns_before_encode: List[str] = field(default_factory=list)
    columns_after_encode: List[str] = field(default_factory=list)

    # Missing value treatment summary
    missing_treatment: Dict[str, str] = field(default_factory=dict)  # col → action

    # Shape
    shape_before: Tuple[int, int] = (0, 0)
    shape_after: Tuple[int, int] = (0, 0)
    step_log: List[Dict[str, Any]] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


# ─────────────────────────────────────────────────────────────────────────────
# MAIN ENGINE
# ─────────────────────────────────────────────────────────────────────────────
class PreprocessingEngine:
    """
    Converts a cleaned DataFrame into a fully numeric EncodedMaster.
    Uses the data_type_map produced by Module 2 (DQ Processing).
    """

    def __init__(self,
                 base_key: str = "cust_id",
                 missing_strategy: str = "ZERO",
                 ordinal_orders: Optional[Dict[str, List[str]]] = None,
                 datetime_cols: Optional[pd.DataFrame] = None):
        """
        Args:
            base_key:        primary key column (preserved separately)
            missing_strategy: ZERO, MEDIAN, MODE, or DROP
            ordinal_orders:  {col: [low, med, high]} for ordinal encoding
            datetime_cols:   extracted datetime columns from Module 2
        """
        self.base_key = base_key
        self.missing_strategy = missing_strategy.upper()
        self.ordinal_orders = ordinal_orders or {}
        self.datetime_cols = datetime_cols

    def preprocess(self, df: pd.DataFrame,
                   data_type_map: Dict[str, str]) -> PreprocessingResult:
        """Execute full preprocessing pipeline."""
        result = PreprocessingResult(shape_before=(len(df), len(df.columns)))
        work = df.copy()

        try:
            # Separate BASE_KEY
            if self.base_key in work.columns:
                result.base_key_series = work[self.base_key].copy()
                work = work.drop(columns=[self.base_key])

            result.columns_before_encode = list(work.columns)

            # Step A: Missing Value Treatment
            work = self._missing_values(work, data_type_map, result)

            # Step B: Datetime Decomposition
            work = self._datetime_decompose(work, data_type_map, result)

            # Step C: Feature Encoding
            work = self._encode_features(work, data_type_map, result)

            # Step D: Final Audit
            work = self._final_audit(work, result)

            result.encoded_master = work
            result.columns_after_encode = list(work.columns)
            result.shape_after = (len(work), len(work.columns))

        except Exception as e:
            logger.error(f"Preprocessing failed: {e}")
            result.step_log.append({"step": "ERROR", "message": str(e)})
            # Return whatever we have
            result.encoded_master = work

        return result

    # ─────────────────────────────────────────────────────────────────────
    # STEP A: MISSING VALUE TREATMENT
    # ─────────────────────────────────────────────────────────────────────
    def _missing_values(self, df: pd.DataFrame, type_map: Dict[str, str],
                        result: PreprocessingResult) -> pd.DataFrame:
        """Fill or drop missing values per strategy."""
        treatment = {}
        total_filled = 0

        for col in df.columns:
            missing = int(df[col].isnull().sum())
            if missing == 0:
                treatment[col] = "NONE"
                continue

            col_type = type_map.get(col, "UNKNOWN")

            if self.missing_strategy == "ZERO":
                if pd.api.types.is_numeric_dtype(df[col]):
                    df[col] = df[col].fillna(0)
                else:
                    df[col] = df[col].fillna("MISSING")
                treatment[col] = f"ZERO_FILL ({missing})"

            elif self.missing_strategy == "MEDIAN":
                if pd.api.types.is_numeric_dtype(df[col]):
                    df[col] = df[col].fillna(df[col].median())
                    treatment[col] = f"MEDIAN ({missing})"
                else:
                    mode_val = df[col].mode()
                    df[col] = df[col].fillna(mode_val.iloc[0] if len(mode_val) > 0 else "MISSING")
                    treatment[col] = f"MODE ({missing})"

            elif self.missing_strategy == "MODE":
                mode_val = df[col].mode()
                fill = mode_val.iloc[0] if len(mode_val) > 0 else (0 if pd.api.types.is_numeric_dtype(df[col]) else "MISSING")
                df[col] = df[col].fillna(fill)
                treatment[col] = f"MODE ({missing})"

            elif self.missing_strategy == "DROP":
                # Only drop if missing < 5% of rows
                if missing / len(df) < 0.05:
                    df = df.dropna(subset=[col])
                    treatment[col] = f"DROP_ROWS ({missing})"
                else:
                    df[col] = df[col].fillna(0 if pd.api.types.is_numeric_dtype(df[col]) else "MISSING")
                    treatment[col] = f"ZERO_FALLBACK ({missing})"
            else:
                df[col] = df[col].fillna(0 if pd.api.types.is_numeric_dtype(df[col]) else "MISSING")
                treatment[col] = f"DEFAULT_ZERO ({missing})"

            total_filled += missing

        result.missing_treatment = treatment
        result.step_log.append({
            "step": "A", "name": "Missing Value Treatment",
            "strategy": self.missing_strategy,
            "total_missing_treated": total_filled,
            "columns_treated": sum(1 for v in treatment.values() if v != "NONE"),
        })
        return df

    # ─────────────────────────────────────────────────────────────────────
    # STEP B: DATETIME DECOMPOSITION
    # ─────────────────────────────────────────────────────────────────────
    def _datetime_decompose(self, df: pd.DataFrame, type_map: Dict[str, str],
                            result: PreprocessingResult) -> pd.DataFrame:
        """Decompose datetime columns into: hour, day_of_week, month, is_weekend."""
        dt_features = []

        # Process datetime columns extracted by Module 2
        if self.datetime_cols is not None and len(self.datetime_cols.columns) > 0:
            for col in self.datetime_cols.columns:
                try:
                    dt_series = pd.to_datetime(self.datetime_cols[col], errors="coerce")
                    prefix = col.replace(" ", "_").lower()

                    feat_df = pd.DataFrame(index=self.datetime_cols.index)
                    feat_df[f"{prefix}_hour"] = dt_series.dt.hour.fillna(0).astype(int)
                    feat_df[f"{prefix}_dayofweek"] = dt_series.dt.dayofweek.fillna(0).astype(int)
                    feat_df[f"{prefix}_month"] = dt_series.dt.month.fillna(0).astype(int)
                    feat_df[f"{prefix}_is_weekend"] = (dt_series.dt.dayofweek >= 5).astype(int)
                    feat_df[f"{prefix}_quarter"] = dt_series.dt.quarter.fillna(0).astype(int)

                    # Days since epoch for time-distance features
                    epoch = pd.Timestamp("2000-01-01")
                    feat_df[f"{prefix}_days_since_epoch"] = (
                        (dt_series - epoch).dt.days.fillna(0).astype(int)
                    )

                    dt_features.append(feat_df)
                except Exception as e:
                    logger.warning(f"Datetime decompose failed for {col}: {e}")

        if dt_features:
            dt_combined = pd.concat(dt_features, axis=1)
            # Align indices
            dt_combined = dt_combined.reindex(df.index).fillna(0)
            df = pd.concat([df, dt_combined], axis=1)
            result.datetime_features = dt_combined

        result.step_log.append({
            "step": "B", "name": "Datetime Decomposition",
            "new_features": len(dt_features),
            "derived_cols": sum(d.shape[1] for d in dt_features) if dt_features else 0,
        })
        return df

    # ─────────────────────────────────────────────────────────────────────
    # STEP C: FEATURE ENCODING
    # ─────────────────────────────────────────────────────────────────────
    def _encode_features(self, df: pd.DataFrame, type_map: Dict[str, str],
                         result: PreprocessingResult) -> pd.DataFrame:
        """
        Continuous  → float64
        Discrete    → int32
        Ordinal     → LabelEncoder (order-preserving)
        Binary      → 0 / 1 int8
        Categorical → OneHot (drop_first=True)
        """
        onehot_cols = []
        label_maps = {}
        encoding_log = {}

        for col in list(df.columns):
            col_type = type_map.get(col, "UNKNOWN")

            # ── CONTINUOUS ──
            if col_type == "CONTINUOUS":
                df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(np.float64)
                encoding_log[col] = "CONTINUOUS → float64"

            # ── DISCRETE ──
            elif col_type == "DISCRETE":
                df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(np.int32)
                encoding_log[col] = "DISCRETE → int32"

            # ── BINARY ──
            elif col_type == "BINARY":
                # V24 FIX: key=str prevents TypeError on mixed-type columns
                unique_vals = sorted(df[col].dropna().unique().tolist(), key=str)
                if len(unique_vals) == 2:
                    val_map = {unique_vals[0]: 0, unique_vals[1]: 1}
                    df[col] = df[col].map(val_map).fillna(0).astype(np.int8)
                    label_maps[col] = {str(k): int(v) for k, v in val_map.items()}
                else:
                    df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(np.int8)
                encoding_log[col] = "BINARY → 0/1 int8"

            # ── ORDINAL ──
            elif col_type == "ORDINAL" or col in self.ordinal_orders:
                if col in self.ordinal_orders:
                    order = self.ordinal_orders[col]
                    val_map = {v: i for i, v in enumerate(order)}
                else:
                    # Auto-order: alphabetical
                    unique_vals = sorted(df[col].dropna().unique().tolist())
                    val_map = {v: i for i, v in enumerate(unique_vals)}

                df[col] = df[col].map(val_map).fillna(0).astype(np.int32)
                label_maps[col] = {str(k): int(v) for k, v in val_map.items()}
                encoding_log[col] = f"ORDINAL → label ({len(val_map)} levels)"

            # ── CATEGORICAL ──
            elif col_type == "CATEGORICAL":
                dummies = pd.get_dummies(df[col], prefix=col, drop_first=True, dtype=np.int8)
                onehot_cols.extend(dummies.columns.tolist())
                df = df.drop(columns=[col])
                df = pd.concat([df, dummies], axis=1)
                encoding_log[col] = f"CATEGORICAL → OneHot ({len(dummies.columns)} cols)"

            # ── ALREADY NUMERIC ──
            elif pd.api.types.is_numeric_dtype(df[col]):
                df[col] = df[col].fillna(0).astype(np.float64)
                encoding_log[col] = "NUMERIC → float64 (passthrough)"

            # ── HIGH CARDINALITY TEXT ──
            elif col_type == "HIGH_CARDINAL_TEXT":
                # Frequency encode: value → count/total
                freq = df[col].value_counts(normalize=True)
                df[col] = df[col].map(freq).fillna(0).astype(np.float64)
                encoding_log[col] = f"HIGH_CARDINAL → frequency ({len(freq)} unique)"

            # ── FALLBACK ──
            else:
                try:
                    df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(np.float64)
                    encoding_log[col] = "FALLBACK → numeric coerce"
                except Exception:
                    # Last resort: drop
                    df = df.drop(columns=[col])
                    encoding_log[col] = "DROP (unconvertible)"

        result.encoding_map = encoding_log
        result.label_encoders = label_maps
        result.onehot_columns_created = onehot_cols

        result.step_log.append({
            "step": "C", "name": "Feature Encoding",
            "total_encoded": len(encoding_log),
            "onehot_new_cols": len(onehot_cols),
            "label_encoded_cols": len(label_maps),
        })
        return df

    # ─────────────────────────────────────────────────────────────────────
    # STEP D: FINAL AUDIT
    # ─────────────────────────────────────────────────────────────────────
    def _final_audit(self, df: pd.DataFrame, result: PreprocessingResult) -> pd.DataFrame:
        """Verify 100% numeric, zero NaN. Force-convert any remaining."""
        # Check for any remaining NaN
        nan_count = int(df.isnull().sum().sum())
        if nan_count > 0:
            logger.warning(f"Final audit found {nan_count} NaN — filling with 0")
            df = df.fillna(0)

        # Check for any non-numeric columns
        non_numeric = df.select_dtypes(exclude=[np.number]).columns.tolist()
        if non_numeric:
            logger.warning(f"Final audit found non-numeric cols: {non_numeric} — force encoding")
            for col in non_numeric:
                try:
                    df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
                except Exception:
                    df = df.drop(columns=[col])

        # Cast all to float64 for consistency
        df = df.astype(np.float64)

        result.step_log.append({
            "step": "D", "name": "Final Audit",
            "nan_remaining": 0,
            "non_numeric_remaining": 0,
            "is_100pct_numeric": True,
            "final_shape": (len(df), len(df.columns)),
        })
        logger.info(f"EncodedMaster ready: {df.shape[0]} rows × {df.shape[1]} features, 100% numeric")
        return df
