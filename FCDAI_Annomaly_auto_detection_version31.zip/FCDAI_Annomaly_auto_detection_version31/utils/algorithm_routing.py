"""
Module 6: Master Algorithm Routing Matrix
==========================================
Maps every one of the 20 unsupervised anomaly detection algorithms to its
MANDATORY transform → scale → reduction path combination.

The routing matrix is the single source of truth that connects:
  - Module 3 (Encoding — which transform?)
  - Module 4 (Scaling — which scaler?)
  - Module 5 (Reduction — which path?)
to the final algorithm execution.

20 Algorithms in 8 Categories
──────────────────────────────
  STATISTICAL    : IQR, Modified Z-Score, Mahalanobis, Benford's Law
  TREE           : Extended Isolation Forest
  DENSITY        : HBOS, LOF, ECOD, COPOD
  DISTANCE       : k-th Nearest Neighbour
  CLUSTERING     : GMM, HDBSCAN, BIRCH
  GRAPH          : PageRank, Leiden Community, OddBall, Betweenness
  TIME-SERIES    : Change Point Detection, Matrix Profile
  DEEP LEARNING  : Variational Autoencoder (VAE)

Special Routing Rules
─────────────────────
  • Benford's Law:      NEVER scale or reduce — works on raw digit distribution
  • Graph algorithms:   Use GRAPH_DATA (adjacency) not tabular PreMaster
  • Time-Series algos:  Use TEMPORAL_DATA not tabular PreMaster
  • Extended IF:        Works on Original (unscaled) for tree splits
  • VAE:                Needs MinMaxScaler [0,1] input

Author: AIM AI Vault V23 — 5-Module Pipeline
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
import logging

logger = logging.getLogger("apurbadas.algorithm_routing")


# ─────────────────────────────────────────────────────────────────────────────
# ALGORITHM CATEGORIES
# ─────────────────────────────────────────────────────────────────────────────
CAT_STATISTICAL   = "Statistical"
CAT_TREE          = "Tree"
CAT_DENSITY       = "Density"
CAT_DISTANCE      = "Distance"
CAT_CLUSTERING    = "Clustering"
CAT_GRAPH         = "Graph"
CAT_TIMESERIES    = "Time-Series"
CAT_DEEPLEARNING  = "Deep Learning"


# ─────────────────────────────────────────────────────────────────────────────
# DATA SOURCE TYPES
# ─────────────────────────────────────────────────────────────────────────────
SRC_TABULAR   = "TABULAR"       # Normal PreMaster from Modules 1-5
SRC_GRAPH     = "GRAPH_DATA"    # Adjacency / edge list from data_sources
SRC_TEMPORAL  = "TEMPORAL_DATA" # Time-series from temporal uploads


# ─────────────────────────────────────────────────────────────────────────────
# ALGORITHM ROUTE DATACLASS
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class AlgorithmRoute:
    """Routing specification for one algorithm."""
    name: str
    short_name: str
    category: str
    data_source: str = SRC_TABULAR

    # Module 3: Transform / Encode requirements
    transform: str = "STANDARD"        # STANDARD | NONE | SPECIAL
    needs_encoding: bool = True        # does it need Module 3 output?

    # Module 4: Scaler
    scaler: str = "StandardScaler"     # one of the 6 scaler names
    allow_original: bool = False       # can it work on unscaled?

    # Module 5: Reduction path (list of compatible paths, first = default)
    reduction_paths: List[int] = field(default_factory=lambda: [1, 2, 7])
    default_reduction: int = 1
    reduction_dims: Optional[int] = None  # override target dims

    # Special flags
    needs_graph: bool = False
    needs_temporal: bool = False
    never_scale: bool = False
    never_reduce: bool = False

    # PyOD / implementation hints
    pyod_class: Optional[str] = None
    notes: str = ""


# ─────────────────────────────────────────────────────────────────────────────
# MASTER ROUTING TABLE — 20 ALGORITHMS
# ─────────────────────────────────────────────────────────────────────────────

ALGORITHM_ROUTES: Dict[str, AlgorithmRoute] = {}


def _register(route: AlgorithmRoute):
    ALGORITHM_ROUTES[route.short_name] = route


# ── STATISTICAL ──────────────────────────────────────────────────────────────

_register(AlgorithmRoute(
    name="IQR (Interquartile Range)",
    short_name="IQR",
    category=CAT_STATISTICAL,
    scaler="RobustScaler",
    reduction_paths=[1, 2, 7],
    default_reduction=1,
    pyod_class=None,
    notes="Per-column IQR, uses quartile-based scaler naturally",
))

_register(AlgorithmRoute(
    name="Modified Z-Score",
    short_name="MOD_ZSCORE",
    category=CAT_STATISTICAL,
    scaler="RobustScaler",
    reduction_paths=[1, 2, 7],
    default_reduction=1,
    pyod_class=None,
    notes="Median-based Z-score with MAD; robust scaler aligns",
))

_register(AlgorithmRoute(
    name="Mahalanobis Distance",
    short_name="MAHALANOBIS",
    category=CAT_STATISTICAL,
    scaler="PowerTransformer",
    reduction_paths=[2, 3, 7, 8],
    default_reduction=2,
    reduction_dims=50,
    pyod_class=None,
    notes="Needs Gaussian-like input; PowerTransformer (Yeo-Johnson) Gaussianizes; reduce to avoid singular covariance",
))

_register(AlgorithmRoute(
    name="Benford's Law",
    short_name="BENFORD",
    category=CAT_STATISTICAL,
    scaler="Original",
    allow_original=True,
    never_scale=True,
    never_reduce=True,
    reduction_paths=[1],
    default_reduction=1,
    pyod_class=None,
    notes="NEVER scale/reduce — needs raw digit distribution; operates on amount columns only",
))

# ── TREE ─────────────────────────────────────────────────────────────────────

_register(AlgorithmRoute(
    name="Extended Isolation Forest",
    short_name="EXT_IF",
    category=CAT_TREE,
    scaler="Original",
    allow_original=True,
    reduction_paths=[1, 2, 3, 4, 5, 7, 8],
    default_reduction=1,
    pyod_class="IForest",
    notes="Tree splits are scale-invariant; original data preferred; reduction optional for speed",
))

# ── DENSITY ──────────────────────────────────────────────────────────────────

_register(AlgorithmRoute(
    name="HBOS (Histogram-Based Outlier Score)",
    short_name="HBOS",
    category=CAT_DENSITY,
    scaler="StandardScaler",
    reduction_paths=[1, 2, 7],
    default_reduction=1,
    pyod_class="HBOS",
    notes="Per-feature histograms; standard scaling normalizes bin widths",
))

_register(AlgorithmRoute(
    name="LOF (Local Outlier Factor)",
    short_name="LOF",
    category=CAT_DENSITY,
    scaler="StandardScaler",
    reduction_paths=[1, 2, 3, 4, 7, 8],
    default_reduction=2,
    reduction_dims=50,
    pyod_class="LOF",
    notes="Distance-based density; needs standard scaling; reduce for curse of dimensionality",
))

_register(AlgorithmRoute(
    name="ECOD (Empirical CDF Outlier Detection)",
    short_name="ECOD",
    category=CAT_DENSITY,
    scaler="Original",
    allow_original=True,
    reduction_paths=[1, 2, 7],
    default_reduction=1,
    pyod_class="ECOD",
    notes="Non-parametric CDF-based; scale-invariant; no reduction needed",
))

_register(AlgorithmRoute(
    name="COPOD (Copula-Based Outlier Detection)",
    short_name="COPOD",
    category=CAT_DENSITY,
    scaler="Original",
    allow_original=True,
    reduction_paths=[1, 2, 7],
    default_reduction=1,
    pyod_class="COPOD",
    notes="Copula-based; empirical CDF approach; scale-invariant",
))

# ── DISTANCE ─────────────────────────────────────────────────────────────────

_register(AlgorithmRoute(
    name="k-th Nearest Neighbour Distance",
    short_name="KNN",
    category=CAT_DISTANCE,
    scaler="StandardScaler",
    reduction_paths=[1, 2, 4, 5, 7, 8],
    default_reduction=2,
    reduction_dims=50,
    pyod_class="KNN",
    notes="Distance-based; requires standard scaling; reduce for dimensionality curse",
))

# ── CLUSTERING ───────────────────────────────────────────────────────────────

_register(AlgorithmRoute(
    name="GMM (Gaussian Mixture Model)",
    short_name="GMM",
    category=CAT_CLUSTERING,
    scaler="PowerTransformer",
    reduction_paths=[2, 3, 5, 7, 8],
    default_reduction=2,
    reduction_dims=30,
    pyod_class="GMM",
    notes="Assumes Gaussian components; PowerTransform Gaussianizes; reduce to avoid EM singularity",
))

_register(AlgorithmRoute(
    name="HDBSCAN",
    short_name="HDBSCAN",
    category=CAT_CLUSTERING,
    scaler="StandardScaler",
    reduction_paths=[2, 4, 5, 7, 8],
    default_reduction=4,
    reduction_dims=30,
    pyod_class=None,
    notes="Density-based clustering; standard scaling for distance; UMAP pre-reduction recommended",
))

_register(AlgorithmRoute(
    name="BIRCH (Balanced Iterative Reducing and Clustering)",
    short_name="BIRCH",
    category=CAT_CLUSTERING,
    scaler="StandardScaler",
    reduction_paths=[1, 2, 7],
    default_reduction=2,
    reduction_dims=50,
    pyod_class=None,
    notes="CF-tree based clustering; standard scaling for distance metrics",
))

# ── GRAPH ────────────────────────────────────────────────────────────────────

_register(AlgorithmRoute(
    name="PageRank Anomaly",
    short_name="PAGERANK",
    category=CAT_GRAPH,
    data_source=SRC_GRAPH,
    needs_graph=True,
    scaler="Original",
    never_scale=True,
    never_reduce=True,
    reduction_paths=[1],
    default_reduction=1,
    notes="Graph algorithm — uses GRAPH_DATA (adjacency matrix), not tabular PreMaster",
))

_register(AlgorithmRoute(
    name="Leiden Community Detection",
    short_name="LEIDEN",
    category=CAT_GRAPH,
    data_source=SRC_GRAPH,
    needs_graph=True,
    scaler="Original",
    never_scale=True,
    never_reduce=True,
    reduction_paths=[1],
    default_reduction=1,
    notes="Graph algorithm — community partitioning on GRAPH_DATA",
))

_register(AlgorithmRoute(
    name="OddBall (Graph Feature Anomaly)",
    short_name="ODDBALL",
    category=CAT_GRAPH,
    data_source=SRC_GRAPH,
    needs_graph=True,
    scaler="Original",
    never_scale=True,
    never_reduce=True,
    reduction_paths=[1],
    default_reduction=1,
    notes="Graph algorithm — ego-net features from GRAPH_DATA",
))

_register(AlgorithmRoute(
    name="Betweenness Centrality",
    short_name="BETWEENNESS",
    category=CAT_GRAPH,
    data_source=SRC_GRAPH,
    needs_graph=True,
    scaler="Original",
    never_scale=True,
    never_reduce=True,
    reduction_paths=[1],
    default_reduction=1,
    notes="Graph algorithm — centrality scores from GRAPH_DATA",
))

# ── TIME-SERIES ──────────────────────────────────────────────────────────────

_register(AlgorithmRoute(
    name="Change Point Detection",
    short_name="CHANGEPOINT",
    category=CAT_TIMESERIES,
    data_source=SRC_TEMPORAL,
    needs_temporal=True,
    scaler="Original",
    never_scale=True,
    reduction_paths=[1],
    default_reduction=1,
    never_reduce=True,
    notes="Time-Series — detects regime changes in raw signal; never scale",
))

_register(AlgorithmRoute(
    name="Matrix Profile",
    short_name="MATRIXPROFILE",
    category=CAT_TIMESERIES,
    data_source=SRC_TEMPORAL,
    needs_temporal=True,
    scaler="Original",
    reduction_paths=[1],
    default_reduction=1,
    never_reduce=True,
    notes="Time-Series — z-normalises internally; Original data preferred",
))

# ── DEEP LEARNING ────────────────────────────────────────────────────────────

_register(AlgorithmRoute(
    name="Variational Autoencoder (VAE)",
    short_name="VAE",
    category=CAT_DEEPLEARNING,
    scaler="MinMaxScaler",
    reduction_paths=[1, 2, 6, 7, 8],
    default_reduction=1,
    pyod_class="VAE",
    notes="Needs [0,1] input via MinMax; reconstruction error = score; SDAE pre-reduction optional",
))


# ─────────────────────────────────────────────────────────────────────────────
# ROUTING HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def get_route(algo_name: str) -> Optional[AlgorithmRoute]:
    """Look up route by short_name (e.g., 'LOF', 'GMM')."""
    return ALGORITHM_ROUTES.get(algo_name.upper())


def get_all_routes() -> Dict[str, AlgorithmRoute]:
    """Return the full routing table."""
    return ALGORITHM_ROUTES


def get_routes_by_category(category: str) -> List[AlgorithmRoute]:
    """Return all routes in a given category."""
    return [r for r in ALGORITHM_ROUTES.values() if r.category == category]


def get_routes_by_scaler(scaler_name: str) -> List[AlgorithmRoute]:
    """Return all algorithms that need a specific scaler."""
    return [r for r in ALGORITHM_ROUTES.values() if r.scaler == scaler_name]


def get_routes_by_data_source(source: str) -> List[AlgorithmRoute]:
    """Return all algorithms that use a specific data source."""
    return [r for r in ALGORITHM_ROUTES.values() if r.data_source == source]


def get_tabular_algorithms() -> List[AlgorithmRoute]:
    """Return algorithms that use tabular PreMaster (not graph/temporal)."""
    return [r for r in ALGORITHM_ROUTES.values() if r.data_source == SRC_TABULAR]


def get_graph_algorithms() -> List[AlgorithmRoute]:
    """Return algorithms that need GRAPH_DATA."""
    return [r for r in ALGORITHM_ROUTES.values() if r.needs_graph]


def get_temporal_algorithms() -> List[AlgorithmRoute]:
    """Return algorithms that need TEMPORAL_DATA."""
    return [r for r in ALGORITHM_ROUTES.values() if r.needs_temporal]


def routing_summary_df():
    """Return the routing table as a pandas DataFrame for display."""
    import pandas as pd
    rows = []
    for route in ALGORITHM_ROUTES.values():
        rows.append({
            "Algorithm": route.name,
            "Short": route.short_name,
            "Category": route.category,
            "Data Source": route.data_source,
            "Scaler": route.scaler,
            "Default Reduction": route.default_reduction,
            "Reduction Dims": route.reduction_dims or "auto",
            "Never Scale": route.never_scale,
            "Never Reduce": route.never_reduce,
            "PyOD Class": route.pyod_class or "custom",
            "Notes": route.notes[:60],
        })
    return pd.DataFrame(rows)


# ─────────────────────────────────────────────────────────────────────────────
# V28: CORRECTED TRANSFORM → SCALE AUTO-RULES ENGINE
# ─────────────────────────────────────────────────────────────────────────────
# PhD-validated per-algorithm preprocessing matrix.
# When the user selects "Auto" for scaling, the pipeline consults this map
# to give EACH algorithm its statistically optimal (transform, scaler)
# combination instead of forcing a single scaler on every detector.
#
# Transform values:
#   None  — No separate transform (algorithm is scale-invariant or scaler
#           already Gaussianises, e.g. PowerTransformer)
#   "log" — Apply np.log1p() on columns with scipy.stats.skew > 2.0
#           (reduces right-skew for distance / density algorithms)
#
# Scaler values:
#   "StandardScaler"   — z-score (mean=0, σ=1) — distance / density algos
#   "MinMaxScaler"     — [0, 1] bounded — neural network inputs
#   "RobustScaler"     — median-centred, IQR-based — outlier-resistant stats
#   "PowerTransformer" — Yeo-Johnson (Gaussianise + standardise in one step)
#   "Original"         — passthrough (tree splits, empirical CDF, raw digits)
# ─────────────────────────────────────────────────────────────────────────────

ALGO_PREPROCESS_MAP: Dict[str, Dict[str, Optional[str]]] = {
    # ── STATISTICAL ──────────────────────────────────────────────────────────
    #  IQR: quartile-based, inherently robust to outliers
    "iqr":              {"transform": None,  "scaler": "RobustScaler"},
    #  Z-Score (Modified): MAD-based, inherently robust
    "zscore":           {"transform": None,  "scaler": "RobustScaler"},
    #  Grubbs: assumes approximate normality
    "grubbs":           {"transform": None,  "scaler": "StandardScaler"},
    #  Dixon Q-test: assumes approximate normality
    "dixon":            {"transform": None,  "scaler": "StandardScaler"},
    #  Generalised ESD: assumes approximate normality
    "esd":              {"transform": None,  "scaler": "StandardScaler"},
    #  Mahalanobis: needs Gaussian-like input; PowerTransformer does BOTH
    "mahalanobis":      {"transform": None,  "scaler": "PowerTransformer"},
    #  Benford's Law: NEVER touch — raw digit distribution only
    "benford":          {"transform": None,  "scaler": "Original"},

    # ── TREE ─────────────────────────────────────────────────────────────────
    #  Isolation Forest: tree splits are scale-invariant
    "isolation_forest": {"transform": None,  "scaler": "Original"},
    #  Extended IF: same as standard IF
    "extended_if":      {"transform": None,  "scaler": "Original"},

    # ── DENSITY ──────────────────────────────────────────────────────────────
    #  HBOS: histogram bins work better on scaled data
    "hbos":             {"transform": "log", "scaler": "StandardScaler"},
    #  LOF: distance-based density estimation, needs normal-ish scales
    "lof":              {"transform": "log", "scaler": "StandardScaler"},
    #  ECOD: empirical CDF — distribution-free, scale-invariant
    "ecod":             {"transform": None,  "scaler": "Original"},
    #  COPOD: copula-based, empirical CDF — distribution-free
    "copod":            {"transform": None,  "scaler": "Original"},
    #  DBSCAN: Euclidean distance → needs comparable scales
    "dbscan":           {"transform": "log", "scaler": "StandardScaler"},
    #  OPTICS: ordering-based, distance-dependent
    "optics":           {"transform": "log", "scaler": "StandardScaler"},
    #  HDBSCAN: density-based, distance-dependent
    "hdbscan":          {"transform": "log", "scaler": "StandardScaler"},
    #  CBLOF: cluster-based LOF, distance-dependent
    "cblof":            {"transform": "log", "scaler": "StandardScaler"},

    # ── DISTANCE ─────────────────────────────────────────────────────────────
    #  k-thNN (ANN): Euclidean distance, needs comparable scales
    "knn":              {"transform": "log", "scaler": "StandardScaler"},

    # ── CLUSTERING ───────────────────────────────────────────────────────────
    #  GMM: Gaussian mixture components; PowerTransformer Gaussianises
    "gmm":              {"transform": None,  "scaler": "PowerTransformer"},
    #  K-Means: centroid distance-based
    "kmeans_anomaly":   {"transform": "log", "scaler": "StandardScaler"},
    #  Spectral: Laplacian eigenvalue-based
    "spectral":         {"transform": "log", "scaler": "StandardScaler"},

    # ── GRAPH ────────────────────────────────────────────────────────────────
    #  Graph algos operate on internally-built k-NN adjacency → raw features
    "pagerank":         {"transform": None,  "scaler": "Original"},
    "hits":             {"transform": None,  "scaler": "Original"},
    "community":        {"transform": None,  "scaler": "Original"},
    "centrality":       {"transform": None,  "scaler": "Original"},

    # ── TIME-SERIES ──────────────────────────────────────────────────────────
    #  STL decomposition: raw signal
    "stl":              {"transform": None,  "scaler": "Original"},
    #  ARIMA residuals: raw signal
    "arima_residual":   {"transform": None,  "scaler": "Original"},
    #  Prophet: raw signal
    "prophet":          {"transform": None,  "scaler": "Original"},

    # ── DEEP LEARNING ────────────────────────────────────────────────────────
    #  VAE: neural nets need bounded [0, 1] inputs via MinMax
    "vae":              {"transform": "log", "scaler": "MinMaxScaler"},
    #  Autoencoder: same bounded requirement
    "autoencoder":      {"transform": "log", "scaler": "MinMaxScaler"},
}


def get_preprocessing_config(algo_name: str) -> Dict[str, Optional[str]]:
    """
    V28 AUTO-RULES ENGINE: Return the statistically optimal
    ``{transform, scaler}`` for *algo_name* based on the corrected
    Transform → Scale matrix.

    When the pipeline ``primary_scaler`` is set to ``"Auto"``, this function
    is called once per active detection method so each algorithm receives
    the preprocessed matrix that gives it the highest statistical power.

    Returns:
        dict with keys ``"transform"`` (None | "log") and ``"scaler"``
        (one of the 6 canonical scaler names).
    """
    config = ALGO_PREPROCESS_MAP.get(algo_name.lower())
    if config:
        return config.copy()
    # Unknown algorithm → safe fallback: StandardScaler + conditional LOG
    logger.warning(f"No preprocessing config for '{algo_name}', defaulting to StandardScaler + log")
    return {"transform": "log", "scaler": "StandardScaler"}
