"""
AIM AI Vault V17 — PII Masking Module (Full Wiring)
================================================================
V17 Enhancements:
- E3: PIIAccessLog table populated on every PII column access
- E9: All callers now use mask_for_*() wrappers (safety lock enforced)

V16 Enhancements (retained):
- ENABLED_BY_DEFAULT=True with safety lock (ALLOW_PII_DISABLE)
- MASK_IN_MEMORY for DataVault in-memory views (FM-008)
- PII access audit logging to SQLite audit_logs table
- All thresholds TOML-parameterized

V8 Enhancements (retained):
- Storage-level masking (mask before writing to vault)
- Export masking (mask when exporting)
- Role-based PII detection using ColumnRoleConfig
"""

import re
import logging
import pandas as pd
import numpy as np
from typing import List, Optional
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import PII

_pii_logger = logging.getLogger("apurbadas.pii")


def mask_value(value: str, visible_chars: int = 4, pattern: str = "XXXX") -> str:
    """
    Mask a single value, keeping only the last N characters visible.
    
    Args:
        value: String to mask
        visible_chars: Number of characters to keep visible at end
        pattern: Replacement pattern for masked portion
        
    Returns:
        Masked string (e.g., "CUST-000123" -> "CUST-XXXX23")
    """
    if pd.isna(value) or value is None:
        return ""
    
    value = str(value)
    
    if len(value) <= visible_chars:
        return value
    
    # Find the prefix (before last hyphen or space)
    separators = ['-', '_', ' ']
    prefix_end = 0
    for sep in separators:
        idx = value.rfind(sep)
        if idx > prefix_end:
            prefix_end = idx + 1
    
    prefix = value[:prefix_end]
    suffix = value[prefix_end:]
    
    if len(suffix) <= visible_chars:
        return value
    
    masked_portion = pattern
    visible_portion = suffix[-visible_chars:]
    
    return f"{prefix}{masked_portion}{visible_portion}"


def mask_email(email: str) -> str:
    """
    Mask an email address, keeping first 2 chars and domain.
    
    Example: "john.doe@company.com" -> "jo****@company.com"
    """
    if pd.isna(email) or '@' not in str(email):
        return str(email) if not pd.isna(email) else ""
    
    email = str(email)
    local, domain = email.rsplit('@', 1)
    
    if len(local) <= 2:
        masked_local = local
    else:
        masked_local = local[:2] + "****"
    
    return f"{masked_local}@{domain}"


def mask_phone(phone: str) -> str:
    """
    Mask a phone number, keeping only last 4 digits.
    
    Example: "+1-555-123-4567" -> "***-***-**-4567"
    """
    if pd.isna(phone):
        return ""
    
    phone = str(phone)
    digits = re.sub(r'\D', '', phone)
    
    if len(digits) <= 4:
        return phone
    
    return f"***-***-{digits[-4:]}"


def mask_account(account: str) -> str:
    """
    Mask an account number, keeping last 4 digits.
    
    Example: "ACC-1234567890" -> "ACC-******7890"
    """
    if pd.isna(account):
        return ""
    
    account = str(account)
    
    # Find prefix
    match = re.match(r'^([A-Za-z]+[-_]?)', account)
    prefix = match.group(1) if match else ""
    
    suffix = account[len(prefix):]
    
    if len(suffix) <= 4:
        return account
    
    return f"{prefix}******{suffix[-4:]}"


def mask_dataframe(
    df: pd.DataFrame, 
    columns: Optional[List[str]] = None,
    enabled: bool = True,
    caller: str = "unknown",
) -> pd.DataFrame:
    """
    Apply PII masking to specified columns in a DataFrame.
    
    V16 Bank Audit Hardening:
      - If PII.ENABLED_BY_DEFAULT=True AND PII.ALLOW_PII_DISABLE=False,
        the `enabled` parameter is IGNORED — masking is always ON.
      - Every PII column access is logged to the audit trail when
        PII.LOG_PII_ACCESS=True.
    
    Args:
        df: DataFrame to mask
        columns: Columns to mask. If None, uses config.PII.MASKED_COLUMNS
        enabled: Whether masking is enabled (overridden by safety lock)
        caller: Identifier for the calling function (for audit log)
        
    Returns:
        DataFrame with masked values (original data unchanged)
    """
    # V16: Safety lock — if PII is enforced, ignore `enabled=False`
    effective_enabled = enabled
    if PII.ENABLED_BY_DEFAULT and not PII.ALLOW_PII_DISABLE:
        effective_enabled = True  # Cannot be disabled without explicit TOML override
    
    if not effective_enabled:
        return df
    
    masked_df = df.copy()
    columns = columns or PII.MASKED_COLUMNS
    
    # V16: Audit-log PII column access
    matched_cols = [c for c in columns if c in masked_df.columns]
    if matched_cols and PII.LOG_PII_ACCESS:
        _log_pii_access(matched_cols, len(masked_df), caller)
    
    for col in columns:
        if col not in masked_df.columns:
            continue
        
        col_lower = col.lower()
        
        # Apply appropriate masking based on column type
        if 'email' in col_lower:
            masked_df[col] = masked_df[col].apply(mask_email)
        elif 'phone' in col_lower or 'mobile' in col_lower:
            masked_df[col] = masked_df[col].apply(mask_phone)
        elif 'account' in col_lower:
            masked_df[col] = masked_df[col].apply(mask_account)
        else:
            # Default masking
            masked_df[col] = masked_df[col].apply(
                lambda x: mask_value(x, PII.VISIBLE_CHARS, PII.MASK_PATTERN)
            )
    
    return masked_df


def _log_pii_access(columns: List[str], n_rows: int, caller: str):
    """V17 E3: Audit-log every PII column access to BOTH audit trail AND PIIAccessLog table."""
    # 1. Write to audit log (file + audit_logs table) — retained from V16
    try:
        from utils.logger import logger as audit_logger
        audit_logger.log_action(
            action="PII_ACCESS",
            user="system",
            metadata={
                "columns": columns,
                "n_rows": n_rows,
                "caller": caller,
                "masking_applied": True,
            },
        )
    except Exception:
        _pii_logger.debug("PII access audit log failed (non-blocking)")

    # 2. V17 E3: Write to PIIAccessLog SQLAlchemy table for regulatory audit
    try:
        import json as _json
        from database.engine import write_session
        from database.models import PIIAccessLog
        with write_session() as session:
            session.add(PIIAccessLog(
                caller=caller[:128],
                columns_accessed=_json.dumps(columns),
                n_rows=n_rows,
                masking_applied=True,
                username="system",
                client_ip="127.0.0.1",
            ))
    except Exception:
        _pii_logger.debug("PIIAccessLog DB write failed (non-blocking)")


def detect_pii_columns(df: pd.DataFrame) -> List[str]:
    """
    Automatically detect columns that may contain PII.
    
    Args:
        df: DataFrame to analyze
        
    Returns:
        List of column names likely to contain PII
    """
    pii_keywords = [
        'customer', 'client', 'account', 'id', 'name', 'email',
        'phone', 'mobile', 'ssn', 'social', 'address', 'zip',
        'postal', 'dob', 'birth', 'passport'
    ]
    
    detected = []
    
    for col in df.columns:
        col_lower = col.lower()
        for keyword in pii_keywords:
            if keyword in col_lower:
                detected.append(col)
                break
    
    return detected


def mask_for_storage(df: pd.DataFrame) -> pd.DataFrame:
    """
    V8: Apply PII masking suitable for on-disk storage.
    V16: Respects safety lock and logs PII access.
    Detects PII columns automatically and masks them.
    Returns a new DataFrame (original untouched).
    """
    pii_cols = detect_pii_columns(df)
    if not pii_cols:
        return df
    return mask_dataframe(df, columns=pii_cols, enabled=True, caller="mask_for_storage")


def mask_for_export(df: pd.DataFrame) -> pd.DataFrame:
    """
    V8: Apply PII masking for data exports.
    V16: Respects safety lock and logs PII access.
    """
    return mask_dataframe(
        df, columns=detect_pii_columns(df), enabled=True, caller="mask_for_export"
    )


def mask_for_memory(df: pd.DataFrame) -> pd.DataFrame:
    """
    V16 FM-008: Apply PII masking for in-memory DataVault views.
    Only active when PII.MASK_IN_MEMORY=True.
    Returns masked copy; original DataFrame unchanged.
    """
    if not PII.MASK_IN_MEMORY:
        return df
    pii_cols = detect_pii_columns(df)
    if not pii_cols:
        return df
    return mask_dataframe(df, columns=pii_cols, enabled=True, caller="mask_for_memory")


def mask_for_api(df: pd.DataFrame) -> pd.DataFrame:
    """
    V16: Apply PII masking for REST API responses.
    Only active when PII.MASK_IN_API=True.
    """
    if not PII.MASK_IN_API:
        return df
    pii_cols = detect_pii_columns(df)
    if not pii_cols:
        return df
    return mask_dataframe(df, columns=pii_cols, enabled=True, caller="mask_for_api")
