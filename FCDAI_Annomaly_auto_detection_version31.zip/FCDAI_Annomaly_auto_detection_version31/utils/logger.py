"""
AIM AI Vault V16 — Logger Module (Bank Audit Hardened)
=========================================================
Comprehensive audit logging and error tracking for FinCEN compliance.

V16 Bank Audit Hardening:
  - A6: Hash chain verified on load with corruption recovery from backups
  - verify_hash_chain() — on-demand integrity check callable from UI/API
  - Rotating backup copies of hash state file (TOML-configurable)
  - Batch write interval TOML-parameterized (no hardcoded constants)

V14 (retained):
  - Structured JSON logging (observability-ready)
  - Error aggregation (dedup within time window)
V10: Dual logging — file + SQLite audit_logs table.

Author: AIM AI Vault Team
"""

import logging
import logging.handlers
import os
import sys
import hashlib
import atexit
import socket
import time
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any
from collections import defaultdict
import traceback
import json
import threading

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from config import PATHS, AUDIT, LOGGING


# =============================================================================
# V14: STRUCTURED JSON FORMATTER
# =============================================================================
class StructuredJSONFormatter(logging.Formatter):
    """
    JSON log formatter for machine-parseable structured logging.
    Each log line is a single JSON object with standardized fields.
    """

    def __init__(self):
        super().__init__()
        self._hostname = socket.gethostname()
        self._pid = os.getpid()

    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            "timestamp": datetime.fromtimestamp(record.created).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage()[:LOGGING.MAX_MESSAGE_LENGTH],
        }
        if LOGGING.INCLUDE_HOSTNAME:
            log_entry["hostname"] = self._hostname
        if LOGGING.INCLUDE_PROCESS_ID:
            log_entry["pid"] = self._pid
            log_entry["thread"] = record.threadName
        if record.exc_info and record.exc_info[1]:
            log_entry["exception"] = {
                "type": type(record.exc_info[1]).__name__,
                "message": str(record.exc_info[1])[:500],
            }
        # Extra fields
        if hasattr(record, "extra_data"):
            log_entry["data"] = record.extra_data
        return json.dumps(log_entry, default=str)


# =============================================================================
# V14: ERROR AGGREGATOR (dedup within time window)
# =============================================================================
class ErrorAggregator:
    """
    Aggregates repeated errors within a time window to prevent log flooding.
    Thread-safe.
    """

    def __init__(self, window_sec: int = None):
        self._window_sec = window_sec or LOGGING.ERROR_AGG_WINDOW_SEC
        self._lock = threading.Lock()
        # Key: (error_type, context) -> {"count": N, "first_seen": ts, "last_seen": ts}
        self._buckets: Dict[tuple, Dict] = {}

    def should_log(self, error_type: str, context: str) -> tuple:
        """
        Check if this error should be logged or suppressed (aggregated).

        Returns: (should_log: bool, suppressed_count: int)
        """
        if not LOGGING.ERROR_AGGREGATION:
            return True, 0

        key = (error_type, context)
        now = time.time()

        with self._lock:
            if key not in self._buckets:
                self._buckets[key] = {"count": 1, "first_seen": now, "last_seen": now}
                return True, 0

            bucket = self._buckets[key]
            elapsed = now - bucket["first_seen"]

            if elapsed > self._window_sec:
                # Window expired — reset and log with suppressed count
                suppressed = bucket["count"] - 1
                self._buckets[key] = {"count": 1, "first_seen": now, "last_seen": now}
                return True, suppressed
            else:
                # Within window — increment but suppress
                bucket["count"] += 1
                bucket["last_seen"] = now
                return False, 0

    def get_summary(self) -> Dict:
        """Return aggregation summary for monitoring."""
        with self._lock:
            return {
                k[0] + ":" + k[1]: v["count"]
                for k, v in self._buckets.items()
                if v["count"] > 1
            }


class AuditLogger:
    """
    Enterprise audit logging for AML compliance.
    
    V16 Bank Audit Hardening:
    - Hash chain verified on load (corruption detection + recovery from backup)
    - verify_hash_chain() callable from UI/API for on-demand integrity check
    - Backup copies of hash state file (AUDIT.HASH_CHAIN_BACKUP_COUNT)
    - Batch interval TOML-parameterized (AUDIT.HASH_CHAIN_BATCH_INTERVAL)
    
    V10 Enhancements:
    - Dual logging: file + SQLite audit_logs table
    
    V9 Enhancements:
    - FM-007: Hash chain persisted to disk across restarts
    
    V8 Enhancements:
    - Rotating file handlers (10MB max, 10 backups)
    - Hash-chain tamper-evident logging
    - Configurable via AuditConfig
    
    Creates two log files:
    - admin_audit.log: User actions (import, export, model training)
    - system_errors.log: Errors and exceptions
    """
    
    _instance = None
    _prev_hash = "GENESIS"  # Hash chain seed
    _HASH_STATE_FILE = PATHS.LOGS / ".hash_chain_state"  # V9: FM-007
    _hash_write_counter = 0
    
    def __new__(cls):
        """Singleton pattern - only one logger instance."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        """Initialize loggers if not already done."""
        if self._initialized:
            return
            
        self._initialized = True
        self._error_aggregator = ErrorAggregator()
        self._load_hash_chain_state()   # V9: FM-007 + V16 hardened
        self._setup_audit_logger()
        self._setup_error_logger()
        self._setup_json_logger()       # V14: Structured JSON log file
        # V13 B-7: Flush hash chain state on exit
        atexit.register(self._flush_hash_chain_state)
    
    def _validate_hash_format(self, state: str) -> bool:
        """V16: Validate that a hash state looks like a valid hex digest."""
        if not state or not isinstance(state, str):
            return False
        # Valid hash should be 8-128 hex chars (SHA-256 truncated to 16 or full 64)
        import re
        return bool(re.match(r'^[0-9a-fA-F]{8,128}$', state)) or state == "GENESIS"
    
    def _load_hash_chain_state(self):
        """V16 Hardened FM-007: Load + verify hash chain state from disk.
        
        Recovery strategy on corruption:
          1. Try primary state file
          2. If invalid, try backup files (.bak.1, .bak.2, ...)
          3. If all fail, reset to GENESIS and log critical warning
        """
        _log = logging.getLogger("apurbadas.audit")
        
        # 1. Try primary file
        try:
            if self._HASH_STATE_FILE.exists():
                state = self._HASH_STATE_FILE.read_text(encoding='utf-8').strip()
                if self._validate_hash_format(state):
                    AuditLogger._prev_hash = state
                    if AUDIT.HASH_CHAIN_VERIFY_ON_LOAD:
                        _log.info(f"Hash chain state loaded OK: ...{state[-8:]}")
                    return
                else:
                    _log.warning(f"Hash chain state file corrupted: '{state[:20]}...'")
        except Exception as exc:
            _log.warning(f"Hash chain state file unreadable: {type(exc).__name__}")
        
        # 2. Try backup files
        for i in range(1, AUDIT.HASH_CHAIN_BACKUP_COUNT + 1):
            bak_path = self._HASH_STATE_FILE.with_suffix(f'.bak.{i}')
            try:
                if bak_path.exists():
                    state = bak_path.read_text(encoding='utf-8').strip()
                    if self._validate_hash_format(state):
                        AuditLogger._prev_hash = state
                        _log.warning(f"Hash chain restored from backup .bak.{i}: ...{state[-8:]}")
                        # Re-save to primary
                        self._flush_hash_chain_state()
                        return
            except Exception:
                continue
        
        # 3. All failed — reset to GENESIS
        AuditLogger._prev_hash = "GENESIS"
        _log.critical(
            "HASH CHAIN INTEGRITY: All state files corrupted/missing — "
            "chain reset to GENESIS. Previous audit continuity broken."
        )
    
    def _save_hash_chain_state(self):
        """V16: Batched persist — interval now TOML-parameterized."""
        AuditLogger._hash_write_counter += 1
        batch_interval = AUDIT.HASH_CHAIN_BATCH_INTERVAL  # V16: from config
        if AuditLogger._hash_write_counter % batch_interval != 0:
            return  # Skip — will flush on shutdown or next batch boundary
        self._flush_hash_chain_state()

    def _flush_hash_chain_state(self):
        """V16 Hardened C-4: Atomic write + rotating backup copies."""
        try:
            self._HASH_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
            
            # V16: Rotate backup copies before writing new state
            if self._HASH_STATE_FILE.exists():
                for i in range(AUDIT.HASH_CHAIN_BACKUP_COUNT, 1, -1):
                    older = self._HASH_STATE_FILE.with_suffix(f'.bak.{i-1}')
                    newer = self._HASH_STATE_FILE.with_suffix(f'.bak.{i}')
                    if older.exists():
                        try:
                            older.replace(newer)
                        except Exception:
                            pass
                # Current → .bak.1
                try:
                    import shutil
                    shutil.copy2(str(self._HASH_STATE_FILE),
                                 str(self._HASH_STATE_FILE.with_suffix('.bak.1')))
                except Exception:
                    pass
            
            # Atomic write: tmp → rename
            tmp_path = self._HASH_STATE_FILE.with_suffix('.tmp')
            tmp_path.write_text(AuditLogger._prev_hash, encoding='utf-8')
            tmp_path.replace(self._HASH_STATE_FILE)  # Atomic rename
        except Exception:
            logging.getLogger("apurbadas.audit").warning(
                "Failed to persist hash chain state to disk"
            )
    
    def verify_hash_chain(self) -> Dict[str, Any]:
        """
        V16: On-demand hash chain integrity verification.
        
        Replays the audit log file and recomputes hash chain from GENESIS.
        Compares final computed hash against current _prev_hash and disk state.
        
        Returns:
            Dict with keys:
              - valid (bool): True if hash chain is intact
              - entries_checked (int): Number of audit entries replayed
              - mismatches (list): Line numbers where hashes diverge
              - current_hash (str): Current in-memory hash (last 8 chars)
              - disk_hash (str): Hash on disk (last 8 chars)
              - status (str): PASS / FAIL / DEGRADED
        """
        result = {
            "valid": False,
            "entries_checked": 0,
            "mismatches": [],
            "current_hash": AuditLogger._prev_hash[-8:] if AuditLogger._prev_hash else "N/A",
            "disk_hash": "N/A",
            "status": "UNKNOWN",
        }
        
        # Check disk state
        try:
            if self._HASH_STATE_FILE.exists():
                disk_state = self._HASH_STATE_FILE.read_text(encoding='utf-8').strip()
                result["disk_hash"] = disk_state[-8:] if disk_state else "EMPTY"
        except Exception:
            result["disk_hash"] = "UNREADABLE"
        
        # Replay audit log
        log_path = PATHS.LOGS / "admin_audit.log"
        if not log_path.exists():
            result["status"] = "PASS"
            result["valid"] = True
            return result
        
        try:
            replay_hash = "GENESIS"
            line_num = 0
            
            with open(log_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line_num += 1
                    if "HASH=" not in line:
                        continue
                    
                    result["entries_checked"] += 1
                    
                    # Extract the recorded hash from the log line
                    try:
                        hash_part = line.split("HASH=")[1].strip().split("|")[0].strip()
                    except (IndexError, ValueError):
                        result["mismatches"].append(line_num)
                        continue
                    
                    # Extract the message portion (before HASH=) for replay
                    try:
                        msg_part = line.split(" | HASH=")[0]
                        # Remove timestamp prefix (first 2 pipe-separated parts)
                        parts = msg_part.split(" | ", 2)
                        if len(parts) >= 3:
                            replay_msg = parts[2]
                        else:
                            replay_msg = msg_part
                    except Exception:
                        result["mismatches"].append(line_num)
                        continue
                    
                    # Recompute expected hash
                    chain_data = f"{replay_hash}|{replay_msg}"
                    expected = hashlib.new(
                        AUDIT.HASH_ALGORITHM, chain_data.encode()
                    ).hexdigest()[:16]
                    
                    if expected != hash_part:
                        result["mismatches"].append(line_num)
                    
                    replay_hash = hash_part  # Chain forward with recorded hash
            
            # Assess result
            if not result["mismatches"]:
                result["valid"] = True
                result["status"] = "PASS"
            elif len(result["mismatches"]) <= 3:
                result["valid"] = False
                result["status"] = "DEGRADED"
            else:
                result["valid"] = False
                result["status"] = "FAIL"
                
        except Exception as exc:
            result["status"] = f"ERROR: {type(exc).__name__}"
        
        return result
    
    def _setup_audit_logger(self):
        """Configure the admin audit logger with rotation."""
        self.audit_logger = logging.getLogger("apurbadas.audit")
        self.audit_logger.setLevel(logging.INFO)
        self.audit_logger.propagate = False   # V20: keep audit in file only, no console leak
        
        # Prevent duplicate handlers
        if self.audit_logger.handlers:
            return
        
        log_path = PATHS.LOGS / "admin_audit.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        # V8: Rotating file handler
        handler = logging.handlers.RotatingFileHandler(
            log_path,
            maxBytes=AUDIT.LOG_ROTATION_MAX_BYTES,
            backupCount=AUDIT.LOG_ROTATION_BACKUP_COUNT,
            encoding='utf-8',
        )
        handler.setLevel(logging.INFO)
        
        formatter = logging.Formatter(
            '%(asctime)s | %(levelname)s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        handler.setFormatter(formatter)
        self.audit_logger.addHandler(handler)
    
    def _setup_error_logger(self):
        """Configure the system error logger with rotation."""
        self.error_logger = logging.getLogger("apurbadas.errors")
        self.error_logger.setLevel(logging.ERROR)
        self.error_logger.propagate = False   # V20: keep errors in file only, no console leak
        
        # Prevent duplicate handlers
        if self.error_logger.handlers:
            return
        
        log_path = PATHS.LOGS / "system_errors.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        # V8: Rotating file handler
        handler = logging.handlers.RotatingFileHandler(
            log_path,
            maxBytes=AUDIT.LOG_ROTATION_MAX_BYTES,
            backupCount=AUDIT.LOG_ROTATION_BACKUP_COUNT,
            encoding='utf-8',
        )
        handler.setLevel(logging.ERROR)
        
        formatter = logging.Formatter(
            '%(asctime)s | %(levelname)s | %(name)s\n'
            'Message: %(message)s\n'
            '---\n',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        handler.setFormatter(formatter)
        self.error_logger.addHandler(handler)

    def _setup_json_logger(self):
        """V14: Configure structured JSON log file for machine parsing."""
        if not LOGGING.STRUCTURED_JSON:
            return

        self.json_logger = logging.getLogger("apurbadas.structured")
        self.json_logger.setLevel(getattr(logging, LOGGING.LOG_LEVEL, logging.INFO))
        self.json_logger.propagate = False   # V20: keep structured logs in file only, no console leak

        if self.json_logger.handlers:
            return

        log_path = PATHS.LOGS / "structured.jsonl"
        log_path.parent.mkdir(parents=True, exist_ok=True)

        handler = logging.handlers.RotatingFileHandler(
            log_path,
            maxBytes=AUDIT.LOG_ROTATION_MAX_BYTES,
            backupCount=AUDIT.LOG_ROTATION_BACKUP_COUNT,
            encoding='utf-8',
        )
        handler.setLevel(getattr(logging, LOGGING.LOG_LEVEL, logging.INFO))
        handler.setFormatter(StructuredJSONFormatter())
        self.json_logger.addHandler(handler)
    
    def log_action(
        self, 
        action: str, 
        user: str = "system",
        metadata: Optional[Dict[str, Any]] = None,
        status: str = "SUCCESS"
    ):
        """
        Log a user action to the audit trail.
        
        Args:
            action: Description of the action (e.g., "Data Import")
            user: User identifier (default: "system")
            metadata: Additional context (e.g., {"rows": 10000})
            status: Action status ("SUCCESS", "FAILED", "PENDING")
        
        Example:
            logger.log_action("Data Import", metadata={"file": "tx.csv", "rows": 10000})
        """
        meta_str = json.dumps(metadata) if metadata else "{}"
        message = f"ACTION={action} | USER={user} | STATUS={status} | META={meta_str}"

        # V8: Hash-chain integrity
        if AUDIT.ENABLE_HASH_CHAIN_LOGS:
            chain_data = f"{AuditLogger._prev_hash}|{message}"
            new_hash = hashlib.new(AUDIT.HASH_ALGORITHM, chain_data.encode()).hexdigest()[:16]
            message = f"{message} | HASH={new_hash}"
            AuditLogger._prev_hash = new_hash
            self._save_hash_chain_state()  # V9: FM-007 persist state

        self.audit_logger.info(message)

        # V14: Structured JSON log
        if LOGGING.STRUCTURED_JSON and hasattr(self, 'json_logger'):
            record = self.json_logger.makeRecord(
                "apurbadas.structured", logging.INFO, "", 0,
                f"{action} by {user}: {status}", (), None,
            )
            record.extra_data = {"action": action, "user": user, "status": status, "metadata": metadata}
            self.json_logger.handle(record)

        # V10: Also log to SQLite audit_logs table
        self._sync_to_db(action, user, status, metadata, new_hash if AUDIT.ENABLE_HASH_CHAIN_LOGS else None)
    
    def log_pipeline_start(self, pipeline_name: str, algorithms: list):
        """Log the start of a pipeline run."""
        self.log_action(
            action=f"Pipeline Start: {pipeline_name}",
            metadata={"algorithms": algorithms, "count": len(algorithms)}
        )
    
    def log_pipeline_complete(self, pipeline_name: str, duration: float, n_anomalies: int):
        """Log pipeline completion with metrics."""
        self.log_action(
            action=f"Pipeline Complete: {pipeline_name}",
            metadata={
                "duration_seconds": round(duration, 2),
                "anomalies_detected": n_anomalies
            }
        )
    
    def log_model_training(self, model_name: str, params: dict, duration: float):
        """Log individual model training."""
        self.log_action(
            action=f"Model Training: {model_name}",
            metadata={
                "parameters": params,
                "duration_seconds": round(duration, 2)
            }
        )
    
    def log_data_import(self, filename: str, rows: int, columns: int):
        """Log data import event."""
        self.log_action(
            action="Data Import",
            metadata={
                "filename": filename,
                "rows": rows,
                "columns": columns,
                "timestamp": datetime.now().isoformat()
            }
        )
    
    def log_export(self, export_type: str, filename: str, rows: int):
        """Log data export event."""
        self.log_action(
            action=f"Export: {export_type}",
            metadata={
                "filename": filename,
                "rows": rows,
                "timestamp": datetime.now().isoformat()
            }
        )
    
    def log_error(
        self, 
        exception: Exception, 
        context: str = "",
        metadata: Optional[Dict[str, Any]] = None
    ):
        """
        Log an error with full traceback.
        V14: Error aggregation — suppresses repeated identical errors.
        """
        error_type = type(exception).__name__

        # V14: Error aggregation check
        should_log, suppressed = self._error_aggregator.should_log(error_type, context)
        if not should_log:
            return  # Suppressed — will be reported on next window

        tb = traceback.format_exc()
        meta_str = json.dumps(metadata) if metadata else "{}"
        
        suppressed_note = ""
        if suppressed > 0:
            suppressed_note = f" | SUPPRESSED={suppressed} identical errors in last {LOGGING.ERROR_AGG_WINDOW_SEC}s"
        
        message = (
            f"CONTEXT={context} | "
            f"ERROR={error_type}: {str(exception)} | "
            f"META={meta_str}{suppressed_note}\n"
            f"TRACEBACK:\n{tb}"
        )
        
        self.error_logger.error(message)
        
        # Also log to audit trail
        self.log_action(
            action=f"Error: {context}",
            status="FAILED",
            metadata={
                "error_type": type(exception).__name__,
                "error_message": str(exception)
            }
        )
    
    def get_recent_logs(self, n_lines: int = 50, log_type: str = "audit") -> list:
        """
        Get recent log entries.
        
        Args:
            n_lines: Number of recent lines to return
            log_type: "audit" or "errors"
            
        Returns:
            List of log entry strings
        """
        if log_type == "audit":
            log_path = PATHS.LOGS / "admin_audit.log"
        else:
            log_path = PATHS.LOGS / "system_errors.log"
        
        if not log_path.exists():
            return []
        
        try:
            with open(log_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            return lines[-n_lines:] if len(lines) > n_lines else lines
        except Exception:
            return []

    # -----------------------------------------------------------------
    # V10: Fine-grained audit methods (view, filter, flag actions)
    # -----------------------------------------------------------------
    def _get_client_ip(self) -> str:
        """Extract client IP from Flask request context."""
        try:
            from flask import request
            return request.remote_addr or "127.0.0.1"
        except (ImportError, RuntimeError):
            return "127.0.0.1"

    def log_view(self, page: str, user: str = "system"):
        """Log a page view event."""
        self.log_action(
            action=f"VIEW:{page}",
            user=user,
            metadata={"page": page, "client_ip": self._get_client_ip()},
        )

    def log_filter(self, filter_type: str, filter_value: str, user: str = "system"):
        """Log a filter/search event."""
        self.log_action(
            action=f"FILTER:{filter_type}",
            user=user,
            metadata={"filter": filter_type, "value": str(filter_value)[:200], "client_ip": self._get_client_ip()},
        )

    def log_flag(self, entity_id: str, flag_type: str, user: str = "system"):
        """Log an anomaly flag/confirmation event.
        F-04 FIX: Hash entity_id before writing to audit trail."""
        hashed_eid = entity_id
        try:
            from utils.crypto import hash_entity_id_short
            hashed_eid = hash_entity_id_short(entity_id)
        except ImportError:
            pass  # crypto wheel not available — degrade gracefully
        self.log_action(
            action=f"FLAG:{flag_type}",
            user=user,
            metadata={"entity_id": hashed_eid, "flag_type": flag_type, "client_ip": self._get_client_ip()},
        )


# Global logger instance
logger = AuditLogger()


# ---------------------------------------------------------------------------
# V10: SQLite sync (defined outside class to avoid circular imports at init)
# ---------------------------------------------------------------------------
def _sync_audit_to_db(action, user, status, metadata, hash_val):
    """Write an audit record to the SQLite audit_logs table. Best-effort."""
    try:
        from database.engine import get_session
        from database.models import AuditLog
        session = get_session()
        try:
            # V10: Extract client_ip from metadata if present
            client_ip = "127.0.0.1"
            if metadata and isinstance(metadata, dict):
                client_ip = metadata.get("client_ip", "127.0.0.1")
            else:
                try:
                    from flask import request
                    client_ip = request.remote_addr or "127.0.0.1"
                except (ImportError, RuntimeError):
                    pass
            record = AuditLog(
                username=user,
                action=action,
                status=status,
                metadata_json=json.dumps(metadata) if metadata else None,
                hash_chain=hash_val,
                client_ip=client_ip,
            )
            session.add(record)
            session.commit()
        except Exception:
            session.rollback()
        finally:
            session.close()
    except Exception:
        # F-09 FIX: warn instead of silent swallow
        logging.getLogger("apurbadas.audit").warning(
            "Audit DB sync failed (DB may not be initialized yet)"
        )


# Monkey-patch the sync method onto the singleton
AuditLogger._sync_to_db = staticmethod(lambda action, user, status, meta, h: _sync_audit_to_db(action, user, status, meta, h))
