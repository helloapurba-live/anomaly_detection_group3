"""
Type-Specific Imputation
========================
STEP 7 from pipeline: Handle missing values based on detected column types.

Imputation Strategy:
- CONTINUOUS → Median
- ORDINAL → Median (preserve order)
- BINARY → Mode
- CATEGORICAL → "UNKNOWN" category
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from utils.schema_detector import ColumnType, ColumnProfile


class TypeSpecificImputer:
    """
    Impute missing values based on auto-detected column types.
    
    PRINCIPLE: Different data types require different imputation strategies
    to preserve statistical properties and modeling effectiveness.
    """
    
    def __init__(self):
        self.imputation_stats: Dict = {}
        self.imputation_log: List[str] = []
    
    def fit_transform(
        self,
        df: pd.DataFrame,
        column_profiles: Dict[str, ColumnProfile]
    ) -> pd.DataFrame:
        """
        Impute missing values based on column types.
        
        Args:
            df: DataFrame with missing values
            column_profiles: Column profiles from SchemaDetector
            
        Returns:
            DataFrame with imputed values
        """
        df_imputed = df.copy()
        self.imputation_log = []
        self.imputation_stats = {}
        
        for col_name, profile in column_profiles.items():
            if col_name not in df_imputed.columns:
                continue
            
            # Skip if no missing values
            if profile.null_count == 0:
                continue
            
            # Impute based on type
            if profile.col_type == ColumnType.CONTINUOUS:
                df_imputed[col_name] = self._impute_continuous(
                    df_imputed[col_name], col_name
                )
            
            elif profile.col_type == ColumnType.ORDINAL:
                df_imputed[col_name] = self._impute_ordinal(
                    df_imputed[col_name], col_name
                )
            
            elif profile.col_type == ColumnType.BINARY:
                df_imputed[col_name] = self._impute_binary(
                    df_imputed[col_name], col_name
                )
            
            elif profile.col_type == ColumnType.CATEGORICAL:
                df_imputed[col_name] = self._impute_categorical(
                    df_imputed[col_name], col_name
                )
            
            elif profile.col_type == ColumnType.DATETIME:
                # Skip datetime imputation (too complex)
                continue
            
            # Log imputation
            log_msg = f"Imputed {col_name} ({profile.col_type.value}): {profile.null_count} values"
            self.imputation_log.append(log_msg)
        
        return df_imputed
    
    def _impute_continuous(self, series: pd.Series, col_name: str) -> pd.Series:
        """
        Impute continuous features with MEDIAN.
        Median is robust to outliers.
        """
        median_value = series.median()
        self.imputation_stats[col_name] = {
            'type': 'CONTINUOUS',
            'method': 'MEDIAN',
            'value': float(median_value)
        }
        return series.fillna(median_value)
    
    def _impute_ordinal(self, series: pd.Series, col_name: str) -> pd.Series:
        """
        Impute ordinal features with MEDIAN.
        Preserves order and central tendency.
        """
        median_value = series.median()
        # Round to nearest integer for ordinal
        median_int = int(round(median_value))
        self.imputation_stats[col_name] = {
            'type': 'ORDINAL',
            'method': 'MEDIAN (rounded)',
            'value': median_int
        }
        return series.fillna(median_int)
    
    def _impute_binary(self, series: pd.Series, col_name: str) -> pd.Series:
        """
        Impute binary features with MODE.
        Use most common value to preserve distribution.
        """
        mode_values = series.mode()
        if len(mode_values) > 0:
            mode_value = mode_values.iloc[0]
        else:
            # Fallback to 0 if mode cannot be determined
            mode_value = 0
        
        self.imputation_stats[col_name] = {
            'type': 'BINARY',
            'method': 'MODE',
            'value': mode_value
        }
        return series.fillna(mode_value)
    
    def _impute_categorical(self, series: pd.Series, col_name: str) -> pd.Series:
        """
        Impute categorical features with "UNKNOWN" category.
        Creates explicit missing indicator rather than using mode.
        """
        self.imputation_stats[col_name] = {
            'type': 'CATEGORICAL',
            'method': 'UNKNOWN',
            'value': 'UNKNOWN'
        }
        return series.fillna('UNKNOWN')
    
    def get_imputation_report(self) -> str:
        """Generate human-readable imputation report."""
        lines = []
        lines.append("=" * 80)
        lines.append("TYPE-SPECIFIC IMPUTATION REPORT")
        lines.append("=" * 80)
        lines.append(f"Total Columns Imputed: {len(self.imputation_stats)}")
        lines.append("")
        
        for col_name, stats in self.imputation_stats.items():
            lines.append(f"{col_name}:")
            lines.append(f"  Type: {stats['type']}")
            lines.append(f"  Method: {stats['method']}")
            lines.append(f"  Fill Value: {stats['value']}")
        
        return "\n".join(lines)
    
    def transform(
        self,
        df: pd.DataFrame,
        column_profiles: Optional[Dict[str, ColumnProfile]] = None
    ) -> pd.DataFrame:
        """
        Transform new data using fitted imputation values.
        
        Args:
            df: DataFrame to impute
            column_profiles: Optional profiles (uses fitted stats if not provided)
            
        Returns:
            Imputed DataFrame
        """
        if not self.imputation_stats:
            raise ValueError("Imputer not fitted. Call fit_transform first.")
        
        df_imputed = df.copy()
        
        for col_name, stats in self.imputation_stats.items():
            if col_name in df_imputed.columns:
                df_imputed[col_name] = df_imputed[col_name].fillna(stats['value'])
        
        return df_imputed
