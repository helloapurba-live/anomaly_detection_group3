"""
AIM AI Vault V14 — Health Check Endpoints
==========================================
Provides /health (liveness) and /ready (readiness) JSON endpoints
for production monitoring. Designed for local-only deployment —
no cloud health probes, just localhost introspection.

Author: AIM AI Vault Team
"""

import sys
import time
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, Any

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import APP, PATHS, HEALTH

_health_logger = logging.getLogger("apurbadas.health")

# Module-level start time (set once on import)
_START_TIME = time.time()


def check_database() -> Dict[str, Any]:
    """Check SQLite database connectivity and size."""
    db_path = PATHS.DATA / "sentinel_vault.db"
    try:
        if not db_path.exists():
            return {"status": "unhealthy", "error": "Database file not found"}
        # Quick integrity check
        from database.engine import get_engine
        from sqlalchemy import text
        engine = get_engine()
        with engine.connect() as conn:
            result = conn.execute(text("SELECT 1")).scalar()
            if result != 1:
                return {"status": "unhealthy", "error": "DB query returned unexpected result"}
        size_mb = db_path.stat().st_size / (1024 * 1024)
        return {"status": "healthy", "size_mb": round(size_mb, 2)}
    except Exception as exc:
        return {"status": "unhealthy", "error": type(exc).__name__}


def check_disk() -> Dict[str, Any]:
    """Check available disk space."""
    try:
        import shutil
        usage = shutil.disk_usage(str(PATHS.BASE))
        free_gb = usage.free / (1024**3)
        percent_used = (usage.used / usage.total) * 100
        status = "healthy" if percent_used < 90 else ("degraded" if percent_used < 95 else "unhealthy")
        return {
            "status": status,
            "free_gb": round(free_gb, 2),
            "percent_used": round(percent_used, 1),
        }
    except Exception as exc:
        return {"status": "unhealthy", "error": type(exc).__name__}


def check_crypto() -> Dict[str, Any]:
    """Check if encryption key is available."""
    key_path = PATHS.DATA / ".vault_key"
    if key_path.exists():
        return {"status": "healthy"}
    return {"status": "degraded", "note": "No encryption key — PII encryption disabled"}


def check_cache() -> Dict[str, Any]:
    """Check diskcache state."""
    cache_path = PATHS.CACHE
    try:
        if cache_path.exists():
            size_mb = sum(
                f.stat().st_size for f in cache_path.rglob("*") if f.is_file()
            ) / (1024 * 1024)
            return {"status": "healthy", "size_mb": round(size_mb, 2)}
        return {"status": "healthy", "size_mb": 0}
    except Exception as exc:
        return {"status": "degraded", "error": type(exc).__name__}


def get_health_response() -> Dict[str, Any]:
    """
    Liveness probe: /health
    Returns overall health status with optional component details.
    """
    uptime = time.time() - _START_TIME
    checks = {}

    if HEALTH.INCLUDE_DETAILS:
        checks["database"] = check_database()
        checks["disk"] = check_disk()
        checks["crypto"] = check_crypto()
        checks["cache"] = check_cache()

        # Try watchdog
        try:
            from utils.watchdog import SystemWatchdog
            wd = SystemWatchdog()
            if wd.is_healthy():
                checks["watchdog"] = {"status": "healthy"}
            else:
                checks["watchdog"] = {"status": "degraded"}
        except Exception:
            checks["watchdog"] = {"status": "unknown"}

    # Overall status
    statuses = [c.get("status", "healthy") for c in checks.values()] if checks else ["healthy"]
    if "unhealthy" in statuses:
        overall = "unhealthy"
    elif "degraded" in statuses:
        overall = "degraded"
    else:
        overall = "healthy"

    return {
        "status": overall,
        "version": APP.VERSION,
        "version_tag": APP.VERSION_TAG,
        "brand": APP.BRAND,
        "uptime_seconds": round(uptime, 1),
        "timestamp": datetime.now().isoformat(),
        "checks": checks,
    }


def get_ready_response() -> Dict[str, Any]:
    """
    Readiness probe: /ready
    Returns whether the app is ready to serve requests.
    Checks database connectivity and essential paths.
    """
    ready = True
    details = {}

    # DB must be accessible
    db_check = check_database()
    details["database"] = db_check
    if db_check["status"] == "unhealthy":
        ready = False

    # Data vault must exist
    vault_exists = PATHS.DATA_VAULT.exists()
    details["data_vault"] = {"status": "healthy" if vault_exists else "unhealthy"}
    if not vault_exists:
        ready = False

    # Logs dir must be writable
    try:
        test_file = PATHS.LOGS / ".ready_check"
        test_file.write_text("ok")
        test_file.unlink()
        details["logs_writable"] = {"status": "healthy"}
    except Exception:
        details["logs_writable"] = {"status": "unhealthy"}
        ready = False

    return {
        "ready": ready,
        "status": "ready" if ready else "not_ready",
        "version": APP.VERSION,
        "timestamp": datetime.now().isoformat(),
        "details": details,
    }


def register_health_routes(flask_server):
    """
    Register /health and /ready Flask routes on the Dash server.

    Called from app.py after Dash app creation:
        register_health_routes(app.server)
    """
    import json

    @flask_server.route(HEALTH.HEALTH_PATH)
    def health_endpoint():
        from flask import Response
        data = get_health_response()
        status_code = 200 if data["status"] != "unhealthy" else 503
        return Response(
            json.dumps(data, indent=2),
            status=status_code,
            mimetype="application/json",
        )

    @flask_server.route(HEALTH.READY_PATH)
    def ready_endpoint():
        from flask import Response
        data = get_ready_response()
        status_code = 200 if data["ready"] else 503
        return Response(
            json.dumps(data, indent=2),
            status=status_code,
            mimetype="application/json",
        )

    _health_logger.info(f"[HEALTH] Registered {HEALTH.HEALTH_PATH} and {HEALTH.READY_PATH}")
