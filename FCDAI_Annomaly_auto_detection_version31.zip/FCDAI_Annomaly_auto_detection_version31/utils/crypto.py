"""
FCDAI V14 — Data Masking & Encryption Layer
=============================================
Fernet-based symmetric encryption for PII at rest.
Locally managed key stored in the vault directory.

V13 Fixes:
  - C-3: Key rotation age check at startup — warns if key > AUTO_ROTATE_DAYS

Architecture:
  1. Entity IDs → SHA-256 hash (irreversible, used as FK in anomalies table)
  2. PII fields → Fernet encrypt (reversible with key, stored encrypted at rest)
  3. Key management → Local file on air-gapped machine (no HSM, no cloud KMS)

Security Notes:
  - Key file must be protected via Windows ACL / NTFS permissions
  - For production: rotate key quarterly and re-encrypt the vault
  - The Fernet key is 256-bit, URL-safe base64 encoded
"""

import hashlib
import os
import sys
import time
import logging
from pathlib import Path
from typing import Optional, Union

sys.path.insert(0, str(Path(__file__).parent.parent))

# ---------------------------------------------------------------------------
# Fernet import (from cryptography library)
# ---------------------------------------------------------------------------
try:
    from cryptography.fernet import Fernet
    HAS_FERNET = True
except ImportError:
    import logging as _log
    _log.getLogger("apurbadas.crypto").critical(
        "FATAL: 'cryptography' package not installed. "
        "PII encryption is MANDATORY for bank deployment. "
        "Install via: pip install cryptography"
    )
    raise SystemExit(
        "FATAL: cryptography package required for bank-grade PII encryption. "
        "Run: pip install cryptography"
    )


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
from config import PATHS

_KEY_FILE = PATHS.DATA / ".vault_key"
_fernet_instance: Optional[object] = None
_crypto_logger = logging.getLogger("apurbadas.crypto")


# ---------------------------------------------------------------------------
# Key Management
# ---------------------------------------------------------------------------
def _load_or_generate_key() -> bytes:
    """
    Load the Fernet key from the local key file.
    If no key exists, generate one and persist it.
    Air-gapped: key never leaves the local filesystem.
    """
    if _KEY_FILE.exists():
        return _KEY_FILE.read_bytes().strip()
    # Generate fresh key
    key = Fernet.generate_key()
    _KEY_FILE.parent.mkdir(parents=True, exist_ok=True)
    _KEY_FILE.write_bytes(key)
    # F-14 FIX: Restrict file permissions — NTFS ACL on Windows, POSIX elsewhere
    try:
        os.chmod(str(_KEY_FILE), 0o600)
    except OSError:
        pass
    # Windows-specific: restrict via icacls (optional, best-effort)
    try:
        import platform
        if platform.system() == "Windows":
            import subprocess
            username = os.environ.get("USERNAME", os.environ.get("USER", "SYSTEM"))
            subprocess.run(
                ["icacls", str(_KEY_FILE), "/inheritance:r",
                 "/grant:r", f"{username}:(R,W)"],
                capture_output=True, check=False, timeout=5,
            )
    except Exception:
        pass  # icacls not available — non-fatal
    return key


def get_fernet() -> Optional[object]:
    """Return the singleton Fernet cipher. None if library missing."""
    global _fernet_instance
    if not HAS_FERNET:
        return None
    if _fernet_instance is None:
        key = _load_or_generate_key()
        _fernet_instance = Fernet(key)
        # V13 C-3: Key rotation age check
        _check_key_rotation_age()
    return _fernet_instance


def _check_key_rotation_age():
    """V13 C-3: Warn if Fernet key is older than AUTO_ROTATE_DAYS."""
    try:
        from config import CRYPTO
        if _KEY_FILE.exists():
            key_age_days = (time.time() - _KEY_FILE.stat().st_mtime) / 86400
            if key_age_days > CRYPTO.AUTO_ROTATE_DAYS:
                _crypto_logger.warning(
                    f"SECURITY: Fernet key is {key_age_days:.0f} days old "
                    f"(limit: {CRYPTO.AUTO_ROTATE_DAYS} days). "
                    "Rotate key and re-encrypt vault data."
                )
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Entity ID Hashing (irreversible)
# ---------------------------------------------------------------------------
# F-06 FIX: Salt derived from key file when available (not hardcoded in source)
_HASH_SALT_CACHE: Optional[bytes] = None


def _get_hash_salt() -> bytes:
    """Derive hash salt from Fernet key file if available, else fallback."""
    global _HASH_SALT_CACHE
    if _HASH_SALT_CACHE is not None:
        return _HASH_SALT_CACHE
    try:
        if _KEY_FILE.exists():
            key_bytes = _KEY_FILE.read_bytes().strip()
            _HASH_SALT_CACHE = hashlib.sha256(b"entity-salt:" + key_bytes).digest()
            return _HASH_SALT_CACHE
    except Exception:
        pass
    # Fallback for first run before key file exists
    _HASH_SALT_CACHE = b"aim-ai-vault-v10-entity-salt"
    return _HASH_SALT_CACHE


def hash_entity_id(entity_id: Union[str, int, float]) -> str:
    """
    Hash an entity identifier using SHA-256 + derived salt.
    Produces a deterministic, irreversible 64-char hex digest.
    Used as the stored FK in the anomalies table — original ID is NOT stored.
    """
    raw = str(entity_id).encode("utf-8")
    return hashlib.sha256(_get_hash_salt() + raw).hexdigest()


def hash_entity_id_short(entity_id: Union[str, int, float], length: int = 12) -> str:
    """Truncated hash for display purposes (e.g., AG Grid columns)."""
    return hash_entity_id(entity_id)[:length]


# ---------------------------------------------------------------------------
# PII Encryption (reversible with key)
# ---------------------------------------------------------------------------
def encrypt_value(plaintext: str) -> Optional[str]:
    """
    Encrypt a plaintext PII value using Fernet.
    Returns a base64-encoded ciphertext string.
    F-02 FIX: Fail-CLOSED — raises on failure when crypto IS available.
    If cryptography wheel is not installed, logs a warning and returns
    plaintext (graceful degradation for air-gapped deployments without wheel).
    """
    if not plaintext:
        return plaintext
    f = get_fernet()
    if f is None:
        # BANK COMPLIANCE: Never store PII unencrypted
        raise RuntimeError("Fernet engine unavailable — cannot store PII unencrypted")
    try:
        token = f.encrypt(plaintext.encode("utf-8"))
        return token.decode("utf-8")
    except Exception as e:
        # Fail-CLOSED: refuse to store plaintext when crypto IS available
        raise RuntimeError(f"Fernet encryption failed — refusing plaintext storage: {e}")


def decrypt_value(ciphertext: str) -> Optional[str]:
    """
    Decrypt a Fernet-encrypted value back to plaintext.
    Returns plaintext on success, or the ciphertext unchanged on failure.
    """
    f = get_fernet()
    if f is None or not ciphertext:
        return ciphertext
    try:
        plaintext = f.decrypt(ciphertext.encode("utf-8"))
        return plaintext.decode("utf-8")
    except Exception:
        return ciphertext  # May be unencrypted legacy data


# ---------------------------------------------------------------------------
# DataFrame-level PII Encryption
# ---------------------------------------------------------------------------
def encrypt_dataframe_pii(df, pii_columns: list) -> "pd.DataFrame":
    """
    Encrypt specified PII columns in a DataFrame in-place.
    Non-destructive: returns a copy with encrypted values.
    """
    import pandas as pd
    if not HAS_FERNET or not pii_columns:
        return df
    df_copy = df.copy()
    for col in pii_columns:
        if col in df_copy.columns:
            df_copy[col] = df_copy[col].astype(str).apply(encrypt_value)
    return df_copy


def decrypt_dataframe_pii(df, pii_columns: list) -> "pd.DataFrame":
    """
    Decrypt previously encrypted PII columns.
    Requires the same Fernet key that was used for encryption.
    """
    import pandas as pd
    if not HAS_FERNET or not pii_columns:
        return df
    df_copy = df.copy()
    for col in pii_columns:
        if col in df_copy.columns:
            df_copy[col] = df_copy[col].astype(str).apply(decrypt_value)
    return df_copy


# ---------------------------------------------------------------------------
# Hash entity_id column in DataFrame
# ---------------------------------------------------------------------------
def hash_entity_column(df, entity_col: str) -> "pd.DataFrame":
    """
    Replace entity_id column with SHA-256 hashes.
    Original values are irreversibly destroyed.
    """
    if entity_col not in df.columns:
        return df
    df_copy = df.copy()
    df_copy[entity_col] = df_copy[entity_col].astype(str).apply(hash_entity_id)
    return df_copy
