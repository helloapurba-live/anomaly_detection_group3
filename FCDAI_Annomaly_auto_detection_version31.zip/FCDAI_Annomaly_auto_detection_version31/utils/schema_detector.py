"""
Schema Detector - Auto Data Type Detection
==========================================
Automatically identifies column types and characteristics without manual configuration.

PRINCIPLE 3: AUTO-DETECTION OF DATA TYPES
- CONTINUOUS: Float, large range integers
- ORDINAL: Integer with small range (2-10 unique)
- BINARY: Only 2 unique values
- CATEGORICAL: String/Object with <20 unique values
- HIGH_CARDINALITY: String with >20 unique (excluded)
- ID_FIELD: Auto-detected and excluded
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from config import COLUMNS


class ColumnType(Enum):
    """Column type classifications."""
    CONTINUOUS = "continuous"
    ORDINAL = "ordinal"
    BINARY = "binary"
    CATEGORICAL = "categorical"
    HIGH_CARDINALITY = "high_cardinality"
    ID_FIELD = "id_field"
    DATETIME = "datetime"
    TEXT = "text"
    PII_TEXT = "pii_text"  # Personal information text fields
    UNKNOWN = "unknown"


@dataclass
class ColumnProfile:
    """Profile of a single column."""
    name: str
    dtype: str
    col_type: ColumnType
    unique_count: int
    null_count: int
    null_pct: float
    sample_values: List
    stats: Dict
    is_usable: bool  # Can be used in modeling


class SchemaDetector:
    """
    Automatically detect column types and characteristics.
    
    V8 RULES:
    - Mandatory-role columns (resolved via ColumnRoleConfig) always kept
    - ID fields are auto-detected and excluded
    - Data types inferred from content, not manual config
    """
    
    def __init__(
        self,
        categorical_threshold: int = 20,
        ordinal_max_unique: int = 10,
        id_keywords: List[str] = None,
        pii_keywords: List[str] = None
    ):
        """
        Initialize schema detector.
        
        Args:
            categorical_threshold: Max unique values for categorical
            ordinal_max_unique: Max unique values for ordinal
            id_keywords: Keywords that indicate ID fields
            pii_keywords: Keywords that indicate PII/text fields to exclude
        """
        self.categorical_threshold = categorical_threshold
        self.ordinal_max_unique = ordinal_max_unique
        self.id_keywords = id_keywords or [
            'id', '_id', 'code', '_code', 'key', '_key', 
            'ref', '_ref', 'number', '_number', 'uuid'
        ]
        self.pii_keywords = pii_keywords or [
            'name', 'desc', 'description', 'address', 'street', 
            'email', 'phone', 'ssn', 'passport', 'comment', 'notes'
        ]
        
    def detect_schema(self, df: pd.DataFrame) -> Dict[str, ColumnProfile]:
        """
        Detect schema for entire DataFrame.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Dictionary of column profiles
        """
        profiles = {}
        
        for col in df.columns:
            profiles[col] = self._profile_column(df, col)
            
        return profiles
    
    def _profile_column(self, df: pd.DataFrame, col: str) -> ColumnProfile:
        """Profile a single column."""
        series = df[col]
        
        # Basic stats
        unique_count = series.nunique(dropna=True)
        null_count = series.isnull().sum()
        null_pct = (null_count / len(series)) * 100 if len(series) > 0 else 100
        sample_values = series.dropna().head(5).tolist()
        
        # Detect type
        col_type = self._detect_column_type(series, col)
        
        # Compute stats based on type
        stats = self._compute_stats(series, col_type)
        
        # Determine if usable for modeling
        is_usable = self._is_usable(col, col_type, null_pct, unique_count, len(series))
        
        return ColumnProfile(
            name=col,
            dtype=str(series.dtype),
            col_type=col_type,
            unique_count=unique_count,
            null_count=null_count,
            null_pct=null_pct,
            sample_values=sample_values,
            stats=stats,
            is_usable=is_usable
        )
    
    def _detect_column_type(self, series: pd.Series, col_name: str) -> ColumnType:
        """
        Detect column type based on content.
        
        Priority:
        1. Check if ID field
        2. Check if datetime
        3. Check boolean
        4. Check numeric types
        5. Check categorical types
        """
        # V8: Resolve mandatory roles dynamically
        _mandatory_cols = set()
        for role in COLUMNS.MANDATORY_ROLES:
            for alias in COLUMNS.ROLE_ALIASES.get(role, []):
                _mandatory_cols.add(alias.lower())
        if col_name.lower() in _mandatory_cols:
            # Keep mandatory-role columns — classify by dtype hint
            dtype_hint = COLUMNS.ROLE_DTYPE_HINT.get(
                next((r for r in COLUMNS.MANDATORY_ROLES
                      if col_name.lower() in [a.lower() for a in COLUMNS.ROLE_ALIASES.get(r, [])]), ""),
                "id"
            )
            if dtype_hint == "text":
                return ColumnType.CATEGORICAL
            return ColumnType.ID_FIELD
        
        # Check if ID field (before other checks)
        if self._is_id_field(col_name, series):
            return ColumnType.ID_FIELD
        
        # Check datetime
        if pd.api.types.is_datetime64_any_dtype(series):
            return ColumnType.DATETIME
        
        # Check boolean (convert to binary)
        if pd.api.types.is_bool_dtype(series):
            return ColumnType.BINARY
        
        # Numeric types
        if pd.api.types.is_numeric_dtype(series):
            return self._classify_numeric(series, col_name)
        
        # String/Object types
        if pd.api.types.is_string_dtype(series) or pd.api.types.is_object_dtype(series):
            return self._classify_categorical(series, col_name)
        
        return ColumnType.UNKNOWN
    
    def _is_id_field(self, col_name: str, series: pd.Series) -> bool:
        """Check if column is an ID field."""
        col_lower = col_name.lower()
        
        # Check name patterns
        for keyword in self.id_keywords:
            if keyword in col_lower:
                # Additional validation: high uniqueness ratio
                uniqueness = series.nunique() / len(series) if len(series) > 0 else 0
                if uniqueness > 0.95:  # 95%+ unique values
                    return True
        
        return False
    
    def _classify_numeric(self, series: pd.Series, col_name: str = "") -> ColumnType:
        """Classify numeric column with enhanced detection."""
        series_clean = series.dropna()
        
        if len(series_clean) == 0:
            return ColumnType.UNKNOWN
        
        unique_count = series_clean.nunique()
        unique_ratio = unique_count / len(series_clean) if len(series_clean) > 0 else 0
        
        # Binary: exactly 2 unique values
        if unique_count == 2:
            return ColumnType.BINARY
        
        # ID Field: Check if column name suggests ID or uniqueness is very high
        col_lower = col_name.lower()
        if any(kw in col_lower for kw in ['_id', '_key']) or unique_ratio > 0.9:
            return ColumnType.ID_FIELD
        
        # Ordinal: small number of unique integers
        if unique_count <= self.ordinal_max_unique:
            # Check if mostly integers
            if pd.api.types.is_integer_dtype(series):
                return ColumnType.ORDINAL
            # Check if values are close to integers
            int_check = (series_clean == series_clean.astype(int)).mean()
            if int_check > 0.95:
                return ColumnType.ORDINAL
        
        # Continuous: everything else
        return ColumnType.CONTINUOUS
    
    def _classify_categorical(self, series: pd.Series, col_name: str = "") -> ColumnType:
        """Classify string/object column with PII detection."""
        series_clean = series.dropna()
        
        if len(series_clean) == 0:
            return ColumnType.UNKNOWN
        
        unique_count = series_clean.nunique()
        col_lower = col_name.lower()
        
        # PII Text: Check column name for PII indicators
        if any(kw in col_lower for kw in self.pii_keywords):
            return ColumnType.PII_TEXT
        
        # Binary: exactly 2 unique values
        if unique_count == 2:
            return ColumnType.BINARY
        
        # Categorical: reasonable number of categories
        if unique_count <= self.categorical_threshold:
            return ColumnType.CATEGORICAL
        
        # High cardinality: too many unique values
        if unique_count > self.categorical_threshold:
            # Check if it's free text
            avg_length = series_clean.astype(str).str.len().mean()
            if avg_length > 50:  # Long text
                return ColumnType.TEXT
            return ColumnType.HIGH_CARDINALITY
        
        return ColumnType.UNKNOWN
    
    def _compute_stats(self, series: pd.Series, col_type: ColumnType) -> Dict:
        """Compute statistics based on column type."""
        stats = {}
        
        if col_type == ColumnType.CONTINUOUS:
            series_clean = series.dropna()
            if len(series_clean) > 0:
                # Add skewness for auto-transform decision
                from scipy.stats import skew
                stats = {
                    'mean': float(series_clean.mean()),
                    'median': float(series_clean.median()),
                    'std': float(series_clean.std()),
                    'min': float(series_clean.min()),
                    'max': float(series_clean.max()),
                    'q25': float(series_clean.quantile(0.25)),
                    'q75': float(series_clean.quantile(0.75)),
                    'skew': float(skew(series_clean, nan_policy='omit'))
                }
        
        elif col_type in [ColumnType.BINARY, ColumnType.CATEGORICAL, ColumnType.ORDINAL]:
            value_counts = series.value_counts()
            stats = {
                'unique_values': value_counts.index.tolist()[:10],
                'value_counts': value_counts.values.tolist()[:10],
                'mode': series.mode().iloc[0] if len(series.mode()) > 0 else None,
            }
        
        return stats
    
    def _is_usable(
        self, 
        col_name: str, 
        col_type: ColumnType, 
        null_pct: float,
        unique_count: int,
        total_rows: int
    ) -> bool:
        """
        Determine if column is usable for modeling.
        
        Rules:
        - cust_id: always keep (mandatory)
        - cust_name: always keep (mandatory)
        - ID fields: exclude (except cust_id)
        - High cardinality: exclude
        - Text fields: exclude
        - Too many nulls (>80%): exclude
        - No variance (1 unique value): exclude
        """
        # V8: Always keep mandatory-role columns
        _mandatory_cols = set()
        for role in COLUMNS.MANDATORY_ROLES:
            for alias in COLUMNS.ROLE_ALIASES.get(role, []):
                _mandatory_cols.add(alias.lower())
        if col_name.lower() in _mandatory_cols:
            return True
        
        # Exclude by type
        if col_type in [ColumnType.ID_FIELD, ColumnType.HIGH_CARDINALITY, ColumnType.TEXT, ColumnType.PII_TEXT, ColumnType.UNKNOWN]:
            return False
        
        # Exclude if too many nulls
        if null_pct > 80:
            return False
        
        # Exclude if no variance
        if unique_count <= 1:
            return False
        
        return True
    
    def get_usable_columns(self, profiles: Dict[str, ColumnProfile]) -> List[str]:
        """Get list of columns that can be used for modeling."""
        return [name for name, profile in profiles.items() if profile.is_usable]
    
    def get_columns_by_type(
        self, 
        profiles: Dict[str, ColumnProfile], 
        col_type: ColumnType
    ) -> List[str]:
        """Get columns of a specific type."""
        return [name for name, profile in profiles.items() if profile.col_type == col_type]
    
    def generate_report(self, profiles: Dict[str, ColumnProfile]) -> str:
        """Generate human-readable schema report."""
        lines = []
        lines.append("=" * 80)
        lines.append("SCHEMA DETECTION REPORT")
        lines.append("=" * 80)
        lines.append(f"Total Columns: {len(profiles)}")
        
        # Count by type
        type_counts = {}
        for profile in profiles.values():
            type_counts[profile.col_type] = type_counts.get(profile.col_type, 0) + 1
        
        lines.append("\nColumn Types:")
        for col_type, count in sorted(type_counts.items(), key=lambda x: -x[1]):
            lines.append(f"  {col_type.value:20s}: {count:3d}")
        
        # Usable columns
        usable = self.get_usable_columns(profiles)
        lines.append(f"\nUsable for Modeling: {len(usable)} / {len(profiles)}")
        
        # Detail for each column
        lines.append("\n" + "=" * 80)
        lines.append("COLUMN DETAILS")
        lines.append("=" * 80)
        
        for name, profile in sorted(profiles.items()):
            lines.append(f"\n{name}")
            lines.append(f"  Type: {profile.col_type.value}")
            lines.append(f"  Dtype: {profile.dtype}")
            lines.append(f"  Unique: {profile.unique_count}")
            lines.append(f"  Nulls: {profile.null_count} ({profile.null_pct:.1f}%)")
            lines.append(f"  Usable: {'✓' if profile.is_usable else '✗'}")
            if profile.sample_values:
                lines.append(f"  Sample: {profile.sample_values[:3]}")
        
        return "\n".join(lines)
