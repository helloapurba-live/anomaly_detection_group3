"""
AIM AI Vault V14 — Data Contracts & Validation
================================================
Dataclass-based contracts for pipeline inputs, outputs, and
inter-layer data exchange. Enforces type safety and bounds
without requiring Pydantic (zero external dependency).

Author: AIM AI Vault Team
"""

import sys
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Any
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent.parent))


# =============================================================================
# VALIDATION HELPERS
# =============================================================================
class ContractViolation(Exception):
    """Raised when a data contract validation fails."""
    def __init__(self, contract: str, field_name: str, reason: str):
        self.contract = contract
        self.field_name = field_name
        self.reason = reason
        super().__init__(f"[{contract}] {field_name}: {reason}")


def _validate_range(value, min_val, max_val, name: str, contract: str):
    """Validate a numeric value is within [min_val, max_val]."""
    if value is not None and not (min_val <= value <= max_val):
        raise ContractViolation(contract, name, f"must be in [{min_val}, {max_val}], got {value}")


def _validate_non_empty(value, name: str, contract: str):
    """Validate a string/list is non-empty."""
    if not value:
        raise ContractViolation(contract, name, "must be non-empty")


# =============================================================================
# PIPELINE RESULT CONTRACT
# =============================================================================
@dataclass
class PipelineResultContract:
    """
    Validated contract for pipeline execution results.
    All fields are bounds-checked to prevent invalid data
    from propagating to the UI or database.
    """
    success: bool
    timestamp: str
    records_processed: int
    dq_score: float
    features_generated: int
    methods_run: int
    alerts_generated: int
    tier_distribution: Dict[str, int]
    execution_time_ms: float
    layer_timings: Dict[str, float] = field(default_factory=dict)
    error: Optional[str] = None
    run_id: Optional[str] = None
    input_hash: Optional[str] = None
    failed_methods: List[str] = field(default_factory=list)
    profiling_path: Optional[str] = None

    def validate(self):
        """Validate all fields against business rules."""
        _validate_range(self.dq_score, 0.0, 1.0, "dq_score", "PipelineResult")
        _validate_range(self.records_processed, 0, 10_000_000, "records_processed", "PipelineResult")
        _validate_range(self.methods_run, 0, 50, "methods_run", "PipelineResult")
        _validate_range(self.alerts_generated, 0, 10_000_000, "alerts_generated", "PipelineResult")
        _validate_range(self.execution_time_ms, 0, 86_400_000, "execution_time_ms", "PipelineResult")
        if self.tier_distribution:
            valid_tiers = {"CRITICAL", "HIGH", "MEDIUM", "LOW", "NORMAL"}
            for tier in self.tier_distribution:
                if tier not in valid_tiers:
                    raise ContractViolation("PipelineResult", "tier_distribution",
                                            f"unknown tier '{tier}'")
        return self

    def to_dict(self) -> Dict:
        return asdict(self)


# =============================================================================
# SCORED ROW CONTRACT
# =============================================================================
@dataclass
class ScoredRowContract:
    """Contract for a single scored anomaly row."""
    row_index: int
    entity_id: str
    anomaly_score: float
    risk_tier: str
    method_scores: Dict[str, float]

    def validate(self):
        _validate_range(self.anomaly_score, 0.0, 1.0, "anomaly_score", "ScoredRow")
        valid_tiers = {"CRITICAL", "HIGH", "MEDIUM", "LOW", "NORMAL"}
        if self.risk_tier not in valid_tiers:
            raise ContractViolation("ScoredRow", "risk_tier",
                                    f"must be one of {valid_tiers}, got '{self.risk_tier}'")
        for method, score in self.method_scores.items():
            _validate_range(score, 0.0, 1.0, f"method_scores[{method}]", "ScoredRow")
        return self


# =============================================================================
# AUDIT ENTRY CONTRACT
# =============================================================================
@dataclass
class AuditEntryContract:
    """Contract for audit log entries (hash-chain compatible)."""
    action: str
    user: str
    status: str = "SUCCESS"
    details: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def validate(self):
        _validate_non_empty(self.action, "action", "AuditEntry")
        _validate_non_empty(self.user, "user", "AuditEntry")
        valid_statuses = {"SUCCESS", "FAILURE", "WARNING", "INFO"}
        if self.status not in valid_statuses:
            raise ContractViolation("AuditEntry", "status",
                                    f"must be one of {valid_statuses}")
        if self.details and len(self.details) > 5000:
            raise ContractViolation("AuditEntry", "details", "exceeds 5000 char limit")
        return self


# =============================================================================
# HEALTH CHECK CONTRACT
# =============================================================================
@dataclass
class HealthCheckContract:
    """Contract for health check responses."""
    status: str              # "healthy" | "degraded" | "unhealthy"
    version: str
    uptime_seconds: float
    timestamp: str
    checks: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    def validate(self):
        valid_statuses = {"healthy", "degraded", "unhealthy"}
        if self.status not in valid_statuses:
            raise ContractViolation("HealthCheck", "status",
                                    f"must be one of {valid_statuses}")
        _validate_range(self.uptime_seconds, 0, 365 * 86400, "uptime_seconds", "HealthCheck")
        return self

    def to_dict(self) -> Dict:
        return asdict(self)


# =============================================================================
# SYSTEM METRICS CONTRACT
# =============================================================================
@dataclass
class SystemMetricsContract:
    """Contract for watchdog system metrics snapshot."""
    timestamp: str
    cpu_percent: float
    memory_percent: float
    memory_used_mb: float
    memory_available_mb: float
    disk_percent: float
    disk_free_gb: float
    db_size_mb: float
    cache_size_mb: float
    active_sessions: int = 0
    pipeline_running: bool = False

    def validate(self):
        _validate_range(self.cpu_percent, 0, 100, "cpu_percent", "SystemMetrics")
        _validate_range(self.memory_percent, 0, 100, "memory_percent", "SystemMetrics")
        _validate_range(self.disk_percent, 0, 100, "disk_percent", "SystemMetrics")
        return self

    def to_dict(self) -> Dict:
        return asdict(self)


# =============================================================================
# DATA IMPORT CONTRACT
# =============================================================================
@dataclass
class DataImportContract:
    """Contract for data import operations."""
    source_name: str
    file_name: str
    file_size_bytes: int
    row_count: int
    column_count: int
    import_timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    hash_digest: Optional[str] = None

    def validate(self):
        _validate_non_empty(self.source_name, "source_name", "DataImport")
        _validate_non_empty(self.file_name, "file_name", "DataImport")
        _validate_range(self.file_size_bytes, 0, 10 * 1024**3, "file_size_bytes", "DataImport")
        _validate_range(self.row_count, 0, 100_000_000, "row_count", "DataImport")
        _validate_range(self.column_count, 0, 10_000, "column_count", "DataImport")
        return self
