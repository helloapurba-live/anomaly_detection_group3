"""
Auto-Generate METHOD_CONFIG
============================
STEP 9 from pipeline: Generate detection method configuration based on data characteristics.

Logic:
- Always enable: Statistical, Distance, Density, Clustering, Tree methods (50+ samples, 3+ features)
- Deep Learning: Requires 100+ samples, 10+ features
- Time-Series: Only if temporal data available
- Graph-Based: Only if network data available
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass


@dataclass
class MethodConfig:
    """Configuration for a single detection method."""
    name: str
    weight: float
    enabled: bool
    params: Dict[str, Any]
    reason: str


class MethodConfigGenerator:
    """
    Auto-generate METHOD_CONFIG based on data characteristics.
    
    PRINCIPLE: Method selection should be data-driven
    - Sample size determines method feasibility
    - Feature count determines dimensionality approaches
    - Data structure determines specialized methods
    """
    
    def __init__(self):
        self.config: List[MethodConfig] = []
        self.data_profile: Dict = {}
    
    def generate(
        self,
        n_samples: int,
        n_features: int,
        has_temporal: bool = False,
        has_graph: bool = False,
        feature_names: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """
        Generate METHOD_CONFIG based on data characteristics.
        
        Args:
            n_samples: Number of customer records
            n_features: Number of features
            has_temporal: Whether time-series data is available
            has_graph: Whether network/graph data is available
            feature_names: Optional list of feature names
            
        Returns:
            List of method configurations
        """
        self.data_profile = {
            'n_samples': n_samples,
            'n_features': n_features,
            'has_temporal': has_temporal,
            'has_graph': has_graph
        }
        
        self.config = []
        
        # Check minimum requirements
        if n_samples < 50 or n_features < 3:
            print(f"[WARN] Insufficient data for detection: {n_samples} samples, {n_features} features")
            print(f"[WARN] Minimum: 50 samples, 3 features")
            return []
        
        # ALWAYS ENABLE: Statistical methods
        self._add_statistical_methods()
        
        # ALWAYS ENABLE: Distance-based methods
        self._add_distance_methods(n_samples)
        
        # ALWAYS ENABLE: Density-based methods
        self._add_density_methods(n_samples)
        
        # ALWAYS ENABLE: Clustering methods
        self._add_clustering_methods(n_samples)
        
        # ALWAYS ENABLE: Tree-based methods
        self._add_tree_methods()
        
        # CONDITIONAL: Deep Learning (requires 100+ samples, 10+ features)
        if n_samples >= 100 and n_features >= 10:
            self._add_deep_learning_methods()
        
        # CONDITIONAL: Time-Series (only if data available)
        if has_temporal:
            self._add_time_series_methods()
        
        # CONDITIONAL: Graph-Based (only if data available)
        if has_graph:
            self._add_graph_methods()
        
        # Convert to dict format
        config_dicts = [
            {
                'name': m.name,
                'weight': m.weight,
                'enabled': m.enabled,
                'params': m.params
            }
            for m in self.config
        ]
        
        print(f"[INFO] Auto-generated METHOD_CONFIG with {len(config_dicts)} methods")
        print(f"[INFO] Data: {n_samples} samples, {n_features} features")
        
        return config_dicts
    
    def _add_statistical_methods(self):
        """Add univariate statistical methods."""
        methods = [
            ('Z-Score', 1.0, {}),
            ('IQR', 1.0, {}),
            ('Grubbs', 1.0, {}),
            ('Dixon', 1.0, {}),
            ('ESD', 1.0, {'alpha': 0.05}),
        ]
        
        for name, weight, params in methods:
            self.config.append(MethodConfig(
                name=name,
                weight=weight,
                enabled=True,
                params=params,
                reason="Always enabled (minimum requirements met)"
            ))
    
    def _add_distance_methods(self, n_samples: int):
        """Add distance-based methods."""
        k_neighbors = min(5, n_samples // 10)
        
        methods = [
            ('KNN', 1.0, {'n_neighbors': k_neighbors}),
            ('Mahalanobis', 1.0, {}),
        ]
        
        for name, weight, params in methods:
            self.config.append(MethodConfig(
                name=name,
                weight=weight,
                enabled=True,
                params=params,
                reason="Always enabled (minimum requirements met)"
            ))
    
    def _add_density_methods(self, n_samples: int):
        """Add density-based methods."""
        n_neighbors = min(20, n_samples // 10)
        
        methods = [
            ('LOF', 1.2, {'n_neighbors': n_neighbors}),
            ('DBSCAN', 1.0, {'eps': 0.5, 'min_samples': 5}),
            ('OPTICS', 1.0, {}),
            ('HDBSCAN', 1.0, {}),
            ('CBLOF', 1.0, {}),
        ]
        
        for name, weight, params in methods:
            self.config.append(MethodConfig(
                name=name,
                weight=weight,
                enabled=True,
                params=params,
                reason="Always enabled (minimum requirements met)"
            ))
    
    def _add_clustering_methods(self, n_samples: int):
        """Add clustering-based methods."""
        n_clusters = min(10, max(2, n_samples // 100))
        
        methods = [
            ('K-Means', 1.0, {'n_clusters': n_clusters}),
            ('GMM', 1.0, {'n_components': n_clusters}),
            ('Spectral', 1.0, {'n_clusters': n_clusters}),
        ]
        
        for name, weight, params in methods:
            self.config.append(MethodConfig(
                name=name,
                weight=weight,
                enabled=True,
                params=params,
                reason="Always enabled (minimum requirements met)"
            ))
    
    def _add_tree_methods(self):
        """Add tree-based ensemble methods."""
        methods = [
            ('Isolation Forest', 1.5, {'contamination': 0.1, 'n_estimators': 100}),
            ('Extended IF', 1.5, {'contamination': 0.1}),
        ]
        
        for name, weight, params in methods:
            self.config.append(MethodConfig(
                name=name,
                weight=weight,
                enabled=True,
                params=params,
                reason="Always enabled (minimum requirements met)"
            ))
    
    def _add_deep_learning_methods(self):
        """Add deep learning methods (requires 100+ samples, 10+ features)."""
        methods = [
            ('Autoencoder', 1.0, {'architecture': 'auto', 'epochs': 50}),
            ('VAE', 1.0, {'latent_dim': 8, 'epochs': 50}),
        ]
        
        for name, weight, params in methods:
            self.config.append(MethodConfig(
                name=name,
                weight=weight,
                enabled=True,
                params=params,
                reason=f"Enabled: {self.data_profile['n_samples']} samples >= 100, {self.data_profile['n_features']} features >= 10"
            ))
    
    def _add_time_series_methods(self):
        """Add time-series methods (only if temporal data available)."""
        methods = [
            ('STL', 1.0, {}),
            ('ARIMA', 1.0, {}),
            ('Prophet', 1.0, {}),
        ]
        
        for name, weight, params in methods:
            self.config.append(MethodConfig(
                name=name,
                weight=weight,
                enabled=True,
                params=params,
                reason="Enabled: Temporal data available"
            ))
    
    def _add_graph_methods(self):
        """Add graph-based methods (only if network data available)."""
        methods = [
            ('PageRank', 1.0, {}),
            ('HITS', 1.0, {}),
            ('Community', 1.0, {}),
            ('Centrality', 1.0, {}),
        ]
        
        for name, weight, params in methods:
            self.config.append(MethodConfig(
                name=name,
                weight=weight,
                enabled=True,
                params=params,
                reason="Enabled: Graph/network data available"
            ))
    
    def get_generation_report(self) -> str:
        """Generate human-readable report of method selection."""
        lines = []
        lines.append("=" * 80)
        lines.append("METHOD CONFIG AUTO-GENERATION REPORT")
        lines.append("=" * 80)
        lines.append("")
        lines.append("DATA PROFILE:")
        lines.append(f"  Samples: {self.data_profile['n_samples']}")
        lines.append(f"  Features: {self.data_profile['n_features']}")
        lines.append(f"  Has Temporal: {self.data_profile['has_temporal']}")
        lines.append(f"  Has Graph: {self.data_profile['has_graph']}")
        lines.append("")
        lines.append(f"METHODS ENABLED: {len(self.config)}")
        lines.append("")
        
        # Group by category
        categories = {
            'Statistical': ['Z-Score', 'IQR', 'Grubbs', 'Dixon', 'ESD'],
            'Distance': ['KNN', 'Mahalanobis'],
            'Density': ['LOF', 'DBSCAN', 'OPTICS', 'HDBSCAN', 'CBLOF'],
            'Clustering': ['K-Means', 'GMM', 'Spectral'],
            'Tree-Based': ['Isolation Forest', 'Extended IF'],
            'Deep Learning': ['Autoencoder', 'VAE'],
            'Time-Series': ['STL', 'ARIMA', 'Prophet'],
            'Graph-Based': ['PageRank', 'HITS', 'Community', 'Centrality']
        }
        
        for category, method_names in categories.items():
            category_methods = [m for m in self.config if m.name in method_names]
            if category_methods:
                lines.append(f"{category}: {len(category_methods)} methods")
                for method in category_methods:
                    lines.append(f"  • {method.name} (weight={method.weight})")
        
        return "\n".join(lines)
