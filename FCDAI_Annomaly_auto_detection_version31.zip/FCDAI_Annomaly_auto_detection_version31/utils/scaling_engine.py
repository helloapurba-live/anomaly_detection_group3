"""
Module 4: 6-Way Scaling Engine
================================
Takes the EncodedMaster (N × K, 100% float64) and produces 6 parallel
scaled versions, one per scaler family. Each algorithm later picks its
mandatory scaler via the Algorithm Routing Matrix (Module 6).

6 Scalers
─────────
  #1  StandardScaler     → mean=0, σ=1       → LOF, kNN, HDBSCAN, BIRCH, HBOS
  #2  MinMaxScaler       → [0, 1]            → VAE, AE
  #3  RobustScaler       → median-centred    → IQR, Modified Z-Score
  #4  MaxAbsScaler       → [-1, 1]           → UMAP sparse
  #5  PowerTransformer   → Gaussianise       → GMM, Mahalanobis
  #6  Original (None)    → passthrough       → Extended IF, Benford, ECOD, COPOD

Output:
  - Dict[str, np.ndarray]  → 6 scaled matrices keyed by scaler name
  - Dict[str, object]      → fitted scaler objects for inverse transform

Author: AIM AI Vault V23 — 5-Module Pipeline
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
import logging
import pickle
import io

logger = logging.getLogger("apurbadas.scaling_engine")


# ─────────────────────────────────────────────────────────────────────────────
# SCALER NAMES (canonical)
# ─────────────────────────────────────────────────────────────────────────────
SCALER_STANDARD  = "StandardScaler"
SCALER_MINMAX    = "MinMaxScaler"
SCALER_ROBUST    = "RobustScaler"
SCALER_MAXABS    = "MaxAbsScaler"
SCALER_POWER     = "PowerTransformer"
SCALER_ORIGINAL  = "Original"

ALL_SCALERS = [
    SCALER_STANDARD, SCALER_MINMAX, SCALER_ROBUST,
    SCALER_MAXABS, SCALER_POWER, SCALER_ORIGINAL,
]


# ─────────────────────────────────────────────────────────────────────────────
# RESULT DATACLASS
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class ScalingResult:
    """Complete result from Module 4: 6-Way Scaling."""
    # Scaled matrices: key = scaler name, value = numpy array (N × K)
    scaled_matrices: Dict[str, np.ndarray] = field(default_factory=dict)

    # Fitted scaler objects (for inverse_transform or explainability)
    scaler_objects: Dict[str, Any] = field(default_factory=dict)

    # Column names preserved
    feature_names: List[str] = field(default_factory=list)

    # Per-scaler statistics
    scaler_stats: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    # Shape
    input_shape: Tuple[int, int] = (0, 0)
    step_log: List[Dict[str, Any]] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def get_scaled_df(self, scaler_name: str) -> Optional[pd.DataFrame]:
        """Return scaled matrix as DataFrame with feature names."""
        if scaler_name in self.scaled_matrices:
            return pd.DataFrame(self.scaled_matrices[scaler_name],
                                columns=self.feature_names)
        return None


# ─────────────────────────────────────────────────────────────────────────────
# MAIN ENGINE
# ─────────────────────────────────────────────────────────────────────────────
class ScalingEngine:
    """
    Applies all 6 scalers in parallel to the EncodedMaster matrix.
    Each scaler produces a separate N × K numpy array.
    """

    def __init__(self, scalers_to_run: List[str] = None):
        """
        Args:
            scalers_to_run: list of scaler names to compute. Default: all 6.
        """
        self.scalers_to_run = scalers_to_run or ALL_SCALERS

    def scale(self, encoded_master: pd.DataFrame) -> ScalingResult:
        """Apply all requested scalers to the EncodedMaster.
        
        V27: Binary/one-hot columns (only 0/1 values) are excluded from
        scaling and passed through unchanged. Scaling 0/1 columns with
        StandardScaler distorts distance-based algorithms.
        """
        from sklearn.preprocessing import (
            StandardScaler, MinMaxScaler, RobustScaler,
            MaxAbsScaler, PowerTransformer
        )

        result = ScalingResult(
            feature_names=list(encoded_master.columns),
            input_shape=encoded_master.shape,
        )

        # V24 FIX: Guard against empty input
        if encoded_master.empty or encoded_master.shape[0] == 0 or encoded_master.shape[1] == 0:
            logger.warning("ScalingEngine: empty input DataFrame, skipping all scalers")
            result.step_log.append({"step": "GUARD", "warning": "empty input, no scalers run"})
            return result

        X = encoded_master.values.astype(np.float64)

        # Replace any inf/-inf with 0
        X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)

        # ── V27: Detect binary/one-hot columns (only contain 0 and 1) ──
        binary_mask = np.array([
            set(np.unique(X[:, j])).issubset({0.0, 1.0})
            for j in range(X.shape[1])
        ])
        continuous_mask = ~binary_mask
        n_binary = int(binary_mask.sum())
        n_continuous = int(continuous_mask.sum())
        if n_binary > 0:
            logger.info(f"V27: {n_binary} binary columns detected — excluded from scaling, {n_continuous} continuous columns will be scaled")
            result.step_log.append({
                "step": "V27_BINARY_DETECT",
                "binary_cols": n_binary,
                "continuous_cols": n_continuous,
                "binary_col_names": [encoded_master.columns[j] for j in range(X.shape[1]) if binary_mask[j]][:20],
            })

        for scaler_name in self.scalers_to_run:
            try:
                if scaler_name == SCALER_STANDARD:
                    scaler = StandardScaler()
                    # V27: Only scale continuous columns
                    if n_continuous > 0 and n_binary > 0:
                        X_scaled = X.copy()
                        X_scaled[:, continuous_mask] = scaler.fit_transform(X[:, continuous_mask])
                    else:
                        X_scaled = scaler.fit_transform(X)
                    result.scaler_objects[scaler_name] = scaler
                    result.scaler_stats[scaler_name] = {
                        "mean_range": [float(scaler.mean_.min()), float(scaler.mean_.max())],
                        "std_range": [float(scaler.scale_.min()), float(scaler.scale_.max())],
                        "binary_cols_passthrough": n_binary,
                    }

                elif scaler_name == SCALER_MINMAX:
                    scaler = MinMaxScaler(feature_range=(0, 1))
                    if n_continuous > 0 and n_binary > 0:
                        X_scaled = X.copy()
                        X_scaled[:, continuous_mask] = scaler.fit_transform(X[:, continuous_mask])
                    else:
                        X_scaled = scaler.fit_transform(X)
                    result.scaler_objects[scaler_name] = scaler
                    result.scaler_stats[scaler_name] = {
                        "data_min": [float(scaler.data_min_.min()), float(scaler.data_min_.max())],
                        "data_max": [float(scaler.data_max_.min()), float(scaler.data_max_.max())],
                        "binary_cols_passthrough": n_binary,
                    }

                elif scaler_name == SCALER_ROBUST:
                    scaler = RobustScaler(quantile_range=(25.0, 75.0))
                    if n_continuous > 0 and n_binary > 0:
                        X_scaled = X.copy()
                        X_scaled[:, continuous_mask] = scaler.fit_transform(X[:, continuous_mask])
                    else:
                        X_scaled = scaler.fit_transform(X)
                    result.scaler_objects[scaler_name] = scaler
                    result.scaler_stats[scaler_name] = {
                        "center_range": [float(scaler.center_.min()), float(scaler.center_.max())],
                        "scale_range": [float(scaler.scale_.min()), float(scaler.scale_.max())],
                        "binary_cols_passthrough": n_binary,
                    }

                elif scaler_name == SCALER_MAXABS:
                    scaler = MaxAbsScaler()
                    if n_continuous > 0 and n_binary > 0:
                        X_scaled = X.copy()
                        X_scaled[:, continuous_mask] = scaler.fit_transform(X[:, continuous_mask])
                    else:
                        X_scaled = scaler.fit_transform(X)
                    result.scaler_objects[scaler_name] = scaler
                    result.scaler_stats[scaler_name] = {
                        "max_abs_range": [float(scaler.max_abs_.min()), float(scaler.max_abs_.max())],
                        "binary_cols_passthrough": n_binary,
                    }

                elif scaler_name == SCALER_POWER:
                    # V24 FIX: Pre-filter constant columns to prevent ValueError
                    # V27: Also exclude binary columns from power transform
                    scalable_mask = continuous_mask & (X.std(axis=0) > 1e-10)
                    non_const_mask = scalable_mask if n_binary > 0 else (X.std(axis=0) > 1e-10)
                    if non_const_mask.sum() == 0:
                        X_scaled = X.copy()
                        result.scaler_objects[scaler_name] = None
                        result.scaler_stats[scaler_name] = {
                            "warning": "all columns constant, passthrough",
                            "method": "yeo-johnson",
                        }
                    else:
                        scaler = PowerTransformer(method="yeo-johnson", standardize=True)
                        X_temp = scaler.fit_transform(X[:, non_const_mask])
                        X_scaled = X.copy()
                        X_scaled[:, non_const_mask] = X_temp
                        result.scaler_objects[scaler_name] = scaler
                        result.scaler_stats[scaler_name] = {
                            "lambdas": [float(l) for l in scaler.lambdas_[:5]],
                            "method": "yeo-johnson",
                            "const_cols_skipped": int((~non_const_mask).sum()),
                        }

                elif scaler_name == SCALER_ORIGINAL:
                    X_scaled = X.copy()
                    result.scaler_objects[scaler_name] = None
                    result.scaler_stats[scaler_name] = {
                        "action": "passthrough (no scaling)",
                    }

                else:
                    logger.warning(f"Unknown scaler: {scaler_name}")
                    continue

                # Sanitise output (replace any NaN/inf from transform)
                X_scaled = np.nan_to_num(X_scaled, nan=0.0, posinf=0.0, neginf=0.0)
                result.scaled_matrices[scaler_name] = X_scaled

                result.step_log.append({
                    "scaler": scaler_name,
                    "shape": X_scaled.shape,
                    "min": float(X_scaled.min()),
                    "max": float(X_scaled.max()),
                    "mean": float(X_scaled.mean()),
                    "status": "OK",
                })
                logger.info(f"Scaler {scaler_name}: shape={X_scaled.shape}, "
                            f"range=[{X_scaled.min():.4f}, {X_scaled.max():.4f}]")

            except Exception as e:
                logger.error(f"Scaler {scaler_name} failed: {e}")
                result.step_log.append({
                    "scaler": scaler_name,
                    "status": "FAILED",
                    "error": str(e),
                })

        logger.info(f"Scaling complete: {len(result.scaled_matrices)}/{len(self.scalers_to_run)} scalers OK")
        return result

    @staticmethod
    def serialize_scalers(result: ScalingResult) -> bytes:
        """Serialize all fitted scaler objects to bytes (for DataVault storage)."""
        buf = io.BytesIO()
        pickle.dump(result.scaler_objects, buf)
        return buf.getvalue()

    @staticmethod
    def deserialize_scalers(data: bytes) -> Dict[str, Any]:
        """Deserialize scaler objects from bytes."""
        buf = io.BytesIO(data)
        return pickle.load(buf)
