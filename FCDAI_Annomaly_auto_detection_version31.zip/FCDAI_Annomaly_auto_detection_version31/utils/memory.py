"""
V15 Memory Optimization Utilities
===================================
Provides float32 downcasting and garbage collection helpers
to reduce memory footprint by ~50% on numeric DataFrames.

Bank Privacy: No telemetry, no external calls.
"""

import gc
import numpy as np
import pandas as pd
from typing import Optional


def downcast_floats(df: pd.DataFrame) -> pd.DataFrame:
    """
    Downcast all float64 columns to float32 in-place.
    
    Saves ~50% memory on numeric-heavy DataFrames.
    float32 provides 7 significant digits — sufficient for
    anomaly scoring, risk metrics, and statistical features.
    
    Args:
        df: DataFrame to downcast (modified in-place for speed)
        
    Returns:
        Same DataFrame with float64 → float32 columns
    """
    float64_cols = df.select_dtypes(include=['float64']).columns
    if len(float64_cols) > 0:
        df[float64_cols] = df[float64_cols].astype(np.float32)
    return df


def downcast_array(arr: np.ndarray) -> np.ndarray:
    """
    Downcast numpy float64 array to float32.
    
    Args:
        arr: numpy array (any dtype)
        
    Returns:
        float32 array if input was float64, otherwise unchanged
    """
    if arr.dtype == np.float64:
        return arr.astype(np.float32)
    return arr


def gc_collect(context: str = "") -> int:
    """
    Force garbage collection and return bytes freed estimate.
    
    Args:
        context: Optional label for logging (e.g., "after L5 detection")
        
    Returns:
        Number of unreachable objects found
    """
    return gc.collect()


def cleanup_intermediates(*args) -> None:
    """
    Delete intermediate variables and force GC.
    
    Usage:
        cleanup_intermediates(df_temp, X_raw, old_matrix)
    """
    for obj in args:
        del obj
    gc.collect()
