"""
Module 2: Data Quality Processing — 12 Sequential Steps
=========================================================
Takes the DQ-validated MASTER table and applies 12 cleansing steps
to produce a clean, analysis-ready DataFrame.

Steps:
   1. Data Type Detection      → DATA_TYPE_MAP
   2. Config Exclusions        → drop listed columns/tables
   3. PII Removal              → auto-drop PII patterns
   4. Datetime Handling        → move to SPECIAL_OBSERVATIONS
   5. Additional Exclusions    → *_id, *_key (preserve BASE_KEY)
   6. Drop Constants           → stddev=0 or 1 unique
   7. Type Validation          → cross-validate vs FEATURE_STORE
   8. Error Detection          → HIGHLIGHT negative/future/OOR → DATA_ERROR_REPORT
   9. Rename Columns           → apply FEATURE_MAP renames
  10. Drop High Null           → null% > 95% → drop
  11. Drop High Cardinality    → categorical unique>20 → drop
  12. Output Summary           → DATA_QUALITY_SUMMARY

Input : MASTER_TABLE DataFrame (post DQ Validation)
Output: DQProcessingResult with cleaned DataFrame + step reports

Author: AIM AI Vault V23 — 5-Module Pipeline
"""

import pandas as pd
import numpy as np
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Set
from datetime import datetime
import fnmatch
import json
import logging

logger = logging.getLogger("apurbadas.dq_processing")


# ─────────────────────────────────────────────────────────────────────────────
# RESULT DATACLASS
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class DQProcessingResult:
    """Complete result from Module 2: DQ Processing."""
    cleaned_df: Optional[pd.DataFrame] = None
    datetime_cols_extracted: Optional[pd.DataFrame] = None  # SPECIAL_OBSERVATIONS

    # Data type map
    data_type_map: Dict[str, str] = field(default_factory=dict)  # col -> type

    # Reports
    error_report: Optional[pd.DataFrame] = None   # DATA_ERROR_REPORT
    summary: Optional[pd.DataFrame] = None         # DATA_QUALITY_SUMMARY
    exclusion_log: List[Dict[str, Any]] = field(default_factory=list)

    # Tracking
    columns_dropped: List[str] = field(default_factory=list)
    columns_renamed: Dict[str, str] = field(default_factory=dict)
    step_log: List[Dict[str, Any]] = field(default_factory=list)

    # Shape tracking
    shape_before: tuple = (0, 0)
    shape_after: tuple = (0, 0)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


# ─────────────────────────────────────────────────────────────────────────────
# MAIN ENGINE
# ─────────────────────────────────────────────────────────────────────────────
class DQProcessingEngine:
    """
    12-Step Data Quality Processing Pipeline.
    Sequentially cleans the MASTER table for downstream preprocessing.
    """

    def __init__(self, base_key: str = "cust_id",
                 pii_patterns: List[str] = None,
                 id_patterns: List[str] = None,
                 high_null_threshold: float = 0.95,
                 high_cardinality_limit: int = 20,
                 exclude_config: Optional[pd.DataFrame] = None,
                 feature_map: Optional[pd.DataFrame] = None,
                 feature_store: Optional[pd.DataFrame] = None):
        self.base_key = base_key
        self.pii_patterns = pii_patterns or [
            "*phone*", "*email*", "*ssn*", "*name*", "*address*",
            "*dob*", "*birth*", "*passport*", "*license*",
        ]
        self.id_patterns = id_patterns or ["*_id", "*_key"]
        self.high_null_threshold = high_null_threshold
        self.high_cardinality_limit = high_cardinality_limit
        self.exclude_config = exclude_config
        self.feature_map = feature_map
        self.feature_store = feature_store

    def process(self, df: pd.DataFrame) -> DQProcessingResult:
        """Run all 12 DQ processing steps sequentially."""
        result = DQProcessingResult(shape_before=(len(df), len(df.columns)))
        work = df.copy()

        try:
            # Step 1: Data Type Detection
            work = self._step01_type_detect(work, result)
            # Step 2: Config Exclusions
            work = self._step02_config_exclude(work, result)
            # Step 3: PII Removal
            work = self._step03_pii_remove(work, result)
            # Step 4: Datetime Handling
            work = self._step04_datetime(work, result)
            # Step 5: Additional Exclusions (*_id, *_key, preserve BASE_KEY)
            work = self._step05_id_exclude(work, result)
            # Step 6: Drop Constants
            work = self._step06_constants(work, result)
            # Step 7: Type Validation
            work = self._step07_type_validate(work, result)
            # Step 8: Error Detection
            work = self._step08_errors(work, result)
            # Step 9: Rename Columns
            work = self._step09_rename(work, result)
            # Step 10: Drop High Null
            work = self._step10_high_null(work, result)
            # Step 11: Drop High Cardinality
            work = self._step11_high_cardinality(work, result)
            # Step 12: Output Summary
            self._step12_summary(work, result)

            result.cleaned_df = work
            result.shape_after = (len(work), len(work.columns))

        except Exception as e:
            logger.error(f"DQ Processing failed at step: {e}")
            result.step_log.append({"step": "ERROR", "message": str(e)})
            result.cleaned_df = work

        return result

    # ─────────────────────────────────────────────────────────────────────
    # STEP 1: DATA TYPE DETECTION
    # ─────────────────────────────────────────────────────────────────────
    def _step01_type_detect(self, df: pd.DataFrame, result: DQProcessingResult) -> pd.DataFrame:
        """Auto-detect: CONTINUOUS (>10 unique), BINARY (2), CATEGORICAL (≤20), DATETIME."""
        type_map = {}
        for col in df.columns:
            nunique = df[col].nunique()
            dtype = df[col].dtype

            # Safe dtype checks (guard against ExtensionDtype like StringDtype)
            try:
                is_dt = np.issubdtype(dtype, np.datetime64)
            except TypeError:
                is_dt = False
            try:
                is_num = np.issubdtype(dtype, np.number)
            except TypeError:
                is_num = False

            if is_dt:
                type_map[col] = "DATETIME"
            elif is_num:
                if nunique == 2:
                    type_map[col] = "BINARY"
                elif nunique <= 20:
                    type_map[col] = "DISCRETE"
                else:
                    type_map[col] = "CONTINUOUS"
            else:
                if nunique == 2:
                    type_map[col] = "BINARY"
                elif nunique <= 20:
                    type_map[col] = "CATEGORICAL"
                else:
                    type_map[col] = "HIGH_CARDINAL_TEXT"

        # Override with FEATURE_STORE if available
        if self.feature_store is not None and "column" in self.feature_store.columns:
            if "type" in self.feature_store.columns:
                store_map = dict(zip(self.feature_store["column"], self.feature_store["type"]))
                for col, declared_type in store_map.items():
                    if col in type_map:
                        type_map[col] = declared_type.upper()

        result.data_type_map = type_map
        result.step_log.append({
            "step": 1, "name": "Data Type Detection",
            "type_counts": {t: list(type_map.values()).count(t) for t in set(type_map.values())},
            "total_columns": len(type_map),
        })
        return df

    # ─────────────────────────────────────────────────────────────────────
    # STEP 2: CONFIG EXCLUSIONS
    # ─────────────────────────────────────────────────────────────────────
    def _step02_config_exclude(self, df: pd.DataFrame, result: DQProcessingResult) -> pd.DataFrame:
        """Drop columns/tables listed in EXCLUDE config."""
        dropped = []
        if self.exclude_config is not None:
            # Expect columns: 'column' or 'name'
            col_key = "column" if "column" in self.exclude_config.columns else "name"
            if col_key in self.exclude_config.columns:
                exclude_list = self.exclude_config[col_key].dropna().str.strip().tolist()
                to_drop = [c for c in df.columns if c in exclude_list]
                if to_drop:
                    df = df.drop(columns=to_drop)
                    dropped = to_drop

        result.columns_dropped.extend(dropped)
        result.exclusion_log.append({"step": 2, "reason": "CONFIG_EXCLUDE", "columns": dropped})
        result.step_log.append({
            "step": 2, "name": "Config Exclusions",
            "dropped_count": len(dropped),
            "dropped": dropped[:20],
        })
        return df

    # ─────────────────────────────────────────────────────────────────────
    # STEP 3: PII REMOVAL
    # ─────────────────────────────────────────────────────────────────────
    def _step03_pii_remove(self, df: pd.DataFrame, result: DQProcessingResult) -> pd.DataFrame:
        """Auto-drop PII columns matching patterns: *phone*, *email*, *ssn*, etc."""
        dropped = []
        for col in df.columns:
            col_lower = col.lower()
            for pattern in self.pii_patterns:
                if fnmatch.fnmatch(col_lower, pattern):
                    dropped.append(col)
                    break

        # Never drop BASE_KEY even if it matches a PII pattern
        dropped = [c for c in dropped if c != self.base_key]

        if dropped:
            df = df.drop(columns=dropped)

        result.columns_dropped.extend(dropped)
        result.exclusion_log.append({"step": 3, "reason": "PII_REMOVAL", "columns": dropped})
        result.step_log.append({
            "step": 3, "name": "PII Removal",
            "dropped_count": len(dropped),
            "dropped": dropped[:20],
        })
        return df

    # ─────────────────────────────────────────────────────────────────────
    # STEP 4: DATETIME HANDLING
    # ─────────────────────────────────────────────────────────────────────
    def _step04_datetime(self, df: pd.DataFrame, result: DQProcessingResult) -> pd.DataFrame:
        """Move datetime columns to SPECIAL_OBSERVATIONS, drop from main df."""
        dt_cols = [c for c in df.columns if result.data_type_map.get(c) == "DATETIME"]

        # Also detect object columns that look like dates
        for col in df.select_dtypes(include=["object"]).columns:
            try:
                pd.to_datetime(df[col].dropna().head(50), errors="raise")
                dt_cols.append(col)
                result.data_type_map[col] = "DATETIME"
            except Exception:
                pass

        dt_cols = list(set(dt_cols))

        if dt_cols:
            result.datetime_cols_extracted = df[dt_cols].copy()
            df = df.drop(columns=dt_cols)

        result.columns_dropped.extend(dt_cols)
        result.step_log.append({
            "step": 4, "name": "Datetime Handling",
            "datetime_cols_extracted": dt_cols,
            "count": len(dt_cols),
        })
        return df

    # ─────────────────────────────────────────────────────────────────────
    # STEP 5: ADDITIONAL EXCLUSIONS (*_id, *_key — preserve BASE_KEY)
    # ─────────────────────────────────────────────────────────────────────
    def _step05_id_exclude(self, df: pd.DataFrame, result: DQProcessingResult) -> pd.DataFrame:
        """Drop columns matching *_id, *_key patterns (preserve BASE_KEY)."""
        dropped = []
        for col in df.columns:
            if col == self.base_key:
                continue  # NEVER drop BASE_KEY
            col_lower = col.lower()
            for pattern in self.id_patterns:
                if fnmatch.fnmatch(col_lower, pattern):
                    dropped.append(col)
                    break

        if dropped:
            df = df.drop(columns=dropped)

        result.columns_dropped.extend(dropped)
        result.exclusion_log.append({"step": 5, "reason": "ID_EXCLUSION", "columns": dropped})
        result.step_log.append({
            "step": 5, "name": "Additional Exclusions (ID/Key)",
            "dropped_count": len(dropped),
            "dropped": dropped[:20],
        })
        return df

    # ─────────────────────────────────────────────────────────────────────
    # STEP 6: DROP CONSTANTS
    # ─────────────────────────────────────────────────────────────────────
    def _step06_constants(self, df: pd.DataFrame, result: DQProcessingResult) -> pd.DataFrame:
        """Drop columns with stddev=0 (numeric) or 1 unique value (categorical)."""
        dropped = []
        for col in df.columns:
            if col == self.base_key:
                continue
            nunique = df[col].nunique()
            if nunique <= 1:
                dropped.append(col)
                continue
            if pd.api.types.is_numeric_dtype(df[col]):
                if df[col].std() == 0:
                    dropped.append(col)

        if dropped:
            df = df.drop(columns=dropped)

        result.columns_dropped.extend(dropped)
        result.step_log.append({
            "step": 6, "name": "Drop Constants",
            "dropped_count": len(dropped),
            "dropped": dropped[:20],
        })
        return df

    # ─────────────────────────────────────────────────────────────────────
    # STEP 7: TYPE VALIDATION
    # ─────────────────────────────────────────────────────────────────────
    def _step07_type_validate(self, df: pd.DataFrame, result: DQProcessingResult) -> pd.DataFrame:
        """Cross-validate detected types vs FEATURE_STORE, flag mismatches."""
        mismatches = []
        if self.feature_store is not None and "column" in self.feature_store.columns:
            if "type" in self.feature_store.columns:
                store_map = dict(zip(self.feature_store["column"], self.feature_store["type"]))
                for col in df.columns:
                    detected = result.data_type_map.get(col, "UNKNOWN")
                    declared = store_map.get(col)
                    if declared and declared.upper() != detected:
                        mismatches.append({
                            "column": col,
                            "detected_type": detected,
                            "declared_type": declared.upper(),
                        })

        result.step_log.append({
            "step": 7, "name": "Type Validation",
            "mismatches": len(mismatches),
            "details": mismatches[:20],
        })
        return df

    # ─────────────────────────────────────────────────────────────────────
    # STEP 8: ERROR DETECTION (HIGHLIGHT, don't drop)
    # ─────────────────────────────────────────────────────────────────────
    def _step08_errors(self, df: pd.DataFrame, result: DQProcessingResult) -> pd.DataFrame:
        """Detect data errors: negatives, out-of-range. Report but don't drop."""
        errors = []
        for col in df.select_dtypes(include=[np.number]).columns:
            col_lower = col.lower()
            series = df[col].dropna()

            # Negative amounts
            if any(kw in col_lower for kw in ["amount", "amt", "value", "balance"]):
                neg = int((series < 0).sum())
                if neg > 0:
                    errors.append({
                        "column": col, "error_type": "NEGATIVE_AMOUNT",
                        "count": neg, "action": "HIGHLIGHT",
                    })

            # Extreme outliers (beyond 10σ)
            if len(series) > 10:
                mean, std = series.mean(), series.std()
                if std > 0:
                    extreme = int((np.abs(series - mean) > 10 * std).sum())
                    if extreme > 0:
                        errors.append({
                            "column": col, "error_type": "EXTREME_OUTLIER_10σ",
                            "count": extreme, "action": "HIGHLIGHT",
                        })

        result.error_report = pd.DataFrame(errors) if errors else pd.DataFrame(
            columns=["column", "error_type", "count", "action"]
        )
        result.step_log.append({
            "step": 8, "name": "Error Detection",
            "errors_found": len(errors),
            "action": "HIGHLIGHT (no drop)",
        })
        return df

    # ─────────────────────────────────────────────────────────────────────
    # STEP 9: RENAME COLUMNS
    # ─────────────────────────────────────────────────────────────────────
    def _step09_rename(self, df: pd.DataFrame, result: DQProcessingResult) -> pd.DataFrame:
        """Apply renames from FEATURE_MAP config."""
        renamed = {}
        if self.feature_map is not None:
            if "original" in self.feature_map.columns and "rename" in self.feature_map.columns:
                # V24 FIX: dropna on both columns together to prevent zip misalignment
                valid_rows = self.feature_map.dropna(subset=["original", "rename"])
                rename_map = dict(zip(valid_rows["original"], valid_rows["rename"]))
                valid_renames = {k: v for k, v in rename_map.items()
                                 if k in df.columns and v and str(v).strip()}
                if valid_renames:
                    df = df.rename(columns=valid_renames)
                    renamed = valid_renames

        result.columns_renamed = renamed
        result.step_log.append({
            "step": 9, "name": "Rename Columns",
            "renamed_count": len(renamed),
            "renames": renamed,
        })
        return df

    # ─────────────────────────────────────────────────────────────────────
    # STEP 10: DROP HIGH NULL
    # ─────────────────────────────────────────────────────────────────────
    def _step10_high_null(self, df: pd.DataFrame, result: DQProcessingResult) -> pd.DataFrame:
        """Drop columns where null% > threshold (default 95%)."""
        dropped = []
        n = len(df)
        for col in df.columns:
            if col == self.base_key:
                continue
            null_pct = df[col].isnull().sum() / n if n > 0 else 0
            if null_pct > self.high_null_threshold:
                dropped.append(col)

        if dropped:
            df = df.drop(columns=dropped)

        result.columns_dropped.extend(dropped)
        result.step_log.append({
            "step": 10, "name": "Drop High Null (>95%)",
            "dropped_count": len(dropped),
            "dropped": dropped[:20],
        })
        return df

    # ─────────────────────────────────────────────────────────────────────
    # STEP 11: DROP HIGH CARDINALITY
    # ─────────────────────────────────────────────────────────────────────
    def _step11_high_cardinality(self, df: pd.DataFrame, result: DQProcessingResult) -> pd.DataFrame:
        """Drop categorical columns with >limit unique values (unless in FEATURE_MAP)."""
        dropped = []
        protected = set()
        if self.feature_map is not None and "original" in self.feature_map.columns:
            protected = set(self.feature_map["original"].dropna().tolist())

        for col in df.select_dtypes(include=["object", "category"]).columns:
            if col == self.base_key:
                continue
            if col in protected:
                continue
            nunique = df[col].nunique()
            if nunique > self.high_cardinality_limit:
                dropped.append(col)

        if dropped:
            df = df.drop(columns=dropped)

        result.columns_dropped.extend(dropped)
        result.step_log.append({
            "step": 11, "name": f"Drop High Cardinality (>{self.high_cardinality_limit})",
            "dropped_count": len(dropped),
            "dropped": dropped[:20],
        })
        return df

    # ─────────────────────────────────────────────────────────────────────
    # STEP 12: OUTPUT SUMMARY
    # ─────────────────────────────────────────────────────────────────────
    def _step12_summary(self, df: pd.DataFrame, result: DQProcessingResult):
        """Generate DATA_QUALITY_SUMMARY report."""
        rows = []
        for col in df.columns:
            dtype = str(df[col].dtype)
            detected_type = result.data_type_map.get(col, "UNKNOWN")
            null_pct = round(df[col].isnull().sum() / len(df) * 100, 2) if len(df) > 0 else 0
            nunique = int(df[col].nunique())

            rows.append({
                "column": col,
                "pandas_dtype": dtype,
                "detected_type": detected_type,
                "null_pct": null_pct,
                "unique_values": nunique,
                "sample_values": str(df[col].dropna().head(3).tolist())[:80],
            })

        result.summary = pd.DataFrame(rows)
        result.step_log.append({
            "step": 12, "name": "Output Summary",
            "final_rows": len(df),
            "final_cols": len(df.columns),
            "total_dropped": len(result.columns_dropped),
            "total_renamed": len(result.columns_renamed),
        })
        logger.info(
            f"DQ Processing complete: {result.shape_before} → ({len(df)}, {len(df.columns)}), "
            f"dropped {len(result.columns_dropped)} cols"
        )
