"""
Module 5: 9-Path Dimension Reduction Engine → PreMaster (V28)
=============================================================
Takes each scaled matrix (N × K) from Module 4 and reduces dimensions
along one of 9 user-selected paths. The result is the PreMaster matrix:
the final algorithm-ready input.

9 Reduction Paths
─────────────────
  Path 1 — None                   : No reduction (K stays as-is)
  Path 2 — Mixed PCA (Linear Fast): PCA on CONTINUOUS, keep BINARY/CATEGORICAL intact
  Path 3 — FAMD (Linear Think) ⭐ : PCA + MCA unified factor space (20-100 dims)
  Path 4 — UMAP Mixed (Non-Linear): UMAP on CONTINUOUS, keep BINARY/CAT intact, concat
  Path 5 — UMAP Metric Intersection: UMAP on ALL features (30-50 dims)
  Path 6 — SDAE (Deep)            : Sparse Denoising AE (K→256→128→D→128→256→K)
  Path 7 — Agent Quick             : Auto-select (speed priority: R × V heuristic)
  Path 8 — Agent Think (Auto Long) : Auto-select (accuracy priority)
  Path 9 — Agent Decide   ⚠️       : Full auto-decision based on R × V matrix

Input:
  - scaled_matrix  (N × K numpy array)
  - feature_names  (list[str])
  - encoding_map   (col → type from Module 3)
  - target_dims    (int, optional)

Output:
  - PreMaster  (N × D DataFrame, D ≤ K)

Author: AIM AI Vault V23 — 5-Module Pipeline
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
import logging

logger = logging.getLogger("apurbadas.reduction_engine")


# ─────────────────────────────────────────────────────────────────────────────
# PATH CONSTANTS
# ─────────────────────────────────────────────────────────────────────────────
PATH_NONE          = 1
PATH_MIXED_PCA     = 2
PATH_FAMD          = 3
PATH_UMAP_MIXED    = 4
PATH_UMAP_FULL     = 5
PATH_SDAE          = 6
PATH_AGENT_QUICK   = 7
PATH_AGENT_THINK   = 8
PATH_AGENT_DECIDE  = 9   # V28: Full auto-decision based on R × V

PATH_NAMES = {
    1: "None (No Reduction)",
    2: "Mixed PCA",
    3: "FAMD",
    4: "UMAP Mixed",
    5: "UMAP Metric Intersection",
    6: "SDAE (Autoencoder)",
    7: "Agent Quick",
    8: "Agent Think",
    9: "Agent Decide",
}


# ─────────────────────────────────────────────────────────────────────────────
# RESULT DATACLASS
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class ReductionResult:
    """Complete result from Module 5: Dimension Reduction."""
    premaster: Optional[pd.DataFrame] = None          # N × D PreMaster matrix
    path_used: int = 1
    path_name: str = "None"
    dims_before: int = 0
    dims_after: int = 0
    explained_variance: Optional[float] = None
    reduction_model: Any = None                       # fitted reducer for reuse

    # For Agent paths: reasoning
    agent_selection: Optional[Dict[str, Any]] = None

    step_log: List[Dict[str, Any]] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


# ─────────────────────────────────────────────────────────────────────────────
# MAIN ENGINE
# ─────────────────────────────────────────────────────────────────────────────
class ReductionEngine:
    """
    8-Path Dimension Reduction.
    Call reduce() with a path number and scaled matrix.
    """

    def __init__(self,
                 pca_variance_ratio: float = 0.95,
                 famd_dims: int = 50,
                 umap_dims: int = 30,
                 sdae_bottleneck: int = 50,
                 umap_n_neighbors: int = 15,
                 umap_min_dist: float = 0.1,
                 random_state: int = 42):
        self.pca_variance_ratio = pca_variance_ratio
        self.famd_dims = famd_dims
        self.umap_dims = umap_dims
        self.sdae_bottleneck = sdae_bottleneck
        self.umap_n_neighbors = umap_n_neighbors
        self.umap_min_dist = umap_min_dist
        self.random_state = random_state

    def reduce(self,
               X: np.ndarray,
               feature_names: List[str],
               path: int = 1,
               encoding_map: Optional[Dict[str, str]] = None,
               target_dims: Optional[int] = None) -> ReductionResult:
        """
        Apply the specified reduction path.

        Args:
            X:             scaled matrix (N × K)
            feature_names: column names matching K
            path:          1-8 (reduction path number)
            encoding_map:  col → type from Module 3 (needed for mixed paths)
            target_dims:   override default target dimensions
        """
        result = ReductionResult(
            path_used=path,
            path_name=PATH_NAMES.get(path, "Unknown"),
            dims_before=X.shape[1] if len(X.shape) > 1 else 0,
        )

        # V24 FIX: Guard against 0-row input
        if X.shape[0] == 0:
            logger.warning("ReductionEngine: 0 rows in input, returning empty PreMaster")
            result.premaster = pd.DataFrame(columns=feature_names)
            result.dims_after = len(feature_names)
            result.step_log.append({"step": "GUARD", "warning": "0 rows, no reduction applied"})
            return result

        encoding_map = encoding_map or {}

        try:
            if path == PATH_NONE:
                premaster = self._path_none(X, feature_names, result)
            elif path == PATH_MIXED_PCA:
                premaster = self._path_mixed_pca(X, feature_names, encoding_map, target_dims, result)
            elif path == PATH_FAMD:
                premaster = self._path_famd(X, feature_names, encoding_map, target_dims, result)
            elif path == PATH_UMAP_MIXED:
                premaster = self._path_umap_mixed(X, feature_names, encoding_map, target_dims, result)
            elif path == PATH_UMAP_FULL:
                premaster = self._path_umap_full(X, feature_names, target_dims, result)
            elif path == PATH_SDAE:
                premaster = self._path_sdae(X, feature_names, target_dims, result)
            elif path == PATH_AGENT_QUICK:
                premaster = self._path_agent_quick(X, feature_names, encoding_map, result)
            elif path == PATH_AGENT_THINK:
                premaster = self._path_agent_think(X, feature_names, encoding_map, result)
            elif path == PATH_AGENT_DECIDE:
                premaster = self._path_agent_decide(X, feature_names, encoding_map, target_dims, result)
            else:
                logger.warning(f"Unknown path {path}, defaulting to None")
                premaster = self._path_none(X, feature_names, result)

            result.premaster = premaster
            result.dims_after = premaster.shape[1]

        except Exception as e:
            logger.error(f"Reduction path {path} failed: {e}")
            result.step_log.append({"step": "ERROR", "message": str(e)})
            # Fallback: return unreduced
            result.premaster = pd.DataFrame(X, columns=feature_names)
            result.dims_after = X.shape[1]

        logger.info(f"Reduction Path {path} ({result.path_name}): "
                     f"{result.dims_before} → {result.dims_after} dims")
        return result

    # ─────────────────────────────────────────────────────────────────────
    # PATH 1: NONE
    # ─────────────────────────────────────────────────────────────────────
    def _path_none(self, X: np.ndarray, features: List[str],
                   result: ReductionResult) -> pd.DataFrame:
        """No reduction — passthrough."""
        result.step_log.append({"path": 1, "action": "passthrough", "dims": X.shape[1]})
        return pd.DataFrame(X, columns=features)

    # ─────────────────────────────────────────────────────────────────────
    # PATH 2: MIXED PCA
    # ─────────────────────────────────────────────────────────────────────
    def _path_mixed_pca(self, X: np.ndarray, features: List[str],
                        encoding_map: Dict[str, str],
                        target_dims: Optional[int],
                        result: ReductionResult) -> pd.DataFrame:
        """PCA on continuous features, keep binary/categorical intact, concat."""
        from sklearn.decomposition import PCA

        cont_idx = [i for i, f in enumerate(features)
                    if encoding_map.get(f, "CONTINUOUS") in ("CONTINUOUS", "DISCRETE")]
        cat_idx = [i for i, f in enumerate(features)
                   if encoding_map.get(f, "CONTINUOUS") not in ("CONTINUOUS", "DISCRETE")]

        if len(cont_idx) == 0:
            result.step_log.append({"path": 2, "warning": "No continuous features for PCA"})
            return pd.DataFrame(X, columns=features)

        X_cont = X[:, cont_idx]
        X_cat = X[:, cat_idx] if cat_idx else None

        # Determine components
        n_components = target_dims or min(X_cont.shape[1], max(2, X_cont.shape[1] // 2))
        n_components = min(n_components, X_cont.shape[0], X_cont.shape[1])

        pca = PCA(n_components=n_components, random_state=self.random_state)
        X_pca = pca.fit_transform(X_cont)
        result.reduction_model = pca

        # Use variance to determine optimal cutoff
        cumvar = np.cumsum(pca.explained_variance_ratio_)
        n_keep = int(np.searchsorted(cumvar, self.pca_variance_ratio) + 1)
        n_keep = min(n_keep, X_pca.shape[1])
        X_pca = X_pca[:, :n_keep]
        result.explained_variance = float(cumvar[n_keep - 1])

        pca_cols = [f"PC_{i+1}" for i in range(X_pca.shape[1])]
        cat_cols = [features[i] for i in cat_idx]

        parts = [pd.DataFrame(X_pca, columns=pca_cols)]
        if X_cat is not None and len(cat_idx) > 0:
            parts.append(pd.DataFrame(X_cat, columns=cat_cols))

        premaster = pd.concat(parts, axis=1)

        result.step_log.append({
            "path": 2, "action": "Mixed PCA",
            "continuous_features": len(cont_idx),
            "pca_components": n_keep,
            "variance_explained": result.explained_variance,
            "binary_cat_kept": len(cat_idx),
        })
        return premaster

    # ─────────────────────────────────────────────────────────────────────
    # PATH 3: FAMD
    # ─────────────────────────────────────────────────────────────────────
    def _path_famd(self, X: np.ndarray, features: List[str],
                   encoding_map: Dict[str, str],
                   target_dims: Optional[int],
                   result: ReductionResult) -> pd.DataFrame:
        """Factor Analysis of Mixed Data (PCA + MCA unified)."""
        try:
            import prince

            n_dims = target_dims or self.famd_dims
            n_dims = min(n_dims, X.shape[1], X.shape[0])

            # FAMD needs a DataFrame with proper dtypes
            df_work = pd.DataFrame(X, columns=features)

            # Mark categorical columns for prince
            for col in features:
                col_type = encoding_map.get(col, "CONTINUOUS")
                if col_type in ("BINARY", "CATEGORICAL"):
                    df_work[col] = df_work[col].astype(str)

            famd = prince.FAMD(n_components=n_dims, random_state=self.random_state)
            X_famd = famd.fit_transform(df_work)
            result.reduction_model = famd

            famd_cols = [f"FAMD_{i+1}" for i in range(X_famd.shape[1])]
            premaster = pd.DataFrame(X_famd.values if hasattr(X_famd, 'values') else X_famd,
                                     columns=famd_cols)

            result.step_log.append({
                "path": 3, "action": "FAMD",
                "target_dims": n_dims,
                "output_dims": premaster.shape[1],
            })
            return premaster

        except ImportError:
            logger.warning("prince not installed — falling back to Mixed PCA")
            result.step_log.append({"path": 3, "warning": "prince not available, fallback to Mixed PCA"})
            return self._path_mixed_pca(X, features, encoding_map, target_dims, result)

    # ─────────────────────────────────────────────────────────────────────
    # PATH 4: UMAP MIXED
    # ─────────────────────────────────────────────────────────────────────
    def _path_umap_mixed(self, X: np.ndarray, features: List[str],
                         encoding_map: Dict[str, str],
                         target_dims: Optional[int],
                         result: ReductionResult) -> pd.DataFrame:
        """UMAP on continuous features, keep binary/cat intact, concat."""
        try:
            import umap

            cont_idx = [i for i, f in enumerate(features)
                        if encoding_map.get(f, "CONTINUOUS") in ("CONTINUOUS", "DISCRETE")]
            cat_idx = [i for i, f in enumerate(features)
                       if encoding_map.get(f, "CONTINUOUS") not in ("CONTINUOUS", "DISCRETE")]

            if len(cont_idx) == 0:
                return pd.DataFrame(X, columns=features)

            X_cont = X[:, cont_idx]
            X_cat = X[:, cat_idx] if cat_idx else None

            n_dims = target_dims or self.umap_dims
            # V24 FIX: UMAP requires n_components < n_samples
            n_dims = min(n_dims, X_cont.shape[1], max(1, X_cont.shape[0] - 1))

            reducer = umap.UMAP(
                n_components=n_dims,
                n_neighbors=self.umap_n_neighbors,
                min_dist=self.umap_min_dist,
                metric="euclidean",
                random_state=self.random_state,
            )
            X_umap = reducer.fit_transform(X_cont)
            result.reduction_model = reducer

            umap_cols = [f"UMAP_{i+1}" for i in range(X_umap.shape[1])]
            cat_cols = [features[i] for i in cat_idx]

            parts = [pd.DataFrame(X_umap, columns=umap_cols)]
            if X_cat is not None and len(cat_idx) > 0:
                parts.append(pd.DataFrame(X_cat, columns=cat_cols))

            premaster = pd.concat(parts, axis=1)

            result.step_log.append({
                "path": 4, "action": "UMAP Mixed",
                "continuous_features": len(cont_idx),
                "umap_dims": n_dims,
                "binary_cat_kept": len(cat_idx),
            })
            return premaster

        except ImportError:
            logger.warning("umap-learn not installed — falling back to Mixed PCA")
            result.step_log.append({"path": 4, "warning": "umap-learn not available, fallback to Mixed PCA"})
            return self._path_mixed_pca(X, features, encoding_map, target_dims, result)

    # ─────────────────────────────────────────────────────────────────────
    # PATH 5: UMAP FULL
    # ─────────────────────────────────────────────────────────────────────
    def _path_umap_full(self, X: np.ndarray, features: List[str],
                        target_dims: Optional[int],
                        result: ReductionResult) -> pd.DataFrame:
        """UMAP on ALL features (metric intersection: Euclidean + Hamming)."""
        try:
            import umap

            n_dims = target_dims or self.umap_dims
            # V24 FIX: UMAP requires n_components < n_samples
            n_dims = min(n_dims, X.shape[1], max(1, X.shape[0] - 1))

            reducer = umap.UMAP(
                n_components=n_dims,
                n_neighbors=self.umap_n_neighbors,
                min_dist=self.umap_min_dist,
                metric="euclidean",  # metric intersection handled by UMAP internals
                random_state=self.random_state,
            )
            X_umap = reducer.fit_transform(X)
            result.reduction_model = reducer

            umap_cols = [f"UMAP_FULL_{i+1}" for i in range(X_umap.shape[1])]
            premaster = pd.DataFrame(X_umap, columns=umap_cols)

            result.step_log.append({
                "path": 5, "action": "UMAP Full",
                "input_dims": X.shape[1],
                "output_dims": n_dims,
            })
            return premaster

        except ImportError:
            logger.warning("umap-learn not installed — falling back to PCA")
            from sklearn.decomposition import PCA
            n_dims = target_dims or self.umap_dims
            n_dims = min(n_dims, *X.shape)
            pca = PCA(n_components=n_dims, random_state=self.random_state)
            X_pca = pca.fit_transform(X)
            result.reduction_model = pca
            cols = [f"PC_{i+1}" for i in range(X_pca.shape[1])]
            result.step_log.append({"path": 5, "warning": "umap fallback to PCA"})
            return pd.DataFrame(X_pca, columns=cols)

    # ─────────────────────────────────────────────────────────────────────
    # PATH 6: SDAE (Stacked Denoising Autoencoder)
    # ─────────────────────────────────────────────────────────────────────
    def _path_sdae(self, X: np.ndarray, features: List[str],
                   target_dims: Optional[int],
                   result: ReductionResult) -> pd.DataFrame:
        """
        Stacked Denoising Autoencoder:
        Architecture: K → 256 → 128 → D → 128 → 256 → K
        Bottleneck layer = target_dims (D)
        """
        try:
            import tensorflow as tf
            from tensorflow import keras

            D = target_dims or self.sdae_bottleneck
            K = X.shape[1]

            # Architecture: K → 256 → 128 → D → 128 → 256 → K
            layer_sizes = [256, 128, D, 128, 256]
            # Clip layer sizes if K is small
            layer_sizes = [min(s, K) for s in layer_sizes]

            # Build encoder
            encoder_input = keras.Input(shape=(K,))
            # Add noise layer for denoising
            x = keras.layers.GaussianNoise(0.1)(encoder_input)
            x = keras.layers.Dense(layer_sizes[0], activation="relu")(x)
            x = keras.layers.BatchNormalization()(x)
            x = keras.layers.Dropout(0.2)(x)
            x = keras.layers.Dense(layer_sizes[1], activation="relu")(x)
            x = keras.layers.BatchNormalization()(x)
            bottleneck = keras.layers.Dense(layer_sizes[2], activation="relu", name="bottleneck")(x)

            # Build decoder
            x = keras.layers.Dense(layer_sizes[3], activation="relu")(bottleneck)
            x = keras.layers.BatchNormalization()(x)
            x = keras.layers.Dense(layer_sizes[4], activation="relu")(x)
            decoder_output = keras.layers.Dense(K, activation="linear")(x)

            # Full autoencoder
            autoencoder = keras.Model(encoder_input, decoder_output)
            autoencoder.compile(optimizer="adam", loss="mse")

            # Train (silent)
            autoencoder.fit(
                X, X,
                epochs=50,
                batch_size=min(256, len(X)),
                validation_split=0.1,
                verbose=0,
                callbacks=[
                    keras.callbacks.EarlyStopping(patience=5, restore_best_weights=True)
                ]
            )

            # Extract encoder up to bottleneck
            encoder = keras.Model(encoder_input, bottleneck)
            X_encoded = encoder.predict(X, verbose=0)

            result.reduction_model = encoder

            sdae_cols = [f"SDAE_{i+1}" for i in range(X_encoded.shape[1])]
            premaster = pd.DataFrame(X_encoded, columns=sdae_cols)

            result.step_log.append({
                "path": 6, "action": "SDAE",
                "architecture": f"{K}→256→128→{D}→128→256→{K}",
                "bottleneck_dims": D,
                "output_dims": X_encoded.shape[1],
            })
            return premaster

        except ImportError:
            logger.warning("tensorflow not installed — falling back to PCA")
            from sklearn.decomposition import PCA
            D = target_dims or self.sdae_bottleneck
            D = min(D, *X.shape)
            pca = PCA(n_components=D, random_state=self.random_state)
            X_pca = pca.fit_transform(X)
            result.reduction_model = pca
            cols = [f"PC_{i+1}" for i in range(X_pca.shape[1])]
            result.step_log.append({"path": 6, "warning": "tensorflow fallback to PCA"})
            return pd.DataFrame(X_pca, columns=cols)

    # ─────────────────────────────────────────────────────────────────────
    # PATH 7: AGENT QUICK (R × V heuristic)
    # ─────────────────────────────────────────────────────────────────────
    def _path_agent_quick(self, X: np.ndarray, features: List[str],
                          encoding_map: Dict[str, str],
                          result: ReductionResult) -> pd.DataFrame:
        """
        Auto-select fastest reduction based on R × V heuristic:
        - If K < 30: PATH_NONE
        - If K < 100: PATH_MIXED_PCA
        - If K < 500: PATH_UMAP_MIXED (faster than full)
        - If K ≥ 500: PATH_MIXED_PCA (PCA is fast)
        """
        N, K = X.shape
        RV = N * K  # Row × Variable complexity score

        if K < 30:
            selected = PATH_NONE
            reason = f"K={K} < 30: too few features for reduction"
        elif RV < 50_000:
            selected = PATH_MIXED_PCA
            reason = f"R×V={RV:,} < 50K: PCA is fast enough"
        elif K < 500:
            selected = PATH_UMAP_MIXED
            reason = f"K={K} < 500: UMAP Mixed gives good balance"
        else:
            selected = PATH_MIXED_PCA
            reason = f"K={K} ≥ 500: PCA for speed on wide matrix"

        result.agent_selection = {
            "mode": "QUICK",
            "N": N, "K": K, "RV": RV,
            "selected_path": selected,
            "selected_name": PATH_NAMES[selected],
            "reason": reason,
        }
        result.step_log.append({
            "path": 7, "action": "Agent Quick",
            "delegated_to": selected,
            "reason": reason,
        })

        # Delegate to selected path
        if selected == PATH_NONE:
            return self._path_none(X, features, result)
        elif selected == PATH_MIXED_PCA:
            return self._path_mixed_pca(X, features, encoding_map, None, result)
        elif selected == PATH_UMAP_MIXED:
            return self._path_umap_mixed(X, features, encoding_map, None, result)
        else:
            return self._path_none(X, features, result)

    # ─────────────────────────────────────────────────────────────────────
    # PATH 8: AGENT THINK (per-algorithm optimal)
    # ─────────────────────────────────────────────────────────────────────
    def _path_agent_think(self, X: np.ndarray, features: List[str],
                          encoding_map: Dict[str, str],
                          result: ReductionResult) -> pd.DataFrame:
        """
        Auto-select best reduction considering data characteristics:
        - Mixed types present? → FAMD or UMAP Mixed
        - High dimensional (>200)? → SDAE or UMAP Full
        - Moderate (<200)? → Mixed PCA
        - Few features (<30)? → None
        """
        N, K = X.shape

        # Count feature types
        n_continuous = sum(1 for f in features
                          if encoding_map.get(f, "CONTINUOUS") in ("CONTINUOUS", "DISCRETE"))
        n_categorical = K - n_continuous
        cat_ratio = n_categorical / K if K > 0 else 0

        if K < 30:
            selected = PATH_NONE
            reason = f"K={K} too few — no reduction needed"
        elif cat_ratio > 0.3:
            # Lots of categorical features
            selected = PATH_FAMD
            reason = f"cat_ratio={cat_ratio:.1%} > 30% — FAMD handles mixed data best"
        elif K > 200 and N > 5000:
            selected = PATH_UMAP_FULL
            reason = f"High-dim K={K}, large N={N} — UMAP Full for manifold learning"
        elif K > 200:
            selected = PATH_SDAE
            reason = f"High-dim K={K} — SDAE for nonlinear reduction"
        else:
            selected = PATH_MIXED_PCA
            reason = f"Moderate K={K}, low cat ratio — PCA is optimal"

        result.agent_selection = {
            "mode": "THINK",
            "N": N, "K": K,
            "n_continuous": n_continuous,
            "n_categorical": n_categorical,
            "cat_ratio": cat_ratio,
            "selected_path": selected,
            "selected_name": PATH_NAMES[selected],
            "reason": reason,
        }
        result.step_log.append({
            "path": 8, "action": "Agent Think",
            "delegated_to": selected,
            "reason": reason,
        })

        # Delegate to selected path
        dispatch = {
            PATH_NONE: lambda: self._path_none(X, features, result),
            PATH_MIXED_PCA: lambda: self._path_mixed_pca(X, features, encoding_map, None, result),
            PATH_FAMD: lambda: self._path_famd(X, features, encoding_map, None, result),
            PATH_UMAP_MIXED: lambda: self._path_umap_mixed(X, features, encoding_map, None, result),
            PATH_UMAP_FULL: lambda: self._path_umap_full(X, features, None, result),
            PATH_SDAE: lambda: self._path_sdae(X, features, None, result),
        }
        return dispatch.get(selected, lambda: self._path_none(X, features, result))()

    # ─────────────────────────────────────────────────────────────────────
    # PATH 9: AGENT DECIDE (V28 — Full R × V decision tree)
    # ─────────────────────────────────────────────────────────────────────
    def _path_agent_decide(self, X: np.ndarray, features: List[str],
                           encoding_map: Dict[str, str],
                           target_dims: Optional[int],
                           result: ReductionResult) -> pd.DataFrame:
        """
        V28: Full auto-decision based on R × V matrix.

        Decision tree (from specification):
          V < 20             → NONE
          V = 20-50:
            R < 5K           → NONE or Mixed PCA
            R ≥ 5K           → Speed: Mixed PCA | Accuracy: FAMD
          V = 50-100:
            R < 2K           → Mixed PCA
            R = 2K-10K       → FAMD ⭐ RECOMMENDED
            R > 10K          → FAMD or UMAP Mixed
          V = 100-150:
            R < 5K           → FAMD (30-50 dims)
            R = 5K-10K       → FAMD or UMAP Mixed
            R > 10K          → FAMD or UMAP or SDAE
          V > 150:
            R < 5K           → FAMD (50-100 dims)
            R = 5K-10K       → FAMD or SDAE
            R > 10K:
              Deep Learning? → SDAE (30-50) ⭐
              Non-linear?    → UMAP Mixed or UMAP Metric
              Standard?      → FAMD (100)
        """
        N, V = X.shape

        # Count feature types for tie-breaking
        n_cat = sum(1 for f in features
                    if encoding_map.get(f, "CONTINUOUS") in ("BINARY", "CATEGORICAL"))
        cat_ratio = n_cat / V if V > 0 else 0

        # ── Decision tree ──
        if V < 20:
            selected = PATH_NONE
            dims = V
            reason = f"V={V} < 20: too few features, no reduction needed"

        elif V <= 50:
            if N < 5_000:
                selected = PATH_NONE if V < 30 else PATH_MIXED_PCA
                dims = target_dims or min(V, 20)
                reason = f"V={V} (20-50), R={N:,} < 5K: {'None' if V < 30 else 'Mixed PCA'}"
            else:
                selected = PATH_FAMD
                dims = target_dims or min(V, 30)
                reason = f"V={V} (20-50), R={N:,} ≥ 5K: FAMD for mixed data accuracy"

        elif V <= 100:
            if N < 2_000:
                selected = PATH_MIXED_PCA
                dims = target_dims or min(V, 30)
                reason = f"V={V} (50-100), R={N:,} < 2K: Mixed PCA (fast)"
            elif N <= 10_000:
                selected = PATH_FAMD
                dims = target_dims or min(V, 50)
                reason = f"V={V} (50-100), R={N:,} (2K-10K): FAMD ⭐ recommended"
            else:
                if cat_ratio > 0.3:
                    selected = PATH_FAMD
                    dims = target_dims or min(V, 50)
                    reason = f"V={V} (50-100), R={N:,} > 10K, cat_ratio={cat_ratio:.0%}: FAMD"
                else:
                    selected = PATH_UMAP_MIXED
                    dims = target_dims or 30
                    reason = f"V={V} (50-100), R={N:,} > 10K, mostly continuous: UMAP Mixed"

        elif V <= 150:
            if N < 5_000:
                selected = PATH_FAMD
                dims = target_dims or min(V, 50)
                reason = f"V={V} (100-150), R={N:,} < 5K: FAMD (30-50 dims)"
            elif N <= 10_000:
                selected = PATH_FAMD if cat_ratio > 0.2 else PATH_UMAP_MIXED
                dims = target_dims or 50
                reason = f"V={V} (100-150), R={N:,} (5K-10K): {'FAMD' if cat_ratio > 0.2 else 'UMAP Mixed'}"
            else:
                selected = PATH_SDAE
                dims = target_dims or 50
                reason = f"V={V} (100-150), R={N:,} > 10K: SDAE deep reduction"

        else:  # V > 150
            if N < 5_000:
                selected = PATH_FAMD
                dims = target_dims or min(V, 100)
                reason = f"V={V} > 150, R={N:,} < 5K: FAMD (50-100 dims)"
            elif N <= 10_000:
                selected = PATH_SDAE if V > 200 else PATH_FAMD
                dims = target_dims or 50
                reason = f"V={V} > 150, R={N:,} (5K-10K): {'SDAE' if V > 200 else 'FAMD'}"
            else:
                # R > 10K, V > 150:
                if V > 300 and N > 20_000:
                    selected = PATH_SDAE
                    dims = target_dims or 50
                    reason = f"V={V} > 300, R={N:,} > 20K: SDAE ⭐ optimal (deep learning)"
                elif cat_ratio < 0.1:
                    selected = PATH_UMAP_MIXED
                    dims = target_dims or 30
                    reason = f"V={V} > 150, R={N:,} > 10K, low cat: UMAP Mixed"
                else:
                    selected = PATH_FAMD
                    dims = target_dims or 100
                    reason = f"V={V} > 150, R={N:,} > 10K, mixed types: FAMD (100)"

        result.agent_selection = {
            "mode": "DECIDE",
            "N": N, "V": V, "RxV": N * V,
            "n_categorical": n_cat,
            "cat_ratio": cat_ratio,
            "selected_path": selected,
            "selected_name": PATH_NAMES[selected],
            "target_dims": dims,
            "reason": reason,
        }
        result.step_log.append({
            "path": 9, "action": "Agent Decide",
            "delegated_to": selected,
            "target_dims": dims,
            "reason": reason,
        })
        logger.info(f"[Agent Decide] R={N:,} × V={V} → Path {selected} ({PATH_NAMES[selected]}), dims={dims}: {reason}")

        # Delegate to selected path
        dispatch = {
            PATH_NONE: lambda: self._path_none(X, features, result),
            PATH_MIXED_PCA: lambda: self._path_mixed_pca(X, features, encoding_map, dims, result),
            PATH_FAMD: lambda: self._path_famd(X, features, encoding_map, dims, result),
            PATH_UMAP_MIXED: lambda: self._path_umap_mixed(X, features, encoding_map, dims, result),
            PATH_UMAP_FULL: lambda: self._path_umap_full(X, features, dims, result),
            PATH_SDAE: lambda: self._path_sdae(X, features, dims, result),
        }
        return dispatch.get(selected, lambda: self._path_none(X, features, result))()
