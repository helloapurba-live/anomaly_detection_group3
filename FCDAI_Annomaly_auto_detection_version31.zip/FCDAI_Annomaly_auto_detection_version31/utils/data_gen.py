
import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from pathlib import Path
import logging

# Configure logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("DataGen")

# ── Name pools for realistic customer names ──────────────────────────────────
FIRST_NAMES = [
    "James", "Mary", "Robert", "Jennifer", "John", "Linda", "Michael", "Sarah",
    "David", "Jessica", "William", "Emily", "Richard", "Amanda", "Joseph", "Rachel",
    "Thomas", "Laura", "Christopher", "Megan", "Daniel", "Hannah", "Matthew", "Olivia",
    "Andrew", "Sophia", "Joshua", "Emma", "Anthony", "Grace", "Kevin", "Chloe",
    "Raj", "Priya", "Wei", "Mei", "Ahmed", "Fatima", "Carlos", "Maria",
]
LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
    "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson",
    "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson",
    "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson",
    "Patel", "Chen", "Wang", "Kim", "Nguyen", "Singh", "Kumar", "Ali", "Abbas", "Tanaka",
]


class DataGenerator:
    """
    V20 Data Generator — 14 tables for full AML coverage.
    Tables: Transactions, Customer (Party), Account, Alert, Case, KYC,
            Watchlist, Relationships (Edges + Nodes), Temporal (Long + Wide)
    """

    def __init__(self, seed: int = 42):
        np.random.seed(seed)
        random.seed(seed)

    def generate_party_data(self, num_parties: int = 100) -> pd.DataFrame:
        """Generates Party/Customer metadata with realistic names."""
        ids = [f"CUST_{i:06d}" for i in range(num_parties)]
        types = np.random.choice(['Individual', 'Corporate', 'Trust'], num_parties, p=[0.7, 0.2, 0.1])
        risk_ratings = np.random.choice(['Low', 'Medium', 'High'], num_parties, p=[0.6, 0.3, 0.1])
        countries = np.random.choice(['US', 'UK', 'SG', 'KY', 'VG', 'DE', 'JP', 'IN'], num_parties)

        # Generate realistic customer names
        names = [
            f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"
            for _ in range(num_parties)
        ]

        df = pd.DataFrame({
            'party_id': ids,
            'customer_name': names,
            'party_type': types,
            'risk_rating': risk_ratings,
            'country_of_origin': countries,
            'kyc_status': np.random.choice(['Verified', 'Pending', 'Expired'], num_parties, p=[0.75, 0.15, 0.10]),
            'onboarding_date': [datetime.now() - timedelta(days=random.randint(10, 3650)) for _ in range(num_parties)]
        })
        logger.info(f"Generated {len(df)} Party/Customer records.")
        return df

    def generate_account_data(self, party_ids: List[str]) -> pd.DataFrame:
        """Generates Account data linked to Parties."""
        num_accounts = int(len(party_ids) * 1.5)
        acc_ids = [f"ACC_{i:09d}" for i in range(num_accounts)]
        owners = np.random.choice(party_ids, num_accounts)

        df = pd.DataFrame({
            'account_id': acc_ids,
            'party_id': owners,
            'account_type': np.random.choice(['Savings', 'Current', 'Corporate', 'Investment'], num_accounts),
            'status': np.random.choice(['Active', 'Dormant', 'Frozen'], num_accounts, p=[0.9, 0.08, 0.02]),
            'currency': np.random.choice(['USD', 'EUR', 'GBP', 'SGD'], num_accounts),
            'balance': np.random.exponential(25000, num_accounts).astype(np.float32).round(2),
            'open_date': [datetime.now() - timedelta(days=random.randint(10, 2000)) for _ in range(num_accounts)]
        })
        logger.info(f"Generated {len(df)} Account records.")
        return df

    def generate_transactions(self, account_ids: List[str], num_txns: int = 1000) -> pd.DataFrame:
        """Generates core Transaction ledger."""
        df = pd.DataFrame({
            'txn_id': [f"TXN_{i:09d}" for i in range(num_txns)],
            'account_id': np.random.choice(account_ids, num_txns),
            'counterparty_account': [f"EXT_{random.randint(1000,9999)}" for _ in range(num_txns)],
            'amount': np.random.exponential(1000, num_txns).astype(np.float32).round(2),
            'currency': 'USD',
            'txn_type': np.random.choice(['Wire', 'ACH', 'Cash', 'Check'], num_txns),
            'timestamp': [datetime.now() - timedelta(days=random.randint(0, 30), hours=random.randint(0, 23)) for _ in range(num_txns)],
            'is_credit': np.random.choice([True, False], num_txns)
        })

        # Derive customer_id from account_id
        df['customer_id'] = df['account_id'].apply(
            lambda x: f"CUST_{int(x.split('_')[1]) // 2:06d}" if '_' in str(x) else 'UNKNOWN'
        )
        # Add structuring anomalies (~2%)
        mask = np.random.random(num_txns) < 0.02
        df.loc[mask, 'amount'] = (9900 + np.random.uniform(0, 99, sum(mask))).astype(np.float32)

        logger.info(f"Generated {len(df)} Transaction records.")
        return df

    def generate_alert_data(self, party_ids: List[str], num_alerts: int = None) -> pd.DataFrame:
        """Generates historical Alert records linked to customers."""
        if num_alerts is None:
            num_alerts = max(20, int(len(party_ids) * 0.3))
        df = pd.DataFrame({
            'alert_id': [f"ALT_{i:06d}" for i in range(num_alerts)],
            'party_id': np.random.choice(party_ids, num_alerts),
            'alert_type': np.random.choice(
                ['Structuring', 'Rapid Movement', 'Large Cash', 'Wire Pattern',
                 'Dormant Activation', 'Sanctions Hit', 'Unusual Volume'],
                num_alerts
            ),
            'severity': np.random.choice(['Critical', 'High', 'Medium', 'Low'], num_alerts, p=[0.05, 0.15, 0.40, 0.40]),
            'status': np.random.choice(['Open', 'Investigating', 'Escalated', 'Closed'], num_alerts, p=[0.25, 0.20, 0.10, 0.45]),
            'created_at': [datetime.now() - timedelta(days=random.randint(0, 90)) for _ in range(num_alerts)],
            'assigned_to': np.random.choice(['Analyst_A', 'Analyst_B', 'Analyst_C', 'Unassigned'], num_alerts),
        })
        logger.info(f"Generated {len(df)} Alert records.")
        return df

    def generate_case_data(self, party_ids: List[str], num_cases: int = None) -> pd.DataFrame:
        """Generates Case/Investigation records linked to customers."""
        if num_cases is None:
            num_cases = max(10, int(len(party_ids) * 0.05))
        df = pd.DataFrame({
            'case_id': [f"CASE_{i:06d}" for i in range(num_cases)],
            'party_id': np.random.choice(party_ids, num_cases),
            'case_type': np.random.choice(['Regulatory Filing', 'STR', 'Internal Review', 'Regulatory'], num_cases),
            'status': np.random.choice(['Open', 'In Progress', 'Closed - Filed', 'Closed - No Action'], num_cases, p=[0.20, 0.30, 0.25, 0.25]),
            'priority': np.random.choice(['P1', 'P2', 'P3'], num_cases, p=[0.15, 0.35, 0.50]),
            'opened_date': [datetime.now() - timedelta(days=random.randint(0, 180)) for _ in range(num_cases)],
            'investigator': np.random.choice(['Inv_Senior', 'Inv_Lead', 'Inv_Junior'], num_cases),
        })
        logger.info(f"Generated {len(df)} Case records.")
        return df

    def generate_kyc_data(self, party_ids: List[str]) -> pd.DataFrame:
        """Generates KYC review records per customer."""
        df = pd.DataFrame({
            'kyc_id': [f"KYC_{i:06d}" for i in range(len(party_ids))],
            'party_id': party_ids,
            'verification_status': np.random.choice(
                ['Verified', 'Pending Review', 'Expired', 'Failed'],
                len(party_ids), p=[0.70, 0.15, 0.10, 0.05]
            ),
            'risk_score': np.random.uniform(0, 1, len(party_ids)).round(3),
            'last_review': [datetime.now() - timedelta(days=random.randint(0, 365)) for _ in range(len(party_ids))],
            'next_review': [datetime.now() + timedelta(days=random.randint(30, 365)) for _ in range(len(party_ids))],
            'doc_type': np.random.choice(['Passport', 'Driving License', 'National ID', 'Utility Bill'], len(party_ids)),
            'reviewer': np.random.choice(['KYC_Team_1', 'KYC_Team_2', 'Auto_Verified'], len(party_ids)),
        })
        logger.info(f"Generated {len(df)} KYC records.")
        return df

    def generate_watchlist_data(self, size: int = 50) -> pd.DataFrame:
        """Generates Sanctions/Watchlist data."""
        df = pd.DataFrame({
            'watchlist_id': [f"WL_{i:05d}" for i in range(size)],
            'entity_name': [f"Bad Actor {i}" for i in range(size)],
            'list_source': np.random.choice(['OFAC', 'UN', 'EU', 'HM_TREASURY'], size),
            'category': np.random.choice(['Sanctions', 'PEP', 'Adverse Media'], size),
            'added_date': [datetime.now() - timedelta(days=random.randint(1, 1000)) for _ in range(size)]
        })
        return df

    def generate_relationship_data(self, party_ids: List[str], count: int = 200) -> Dict[str, pd.DataFrame]:
        """
        V20: Generates relationship/graph data as TWO sheets — edges + nodes.

        Returns dict with:
          'edges': DataFrame(source, target, weight, relationship_type,
                             transaction_date, shared_attributes)
          'nodes': DataFrame(node_id, label, node_type, risk_score,
                             country, total_transactions)
        """
        # ── Build EDGES ──────────────────────────────────────────────
        n = min(count, len(party_ids) * 3)
        rel_types = ['Director', 'Shareholder', 'Signatory', 'Guarantor',
                     'Beneficial Owner', 'Authorized Signatory', 'Joint Account Holder',
                     'Power of Attorney', 'Trustee', 'Nominee']
        countries = ['US', 'UK', 'SG', 'KY', 'VG', 'DE', 'JP', 'IN']
        node_types = ['INDIVIDUAL', 'BUSINESS', 'PEP', 'HIGH_RISK']

        sources = np.random.choice(party_ids, n)
        targets = np.random.choice(party_ids, n)

        shared_pool = ['common_address', 'same_phone', 'shared_employer',
                       'same_ip_address', 'linked_business', 'family_tie',
                       'co_signatory', 'shared_beneficiary']

        edges_df = pd.DataFrame({
            'source': sources,
            'target': targets,
            'weight': np.random.uniform(0.1, 1.0, n).round(3),
            'relationship_type': np.random.choice(rel_types, n),
            'transaction_date': pd.to_datetime([
                datetime.now() - timedelta(days=random.randint(1, 2000)) for _ in range(n)
            ]),
            'shared_attributes': [
                random.choice(shared_pool) for _ in range(n)
            ],
        })
        # Remove self-loops
        edges_df = edges_df[edges_df['source'] != edges_df['target']].reset_index(drop=True)

        # ── Build NODES from all unique nodes in edges ───────────────
        all_node_ids = sorted(set(edges_df['source'].unique()) | set(edges_df['target'].unique()))
        num_nodes = len(all_node_ids)

        # Compute total_transactions per node (count of edges where node is source or target)
        src_counts = edges_df['source'].value_counts()
        tgt_counts = edges_df['target'].value_counts()
        total_txns = (src_counts.add(tgt_counts, fill_value=0)).fillna(0)

        nodes_df = pd.DataFrame({
            'node_id': all_node_ids,
            'label': [f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}" for _ in range(num_nodes)],
            'node_type': np.random.choice(node_types, num_nodes, p=[0.55, 0.30, 0.08, 0.07]),
            'risk_score': np.random.uniform(0.0, 1.0, num_nodes).round(3),
            'country': np.random.choice(countries, num_nodes),
            'total_transactions': [int(total_txns.get(nid, 0)) for nid in all_node_ids],
        })

        logger.info(f"Generated Relationship data: {len(edges_df)} edges, {len(nodes_df)} nodes.")
        return {"edges": edges_df, "nodes": nodes_df}

    def generate_temporal_data(self, party_ids: List[str], months: int = 6) -> Dict[str, pd.DataFrame]:
        """
        V20: Generates time-series data in BOTH long and wide formats.

        Long schema:  cust_id | period_date | amount | transaction_count
        Wide schema:  cust_id | month_YYYY_MM | month_YYYY_MM | ...  (amount pivoted)

        Returns dict with:
          'long': DataFrame with above long schema
          'wide': DataFrame with above wide schema (one row per customer)
        """
        records = []

        # Generate 'months' periods ending at current month
        base_date = datetime.now()
        periods = []
        for m in range(months - 1, -1, -1):
            dt = base_date - timedelta(days=30 * m)
            periods.append(dt.strftime('%Y-%m'))

        for cust_id in party_ids:
            base_amount = random.uniform(2000, 80000)
            base_txn = random.randint(10, 60)

            for i, period in enumerate(periods):
                # Seasonality + noise
                seasonal = 1.0 + 0.15 * np.sin(2 * np.pi * i / 12)
                noise = np.random.normal(1.0, 0.12)
                factor = seasonal * noise

                amount = round(base_amount * factor, 0)
                txn_count = max(1, int(base_txn * factor))

                # ~5% chance of anomaly spike
                if random.random() < 0.05:
                    amount = round(amount * random.uniform(5, 15), 0)
                    txn_count = int(txn_count * random.uniform(1.5, 3))

                records.append({
                    'cust_id': cust_id,
                    'period_date': period,
                    'amount': int(amount),
                    'transaction_count': txn_count,
                })

        long_df = pd.DataFrame(records)

        # ── Build WIDE from LONG: pivot amount by period_date ────────
        try:
            wide_df = long_df.pivot_table(
                index='cust_id', columns='period_date',
                values='amount', aggfunc='sum'
            ).reset_index()
            # Rename columns: '2025-01' → 'month_2025_01'
            wide_df.columns = [
                f"month_{c.replace('-', '_')}" if c != 'cust_id' else c
                for c in wide_df.columns
            ]
        except Exception:
            wide_df = long_df.copy()

        logger.info(f"Generated temporal data: LONG={len(long_df)} rows, WIDE={len(wide_df)} rows "
                     f"({len(party_ids)} customers × {months} months).")
        return {"long": long_df, "wide": wide_df}

    def generate_full_schema(self, num_customers: int = 100) -> Dict[str, pd.DataFrame]:
        """
        V20: Orchestrates generation of all 14 data tables + 10 config tables.

        Returns dict with keys:
            14 Data tables: BASE, transactions, customer_party, accounts, alerts,
                cases, kyc, watchlist, relationships_edges, relationships_nodes,
                temporal_long, temporal_wide, others1, others2
            10 Config tables: EXCLUDE, FEATURE_MAP, TABLE_MAP, METHOD_CONFIG,
                ALGO_FEATURE_MAP, FEATURE_STORE, METADATA, CUSTOM_CONFIG,
                TABLE_GRAIN_DETECTION, FEATURE_ENGINEERING
        """
        logger.info(f"Generating schema for {num_customers} customers...")

        # 1. Parties / Customers
        parties = self.generate_party_data(num_customers)
        party_ids = parties['party_id'].tolist()

        # 2. Accounts (1.5x per customer)
        accounts = self.generate_account_data(party_ids)
        account_ids = accounts['account_id'].tolist()

        # 3. Transactions (20 per account)
        avg_txns_per_acct = 20
        total_txns = len(account_ids) * avg_txns_per_acct
        txns = self.generate_transactions(account_ids, total_txns)

        # 4. Alerts (~30% of customers)
        alerts = self.generate_alert_data(party_ids)

        # 5. Cases (~5% of customers)
        cases = self.generate_case_data(party_ids)

        # 6. KYC (1 per customer)
        kyc = self.generate_kyc_data(party_ids)

        # 7. Watchlist (fixed size)
        wl_size = min(1000, max(50, int(num_customers * 0.01)))
        watchlist = self.generate_watchlist_data(wl_size)

        # 8. Relationships — V20: TWO sheets (edges + nodes)
        rel_count = int(num_customers * 2)
        rel_data = self.generate_relationship_data(party_ids, rel_count)
        # rel_data is dict: {"edges": df, "nodes": df}

        # ── Build cross-table mappings for BASE & temporal ─────────
        acct_party_map = accounts[['account_id', 'party_id']].copy()
        txn_with_party = txns.merge(acct_party_map, on='account_id', how='left')

        # 9. BASE — Customer-level aggregated entity table
        txn_agg = txn_with_party.groupby('party_id').agg(
            total_transactions=('txn_id', 'count'),
            total_amount=('amount', 'sum'),
            avg_amount=('amount', 'mean'),
            max_amount=('amount', 'max'),
        ).reset_index()

        acct_agg = accounts.groupby('party_id').agg(
            account_count=('account_id', 'count'),
            total_balance=('balance', 'sum'),
        ).reset_index()

        alert_agg = alerts.groupby('party_id').agg(
            alert_count=('alert_id', 'count'),
        ).reset_index()

        case_agg = cases.groupby('party_id').agg(
            case_count=('case_id', 'count'),
        ).reset_index()

        base = parties[['party_id', 'customer_name', 'party_type',
                          'risk_rating', 'country_of_origin', 'kyc_status']].copy()
        base = base.rename(columns={'party_id': 'cust_id'})
        base = base.merge(txn_agg.rename(columns={'party_id': 'cust_id'}), on='cust_id', how='left')
        base = base.merge(acct_agg.rename(columns={'party_id': 'cust_id'}), on='cust_id', how='left')
        base = base.merge(alert_agg.rename(columns={'party_id': 'cust_id'}), on='cust_id', how='left')
        base = base.merge(case_agg.rename(columns={'party_id': 'cust_id'}), on='cust_id', how='left')
        base = base.fillna(0)
        for int_col in ['total_transactions', 'account_count', 'alert_count', 'case_count']:
            if int_col in base.columns:
                base[int_col] = base[int_col].astype(int)
        logger.info(f"Generated BASE table: {len(base)} customers, {len(base.columns)} features.")

        # 10. Temporal — V20: TWO sheets (long + wide)
        temporal_data = self.generate_temporal_data(party_ids, months=6)
        # temporal_data is dict: {"long": df, "wide": df}
        logger.info(f"Generated temporal data: long={len(temporal_data['long'])} rows, wide={len(temporal_data['wide'])} rows.")

        # 11. Others1 - Additional custom data
        others1_df = pd.DataFrame({
            'party_id': party_ids[:min(50, len(party_ids))],
            'custom_field_1': np.random.choice(['TypeA', 'TypeB', 'TypeC'], min(50, len(party_ids))),
            'custom_score': np.random.uniform(0, 100, min(50, len(party_ids))),
            'custom_date': pd.date_range(end=pd.Timestamp.now(), periods=min(50, len(party_ids))),
        })

        # 12. Others2 - Additional custom data  
        others2_df = pd.DataFrame({
            'party_id': party_ids[:min(30, len(party_ids))],
            'external_id': [f'EXT_{i:06d}' for i in range(min(30, len(party_ids)))],
            'rating': np.random.randint(1, 6, min(30, len(party_ids))),
            'notes': [f'Note {i}' for i in range(min(30, len(party_ids)))],
        })

        logger.info("Schema generation complete — 14 data tables (incl. 2×relationships, 2×temporal).")

        # ──────────────────────────────────────────────────────────────
        # V20: GENERATE 10 CONFIG TABLES (sample defaults)
        # ──────────────────────────────────────────────────────────────
        configs = self._generate_config_tables(base)

        result = {
            "BASE": base,
            "transactions": txns,
            "customer_party": parties,
            "accounts": accounts,
            "alerts": alerts,
            "cases": cases,
            "kyc": kyc,
            "watchlist": watchlist,
            # V20: Relationships — two sheets
            "relationships_edges": rel_data["edges"],
            "relationships_nodes": rel_data["nodes"],
            # V20: Temporal — two sheets
            "temporal_long": temporal_data["long"],
            "temporal_wide": temporal_data["wide"],
            "others1": others1_df,
            "others2": others2_df,
        }
        result.update(configs)
        return result

    def _generate_config_tables(self, base_df: pd.DataFrame) -> Dict[str, pd.DataFrame]:
        """V20: Generate sample config tables for all 10 CONFIG_SLOTS."""
        configs = {}

        # 1. EXCLUDE — columns/tables to exclude
        configs["EXCLUDE"] = pd.DataFrame({
            'feature_name': ['ssn', 'email', 'phone', 'account_number', 'internal_id',
                             'sys_timestamp', 'audit_trail_id', 'temp_flag'],
            'reason': ['PII', 'PII', 'PII', 'PII', 'System ID',
                       'System Field', 'System Field', 'Temp Field'],
            'scope': ['column', 'column', 'column', 'column', 'column',
                      'column', 'column', 'column'],
        })

        # 2. FEATURE_MAP — column renames + transformations
        configs["FEATURE_MAP"] = pd.DataFrame({
            'original_column': ['total_amount', 'avg_amount', 'max_amount', 'total_balance',
                                'alert_count', 'case_count', 'custom_score', 'risk_score'],
            'new_name': ['total_amt_log', 'avg_amt_log', 'max_amt_log', 'balance_log',
                         'alert_cnt', 'case_cnt', 'custom_score_sqrt', 'risk_score_norm'],
            'transformation': ['LOG', 'LOG', 'LOG', 'LOG', 'NONE', 'NONE', 'SQRT', 'MINMAX'],
        })

        # 3. TABLE_MAP — join keys and join types per table
        configs["TABLE_MAP"] = pd.DataFrame({
            'target_table': ['transactions', 'customer_party', 'accounts', 'alerts',
                             'cases', 'kyc', 'watchlist', 'others1', 'others2'],
            'target_key': ['party_id', 'party_id', 'party_id', 'party_id',
                           'party_id', 'party_id', 'entity_name', 'party_id', 'party_id'],
            'join_type': ['left', 'left', 'left', 'left', 'left', 'left', 'left', 'left', 'left'],
            'optional': [True, True, True, True, True, True, True, True, True],
        })

        # 4. METHOD_CONFIG — anomaly detection algorithms & weights
        configs["METHOD_CONFIG"] = pd.DataFrame({
            'algorithm': ['IsolationForest', 'LocalOutlierFactor', 'DBSCAN',
                          'StatisticalZScore', 'RuleBased', 'EnsembleVoting'],
            'weight': [0.25, 0.20, 0.15, 0.15, 0.15, 0.10],
            'enabled': [True, True, True, True, True, True],
            'contamination': [0.05, 0.05, None, 0.05, None, None],
            'threshold': [None, None, None, 3.0, None, 0.5],
        })

        # 5. ALGO_FEATURE_MAP — required features per algorithm
        algo_features = []
        feature_cols = [c for c in base_df.columns if base_df[c].dtype in ['int64', 'float64', 'float32', 'int32']]
        for algo in ['IsolationForest', 'LocalOutlierFactor', 'DBSCAN', 'StatisticalZScore']:
            for feat in feature_cols[:8]:
                algo_features.append({'algorithm': algo, 'feature': feat, 'required': True})
        configs["ALGO_FEATURE_MAP"] = pd.DataFrame(algo_features)

        # 6. FEATURE_STORE — feature metadata
        feature_store = []
        for col in base_df.columns:
            dtype = str(base_df[col].dtype)
            is_pii = col.lower() in ['customer_name', 'ssn', 'email', 'phone']
            feature_store.append({
                'feature_name': col,
                'data_type': 'numeric' if 'int' in dtype or 'float' in dtype else 'categorical',
                'description': f"Feature: {col}",
                'is_pii': is_pii,
                'source_table': 'BASE',
                'format': dtype,
            })
        configs["FEATURE_STORE"] = pd.DataFrame(feature_store)

        # 7. METADATA — system parameters
        configs["METADATA"] = pd.DataFrame({
            'parameter': ['base_key', 'default_grain', 'pii_masking_enabled',
                          'max_memory_gb', 'max_workers', 'export_format',
                          'log_level', 'audit_enabled', 'run_version'],
            'value': ['cust_id', 'customer', 'true', '8', '4', 'csv',
                      'INFO', 'true', '1.0'],
            'description': ['Primary key column', 'Default grain level', 'Enable PII masking',
                            'Max memory (GB)', 'Max parallel workers', 'Export format',
                            'Logging level', 'Enable audit trail', 'Run version'],
        })

        # 8. CUSTOM_CONFIG — user-defined key-value settings
        configs["CUSTOM_CONFIG"] = pd.DataFrame({
            'key': ['dashboard_theme', 'pagination_size', 'auto_refresh',
                    'alert_threshold', 'report_format', 'notification_email'],
            'value': ['dark', '20', 'true', '0.85', 'pdf', 'admin@bank.com'],
            'category': ['UI', 'UI', 'System', 'Detection', 'Reporting', 'Notification'],
        })

        # 9. TABLE_GRAIN_DETECTION — rollup strategy per table
        configs["TABLE_GRAIN_DETECTION"] = pd.DataFrame({
            'table_name': ['transactions', 'customer_party', 'accounts', 'alerts',
                           'cases', 'kyc', 'watchlist', 'others1', 'others2'],
            'rollup_strategy': ['AGGREGATE', 'DIRECT', 'AGGREGATE', 'AGGREGATE',
                                'AGGREGATE', 'TAKE_LATEST', 'AGGREGATE', 'AUTO_DETECT', 'AUTO_DETECT'],
            'native_grain': ['transaction', 'customer', 'account', 'alert',
                             'case', 'kyc_record', 'match', 'custom', 'custom'],
            'target_grain': ['customer'] * 9,
        })

        # 10. FEATURE_ENGINEERING — aggregation & derived features
        configs["FEATURE_ENGINEERING"] = pd.DataFrame({
            'source_column': ['amount', 'amount', 'amount', 'amount',
                              'balance', 'balance', 'alert_id', 'case_id',
                              'txn_type', 'is_credit'],
            'aggregation': ['SUM', 'AVG', 'MAX', 'COUNT',
                            'SUM', 'AVG', 'COUNT', 'COUNT',
                            'MODE', 'SUM'],
            'output_name': ['total_amount', 'avg_amount', 'max_amount', 'txn_count',
                            'total_balance', 'avg_balance', 'alert_count', 'case_count',
                            'most_common_txn_type', 'credit_transaction_count'],
            'source_table': ['transactions', 'transactions', 'transactions', 'transactions',
                             'accounts', 'accounts', 'alerts', 'cases',
                             'transactions', 'transactions'],
        })

        logger.info(f"Generated 10 config tables.")
        return configs


if __name__ == "__main__":
    dg = DataGenerator()
    data = dg.generate_full_schema(100)
    for k, v in data.items():
        print(f"{k}: {v.shape}")
