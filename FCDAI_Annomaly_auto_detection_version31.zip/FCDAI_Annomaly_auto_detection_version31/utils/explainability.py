"""
AIM AI Vault V14 — SHAP Explainability Module
===================================================
Local feature importance explanations for anomaly alerts.
Provides interpretable "Why" for each flagged transaction.

Author: AIM AI Vault Team
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import warnings

warnings.filterwarnings('ignore')


class LocalExplainer:
    """
    SHAP-style local explainer for anomaly detection.
    Uses permutation-based importance for model-agnostic explanations.
    """
    
    def __init__(
        self,
        n_samples: int = 100,
        random_state: int = 42
    ):
        self.n_samples = n_samples
        self.random_state = random_state
        self.feature_names_: List[str] = []
        self.baseline_score_ = None
    
    def _permutation_importance(
        self,
        model: Any,
        X: np.ndarray,
        instance_idx: int
    ) -> np.ndarray:
        """Calculate permutation-based feature importance for a single instance."""
        np.random.seed(self.random_state)
        
        instance = X[instance_idx:instance_idx + 1]
        base_score = model.decision_function(instance)[0]
        
        importances = np.zeros(X.shape[1])
        
        for feature_idx in range(X.shape[1]):
            scores = []
            
            for _ in range(min(self.n_samples, len(X))):
                # Create perturbed instance
                perturbed = instance.copy()
                # Replace with random value from dataset
                random_idx = np.random.randint(0, len(X))
                perturbed[0, feature_idx] = X[random_idx, feature_idx]
                
                # Get new score
                new_score = model.decision_function(perturbed)[0]
                scores.append(new_score)
            
            # Importance = difference in score when feature is permuted
            importances[feature_idx] = base_score - np.mean(scores)
        
        return importances
    
    def explain_instance(
        self,
        model: Any,
        X: np.ndarray,
        instance_idx: int,
        feature_names: Optional[List[str]] = None
    ) -> Dict[str, float]:
        """
        Explain a single instance's anomaly score.
        
        Returns:
            Dictionary mapping feature names to their contribution to the anomaly score.
        """
        if feature_names is None:
            feature_names = [f"Feature_{i}" for i in range(X.shape[1])]
        
        self.feature_names_ = feature_names
        
        importances = self._permutation_importance(model, X, instance_idx)
        
        return dict(zip(feature_names, importances))
    
    def explain_batch(
        self,
        model: Any,
        X: np.ndarray,
        instance_indices: List[int],
        feature_names: Optional[List[str]] = None,
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Explain multiple instances.
        
        Returns:
            List of explanation dictionaries with top contributing features.
        """
        explanations = []
        
        for idx in instance_indices:
            importance = self.explain_instance(model, X, idx, feature_names)
            
            # Sort by absolute importance
            sorted_features = sorted(
                importance.items(),
                key=lambda x: abs(x[1]),
                reverse=True
            )[:top_k]
            
            explanations.append({
                'instance_idx': idx,
                'anomaly_score': model.decision_function(X[idx:idx + 1])[0],
                'top_features': dict(sorted_features),
                'explanation_text': self._generate_explanation_text(sorted_features)
            })
        
        return explanations
    
    def _generate_explanation_text(
        self,
        sorted_features: List[Tuple[str, float]]
    ) -> str:
        """Generate human-readable explanation text."""
        if not sorted_features:
            return "No significant contributing factors identified."
        
        parts = []
        for feature, importance in sorted_features[:3]:
            if importance > 0:
                parts.append(f"High {feature.replace('_', ' ')}")
            else:
                parts.append(f"Low {feature.replace('_', ' ')}")
        
        return "Alert triggered by: " + ", ".join(parts)


class FeatureContributionAnalyzer:
    """
    Analyze feature contributions across the dataset.
    Provides global explanations and feature ranking.
    """
    
    def __init__(self, random_state: int = 42):
        self.random_state = random_state
        self.global_importance_: Dict[str, float] = {}
        self.feature_stats_: Dict[str, Dict] = {}
    
    def fit(
        self,
        model: Any,
        X: np.ndarray,
        feature_names: Optional[List[str]] = None,
        n_samples: int = 500
    ) -> 'FeatureContributionAnalyzer':
        """
        Compute global feature importance by aggregating local explanations.
        """
        if feature_names is None:
            feature_names = [f"Feature_{i}" for i in range(X.shape[1])]
        
        explainer = LocalExplainer(random_state=self.random_state)
        
        # Sample indices for efficiency
        np.random.seed(self.random_state)
        sample_size = min(n_samples, len(X))
        sample_indices = np.random.choice(len(X), sample_size, replace=False)
        
        # Aggregate importances
        all_importances = {name: [] for name in feature_names}
        
        for idx in sample_indices:
            importance = explainer.explain_instance(model, X, idx, feature_names)
            for name, imp in importance.items():
                all_importances[name].append(imp)
        
        # Compute global importance (mean absolute importance)
        self.global_importance_ = {
            name: np.mean(np.abs(imps))
            for name, imps in all_importances.items()
        }
        
        # Compute feature statistics
        for i, name in enumerate(feature_names):
            self.feature_stats_[name] = {
                'mean': np.mean(X[:, i]),
                'std': np.std(X[:, i]),
                'min': np.min(X[:, i]),
                'max': np.max(X[:, i]),
                'importance': self.global_importance_[name]
            }
        
        return self
    
    def get_top_features(self, n: int = 10) -> List[Tuple[str, float]]:
        """Get top N most important features."""
        sorted_features = sorted(
            self.global_importance_.items(),
            key=lambda x: x[1],
            reverse=True
        )
        return sorted_features[:n]
    
    def get_feature_report(self) -> pd.DataFrame:
        """Generate a feature analysis report."""
        if not self.feature_stats_:
            return pd.DataFrame()
        
        report = pd.DataFrame(self.feature_stats_).T
        report.index.name = 'feature'
        report = report.sort_values('importance', ascending=False)
        
        return report


class AnomalyReasoner:
    """
    High-level reasoner that generates structured explanations
    for anomaly alerts suitable for compliance/audit purposes.
    """
    
    RISK_FACTORS = {
        'amount': 'Transaction amount significantly deviates from baseline',
        'velocity': 'Unusual transaction frequency detected',
        'location': 'Geographic pattern inconsistent with customer profile',
        'time': 'Transaction timing falls outside normal operating hours',
        'counterparty': 'Counterparty exhibits high-risk characteristics',
        'pattern': 'Behavioral pattern deviates from established baseline'
    }
    
    def __init__(self):
        self.explainer = LocalExplainer()
    
    def generate_alert_reasoning(
        self,
        model: Any,
        X: np.ndarray,
        instance_idx: int,
        feature_names: List[str],
        original_data: Optional[pd.DataFrame] = None
    ) -> Dict[str, Any]:
        """
        Generate a comprehensive reasoning report for an alert.
        """
        # Get local explanation
        importance = self.explainer.explain_instance(model, X, instance_idx, feature_names)
        
        # Sort by absolute importance
        sorted_features = sorted(
            importance.items(),
            key=lambda x: abs(x[1]),
            reverse=True
        )
        
        # Categorize risk factors
        categorized_risks = []
        for feature, imp in sorted_features[:5]:
            for category, description in self.RISK_FACTORS.items():
                if category.lower() in feature.lower():
                    categorized_risks.append({
                        'category': category.title(),
                        'feature': feature,
                        'contribution': imp,
                        'description': description,
                        'direction': 'HIGH' if imp > 0 else 'LOW'
                    })
                    break
            else:
                categorized_risks.append({
                    'category': 'Other',
                    'feature': feature,
                    'contribution': imp,
                    'description': f'{feature} contributes to anomaly score',
                    'direction': 'HIGH' if imp > 0 else 'LOW'
                })
        
        # Generate narrative
        narrative = self._generate_narrative(categorized_risks)
        
        return {
            'instance_idx': instance_idx,
            'anomaly_score': model.decision_function(X[instance_idx:instance_idx + 1])[0],
            'risk_factors': categorized_risks,
            'narrative': narrative,
            'feature_importance': dict(sorted_features),
            'confidence': self._calculate_confidence(sorted_features)
        }
    
    def _generate_narrative(self, risks: List[Dict]) -> str:
        """Generate human-readable narrative."""
        if not risks:
            return "No significant risk factors identified."
        
        parts = []
        for risk in risks[:3]:
            parts.append(
                f"{risk['direction']} {risk['category']}: {risk['description']}"
            )
        
        return "ALERT REASONING: " + "; ".join(parts) + "."
    
    def _calculate_confidence(self, sorted_features: List[Tuple[str, float]]) -> str:
        """Calculate confidence level based on feature importance distribution."""
        if not sorted_features:
            return "LOW"
        
        top_contribution = abs(sorted_features[0][1])
        total_contribution = sum(abs(imp) for _, imp in sorted_features)
        
        if total_contribution == 0:
            return "LOW"
        
        concentration = top_contribution / total_contribution
        
        if concentration > 0.5:
            return "HIGH"
        elif concentration > 0.3:
            return "MEDIUM"
        else:
            return "LOW"


def generate_shap_summary_plot_data(
    model: Any,
    X: np.ndarray,
    feature_names: List[str],
    n_samples: int = 200
) -> pd.DataFrame:
    """
    Generate data for SHAP-style summary plot.
    Returns DataFrame with feature, importance, and value for Plotly visualization.
    """
    np.random.seed(42)
    sample_size = min(n_samples, len(X))
    sample_indices = np.random.choice(len(X), sample_size, replace=False)
    
    explainer = LocalExplainer()
    
    records = []
    for idx in sample_indices:
        importance = explainer.explain_instance(model, X, idx, feature_names)
        
        for feat_idx, (name, imp) in enumerate(importance.items()):
            records.append({
                'feature': name,
                'importance': imp,
                'value': X[idx, feat_idx],
                'instance': idx
            })
    
    return pd.DataFrame(records)
