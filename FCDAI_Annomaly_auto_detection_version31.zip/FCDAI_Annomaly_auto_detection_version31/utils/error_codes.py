"""
AIM AI Vault V14 — Standardized Error Codes
=============================================
Enterprise error taxonomy for consistent error handling, logging,
and audit trail reporting.

Each error code encodes:
  - Category prefix (E = pipeline, D = data, A = auth, S = system, U = UI)
  - Severity suffix (numeric 001-999)

Author: AIM AI Vault Team
"""

from enum import Enum
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class ErrorDetail:
    """Immutable error detail for structured error responses."""
    code: str
    category: str
    severity: str        # CRITICAL | HIGH | MEDIUM | LOW
    message: str
    recovery_hint: str


class ErrorCode(Enum):
    """
    Centralized error code registry.

    Usage:
        from utils.error_codes import ErrorCode
        err = ErrorCode.E001_PIPELINE_NO_DATA
        raise PipelineError(err.value.code, err.value.message)
    """

    # ── PIPELINE ERRORS (E001–E099) ──────────────────────────────────────
    E001_PIPELINE_NO_DATA = ErrorDetail(
        "E001", "pipeline", "HIGH",
        "No non-empty source tables provided for pipeline execution",
        "Upload at least one data source via the Data Sources page",
    )
    E002_PIPELINE_LAYER_FAILED = ErrorDetail(
        "E002", "pipeline", "HIGH",
        "Pipeline layer execution failed",
        "Check system health page for resource constraints; retry with fewer methods",
    )
    E003_PIPELINE_TIMEOUT = ErrorDetail(
        "E003", "pipeline", "MEDIUM",
        "Pipeline execution exceeded time limit",
        "Reduce dataset size or disable heavy detection methods",
    )
    E004_PIPELINE_CIRCUIT_OPEN = ErrorDetail(
        "E004", "pipeline", "MEDIUM",
        "Circuit breaker is open — layer temporarily disabled",
        "Wait for recovery timeout or manually reset via admin panel",
    )
    E005_PIPELINE_PARTIAL_RESULT = ErrorDetail(
        "E005", "pipeline", "LOW",
        "Pipeline completed with partial results (some methods excluded)",
        "Review execution log for skipped methods and their reasons",
    )

    # ── DATA ERRORS (D001–D099) ──────────────────────────────────────────
    D001_DATA_CORRUPT_PARQUET = ErrorDetail(
        "D001", "data", "HIGH",
        "Parquet file is corrupt or unreadable",
        "Re-import the source data or restore from last backup",
    )
    D002_DATA_SCHEMA_MISMATCH = ErrorDetail(
        "D002", "data", "HIGH",
        "Data schema does not match expected column roles",
        "Configure column mapping in Data Sources page",
    )
    D003_DATA_EMPTY_SOURCE = ErrorDetail(
        "D003", "data", "MEDIUM",
        "Source data table is empty after filtering",
        "Check data quality; ingested file may have no valid records",
    )
    D004_DATA_EXPORT_FAILED = ErrorDetail(
        "D004", "data", "MEDIUM",
        "Data export operation failed",
        "Verify disk space and write permissions in exports directory",
    )
    D005_DATA_PARTITION_ERROR = ErrorDetail(
        "D005", "data", "MEDIUM",
        "Parquet partition write failed",
        "Check disk space; ensure data/vault/runs/ directory is writable",
    )

    # ── AUTH ERRORS (A001–A099) ──────────────────────────────────────────
    A001_AUTH_INVALID_CREDS = ErrorDetail(
        "A001", "auth", "HIGH",
        "Invalid username or password",
        "Check credentials; contact administrator for password reset",
    )
    A002_AUTH_INSUFFICIENT_ROLE = ErrorDetail(
        "A002", "auth", "MEDIUM",
        "User role does not have permission for this action",
        "Contact administrator to upgrade role permissions",
    )
    A003_AUTH_SESSION_EXPIRED = ErrorDetail(
        "A003", "auth", "LOW",
        "User session has expired",
        "Log in again to continue",
    )

    # ── SYSTEM ERRORS (S001–S099) ─────────────────────────────────────────
    S001_DB_LOCKED = ErrorDetail(
        "S001", "system", "HIGH",
        "Database is locked — concurrent write conflict",
        "Retry automatically; if persistent, check for zombie processes",
    )
    S002_MEMORY_CRITICAL = ErrorDetail(
        "S002", "system", "CRITICAL",
        "System memory usage is critically high",
        "Reduce active dataset size or restart the application",
    )
    S003_DISK_CRITICAL = ErrorDetail(
        "S003", "system", "CRITICAL",
        "Disk space is critically low",
        "Free disk space; archive old run data or purge exports",
    )
    S004_CACHE_OVERFLOW = ErrorDetail(
        "S004", "system", "MEDIUM",
        "Background task cache exceeded size limit",
        "Clear stale cache entries via admin panel",
    )
    S005_CRYPTO_KEY_MISSING = ErrorDetail(
        "S005", "system", "CRITICAL",
        "Fernet encryption key file not found",
        "Generate new key via admin panel or check .vault_key file",
    )
    S006_WATCHDOG_ALERT = ErrorDetail(
        "S006", "system", "MEDIUM",
        "Watchdog detected resource threshold breach",
        "Review system health page for detailed metrics",
    )

    # ── UI ERRORS (U001–U099) ─────────────────────────────────────────────
    U001_CALLBACK_ERROR = ErrorDetail(
        "U001", "ui", "LOW",
        "Page callback failed to render",
        "Refresh the page; if persistent, check server logs",
    )
    U002_THEME_LOAD_FAILED = ErrorDetail(
        "U002", "ui", "LOW",
        "Theme CSS injection failed",
        "Reset theme to default via theme selector",
    )

    @property
    def code(self) -> str:
        return self.value.code

    @property
    def severity(self) -> str:
        return self.value.severity

    @property
    def message(self) -> str:
        return self.value.message

    @classmethod
    def by_code(cls, code: str) -> Optional["ErrorCode"]:
        """Lookup error by code string (e.g., 'E001')."""
        for member in cls:
            if member.value.code == code:
                return member
        return None

    @classmethod
    def by_category(cls, category: str):
        """Return all errors in a category."""
        return [m for m in cls if m.value.category == category]
