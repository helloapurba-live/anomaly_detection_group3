"""
AIM AI Vault V14 — System Watchdog
====================================
Background daemon thread that monitors system resources and
records metrics for the System Health dashboard.

Monitors:
  - CPU usage (per-process + system-wide)
  - Memory (RSS, available, percent)
  - Disk (free space, percent)
  - SQLite database size
  - Diskcache size
  - Pipeline status

All metrics stored in-memory (rolling window) and periodically
persisted to SQLite for historical analysis. Zero external
dependencies — uses only psutil (already required).

Author: AIM AI Vault Team
"""

import sys
import os
import time
import threading
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any
from collections import deque

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PATHS, WATCHDOG

_wd_logger = logging.getLogger("apurbadas.watchdog")


class SystemWatchdog:
    """
    Background watchdog thread for resource monitoring.

    Usage:
        watchdog = SystemWatchdog()
        watchdog.start()
        ...
        metrics = watchdog.get_latest_metrics()
        history = watchdog.get_metrics_history(minutes=60)
        ...
        watchdog.stop()
    """

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._metrics_history: deque = deque(maxlen=WATCHDOG.MAX_METRICS_HISTORY)
        self._latest: Dict[str, Any] = {}
        self._alerts: List[Dict] = []
        self._data_lock = threading.Lock()

    def start(self):
        """Start the watchdog background thread."""
        if not WATCHDOG.ENABLED:
            _wd_logger.info("[WATCHDOG] Disabled by configuration")
            return
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(
            target=self._monitor_loop,
            name="SystemWatchdog",
            daemon=True,
        )
        self._thread.start()
        _wd_logger.info("[WATCHDOG] Started — monitoring every %ds", WATCHDOG.CHECK_INTERVAL_SEC)

    def stop(self):
        """Stop the watchdog thread."""
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=5)
        _wd_logger.info("[WATCHDOG] Stopped")

    def _monitor_loop(self):
        """Main monitoring loop (runs in daemon thread)."""
        while self._running:
            try:
                metrics = self._collect_metrics()
                with self._data_lock:
                    self._latest = metrics
                    self._metrics_history.append(metrics)
                self._check_thresholds(metrics)
            except Exception as exc:
                _wd_logger.warning(f"[WATCHDOG] Collection error: {type(exc).__name__}")
            time.sleep(WATCHDOG.CHECK_INTERVAL_SEC)

    def _collect_metrics(self) -> Dict[str, Any]:
        """Collect all system metrics."""
        import psutil

        proc = psutil.Process(os.getpid())
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage(str(PATHS.BASE))

        # Database size
        db_path = PATHS.DATA / "sentinel_vault.db"
        db_size_mb = db_path.stat().st_size / (1024 * 1024) if db_path.exists() else 0.0

        # Cache size
        cache_path = PATHS.CACHE
        cache_size_mb = 0.0
        if cache_path.exists():
            try:
                cache_size_mb = sum(
                    f.stat().st_size for f in cache_path.rglob("*") if f.is_file()
                ) / (1024 * 1024)
            except Exception:
                pass

        # Pipeline status
        pipeline_running = False
        status_path = PATHS.DATA_VAULT / "pipeline_status.json"
        if status_path.exists():
            try:
                import json
                with open(status_path) as f:
                    st = json.load(f)
                pipeline_running = st.get("status") == "running"
            except Exception:
                pass

        return {
            "timestamp": datetime.now().isoformat(),
            "cpu_percent": proc.cpu_percent(interval=None),
            "cpu_system_percent": psutil.cpu_percent(interval=None),
            "memory_percent": mem.percent,
            "memory_used_mb": round(mem.used / (1024 * 1024), 1),
            "memory_available_mb": round(mem.available / (1024 * 1024), 1),
            "memory_rss_mb": round(proc.memory_info().rss / (1024 * 1024), 1),
            "disk_percent": disk.percent,
            "disk_free_gb": round(disk.free / (1024**3), 2),
            "disk_total_gb": round(disk.total / (1024**3), 2),
            "db_size_mb": round(db_size_mb, 2),
            "cache_size_mb": round(cache_size_mb, 2),
            "pipeline_running": pipeline_running,
            "thread_count": threading.active_count(),
            "open_files": len(proc.open_files()) if hasattr(proc, "open_files") else 0,
        }

    def _check_thresholds(self, metrics: Dict):
        """Check metrics against configured thresholds and raise alerts."""
        alerts = []

        # Memory
        mem_pct = metrics.get("memory_percent", 0)
        if mem_pct > WATCHDOG.MEMORY_CRITICAL_PERCENT:
            alerts.append({
                "severity": "CRITICAL",
                "component": "memory",
                "message": f"Memory usage critical: {mem_pct:.1f}%",
                "value": mem_pct,
                "threshold": WATCHDOG.MEMORY_CRITICAL_PERCENT,
            })
        elif mem_pct > WATCHDOG.MEMORY_WARN_PERCENT:
            alerts.append({
                "severity": "WARNING",
                "component": "memory",
                "message": f"Memory usage high: {mem_pct:.1f}%",
                "value": mem_pct,
                "threshold": WATCHDOG.MEMORY_WARN_PERCENT,
            })

        # Disk
        disk_pct = metrics.get("disk_percent", 0)
        if disk_pct > WATCHDOG.DISK_CRITICAL_PERCENT:
            alerts.append({
                "severity": "CRITICAL",
                "component": "disk",
                "message": f"Disk usage critical: {disk_pct:.1f}%",
                "value": disk_pct,
                "threshold": WATCHDOG.DISK_CRITICAL_PERCENT,
            })
        elif disk_pct > WATCHDOG.DISK_WARN_PERCENT:
            alerts.append({
                "severity": "WARNING",
                "component": "disk",
                "message": f"Disk usage high: {disk_pct:.1f}%",
                "value": disk_pct,
                "threshold": WATCHDOG.DISK_WARN_PERCENT,
            })

        # DB size
        db_mb = metrics.get("db_size_mb", 0)
        if db_mb > WATCHDOG.DB_SIZE_WARN_MB:
            alerts.append({
                "severity": "WARNING",
                "component": "database",
                "message": f"Database size: {db_mb:.1f} MB (threshold: {WATCHDOG.DB_SIZE_WARN_MB} MB)",
                "value": db_mb,
                "threshold": WATCHDOG.DB_SIZE_WARN_MB,
            })

        # Cache size
        cache_mb = metrics.get("cache_size_mb", 0)
        if cache_mb > WATCHDOG.CACHE_SIZE_WARN_MB:
            alerts.append({
                "severity": "WARNING",
                "component": "cache",
                "message": f"Cache size: {cache_mb:.1f} MB (threshold: {WATCHDOG.CACHE_SIZE_WARN_MB} MB)",
                "value": cache_mb,
                "threshold": WATCHDOG.CACHE_SIZE_WARN_MB,
            })

        if alerts:
            with self._data_lock:
                ts = datetime.now().isoformat()
                for a in alerts:
                    a["timestamp"] = ts
                self._alerts.extend(alerts)
                # Keep alerts bounded
                if len(self._alerts) > 500:
                    self._alerts = self._alerts[-250:]

            if WATCHDOG.LOG_METRICS:
                for a in alerts:
                    lvl = logging.CRITICAL if a["severity"] == "CRITICAL" else logging.WARNING
                    _wd_logger.log(lvl, f"[WATCHDOG] {a['message']}")

    # ── Public API ──────────────────────────────────────────────────────
    def get_latest_metrics(self) -> Dict[str, Any]:
        """Return the most recent metrics snapshot."""
        with self._data_lock:
            return dict(self._latest)

    def get_metrics_history(self, minutes: int = 60) -> List[Dict]:
        """Return metrics history for the last N minutes."""
        with self._data_lock:
            if not self._metrics_history:
                return []
            cutoff = time.time() - (minutes * 60)
            result = []
            for m in self._metrics_history:
                try:
                    ts = datetime.fromisoformat(m["timestamp"]).timestamp()
                    if ts >= cutoff:
                        result.append(dict(m))
                except Exception:
                    result.append(dict(m))
            return result

    def get_alerts(self, limit: int = 50) -> List[Dict]:
        """Return recent watchdog alerts."""
        with self._data_lock:
            return list(reversed(self._alerts[-limit:]))

    def clear_alerts(self):
        """Clear all watchdog alerts."""
        with self._data_lock:
            self._alerts.clear()

    def is_healthy(self) -> bool:
        """Quick health check — True if no CRITICAL alerts in last interval."""
        with self._data_lock:
            if not self._latest:
                return True
            mem = self._latest.get("memory_percent", 0)
            disk = self._latest.get("disk_percent", 0)
            return (mem < WATCHDOG.MEMORY_CRITICAL_PERCENT
                    and disk < WATCHDOG.DISK_CRITICAL_PERCENT)
