"""
FCDAI V14 — Data I/O Module
==============================
Handles multi-table source persistence, pipeline result persistence,
scored data, export with anomaly scorecards.

V14 Enhancements:
  - Parquet partitioning by run_id (data/vault/runs/<run_id>/scored.parquet)
  - Data versioning for scored datasets
  - Partition pruning for historical run access

V13 Fixes (retained):
  - B-4: Lazy loading — Parquet files loaded on demand, not at startup
  - C-2: Proper memory release on reload_from_disk()
  - F-4: Log on corrupt Parquet instead of bare except:pass
  - S-4: Cached scored data with TTL (avoids disk re-reads)

V10 Enhancements (retained):
  - SQLite sync: anomalies, data_imports, pipeline_runs written to DB
  - Polars fast CSV ingestion (fallback to pandas)
  - Anomaly confirmation workflow (investigator -> DB)

All data stored as Parquet in the vault directory + mirrored to SQLite.
"""

import os
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional, Tuple, List, Dict, Any
import pandas as pd
import numpy as np
import gc
import io
import base64
import json
import hashlib
import uuid

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import PATHS, PII, AUDIT, APP
from utils.logger import logger
from utils.memory import downcast_floats

# V10: Optional Polars for fast ingest
try:
    import polars as pl
    HAS_POLARS = True
except ImportError:
    HAS_POLARS = False


class DataVault:
    """
    Local Parquet-based data persistence layer.

    Stores:
      - Source tables  (vault/sources/<table>.parquet)
      - Merged analytical view (vault/current.parquet)
      - Scored data    (vault/scored.parquet)
      - Pipeline result JSON (vault/pipeline_result.json)
      - Import metadata (vault/metadata.json)
    """

    def __init__(self):
        self._current_data: Optional[pd.DataFrame] = None
        self._scored_data: Optional[pd.DataFrame] = None
        self._sources: Dict[str, pd.DataFrame] = {}
        self._metadata: Dict[str, Any] = {}
        self._pipeline_result: Dict[str, Any] = {}
        self._sources_loaded = False  # V13 B-4: Lazy flag
        # V13 B-4: Only load metadata at startup (lightweight)
        self._load_metadata_only()

    # -----------------------------------------------------------------
    # V13 B-4: Lightweight metadata-only load at startup
    # -----------------------------------------------------------------
    def _load_metadata_only(self):
        """Load only metadata.json at startup — Parquet loaded on demand."""
        meta_path = PATHS.DATA_VAULT / "metadata.json"
        if meta_path.exists():
            try:
                with open(meta_path, 'r') as f:
                    self._metadata = json.load(f)
            except Exception as e:
                logger.log_error(e, "Loading vault metadata")

    # -----------------------------------------------------------------
    # V8: Force reload from disk (fixes cross-page sync)
    # -----------------------------------------------------------------
    def reload_from_disk(self):
        """Re-read ALL vault data from disk. Call after subprocess writes.
        V13 C-2: Explicitly delete old DFs and run gc.collect()."""
        # C-2: Release old DataFrames before loading new ones
        old_refs = [self._current_data, self._scored_data]
        old_refs.extend(self._sources.values())
        self._current_data = None
        self._scored_data = None
        self._sources = {}
        self._metadata = {}
        self._pipeline_result = {}
        self._sources_loaded = False
        del old_refs
        gc.collect()
        self._load_persisted_data()

    # -----------------------------------------------------------------
    # Loading
    # -----------------------------------------------------------------
    def _load_persisted_data(self):
        """Load any previously persisted data from vault.
        V17 E1: Apply mask_for_memory() to all loaded DataFrames."""
        vault = PATHS.DATA_VAULT

        # Load raw/merged data
        vault_path = vault / "current.parquet"
        meta_path = vault / "metadata.json"
        scored_path = vault / "scored.parquet"
        result_path = vault / "pipeline_result.json"

        if vault_path.exists():
            try:
                self._current_data = pd.read_parquet(vault_path)
                # V17 E1: mask PII in memory view
                from utils.pii_masking import mask_for_memory
                self._current_data = mask_for_memory(self._current_data)
                if meta_path.exists():
                    with open(meta_path, 'r') as f:
                        self._metadata = json.load(f)
            except Exception as e:
                logger.log_error(e, "Loading persisted data")

        # Load scored data
        if scored_path.exists():
            try:
                self._scored_data = pd.read_parquet(scored_path)
                # V17 E1: mask PII in memory view
                from utils.pii_masking import mask_for_memory
                self._scored_data = mask_for_memory(self._scored_data)
            except Exception as e:
                logger.log_error(e, "Loading scored data")

        # Load pipeline result
        if result_path.exists():
            try:
                with open(result_path, 'r') as f:
                    self._pipeline_result = json.load(f)
            except Exception as e:
                logger.log_error(e, "Loading pipeline result")

        # Load individual source tables
        sources_dir = vault / "sources"
        if sources_dir.exists():
            for pq in sources_dir.glob("*.parquet"):
                try:
                    df = pd.read_parquet(pq)
                    # V17 E1: mask PII in memory view for source tables
                    self._sources[pq.stem] = mask_for_memory(df)
                except Exception as e:
                    # V13 F-4: Log corrupt Parquet instead of silent swallow
                    logger.log_error(e, f"Loading source table: {pq.stem}")
        self._sources_loaded = True

    # -----------------------------------------------------------------
    # Source Tables (per-table persistence)
    # -----------------------------------------------------------------
    def save_sources(self, tables: Dict[str, pd.DataFrame]):
        """Save individual source tables to vault/sources/ as Parquet.
        V17 E7/E9: Uses mask_for_storage() wrapper (enforces safety lock)."""
        sources_dir = PATHS.DATA_VAULT / "sources"
        sources_dir.mkdir(parents=True, exist_ok=True)
        self._sources = {}
        for name, df in tables.items():
            try:
                df_to_save = df
                # V17 E7: Route through mask_for_storage() wrapper
                # (replaces inline mask_dataframe + detect_pii_columns)
                # E9: Safety lock (ALLOW_PII_DISABLE) enforced inside wrapper
                if PII.MASK_AT_STORAGE:
                    from utils.pii_masking import mask_for_storage
                    df_to_save = mask_for_storage(df_to_save)
                df_to_save.to_parquet(sources_dir / f"{name}.parquet", index=False)
                # Always store masked copy in memory when storage masking is on
                if PII.MASK_AT_STORAGE:
                    self._sources[name] = df_to_save  # Store masked copy
                else:
                    self._sources[name] = df
            except Exception as e:
                logger.log_error(e, f"Saving source table: {name}")

    def load_sources(self) -> Dict[str, pd.DataFrame]:
        """Load all source tables from vault. V13 B-4: Lazy on first call.
        V17 E1: Apply mask_for_memory() to each loaded DataFrame."""
        if not self._sources_loaded:
            sources_dir = PATHS.DATA_VAULT / "sources"
            if sources_dir.exists():
                from utils.pii_masking import mask_for_memory
                for pq in sources_dir.glob("*.parquet"):
                    try:
                        df = pd.read_parquet(pq)
                        # V17 E1: mask PII in memory view
                        self._sources[pq.stem] = mask_for_memory(df)
                    except Exception as e:
                        logger.log_error(e, f"Loading source table: {pq.stem}")
            self._sources_loaded = True
        return self._sources

    def get_source_stats(self) -> Dict[str, Any]:
        """Get summary stats for loaded sources."""
        sources = self.load_sources()
        stats = {
            "table_count": len(sources),
            "tables": {},
            "total_rows": 0,
            "last_generated": self._metadata.get("import_time", None),
        }
        for name, df in sources.items():
            stats["tables"][name] = {
                "rows": len(df),
                "columns": len(df.columns),
                "column_list": df.columns.tolist(),
            }
            stats["total_rows"] += len(df)
        return stats

    # -----------------------------------------------------------------
    # Merged / Analytical View
    # -----------------------------------------------------------------
    def import_data(
        self,
        contents: str,
        filename: str
    ) -> Tuple[bool, str, Optional[pd.DataFrame]]:
        """Import data from uploaded file contents.
        V10: Uses Polars for fast CSV parsing when available."""
        try:
            content_type, content_string = contents.split(',')
            decoded = base64.b64decode(content_string)

            # V9: FM-009 — check upload size
            max_bytes = AUDIT.MAX_UPLOAD_SIZE_MB * 1024 * 1024
            if len(decoded) > max_bytes:
                return False, f"File too large ({len(decoded) / 1024 / 1024:.1f} MB). Max: {AUDIT.MAX_UPLOAD_SIZE_MB} MB", None

            # V10: Polars fast path for CSV
            if filename.endswith('.csv') and HAS_POLARS:
                try:
                    pl_df = pl.read_csv(io.BytesIO(decoded))
                    df = pl_df.to_pandas()
                except Exception:
                    df = pd.read_csv(io.StringIO(decoded.decode('utf-8')))
            elif filename.endswith('.csv'):
                df = pd.read_csv(io.StringIO(decoded.decode('utf-8')))
            elif filename.endswith('.parquet'):
                df = pd.read_parquet(io.BytesIO(decoded))
            elif filename.endswith(('.xlsx', '.xls')):
                df = pd.read_excel(io.BytesIO(decoded))
            else:
                return False, f"Unsupported file type: {filename}", None

            is_valid, issues = self._validate_data(df)
            if not is_valid:
                return False, f"Validation failed: {', '.join(issues)}", None

            # V15: float32 downcast — 50% memory reduction
            df = downcast_floats(df)

            self._current_data = df
            self._metadata = {
                "filename": filename,
                "rows": len(df),
                "columns": len(df.columns),
                "import_time": datetime.now().isoformat(),
                "columns_list": df.columns.tolist()
            }
            self._persist_data()

            # V10: Record import in SQLite
            self._sync_data_import_to_db(filename, len(df), len(df.columns), decoded)

            logger.log_data_import(filename, len(df), len(df.columns))
            return True, f"Successfully imported {len(df):,} rows", df

        except Exception as e:
            logger.log_error(e, f"Data import: {filename}")
            return False, f"Import error: {str(e)}", None

    def set_current_data(self, df: pd.DataFrame, label: str = "generated"):
        """Directly set the merged analytical view and persist."""
        self._current_data = df
        self._metadata = {
            "filename": label,
            "rows": len(df),
            "columns": len(df.columns),
            "import_time": datetime.now().isoformat(),
            "columns_list": df.columns.tolist(),
        }
        self._persist_data()

    def _validate_data(self, df: pd.DataFrame) -> Tuple[bool, List[str]]:
        issues = []
        if len(df) < 10:
            issues.append("Dataset has fewer than 10 rows")
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) == 0:
            issues.append("No numeric columns found for analysis")
        empty_cols = df.columns[df.isnull().all()].tolist()
        if empty_cols:
            issues.append(f"Empty columns: {empty_cols}")
        return len(issues) == 0, issues

    def _persist_data(self):
        if self._current_data is not None:
            vault = PATHS.DATA_VAULT
            try:
                self._current_data.to_parquet(vault / "current.parquet", index=False)
                with open(vault / "metadata.json", 'w') as f:
                    json.dump(self._metadata, f, indent=2)
            except Exception as e:
                logger.log_error(e, "Persisting data to vault")

    def get_data(self) -> Optional[pd.DataFrame]:
        # V13 B-4: Lazy load current data on first access
        if self._current_data is None:
            vault_path = PATHS.DATA_VAULT / "current.parquet"
            if vault_path.exists():
                try:
                    self._current_data = pd.read_parquet(vault_path)
                except Exception as e:
                    logger.log_error(e, "Lazy-loading current.parquet")
        return self._current_data

    def get_scored_data(self) -> Optional[pd.DataFrame]:
        # V13 B-4/S-4: Lazy load scored data on first access
        if self._scored_data is None:
            scored_path = PATHS.DATA_VAULT / "scored.parquet"
            if scored_path.exists():
                try:
                    self._scored_data = pd.read_parquet(scored_path)
                except Exception as e:
                    logger.log_error(e, "Lazy-loading scored.parquet")
        return self._scored_data

    def set_scored_data(self, df: pd.DataFrame, run_id: str = None):
        """Persist scored data. V14: Also writes run-partitioned copy."""
        self._scored_data = df
        try:
            df.to_parquet(PATHS.DATA_VAULT / "scored.parquet", index=False)
        except Exception as e:
            logger.log_error(e, "Persisting scored data")

        # V14: Run-partitioned Parquet
        if run_id:
            try:
                run_dir = PATHS.RUN_HISTORY / run_id
                run_dir.mkdir(parents=True, exist_ok=True)
                df.to_parquet(run_dir / "scored.parquet", index=False, engine="pyarrow")
            except Exception as e:
                logger.log_error(e, f"Partitioning scored data for run {run_id}")

    def load_run_scored(self, run_id: str) -> Optional[pd.DataFrame]:
        """V14: Load scored data for a specific historical run."""
        run_path = PATHS.RUN_HISTORY / run_id / "scored.parquet"
        if run_path.exists():
            try:
                return pd.read_parquet(run_path)
            except Exception as e:
                logger.log_error(e, f"Loading run {run_id} scored data")
        return None

    def list_run_ids(self) -> List[str]:
        """V14: List all available run IDs from partitioned storage."""
        try:
            if PATHS.RUN_HISTORY.exists():
                return sorted(
                    [d.name for d in PATHS.RUN_HISTORY.iterdir()
                     if d.is_dir() and (d / "scored.parquet").exists()],
                    reverse=True,
                )
        except Exception:
            pass
        return []

    def get_metadata(self) -> Dict[str, Any]:
        return self._metadata
    
    def save_metadata(self):
        """Save metadata to vault/metadata.json."""
        try:
            with open(PATHS.DATA_VAULT / "metadata.json", 'w') as f:
                json.dump(self._metadata, f, indent=2)
        except Exception as e:
            logger.log_error(e, "Saving metadata")

    # -----------------------------------------------------------------
    # Pipeline Result Persistence
    # -----------------------------------------------------------------
    def save_pipeline_result(self, result: Dict[str, Any]):
        """Save pipeline result JSON to vault for dashboard consumption."""
        self._pipeline_result = result
        try:
            with open(PATHS.DATA_VAULT / "pipeline_result.json", 'w') as f:
                json.dump(result, f, indent=2, default=str)
        except Exception as e:
            logger.log_error(e, "Saving pipeline result")

    def load_pipeline_result(self) -> Dict[str, Any]:
        """Load last pipeline result from vault."""
        if not self._pipeline_result:
            path = PATHS.DATA_VAULT / "pipeline_result.json"
            if path.exists():
                try:
                    with open(path, 'r') as f:
                        self._pipeline_result = json.load(f)
                except Exception:
                    pass
        return self._pipeline_result

    # -----------------------------------------------------------------
    # Clear / Reset
    # -----------------------------------------------------------------
    def clear_data(self):
        """Clear ALL data from vault (sources, merged, scored, results)."""
        self._current_data = None
        self._scored_data = None
        self._sources = {}
        self._metadata = {}
        self._pipeline_result = {}

        vault = PATHS.DATA_VAULT
        for f in ["current.parquet", "scored.parquet", "metadata.json",
                   "pipeline_result.json", "pipeline_status.json"]:
            path = vault / f
            if path.exists():
                path.unlink()

        # Clear source tables
        sources_dir = vault / "sources"
        if sources_dir.exists():
            for pq in sources_dir.glob("*.parquet"):
                pq.unlink()

        logger.log_action("Data Cleared", metadata={"vault": "full_reset"})

    # -----------------------------------------------------------------
    # V8: Run Versioning & Data Lineage
    # -----------------------------------------------------------------
    def create_run_record(self, config_snapshot: Dict = None) -> str:
        """Create a new run record with UUID and config snapshot.
        Returns run_id."""
        run_id = str(uuid.uuid4())[:8]
        run_dir = PATHS.RUN_HISTORY / run_id
        run_dir.mkdir(parents=True, exist_ok=True)

        record = {
            "run_id": run_id,
            "timestamp": datetime.now().isoformat(),
            "version": APP.VERSION,
        }
        if AUDIT.CAPTURE_CONFIG_SNAPSHOT and config_snapshot:
            record["config_snapshot"] = config_snapshot

        # Hash the input data for lineage
        if AUDIT.ENABLE_DATA_LINEAGE and self._current_data is not None:
            # V15: Use hash_pandas_object (O(N)) instead of .to_csv().encode() (O(N×M) string alloc)
            data_hash = pd.util.hash_pandas_object(self._current_data).values.tobytes()
            record["input_hash"] = hashlib.new(
                AUDIT.HASH_ALGORITHM, data_hash
            ).hexdigest()

        with open(run_dir / "run_manifest.json", "w") as f:
            json.dump(record, f, indent=2, default=str)

        logger.log_action("Run Created", metadata={"run_id": run_id})
        return run_id

    def save_run_artifact(self, run_id: str, name: str, df: pd.DataFrame):
        """Save a DataFrame artifact to a run folder."""
        run_dir = PATHS.RUN_HISTORY / run_id
        run_dir.mkdir(parents=True, exist_ok=True)
        df.to_parquet(run_dir / f"{name}.parquet", index=False)

    def list_runs(self) -> List[Dict]:
        """List all saved run records."""
        runs = []
        if not PATHS.RUN_HISTORY.exists():
            return runs
        for d in sorted(PATHS.RUN_HISTORY.iterdir(), reverse=True):
            manifest = d / "run_manifest.json"
            if manifest.exists():
                try:
                    with open(manifest) as f:
                        runs.append(json.load(f))
                except Exception:
                    pass
        return runs

    # -----------------------------------------------------------------
    # Export
    # -----------------------------------------------------------------
    def export_scorecard(self, format: str = "excel") -> Tuple[bytes, str]:
        if self._scored_data is None:
            raise ValueError("No scored data available. Run pipeline first.")

        df = self._scored_data.copy()
        # V17 E7: Route through mask_for_export() wrapper (enforces safety lock)
        if PII.MASK_IN_EXPORTS:
            from utils.pii_masking import mask_for_export
            df = mask_for_export(df)
        export_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = io.BytesIO()

        if format == "excel":
            filename = f"fcdai_scorecard_{export_timestamp}.xlsx"
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name='Anomaly Scorecard', index=False)
                summary = pd.DataFrame([{
                    "Export Date": datetime.now().isoformat(),
                    "Total Records": len(df),
                    "Anomalies Detected": df['anomaly_score'].apply(
                        lambda x: x > 0.5 if pd.notna(x) else False
                    ).sum() if 'anomaly_score' in df.columns else 'N/A',
                    "Source File": self._metadata.get('filename', 'Unknown'),
                    "Import Date": self._metadata.get('import_time', 'Unknown')
                }])
                summary.to_excel(writer, sheet_name='Export Summary', index=False)
        else:
            filename = f"fcdai_scorecard_{export_timestamp}.csv"
            # V9: FM-010 — sanitize CSV cells to prevent formula injection
            df = self._sanitize_csv_cells(df)
            df.to_csv(output, index=False)

        output.seek(0)
        logger.log_export(format.upper(), filename, len(df))
        return output.getvalue(), filename


    @staticmethod
    def _sanitize_csv_cells(df: pd.DataFrame) -> pd.DataFrame:
        """V9 FM-010: Sanitize string cells to prevent CSV formula injection.
        Prefixes cells starting with =, +, -, @ with a single quote."""
        df = df.copy()
        for col in df.select_dtypes(include=['object']).columns:
            df[col] = df[col].apply(
                lambda v: f"'{v}" if isinstance(v, str) and len(v) > 0 and v[0] in ('=', '+', '-', '@') else v
            )
        return df

    # -----------------------------------------------------------------
    # V10: SQLite Sync Methods
    # -----------------------------------------------------------------
    def _sync_data_import_to_db(self, filename: str, rows: int, cols: int, raw_bytes: bytes):
        """Record an import event in the SQLite data_imports table."""
        try:
            from database.engine import get_session
            from database.models import DataImport
            session = get_session()
            try:
                file_hash = hashlib.new(AUDIT.HASH_ALGORITHM, raw_bytes).hexdigest()[:32]
                record = DataImport(
                    filename=filename,
                    table_slot="merged",
                    row_count=rows,
                    col_count=cols,
                    file_hash=file_hash,
                )
                session.add(record)
                session.commit()
            except Exception:
                session.rollback()
            finally:
                session.close()
        except Exception:
            pass  # DB sync is best-effort

    def sync_anomalies_to_db(self, run_id: str):
        """V10: Write scored anomalies to SQLite anomalies table."""
        if self._scored_data is None:
            return
        try:
            from database.engine import get_session
            from database.models import Anomaly
            session = get_session()
            try:
                df = self._scored_data
                score_col = 'anomaly_score' if 'anomaly_score' in df.columns else None
                tier_col = 'risk_tier' if 'risk_tier' in df.columns else None
                vote_col = 'total_votes' if 'total_votes' in df.columns else (
                    'vote_count' if 'vote_count' in df.columns else None
                )
                entity_col = None
                for c in ['cust_id', 'customer_id', 'entity_id', 'party_id']:
                    if c in df.columns:
                        entity_col = c
                        break

                # F-03 FIX: Hash entity_id before writing to DB (never store raw PII)
                try:
                    from utils.crypto import hash_entity_id
                    from config import CRYPTO
                    _should_hash = CRYPTO.HASH_ENTITY_IDS
                except ImportError:
                    _should_hash = False

                anomaly_rows = []
                for idx, row in df.iterrows():
                    score = float(row[score_col]) if score_col and pd.notna(row.get(score_col)) else 0.0
                    if score < 0.5:
                        continue  # Only store flagged anomalies
                    eid = str(row[entity_col]) if entity_col else None
                    if eid and _should_hash:
                        eid = hash_entity_id(eid)
                    anomaly_rows.append(Anomaly(
                        run_id=run_id,
                        row_index=int(idx),
                        entity_id=eid,
                        anomaly_score=score,
                        risk_tier=str(row[tier_col]) if tier_col else None,
                        vote_count=int(row[vote_col]) if vote_col and pd.notna(row.get(vote_col)) else 0,
                    ))

                if anomaly_rows:
                    session.bulk_save_objects(anomaly_rows)
                    session.commit()
            except Exception:
                session.rollback()
            finally:
                session.close()
        except Exception:
            pass

    def confirm_anomaly(self, anomaly_id: int, user_id: int, notes: str = "") -> bool:
        """V10: Mark an anomaly as confirmed by an investigator. Returns success.
        F-16 FIX: Requires investigator+ role (checked via Flask-Login)."""
        # RBAC gate: only investigator or admin may confirm
        try:
            from flask_login import current_user
            if current_user.is_authenticated and current_user.role == "viewer":
                logger.log_action(
                    "CONFIRM_DENIED", user=current_user.username,
                    metadata={"anomaly_id": anomaly_id, "reason": "viewer role"}, status="FAILED",
                )
                return False
        except Exception:
            pass  # Outside request context (e.g., CLI) — allow
        try:
            from database.engine import get_session
            from database.models import Anomaly
            session = get_session()
            try:
                anom = session.query(Anomaly).get(anomaly_id)
                if anom:
                    anom.is_confirmed = True
                    anom.confirmed_by = user_id
                    anom.confirmed_at = datetime.now()
                    anom.notes = notes
                    session.commit()
                    logger.log_action(
                        "Anomaly Confirmed",
                        metadata={"anomaly_id": anomaly_id, "user_id": user_id, "notes": notes}
                    )
                    return True
                return False
            except Exception:
                session.rollback()
                return False
            finally:
                session.close()
        except Exception:
            return False

    def get_anomalies_from_db(self, run_id: str = None, confirmed_only: bool = False) -> List[Dict]:
        """V10: Query anomalies from SQLite."""
        try:
            from database.engine import get_session
            from database.models import Anomaly
            session = get_session()
            try:
                q = session.query(Anomaly)
                if run_id:
                    q = q.filter(Anomaly.run_id == run_id)
                if confirmed_only:
                    q = q.filter(Anomaly.is_confirmed == True)
                results = []
                for a in q.order_by(Anomaly.anomaly_score.desc()).limit(5000).all():
                    results.append({
                        "id": a.id, "run_id": a.run_id, "row_index": a.row_index,
                        "entity_id": a.entity_id, "anomaly_score": a.anomaly_score,
                        "risk_tier": a.risk_tier, "vote_count": a.vote_count,
                        "is_confirmed": a.is_confirmed, "confirmed_at": str(a.confirmed_at) if a.confirmed_at else None,
                        "notes": a.notes,
                    })
                return results
            finally:
                session.close()
        except Exception:
            return []


# Global data vault instance
data_vault = DataVault()


# Convenience functions
def clear_data():
    data_vault.clear_data()


def clear_scored_data():
    data_vault._scored_data = None
    scored_path = PATHS.DATA_VAULT / "scored.parquet"
    if scored_path.exists():
        scored_path.unlink()
