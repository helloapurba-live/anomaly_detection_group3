"""
V31 — Scoring Engine: Normalize → Fuse → Threshold
====================================================
Post-detection score processing for AML anomaly detection pipeline.

Three-stage pipeline:
  STEP 1: Score Normalization — raw algo scores → [0, 1]
  STEP 2: Score Fusion — combine M normalized scores → 1 ensemble score
  STEP 3: Threshold Calibration — ensemble score → risk tier

Each step supports multiple strategies selectable via dropdown + an
"Auto" mode that picks the statistically best-practice default.

Statistical Design Rationale:
  - Normalization (Auto = Percentile Rank): Non-parametric, robust to
    heavy-tailed distributions.  Anomaly scores from Z-Score (0–20),
    LOF (1–50+), IF (0–1), PageRank (0–0.001) are all mapped to [0,1]
    without distributional assumptions.
  - Fusion (Auto = Family→Algo Weighted): Hierarchical weighting prevents
    large-family dominance; AML domain weights encode regulatory priorities
    (Benford structuring, Graph mule detection).
  - Threshold (Auto = Percentile-Based): Adapts to any score distribution;
    maps directly to investigation capacity.

Author: AIM AI Vault V31 Team
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from pathlib import Path
import json
import logging
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import SCORING, AUDIT

try:
    from scipy import stats as scipy_stats
    HAS_SCIPY = True
except ImportError:
    HAS_SCIPY = False

_log = logging.getLogger("scoring_engine")


# =============================================================================
# RESULT DATACLASS
# =============================================================================
@dataclass
class ScoringResult:
    """Complete output of the 3-stage scoring pipeline."""
    # Normalized scores (N × M), all [0, 1]
    normalized_scores: np.ndarray
    normalization_method: str

    # Ensemble fusion output
    ensemble_scores: np.ndarray       # N × 1 fused score
    vote_counts: np.ndarray           # N × 1 method vote count
    family_scores: Optional[Dict[str, np.ndarray]] = None  # per-family scores
    fusion_method: str = ""

    # Threshold / tier assignment
    risk_tiers: np.ndarray = field(default_factory=lambda: np.array([]))
    tier_counts: Dict[str, int] = field(default_factory=dict)
    threshold_method: str = ""

    # Audit trail
    weights_used: Dict[str, float] = field(default_factory=dict)
    family_weights_used: Dict[str, float] = field(default_factory=dict)
    tier_thresholds_used: Dict[str, Any] = field(default_factory=dict)
    audit_log: List[str] = field(default_factory=list)


# =============================================================================
# SCORING ENGINE
# =============================================================================
class ScoringEngine:
    """
    V31 Scoring Engine — 3‑stage: Normalize → Fuse → Threshold.

    Usage:
        engine = ScoringEngine()
        result = engine.score(
            score_matrix,        # N × M numpy array of raw detection scores
            method_names,        # list of M method names
            normalization="auto",
            fusion="auto",
            threshold="auto",
        )
    """

    def __init__(self):
        self.cfg = SCORING

    # =====================================================================
    #  PUBLIC API
    # =====================================================================
    def score(
        self,
        score_matrix: np.ndarray,
        method_names: List[str],
        normalization: str = "auto",
        fusion: str = "auto",
        threshold: str = "auto",
    ) -> ScoringResult:
        """Execute the full 3-stage scoring pipeline.

        Args:
            score_matrix: (N, M) raw detection scores.
            method_names: List of M algorithm names.
            normalization: One of SCORING.NORMALIZATION_METHODS.
            fusion: One of SCORING.FUSION_METHODS.
            threshold: One of SCORING.THRESHOLD_METHODS.

        Returns:
            ScoringResult with all outputs + audit trail.
        """
        audit = []
        n_samples, n_methods = score_matrix.shape
        audit.append(f"Input: {n_samples} samples × {n_methods} methods")

        # ── STEP 1: Normalize ──
        norm_method = self._resolve_normalization(normalization)
        normalized = self._normalize(score_matrix, norm_method)
        audit.append(f"Step1 Normalization: {norm_method}")

        # ── STEP 2: Fuse ──
        fuse_method = self._resolve_fusion(fusion)
        ensemble_scores, vote_counts, family_scores, weights_used, fam_weights = \
            self._fuse(normalized, method_names, fuse_method)
        audit.append(f"Step2 Fusion: {fuse_method} → ensemble range [{ensemble_scores.min():.4f}, {ensemble_scores.max():.4f}]")

        # ── STEP 3: Threshold ──
        thresh_method = self._resolve_threshold(threshold)
        risk_tiers, tier_counts, tier_thresholds = \
            self._threshold(ensemble_scores, vote_counts, n_methods, thresh_method)
        audit.append(f"Step3 Threshold: {thresh_method} → {tier_counts}")

        return ScoringResult(
            normalized_scores=normalized,
            normalization_method=norm_method,
            ensemble_scores=ensemble_scores,
            vote_counts=vote_counts,
            family_scores=family_scores,
            fusion_method=fuse_method,
            risk_tiers=risk_tiers,
            tier_counts=tier_counts,
            threshold_method=thresh_method,
            weights_used=weights_used,
            family_weights_used=fam_weights,
            tier_thresholds_used=tier_thresholds,
            audit_log=audit,
        )

    # =====================================================================
    #  STEP 1 — NORMALIZATION
    # =====================================================================
    def _resolve_normalization(self, method: str) -> str:
        return "percentile_rank" if method == "auto" else method

    def _normalize(self, score_matrix: np.ndarray, method: str) -> np.ndarray:
        """Normalize raw scores to [0, 1]."""
        dispatch = {
            "percentile_rank": self._norm_percentile_rank,
            "minmax":          self._norm_minmax,
            "zscore_sigmoid":  self._norm_zscore_sigmoid,
            "rank_transform":  self._norm_rank_transform,
            "robust_scale":    self._norm_robust_scale,
            "log_minmax":      self._norm_log_minmax,
        }
        fn = dispatch.get(method, self._norm_percentile_rank)
        return fn(score_matrix)

    @staticmethod
    def _norm_percentile_rank(M: np.ndarray) -> np.ndarray:
        """Percentile rank normalization (RECOMMENDED).

        Non-parametric: works for all distributions.
        Interpretation: 0.95 = Top 5% most anomalous.
        """
        n, m = M.shape
        out = np.zeros_like(M, dtype=np.float64)
        for j in range(m):
            col = M[:, j]
            if HAS_SCIPY:
                out[:, j] = np.array([
                    scipy_stats.percentileofscore(col, x, kind='rank') / 100.0
                    for x in col
                ])
            else:
                order = np.argsort(col)
                ranks = np.zeros(n, dtype=np.float64)
                ranks[order] = np.arange(n) / max(n - 1, 1)
                out[:, j] = ranks
        return out

    @staticmethod
    def _norm_minmax(M: np.ndarray) -> np.ndarray:
        """Min-Max scaling: (x - min) / (max - min).

        Best for bounded scores (IF 0–1, HDBSCAN).
        """
        n, m = M.shape
        out = np.zeros_like(M, dtype=np.float64)
        for j in range(m):
            col = M[:, j]
            cmin, cmax = col.min(), col.max()
            rng = cmax - cmin
            out[:, j] = (col - cmin) / rng if rng > 1e-12 else np.zeros(n)
        return out

    @staticmethod
    def _norm_zscore_sigmoid(M: np.ndarray) -> np.ndarray:
        """Z-Score + sigmoid: 1 / (1 + exp(-z)).

        Smooth S-curve; assumes ~Normal distribution.
        """
        n, m = M.shape
        out = np.zeros_like(M, dtype=np.float64)
        for j in range(m):
            col = M[:, j]
            mu, sigma = col.mean(), col.std()
            sigma = max(sigma, 1e-12)
            z = (col - mu) / sigma
            out[:, j] = 1.0 / (1.0 + np.exp(-z))
        return out

    @staticmethod
    def _norm_rank_transform(M: np.ndarray) -> np.ndarray:
        """Rank transform: rank(x) / n.

        Non-parametric; heavy-tailed safe.
        """
        n, m = M.shape
        out = np.zeros_like(M, dtype=np.float64)
        for j in range(m):
            col = M[:, j]
            order = np.argsort(col)
            ranks = np.zeros(n, dtype=np.float64)
            ranks[order] = np.arange(n) / max(n - 1, 1)
            out[:, j] = ranks
        return out

    @staticmethod
    def _norm_robust_scale(M: np.ndarray) -> np.ndarray:
        """Robust scaling: (x - median) / IQR, clipped to [0, 1].

        Outlier-resistant baseline.
        """
        n, m = M.shape
        out = np.zeros_like(M, dtype=np.float64)
        for j in range(m):
            col = M[:, j]
            med = np.median(col)
            q25, q75 = np.percentile(col, 25), np.percentile(col, 75)
            iqr = q75 - q25
            if iqr < 1e-12:
                out[:, j] = np.zeros(n)
            else:
                scaled = (col - med) / iqr
                # Shift to [0, 1]
                smin, smax = scaled.min(), scaled.max()
                rng = smax - smin
                out[:, j] = (scaled - smin) / rng if rng > 1e-12 else np.zeros(n)
        return out

    @staticmethod
    def _norm_log_minmax(M: np.ndarray) -> np.ndarray:
        """Log transform + MinMax: minmax(log1p(x)).

        Compresses extreme values for highly skewed scores.
        """
        n, m = M.shape
        out = np.zeros_like(M, dtype=np.float64)
        for j in range(m):
            col = M[:, j]
            # Shift non-negative then log1p
            col_shifted = col - col.min() if col.min() < 0 else col
            logged = np.log1p(col_shifted)
            lmin, lmax = logged.min(), logged.max()
            rng = lmax - lmin
            out[:, j] = (logged - lmin) / rng if rng > 1e-12 else np.zeros(n)
        return out

    # =====================================================================
    #  STEP 2 — FUSION
    # =====================================================================
    def _resolve_fusion(self, method: str) -> str:
        return "family_then_algo" if method == "auto" else method

    def _fuse(
        self,
        normalized: np.ndarray,
        method_names: List[str],
        fusion_method: str,
    ) -> Tuple[np.ndarray, np.ndarray, Optional[Dict], Dict, Dict]:
        """Fuse normalized scores into a single ensemble.

        Returns:
            (ensemble_scores, vote_counts, family_scores, weights_used, family_weights_used)
        """
        n_samples, n_methods = normalized.shape

        # Compute vote counts (always needed)
        flag_thresh = self.cfg.FLAG_THRESHOLD
        flags = (normalized > flag_thresh).astype(int)
        vote_counts = flags.sum(axis=1)

        # Build weights
        algo_w = {m: self.cfg.ALGO_WEIGHTS.get(m, 1.0) for m in method_names}
        fam_w = dict(self.cfg.FAMILY_WEIGHTS)

        dispatch = {
            "simple_voting":    self._fuse_simple_voting,
            "average":          self._fuse_average,
            "weighted_average": self._fuse_weighted_average,
            "maximum":          self._fuse_maximum,
            "family_weighted":  self._fuse_family_weighted,
            "tiered_consensus": self._fuse_tiered_consensus,
            "borda_count":      self._fuse_borda_count,
            "family_then_algo": self._fuse_family_then_algo,
            "rank_fusion":      self._fuse_rank_fusion,
        }

        fn = dispatch.get(fusion_method, self._fuse_family_then_algo)
        ensemble, family_scores = fn(normalized, method_names, algo_w, fam_w)

        return ensemble, vote_counts, family_scores, algo_w, fam_w

    # ── Individual fusion methods ──

    def _fuse_simple_voting(self, norm, names, aw, fw):
        """Simple voting: flag_count / n_methods. flag if > threshold."""
        flags = (norm > self.cfg.FLAG_THRESHOLD).astype(float)
        ensemble = flags.mean(axis=1)
        return ensemble, None

    def _fuse_average(self, norm, names, aw, fw):
        """Unweighted average of normalized scores."""
        return norm.mean(axis=1), None

    def _fuse_weighted_average(self, norm, names, aw, fw):
        """Weighted average by per-algorithm weights."""
        w = np.array([aw.get(n, 1.0) for n in names])
        w = w / (w.sum() + 1e-12)
        return np.dot(norm, w), None

    def _fuse_maximum(self, norm, names, aw, fw):
        """Maximum score across all methods (conservative, high recall)."""
        return norm.max(axis=1), None

    def _fuse_family_weighted(self, norm, names, aw, fw):
        """Average within family, then weighted average across families."""
        families = self._group_by_family(names)
        n = norm.shape[0]
        fam_scores = {}
        for fam, idxs in families.items():
            if idxs:
                fam_scores[fam] = norm[:, idxs].mean(axis=1)
            else:
                fam_scores[fam] = np.zeros(n)

        total_w = sum(fw.get(f, 1.0) for f in fam_scores)
        ensemble = np.zeros(n)
        for fam, scores in fam_scores.items():
            w = fw.get(fam, 1.0) / max(total_w, 1e-12)
            ensemble += w * scores

        return ensemble, fam_scores

    def _fuse_tiered_consensus(self, norm, names, aw, fw):
        """Tiered consensus: OR logic on score & vote thresholds.

        Returns ensemble as weighted average; tiers applied in Step 3.
        """
        # Use weighted average for scoring
        ensemble, _ = self._fuse_weighted_average(norm, names, aw, fw)
        return ensemble, None

    def _fuse_borda_count(self, norm, names, aw, fw):
        """Borda count: sum of ranks across methods. Lower = more suspicious."""
        n, m = norm.shape
        rank_matrix = np.zeros_like(norm)
        for j in range(m):
            order = np.argsort(norm[:, j])
            rank_matrix[order, j] = np.arange(n)  # 0 = least anomalous

        # Borda score = sum of ranks (higher = more anomalous)
        borda = rank_matrix.sum(axis=1)
        # Normalize to [0, 1]
        bmin, bmax = borda.min(), borda.max()
        rng = bmax - bmin
        ensemble = (borda - bmin) / rng if rng > 1e-12 else np.zeros(n)
        return ensemble, None

    def _fuse_family_then_algo(self, norm, names, aw, fw):
        """RECOMMENDED: Hierarchical family→algorithm weighted fusion.

        Step 1: Within each family, compute weighted average using algo weights.
        Step 2: Across families, compute weighted average using family weights.

        This prevents a family with 5 methods from dominating one with 1 method.
        """
        families = self._group_by_family(names)
        n = norm.shape[0]
        fam_scores = {}

        for fam, idxs in families.items():
            if not idxs:
                continue
            fam_methods = [names[i] for i in idxs]
            w = np.array([aw.get(m, 1.0) for m in fam_methods])
            w = w / (w.sum() + 1e-12)
            fam_scores[fam] = np.dot(norm[:, idxs], w)

        # Weighted average across families
        total_fw = sum(fw.get(f, 1.0) for f in fam_scores)
        ensemble = np.zeros(n)
        for fam, scores in fam_scores.items():
            w = fw.get(fam, 1.0) / max(total_fw, 1e-12)
            ensemble += w * scores

        return ensemble, fam_scores

    def _fuse_rank_fusion(self, norm, names, aw, fw):
        """Rank-based fusion: convert each to rank percentile, then weighted avg."""
        n, m = norm.shape
        rank_pct = np.zeros_like(norm)
        for j in range(m):
            order = np.argsort(norm[:, j])
            rank_pct[order, j] = np.arange(n) / max(n - 1, 1)

        w = np.array([aw.get(names[j], 1.0) for j in range(m)])
        w = w / (w.sum() + 1e-12)
        ensemble = np.dot(rank_pct, w)
        return ensemble, None

    def _group_by_family(self, method_names: List[str]) -> Dict[str, List[int]]:
        """Group method indices by family."""
        fam_map = self.cfg.ALGO_FAMILY_MAP
        families: Dict[str, List[int]] = {}
        for i, m in enumerate(method_names):
            fam = fam_map.get(m, "Unknown")
            families.setdefault(fam, []).append(i)
        return families

    # =====================================================================
    #  STEP 3 — THRESHOLD CALIBRATION
    # =====================================================================
    def _resolve_threshold(self, method: str) -> str:
        return "percentile_based" if method == "auto" else method

    def _threshold(
        self,
        ensemble_scores: np.ndarray,
        vote_counts: np.ndarray,
        n_methods: int,
        method: str,
    ) -> Tuple[np.ndarray, Dict[str, int], Dict]:
        """Assign risk tiers."""
        dispatch = {
            "rule_based":       self._thresh_rule_based,
            "percentile_based": self._thresh_percentile_based,
            "borda_consensus":  self._thresh_borda_consensus,
        }
        fn = dispatch.get(method, self._thresh_percentile_based)
        return fn(ensemble_scores, vote_counts, n_methods)

    def _thresh_rule_based(self, scores, votes, n_methods):
        """Fixed score + vote threshold (regulatory compliance)."""
        epsilon = AUDIT.RISK_TIER_EPSILON
        tiers = np.full(len(scores), "NORMAL", dtype="<U10")
        thresholds = {}

        for tier_name in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            score_t = self.cfg.TIER_SCORE_THRESHOLDS.get(tier_name, 0) - epsilon
            vote_pct = self.cfg.TIER_VOTE_PCTS.get(tier_name, 0)
            vote_t = int(vote_pct * n_methods)
            mask = (scores >= score_t) | (votes >= vote_t)
            tiers[mask] = tier_name
            thresholds[tier_name] = {
                "score_threshold": score_t + epsilon,
                "vote_threshold": vote_t,
                "vote_pct": vote_pct,
            }

        unique, counts = np.unique(tiers, return_counts=True)
        tier_counts = dict(zip(unique.tolist(), counts.astype(int).tolist()))
        return tiers, tier_counts, thresholds

    def _thresh_percentile_based(self, scores, votes, n_methods):
        """Percentile-based thresholds (RECOMMENDED).

        Maps directly to investigation capacity:
          CRITICAL = Top 0.2% → same-day review
          HIGH     = Top 1%   → 72hr review
          MEDIUM   = Top 3%   → 7-day
          LOW      = Top 10%  → 30-day monitoring
        """
        tiers = np.full(len(scores), "NORMAL", dtype="<U10")
        thresholds = {}

        for tier_name in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            pct = self.cfg.TIER_PERCENTILES.get(tier_name, 100)
            score_t = np.percentile(scores, pct) if len(scores) > 0 else 0
            vote_pct = self.cfg.TIER_VOTE_PCTS.get(tier_name, 0)
            vote_t = int(vote_pct * n_methods)
            mask = (scores >= score_t) | (votes >= vote_t)
            tiers[mask] = tier_name
            thresholds[tier_name] = {
                "percentile": pct,
                "computed_score_threshold": float(score_t),
                "vote_threshold": vote_t,
            }

        unique, counts = np.unique(tiers, return_counts=True)
        tier_counts = dict(zip(unique.tolist(), counts.astype(int).tolist()))
        return tiers, tier_counts, thresholds

    def _thresh_borda_consensus(self, scores, votes, n_methods):
        """Borda consensus: flag only if suspicious in ≥K families.

        Reduces false positives by requiring cross-family agreement.
        Falls back to percentile for non-Borda fusion methods.
        """
        # Use percentile thresholds for scoring, then overlay
        # family-consensus requirement for CRITICAL/HIGH
        tiers, tier_counts, thresholds = self._thresh_percentile_based(
            scores, votes, n_methods
        )

        min_fam = self.cfg.BORDA_MIN_FAMILIES
        thresholds["borda_min_families"] = min_fam
        thresholds["note"] = (
            f"Borda consensus requires agreement across ≥{min_fam} families. "
            "Family-level filtering applied when family_scores are available."
        )

        return tiers, tier_counts, thresholds

    # =====================================================================
    #  UTILITY — Audit Trail Export
    # =====================================================================
    def export_audit(self, result: ScoringResult, path: Path = None) -> Dict:
        """Export complete audit trail for regulatory compliance."""
        audit = {
            "scoring_version": "V31",
            "normalization": {
                "method": result.normalization_method,
                "description": self._method_description("norm", result.normalization_method),
            },
            "fusion": {
                "method": result.fusion_method,
                "description": self._method_description("fuse", result.fusion_method),
                "algorithm_weights": result.weights_used,
                "family_weights": result.family_weights_used,
            },
            "threshold": {
                "method": result.threshold_method,
                "description": self._method_description("thresh", result.threshold_method),
                "thresholds_applied": result.tier_thresholds_used,
            },
            "tier_distribution": result.tier_counts,
            "pipeline_log": result.audit_log,
        }
        if path:
            with open(path, "w") as f:
                json.dump(audit, f, indent=2, default=str)
        return audit

    @staticmethod
    def _method_description(stage: str, method: str) -> str:
        descs = {
            ("norm", "percentile_rank"): "Non-parametric percentile rank; robust to outliers and heavy-tailed distributions.",
            ("norm", "minmax"):          "Min-Max scaling to [0,1]; best for bounded-range scores.",
            ("norm", "zscore_sigmoid"):  "Z-score followed by sigmoid; assumes approximately Normal distribution.",
            ("norm", "rank_transform"):  "Rank / n; heavy-tail safe, non-parametric.",
            ("norm", "robust_scale"):    "Median/IQR scaling clipped to [0,1]; outlier-resistant.",
            ("norm", "log_minmax"):      "Log1p transform then Min-Max; compresses extreme skew.",
            ("fuse", "simple_voting"):   "Binary flag voting — count methods agreeing.",
            ("fuse", "average"):         "Unweighted arithmetic mean of normalized scores.",
            ("fuse", "weighted_average"):"Per-algorithm weighted average (AML domain weights).",
            ("fuse", "maximum"):         "Maximum score across all methods (high recall, higher FP).",
            ("fuse", "family_weighted"): "Average within family, then family-weighted average across families.",
            ("fuse", "tiered_consensus"):"Weighted average with tiered OR-logic tier assignment.",
            ("fuse", "borda_count"):     "Sum of ranks across methods (Borda count voting).",
            ("fuse", "family_then_algo"):"RECOMMENDED: Hierarchical family→algo weighted fusion.",
            ("fuse", "rank_fusion"):     "Convert to rank percentiles, then weighted average.",
            ("thresh", "rule_based"):    "Fixed score + vote thresholds per tier (regulatory).",
            ("thresh", "percentile_based"): "RECOMMENDED: Percentile-based, maps to investigation capacity.",
            ("thresh", "borda_consensus"): "Percentile + cross-family consensus requirement.",
        }
        return descs.get((stage, method), method)
