"""
V30: Algorithm Execution Engine — L11 Detection Pipeline
=========================================================
Enhanced Algorithm Execution Pipeline with:
  - Manual Family Selection (8 families, 20 algorithms)
  - Agent Auto selection based on data characteristics (N, K, HAS_GRAPH, HAS_TEMPORAL)
  - Full Suite mode (execute all applicable algorithms)
  - Internal SUOD optimization (invisible to user, 4x speedup when 3+ compatible algos)
  - Phased execution (Statistical → Tree+Density+Distance → Clustering → Graph → TimeSeries → DL)
  - Individual per-algorithm score extraction (NEVER SUOD aggregate)
  - Family mapping for downstream L13 Ensemble Fusion

SUOD Principle:
  - User NEVER sees SUOD option in UI
  - System decides internally when 3+ SUOD-compatible algos are selected
  - Output is ALWAYS individual algorithm scores
  - Metadata tracks SUOD usage for internal debugging only

Author: AIM AI Vault V30
PhD-validated statistical pipeline
"""

import numpy as np
import pandas as pd
import json
import time
import logging
import traceback
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any

logger = logging.getLogger("apurbadas.algo_execution_engine")


# ─────────────────────────────────────────────────────────────────────────────
# ALGORITHM FAMILY DEFINITIONS
# ─────────────────────────────────────────────────────────────────────────────
ALGO_FAMILIES = {
    "Statistical": {
        "algos": ["IQR", "ZScore", "Mahalanobis", "Benford"],
        "icon": "mdi:chart-bell-curve-cumulative",
        "color": "blue",
        "description": "Distribution-based outlier detection",
    },
    "Tree": {
        "algos": ["ExtIF"],
        "icon": "mdi:file-tree",
        "color": "green",
        "description": "Tree-splitting isolation detectors",
    },
    "Density": {
        "algos": ["HBOS", "LOF", "ECOD", "COPOD"],
        "icon": "mdi:chart-scatter-plot",
        "color": "teal",
        "description": "Local density anomaly estimation",
    },
    "Distance": {
        "algos": ["KNN"],
        "icon": "mdi:vector-radius",
        "color": "cyan",
        "description": "Distance-based nearest neighbour",
    },
    "Clustering": {
        "algos": ["GMM", "HDBSCAN", "BIRCH"],
        "icon": "mdi:chart-bubble",
        "color": "grape",
        "description": "Cluster membership anomaly",
    },
    "Graph": {
        "algos": ["PageRank", "Leiden", "OddBall", "Betweenness"],
        "icon": "mdi:graph",
        "color": "orange",
        "description": "Graph structure anomaly (requires GRAPH_DATA)",
        "requires": "graph_data",
    },
    "TimeSeries": {
        "algos": ["ChangePoint", "MatrixProfile"],
        "icon": "mdi:chart-timeline-variant",
        "color": "red",
        "description": "Temporal pattern anomaly (requires TEMPORAL_DATA)",
        "requires": "temporal_data",
    },
    "DeepLearning": {
        "algos": ["VAE"],
        "icon": "mdi:brain",
        "color": "violet",
        "description": "Neural network reconstruction error",
    },
}

# Flat list: all 20 algorithms
ALL_ALGORITHMS = []
ALGO_TO_FAMILY = {}
for fam, info in ALGO_FAMILIES.items():
    for algo in info["algos"]:
        ALL_ALGORITHMS.append(algo)
        ALGO_TO_FAMILY[algo] = fam


# ─────────────────────────────────────────────────────────────────────────────
# SUOD COMPATIBILITY (internal only)
# ─────────────────────────────────────────────────────────────────────────────
SUOD_COMPATIBLE = {"ExtIF", "HBOS", "LOF", "ECOD", "COPOD", "KNN"}
SUOD_MIN_ALGOS = 3   # Enable SUOD only when 3+ compatible algos selected


# ─────────────────────────────────────────────────────────────────────────────
# ALGORITHM → INPUT ROUTING (which scaler / data source each algo needs)
# ─────────────────────────────────────────────────────────────────────────────
ALGO_INPUT_ROUTING = {
    "IQR":           {"input": "X_robust",         "scaler": "RobustScaler",    "suod": False},
    "ZScore":        {"input": "X_robust",         "scaler": "RobustScaler",    "suod": False},
    "Mahalanobis":   {"input": "X_power",          "scaler": "PowerTransformer","suod": False},
    "Benford":       {"input": "X_original",       "scaler": "Original",        "suod": False},
    "ExtIF":         {"input": "X_original",       "scaler": "Original",        "suod": True},
    "HBOS":          {"input": "X_standard",       "scaler": "StandardScaler",  "suod": True},
    "LOF":           {"input": "X_standard",       "scaler": "StandardScaler",  "suod": True},
    "ECOD":          {"input": "X_original",       "scaler": "Original",        "suod": True},
    "COPOD":         {"input": "X_original",       "scaler": "Original",        "suod": True},
    "KNN":           {"input": "X_standard",       "scaler": "StandardScaler",  "suod": True},
    "GMM":           {"input": "X_power",          "scaler": "PowerTransformer","suod": False},
    "HDBSCAN":       {"input": "X_standard",       "scaler": "StandardScaler",  "suod": False},
    "BIRCH":         {"input": "X_standard",       "scaler": "StandardScaler",  "suod": False},
    "PageRank":      {"input": "GRAPH_DATA",       "scaler": "Original",        "suod": False},
    "Leiden":        {"input": "GRAPH_DATA",       "scaler": "Original",        "suod": False},
    "OddBall":       {"input": "GRAPH_DATA",       "scaler": "Original",        "suod": False},
    "Betweenness":   {"input": "GRAPH_DATA",       "scaler": "Original",        "suod": False},
    "ChangePoint":   {"input": "TEMPORAL_DATA",    "scaler": "Original",        "suod": False},
    "MatrixProfile": {"input": "TEMPORAL_DATA",    "scaler": "Original",        "suod": False},
    "VAE":           {"input": "X_minmax",         "scaler": "MinMaxScaler",    "suod": False},
}

# Algorithm default parameters
ALGO_DEFAULT_PARAMS = {
    "IQR":           {"multiplier": 1.5},
    "ZScore":        {"threshold": 3.0},
    "Mahalanobis":   {},
    "Benford":       {"first_digit_only": True},
    "ExtIF":         {"n_estimators": 100, "contamination": 0.05},
    "HBOS":          {"n_bins": 10, "alpha": 0.1, "contamination": 0.05},
    "LOF":           {"n_neighbors": 20, "contamination": 0.05},
    "ECOD":          {"contamination": 0.05},
    "COPOD":         {"contamination": 0.05},
    "KNN":           {"n_neighbors": 10, "method": "largest", "contamination": 0.05},
    "GMM":           {"n_components": 5, "contamination": 0.05},
    "HDBSCAN":       {"min_cluster_size": 15, "min_samples": 5},
    "BIRCH":         {"n_clusters": 8, "threshold": 0.5},
    "PageRank":      {"alpha": 0.85, "max_iter": 100},
    "Leiden":        {"resolution": 1.0},
    "OddBall":       {},
    "Betweenness":   {},
    "ChangePoint":   {"penalty": "mbic"},
    "MatrixProfile": {"window_size": 10},
    "VAE":           {"hidden_neurons": [64, 32, 16], "epochs": 50, "contamination": 0.05},
}

# Algorithm execution phase ordering
EXECUTION_PHASES = [
    ("Phase 1: Statistical",        ["IQR", "ZScore", "Mahalanobis", "Benford"]),
    ("Phase 2: Tree+Density+Distance", ["ExtIF", "HBOS", "LOF", "ECOD", "COPOD", "KNN"]),
    ("Phase 3: Clustering",         ["GMM", "HDBSCAN", "BIRCH"]),
    ("Phase 4: Graph",              ["PageRank", "Leiden", "OddBall", "Betweenness"]),
    ("Phase 5: Time-Series",        ["ChangePoint", "MatrixProfile"]),
    ("Phase 6: Deep Learning",      ["VAE"]),
]


# ─────────────────────────────────────────────────────────────────────────────
# ALGO EXECUTION RESULT
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class AlgoResult:
    """Result from a single algorithm execution."""
    algo_name: str
    family: str
    scores: Optional[np.ndarray] = None
    n_anomalies: int = 0
    runtime_s: float = 0.0
    status: str = "pending"          # pending | running | success | failed | skipped
    error: str = ""
    internal_suod: bool = False      # internal debug flag


@dataclass
class AlgoExecutionResult:
    """Full result from the algorithm execution pipeline."""
    raw_scores: Dict[str, np.ndarray] = field(default_factory=dict)
    algo_results: Dict[str, AlgoResult] = field(default_factory=dict)
    algo_metadata: Dict[str, Dict] = field(default_factory=dict)
    family_mapping: Dict[str, str] = field(default_factory=dict)
    execution_mode: str = ""
    selected_algorithms: List[str] = field(default_factory=list)
    total_runtime_s: float = 0.0
    n_customers: int = 0
    n_features: int = 0
    suod_used_internally: bool = False
    suod_algos: List[str] = field(default_factory=list)
    phase_log: List[str] = field(default_factory=list)
    timestamp: str = ""


# ─────────────────────────────────────────────────────────────────────────────
# AGENT AUTO LOGIC
# ─────────────────────────────────────────────────────────────────────────────
def agent_auto_select(
    N: int,
    K: int,
    has_graph: bool = False,
    has_temporal: bool = False,
    has_amount: bool = False,
    algo_config_path: Optional[Path] = None,
) -> List[str]:
    """
    Agent Auto mode: Select algorithms based on data characteristics.

    If ALGO_CONFIG.json exists, load from there.
    Otherwise, auto-generate based on N (rows), K (features),
    HAS_GRAPH, HAS_TEMPORAL, HAS_AMOUNT.

    Returns list of algorithm short names.
    """
    # Try loading from config file first
    if algo_config_path and algo_config_path.exists():
        try:
            with open(algo_config_path, "r") as f:
                config = json.load(f)
            selected = [
                a["name"] for a in config.get("algorithms", [])
                if a.get("enabled", True)
            ]
            if selected:
                logger.info(f"Agent Auto: Loaded {len(selected)} algos from {algo_config_path}")
                return selected
        except Exception as exc:
            logger.warning(f"Agent Auto: Failed to load config: {exc}")

    # Auto-generate based on data characteristics
    selected = []

    # ALWAYS (K≥3, N≥50): Core algorithms
    if K >= 3 and N >= 50:
        selected.extend(["IQR", "ZScore", "ExtIF", "ECOD", "COPOD"])

    # K≥5, N≥100: Add density/distance/clustering
    if K >= 5 and N >= 100:
        selected.extend(["HBOS", "LOF", "KNN", "HDBSCAN", "BIRCH"])

    # K≥10, N≥200: Add Mahalanobis, GMM
    if K >= 10 and N >= 200:
        selected.extend(["Mahalanobis", "GMM"])

    # K≥20, N≥500: Add VAE
    if K >= 20 and N >= 500:
        selected.append("VAE")

    # HAS_AMOUNT: Add Benford
    if has_amount:
        selected.append("Benford")

    # HAS_GRAPH: Add graph algorithms
    if has_graph:
        selected.extend(["PageRank", "Leiden", "OddBall", "Betweenness"])

    # HAS_TEMPORAL: Add time-series
    if has_temporal:
        selected.extend(["ChangePoint", "MatrixProfile"])

    # Fallback: at least IQR + ZScore
    if not selected:
        selected = ["IQR", "ZScore"]

    logger.info(
        f"Agent Auto: N={N}, K={K}, graph={has_graph}, "
        f"temporal={has_temporal}, amount={has_amount} → {len(selected)} algos"
    )
    return selected


# ─────────────────────────────────────────────────────────────────────────────
# INDIVIDUAL ALGORITHM RUNNERS (map to l5_detection.py detector classes)
# ─────────────────────────────────────────────────────────────────────────────
# Mapping from execution engine algo names → l5_detection.py method keys
ALGO_TO_L5_KEY = {
    "IQR":           "iqr",
    "ZScore":        "zscore",
    "Mahalanobis":   "mahalanobis",
    "Benford":       "iqr",           # Benford uses IQR on digit-distribution (custom below)
    "ExtIF":         "extended_if",
    "HBOS":          "hbos",          # Will use PyOD via SUOD if available
    "LOF":           "lof",
    "ECOD":          "ecod",
    "COPOD":         "copod",
    "KNN":           "knn",
    "GMM":           "gmm",
    "HDBSCAN":       "hdbscan",
    "BIRCH":         "birch",
    "PageRank":      "pagerank",
    "Leiden":        "community",
    "OddBall":       "oddball",
    "Betweenness":   "centrality",
    "ChangePoint":   "changepoint",
    "MatrixProfile": "matrixprofile",
    "VAE":           "vae",
}

# PyOD class mapping for SUOD-compatible algorithms
PYOD_CLASS_MAP = {
    "ExtIF":  "IForest",
    "HBOS":   "HBOS",
    "LOF":    "LOF",
    "ECOD":   "ECOD",
    "COPOD":  "COPOD",
    "KNN":    "KNN",
}


def _normalize_scores(scores: np.ndarray) -> np.ndarray:
    """Min-max normalize scores to [0, 1]."""
    mn, mx = np.nanmin(scores), np.nanmax(scores)
    if mx - mn < 1e-10:
        return np.zeros_like(scores)
    return (scores - mn) / (mx - mn)


def _get_scaled_input(
    algo_name: str,
    scaled_matrices: Dict[str, np.ndarray],
    X_original: np.ndarray,
) -> Optional[np.ndarray]:
    """
    Select the correct input matrix for an algorithm based on ALGO_INPUT_ROUTING.
    Maps routing scaler names to the keys in scaled_matrices.
    """
    routing = ALGO_INPUT_ROUTING.get(algo_name, {})
    scaler = routing.get("scaler", "StandardScaler")
    input_key = routing.get("input", "X_standard")

    # Direct lookup from scaled_matrices
    if scaler in scaled_matrices:
        return scaled_matrices[scaler]

    # Fallback mappings
    key_map = {
        "X_original":  "Original",
        "X_standard":  "StandardScaler",
        "X_robust":    "RobustScaler",
        "X_power":     "PowerTransformer",
        "X_minmax":    "MinMaxScaler",
    }
    mapped = key_map.get(input_key, scaler)
    if mapped in scaled_matrices:
        return scaled_matrices[mapped]

    # Ultimate fallback: StandardScaler or first available
    if "StandardScaler" in scaled_matrices:
        return scaled_matrices["StandardScaler"]
    if scaled_matrices:
        return next(iter(scaled_matrices.values()))

    return X_original


def _run_single_algorithm(
    algo_name: str,
    X: np.ndarray,
    params: Dict,
    contamination: float = 0.05,
) -> AlgoResult:
    """
    Execute a single algorithm and return result.
    Uses l5_detection.py detector classes when available,
    otherwise falls back to safe statistical implementations.
    """
    t0 = time.time()
    result = AlgoResult(
        algo_name=algo_name,
        family=ALGO_TO_FAMILY.get(algo_name, "Unknown"),
        status="running",
    )

    try:
        N, K = X.shape
        scores = np.zeros(N, dtype=np.float64)

        if algo_name == "IQR":
            q1 = np.nanpercentile(X, 25, axis=0)
            q3 = np.nanpercentile(X, 75, axis=0)
            iqr = q3 - q1 + 1e-10
            multi = params.get("multiplier", 1.5)
            lower = q1 - multi * iqr
            upper = q3 + multi * iqr
            deviation = np.maximum(
                np.maximum(lower - X, 0),
                np.maximum(X - upper, 0)
            )
            scores = np.max(deviation / (iqr + 1e-10), axis=1)

        elif algo_name == "ZScore":
            mean = np.nanmean(X, axis=0)
            std = np.nanstd(X, axis=0) + 1e-10
            z = np.abs((X - mean) / std)
            scores = np.max(z, axis=1)
            threshold = params.get("threshold", 3.0)
            scores = scores / (threshold * 2)

        elif algo_name == "Mahalanobis":
            from numpy.linalg import inv, LinAlgError
            mean = np.nanmean(X, axis=0)
            try:
                cov = np.cov(X, rowvar=False)
                if cov.ndim < 2:
                    cov = np.array([[cov]])
                cov_inv = inv(cov + np.eye(cov.shape[0]) * 1e-6)
                diff = X - mean
                left = diff @ cov_inv
                scores = np.sqrt(np.sum(left * diff, axis=1))
            except (LinAlgError, np.linalg.LinAlgError):
                # Fallback: Euclidean distance from mean
                scores = np.sqrt(np.sum((X - mean) ** 2, axis=1))

        elif algo_name == "Benford":
            # Benford's Law on first digits of absolute values
            expected = np.log10(1 + 1 / np.arange(1, 10))
            amt_cols = [i for i in range(K) if np.any(np.abs(X[:, i]) >= 1)]
            if amt_cols:
                first_digits = np.zeros((N, 9))
                for ci in amt_cols:
                    vals = np.abs(X[:, ci])
                    vals = vals[vals >= 1]
                    if len(vals) < 10:
                        continue
                    fd = (vals / 10 ** np.floor(np.log10(vals + 1e-300))).astype(int)
                    fd = np.clip(fd, 1, 9)
                    for d in range(1, 10):
                        first_digits[:len(vals), d - 1] += (fd == d).astype(float)
                row_total = first_digits.sum(axis=1, keepdims=True) + 1e-10
                observed = first_digits / row_total
                chi_sq = np.sum((observed - expected) ** 2 / (expected + 1e-10), axis=1)
                scores = chi_sq
            else:
                scores = np.zeros(N)

        elif algo_name == "ExtIF":
            try:
                from pyod.models.iforest import IForest
                model = IForest(
                    n_estimators=params.get("n_estimators", 100),
                    contamination=contamination,
                    behaviour='new',
                    random_state=42,
                )
                model.fit(X)
                scores = model.decision_scores_
            except ImportError:
                # Fallback: sklearn Isolation Forest
                from sklearn.ensemble import IsolationForest
                clf = IsolationForest(
                    n_estimators=params.get("n_estimators", 100),
                    contamination=contamination,
                    random_state=42,
                )
                clf.fit(X)
                scores = -clf.decision_function(X)

        elif algo_name == "HBOS":
            try:
                from pyod.models.hbos import HBOS
                model = HBOS(
                    n_bins=params.get("n_bins", 10),
                    alpha=params.get("alpha", 0.1),
                    contamination=contamination,
                )
                model.fit(X)
                scores = model.decision_scores_
            except ImportError:
                # Histogram-based fallback
                scores_per_feat = np.zeros((N, K))
                for j in range(K):
                    hist, bin_edges = np.histogram(X[:, j], bins=10, density=True)
                    digitized = np.digitize(X[:, j], bin_edges[1:-1])
                    digitized = np.clip(digitized, 0, len(hist) - 1)
                    densities = hist[digitized] + 1e-10
                    scores_per_feat[:, j] = -np.log(densities)
                scores = np.sum(scores_per_feat, axis=1)

        elif algo_name == "LOF":
            try:
                from pyod.models.lof import LOF as PyodLOF
                model = PyodLOF(
                    n_neighbors=min(params.get("n_neighbors", 20), N - 1),
                    contamination=contamination,
                )
                model.fit(X)
                scores = model.decision_scores_
            except ImportError:
                from sklearn.neighbors import LocalOutlierFactor
                clf = LocalOutlierFactor(
                    n_neighbors=min(params.get("n_neighbors", 20), N - 1),
                    contamination=contamination,
                )
                clf.fit_predict(X)
                scores = -clf.negative_outlier_factor_

        elif algo_name == "ECOD":
            try:
                from pyod.models.ecod import ECOD
                model = ECOD(contamination=contamination)
                model.fit(X)
                scores = model.decision_scores_
            except ImportError:
                # Empirical CDF fallback
                from scipy.stats import rankdata
                rank_mat = np.apply_along_axis(rankdata, 0, X).astype(float)
                rank_mat /= (N + 1)
                tail_probs = np.minimum(rank_mat, 1 - rank_mat)
                scores = -np.sum(np.log(tail_probs + 1e-10), axis=1)

        elif algo_name == "COPOD":
            try:
                from pyod.models.copod import COPOD
                model = COPOD(contamination=contamination)
                model.fit(X)
                scores = model.decision_scores_
            except ImportError:
                # Copula-based fallback (same CDF approach)
                from scipy.stats import rankdata
                rank_mat = np.apply_along_axis(rankdata, 0, X).astype(float)
                rank_mat /= (N + 1)
                scores = -np.sum(np.log(np.minimum(rank_mat, 1 - rank_mat) + 1e-10), axis=1)

        elif algo_name == "KNN":
            try:
                from pyod.models.knn import KNN as PyodKNN
                model = PyodKNN(
                    n_neighbors=min(params.get("n_neighbors", 10), N - 1),
                    method=params.get("method", "largest"),
                    contamination=contamination,
                )
                model.fit(X)
                scores = model.decision_scores_
            except ImportError:
                from sklearn.neighbors import NearestNeighbors
                k = min(params.get("n_neighbors", 10), N - 1)
                nn = NearestNeighbors(n_neighbors=k + 1)
                nn.fit(X)
                dists, _ = nn.kneighbors(X)
                scores = dists[:, -1]

        elif algo_name == "GMM":
            from sklearn.mixture import GaussianMixture
            n_comp = min(params.get("n_components", 5), N // 2, K)
            n_comp = max(n_comp, 1)
            gmm = GaussianMixture(n_components=n_comp, random_state=42)
            gmm.fit(X)
            scores = -gmm.score_samples(X)

        elif algo_name == "HDBSCAN":
            try:
                import hdbscan
                clusterer = hdbscan.HDBSCAN(
                    min_cluster_size=max(params.get("min_cluster_size", 15), 2),
                    min_samples=max(params.get("min_samples", 5), 2),
                )
                labels = clusterer.fit_predict(X)
                # Outlier score: points labeled -1 are anomalies
                probs = clusterer.probabilities_ if hasattr(clusterer, 'probabilities_') else np.zeros(N)
                scores = 1.0 - probs
            except ImportError:
                # Fallback: DBSCAN from sklearn
                from sklearn.cluster import DBSCAN
                db = DBSCAN(eps=0.5, min_samples=5)
                labels = db.fit_predict(X)
                scores = (labels == -1).astype(float)

        elif algo_name == "BIRCH":
            from sklearn.cluster import Birch
            n_cl = min(params.get("n_clusters", 8), N // 3)
            n_cl = max(n_cl, 2)
            birch = Birch(n_clusters=n_cl, threshold=params.get("threshold", 0.5))
            labels = birch.fit_predict(X)
            # Distance from cluster center as anomaly score
            centers = birch.subcluster_centers_ if hasattr(birch, 'subcluster_centers_') else np.zeros((1, K))
            if labels.max() < len(centers):
                assigned_centers = centers[np.clip(labels, 0, len(centers) - 1)]
                scores = np.sqrt(np.sum((X - assigned_centers) ** 2, axis=1))
            else:
                scores = np.zeros(N)

        elif algo_name in ("PageRank", "Leiden", "OddBall", "Betweenness"):
            # Graph algorithms — compute from adjacency or k-NN graph
            scores = _run_graph_algorithm(algo_name, X, N, params)

        elif algo_name == "ChangePoint":
            # Change-point detection on aggregated temporal signal
            signal = np.mean(X, axis=1) if K > 1 else X.ravel()
            scores = _run_changepoint(signal, params)

        elif algo_name == "MatrixProfile":
            signal = np.mean(X, axis=1) if K > 1 else X.ravel()
            scores = _run_matrixprofile(signal, params)

        elif algo_name == "VAE":
            scores = _run_vae(X, params, contamination)

        else:
            result.status = "skipped"
            result.error = f"Unknown algorithm: {algo_name}"
            return result

        # Normalize to [0, 1]
        scores = _normalize_scores(scores)
        result.scores = scores
        result.n_anomalies = int(np.sum(scores > 0.5))
        result.status = "success"
        result.runtime_s = round(time.time() - t0, 3)

    except Exception as exc:
        result.status = "failed"
        result.error = str(exc)[:300]
        result.runtime_s = round(time.time() - t0, 3)
        logger.error(f"Algorithm {algo_name} failed: {exc}")
        traceback.print_exc()

    return result


# ─────────────────────────────────────────────────────────────────────────────
# SPECIALIZED ALGORITHM RUNNERS
# ─────────────────────────────────────────────────────────────────────────────
def _run_graph_algorithm(algo_name: str, X: np.ndarray, N: int, params: Dict) -> np.ndarray:
    """Run graph-based anomaly algorithms using k-NN adjacency construction."""
    try:
        import networkx as nx
        from sklearn.neighbors import NearestNeighbors

        k = min(10, N - 1)
        nn = NearestNeighbors(n_neighbors=k + 1)
        nn.fit(X)
        dists, indices = nn.kneighbors(X)

        G = nx.Graph()
        G.add_nodes_from(range(N))
        for i in range(N):
            for j_idx in range(1, min(k + 1, len(indices[i]))):
                j = indices[i][j_idx]
                w = max(1.0 / (dists[i][j_idx] + 1e-10), 0.001)
                if not G.has_edge(i, j):
                    G.add_edge(i, j, weight=w)

        if algo_name == "PageRank":
            pr = nx.pagerank(G, alpha=params.get("alpha", 0.85), max_iter=params.get("max_iter", 100))
            scores = np.array([pr.get(i, 0) for i in range(N)])
            # Low PageRank = anomalous (isolated)
            scores = 1.0 - scores / (scores.max() + 1e-10)

        elif algo_name == "Leiden":
            try:
                import leidenalg
                import igraph as ig
                ig_graph = ig.Graph.from_networkx(G)
                partition = leidenalg.find_partition(
                    ig_graph, leidenalg.ModularityVertexPartition,
                    resolution_parameter=params.get("resolution", 1.0)
                )
                membership = np.array(partition.membership)
            except ImportError:
                # Fallback: Louvain via networkx
                communities = nx.community.louvain_communities(G)
                membership = np.zeros(N, dtype=int)
                for cidx, comm in enumerate(communities):
                    for node in comm:
                        membership[node] = cidx
            # Small communities are anomalous
            comm_sizes = np.bincount(membership)
            scores = np.array([1.0 / (comm_sizes[m] + 1) for m in membership])

        elif algo_name == "OddBall":
            # Ego-net feature anomaly: nodes with unusual ego-net density
            degrees = np.array([G.degree(i) for i in range(N)], dtype=float)
            ego_edges = np.zeros(N)
            for i in range(N):
                ego = nx.ego_graph(G, i, radius=1)
                ego_edges[i] = ego.number_of_edges()
            # OddBall: deviation from power-law E ~ D^α
            expected_edges = degrees ** 1.5 / (degrees.max() ** 0.5 + 1e-10)
            scores = np.abs(ego_edges - expected_edges)

        elif algo_name == "Betweenness":
            bc = nx.betweenness_centrality(G)
            scores = np.array([bc.get(i, 0) for i in range(N)])
            # Very high OR very low betweenness can be anomalous
            median_bc = np.median(scores)
            scores = np.abs(scores - median_bc)

        return scores

    except Exception as exc:
        logger.warning(f"Graph algorithm {algo_name} failed: {exc}")
        return np.zeros(N)


def _run_changepoint(signal: np.ndarray, params: Dict) -> np.ndarray:
    """Change-point detection algorithm."""
    N = len(signal)
    try:
        import ruptures
        algo = ruptures.Pelt(model="rbf").fit(signal.reshape(-1, 1))
        result = algo.predict(pen=10)
        scores = np.zeros(N)
        for cp in result[:-1]:
            if 0 <= cp < N:
                window = max(1, N // 20)
                start = max(0, cp - window)
                end = min(N, cp + window)
                scores[start:end] += 1.0
        return scores
    except ImportError:
        # Simple rolling mean-shift fallback
        window = max(5, N // 20)
        scores = np.zeros(N)
        means = np.convolve(signal, np.ones(window) / window, mode='same')
        scores = np.abs(signal - means)
        return scores


def _run_matrixprofile(signal: np.ndarray, params: Dict) -> np.ndarray:
    """Matrix Profile algorithm."""
    N = len(signal)
    try:
        import stumpy
        window = min(params.get("window_size", 10), N // 3)
        window = max(window, 4)
        mp = stumpy.stump(signal.astype(np.float64), m=window)
        profile = mp[:, 0].astype(float)
        # Pad to match original length
        pad = N - len(profile)
        if pad > 0:
            profile = np.concatenate([profile, np.full(pad, np.median(profile))])
        return profile[:N]
    except ImportError:
        # Simple self-join distance fallback
        window = min(params.get("window_size", 10), N // 3)
        window = max(window, 4)
        scores = np.zeros(N)
        for i in range(N - window):
            subseq = signal[i:i + window]
            min_dist = np.inf
            for j in range(N - window):
                if abs(i - j) < window:
                    continue
                dist = np.sum((subseq - signal[j:j + window]) ** 2)
                if dist < min_dist:
                    min_dist = dist
            scores[i] = min_dist if min_dist < np.inf else 0
        return scores


def _run_vae(X: np.ndarray, params: Dict, contamination: float) -> np.ndarray:
    """VAE anomaly detection."""
    N, K = X.shape
    try:
        from pyod.models.vae import VAE
        hidden = params.get("hidden_neurons", [64, 32, 16])
        # Ensure hidden dims don't exceed input
        hidden = [min(h, max(K * 2, 8)) for h in hidden]
        model = VAE(
            encoder_neurons=hidden,
            decoder_neurons=hidden[::-1],
            epochs=params.get("epochs", 50),
            contamination=contamination,
            random_state=42,
            verbose=0,
        )
        model.fit(X)
        return model.decision_scores_
    except ImportError:
        # Reconstruction error fallback using PCA
        from sklearn.decomposition import PCA
        n_comp = min(max(K // 2, 2), K, N)
        pca = PCA(n_components=n_comp, random_state=42)
        X_proj = pca.fit_transform(X)
        X_recon = pca.inverse_transform(X_proj)
        recon_error = np.sqrt(np.sum((X - X_recon) ** 2, axis=1))
        return recon_error


# ─────────────────────────────────────────────────────────────────────────────
# INTERNAL SUOD EXECUTION
# ─────────────────────────────────────────────────────────────────────────────
def _run_suod_batch(
    algos: List[str],
    X: np.ndarray,
    params_map: Dict[str, Dict],
    contamination: float = 0.05,
) -> Dict[str, AlgoResult]:
    """
    Internal SUOD parallel execution.
    User NEVER sees this — system decides automatically.
    Extracts INDIVIDUAL per-algorithm scores (never aggregate).
    """
    results = {}
    try:
        from pyod.models.suod import SUOD
        from pyod.models.iforest import IForest
        from pyod.models.hbos import HBOS
        from pyod.models.lof import LOF
        from pyod.models.ecod import ECOD
        from pyod.models.copod import COPOD
        from pyod.models.knn import KNN

        N = X.shape[0]
        pyod_map = {
            "ExtIF": lambda p: IForest(n_estimators=p.get("n_estimators", 100),
                                       contamination=contamination, random_state=42),
            "HBOS":  lambda p: HBOS(n_bins=p.get("n_bins", 10), alpha=p.get("alpha", 0.1),
                                    contamination=contamination),
            "LOF":   lambda p: LOF(n_neighbors=min(p.get("n_neighbors", 20), N - 1),
                                   contamination=contamination),
            "ECOD":  lambda p: ECOD(contamination=contamination),
            "COPOD": lambda p: COPOD(contamination=contamination),
            "KNN":   lambda p: KNN(n_neighbors=min(p.get("n_neighbors", 10), N - 1),
                                   method=p.get("method", "largest"),
                                   contamination=contamination),
        }

        estimators = []
        mapping = {}  # {index: algo_name}

        for idx, algo in enumerate(algos):
            if algo in pyod_map:
                params = params_map.get(algo, {})
                estimators.append(pyod_map[algo](params))
                mapping[idx] = algo

        if len(estimators) < SUOD_MIN_ALGOS:
            return {}  # Not worth SUOD

        t0 = time.time()
        print(f"    [SUOD] Parallel execution of {len(estimators)} algorithms...")
        suod = SUOD(base_estimators=estimators, n_jobs=-1, verbose=False)
        suod.fit(X)

        # CRITICAL: Extract INDIVIDUAL scores per algorithm
        for idx, algo_name in mapping.items():
            try:
                # decision_scores_ from fitted sub-estimators
                individual_scores = suod.fitted_clf_[idx].decision_scores_
                individual_scores = _normalize_scores(individual_scores)

                result = AlgoResult(
                    algo_name=algo_name,
                    family=ALGO_TO_FAMILY.get(algo_name, "Unknown"),
                    scores=individual_scores,
                    n_anomalies=int(np.sum(individual_scores > 0.5)),
                    runtime_s=round(time.time() - t0, 3),
                    status="success",
                    internal_suod=True,
                )
                results[algo_name] = result
            except Exception as exc:
                logger.warning(f"SUOD individual extraction failed for {algo_name}: {exc}")

        speedup_s = round(time.time() - t0, 2)
        print(f"    [SUOD] Done: {len(results)}/{len(algos)} extracted in {speedup_s}s")

    except ImportError:
        logger.info("SUOD not available — falling back to sequential execution")
    except Exception as exc:
        logger.warning(f"SUOD batch failed: {exc}")
        traceback.print_exc()

    return results


# ─────────────────────────────────────────────────────────────────────────────
# MAIN EXECUTION ENGINE
# ─────────────────────────────────────────────────────────────────────────────
class AlgorithmExecutionEngine:
    """
    V30: L11 Detection — Algorithm Execution Pipeline.

    Modes:
      1. manual   — User selects families via checkboxes
      2. auto     — Agent decides based on data characteristics
      3. full     — Execute ALL applicable algorithms

    SUOD optimization is INTERNAL ONLY — user never sees it.
    """

    def __init__(self, contamination: float = 0.05):
        self.contamination = contamination
        self.result = AlgoExecutionResult()

    def execute(
        self,
        scaled_matrices: Dict[str, np.ndarray],
        X_original: np.ndarray,
        mode: str = "auto",
        selected_families: Optional[List[str]] = None,
        selected_algorithms: Optional[List[str]] = None,
        has_graph: bool = False,
        has_temporal: bool = False,
        has_amount: bool = False,
        algo_config_path: Optional[Path] = None,
        feature_names: Optional[List[str]] = None,
        progress_callback=None,
    ) -> AlgoExecutionResult:
        """
        Execute the algorithm pipeline.

        Args:
            scaled_matrices: Dict of scaler_name → np.ndarray (from ScalingEngine)
            X_original: Original unscaled data
            mode: 'manual' | 'auto' | 'full'
            selected_families: List of family names (for manual mode)
            selected_algorithms: List of specific algo names (override)
            has_graph: Whether GRAPH_DATA is available
            has_temporal: Whether TEMPORAL_DATA is available
            has_amount: Whether amount columns exist
            algo_config_path: Path to ALGO_CONFIG.json
            feature_names: Feature names from M4
            progress_callback: Optional callable(phase, algo, status) for UI updates

        Returns:
            AlgoExecutionResult with raw_scores, metadata, etc.
        """
        t_start = time.time()
        self.result = AlgoExecutionResult()
        self.result.execution_mode = mode
        self.result.timestamp = datetime.now().isoformat()

        # Get representative matrix for shape info
        X_ref = X_original
        if scaled_matrices:
            X_ref = next(iter(scaled_matrices.values()))
        N, K = X_ref.shape
        self.result.n_customers = N
        self.result.n_features = K

        print(f"\n{'='*70}")
        print(f"  [ALGO ENGINE] V30 L11 Detection Pipeline")
        print(f"  Mode: {mode} | N={N} | K={K} | Graph={has_graph} | Temporal={has_temporal}")
        print(f"{'='*70}")

        # ── STEP 1-3: Determine which algorithms to run ──
        algos_to_run = self._resolve_algorithms(
            mode, selected_families, selected_algorithms,
            N, K, has_graph, has_temporal, has_amount, algo_config_path
        )
        self.result.selected_algorithms = algos_to_run

        if not algos_to_run:
            self.result.phase_log.append("No algorithms selected — aborting")
            return self.result

        print(f"  Selected: {len(algos_to_run)} algorithms: {algos_to_run}")

        # Build family mapping
        for algo in algos_to_run:
            self.result.family_mapping[algo] = ALGO_TO_FAMILY.get(algo, "Unknown")

        # ── STEP 4: Internal SUOD decision ──
        suod_algos = [a for a in algos_to_run if a in SUOD_COMPATIBLE]
        use_suod = len(suod_algos) >= SUOD_MIN_ALGOS
        self.result.suod_used_internally = use_suod
        self.result.suod_algos = suod_algos if use_suod else []

        if use_suod:
            print(f"  [INTERNAL] SUOD enabled for speedup ({len(suod_algos)} compatible algos)")
        else:
            print(f"  [INTERNAL] Sequential execution (SUOD not beneficial, {len(suod_algos)} compatible)")

        # ── STEP 5-6: Execute by phase ──
        suod_results = {}
        if use_suod:
            # Get StandardScaler matrix for SUOD (SUOD-compatible algos use various scalers
            # but SUOD runs them all on one matrix — individual scores still correct)
            X_suod = _get_scaled_input("HBOS", scaled_matrices, X_original)  # StandardScaler
            params_map = {a: ALGO_DEFAULT_PARAMS.get(a, {}) for a in suod_algos}
            suod_results = _run_suod_batch(suod_algos, X_suod, params_map, self.contamination)

        for phase_name, phase_algos in EXECUTION_PHASES:
            phase_selected = [a for a in phase_algos if a in algos_to_run]
            if not phase_selected:
                continue

            print(f"\n  [{phase_name}] Running {len(phase_selected)} algorithms...")
            self.result.phase_log.append(f"{phase_name}: {phase_selected}")

            if progress_callback:
                try:
                    progress_callback(phase_name, "", "starting")
                except Exception:
                    pass

            for algo in phase_selected:
                # Check if already handled by SUOD
                if algo in suod_results:
                    self.result.algo_results[algo] = suod_results[algo]
                    self.result.raw_scores[algo] = suod_results[algo].scores
                    print(f"    ✓ {algo}: {suod_results[algo].n_anomalies} anomalies "
                          f"({suod_results[algo].runtime_s}s) [via SUOD]")
                    continue

                # Get correct input matrix for this algorithm
                X_algo = _get_scaled_input(algo, scaled_matrices, X_original)
                if X_algo is None:
                    self.result.algo_results[algo] = AlgoResult(
                        algo_name=algo, family=ALGO_TO_FAMILY.get(algo, ""),
                        status="skipped", error="No input matrix available"
                    )
                    continue

                # Run algorithm
                params = ALGO_DEFAULT_PARAMS.get(algo, {})
                result = _run_single_algorithm(algo, X_algo, params, self.contamination)
                self.result.algo_results[algo] = result

                if result.status == "success" and result.scores is not None:
                    self.result.raw_scores[algo] = result.scores
                    print(f"    ✓ {algo}: {result.n_anomalies} anomalies ({result.runtime_s}s)")
                else:
                    print(f"    ✗ {algo}: {result.status} — {result.error[:80]}")

                if progress_callback:
                    try:
                        progress_callback(phase_name, algo, result.status)
                    except Exception:
                        pass

        # ── STEP 7: Build metadata ──
        for algo, res in self.result.algo_results.items():
            self.result.algo_metadata[algo] = {
                "family": res.family,
                "weight": self._get_weight(algo),
                "executed": res.status == "success",
                "status": res.status,
                "runtime_s": res.runtime_s,
                "n_anomalies": res.n_anomalies,
            }

        self.result.total_runtime_s = round(time.time() - t_start, 2)

        n_success = sum(1 for r in self.result.algo_results.values() if r.status == "success")
        n_failed = sum(1 for r in self.result.algo_results.values() if r.status == "failed")
        n_skipped = sum(1 for r in self.result.algo_results.values() if r.status == "skipped")

        print(f"\n{'='*70}")
        print(f"  [DONE] {n_success} success | {n_failed} failed | {n_skipped} skipped "
              f"| {self.result.total_runtime_s}s total")
        print(f"{'='*70}\n")

        self.result.phase_log.append(
            f"TOTAL: {n_success}/{len(algos_to_run)} success in {self.result.total_runtime_s}s"
        )

        return self.result

    def _resolve_algorithms(
        self, mode, selected_families, selected_algorithms,
        N, K, has_graph, has_temporal, has_amount, algo_config_path
    ) -> List[str]:
        """Resolve which algorithms to run based on mode."""
        if selected_algorithms:
            return [a for a in selected_algorithms if a in ALL_ALGORITHMS]

        if mode == "manual" and selected_families:
            algos = []
            for fam in selected_families:
                fam_info = ALGO_FAMILIES.get(fam, {})
                requires = fam_info.get("requires")
                if requires == "graph_data" and not has_graph:
                    continue
                if requires == "temporal_data" and not has_temporal:
                    continue
                algos.extend(fam_info.get("algos", []))
            return algos

        if mode == "auto":
            return agent_auto_select(
                N, K, has_graph, has_temporal, has_amount, algo_config_path
            )

        if mode == "full":
            algos = []
            for fam, info in ALGO_FAMILIES.items():
                requires = info.get("requires")
                if requires == "graph_data" and not has_graph:
                    continue
                if requires == "temporal_data" and not has_temporal:
                    continue
                algos.extend(info["algos"])
            return algos

        return ["IQR", "ZScore"]  # Fallback

    def _get_weight(self, algo_name: str) -> float:
        """Get algorithm weight for ensemble fusion."""
        weights = {
            "IQR": 1.0, "ZScore": 1.0, "Mahalanobis": 1.5,
            "Benford": 2.0, "ExtIF": 1.8, "HBOS": 1.0,
            "LOF": 1.5, "ECOD": 1.0, "COPOD": 1.0,
            "KNN": 1.0, "GMM": 1.2, "HDBSCAN": 1.2,
            "BIRCH": 1.0, "PageRank": 1.0, "Leiden": 1.2,
            "OddBall": 1.5, "Betweenness": 1.0,
            "ChangePoint": 1.0, "MatrixProfile": 1.0, "VAE": 0.8,
        }
        return weights.get(algo_name, 1.0)

    # ── STEP 8: Output persistence ──
    def save_outputs(self, output_dir: Path) -> Dict[str, str]:
        """
        Save execution outputs to structured directory.
        User-facing files have NO SUOD references.
        Internal debug files go to _internal/.
        """
        output_dir.mkdir(parents=True, exist_ok=True)

        saved = {}
        r = self.result

        # ── User-facing: algo_execution/ ──
        exec_dir = output_dir / "algo_execution"
        exec_dir.mkdir(exist_ok=True)

        # RAW_SCORES.csv (N × M: customer_index + per-algo scores)
        if r.raw_scores:
            df_scores = pd.DataFrame(r.raw_scores)
            df_scores.index.name = "customer_idx"
            df_scores.to_csv(exec_dir / "RAW_SCORES.csv")
            np.save(exec_dir / "RAW_SCORES.npy", df_scores.values)
            saved["RAW_SCORES"] = str(exec_dir / "RAW_SCORES.csv")

        # EXECUTION_SUMMARY.json (no SUOD references)
        summary = {
            "timestamp": r.timestamp,
            "execution_mode": r.execution_mode,
            "n_customers": r.n_customers,
            "n_features": r.n_features,
            "total_algorithms_selected": len(r.selected_algorithms),
            "total_executed": sum(1 for v in r.algo_results.values() if v.status == "success"),
            "total_failed": sum(1 for v in r.algo_results.values() if v.status == "failed"),
            "total_skipped": sum(1 for v in r.algo_results.values() if v.status == "skipped"),
            "total_runtime_s": r.total_runtime_s,
            "algorithms": r.selected_algorithms,
        }
        with open(exec_dir / "EXECUTION_SUMMARY.json", "w") as f:
            json.dump(summary, f, indent=2, default=str)
        saved["EXECUTION_SUMMARY"] = str(exec_dir / "EXECUTION_SUMMARY.json")

        # FAMILY_MAPPING.json
        with open(exec_dir / "FAMILY_MAPPING.json", "w") as f:
            json.dump(r.family_mapping, f, indent=2)
        saved["FAMILY_MAPPING"] = str(exec_dir / "FAMILY_MAPPING.json")

        # ALGO_CONFIG_USED.json
        config_used = {}
        for algo in r.selected_algorithms:
            config_used[algo] = {
                "params": ALGO_DEFAULT_PARAMS.get(algo, {}),
                "routing": ALGO_INPUT_ROUTING.get(algo, {}),
                "family": ALGO_TO_FAMILY.get(algo, "Unknown"),
            }
        with open(exec_dir / "ALGO_CONFIG_USED.json", "w") as f:
            json.dump(config_used, f, indent=2, default=str)
        saved["ALGO_CONFIG_USED"] = str(exec_dir / "ALGO_CONFIG_USED.json")

        # EXECUTION_LOG.csv
        log_rows = []
        for algo, res in r.algo_results.items():
            log_rows.append({
                "algorithm": algo,
                "family": res.family,
                "status": res.status,
                "runtime_s": res.runtime_s,
                "n_anomalies": res.n_anomalies,
                "error": res.error,
            })
        pd.DataFrame(log_rows).to_csv(exec_dir / "EXECUTION_LOG.csv", index=False)
        saved["EXECUTION_LOG"] = str(exec_dir / "EXECUTION_LOG.csv")

        # ── Per-algorithm details ──
        details_dir = output_dir / "algo_details"
        details_dir.mkdir(exist_ok=True)
        for algo, res in r.algo_results.items():
            detail = {
                "algorithm": algo,
                "family": res.family,
                "status": res.status,
                "runtime_s": res.runtime_s,
                "n_anomalies": res.n_anomalies,
                "score_stats": {},
            }
            if res.scores is not None:
                detail["score_stats"] = {
                    "min": float(np.min(res.scores)),
                    "max": float(np.max(res.scores)),
                    "mean": float(np.mean(res.scores)),
                    "std": float(np.std(res.scores)),
                    "median": float(np.median(res.scores)),
                    "pct_above_0.5": float(np.mean(res.scores > 0.5) * 100),
                }
            with open(details_dir / f"{algo}_details.json", "w") as f:
                json.dump(detail, f, indent=2, default=str)

        # ── Internal debug: _internal/ ──
        internal_dir = output_dir / "_internal"
        internal_dir.mkdir(exist_ok=True)
        suod_log = {
            "suod_used": r.suod_used_internally,
            "algos_via_suod": r.suod_algos,
            "n_suod_compatible_selected": len([a for a in r.selected_algorithms if a in SUOD_COMPATIBLE]),
            "suod_threshold": SUOD_MIN_ALGOS,
        }
        with open(internal_dir / "suod_execution_log.json", "w") as f:
            json.dump(suod_log, f, indent=2)

        # ── Ready for fusion ──
        fusion_dir = output_dir / "ready_for_fusion"
        fusion_dir.mkdir(exist_ok=True)
        if r.raw_scores:
            df_scores = pd.DataFrame(r.raw_scores)
            df_scores.to_csv(fusion_dir / "RAW_SCORES_MATRIX.csv", index=False)
            pd.DataFrame({"customer_idx": range(r.n_customers)}).to_csv(
                fusion_dir / "CUSTOMER_IDS.csv", index=False
            )
            # User-facing metadata (no _internal_suod)
            user_meta = {}
            for algo, meta in r.algo_metadata.items():
                user_meta[algo] = {k: v for k, v in meta.items() if not k.startswith("_internal")}
            with open(fusion_dir / "ALGO_METADATA.json", "w") as f:
                json.dump(user_meta, f, indent=2, default=str)

        saved["fusion_dir"] = str(fusion_dir)
        return saved
