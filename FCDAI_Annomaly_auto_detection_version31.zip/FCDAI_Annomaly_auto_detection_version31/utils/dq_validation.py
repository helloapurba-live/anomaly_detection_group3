"""
Module 1: Data Quality Validation — 6-Step Gate
=================================================
Gate: DQ_SCORE ≥ 95% to proceed (override allowed with warning).

Steps:
  1. Schema Validation    → SCHEMA_COMPLIANCE_REPORT
  2. Completeness         → COMPLETENESS_MATRIX
  3. Validity             → INVALID_RECORDS
  4. Referential Integrity→ ORPHAN_RECORDS
  5. Uniqueness           → DUPLICATE_LOG
  6. DQ Score Calculation  → DQ_SCORECARD

Input : MASTER_TABLE DataFrame + optional GRAPH_DATA + TEMPORAL_DATA
Output: DQValidationResult with per-dimension scores, overall DQ score,
        and detailed reports (DataFrames) for each step.

Author: AIM AI Vault V23 — 5-Module Pipeline
"""

import pandas as pd
import numpy as np
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import json
import logging

logger = logging.getLogger("apurbadas.dq_validation")


# ─────────────────────────────────────────────────────────────────────────────
# RESULT DATACLASS
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class DQValidationResult:
    """Complete result from Module 1: DQ Validation."""
    # Overall
    dq_score: float = 0.0
    passed: bool = False
    override_allowed: bool = True

    # Per-dimension scores (0-1 scale)
    completeness_score: float = 0.0
    validity_score: float = 0.0
    consistency_score: float = 0.0
    timeliness_score: float = 0.0
    uniqueness_score: float = 0.0

    # Detailed reports
    schema_report: Optional[pd.DataFrame] = None
    completeness_matrix: Optional[pd.DataFrame] = None
    invalid_records: Optional[pd.DataFrame] = None
    orphan_records: Optional[pd.DataFrame] = None
    duplicate_log: Optional[pd.DataFrame] = None

    # Metadata
    total_rows: int = 0
    total_cols: int = 0
    step_log: List[Dict[str, Any]] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


# ─────────────────────────────────────────────────────────────────────────────
# MAIN ENGINE
# ─────────────────────────────────────────────────────────────────────────────
class DQValidationEngine:
    """
    6-Step Data Quality Validation Gate.
    Operates on the MASTER_TABLE produced by the Rollup Engine.
    """

    def __init__(self, base_key: str = "cust_id", dq_weights: Dict[str, float] = None,
                 pass_threshold: float = 0.95, allow_override: bool = True):
        self.base_key = base_key
        self.pass_threshold = pass_threshold
        self.allow_override = allow_override
        self.weights = dq_weights or {
            "completeness": 0.25,
            "validity": 0.25,
            "consistency": 0.20,
            "timeliness": 0.15,
            "uniqueness": 0.15,
        }

    def validate(self, df_raw: pd.DataFrame,
                 graph_df: Optional[pd.DataFrame] = None,
                 temporal_df: Optional[pd.DataFrame] = None,
                 parent_tables: Optional[Dict[str, pd.DataFrame]] = None
                 ) -> DQValidationResult:
        """Run all 6 DQ validation steps on the input DataFrame.

        V27: Parameter renamed from ``master_df`` → ``df_raw`` to match
        pipeline.py caller which always passes df_raw (raw ingested data).
        """
        result = DQValidationResult(
            total_rows=len(df_raw),
            total_cols=len(df_raw.columns),
            override_allowed=self.allow_override,
        )

        # V24: Store df reference for timeliness computation in _step6_score
        self.df = df_raw

        try:
            # Step 1: Schema Validation
            result.schema_report = self._step1_schema(df_raw, result)

            # Step 2: Completeness
            result.completeness_matrix = self._step2_completeness(df_raw, result)

            # Step 3: Validity
            result.invalid_records = self._step3_validity(df_raw, result)

            # Step 4: Referential Integrity
            result.orphan_records = self._step4_referential(
                df_raw, parent_tables or {}, result
            )

            # Step 5: Uniqueness
            result.duplicate_log = self._step5_uniqueness(df_raw, result)

            # Step 6: Calculate DQ Score
            self._step6_score(result)

        except Exception as e:
            logger.error(f"DQ Validation failed: {e}")
            result.step_log.append({"step": "ERROR", "message": str(e)})

        return result

    # ─────────────────────────────────────────────────────────────────────
    # STEP 1: SCHEMA VALIDATION
    # ─────────────────────────────────────────────────────────────────────
    def _step1_schema(self, df: pd.DataFrame, result: DQValidationResult) -> pd.DataFrame:
        """Verify columns exist, check dtypes, validate BASE_KEY."""
        rows = []
        for col in df.columns:
            dtype_str = str(df[col].dtype)
            # Guard against ExtensionDtype (e.g. StringDtype) that np.issubdtype cannot handle
            try:
                is_numeric = np.issubdtype(df[col].dtype, np.number)
            except TypeError:
                is_numeric = False
            try:
                is_datetime = np.issubdtype(df[col].dtype, np.datetime64)
            except TypeError:
                is_datetime = False
            is_string = df[col].dtype == object or pd.api.types.is_string_dtype(df[col])
            null_count = int(df[col].isnull().sum())

            rows.append({
                "column": col,
                "dtype": dtype_str,
                "is_numeric": is_numeric,
                "is_datetime": is_datetime,
                "is_string": is_string,
                "null_count": null_count,
                "unique_count": int(df[col].nunique()),
                "compliant": True,  # auto-inferred schema always compliant
            })

        # Validate BASE_KEY
        base_key_exists = self.base_key in df.columns
        base_key_not_null = df[self.base_key].isnull().sum() == 0 if base_key_exists else False
        base_key_unique = df[self.base_key].is_unique if base_key_exists else False

        result.step_log.append({
            "step": 1, "name": "Schema Validation",
            "base_key_exists": base_key_exists,
            "base_key_not_null": base_key_not_null,
            "base_key_unique": base_key_unique,
            "columns_found": len(df.columns),
            "status": "PASS" if base_key_exists else "WARN",
        })

        report = pd.DataFrame(rows)
        return report

    # ─────────────────────────────────────────────────────────────────────
    # STEP 2: COMPLETENESS
    # ─────────────────────────────────────────────────────────────────────
    def _step2_completeness(self, df: pd.DataFrame, result: DQValidationResult) -> pd.DataFrame:
        """Calculate missing % per column, flag WARNING/CRITICAL."""
        rows = []
        for col in df.columns:
            n = len(df)
            null_count = int(df[col].isnull().sum())
            missing_pct = null_count / n if n > 0 else 0

            if missing_pct > 0.20:
                severity = "CRITICAL"
            elif missing_pct > 0.05:
                severity = "WARNING"
            else:
                severity = "OK"

            # Missingness pattern (simplified)
            pattern = "MCAR"  # default assumption
            if missing_pct > 0:
                # Check if missingness correlates with other columns
                null_mask = df[col].isnull()
                if null_mask.sum() > 0:
                    numeric_cols = df.select_dtypes(include=[np.number]).columns
                    for other_col in numeric_cols[:5]:
                        if other_col != col:
                            try:
                                corr = null_mask.astype(float).corr(df[other_col].fillna(0))
                                if abs(corr) > 0.3:
                                    pattern = "MAR"
                                    break
                            except Exception:
                                pass

            rows.append({
                "column": col,
                "total_rows": n,
                "null_count": null_count,
                "missing_pct": round(missing_pct * 100, 2),
                "severity": severity,
                "pattern": pattern,
            })

        matrix = pd.DataFrame(rows)
        avg_completeness = 1.0 - matrix["missing_pct"].mean() / 100
        result.completeness_score = avg_completeness

        result.step_log.append({
            "step": 2, "name": "Completeness",
            "avg_completeness": round(avg_completeness, 4),
            "critical_columns": int((matrix["severity"] == "CRITICAL").sum()),
            "warning_columns": int((matrix["severity"] == "WARNING").sum()),
            "status": "PASS" if avg_completeness >= 0.95 else "WARN",
        })
        return matrix

    # ─────────────────────────────────────────────────────────────────────
    # STEP 3: VALIDITY
    # ─────────────────────────────────────────────────────────────────────
    def _step3_validity(self, df: pd.DataFrame, result: DQValidationResult) -> pd.DataFrame:
        """Range checks, date checks, enum checks."""
        invalid_rows = []
        n = len(df)
        # V24 FIX: Track invalid row INDICES to avoid double-counting across columns
        invalid_row_indices = set()

        for col in df.columns:
            col_lower = col.lower()
            series = df[col]

            # Guard against ExtensionDtype
            try:
                _is_numeric = np.issubdtype(series.dtype, np.number)
            except TypeError:
                _is_numeric = False
            try:
                _is_datetime = np.issubdtype(series.dtype, np.datetime64)
            except TypeError:
                _is_datetime = False

            # Range checks for numeric columns
            if _is_numeric:
                # Amount should be >= 0 (bank AML: flag negatives)
                if any(kw in col_lower for kw in ["amount", "amt", "value", "balance"]):
                    neg_mask = series.dropna() < 0
                    neg_count = int(neg_mask.sum())
                    if neg_count > 0:
                        invalid_rows.append({
                            "column": col, "rule": "amount >= 0",
                            "invalid_count": neg_count,
                            "reason_code": "NEGATIVE_AMOUNT",
                        })
                        # V24 FIX: track row indices, not decrement counter
                        invalid_row_indices.update(series.dropna().index[neg_mask])

                # Age 18-120
                if "age" in col_lower:
                    out = ((series.dropna() < 18) | (series.dropna() > 120)).sum()
                    if out > 0:
                        invalid_rows.append({
                            "column": col, "rule": "18 <= age <= 120",
                            "invalid_count": int(out),
                            "reason_code": "OUT_OF_RANGE_AGE",
                        })
                        # V24 FIX: track row indices
                        age_invalid = (series.dropna() < 18) | (series.dropna() > 120)
                        invalid_row_indices.update(series.dropna().index[age_invalid])

                # Risk score 0-100
                if "risk" in col_lower and "score" in col_lower:
                    out = ((series.dropna() < 0) | (series.dropna() > 100)).sum()
                    if out > 0:
                        invalid_rows.append({
                            "column": col, "rule": "0 <= risk_score <= 100",
                            "invalid_count": int(out),
                            "reason_code": "OUT_OF_RANGE_RISK",
                        })
                        # V24 FIX: track row indices
                        risk_invalid = (series.dropna() < 0) | (series.dropna() > 100)
                        invalid_row_indices.update(series.dropna().index[risk_invalid])

            # Date checks
            if _is_datetime:
                now = pd.Timestamp.now()
                future_limit = now + pd.Timedelta(days=365)
                ancient_limit = now - pd.Timedelta(days=36500)  # ~100 years

                future_count = int((series.dropna() > future_limit).sum())
                ancient_count = int((series.dropna() < ancient_limit).sum())

                if future_count > 0:
                    invalid_rows.append({
                        "column": col, "rule": "date <= SYSDATE+1yr",
                        "invalid_count": future_count,
                        "reason_code": "FUTURE_DATE",
                    })
                    # V24 FIX: track row indices
                    invalid_row_indices.update(series.dropna().index[series.dropna() > future_limit])
                if ancient_count > 0:
                    invalid_rows.append({
                        "column": col, "rule": "date >= SYSDATE-100yr",
                        "invalid_count": ancient_count,
                        "reason_code": "ANCIENT_DATE",
                    })
                    # V24 FIX: track row indices
                    invalid_row_indices.update(series.dropna().index[series.dropna() < ancient_limit])

        report = pd.DataFrame(invalid_rows) if invalid_rows else pd.DataFrame(
            columns=["column", "rule", "invalid_count", "reason_code"]
        )

        # V24 FIX: Row-level validity from unique invalid row indices
        validity = (n - len(invalid_row_indices)) / n if n > 0 else 1.0
        result.validity_score = validity

        result.step_log.append({
            "step": 3, "name": "Validity",
            "validity_score": round(validity, 4),
            "invalid_rules_triggered": len(invalid_rows),
            "status": "PASS" if validity >= 0.95 else "WARN",
        })
        return report

    # ─────────────────────────────────────────────────────────────────────
    # STEP 4: REFERENTIAL INTEGRITY
    # ─────────────────────────────────────────────────────────────────────
    def _step4_referential(self, df_raw: pd.DataFrame,
                           parent_tables: Dict[str, pd.DataFrame],
                           result: DQValidationResult) -> pd.DataFrame:
        """Check FK references: no orphan records."""
        orphan_rows = []
        total_refs = 0
        valid_refs = 0

        if self.base_key in df_raw.columns:
            master_keys = set(df_raw[self.base_key].dropna().unique())

            for tname, tdf in parent_tables.items():
                if self.base_key in tdf.columns:
                    child_keys = set(tdf[self.base_key].dropna().unique())
                    orphans = child_keys - master_keys
                    total_refs += len(child_keys)
                    valid_refs += len(child_keys) - len(orphans)

                    if orphans:
                        for orphan_key in list(orphans)[:100]:  # cap at 100
                            orphan_rows.append({
                                "table": tname,
                                "orphan_key": str(orphan_key),
                                "key_column": self.base_key,
                            })

        report = pd.DataFrame(orphan_rows) if orphan_rows else pd.DataFrame(
            columns=["table", "orphan_key", "key_column"]
        )

        ref_score = valid_refs / total_refs if total_refs > 0 else 1.0
        # Referential integrity contributes to consistency
        result.consistency_score = ref_score

        result.step_log.append({
            "step": 4, "name": "Referential Integrity",
            "total_references": total_refs,
            "valid_references": valid_refs,
            "orphan_count": len(orphan_rows),
            "status": "PASS" if ref_score >= 0.95 else "WARN",
        })
        return report

    # ─────────────────────────────────────────────────────────────────────
    # STEP 5: UNIQUENESS
    # ─────────────────────────────────────────────────────────────────────
    def _step5_uniqueness(self, df: pd.DataFrame, result: DQValidationResult) -> pd.DataFrame:
        """Check PRIMARY KEY uniqueness, identify full-row duplicates."""
        dup_rows = []
        n = len(df)

        # Primary key uniqueness
        if self.base_key in df.columns:
            pk_dups = df[df.duplicated(subset=[self.base_key], keep=False)]
            pk_dup_count = len(pk_dups)
            if pk_dup_count > 0:
                dup_rows.append({
                    "check": "PRIMARY_KEY",
                    "column": self.base_key,
                    "duplicate_count": pk_dup_count,
                    "unique_dup_keys": int(pk_dups[self.base_key].nunique()),
                    "strategy": "KEEP_FIRST",
                })

        # Full-row duplicates
        full_dups = df[df.duplicated(keep=False)]
        full_dup_count = len(full_dups)
        # V24 FIX: Count actual extra copies (not all rows in dup groups)
        full_extra_copies = int(df.duplicated(keep='first').sum())
        if full_dup_count > 0:
            dup_rows.append({
                "check": "FULL_ROW",
                "column": "ALL",
                "duplicate_count": full_dup_count,
                "unique_dup_keys": full_dup_count - full_extra_copies,
                "strategy": "KEEP_FIRST",
            })

        report = pd.DataFrame(dup_rows) if dup_rows else pd.DataFrame(
            columns=["check", "column", "duplicate_count", "unique_dup_keys", "strategy"]
        )

        pk_unique = 1.0
        if self.base_key in df.columns and n > 0:
            pk_unique = df[self.base_key].nunique() / n

        # V24 FIX: Use actual extra copies for correct uniqueness
        full_unique = (n - full_extra_copies) / n if n > 0 else 1.0
        result.uniqueness_score = min(pk_unique, full_unique)

        result.step_log.append({
            "step": 5, "name": "Uniqueness",
            "pk_uniqueness": round(pk_unique, 4),
            "full_row_uniqueness": round(full_unique, 4),
            "total_duplicates": pk_dup_count if self.base_key in df.columns else 0,
            "status": "PASS" if result.uniqueness_score >= 0.95 else "WARN",
        })
        return report

    # ─────────────────────────────────────────────────────────────────────
    # STEP 6: DQ SCORE CALCULATION
    # ─────────────────────────────────────────────────────────────────────
    def _step6_score(self, result: DQValidationResult):
        """
        DQ_SCORE = Σ(dimension_score × weight)
        Weights: Completeness 25%, Validity 25%, Consistency 20%,
                 Timeliness 15%, Uniqueness 15%
        """
        # V24 FIX: Compute actual timeliness from datetime column freshness
        timeliness = 1.0
        if result.schema_report is not None and 'is_datetime' in result.schema_report.columns:
            dt_cols = result.schema_report[result.schema_report['is_datetime']]['column'].tolist()
            if dt_cols:
                max_dates = []
                for c in dt_cols:
                    if c in self.df.columns:
                        try:
                            col_max = pd.to_datetime(self.df[c], errors='coerce').max()
                            if pd.notna(col_max):
                                max_dates.append(col_max)
                        except Exception:
                            pass
                if max_dates:
                    most_recent = max(max_dates)
                    days_stale = (pd.Timestamp.now() - most_recent).days
                    timeliness = max(0.0, 1.0 - days_stale / 365)
                else:
                    timeliness = min(1.0, result.completeness_score + 0.02)
            else:
                timeliness = min(1.0, result.completeness_score + 0.02)
        else:
            timeliness = min(1.0, result.completeness_score + 0.02)
        result.timeliness_score = timeliness

        scores = {
            "completeness": result.completeness_score,
            "validity": result.validity_score,
            "consistency": result.consistency_score,
            "timeliness": result.timeliness_score,
            "uniqueness": result.uniqueness_score,
        }

        dq_score = sum(scores[dim] * self.weights.get(dim, 0) for dim in scores)
        result.dq_score = round(dq_score, 4)
        result.passed = result.dq_score >= self.pass_threshold

        result.step_log.append({
            "step": 6, "name": "DQ Score Calculation",
            "dq_score": result.dq_score,
            "scores": {k: round(v, 4) for k, v in scores.items()},
            "weights": self.weights,
            "threshold": self.pass_threshold,
            "passed": result.passed,
            "status": "PASS" if result.passed else "FAIL",
        })

        logger.info(
            f"DQ Score: {result.dq_score:.1%} "
            f"({'PASS' if result.passed else 'FAIL — override={self.allow_override}'})"
        )

    # ─────────────────────────────────────────────────────────────────────
    # UTILITY: Export scorecard as dict (for JSON serialization)
    # ─────────────────────────────────────────────────────────────────────
    def scorecard_to_dict(self, result: DQValidationResult) -> Dict[str, Any]:
        """Export the DQ scorecard as a serializable dictionary."""
        return {
            "dq_score": result.dq_score,
            "passed": result.passed,
            "dimensions": {
                "completeness": round(result.completeness_score, 4),
                "validity": round(result.validity_score, 4),
                "consistency": round(result.consistency_score, 4),
                "timeliness": round(result.timeliness_score, 4),
                "uniqueness": round(result.uniqueness_score, 4),
            },
            "total_rows": result.total_rows,
            "total_cols": result.total_cols,
            "step_log": result.step_log,
            "timestamp": result.timestamp,
        }
