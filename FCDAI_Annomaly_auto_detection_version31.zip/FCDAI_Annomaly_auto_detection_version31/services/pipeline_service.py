"""
AIM AI Vault V14 — Pipeline Service Layer
==========================================
Abstraction layer between Dash page callbacks and the pipeline engine.
Enforces data contracts, records audit entries, manages run versioning,
and applies circuit breaker patterns.

Pages should call PipelineService instead of ApurbaDasPipeline directly.

Author: AIM AI Vault Team
"""

import sys
import uuid
import json
import time
import logging
import cProfile
import pstats
import io
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any

import pandas as pd

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import PATHS, APP, AUDIT, PROFILING
from utils.error_codes import ErrorCode
from utils.contracts import PipelineResultContract

_svc_logger = logging.getLogger("apurbadas.pipeline_service")


class PipelineService:
    """
    Service façade for pipeline operations.

    Responsibilities:
    - Generate run_id (UUID)
    - Validate inputs via data contracts
    - Execute pipeline with circuit breaker
    - Profile execution (optional)
    - Persist results with run-partitioned Parquet
    - Audit-log every run (start + end)
    - Return validated PipelineResultContract
    """

    def __init__(self):
        from pipeline import ApurbaDasPipeline
        self._pipeline = ApurbaDasPipeline()

    def execute_pipeline(
        self,
        sources: Dict[str, pd.DataFrame],
        detection_methods: Optional[List[str]] = None,
        ensemble_method: str = "weighted_average",
        user: str = "system",
        merged_df: Optional[pd.DataFrame] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Execute the full 7-layer pipeline with service-level orchestration.

        Returns a dict containing:
          - result: PipelineResultContract (validated)
          - df_scored: DataFrame (or None)
          - run_id: str
          - profiling_path: str | None
        """
        run_id = uuid.uuid4().hex[:12]
        start_time = time.time()

        # Audit: pipeline start
        self._audit("PIPELINE_START", user, {
            "run_id": run_id,
            "sources": list(sources.keys()) if sources else [],
            "methods": detection_methods,
            "ensemble": ensemble_method,
        })

        profiling_path = None

        try:
            # Optional cProfile profiling
            if PROFILING.ENABLED:
                profiler = cProfile.Profile()
                profiler.enable()

            # Execute pipeline
            result = self._pipeline.run(
                sources=sources,
                detection_methods=detection_methods,
                ensemble_method=ensemble_method,
                merged_df=merged_df,
                **kwargs,
            )

            if PROFILING.ENABLED:
                profiler.disable()
                profiling_path = self._save_profile(profiler, run_id)

            # Stamp run_id on result
            result.run_id = run_id

            # Persist scored data with run-partitioned Parquet
            if result.success and result.df_scored is not None:
                self._persist_run_data(result.df_scored, run_id)

            # V27: Persist Tier 2 analytics (feature importance, DQ, model perf, etc.)
            if result.success:
                try:
                    from services.tier2_persistence import persist_tier2
                    persist_tier2(
                        run_id=run_id,
                        pipeline_instance=self._pipeline,
                        pipeline_result=result,
                        score_matrix=getattr(self._pipeline, '_last_score_matrix', None),
                        method_names=getattr(self._pipeline, '_last_method_names', None),
                        df_scored=result.df_scored,
                        layer_timings=result.layer_timings,
                        failed_methods=result.failed_methods,
                        cb_skipped=result.circuit_breaker_skipped,
                    )
                except Exception as t2e:
                    _svc_logger.warning(f"[SVC] Tier 2 persistence non-fatal: {type(t2e).__name__}: {t2e}")

            # Build validated contract
            contract = PipelineResultContract(
                success=result.success,
                timestamp=result.timestamp,
                records_processed=result.records_processed,
                dq_score=result.dq_score,
                features_generated=result.features_generated,
                methods_run=result.methods_run,
                alerts_generated=result.alerts_generated,
                tier_distribution=result.tier_distribution,
                execution_time_ms=result.execution_time_ms,
                layer_timings=result.layer_timings,
                error=result.error,
                run_id=run_id,
                input_hash=result.input_hash,
                profiling_path=profiling_path,
            )

            try:
                contract.validate()
            except Exception as ve:
                _svc_logger.warning(f"Contract validation warning: {ve}")

            # Audit: pipeline end
            elapsed_sec = time.time() - start_time
            self._audit("PIPELINE_COMPLETE" if result.success else "PIPELINE_FAILED", user, {
                "run_id": run_id,
                "success": result.success,
                "records": result.records_processed,
                "methods_run": result.methods_run,
                "alerts": result.alerts_generated,
                "elapsed_sec": round(elapsed_sec, 2),
                "error": result.error,
            })

            return {
                "result": contract,
                "df_scored": result.df_scored,
                "ensemble_result": result.ensemble_result,
                "run_id": run_id,
                "profiling_path": profiling_path,
                "pipeline_result_raw": result,
            }

        except Exception as exc:
            elapsed_sec = time.time() - start_time
            safe_error = f"{type(exc).__name__}: pipeline execution failed"
            _svc_logger.error(f"Pipeline service error: {exc}", exc_info=True)
            self._audit("PIPELINE_FAILED", user, {
                "run_id": run_id,
                "error": safe_error,
                "elapsed_sec": round(elapsed_sec, 2),
            })
            return {
                "result": PipelineResultContract(
                    success=False,
                    timestamp=datetime.now().isoformat(),
                    records_processed=0,
                    dq_score=0.0,
                    features_generated=0,
                    methods_run=0,
                    alerts_generated=0,
                    tier_distribution={},
                    execution_time_ms=elapsed_sec * 1000,
                    error=safe_error,
                    run_id=run_id,
                ),
                "df_scored": None,
                "ensemble_result": None,
                "run_id": run_id,
                "profiling_path": None,
                "pipeline_result_raw": None,
            }

    def _persist_run_data(self, df_scored: pd.DataFrame, run_id: str):
        """Save scored data as run-partitioned Parquet."""
        try:
            run_dir = PATHS.RUN_HISTORY / run_id
            run_dir.mkdir(parents=True, exist_ok=True)
            output_path = run_dir / "scored.parquet"
            df_scored.to_parquet(output_path, index=False, engine="pyarrow")
            _svc_logger.info(f"[SVC] Persisted run {run_id}: {len(df_scored)} rows → {output_path}")
        except Exception as exc:
            _svc_logger.warning(f"[SVC] Run persist failed: {type(exc).__name__}")

    def _save_profile(self, profiler: cProfile.Profile, run_id: str) -> Optional[str]:
        """Save cProfile results to file."""
        try:
            profile_dir = Path(PROFILING.OUTPUT_DIR)
            profile_dir.mkdir(parents=True, exist_ok=True)
            output_path = profile_dir / f"profile_{run_id}.txt"
            stream = io.StringIO()
            sort_key = "cumulative" if PROFILING.CUMULATIVE_SORT else "time"
            stats = pstats.Stats(profiler, stream=stream)
            stats.sort_stats(sort_key)
            stats.print_stats(PROFILING.TOP_N_FUNCTIONS)
            output_path.write_text(stream.getvalue(), encoding="utf-8")
            _svc_logger.info(f"[SVC] Profile saved: {output_path}")
            return str(output_path)
        except Exception as exc:
            _svc_logger.warning(f"[SVC] Profile save failed: {type(exc).__name__}")
            return None

    def _audit(self, action: str, user: str, metadata: Dict):
        """Log to audit trail."""
        try:
            from utils.logger import logger
            logger.log_action(action, user=user, metadata=metadata)
        except Exception:
            pass

    def get_run_history(self, limit: int = 50) -> List[Dict]:
        """List all pipeline runs from run history directory."""
        runs = []
        try:
            if PATHS.RUN_HISTORY.exists():
                for run_dir in sorted(PATHS.RUN_HISTORY.iterdir(), reverse=True):
                    if run_dir.is_dir():
                        meta_path = run_dir / "scored.parquet"
                        runs.append({
                            "run_id": run_dir.name,
                            "has_data": meta_path.exists(),
                            "created": datetime.fromtimestamp(
                                run_dir.stat().st_ctime
                            ).isoformat(),
                        })
                        if len(runs) >= limit:
                            break
        except Exception:
            pass
        return runs

    def get_pipeline_instance(self):
        """Get the underlying pipeline instance (for backward compatibility)."""
        return self._pipeline
