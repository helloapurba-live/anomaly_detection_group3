"""
V27 — Tier 2 Persistence Helper
===================================
Persists pipeline run artifacts into the 6 new Tier 2 SQLAlchemy tables:
  C1: FeatureImportance
  C2: DataQualityMetric
  C3: ModelPerformance
  C4: AnomalyMethodScore
  C5: EntityGraphMetric
  C6: MethodExecutionLog

Called from pipeline_service after a successful pipeline execution.
Author: AIM AI Vault V27
"""

import numpy as np
import pandas as pd
import json
import logging
import time
from typing import Dict, Any, Optional, List
from datetime import datetime

logger = logging.getLogger("apurbadas.tier2_persistence")


def persist_tier2(
    run_id: str,
    pipeline_instance,
    pipeline_result,
    score_matrix: np.ndarray = None,
    method_names: List[str] = None,
    df_scored: pd.DataFrame = None,
    dq_report=None,
    layer_timings: Dict[str, float] = None,
    failed_methods: List[str] = None,
    cb_skipped: List[str] = None,
):
    """
    Persist all Tier 2 statistics into the database.
    
    Non-fatal: all errors are caught and logged, never blocks pipeline.
    """
    try:
        from database.engine import get_session
        from database.models import (
            FeatureImportance, DataQualityMetric, ModelPerformance,
            AnomalyMethodScore, EntityGraphMetric, MethodExecutionLog,
            Anomaly,
        )
    except ImportError as e:
        logger.warning(f"[TIER2] Cannot import DB models: {e}")
        return

    session = None
    try:
        session = get_session()
        
        # ─── C1: Feature Importance ───
        _persist_feature_importance(session, run_id, pipeline_instance, FeatureImportance)
        
        # ─── C2: Data Quality Metrics ───
        _persist_dq_metrics(session, run_id, df_scored, DataQualityMetric)
        
        # ─── C3: Model Performance ───
        _persist_model_performance(
            session, run_id, pipeline_instance, pipeline_result,
            score_matrix, method_names, ModelPerformance,
        )
        
        # ─── C4: Anomaly Method Scores ───
        _persist_anomaly_method_scores(
            session, run_id, score_matrix, method_names,
            pipeline_result, AnomalyMethodScore, Anomaly,
        )
        
        # ─── C5: Entity Graph Metrics ───
        _persist_graph_metrics(session, run_id, pipeline_instance, EntityGraphMetric)
        
        # ─── C6: Method Execution Logs ───
        _persist_method_execution_logs(
            session, run_id, pipeline_instance, method_names,
            failed_methods, cb_skipped, layer_timings, MethodExecutionLog,
        )
        
        session.commit()
        logger.info(f"[TIER2] Persisted all Tier 2 data for run {run_id}")
        
    except Exception as e:
        logger.warning(f"[TIER2] Persistence error: {type(e).__name__}: {e}")
        if session:
            try:
                session.rollback()
            except Exception:
                pass
    finally:
        if session:
            try:
                session.close()
            except Exception:
                pass


# ─────────────────────────────────────────────────────────────────────────────
# C1: FEATURE IMPORTANCE
# ─────────────────────────────────────────────────────────────────────────────
def _persist_feature_importance(session, run_id, pipeline_instance, FIModel):
    """Save SHAP / permutation importance per method per feature."""
    try:
        from pathlib import Path
        from config import PATHS
        
        shap_path = PATHS.DATA_VAULT / "shap_results.json"
        if not shap_path.exists():
            logger.info("[TIER2-C1] No shap_results.json found, skipping feature importance")
            return
        
        with open(shap_path) as f:
            shap_data = json.load(f)
        
        rows = []
        for method_name, method_data in shap_data.items():
            importance_list = method_data.get("global_importance", [])
            explainer_type = method_data.get("explainer_type", "unknown")
            for item in importance_list:
                rows.append(FIModel(
                    run_id=run_id,
                    method_name=method_name,
                    feature_name=item.get("feature", ""),
                    importance_score=float(item.get("mean_abs_shap", 0)),
                    rank=int(item.get("rank", 0)),
                    explainer_type=explainer_type,
                ))
        
        if rows:
            session.add_all(rows)
            logger.info(f"[TIER2-C1] {len(rows)} feature importance rows for run {run_id}")
    except Exception as e:
        logger.warning(f"[TIER2-C1] Error: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# C2: DATA QUALITY METRICS
# ─────────────────────────────────────────────────────────────────────────────
def _persist_dq_metrics(session, run_id, df_scored, DQModel):
    """Save column-level DQ stats from the scored DataFrame."""
    try:
        if df_scored is None or df_scored.empty:
            return
        
        numeric_cols = df_scored.select_dtypes(include=[np.number]).columns
        rows = []
        for col in numeric_cols:
            series = df_scored[col]
            non_null = series.dropna()
            if len(non_null) == 0:
                continue
            
            mean_val = float(non_null.mean())
            std_val = float(non_null.std()) if len(non_null) > 1 else 0.0
            
            # Outlier count: |z| > 3
            if std_val > 1e-10:
                z_scores = np.abs((non_null - mean_val) / std_val)
                n_outliers = int((z_scores > 3).sum())
            else:
                n_outliers = 0
            
            rows.append(DQModel(
                run_id=run_id,
                column_name=str(col),
                completeness=round(float(1 - series.isna().mean()), 4),
                uniqueness=round(float(series.nunique() / max(len(series), 1)), 4),
                mean_value=round(mean_val, 6),
                std_value=round(std_val, 6),
                min_value=round(float(non_null.min()), 6),
                max_value=round(float(non_null.max()), 6),
                skewness=round(float(non_null.skew()), 4) if len(non_null) > 2 else None,
                kurtosis=round(float(non_null.kurtosis()), 4) if len(non_null) > 3 else None,
                n_outliers=n_outliers,
                n_zeros=int((series == 0).sum()),
            ))
        
        if rows:
            session.add_all(rows)
            logger.info(f"[TIER2-C2] {len(rows)} DQ metric rows for run {run_id}")
    except Exception as e:
        logger.warning(f"[TIER2-C2] Error: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# C3: MODEL PERFORMANCE
# ─────────────────────────────────────────────────────────────────────────────
def _persist_model_performance(session, run_id, pipeline_instance, result, score_matrix, method_names, MPModel):
    """Save per-method performance metrics."""
    try:
        if score_matrix is None or method_names is None:
            return
        
        ensemble_labels = None
        if result and hasattr(result, 'ensemble_result') and result.ensemble_result is not None:
            if hasattr(result.ensemble_result, 'risk_tiers'):
                ensemble_labels = np.array([1 if t == "CRITICAL" or t == "HIGH" else 0 
                                            for t in result.ensemble_result.risk_tiers])
        
        rows = []
        n_total = score_matrix.shape[0]
        
        for i, method_name in enumerate(method_names):
            scores = score_matrix[:, i]
            flagged = (scores > np.percentile(scores, 95)).astype(int) if scores.max() > 0 else np.zeros(n_total)
            n_flagged = int(flagged.sum())
            
            # Ensemble agreement
            agreement = None
            if ensemble_labels is not None and len(ensemble_labels) == n_total:
                agreement = float(np.mean(flagged == ensemble_labels))
            
            rows.append(MPModel(
                run_id=run_id,
                method_name=method_name,
                n_flagged=n_flagged,
                anomaly_rate=round(n_flagged / max(n_total, 1), 6),
                mean_score=round(float(scores.mean()), 6),
                std_score=round(float(scores.std()), 6),
                max_score=round(float(scores.max()), 6),
                score_p95=round(float(np.percentile(scores, 95)), 6),
                ensemble_agreement=round(agreement, 4) if agreement is not None else None,
            ))
        
        if rows:
            session.add_all(rows)
            logger.info(f"[TIER2-C3] {len(rows)} model performance rows for run {run_id}")
    except Exception as e:
        logger.warning(f"[TIER2-C3] Error: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# C4: ANOMALY METHOD SCORES
# ─────────────────────────────────────────────────────────────────────────────
def _persist_anomaly_method_scores(session, run_id, score_matrix, method_names, result, AMSModel, AnomalyModel):
    """Save normalized per-anomaly per-method scores."""
    try:
        if score_matrix is None or method_names is None:
            return
        
        # Get anomaly IDs from DB for this run
        anomalies = session.query(AnomalyModel).filter(AnomalyModel.run_id == run_id).all()
        if not anomalies:
            logger.info("[TIER2-C4] No anomalies in DB for this run, skipping")
            return
        
        # Map row_index to anomaly ID
        idx_to_anomaly = {a.row_index: a for a in anomalies if a.row_index is not None}
        
        rows = []
        for i, method_name in enumerate(method_names):
            scores = score_matrix[:, i]
            score_range = scores.max() - scores.min()
            
            for row_idx, anomaly in idx_to_anomaly.items():
                if row_idx >= len(scores):
                    continue
                raw = float(scores[row_idx])
                normalized = float((raw - scores.min()) / score_range) if score_range > 1e-10 else 0.0
                # Is this entity flagged by this method? (top 5%)
                threshold = np.percentile(scores, 95)
                
                rows.append(AMSModel(
                    anomaly_id=anomaly.id,
                    run_id=run_id,
                    method_name=method_name,
                    raw_score=round(raw, 6),
                    normalized_score=round(normalized, 6),
                    is_flagged=bool(raw >= threshold),
                    rank_in_method=int(np.sum(scores >= raw)),
                ))
        
        if rows:
            session.add_all(rows)
            logger.info(f"[TIER2-C4] {len(rows)} anomaly method scores for run {run_id}")
    except Exception as e:
        logger.warning(f"[TIER2-C4] Error: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# C5: ENTITY GRAPH METRICS
# ─────────────────────────────────────────────────────────────────────────────
def _persist_graph_metrics(session, run_id, pipeline_instance, EGMModel):
    """Save graph centrality metrics from L5 graph detectors."""
    try:
        detection = pipeline_instance.detection if hasattr(pipeline_instance, 'detection') else None
        if detection is None:
            return
        
        # Check for graph detector results
        graph_methods = ["pagerank", "centrality", "hits", "community"]
        graph_data = {}
        
        for m in graph_methods:
            if m in detection.results:
                graph_data[m] = detection.results[m].scores
        
        if not graph_data:
            logger.info("[TIER2-C5] No graph detector results available")
            return
        
        n_entities = max(len(s) for s in graph_data.values())
        rows = []
        
        for idx in range(n_entities):
            pr = float(graph_data["pagerank"][idx]) if "pagerank" in graph_data and idx < len(graph_data["pagerank"]) else None
            cent = float(graph_data["centrality"][idx]) if "centrality" in graph_data and idx < len(graph_data["centrality"]) else None
            hits_val = float(graph_data["hits"][idx]) if "hits" in graph_data and idx < len(graph_data["hits"]) else None
            comm = float(graph_data["community"][idx]) if "community" in graph_data and idx < len(graph_data["community"]) else None
            
            rows.append(EGMModel(
                run_id=run_id,
                entity_id=str(idx),
                entity_index=idx,
                pagerank=pr,
                betweenness=cent,           # Using centrality score as proxy
                closeness=hits_val,          # Using HITS score as proxy
                eigenvector=None,
                degree=None,
                community_id=int(comm) if comm is not None and not np.isnan(comm) else None,
            ))
        
        # Limit to avoid massive inserts
        if len(rows) > 5000:
            rows = rows[:5000]
        
        if rows:
            session.add_all(rows)
            logger.info(f"[TIER2-C5] {len(rows)} entity graph metric rows for run {run_id}")
    except Exception as e:
        logger.warning(f"[TIER2-C5] Error: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# C6: METHOD EXECUTION LOGS
# ─────────────────────────────────────────────────────────────────────────────
def _persist_method_execution_logs(
    session, run_id, pipeline_instance, method_names,
    failed_methods, cb_skipped, layer_timings, MELModel,
):
    """Save per-method execution telemetry."""
    try:
        if method_names is None:
            return
        
        detection = pipeline_instance.detection if hasattr(pipeline_instance, 'detection') else None
        
        rows = []
        
        # Successful / failed methods
        for method_name in method_names:
            status = "failed" if method_name in (failed_methods or []) else "success"
            n_flags = 0
            n_input = 0
            
            if detection and method_name in detection.results:
                det_result = detection.results[method_name]
                n_flags = int(det_result.labels.sum())
                n_input = len(det_result.scores)
            
            rows.append(MELModel(
                run_id=run_id,
                method_name=method_name,
                status=status,
                duration_ms=None,  # Individual method timing not tracked yet
                n_input_rows=n_input,
                n_flags=n_flags,
                skip_reason=None,
                circuit_breaker_state="closed",
                error_type=None if status == "success" else "zero-output",
            ))
        
        # Circuit-breaker skipped methods
        for method_name in (cb_skipped or []):
            rows.append(MELModel(
                run_id=run_id,
                method_name=method_name,
                status="cb_open",
                duration_ms=0,
                n_input_rows=0,
                n_flags=0,
                skip_reason="circuit_breaker_open",
                circuit_breaker_state="open",
            ))
        
        if rows:
            session.add_all(rows)
            logger.info(f"[TIER2-C6] {len(rows)} method execution logs for run {run_id}")
    except Exception as e:
        logger.warning(f"[TIER2-C6] Error: {e}")
