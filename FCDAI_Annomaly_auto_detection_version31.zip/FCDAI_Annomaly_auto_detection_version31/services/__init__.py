"""
AIM AI Vault V14 — Services Package
=====================================
Service layer abstraction decoupling pages from direct DB/vault access.
"""
