"""
AIM AI Vault V17 — Data Service Layer
=======================================
Abstraction layer for data vault and database operations.
Pages should call DataService instead of directly accessing DataVault
or SQLAlchemy sessions.

V17 E5: All data getters apply mask_for_memory() PII gate before returning.

Responsibilities:
  - Manage DataVault lifecycle
  - Validate data contracts on import/export
  - Enforce PII masking policies (V17: wired into all getters)
  - Provide safe data access with error handling
  - Support incremental backup automation

Author: AIM AI Vault Team
"""

import sys
import gc
import shutil
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple

import pandas as pd

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import PATHS, APP, PII, AUDIT
from utils.error_codes import ErrorCode
from utils.contracts import DataImportContract

_svc_logger = logging.getLogger("apurbadas.data_service")


class DataService:
    """
    Service façade for data vault and database operations.

    Usage:
        from services.data_service import DataService
        ds = DataService()
        ds.import_source("transactions", df)
        current_df = ds.get_current_data()
    """

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        from utils.data_io import DataVault
        self._vault = DataVault()

    @property
    def vault(self):
        """Access underlying DataVault (backward compatibility)."""
        return self._vault

    def import_source(
        self,
        source_name: str,
        df: pd.DataFrame,
        file_name: str = "",
        user: str = "system",
    ) -> Dict[str, Any]:
        """
        Import a source table with validation and audit logging.

        Returns: {"success": bool, "rows": int, "columns": int, "error": str|None}
        """
        try:
            # Validate contract
            contract = DataImportContract(
                source_name=source_name,
                file_name=file_name or f"{source_name}.upload",
                file_size_bytes=df.memory_usage(deep=True).sum(),
                row_count=len(df),
                column_count=len(df.columns),
            )
            contract.validate()

            # Store in vault
            self._vault.save_sources({source_name: df})

            # Audit
            self._audit("DATA_IMPORT", user, {
                "source": source_name,
                "rows": len(df),
                "columns": len(df.columns),
                "file": file_name,
            })

            _svc_logger.info(f"[DATA] Imported {source_name}: {len(df)} rows × {len(df.columns)} cols")
            return {
                "success": True,
                "rows": len(df),
                "columns": len(df.columns),
                "error": None,
            }

        except Exception as exc:
            safe_error = f"{type(exc).__name__}: import failed"
            _svc_logger.error(f"[DATA] Import error: {exc}")
            return {"success": False, "rows": 0, "columns": 0, "error": safe_error}

    def get_current_data(self) -> Optional[pd.DataFrame]:
        """Get the current analytical view from vault.
        V17 E5: PII gate — applies mask_for_memory() before returning."""
        try:
            df = self._vault.get_data()
            if df is not None:
                from utils.pii_masking import mask_for_memory
                df = mask_for_memory(df)
            return df
        except Exception as exc:
            _svc_logger.warning(f"[DATA] get_current_data failed: {type(exc).__name__}")
            return None

    def get_scored_data(self) -> Optional[pd.DataFrame]:
        """Get the most recent scored data from vault.
        V17 E5: PII gate — applies mask_for_memory() before returning."""
        try:
            df = self._vault.get_scored_data()
            if df is not None:
                from utils.pii_masking import mask_for_memory
                df = mask_for_memory(df)
            return df
        except Exception as exc:
            _svc_logger.warning(f"[DATA] get_scored_data failed: {type(exc).__name__}")
            return None

    def get_source_names(self) -> List[str]:
        """List available source table names."""
        try:
            return list(self._vault.load_sources().keys())
        except Exception:
            return []

    def get_source(self, name: str) -> Optional[pd.DataFrame]:
        """Get a specific source table.
        V17 E5: PII gate — applies mask_for_memory() before returning."""
        try:
            sources = self._vault.load_sources()
            df = sources.get(name)
            if df is not None:
                from utils.pii_masking import mask_for_memory
                df = mask_for_memory(df)
            return df
        except Exception:
            return None

    def reload_vault(self):
        """Force reload all vault data from disk."""
        try:
            self._vault.reload_from_disk()
            _svc_logger.info("[DATA] Vault reloaded from disk")
        except Exception as exc:
            _svc_logger.warning(f"[DATA] Vault reload failed: {type(exc).__name__}")

    def create_backup(self, user: str = "system") -> Dict[str, Any]:
        """
        Create an incremental backup of the database and vault.

        Strategy:
        1. WAL checkpoint (flush pending writes)
        2. Copy DB file
        3. Copy vault metadata
        """
        try:
            backup_dir = PATHS.DATA / "backups"
            backup_dir.mkdir(parents=True, exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = f"backup_{ts}"
            target = backup_dir / backup_name
            target.mkdir(exist_ok=True)

            # 1. WAL checkpoint
            try:
                from database.engine import get_engine
                from sqlalchemy import text
                with get_engine().connect() as conn:
                    conn.execute(text("PRAGMA wal_checkpoint(TRUNCATE)"))
                    conn.commit()
            except Exception:
                pass

            # 2. Copy database
            db_path = PATHS.DATA / "sentinel_vault.db"
            if db_path.exists():
                shutil.copy2(db_path, target / "sentinel_vault.db")

            # 3. Copy vault metadata
            meta_path = PATHS.DATA_VAULT / "metadata.json"
            if meta_path.exists():
                shutil.copy2(meta_path, target / "metadata.json")

            # 4. Record backup in DB
            try:
                from database.engine import write_session
                from database.models import DbBackup
                with write_session() as session:
                    session.add(DbBackup(
                        backup_path=str(target),
                        size_mb=round(sum(
                            f.stat().st_size for f in target.rglob("*") if f.is_file()
                        ) / (1024 * 1024), 2),
                        created_by=user,
                        status="SUCCESS",
                    ))
            except Exception:
                pass

            self._audit("BACKUP_CREATED", user, {"path": str(target)})
            _svc_logger.info(f"[DATA] Backup created: {target}")
            return {"success": True, "path": str(target), "error": None}

        except Exception as exc:
            safe_error = f"{type(exc).__name__}: backup failed"
            _svc_logger.error(f"[DATA] Backup error: {exc}")
            return {"success": False, "path": "", "error": safe_error}

    def cleanup_memory(self):
        """Release unused memory (call after large operations)."""
        gc.collect()
        _svc_logger.info("[DATA] Memory cleanup completed")

    def _audit(self, action: str, user: str, metadata: Dict):
        """Log to audit trail."""
        try:
            from utils.logger import logger
            logger.log_action(action, user=user, metadata=metadata)
        except Exception:
            pass
