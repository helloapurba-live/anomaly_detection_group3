"""
Pipeline Runner — AIM AI Vault V14
=====================
Standalone entry point for running the pipeline in a subprocess.
Fixes: PATHS import bug, proper error handling.
"""

import sys
import os
import gc
import pandas as pd
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from config import PATHS
from pipeline import ApurbaDasPipeline
from utils.data_io import data_vault
from utils.logger import logger


def main():
    try:
        # Write PID for Stop functionality
        pid = os.getpid()
        pid_file = PATHS.DATA_VAULT / "pipeline.pid"
        pid_file.parent.mkdir(parents=True, exist_ok=True)
        with open(pid_file, "w") as f:
            f.write(str(pid))
            
        logger.info(f"Pipeline Runner Started (PID: {pid})")
        
        # 1. Load Data
        df = data_vault.get_data()
        if df is None or df.empty:
            logger.error("No data found in vault to process")
            return
            
        logger.info(f"Loaded {len(df)} records from vault")
        
        # 2. Initialize Pipeline
        pipeline = ApurbaDasPipeline()
        
        # 3. Run Pipeline
        result = pipeline.run_single_source(df, source_name="transactions")
        
        if result.success:
            logger.info(f"Pipeline completed: {result.records_processed} records, "
                        f"{result.alerts_generated} alerts, "
                        f"{result.execution_time_ms:.0f}ms")
            pipeline.save_results()
            data_vault.set_scored_data(result.df_scored)
        else:
            logger.error(f"Pipeline failed: {result.error}")

    except Exception as e:
        logger.log_error(e, "Pipeline Runner")
    finally:
        # V15: Force GC before process exit
        gc.collect()
        # Clean up PID file
        try:
            pid_file = PATHS.DATA_VAULT / "pipeline.pid"
            if pid_file.exists():
                pid_file.unlink()
        except Exception:
            pass


if __name__ == "__main__":
    main()
