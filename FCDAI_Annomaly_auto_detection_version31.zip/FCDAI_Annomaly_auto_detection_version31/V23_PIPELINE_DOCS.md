# FCDAI V23 — 5-Module Pipeline Documentation

> **Version**: 23.0.0 | **Port**: 8099 | **Base**: Forked from V20 (unchanged)

---

## 1. Architecture Overview

```
Raw Upload ──► Module 1: DQ Validation (6-step gate, ≥95%)
                     │
                     ▼
              Module 2: DQ Processing (12 sequential steps)
                     │
                     ▼
              Module 3: Preprocessing (Missing → Transform → Encode)
                     │  outputs ──► EncodedMaster (100% numeric, zero NaN)
                     ▼
              Module 4: 6-Way Scaling (parallel)
                     │  outputs ──► 6 scaled matrices
                     ▼
              Module 5: 8-Path Dimension Reduction
                     │  outputs ──► PreMaster (reduced feature set)
                     ▼
              Algorithm Routing Matrix (20 algorithms)
```

---

## 2. Files Created / Modified

### New Engine Files (utils/)

| File | Module | Lines | Purpose |
|------|--------|-------|---------|
| `utils/dq_validation.py` | 1 | ~300 | 6-step DQ gate with weighted scoring |
| `utils/dq_processing.py` | 2 | ~320 | 12-step sequential data cleaning |
| `utils/preprocessing_engine.py` | 3 | ~290 | Missing values → feature encoding → EncodedMaster |
| `utils/scaling_engine.py` | 4 | ~190 | 6 parallel scalers |
| `utils/reduction_engine.py` | 5 | ~380 | 8 dimension reduction paths → PreMaster |
| `utils/algorithm_routing.py` | — | ~320 | 20-algorithm routing matrix |

### Modified Files

| File | Changes |
|------|---------|
| `config.py` | V23 version/port, `DQPipelineConfig` dataclass with all module settings |
| `pages/layer_view.py` | 6 new pipeline tabs (DQ Scorecard, DQ Processing, EncodedMaster, Scaling, Reduction, Routing) + original L1–L7 |
| `pages/pipeline_run.py` | New dropdowns: Reduction Path (8 options) + Missing Strategy (4 options) |
| `requirements.txt` | Added `prince`, `umap-learn`, `tensorflow` |

---

## 3. Module Details

### Module 1 — DQ Validation (`dq_validation.py`)

**Class**: `DQValidationEngine` → returns `DQValidationResult`

6 sequential steps:
1. **Schema Check** — dtype validation, BASE_KEY existence
2. **Completeness** — per-column null % (WARNING 5–20%, CRITICAL >20%)
3. **Validity** — range checks, date format validation
4. **Referential Integrity** — FK orphan detection across slots
5. **Uniqueness** — PK duplicates, full-row duplicates
6. **Composite Score** — weighted average:
   - Completeness 25%, Validity 25%, Consistency 20%, Timeliness 15%, Uniqueness 15%
   - **Pass threshold**: ≥ 0.95 (configurable)
   - **Override**: Allowed with warning (user-selected)

### Module 2 — DQ Processing (`dq_processing.py`)

**Class**: `DQProcessingEngine` → returns `DQProcessingResult`

12 sequential steps:
| Step | Name | Action |
|------|------|--------|
| 1 | Type Detect | CONTINUOUS / BINARY / DISCRETE / CATEGORICAL / HIGH_CARDINAL_TEXT / DATETIME |
| 2 | Config Exclude | Remove columns listed in `EXCLUDE_COLUMNS` |
| 3 | PII Remove | Strip columns matching PII patterns (SSN, email, phone, etc.) |
| 4 | Datetime Extract | Move datetime columns to `SPECIAL_OBSERVATIONS` |
| 5 | ID Exclude | Remove `*_id`, `*_key` columns (preserve BASE_KEY) |
| 6 | Constants | Drop zero-variance columns (σ = 0) |
| 7 | Type Validate | Cross-validate inferred types vs `FEATURE_STORE` |
| 8 | Error Highlight | Flag negative amounts, 10σ outliers |
| 9 | Rename | Apply `FEATURE_MAP` renaming rules |
| 10 | High Null | Drop columns with >95% null |
| 11 | High Cardinality | Flag categorical columns with >20 unique values |
| 12 | Summary | Final shape, step log, column metadata |

### Module 3 — Preprocessing (`preprocessing_engine.py`)

**Class**: `PreprocessingEngine` → returns `PreprocessingResult`

4 sub-steps:
1. **Missing Values** — Strategy: ZERO (default) / MEDIAN / MODE / DROP
2. **Datetime Decompose** — Extract: hour, dayofweek, month, is_weekend, quarter, days_since_epoch
3. **Feature Encoding**:
   - Continuous → float64 (passthrough)
   - Discrete → int32
   - Binary → 0/1 int8
   - Ordinal → LabelEncoder int32
   - Categorical → pd.get_dummies (drop_first)
   - High Cardinal → Frequency encoding
4. **Final Audit** — Verify 100% numeric, zero NaN → **EncodedMaster**

### Module 4 — 6-Way Scaling (`scaling_engine.py`)

**Class**: `ScalingEngine` → returns `ScalingResult`

| # | Scaler | sklearn Class | Notes |
|---|--------|--------------|-------|
| 1 | Standard | StandardScaler | z-score (μ=0, σ=1) |
| 2 | MinMax | MinMaxScaler | [0, 1] range |
| 3 | Robust | RobustScaler | IQR-based, outlier-resistant |
| 4 | MaxAbs | MaxAbsScaler | [-1, 1], preserves sparsity |
| 5 | Power | PowerTransformer | Yeo-Johnson, Gaussian-like |
| 6 | Original | — | No scaling (passthrough) |

All 6 run in parallel on the **EncodedMaster**. Each produces a `np.ndarray`. Scaler objects are pickle-serializable for production deployment.

### Module 5 — 8-Path Dimension Reduction (`reduction_engine.py`)

**Class**: `ReductionEngine` → returns `ReductionResult`

| Path | Name | Library | Default Dims | Notes |
|------|------|---------|-------------|-------|
| 1 | None | — | — | Passthrough (full feature set) |
| 2 | Mixed PCA | sklearn | 95% variance | PCA on continuous, keep binary/cat |
| 3 | FAMD | prince | 50 | Factor Analysis of Mixed Data |
| 4 | UMAP Mixed | umap-learn | 30 | UMAP on continuous, keep binary/cat |
| 5 | UMAP Full | umap-learn | 30 | UMAP on all features |
| 6 | SDAE | tensorflow | 50 | Stacked Denoising Autoencoder |
| 7 | Agent Quick | heuristic | auto | R×V rule: K<30→None, RV<50K→PCA, K<500→UMAP, else→PCA |
| 8 | Agent Think | data-aware | auto | cat_ratio>30%→FAMD, K>200+N>5K→UMAP, K>200→SDAE, else→PCA |

**Default**: Path 7 (Agent Quick). Output → **PreMaster**.

All optional libraries have graceful fallbacks to Mixed PCA if import fails.

---

## 4. Algorithm Routing Matrix (20 Algorithms)

| # | Algorithm | Category | Scaler | Default Reduction | Never Scale | Never Reduce |
|---|-----------|----------|--------|-------------------|-------------|--------------|
| 1 | IQR | Statistical | Robust | 1 (None) | ✗ | ✗ |
| 2 | Modified Z-Score | Statistical | Robust | 1 (None) | ✗ | ✗ |
| 3 | Mahalanobis | Statistical | Power | 2 (Mixed PCA) | ✗ | ✗ |
| 4 | Benford's Law | Statistical | Original | 1 (None) | ✓ | ✓ |
| 5 | Extended IF | Proximity | Original | 1 (None) | ✗ | ✗ |
| 6 | HBOS | Proximity | Standard | 1 (None) | ✗ | ✗ |
| 7 | LOF | Proximity | Standard | 2 (Mixed PCA) | ✗ | ✗ |
| 8 | ECOD | Proximity | Original | 1 (None) | ✗ | ✗ |
| 9 | COPOD | Proximity | Original | 1 (None) | ✗ | ✗ |
| 10 | k-th NN | Proximity | Standard | 2 (Mixed PCA) | ✗ | ✗ |
| 11 | GMM | Clustering | Power | 2 (Mixed PCA) | ✗ | ✗ |
| 12 | HDBSCAN | Clustering | Standard | 4 (UMAP Mixed) | ✗ | ✗ |
| 13 | BIRCH | Clustering | Standard | 2 (Mixed PCA) | ✗ | ✗ |
| 14 | PageRank | Graph | — | — | ✓ | ✓ |
| 15 | Leiden | Graph | — | — | ✓ | ✓ |
| 16 | OddBall | Graph | — | — | ✓ | ✓ |
| 17 | Betweenness | Graph | — | — | ✓ | ✓ |
| 18 | Change Point | Temporal | — | — | ✓ | ✓ |
| 19 | Matrix Profile | Temporal | — | — | ✓ | ✓ |
| 20 | VAE | Deep Learning | MinMax | 1 (None) | ✗ | ✗ |

**Graph algorithms** (14–17) use `GRAPH_DATA` — no scaling or reduction.  
**Temporal algorithms** (18–19) use `TEMPORAL_DATA` — no scaling or reduction.

---

## 5. UI Changes

### Layer View Page (`pages/layer_view.py`)

Two tab groups separated by a divider:

**Pipeline Modules** (new):
- **DQ Scorecard** — Ring gauges for each DQ dimension, step log table
- **DQ Processing** — Shape before/after KPIs, 12-step log, summary grid
- **EncodedMaster** — Encoding pie chart, missing treatment summary, detail grid
- **6-Way Scaling** — 6 scaler cards with shapes, algo assignments, status badges
- **Reduction** — Path/dims KPIs, progress bar, agent reasoning panel, path reference table
- **Algo Routing** — Category bar chart, scaler pie chart, full 20-row routing matrix grid

**Original 7-Layer View** (preserved):
- L1-2 Ingest, L3 DQ, L4 Preprocessing, L5 Feature, L6 Algorithm, L7 Rollup

### Pipeline Run Page (`pages/pipeline_run.py`)

New execution settings:
- **Reduction Path** dropdown — 8 paths, default = Agent Quick (path 7)
- **Missing Strategy** dropdown — ZERO / MEDIAN / MODE / DROP, default = ZERO

---

## 6. Configuration (`config.py`)

New `DQPipelineConfig` dataclass added:

```python
DQ_PASS_THRESHOLD = 0.95          # Minimum DQ score to pass gate
DQ_ALLOW_OVERRIDE = True          # Allow override with warning
DQ_WEIGHTS = {completeness: 0.25, validity: 0.25, consistency: 0.20, 
              timeliness: 0.15, uniqueness: 0.15}
PII_PATTERNS = ["*ssn*", "*social*sec*", "*tax*id*", ...]
SCALER_TYPES = [Standard, MinMax, Robust, MaxAbs, Power, Original]
REDUCTION_PATHS = [None, Mixed PCA, FAMD, UMAP Mixed, UMAP Full, 
                   SDAE, Agent Quick, Agent Think]
FAMD_DEFAULT_DIMS = 50
UMAP_DEFAULT_DIMS = 30
SDAE_DEFAULT_DIMS = 50
PCA_VARIANCE_RATIO = 0.95
```

---

## 7. New Dependencies

| Package | Version | License | Purpose |
|---------|---------|---------|---------|
| `prince` | ≥0.13.0 | MIT | FAMD (Module 5, path 3) |
| `umap-learn` | ≥0.5.5 | BSD-3 | UMAP (Module 5, paths 4–5) |
| `tensorflow` | ≥2.15.0 | Apache-2.0 | SDAE autoencoder (Module 5, path 6) |

All three have fallback handling — if import fails, reduction falls back to Mixed PCA.

---

## 8. How to Run

```bash
# Activate environment
conda activate ai311

# Install new dependencies
pip install prince umap-learn tensorflow

# Start V23
cd FCDAI_Annomaly_auto_detection_version23
python app.py
# → http://localhost:8099
```

---

## 9. Data Flow Summary

```
                    ┌─────────────────────┐
                    │   Raw CSV/Excel     │
                    │   (12 table slots)  │
                    └──────────┬──────────┘
                               │
                    ┌──────────▼──────────┐
                    │  Module 1: DQ Gate  │  6 checks → score ≥ 95%
                    │  (or override)      │
                    └──────────┬──────────┘
                               │
                    ┌──────────▼──────────┐
                    │  Module 2: DQ Proc  │  12 sequential cleaning steps
                    └──────────┬──────────┘
                               │
                    ┌──────────▼──────────┐
                    │  Module 3: Preproc  │  Missing → Transform → Encode
                    │                     │  Output: EncodedMaster
                    └──────────┬──────────┘   (100% numeric, 0 NaN)
                               │
                    ┌──────────▼──────────┐
                    │  Module 4: Scaling  │  6 scalers in parallel
                    │                     │  Output: 6 scaled matrices
                    └──────────┬──────────┘
                               │
                    ┌──────────▼──────────┐
                    │  Module 5: Reduce   │  1 of 8 paths selected
                    │                     │  Output: PreMaster
                    └──────────┬──────────┘
                               │
                ┌──────────────▼──────────────┐
                │  Algorithm Routing Matrix   │
                │  20 algorithms × 8 categories│
                │  Each mapped to scaler +    │
                │  reduction path             │
                └─────────────────────────────┘
```

---

*Generated for FCDAI V23 — 5-Module Pipeline with 20-Algorithm Routing Matrix*
