# ROBUST DETECTION EXECUTION - IMPLEMENTATION GUIDE

**Version 7 Enhancement: Adaptive Method Selection & Execution**

---

## 📋 OVERVIEW

Version 7 implements **intelligent method execution** that adapts to available data structures. Methods are conditionally enabled/disabled based on:

- **Data Volume**: Sample count, feature count
- **Data Structures**: Temporal data, graph networks
- **Method Requirements**: Minimum thresholds per category

**Core Benefit**: Never fail due to missing data — gracefully degrade with comprehensive logging.

---

## 🏗️ ARCHITECTURE COMPONENTS

### 1. Method Execution Engine (`l5_detection.py`)
- **MethodExecutionEngine**: Validates requirements and tracks execution
- **MethodConfig**: Specification for each method's requirements
- **METHOD_SPECS**: 26 method specifications with weights and constraints

### 2. Auto-Parameter Generator (`utils/auto_params.py`)
- **AutoParamGenerator**: Data-adaptive parameter generation
- **get_auto_params()**: Single-method parameter retrieval
- Adapts to `n_samples`, `n_features`, and data distribution

### 3. Enhanced Layer 5 (`l5_detection.py`)
- **detect_all_robust()**: New execution method with conditional logic
- **detect_all()**: Legacy execution (backward compatible)
- Supports multiple input data types (X_RAW, X_STANDARD, X_MINMAX, TIME_SERIES, GRAPH)

### 4. Enhanced Layer 6 (`l6_ensemble.py`)
- **fuse_robust()**: Fusion method for robust execution output
- **fuse()**: Standard fusion (backward compatible)
- Auto-extracts method weights from specifications

---

## 🚀 USAGE EXAMPLES

### Scenario 1: Minimal MASTER Only

**Data Available**: MASTER with 5 features, 100 customers

```python
import numpy as np
from layers.l1_l2_ingestion import Layer1DataIngestion, Layer2DataLoading
from layers.l3_feature_engineering import Layer3FeatureEngineering
from layers.l4_preprocessing import Layer4Preprocessing
from layers.l5_detection import Layer5Detection
from layers.l6_ensemble import Layer6Ensemble

# STEP 1-4: Load and preprocess data
l1 = Layer1DataIngestion()
l1.upload_master("data/MASTER.csv")
l1.detect_schema()

l2 = Layer2DataLoading()
l2.load_uploaded_data(l1)

l3 = Layer3FeatureEngineering()
df_features = l3.engineer_features(l2.master_df, l2.schema)

l4 = Layer4Preprocessing()
data_structures = l4.preprocess(
    df_features,
    id_columns=['cust_id'],
    pca_components=None,
    create_time_series=False,
    create_graph=False
)

# STEP 5: Robust detection execution
l5 = Layer5Detection(contamination=0.05)
execution_output = l5.detect_all_robust(
    data_structures=data_structures,
    customer_ids=l4.customer_ids,
    feature_names=l4.feature_names,
    enabled_methods=None,  # Auto-enable all compatible methods
    threshold=0.5
)

# STEP 6: Ensemble fusion
l6 = Layer6Ensemble(method="tiered_consensus")
ensemble_result = l6.fuse_robust(execution_output, threshold=0.5)

# VIEW RESULTS
print(f"Executed: {len(execution_output['executed_methods'])} methods")
print(f"Skipped: {len(execution_output['skipped_methods'])} methods")
print(f"Total Weight: {execution_output['summary']['total_weight']}")
print(f"\nRisk Tiers: {ensemble_result.tier_counts}")
```

**Expected Output**:
```
Executed: 17 methods
  Statistical: 5/5
  Distance: 3/3
  Density: 4/4
  Clustering: 3/3
  Trees: 2/2
Skipped: 9 methods
  Deep Learning (2): Insufficient features (have 5, need 10)
  Time-Series (3): No temporal data
  Graph (4): No graph data
Total Weight: 18.5

Risk Tiers: {'CRITICAL': 2, 'HIGH': 5, 'MEDIUM': 8, 'LOW': 12, 'NORMAL': 73}
```

---

### Scenario 2: MASTER + TRANSACTIONS (Temporal)

**Data Available**: MASTER with 10 features + TRANSACTIONS (time-indexed), 200 customers

```python
# STEP 1-3: Same as above

# STEP 4: Preprocessing with temporal data
l4 = Layer4Preprocessing()
data_structures = l4.preprocess(
    df_features,
    id_columns=['cust_id'],
    pca_components=None,
    create_time_series=True,  # Enable temporal
    create_graph=False
)

# STEP 5-6: Same as above
```

**Expected Output**:
```
Executed: 22 methods
  Statistical: 5/5
  Distance: 3/3
  Density: 4/4
  Clustering: 3/3
  Trees: 2/2
  Deep Learning: 2/2 (features >= 10, samples >= 100)
  Time-Series: 3/3 (temporal data available)
Skipped: 4 methods
  Graph (4): No graph data
Total Weight: 21.5
```

---

### Scenario 3: Full Dataset (MASTER + TRANSACTIONS + RELATIONSHIPS)

**Data Available**: MASTER (10 features) + TRANSACTIONS (temporal) + RELATIONSHIPS (graph), 200 customers

```python
# STEP 4: Preprocessing with all data structures
l4 = Layer4Preprocessing()
data_structures = l4.preprocess(
    df_features,
    id_columns=['cust_id'],
    pca_components=None,
    create_time_series=True,   # Enable temporal
    create_graph=True         # Enable graph
)

# STEP 5-6: Same as above
```

**Expected Output**:
```
Executed: 26 methods (ALL METHODS)
  Statistical: 5/5
  Distance: 3/3
  Density: 4/4
  Clustering: 3/3
  Trees: 2/2
  Deep Learning: 2/2
  Time-Series: 3/3
  Graph: 4/4
Skipped: 0 methods
Total Weight: 25.5
```

---

## 🔍 EXECUTION LOG ANALYSIS

Access detailed execution log:

```python
# View full execution log
for log_entry in execution_output['execution_log']:
    print(log_entry)

# View skipped methods with reasons
for skip_info in execution_output['skipped_methods']:
    print(f"{skip_info['method']} ({skip_info['category']}): {skip_info['reason']}")

# View executed methods with anomaly counts
for method_name in execution_output['executed_methods']:
    result = execution_output['results'][method_name]
    anomaly_count = result.labels.sum()
    print(f"{method_name}: {anomaly_count} anomalies")
```

**Example Log Output**:
```
[L5 Exec] Data: 100 samples, 5 features
[L5 Exec] Temporal data: NO
[L5 Exec] Graph data: NO
[L5 Exec] Total methods: 26
[L5 Exec] EXEC zscore: 3/100 anomalies (3.0%)
[L5 Exec] EXEC iqr: 5/100 anomalies (5.0%)
[L5 Exec] EXEC grubbs: 2/100 anomalies (2.0%)
[L5 Exec] EXEC dixon: 3/100 anomalies (3.0%)
[L5 Exec] EXEC esd: 4/100 anomalies (4.0%)
[L5 Exec] EXEC knn: 6/100 anomalies (6.0%)
[L5 Exec] EXEC mahalanobis: 5/100 anomalies (5.0%)
[L5 Exec] EXEC lof: 7/100 anomalies (7.0%)
[L5 Exec] EXEC isolation_forest: 10/100 anomalies (10.0%)
[L5 Exec] EXEC extended_if: 9/100 anomalies (9.0%)
[L5 Exec] SKIP autoencoder: Need 10 features, have 5
[L5 Exec] SKIP vae: Need 10 features, have 5
[L5 Exec] SKIP stl: No temporal data available
[L5 Exec] SKIP arima_residual: No temporal data available
[L5 Exec] SKIP prophet: No temporal data available
[L5 Exec] SKIP pagerank: No graph data available
[L5 Exec] SKIP hits: No graph data available
[L5 Exec] SKIP community: No graph data available
[L5 Exec] SKIP centrality: No graph data available
```

---

## 📊 METHOD WEIGHTS & ENSEMBLE

**Weight Distribution** (automatically applied):

| Category        | Methods                  | Weight |
|-----------------|--------------------------|--------|
| Tree-Based      | Isolation Forest, Ext IF | 1.5    |
| Distance        | LOF                      | 1.2    |
| All Others      | 23 methods               | 1.0    |

**Ensemble Formula**:
```
final_score[i] = Σ(weight[m] × normalized_score[m][i]) / Σ(weight[m])
                 for m in EXECUTED_METHODS
```

**Example**: If only 17 methods execute (skip deep learning, time-series, graph):
- Total weight = (5×1.0) + (3×1.0) + (4×1.0) + (3×1.0) + (2×1.5) = 18.5
- Tree methods contribute: (1.5 / 18.5) = 8.1% per method
- Other methods contribute: (1.0 / 18.5) = 5.4% per method

---

## 🛡️ ERROR HANDLING

### Graceful Degradation
- Individual method failures don't crash pipeline
- Execution continues with remaining methods
- Failed methods logged with error details

### Automatic Recovery
```python
# If a method fails
[L5 Exec] FAIL dbscan: ValueError: eps must be positive

# Execution continues
[L5 Exec] EXEC optics: 8/100 anomalies (8.0%)
[L5 Exec] EXEC hdbscan: 9/100 anomalies (9.0%)
```

### Validation Checks
- Minimum 2 samples required
- Minimum 1 feature required
- Empty data structures handled gracefully

---

## 🔧 CUSTOM CONFIGURATION

### Enable Specific Methods Only

```python
execution_output = l5.detect_all_robust(
    data_structures=data_structures,
    customer_ids=l4.customer_ids,
    feature_names=l4.feature_names,
    enabled_methods=["isolation_forest", "lof", "zscore"],  # Only these 3
    threshold=0.5
)
```

### Custom Parameters

```python
from utils.auto_params import AutoParamGenerator, get_auto_params

# Get auto-generated parameters
n_samples = len(l4.customer_ids)
n_features = len(l4.feature_names)
all_params = AutoParamGenerator.generate_all(n_samples, n_features)

# Customize specific method
all_params["isolation_forest"]["contamination"] = 0.15  # Increase contamination

# Apply during method execution (requires manual execution)
```

---

## 📈 PERFORMANCE OPTIMIZATION

### CPU-Only Deep Learning
- Uses `tensorflow-cpu` or `pytorch-cpu`
- No GPU required
- Suitable for standard servers

### Parallel Execution
- SKLearn methods use `n_jobs=-1`
- LOF, IsolationForest, KNN parallelized
- Scales to multi-core systems

### Memory Management
- float32 downcast (50% memory reduction)
- k-NN graph caching for graph methods
- MiniBatch variants for large datasets

---

## 🎯 INTEGRATION CHECKLIST

- [ ] Update UI to display executed vs skipped methods
- [ ] Add execution log viewer in dashboard
- [ ] Show method weights in results table
- [ ] Display skip reasons for user clarity
- [ ] Add toggle to enable/disable method categories

---

## 🔗 RELATED FILES

- **Specification**: `DETECTION_METHODS_SPECIFICATION.md`
- **Auto-Params**: `utils/auto_params.py`
- **Layer 5**: `layers/l5_detection.py`
- **Layer 6**: `layers/l6_ensemble.py`
- **Method Config**: `utils/method_config_generator.py`

---

**Last Updated**: February 12, 2026  
**Version**: 7.0.0  
**Status**: Implementation Complete ✅
