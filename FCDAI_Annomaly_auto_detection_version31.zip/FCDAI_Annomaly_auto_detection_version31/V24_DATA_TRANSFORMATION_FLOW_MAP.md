# V24 COMPREHENSIVE DATA TRANSFORMATION FLOW MAP

> **Generated from**: FCDAI_Annomaly_auto_detection_version24  
> **Scope**: Every data artifact (DataFrame, matrix, dict, file) traced step-by-step through the entire system  
> **Files analysed**: pipeline.py, all utils/, all layers/, all pages/, data_io.py

---

## A. PIPELINE DATA FLOW — Step-by-Step Variable Trace

### Overview: Execution Order

```
pipeline_run.py → ApurbaDasPipeline.run()
  ├── Step L1-2: Ingest + DQ       → df, dq_report
  ├── Step M1:   DQ Validation      → dq_val_result, dq_validation_dict
  ├── Step V6:   Customer Aggregation (optional)
  ├── Step L3:   Feature Engineering → df (extended with ~50+ cols)
  ├── Step V8:   Schema Detection   → schema_profiles, usable_cols
  ├── Step M2:   DQ Processing      → m2_result → df_cleaned, dq_processing_dict
  ├── Step M3:   Preprocessing      → m3_result → encoded_master, preprocessing_dict
  ├── Step M4:   Scaling            → m4_result → scaled_matrices{6}, scaling_dict
  ├── Step M5:   Reduction          → m5_result → X (PreMaster), reduction_dict
  ├── [Fallback L4 if V24 fails]   → matrices dict → X
  ├── Step V8b:  Auto Params        → auto_params
  ├── Step L5:   Detection          → self.detection.results, score_matrix, method_names
  ├── Step L6:   Ensemble Fusion    → ensemble_result (EnsembleResult)
  ├── Step L7:   Output             → output_summary, alerts, narratives, audit
  └── Persist:   save_results()     → scored.parquet, pipeline_result.json, SQLite
```

---

### Step L1-2: Ingest + Data Quality

| Aspect | Detail |
|--------|--------|
| **Entry point** | `pipeline_run.py → run_pipeline()` → `ApurbaDasPipeline.run(sources, ..., merged_df)` |
| **Input** | `sources: Dict[str, DataFrame]` — 12 table slots (BASE + 11 optional) |
| **Merge logic** | If `merged_df` provided → use directly. Else `IngestPipeline.run(sources)` |
| **Merge strategy** | BASE table + left-join other tables on resolved primary key |
| **Output variable** | `df` — merged DataFrame (N rows × K columns) |
| **Output variable** | `dq_report` — `DataQualityReport` dataclass |
| **DataQualityReport fields** | `completeness` (float), `consistency` (float), `validity` (float), `overall_score` (float), `issues` (List), `timestamp` (str) |
| **Persistence** | `vault/sources/<table>.parquet` for each source table |
| **Persistence** | `vault/current.parquet` — merged analytical view |

**Data shape**: `df` starts as N×K where N = merged rows, K = sum of all table columns after join.

---

### Step M1: DQ Validation (Module 1)

| Aspect | Detail |
|--------|--------|
| **Call** | `self.dq_validator.validate(df)` |
| **Engine** | `utils/dq_validation.py → DQValidationEngine` |
| **Input** | `df` (merged DataFrame) |
| **6-Step process** | Schema → Completeness → Validity → Referential Integrity → Uniqueness → DQ Score |
| **Output variable** | `dq_val_result: DQValidationResult` |
| **Serialised to** | `dq_validation_dict` via `scorecard_to_dict()` |

**`DQValidationResult` fields**:

| Field | Type | Description |
|-------|------|-------------|
| `dq_score` | `float` | Overall score 0–1 |
| `passed` | `bool` | True if score ≥ threshold |
| `override_allowed` | `bool` | Allow manual override |
| `completeness_score` | `float` | Column completeness 0–1 |
| `validity_score` | `float` | Type/range validity 0–1 |
| `consistency_score` | `float` | Cross-table consistency 0–1 |
| `timeliness_score` | `float` | Recency measure 0–1 |
| `uniqueness_score` | `float` | Duplicate detection 0–1 |
| `schema_report` | `DataFrame` | Per-column schema audit |
| `completeness_matrix` | `DataFrame` | Per-column null rates |
| `invalid_records` | `DataFrame` | Failed validity rules |
| `orphan_records` | `DataFrame` | Broken ref. integrity |
| `duplicate_log` | `DataFrame` | Duplicate detection log |
| `total_rows` | `int` | Input row count |
| `total_cols` | `int` | Input column count |
| `step_log` | `List[Dict]` | 6-step execution log |
| `timestamp` | `str` | ISO timestamp |

**`dq_validation_dict` keys** (serialised for JSON): `dq_score`, `passed`, `dimensions` (nested dict with completeness/validity/consistency/timeliness/uniqueness scores), `step_log`, `total_rows`, `total_cols`.

---

### Step V6: Customer Aggregation (Conditional)

| Aspect | Detail |
|--------|--------|
| **Condition** | `APP.CUSTOMER_LEVEL_PROCESSING == True` |
| **Call** | `CustomerAggregator.aggregate(df)` |
| **Effect** | Aggregates transaction-level rows → customer-level rows |
| **Input** | `df` (N×K) |
| **Output** | `df` (N'×K) where N' = unique customers |

---

### Step L3: Feature Engineering

| Aspect | Detail |
|--------|--------|
| **Call** | `self.features.engineer_features(df, customer_col, amount_col, timestamp_col)` |
| **Engine** | `layers/l3_feature_engineering.py → Layer3FeatureEngineering` |
| **Input** | `df` (N×K) |
| **Output** | `df` (N×K', K' > K) — same rows, additional feature columns |

**Feature columns created** (stored in `self.feature_columns`):

| Category | Prefix | Columns |
|----------|--------|---------|
| Velocity | `vel_` | `vel_txn_count`, `vel_cumsum`, `vel_amount_sum`, `vel_amount_mean`, `vel_amount_std` |
| Aggregate | `agg_` | `agg_amount_max`, `agg_amount_min`, `agg_amount_range`, `agg_amount_prank`, `agg_amount_quartile` |
| Ratio | `ratio_` | `ratio_to_mean`, `ratio_zscore`, `ratio_log_amount` |
| Flag | `flag_` | `flag_round_amount`, `flag_large_txn`, `flag_small_txn`, `flag_zero_amount` |
| Temporal | `temp_` | `temp_hour`, `temp_day_of_week`, `temp_day_of_month`, `temp_month`, `temp_quarter`, `temp_is_weekend`, `temp_is_night`, `temp_is_business` |
| Behavioral | `behav_` | `behav_cust_zscore`, `behav_unusual`, `behav_pct_of_max` |

---

### Step V8: Schema Detection

| Aspect | Detail |
|--------|--------|
| **Call** | `self.schema_detector.detect_schema(df)` |
| **Engine** | `utils/schema_detector.py → SchemaDetector` |
| **Output** | `schema_profiles`, `usable_cols` |
| **Purpose** | Identify column types for routing to M2-M5 |

---

### Step M2: DQ Processing (Module 2)

| Aspect | Detail |
|--------|--------|
| **Call** | `self.dq_processor.process(df)` |
| **Engine** | `utils/dq_processing.py → DQProcessingEngine` |
| **Input** | `df` (N×K' with features) |
| **12-Step process** | Type Detect → Config Exclude → PII Remove → Datetime Handling → ID Exclude → Drop Constants → Type Validate → Error Detect → Rename Columns → Drop High Null → Drop High Cardinality → Output Summary |
| **Output variable** | `m2_result: DQProcessingResult` |
| **Key output** | `df_cleaned = m2_result.cleaned_df` |
| **Serialised to** | `dq_processing_dict` |

**`DQProcessingResult` fields**:

| Field | Type | Description |
|-------|------|-------------|
| `cleaned_df` | `DataFrame` | Cleaned master (N×K'') |
| `datetime_cols_extracted` | `DataFrame` | SPECIAL_OBSERVATIONS |
| `data_type_map` | `Dict[str, str]` | col → type (CONTINUOUS/BINARY/DISCRETE/CATEGORICAL/DATETIME/HIGH_CARDINAL_TEXT) |
| `error_report` | `DataFrame` | Per-cell error log |
| `summary` | `DataFrame` | Per-column quality summary |
| `exclusion_log` | ― | Exclusion decisions |
| `columns_dropped` | `List[str]` | Columns removed |
| `columns_renamed` | `Dict[str, str]` | old → new name map |
| `step_log` | `List[Dict]` | 12-step execution log |
| `shape_before` | `Tuple[int, int]` | Input shape |
| `shape_after` | `Tuple[int, int]` | Output shape |
| `timestamp` | `str` | ISO timestamp |

**`dq_processing_dict` keys**: `step_log`, `columns_dropped`, `columns_renamed`, `shape_before`, `shape_after`, `summary`, `data_type_map`.

---

### Step M3: Preprocessing / Encoding (Module 3)

| Aspect | Detail |
|--------|--------|
| **Call** | `self.preprocessing_engine.preprocess(df_cleaned, m2_result.data_type_map)` |
| **Engine** | `utils/preprocessing_engine.py → PreprocessingEngine` |
| **Input** | `df_cleaned` (N×K''), `data_type_map` (Dict[str, str]) |
| **Output variable** | `m3_result: PreprocessingResult` |
| **Key output** | `encoded_master = m3_result.encoded_master` — **100% float DataFrame (N×K''')** |
| **Serialised to** | `preprocessing_dict` |

**Processing steps**:
1. Separate `BASE_KEY` column → `base_key_series`
2. Missing value treatment (strategy: `ZERO`/`MEDIAN`/`MODE`/`DROP`)
3. Datetime decomposition → `datetime_features`
4. Feature encoding by type:
   - CONTINUOUS → `float64` (no change)
   - DISCRETE → `int32`
   - BINARY → `0/1 int8`
   - Ordinal → `LabelEncoder`
   - CATEGORICAL → `OneHotEncoder(drop_first=True)`
5. Final audit

**`PreprocessingResult` fields**:

| Field | Type | Description |
|-------|------|-------------|
| `encoded_master` | `DataFrame` | N×K''' all-float matrix |
| `base_key_series` | `Series` | Customer key column |
| `datetime_features` | `DataFrame` | Extracted datetime features |
| `encoding_map` | `Dict[str, str]` | col → encoding method applied |
| `label_encoders` | `Dict[str, Dict]` | Encoder mappings |
| `onehot_columns_created` | `List[str]` | New OHE columns |
| `columns_before_encode` | `List[str]` | Pre-encoding columns |
| `columns_after_encode` | `List[str]` | Post-encoding columns |
| `missing_treatment` | `Dict[str, str]` | col → fill strategy |
| `shape_before` | `Tuple[int, int]` | Input shape |
| `shape_after` | `Tuple[int, int]` | Output shape (encoded_master) |
| `step_log` | `List[Dict]` | Step execution log |
| `timestamp` | `str` | ISO timestamp |

**`preprocessing_dict` keys**: `shape_before`, `shape_after`, `encoding_map`, `missing_treatment`, `step_log`, `columns_before`, `columns_after`.

---

### Step M4: 6-Way Scaling (Module 4)

| Aspect | Detail |
|--------|--------|
| **Call** | `self.scaling_engine.scale(encoded_master)` |
| **Engine** | `utils/scaling_engine.py → ScalingEngine` |
| **Input** | `encoded_master` (DataFrame N×K''') |
| **Output variable** | `m4_result: ScalingResult` |
| **Key output** | `m4_result.scaled_matrices` — Dict of 6 numpy arrays |
| **Serialised to** | `scaling_dict` |

**6 Scaler outputs** (each N×K''' `np.ndarray`):

| Key | Scaler | Target algorithms |
|-----|--------|-------------------|
| `"StandardScaler"` | `sklearn.StandardScaler` | LOF, kNN, HDBSCAN, BIRCH, HBOS |
| `"MinMaxScaler"` | `sklearn.MinMaxScaler` | VAE, Autoencoder |
| `"RobustScaler"` | `sklearn.RobustScaler` | IQR, Modified Z-Score |
| `"MaxAbsScaler"` | `sklearn.MaxAbsScaler` | UMAP sparse |
| `"PowerTransformer"` | `sklearn.PowerTransformer` | GMM, Mahalanobis |
| `"Original"` | No scaling (identity) | Extended IF, Benford, ECOD, COPOD |

**`ScalingResult` fields**:

| Field | Type | Description |
|-------|------|-------------|
| `scaled_matrices` | `Dict[str, np.ndarray]` | 6 keyed arrays N×K''' |
| `scaler_objects` | `Dict[str, Any]` | Fitted scaler instances |
| `feature_names` | `List[str]` | Column names of encoded_master |
| `scaler_stats` | `Dict[str, Dict]` | Per-scaler min/max/mean stats |
| `input_shape` | `Tuple[int, int]` | Shape of encoded_master |
| `step_log` | `List[Dict]` | Per-scaler execution log with status, shape, min, max |
| `timestamp` | `str` | ISO timestamp |

**`scaling_dict` keys**: `step_log`, `scaler_stats`, `input_shape`, `feature_names`.

---

### Step M5: Dimension Reduction (Module 5)

| Aspect | Detail |
|--------|--------|
| **Call** | `self.reduction_engine.reduce(X_for_reduction, feature_names, path, encoding_map)` |
| **Engine** | `utils/reduction_engine.py → ReductionEngine` |
| **Input selection** | `X_for_reduction = m4_result.scaled_matrices.get("StandardScaler")` (fallback: first available) |
| **Output variable** | `m5_result: ReductionResult` |
| **Key output** | `X = m5_result.premaster.values` — numpy array N×D (D ≤ K''') |
| **Fallback** | If reduction fails → `X = X_for_reduction` |
| **Serialised to** | `reduction_dict` |

**8 Reduction paths**:

| Path # | Name | Method |
|--------|------|--------|
| 1 | None | No reduction (pass-through) |
| 2 | Mixed PCA | PCA on continuous + keep binary/categorical |
| 3 | FAMD | Factor Analysis of Mixed Data (PCA + MCA) |
| 4 | UMAP Mixed | UMAP on continuous + keep binary/categorical |
| 5 | UMAP Full | UMAP on all features |
| 6 | SDAE | Stacked Denoising Autoencoder |
| 7 | Agent Quick | Auto-select path (speed priority) |
| 8 | Agent Think | Auto-select path (accuracy priority) |

**`ReductionResult` fields**:

| Field | Type | Description |
|-------|------|-------------|
| `premaster` | `DataFrame` | N×D reduced matrix |
| `path_used` | `int` | Selected path number |
| `path_name` | `str` | Human-readable path name |
| `dims_before` | `int` | K''' (input features) |
| `dims_after` | `int` | D (output dims) |
| `explained_variance` | `float or None` | Variance explained (PCA paths) |
| `reduction_model` | `Any` | Fitted reducer |
| `agent_selection` | `Dict or None` | Agent reasoning (paths 7/8) |
| `step_log` | `List[Dict]` | Execution log |
| `timestamp` | `str` | ISO timestamp |

**`reduction_dict` keys**: `path_used`, `path_name`, `dims_before`, `dims_after`, `explained_variance`, `agent_selection`, `step_log`.

---

### Fallback L4: Old Preprocessing (if V24 pipeline fails)

| Aspect | Detail |
|--------|--------|
| **Call** | `self.preprocess.preprocess(df, id_columns=all_id_cols)` |
| **Engine** | `layers/l4_preprocessing.py → Layer4Preprocessing` |
| **Input** | `df` (N×K' with features) |
| **Output** | `matrices: Dict` |
| **Key lookup** | `X = matrices.get('scaled', matrices.get('raw'))` |

**`matrices` dict keys**:

| Key | Type | Description |
|-----|------|-------------|
| `"X_RAW"` / `"raw"` | `np.ndarray` | Raw numeric matrix |
| `"X_STANDARD"` / `"scaled"` | `np.ndarray` | StandardScaler output |
| `"X_MINMAX"` | `np.ndarray` | MinMaxScaler output |
| `"pca"` | `np.ndarray` | PCA-reduced matrix |
| `"encoded"` | `np.ndarray` | Label-encoded matrix |
| `"TIME_SERIES"` | `np.ndarray` (optional) | Time-series features |
| `"GRAPH_NETWORK"` | `np.ndarray` (optional) | Graph features |

---

### Step V8b: Auto Parameters

| Aspect | Detail |
|--------|--------|
| **Call** | `AutoParamGenerator.generate_all(n_samples, n_features)` |
| **Input** | `n_samples, n_features = X.shape` |
| **Output** | `auto_params: Dict` — per-method optimal hyperparameters |

---

### Step L5: Detection (26 Methods)

| Aspect | Detail |
|--------|--------|
| **Call** | `self.detection.detect_all(X, methods=active_methods)` or `detect_all_parallel()` |
| **Engine** | `layers/l5_detection.py → Layer5Detection` |
| **Input** | `X` — numpy array N×D |
| **Output** | `self.detection.results: Dict[str, DetectionResult]` |
| **Extraction** | `score_matrix, method_names = self.detection.get_score_matrix()` |

**`DetectionResult` dataclass** (per method):

| Field | Type | Description |
|-------|------|-------------|
| `method_name` | `str` | Algorithm name |
| `category` | `str` | Family category |
| `scores` | `np.ndarray` | N-length score array [0, 1] |
| `labels` | `np.ndarray` | N-length binary labels |
| `threshold` | `float` | Decision threshold used |

**`score_matrix`**: `np.ndarray` shape `(N, M)` where M = number of methods run.  
**`method_names`**: `List[str]` length M — ordered method names.

**26 detectors across 8 categories**:

| Category | Methods |
|----------|---------|
| Statistical (5) | `zscore`, `iqr`, `grubbs`, `dixon`, `esd` |
| Distance (3) | `knn`, `mahalanobis`, `lof` |
| Density (4) | `dbscan`, `optics`, `hdbscan`, `cblof` |
| Clustering (3) | `kmeans_anomaly`, `gmm`, `spectral` |
| Trees (2) | `isolation_forest`, `extended_if` |
| Time-Series (3) | `stl`, `arima_residual`, `prophet` |
| Graph (4) | `pagerank`, `hits`, `community`, `centrality` |
| Deep Learning (2) | `autoencoder`, `vae` |

Each method receives the appropriate matrix version per `METHOD_SPECS` (X_RAW, X_STANDARD, X_MINMAX, TIME_SERIES, GRAPH).

---

### Step L6: Ensemble Fusion

| Aspect | Detail |
|--------|--------|
| **Call** | `self.ensemble.fuse(score_matrix, method_names)` |
| **Engine** | `layers/l6_ensemble.py → Layer6Ensemble` |
| **Input** | `score_matrix` (N×M), `method_names` (List[str]) |
| **Output variable** | `ensemble_result: EnsembleResult` |

**`EnsembleResult` dataclass**:

| Field | Type | Description |
|-------|------|-------------|
| `final_scores` | `np.ndarray` | N-length fused scores [0, 1] |
| `risk_tiers` | `np.ndarray` | N-length tier labels |
| `method_weights` | `Dict[str, float]` | Per-method concordance weights |
| `tier_counts` | `Dict[str, int]` | CRITICAL/HIGH/MEDIUM/LOW/NORMAL counts |
| `vote_counts` | `np.ndarray` | N-length vote tallies |
| `normalized_scores` | `np.ndarray` | N×M normalized score matrix |

**5 Fusion methods**:

| Method | Formula |
|--------|---------|
| `tiered_consensus` (default) | Concordance-weighted average |
| `weighted_average` | Direct weighted sum |
| `rank_fusion` | Per-method rank normalization → mean |
| `max` | Per-record max across methods |
| `voting` | Binary vote threshold → proportion |

**Risk tier thresholds** (V16 epsilon tolerance):

| Tier | Score range |
|------|-------------|
| CRITICAL | > 0.80 |
| HIGH | > 0.60, ≤ 0.80 |
| MEDIUM | > 0.40, ≤ 0.60 |
| LOW | > 0.20, ≤ 0.40 |
| NORMAL | ≤ 0.20 |

---

### Step L7: Output

| Aspect | Detail |
|--------|--------|
| **Call** | `self.output.process(df, final_scores, risk_tiers, score_matrix, method_names)` |
| **Engine** | `layers/l7_output.py → Layer7Output` |
| **Input** | `df` (DataFrame), `ensemble_result` fields, `score_matrix`, `method_names` |
| **Output** | `output_summary: Dict` with key `alerts_generated` |

**Sub-components**:

| Component | Class | Output |
|-----------|-------|--------|
| Investigation Queue | `InvestigationQueue` | Priority-sorted alerts (capacity-limited) |
| Narrative System | `NarrativeSystem` | SHAP-style text explanations per alert |
| Audit Trail | `AuditTrail` | JSONL log to `vault/logs/audit_trail.jsonl` |

**`Alert` dataclass** (per flagged record):

| Field | Type |
|-------|------|
| `alert_id` | `str` |
| `record_index` | `int` |
| `risk_score` | `float` |
| `risk_tier` | `str` |
| `top_contributors` | `List[Dict]` |
| `narrative` | `str` |
| `status` | `str` |
| `assigned_to` | `str` |
| `created_at` | `str` |

---

### Final: Scored DataFrame Construction

After L7, the pipeline adds columns to `df`:

| Added Column | Source |
|--------------|--------|
| `anomaly_score` | `ensemble_result.final_scores` |
| `risk_tier` | `ensemble_result.risk_tiers` |
| `score_{method}` (one per method) | `score_matrix[:, i]` for each `method_names[i]` |

Stored as `self.df_processed` and `result.df_scored`.

---

### Persistence (save_results)

| File | Path | Content |
|------|------|---------|
| Scored data | `vault/scored.parquet` | `df_scored` (full DataFrame with all scores) |
| Pipeline result JSON | `vault/pipeline_result.json` | `result_json` dict (see Section B) |
| Run history | `vault/run_history/<run_id>/scored.parquet` | Per-run scored data |
| Run manifest | `vault/run_history/<run_id>/run_manifest.json` | Run metadata |
| Alert exports | `exports/alerts_*.xlsx` | Excel export of flagged records |
| Audit trail | `vault/logs/audit_trail.jsonl` | All L7 audit decisions |
| Pipeline status | `vault/pipeline_status.json` | Progress polling file |
| Metadata | `vault/metadata.json` | Import metadata |
| SQLite | `database/` | Tables: `data_imports`, `anomalies`, `pipeline_runs` |

---

## B. DATA ARTIFACT INVENTORY

### `result_json` — Central JSON Artifact

Built in `pipeline_run.py` L664–683 and saved to `vault/pipeline_result.json`:

```python
result_json = {
    # ─── Core metrics ───
    "success":            True,                          # bool
    "timestamp":          result.timestamp,              # str (ISO)
    "records_processed":  result.records_processed,      # int
    "dq_score":           result.dq_score,               # float
    "features_generated": result.features_generated,     # int
    "methods_run":        result.methods_run,             # int
    "alerts_generated":   result.alerts_generated,       # int
    "tier_distribution":  result.tier_distribution,      # Dict[str, int] {Critical: N, High: N, ...}
    "execution_time_ms":  result.execution_time_ms,      # float
    "data_source":        data_source,                   # str ("sample" | "actual")

    # ─── Per-method scores ───
    "method_scores":      method_scores,                 # List[Dict] [{method, category, mean_score, max_score, anomalies}]
    "layer_timings":      layer_timings,                 # Dict[str, float] {layer_label → seconds}

    # ─── Risk analysis ───
    "risk_by_family":     risk_by_family,                # List[Dict] [{Family, Methods, Critical, High, Medium, Low}]
    "risk_by_ensemble":   risk_by_ensemble,              # List[Dict] [{Ensemble Method, Total Customers, Critical, High, Medium, Low, Anomaly Rate}]

    # ─── V24 5-Module DQ Pipeline results ───
    "dq_validation":      result.dq_validation_dict,     # Dict (M1 output)
    "dq_processing":      result.dq_processing_dict,     # Dict (M2 output)
    "preprocessing":      result.preprocessing_dict,     # Dict (M3 output)
    "scaling":            result.scaling_dict,            # Dict (M4 output)
    "reduction":          result.reduction_dict,          # Dict (M5 output)
}
```

### `PipelineResult` Dataclass Fields

| Field | Type | Source step |
|-------|------|-------------|
| `success` | `bool` | Pipeline completion status |
| `timestamp` | `str` | ISO timestamp |
| `records_processed` | `int` | len(df_scored) |
| `dq_score` | `float` | From M1 (DQ validation) |
| `features_generated` | `int` | From L3 |
| `methods_run` | `int` | Number of L5 methods |
| `alerts_generated` | `int` | From L7 output_summary |
| `tier_distribution` | `Dict[str, int]` | From L6 ensemble_result.tier_counts |
| `execution_time_ms` | `float` | Wall-clock time |
| `df_scored` | `Optional[DataFrame]` | Final scored DataFrame |
| `ensemble_result` | `Optional[EnsembleResult]` | L6 output |
| `layer_timings` | `Dict` | Per-layer timing |
| `error` | `Optional[str]` | Error message if failed |
| `run_id` | `str` | UUID for this run |
| `input_hash` | `str` | Hash of input data |
| `failed_methods` | `List[str]` | L5 methods that failed |
| `circuit_breaker_skipped` | `List[str]` | Methods skipped by circuit breaker |
| `dq_validation_dict` | `Dict` | M1 serialised |
| `dq_processing_dict` | `Dict` | M2 serialised |
| `preprocessing_dict` | `Dict` | M3 serialised |
| `scaling_dict` | `Dict` | M4 serialised |
| `reduction_dict` | `Dict` | M5 serialised |

### Vault File Inventory

| File | Format | Producer | Consumer(s) |
|------|--------|----------|-------------|
| `vault/sources/<table>.parquet` | Parquet | `data_vault.save_sources()` | `data_vault.load_sources()`, L1-2, dashboard, data_sources page |
| `vault/current.parquet` | Parquet | `data_vault.set_current_data()` | `data_vault.get_data()`, pipeline_run.py |
| `vault/scored.parquet` | Parquet | `data_vault.set_scored_data()` | All pages (dashboard, queue, narratives, diagnostics, explainability, layer_view) |
| `vault/pipeline_result.json` | JSON | `data_vault.save_pipeline_result()` | dashboard, layer_view (all module tabs), pipeline_run.py (reload) |
| `vault/pipeline_status.json` | JSON | Pipeline progress updates | pipeline_run.py polling callback |
| `vault/metadata.json` | JSON | `data_vault.import_data()` | Internal tracking |
| `vault/l5_checkpoint.json` | JSON | L5 detection checkpoint | Pipeline resume |
| `vault/exclude_vars.json` | JSON | Exclusion config | DQ processing |
| `vault/run_history/<run_id>/scored.parquet` | Parquet | `save_results()` | History browsing |
| `vault/run_history/<run_id>/run_manifest.json` | JSON | `save_results()` | History browsing |
| `exports/alerts_*.xlsx` | Excel | `export_alerts_excel()` | Download |
| `vault/logs/audit_trail.jsonl` | JSONL | `AuditTrail` (L7) | Compliance audit |
| `data_sources/config_*.csv` | CSV | Data sources page uploads | `_config_store` auto-load |

### dcc.Store Artifacts (Client-Side)

| Store ID | Type | Set by | Read by |
|----------|------|--------|---------|
| `store-pipeline-complete` | `data` (timestamp) | `run_pipeline()` callback | All pages (triggers refresh) |
| `store-current-customer` | `data` (dict: `{idx, score}`) | explainability.py `analyze_customer()` | explainability.py chart callbacks |

---

## C. PAGE → DATA MAP

### Page: Dashboard (`pages/dashboard.py`, route `/`)

| Callback | Reads from | Keys/Columns used |
|----------|-----------|-------------------|
| `update_source_stats()` | `data_vault.get_source_stats()` | `table_count`, `total_rows`, `tables` dict |
| `update_pipeline_summary()` | `data_vault.load_pipeline_result()` | `success`, `timestamp`, `records_processed`, `dq_score`, `features_generated`, `methods_run`, `alerts_generated`, `tier_distribution`, `execution_time_ms` |
| `update_kpi_row()` | `data_vault.get_scored_data()` + `load_pipeline_result()` | `anomaly_score` (col), `score_*` (cols, counted) |
| `update_layer_status()` | `data_vault.load_pipeline_result()` | `layer_timings`, `success` |
| `update_methods_cat()` | `LAYERS.DETECTION_METHODS` | Config only (no vault data) |
| `update_risk_dist()` | `data_vault.get_scored_data()` | `risk_tier` (col) |
| `update_algo_perf()` | `data_vault.get_scored_data()` | `score_*` (cols, detection rate) |
| `update_trend_chart()` | `data_vault.get_scored_data()` | `timestamp` (col), `anomaly_score` (col) |
| `update_heatmap()` | `data_vault.get_scored_data()` | `timestamp` (col), `anomaly_score` (col) |
| `clear_cache()` | `data_vault.clear_data()` | Clears all vault data |

### Page: Data Sources (`pages/data_sources.py`, route `/sources`)

| Callback / Function | Reads from | Keys/Columns used |
|---------------------|-----------|-------------------|
| Upload callbacks | File uploads → `data_vault.save_sources()` | 12 table slots + 10 config slots |
| `_build_master_table()` | `data_vault.load_sources()` | All source DataFrames merged via RollupEngine |
| `_slot_status_widget()` | `sources` dict | Per-table row counts |
| `_auto_load_configs()` | `PATHS.DATA_SOURCES / config_*.csv` | Config CSVs from disk |
| MULTI_SHEET_SLOTS | `relationships` → `relationships_edges`, `relationships_nodes`; `temporal` → `temporal_long`, `temporal_wide` | Split into sub-tables |

### Page: Pipeline Run / Execution Engine (`pages/pipeline_run.py`, route `/pipeline`)

| Callback | Reads from | Keys/Columns used |
|----------|-----------|-------------------|
| `layout()` | `data_vault.load_sources()`, `data_vault.get_data()` | Source tables, merged data |
| `update_data_status()` | `data_vault.load_sources()`, `data_vault.get_data()` | Table count, row count, unique customers |
| `run_pipeline()` | `data_vault.load_sources()`, `data_vault.get_data()` | Source DataFrames, merged DataFrame |
| `run_pipeline()` → Writes | `data_vault.save_pipeline_result(result_json)`, `data_vault.set_scored_data()`, `data_vault.sync_anomalies_to_db()` | Full result_json, scored DataFrame, SQLite sync |
| `poll_progress()` | `PATHS.DATA_VAULT / "pipeline_status.json"` | `progress`, `status`, `stage` |
| `load_saved_results()` | `data_vault.load_pipeline_result()`, `data_vault.get_scored_data()` | All result_json keys, scored DataFrame |
| `_build_scored_preview()` | `df_scored` | `customer_name`, `customer_id`, `party_id`, `anomaly_score`, `risk_tier`, `score_*` cols |

### Page: Layer View (`pages/layer_view.py`, route `/layers`)

| Callback | Reads from | result_json keys used |
|----------|-----------|----------------------|
| `update_l12()` | `data_vault.load_sources()`, `load_pipeline_result()` | `dq_score` |
| `update_l3()` | `data_vault.get_scored_data()`, `load_pipeline_result()` | `features_generated` |
| `update_l4()` | `data_vault.get_scored_data()` | Scored DataFrame numeric cols |
| `update_l5()` | `data_vault.get_scored_data()`, `load_pipeline_result()` | `methods_run`, `score_*` cols |
| `update_l6()` | `data_vault.get_scored_data()`, `load_pipeline_result()` | `anomaly_score` col, `tier_distribution` |
| `update_l7()` | `data_vault.get_scored_data()`, `load_pipeline_result()` | `alerts_generated`, `tier_distribution`, `execution_time_ms`, `anomaly_score`, `risk_tier`, `score_*` cols |
| `update_dq_scorecard()` | `load_pipeline_result()` | **`dq_validation`** → `dq_score`, `passed`, `dimensions`, `step_log` |
| `update_dq_processing()` | `load_pipeline_result()` | **`dq_processing`** → `step_log`, `columns_dropped`, `columns_renamed`, `shape_before`, `shape_after`, `summary` |
| `update_encoded_master()` | `load_pipeline_result()` | **`preprocessing`** → `shape_before`, `shape_after`, `encoding_map`, `missing_treatment`, `step_log` |
| `update_scaling()` | `load_pipeline_result()` | **`scaling`** → `step_log`, `scaler_stats`, `input_shape` |
| `update_reduction()` | `load_pipeline_result()` | **`reduction`** → `path_used`, `path_name`, `dims_before`, `dims_after`, `explained_variance`, `agent_selection`, `step_log` |
| `update_routing()` | `utils/algorithm_routing` module | `routing_summary_df()`, `get_all_routes()` |

### Page: Investigation Queue (`pages/investigation_queue.py`, route `/queue`)

| Callback | Reads from | Keys/Columns used |
|----------|-----------|-------------------|
| `update_queue()` | `data_vault.get_scored_data()` | `anomaly_score`, `risk_tier`, `customer_id`/`party_id`, `vote_count` (if present) |

### Page: Narratives (`pages/narratives.py`, route `/narratives`)

| Callback | Reads from | Keys/Columns used |
|----------|-----------|-------------------|
| `update_narratives()` | `data_vault.get_scored_data()`, `data_vault.load_pipeline_result()` | `anomaly_score`, `risk_tier`, `customer_name`/`customer_id`/`party_id`, `score_*` cols |

### Page: Model Diagnostics (`pages/model_diagnostics.py`, route `/diagnostics`)

| Callback | Reads from | Keys/Columns used |
|----------|-----------|-------------------|
| `update_model_status()` | `LAYERS.DETECTION_METHODS`, model file check | Config only |
| `update_latent_space()` | `data_vault.get_scored_data()` | All numeric columns, `anomaly_score`, `risk_level` |
| `update_score_histogram()` | `data_vault.get_scored_data()` | `score_*` cols (filtered by family/algo) |
| `update_feature_importance()` | `data_vault.get_scored_data()` | All numeric cols vs `score_*` cols (correlation) |
| `update_algo_agreement()` | `data_vault.get_scored_data()` | `score_*` cols (pairwise correlation matrix) |
| `update_config_table()` | `LAYERS` config | Config only |

### Page: Explainability (`pages/explainability.py`, route `/explainability`)

| Callback | Reads from | Keys/Columns used |
|----------|-----------|-------------------|
| `analyze_customer()` | `data_vault.get_scored_data()` | `anomaly_score`, `risk_tier`, `customer_name`, `customer_id`, `party_id` |
| `update_feature_contribution()` | `data_vault.get_scored_data()` | `score_*` cols for selected customer index |
| `update_reasoning()` | `data_vault.get_scored_data()` | `anomaly_score`, `score_*` cols for selected customer |
| `update_global_importance()` | `data_vault.get_scored_data()` | `score_*` cols (std dev as importance proxy) |

---

## D. MODULE TAB MAP (layer_view.py)

### Pipeline Module Tabs (V23/V24 Addition)

| Tab Value | Tab Label | Callback Function | Output div ID | result_json Key | Sub-keys Consumed |
|-----------|-----------|-------------------|---------------|-----------------|-------------------|
| `dq_score` | DQ Scorecard | `update_dq_scorecard()` | `layer-dq-score-content` | `"dq_validation"` | `dq_score`, `passed`, `dimensions` (dict of 5 scores), `step_log` |
| `dq_proc` | DQ Processing | `update_dq_processing()` | `layer-dq-proc-content` | `"dq_processing"` | `step_log`, `columns_dropped`, `columns_renamed`, `shape_before`, `shape_after`, `summary` |
| `enc_master` | EncodedMaster | `update_encoded_master()` | `layer-enc-master-content` | `"preprocessing"` | `shape_before`, `shape_after`, `encoding_map`, `missing_treatment`, `step_log` |
| `scaling` | 6-Way Scaling | `update_scaling()` | `layer-scaling-content` | `"scaling"` | `step_log` (list of dicts with `scaler`, `status`, `shape`, `min`, `max`), `scaler_stats`, `input_shape` |
| `reduction` | Reduction | `update_reduction()` | `layer-reduction-content` | `"reduction"` | `path_used`, `path_name`, `dims_before`, `dims_after`, `explained_variance`, `agent_selection`, `step_log` |
| `routing` | Algo Routing | `update_routing()` | `layer-routing-content` | *(none — reads from `utils/algorithm_routing` module)* | `routing_summary_df()`, `get_all_routes()` |

### Original Layer Tabs (L1–L7)

| Tab Value | Tab Label | Callback Function | Output div ID | Data Source | Key Artifacts |
|-----------|-----------|-------------------|---------------|-------------|---------------|
| `l12` | L1-2: Ingest + DQ | `update_l12()` | `layer-l12-content` | `data_vault.load_sources()` + `load_pipeline_result()` | Source table stats, null analysis, type distribution, `dq_score` |
| `l3` | L3: Features | `update_l3()` | `layer-l3-content` | `data_vault.get_scored_data()` + `load_pipeline_result()` | `features_generated`, feature category counts, correlation heatmap |
| `l4` | L4: Preproc | `update_l4()` | `layer-l4-content` | `data_vault.get_scored_data()` | Matrix version cards (RAW/SCALED/PCA/ENCODED), feature stats, box plots |
| `l5` | L5: Detection | `update_l5()` | `layer-l5-content` | `data_vault.get_scored_data()` + `load_pipeline_result()` | `methods_run`, per-method stats from `score_*` cols, category chart, score heatmap |
| `l6` | L6: Ensemble | `update_l6()` | `layer-l6-content` | `data_vault.get_scored_data()` + `load_pipeline_result()` | `anomaly_score` distribution, `tier_distribution`, Sankey diagram (categories → ensemble → tiers) |
| `l7` | L7: Output | `update_l7()` | `layer-l7-content` | `data_vault.get_scored_data()` + `load_pipeline_result()` | `alerts_generated`, `tier_distribution`, `execution_time_ms`, top-20 risk records |

---

## E. COMPLETE DATA SHAPE TRANSFORMATION TRACE

```
sources (Dict of 12 DataFrames)
    │
    ▼
df = merged DataFrame .................. N × K     (raw merged)
    │
    ├── M1: DQ Validation .............. N × K     (no shape change, produces dq_validation_dict)
    │
    ├── V6: Customer Aggregation ....... N' × K    (optional, N' ≤ N)
    │
    ├── L3: Feature Engineering ........ N' × K'   (K' > K, adds ~25 feature columns)
    │
    ├── V8: Schema Detection ........... N' × K'   (no shape change, produces schema_profiles)
    │
    ▼
df_cleaned (M2 output) ................ N' × K''  (K'' ≤ K', columns dropped/renamed)
    │
    ▼
encoded_master (M3 output) ............ N' × K''' (K''' may differ from K'', OHE expands, 100% float)
    │
    ▼
scaled_matrices (M4 output) ........... 6 × [N' × K'''] numpy arrays (one per scaler)
    │
    ├── Select StandardScaler .......... N' × K''' numpy array
    │
    ▼
X = premaster (M5 output) ............. N' × D    (D ≤ K''', dims reduced)
    │
    ▼
L5: Detection ......................... score_matrix: N' × M  (M = methods run)
    │                                    method_names: [M]
    │
    ▼
L6: Ensemble .......................... final_scores: [N']
    │                                    risk_tiers:   [N']
    │
    ▼
L7: Output ............................ alerts: List[Alert]
    │                                    narratives: List[str]
    │
    ▼
df_scored .............................. N' × (K' + M + 2)
    │                                    (original cols + score_{method} cols + anomaly_score + risk_tier)
    │
    ▼
vault/scored.parquet .................. Persisted
vault/pipeline_result.json ............ Persisted
SQLite (anomalies, pipeline_runs) ..... Persisted
```

---

*End of V24 Data Transformation Flow Map*
