"""
AIM AI Vault V30 — Unified L01–L14 Sequential Pipeline
=======================================================
Centralized configuration for the 14-layer AML anomaly detection pipeline.

V30 Enhancements (Unified L01–L14 Naming):
  L01: Ingest & Merge — Multi-source ingestion + initial DQ cleanse
  L02: DQ Validation — 6-check quality scorecard gate (≥95% to proceed)
  L03: Customer Aggregation — Aggregate to entity/customer level
  L04: Feature Engineering — Generate 50+ AML behavioural features
  L05: Schema Detection — Type-aware column profiling + auto-parameters
  L06: DQ Processing — 12-step sequential cleansing
  L07: Encoding — Missing→Encode → EncodedMaster (100% numeric)
  L08: Transformation — Conditional log/power/Box-Cox per-column transform
  L09: Scaling — 6-Way: Standard/MinMax/Robust/MaxAbs/Power/Original
  L10: Dimension Reduction — 9-Path: None/MixedPCA/FAMD/UMAP/SDAE/Agent
  L11: Detection — 20 algorithms across 8 families + algorithm routing
  L12: Explainability — SHAP TreeExplainer/KernelExplainer per method
  L13: Ensemble Fusion — Weighted combine + risk tier assignment
  L14: Output & Alerts — Investigation queue, audit trail, persistence
  UI: Layer View enhanced with DQ Scorecard, Processing, Scaling, Reduction tabs
  UI: Execution Engine dropdown for reduction path selection

V20 Enhancements (UX & Export):
  U1: Master data CSV export button (download MASTER_TABLE.csv)
  U2: Per-column floating filter search in master AG Grid
  U3: Improved sidebar toggle button (prominent, always visible)
  U4: Compact config file upload boxes

V19 Enhancements (Spec-Driven Rollup Engine):
  R1: New RollupEngine — 4 strategies (DIRECT, AGGREGATE, TAKE_LATEST, AUTO_DETECT)
  R2: 12 data-table slots (BASE mandatory + 11 optional)
  R3: 10 config-file upload slots (all optional with safe defaults)
  R4: GRAPH_DATA & TEMPORAL_DATA extracted separately — NOT joined to MASTER
  R5: Configurable BASE_KEY with alias detection (cust_id, customer_id, party_id, …)
  R6: 4-priority key discovery (TABLE_MAP config → exact → alias → suffix)
  R7: Type-aware aggregation (numeric SUM/AVG/MAX; categorical COUNT/MODE; datetime SPAN)
  R8: Automatic blank-column cleaning & PII exclusion
  R9: Full processing log with per-table rollup summary
  R10: Downloadable exports (MASTER CSV, GRAPH JSON, TEMPORAL JSON)

V17 Enhancements (Full Wiring — Air-Gapped Privacy):
  All V16 declarations (A4/A5/A6) wired into execution code:
  E1: mask_for_memory() wired into all data-load paths
  E2: mask_for_api() wired into REST API DataFrame endpoints
  E3: PIIAccessLog table populated on every PII column access
  E4: HashVerification table populated on every verify_hash_chain()
  E5: DataService PII gate — all getters mask before returning
  E6: AIRGAP_CHECK TOML-toggleable config param
  E7: Inline mask_dataframe() replaced with V16 wrappers
  E8: Hash chain verify button in Dash audit trail page
  E9: ALLOW_PII_DISABLE safety lock enforced via wrappers

V16 Enhancements (Bank Audit Hardening):
  A4: PII masking enforced-by-default with TOML override
  A5: Risk tier epsilon tolerance wired into L6 ensemble
  A6: Hash-chain persistence hardened with verification & corruption recovery
  Modular TOML-parameterized config — change ANYTHING without code edits
  Bank audit table enhancements (PII access log, hash chain verification)
  Air-gapped reinforcement with network interface check

V15 Enhancements (retained):
  FastAPI REST API (14 endpoints), JWT + API Key auth, PII auto-masking,
  Swagger UI, OpenAPI 3.0, GitHub-ready project structure

V14 Enhancements (Categories 1-5, 7):
  1. SCALABILITY:   Waitress WSGI, ProcessPoolExecutor L5, TOML config
  2. ROBUSTNESS:    Circuit breaker, graceful degradation, watchdog thread
  3. CONSISTENCY:   Data contracts, error codes, service layer
  4. PERSISTENCE:   Parquet partitioning by run_id, backup automation
  5. OBSERVABILITY: Structured JSON logging, system health page, cProfile
  7. UX/FRONTEND:   Loading states, keyboard shortcuts, offline help

V13 Fixes (retained):
  - F-1: safe_session / write_session context managers in engine.py
  - F-2: Sanitized error messages in pipeline
  - F-3: Safe load_user int() conversion
  - F-4: Logged corrupt Parquet errors in DataVault
  - F-6: Safe Diskcache creation
  - F-7: Atomic pipeline status write
  - B-1/B-3: Reduced polling intervals (30s/15s)
  - B-2/S-5: Parallel L5 detection (ThreadPoolExecutor)
  - B-4/S-4: Lazy Parquet loading in DataVault
  - B-5: Chunked DataFrame hashing
  - B-6/S-2: Reduced DataFrame copies
  - B-7/C-4: Batched hash chain persistence
  - C-1: Diskcache cleared on startup
  - C-2: Memory release on vault reload
  - C-3: Fernet key rotation age warning
  - S-1: DB write serialization (threading.Lock + retry)
  - S-6: Audit log archival

V10 Enhancements (Production Core):
  - SQLite + SQLAlchemy persistent backend (WAL mode)
  - Flask-Login multi-user authentication with RBAC
  - Diskcache background task queue for pipeline
  - Polars fast data ingestion
  - Anomaly confirmation workflow stored in DB
  - DB-backed audit logging (dual: file + SQLite)

V9 Enhancements (VAT audit fixes):
  - PII masking enabled by default (FM-006)
  - Hash chain persistence across restarts (FM-007)
  - Risk tier ε-tolerance for float boundaries (FM-003)
  - CSV formula injection protection (FM-010)
  - Upload size validation (FM-009)
  - VAE KL divergence backprop fix (FM-020)
  - In-memory PII masking for data vault (FM-008)

V8 Enhancements:
  - Role-based column mapping (no hardcoded column names)
  - Type-aware preprocessing config
  - Parameterized thresholds (all tunable from here)
  - Memory-safe limits for 8GB CPU-only
  - Audit & data lineage config
  - Air-gapped / zero-telemetry enforcement

Author: AIM AI Vault Team
"""

from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


# =============================================================================
# PATH CONFIGURATION
# =============================================================================
BASE_DIR = Path(__file__).parent

@dataclass
class PathConfig:
    """File system paths."""
    BASE: Path = BASE_DIR
    DATA: Path = BASE_DIR / "data"
    DATA_VAULT: Path = BASE_DIR / "data" / "vault"
    DATA_SOURCES: Path = BASE_DIR / "data" / "sources"
    EXPORTS: Path = BASE_DIR / "data" / "exports"
    MODELS: Path = BASE_DIR / "models"
    LOGS: Path = BASE_DIR / "logs"
    CACHE: Path = BASE_DIR / "cache"
    ASSETS: Path = BASE_DIR / "assets"
    RUN_HISTORY: Path = BASE_DIR / "data" / "vault" / "runs"

    def __post_init__(self):
        for path in [self.DATA_VAULT, self.DATA_SOURCES, self.EXPORTS,
                     self.MODELS, self.LOGS, self.CACHE, self.ASSETS,
                     self.RUN_HISTORY]:
            path.mkdir(parents=True, exist_ok=True)


# =============================================================================
# V8: ROLE-BASED COLUMN CONFIGURATION (No hardcoded column names!)
# =============================================================================
@dataclass
class ColumnRoleConfig:
    """
    Maps *semantic roles* to potential column names.
    The pipeline resolves columns by ROLE, never by hardcoded name.
    Users can override via the Data Sources config page.
    """
    ROLE_ALIASES: Dict[str, List[str]] = field(default_factory=lambda: {
        "primary_key":  ["cust_id", "customer_id", "party_id", "client_id", "entity_id"],
        "entity_name":  ["cust_name", "customer_name", "party_name", "client_name", "full_name", "name"],
        "amount":       ["amount", "txn_amount", "transaction_amount", "value", "amt"],
        "timestamp":    ["timestamp", "txn_date", "transaction_date", "date", "created_at", "event_date"],
        "account_key":  ["account_id", "acct_id", "account_number", "account"],
        "txn_key":      ["txn_id", "transaction_id", "trans_id"],
        "txn_type":     ["txn_type", "transaction_type", "type", "tx_type"],
        "currency":     ["currency", "ccy", "currency_code"],
        "country":      ["country", "country_code", "jurisdiction"],
        "channel":      ["channel", "txn_channel", "payment_method"],
    })

    ROLE_DTYPE_HINT: Dict[str, str] = field(default_factory=lambda: {
        "primary_key": "id", "entity_name": "text", "amount": "numeric",
        "timestamp": "datetime", "account_key": "id", "txn_key": "id",
        "txn_type": "categorical", "currency": "categorical",
        "country": "categorical", "channel": "categorical",
    })

    MANDATORY_ROLES: List[str] = field(default_factory=lambda: ["primary_key"])

    # Runtime overrides from UI (role -> actual column name)
    USER_OVERRIDES: Dict[str, str] = field(default_factory=dict)

    def resolve(self, df_columns: List[str], role: str) -> Optional[str]:
        """Resolve a role to an actual column name in the dataframe."""
        # 1. Check user overrides first
        if role in self.USER_OVERRIDES:
            override = self.USER_OVERRIDES[role]
            if override in df_columns:
                return override

        # 2. Check aliases (case-insensitive)
        aliases = self.ROLE_ALIASES.get(role, [])
        col_lower_map = {c.lower(): c for c in df_columns}
        for alias in aliases:
            if alias.lower() in col_lower_map:
                return col_lower_map[alias.lower()]

        # 3. Partial match
        for alias in aliases:
            for col_lower, col_orig in col_lower_map.items():
                if alias.lower() in col_lower:
                    return col_orig

        return None


# =============================================================================
# THEME CONFIGURATION
# =============================================================================
@dataclass
class ThemeConfig:
    """UI theme colors and styles."""
    PRIMARY: str = "#00D4FF"
    SECONDARY: str = "#9D4EDD"
    SUCCESS: str = "#00C853"
    WARNING: str = "#FFB300"
    DANGER: str = "#FF5252"
    INFO: str = "#2196F3"

    DARK_BG: str = "#0D1117"
    DARK_BG_PRIMARY: str = "#0a0a12"
    DARK_BG_SECONDARY: str = "#12121f"
    DARK_BG_PAPER: str = "#1a1a2e"
    DARK_BG_CARD: str = "#16213e"
    DARK_BORDER: str = "#30363D"

    RISK_GRADIENT: List[str] = field(default_factory=lambda: [
        "#00C853", "#4CAF50", "#FFC107", "#FF9800", "#FF5252",
    ])

    def get_mantine_theme(self) -> Dict[str, Any]:
        """Return base Mantine theme dict.

        Paper / Card component styles are intentionally omitted here so
        that the per-theme ``switch_theme`` callback can inject the
        correct background colours for both dark *and* light themes.
        """
        return {
            "primaryColor": "cyan",
            "fontFamily": "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
            "colors": {
                "cyan": ["#e3fafc","#c5f6fa","#99e9f2","#66d9e8","#3bc9db",
                         "#22b8cf","#15aabf","#1098ad","#0c8599","#0b7285"],
                "grape": ["#f8f0fc","#f3d9fa","#eebefa","#e599f7","#da77f2",
                          "#cc5de8","#be4bdb","#ae3ec9","#9c36b5","#862e9c"],
                "indigo": ["#edf2ff","#dbe4ff","#bac8ff","#91a7ff","#748ffc",
                           "#5c7cfa","#4c6ef5","#4263eb","#3b5bdb","#364fc7"],
                "violet": ["#f3f0ff","#e5dbff","#d0bfff","#b197fc","#9775fa",
                           "#845ef7","#7950f2","#7048e8","#6741d9","#5f3dc4"],
                "teal": ["#e6fcf5","#c3fae8","#96f2d7","#63e6be","#38d9a9",
                         "#20c997","#12b886","#0ca678","#099268","#087f5b"],
                "orange": ["#fff4e6","#ffe8cc","#ffd8a8","#ffc078","#ffa94d",
                           "#ff922b","#fd7e14","#f76707","#e8590c","#d9480f"],
                "pink": ["#fff0f6","#ffdeeb","#fcc2d7","#faa2c1","#f783ac",
                         "#f06595","#e64980","#d6336c","#c2255c","#a61e4d"],
            },
            "components": {},
        }


# =============================================================================
# PII MASKING CONFIGURATION
# =============================================================================
@dataclass
class PIIConfig:
    """Privacy mode configuration for PII data protection.
    
    V16 Bank Audit Hardening:
      - ENABLED_BY_DEFAULT=True (FMEA FM-006, RPN 240) — cannot be toggled off
        unless ALLOW_PII_DISABLE=True is explicitly set in config.toml
      - MASK_IN_MEMORY=True (FMEA FM-008) — mask PII in DataVault memory
      - ALLOW_PII_DISABLE — safety lock: must be explicitly True to allow
        disabling PII masking (prevents accidental exposure)
      - LOG_PII_ACCESS — audit every PII column access to audit_logs table
    
    All parameters overridable via [pii] section in config.toml.
    """
    ENABLED_BY_DEFAULT: bool = True   # V9: FM-006 — enabled by default for production safety
    ALLOW_PII_DISABLE: bool = False   # V16: Safety lock — True required to disable PII
    MASK_AT_STORAGE: bool = True      # V8: Mask before writing to vault
    MASK_IN_EXPORTS: bool = True      # V8: Mask when exporting
    MASK_IN_MEMORY: bool = True       # V16: FM-008 — mask PII in DataVault memory views
    MASK_IN_API: bool = True          # V16: Mask PII in all REST API responses
    LOG_PII_ACCESS: bool = True       # V16: Audit-log every PII column access
    MASK_PATTERN: str = "XXXX"
    VISIBLE_CHARS: int = 4

    MASKED_COLUMNS: List[str] = field(default_factory=lambda: [
        "customer_id", "account_number", "ssn", "email", "phone",
    ])

    PATTERNS: Dict[str, str] = field(default_factory=lambda: {
        "customer_id": r"^(.{4}).*(.{4})$",
        "email": r"^(.{2}).*(@.*)$",
        "phone": r"^.*(.{4})$",
        "account": r"^.*(.{4})$",
    })


# =============================================================================
# V8: MEMORY & RESOURCE CONFIGURATION (8GB CPU-only)
# =============================================================================
@dataclass
class ResourceConfig:
    """Resource limits for 8GB RAM / CPU-only environment."""
    MAX_MEMORY_MB: int = 4096
    MAX_ROWS_FOR_HEAVY_METHODS: int = 5000
    MAX_ROWS_AG_GRID_PREVIEW: int = 500
    BATCH_SIZE_DETECTION: int = 2000
    LAZY_MATRIX_CREATION: bool = True
    MAX_CONCURRENT_METHODS: int = 4   # V13: Allow parallel L5 threads


# =============================================================================
# LAYER CONFIGURATION — fully parameterized
# =============================================================================
@dataclass
class LayerConfig:
    """7-Layer pipeline configuration."""

    # Layer 1-2: Ingestion & Data Quality
    DQ_THRESHOLDS: Dict[str, float] = field(default_factory=lambda: {
        "completeness": 0.95, "consistency": 0.90, "validity": 0.85,
    })

    # Layer 3: Feature Engineering — all thresholds configurable
    FEATURE_CATEGORIES: List[str] = field(default_factory=lambda: [
        "velocity", "aggregates", "ratios", "flags", "temporal", "behavioral",
    ])
    SKEW_THRESHOLD: float = 2.0
    ROUND_AMOUNT_DIVISOR: float = 100.0
    HIGH_AMOUNT_QUANTILE: float = 0.95
    LARGE_TXN_MULTIPLIER: float = 3.0
    CONTAMINATION_RATE: float = 0.05

    # Layer 4: Preprocessing
    MATRIX_VERSIONS: List[str] = field(default_factory=lambda: [
        "raw", "scaled", "pca", "encoded",
    ])
    PCA_COMPONENTS: int = 10
    MIN_FEATURES_FOR_DL: int = 10

    # Layer 5: Detection Methods (26 across 8 families)
    DETECTION_METHODS: Dict[str, List[str]] = field(default_factory=lambda: {
        "statistical":   ["zscore", "iqr", "grubbs", "dixon", "esd"],
        "distance":      ["knn", "mahalanobis", "lof"],
        "density":       ["dbscan", "optics", "hdbscan", "cblof"],
        "clustering":    ["kmeans_anomaly", "gmm", "spectral"],
        "trees":         ["isolation_forest", "extended_if"],
        "timeseries":    ["stl", "arima_residual", "prophet"],
        "graph":         ["pagerank", "hits", "community", "centrality"],
        "deep_learning": ["autoencoder", "vae"],
    })

    HEAVY_METHODS: List[str] = field(default_factory=lambda: [
        "knn", "lof", "dbscan", "optics", "hdbscan", "cblof",
        "spectral", "mahalanobis", "pagerank", "hits", "centrality",
    ])

    ENSEMBLE_FLAG_THRESHOLD: float = 0.5
    ENSEMBLE_METHOD: str = "tiered_consensus"

    RISK_TIERS: Dict[str, Dict] = field(default_factory=lambda: {
        "CRITICAL": {"score_min": 0.95, "vote_min": 23},
        "HIGH":     {"score_min": 0.85, "vote_min": 18},
        "MEDIUM":   {"score_min": 0.70, "vote_min": 12},
        "LOW":      {"score_min": 0.50, "vote_min": 8},
        "NORMAL":   {"score_min": 0.0,  "vote_min": 0},
    })

    METHOD_WEIGHTS: Dict[str, float] = field(default_factory=lambda: {
        "benford": 2.0, "zscore": 1.0, "mad": 1.0, "grubbs": 1.0,
        "isolation_forest": 1.5, "extended_if": 1.3, "lof": 1.5, "knn": 1.0,
        "hdbscan": 1.2, "dbscan": 1.0, "community": 1.2, "pagerank": 1.0,
        "autoencoder": 0.8, "vae": 0.8, "lstm_ae": 0.5,
    })

    SCORE_NORMALIZATION: str = "percentile_rank"
    INVESTIGATION_CAPACITY: int = 1000

    @property
    def MAX_ROWS_FOR_DISTANCE_METHODS(self) -> int:
        """Backward compat alias."""
        return RESOURCES.MAX_ROWS_FOR_HEAVY_METHODS


# =============================================================================
# V8: AUDIT & DATA LINEAGE CONFIGURATION
# =============================================================================
@dataclass
class AuditConfig:
    """Bank MRM audit-ready configuration.
    
    V16 Bank Audit Hardening:
      - Hash chain state verified on load (corruption detection)
      - verify_hash_chain() callable from UI/API
      - HASH_CHAIN_VERIFY_ON_LOAD — auto-verify when loading persisted state
      - HASH_CHAIN_BACKUP_COUNT — keep N backup copies of hash state file
      - All params TOML-overridable via [audit] section
    """
    ENABLE_DATA_LINEAGE: bool = True
    ENABLE_RUN_VERSIONING: bool = True
    ENABLE_HASH_CHAIN_LOGS: bool = True
    LOG_ROTATION_MAX_BYTES: int = 10_000_000   # 10MB
    LOG_ROTATION_BACKUP_COUNT: int = 10
    HASH_ALGORITHM: str = "sha256"
    CAPTURE_CONFIG_SNAPSHOT: bool = True
    PERSIST_HASH_CHAIN: bool = True       # V9: FM-007 — persist hash state across restarts
    HASH_CHAIN_VERIFY_ON_LOAD: bool = True  # V16: Verify integrity when loading state
    HASH_CHAIN_BACKUP_COUNT: int = 3        # V16: Keep N backup copies of hash state
    HASH_CHAIN_BATCH_INTERVAL: int = 10     # V16: Persist every N actions (was hardcoded)
    MAX_UPLOAD_SIZE_MB: int = 100          # V9: FM-009 — upload size limit
    RISK_TIER_EPSILON: float = 1e-9        # V9: FM-003 — float boundary tolerance


# =============================================================================
# APPLICATION CONFIGURATION
# =============================================================================
@dataclass
class AppConfig:
    """Application settings."""
    # ── Centralized branding (change ONLY here for version bumps) ──
    BRAND: str = "AIM AI Vault"
    VERSION: str = "31.0.0"
    VERSION_TAG: str = "V31"                # Short tag for UI badges/tabs
    TITLE: str = f"{BRAND} — FCDAI Anomaly Auto Detection {VERSION_TAG}"
    AIRGAP_CHECK: bool = True               # V17 E6: Enable air-gap network check on startup
    BADGE_COLOR: str = "cyan"               # Standard page subtitle badge color
    RANDOM_SEED: int = 42                   # V27: Global reproducibility seed
    # F-11 FIX: Derive SECRET_KEY from environment; fallback generates random key
    SECRET_KEY: str = field(default_factory=lambda: __import__("os").environ.get(
        "VAULT_SECRET_KEY",
        __import__("os").urandom(32).hex(),
    ))
    HOST: str = "127.0.0.1"
    PORT: int = 8117
    DEBUG: bool = False
    SERVE_LOCALLY: bool = True
    CUSTOMER_LEVEL_PROCESSING: bool = True
    SYNC_INTERVAL_MS: int = 5000

    # Zero-leakage: Strip all cloud-phoning from Plotly
    PLOTLY_CONFIG: Dict = field(default_factory=lambda: {
        "displaylogo": False,
        "modeBarButtonsToRemove": ["sendDataToCloud", "lasso2d", "select2d"],
        "toImageButtonOptions": {"format": "png", "scale": 2},
        "staticPlot": False,
    })


# =============================================================================
# V10: SECURITY / CRYPTO CONFIGURATION
# =============================================================================
@dataclass
class CryptoConfig:
    """Fernet encryption + PII hashing for data sovereignty."""
    ENCRYPT_PII_AT_REST: bool = True       # Fernet-encrypt PII columns in Parquet
    HASH_ENTITY_IDS: bool = True           # SHA-256 hash entity_id in anomalies table
    KEY_FILE: str = ".vault_key"           # Fernet key file (inside data/ dir)
    HASH_SALT: str = "aim-ai-vault-v10"  # Salt for entity_id hashing
    AUTO_ROTATE_DAYS: int = 90             # Key rotation reminder (no auto-rotate yet)


# =============================================================================
# DATA SOURCES CONFIGURATION — role-based
# =============================================================================
@dataclass
class DataSourceConfig:
    """Multi-source data configuration."""
    SOURCES: Dict[str, Dict] = field(default_factory=lambda: {
        "kyc":          {"key_role": "primary_key"},
        "transactions": {"key_role": "txn_key"},
        "alerts":       {"key_role": "primary_key"},
        "cases":        {"key_role": "primary_key"},
        "accounts":     {"key_role": "account_key"},
        "watchlist":    {"key_role": "primary_key"},
    })


# =============================================================================
# V10: DATABASE CONFIGURATION
# =============================================================================
@dataclass
class DatabaseConfig:
    """SQLite + SQLAlchemy backend."""
    DB_NAME: str = "sentinel_vault.db"
    WAL_MODE: bool = True
    ECHO_SQL: bool = False
    POOL_PRE_PING: bool = True
    BUSY_TIMEOUT_MS: int = 5000
    CACHE_SIZE_KB: int = 64000          # 64 MB page cache
    SYNC_ANOMALIES_TO_DB: bool = True   # Write scored data to anomalies table
    SYNC_AUDIT_TO_DB: bool = True       # Write audit entries to DB


# =============================================================================
# V10: AUTHENTICATION CONFIGURATION
# =============================================================================
@dataclass
class AuthConfig:
    """Flask-Login + RBAC settings."""
    ENABLED: bool = True
    SESSION_LIFETIME_MINUTES: int = 480  # 8 hours
    PASSWORD_HASH_METHOD: str = "pbkdf2:sha256"
    DEFAULT_ADMIN_USER: str = "admin"
    DEFAULT_ADMIN_PASS: str = "admin123"   # Change in production!
    ROLES: List[str] = field(default_factory=lambda: ["admin", "investigator", "viewer"])
    ROLE_PAGES: Dict[str, List[str]] = field(default_factory=lambda: {
        "admin":        ["*"],  # all pages
        "investigator": ["/", "/sources", "/pipeline", "/layers", "/queue",
                         "/narratives", "/audit", "/audit-vault",
                         "/diagnostics", "/explainability"],
        "viewer":       ["/", "/layers", "/audit", "/diagnostics", "/explainability"],
    })


# =============================================================================
# V10: BACKGROUND TASK CONFIGURATION
# =============================================================================
@dataclass
class TaskConfig:
    """Diskcache-based background task queue."""
    CACHE_DIR: str = "cache/task_queue"
    EXPIRE_SECONDS: int = 3600           # 1 hour TTL for results
    MAX_RETRIES: int = 2
    POLL_INTERVAL_MS: int = 2000         # UI polling for status


# =============================================================================
# V11: SCHEDULER CONFIGURATION
# =============================================================================
@dataclass
class SchedulerConfig:
    """Offline scheduled pipeline runs (no cloud, Windows-local)."""
    ENABLED: bool = True
    CHECK_INTERVAL_SEC: int = 60          # How often to check for due jobs
    MAX_CONCURRENT_RUNS: int = 1          # Sequential only for SQLite safety
    LOG_SCHEDULE_EVENTS: bool = True      # Audit-log every schedule trigger
    PERSISTENCE_FILE: str = "data/scheduler_state.json"  # Air-gapped state file


# =============================================================================
# V11: ALERT CONFIGURATION
# =============================================================================
@dataclass
class AlertConfig:
    """On-screen alerts for critical detections (zero-network, no webhooks)."""
    ENABLED: bool = True
    CRITICAL_THRESHOLD: float = 0.95
    HIGH_THRESHOLD: float = 0.85
    MAX_TOAST_DISPLAY: int = 10           # Max simultaneous toasts
    AUTO_DISMISS_SEC: int = 15            # Toast auto-dismiss
    SOUND_ENABLED: bool = False           # No audio in air-gapped
    PERSIST_ALERTS: bool = True           # Store alerts in DB


# =============================================================================
# V11: REPORT GENERATION CONFIGURATION
# =============================================================================
@dataclass
class ReportConfig:
    """Offline PDF/HTML report generation (no cloud dependencies)."""
    OUTPUT_DIR: str = "data/reports"
    BANK_NAME: str = "[Institution Name]"
    REGULATORY_BODY: str = "[Regulatory Authority]"
    REPORT_CLASSIFICATION: str = "CONFIDENTIAL — INTERNAL USE ONLY"
    INCLUDE_PII: bool = False             # Never include raw PII in reports
    MAX_CUSTOMERS_PER_REPORT: int = 500
    TEMPLATE_FORMAT: str = "html"          # html or pdf (requires weasyprint)
    RETENTION_DAYS: int = 365             # 1-year report retention


# =============================================================================
# V11: MODEL DRIFT MONITORING CONFIGURATION
# =============================================================================
@dataclass
class DriftConfig:
    """Track detection score distributions across runs."""
    ENABLED: bool = True
    MIN_RUNS_FOR_DRIFT: int = 3           # Need ≥3 runs to assess drift
    KS_TEST_ALPHA: float = 0.05           # Kolmogorov-Smirnov significance
    PSI_THRESHOLD: float = 0.20           # Population Stability Index warning
    STORE_DISTRIBUTIONS: bool = True      # Persist score distributions per run


# =============================================================================
# V14: WAITRESS WSGI SERVER CONFIGURATION
# =============================================================================
@dataclass
class WaitressConfig:
    """Waitress production WSGI server (pure Python, Windows-native)."""
    ENABLED: bool = True                  # Use Waitress instead of Flask dev server
    THREADS: int = 8                      # Worker threads per channel
    CONNECTION_LIMIT: int = 100           # Max simultaneous connections
    CHANNEL_TIMEOUT: int = 120            # Seconds before idle channel close
    RECV_BYTES: int = 8192                # Receive buffer size
    SEND_BYTES: int = 18000               # Send buffer size
    BACKLOG: int = 2048                   # TCP listen backlog
    EXPOSE_TRACEBACKS: bool = False       # Never expose tracebacks in production


# =============================================================================
# V14: WATCHDOG MONITORING CONFIGURATION
# =============================================================================
@dataclass
class WatchdogConfig:
    """Background thread for system resource monitoring."""
    ENABLED: bool = True
    CHECK_INTERVAL_SEC: int = 30          # How often to check system metrics
    MEMORY_WARN_PERCENT: float = 80.0     # Warn if memory > 80%
    MEMORY_CRITICAL_PERCENT: float = 90.0 # Critical if memory > 90%
    DISK_WARN_PERCENT: float = 85.0       # Warn if disk > 85%
    DISK_CRITICAL_PERCENT: float = 95.0   # Critical if disk > 95%
    DB_SIZE_WARN_MB: int = 500            # Warn if DB > 500MB
    CACHE_SIZE_WARN_MB: int = 200         # Warn if cache > 200MB
    MAX_METRICS_HISTORY: int = 1000       # Rolling window of metric points
    LOG_METRICS: bool = True              # Log metrics to audit trail


# =============================================================================
# V14: STRUCTURED LOGGING CONFIGURATION
# =============================================================================
@dataclass
class LoggingConfig:
    """Structured JSON logging for observability."""
    STRUCTURED_JSON: bool = True          # Enable JSON-formatted log lines
    LOG_LEVEL: str = "INFO"               # Global minimum log level
    INCLUDE_TIMESTAMP: bool = True
    INCLUDE_HOSTNAME: bool = True
    INCLUDE_PROCESS_ID: bool = True
    MAX_MESSAGE_LENGTH: int = 2000        # Truncate long messages
    ERROR_AGGREGATION: bool = True        # Aggregate repeated errors
    ERROR_AGG_WINDOW_SEC: int = 60        # Window for error dedup


# =============================================================================
# V14: HEALTH CHECK CONFIGURATION
# =============================================================================
@dataclass
class HealthConfig:
    """Health/readiness probe configuration."""
    ENABLED: bool = True
    HEALTH_PATH: str = "/health"           # Liveness probe
    READY_PATH: str = "/ready"             # Readiness probe
    INCLUDE_DETAILS: bool = True           # Return detailed health info
    DB_CHECK_TIMEOUT_SEC: int = 5          # Max time for DB health check


# =============================================================================
# V14: PIPELINE PROFILING CONFIGURATION
# =============================================================================
@dataclass
class ProfilingConfig:
    """cProfile-based pipeline profiling for performance analysis."""
    ENABLED: bool = False                 # Enable per-run profiling (toggle in config)
    OUTPUT_DIR: str = "data/profiles"      # Profile output directory
    TOP_N_FUNCTIONS: int = 30             # Show top N functions in summary
    CUMULATIVE_SORT: bool = True          # Sort by cumulative time


# =============================================================================
# V14: CIRCUIT BREAKER CONFIGURATION
# =============================================================================
@dataclass
class CircuitBreakerConfig:
    """Circuit breaker for pipeline layer fault tolerance."""
    ENABLED: bool = True
    FAILURE_THRESHOLD: int = 3            # Failures before opening circuit
    RECOVERY_TIMEOUT_SEC: int = 300       # Seconds before half-open retry
    HALF_OPEN_MAX_CALLS: int = 1          # Probing calls in half-open state
    EXCLUDE_FROM_ENSEMBLE: bool = True    # Exclude failed methods from ensemble


# =============================================================================
# V31: SCORING ENHANCEMENT CONFIG — Normalization → Fusion → Threshold
# =============================================================================
@dataclass
class ScoringConfig:
    """V31: Post-detection scoring pipeline (L13 enhancement).

    Three-step scoring: Normalize → Fuse → Threshold
    Each step supports multiple methods + Auto (best-practice default).

    Statistical rationale (PhD-level):
    - Normalization: Percentile Rank default — robust to heavy-tailed anomaly
      score distributions; no distributional assumptions; maps to [0,1]
      while preserving relative ordering.
    - Fusion: Family-Weighted Average default — prevents large families
      (e.g., 5 Statistical) from dominating smaller families (e.g., 1 DL);
      encodes AML domain expertise via hierarchical weights.
    - Threshold: Percentile-based default — adapts to score distribution;
      maps directly to investigation capacity (Top 0.2% ≈ 20/10K for
      same-day review).
    """

    # ── Step 1: Score Normalization (raw scores → [0,1]) ──
    NORMALIZATION_METHODS: list = field(default_factory=lambda: [
        "auto", "percentile_rank", "minmax", "zscore_sigmoid",
        "rank_transform", "robust_scale", "log_minmax",
    ])
    NORMALIZATION_DEFAULT: str = "auto"  # Auto = percentile_rank

    # ── Step 2: Score Fusion (N×M → N×1 ensemble) ──
    FUSION_METHODS: list = field(default_factory=lambda: [
        "auto", "simple_voting", "average", "weighted_average",
        "maximum", "family_weighted", "tiered_consensus",
        "borda_count", "family_then_algo", "rank_fusion",
    ])
    FUSION_DEFAULT: str = "auto"  # Auto = family_then_algo + tiered_consensus

    # ── Step 3: Threshold Calibration (score → tier) ──
    THRESHOLD_METHODS: list = field(default_factory=lambda: [
        "auto", "rule_based", "percentile_based", "borda_consensus",
    ])
    THRESHOLD_DEFAULT: str = "auto"  # Auto = percentile_based

    # ── Family Weights (AML domain-driven) ──
    FAMILY_WEIGHTS: Dict[str, float] = field(default_factory=lambda: {
        "Statistical":   2.5,   # Benford structuring = #1 AML priority
        "Tree":          2.0,   # Best overall for mixed banking data
        "Density":       1.5,   # LOF proven for fraud detection
        "Distance":      1.2,   # Good for isolated points
        "Clustering":    1.0,   # Finds accounts not fitting any segment
        "Graph":         2.5,   # CRITICAL for network/money mule detection
        "TimeSeries":    2.0,   # Behaviour change = key AML indicator
        "DeepLearning":  0.5,   # Experimental — lower until validated
    })

    # ── Per-Algorithm Weights (within family) ──
    ALGO_WEIGHTS: Dict[str, float] = field(default_factory=lambda: {
        # Statistical (family weight 2.5)
        "zscore": 1.0, "mad": 1.2, "iqr": 0.8, "grubbs": 0.9,
        "mahalanobis": 1.3, "benford": 2.0, "esd": 0.8, "dixon": 0.7,
        # Tree (family weight 2.0)
        "isolation_forest": 1.8, "extended_if": 1.5, "sciforest": 1.2,
        # Density (family weight 1.5)
        "lof": 1.5, "hbos": 1.0, "ecod": 1.0, "copod": 1.0,
        "dbscan": 1.0, "optics": 0.9, "hdbscan": 1.2, "cblof": 1.0,
        # Distance (family weight 1.2)
        "knn": 1.0, "kthnn": 1.0, "ldof": 1.1, "loop": 1.2,
        # Clustering (family weight 1.0)
        "gmm": 1.2, "hdbscan_cluster": 1.3, "kmeans_anomaly": 1.0,
        "spectral": 0.9, "birch": 0.8,
        # Graph (family weight 2.5)
        "pagerank": 1.3, "betweenness": 1.5, "community": 1.5,
        "centrality": 1.3, "hits": 1.2, "oddball": 1.3,
        # TimeSeries (family weight 2.0)
        "change_point": 1.5, "stl": 1.0, "matrix_profile": 1.2,
        "arima_residual": 1.0, "prophet": 0.8,
        # DeepLearning (family weight 0.5)
        "autoencoder": 0.8, "vae": 0.5, "lstm_ae": 0.5,
    })

    # ── Algorithm → Family mapping ──
    ALGO_FAMILY_MAP: Dict[str, str] = field(default_factory=lambda: {
        "zscore": "Statistical", "mad": "Statistical", "iqr": "Statistical",
        "grubbs": "Statistical", "mahalanobis": "Statistical", "benford": "Statistical",
        "esd": "Statistical", "dixon": "Statistical",
        "isolation_forest": "Tree", "extended_if": "Tree", "sciforest": "Tree",
        "lof": "Density", "hbos": "Density", "ecod": "Density", "copod": "Density",
        "dbscan": "Density", "optics": "Density", "hdbscan": "Density", "cblof": "Density",
        "knn": "Distance", "kthnn": "Distance", "ldof": "Distance", "loop": "Distance",
        "gmm": "Clustering", "hdbscan_cluster": "Clustering",
        "kmeans_anomaly": "Clustering", "spectral": "Clustering", "birch": "Clustering",
        "pagerank": "Graph", "betweenness": "Graph", "community": "Graph",
        "centrality": "Graph", "hits": "Graph", "oddball": "Graph",
        "change_point": "TimeSeries", "stl": "TimeSeries", "matrix_profile": "TimeSeries",
        "arima_residual": "TimeSeries", "prophet": "TimeSeries",
        "autoencoder": "DeepLearning", "vae": "DeepLearning", "lstm_ae": "DeepLearning",
    })

    # ── Tiered Threshold Config (percentile-based defaults) ──
    TIER_PERCENTILES: Dict[str, float] = field(default_factory=lambda: {
        "CRITICAL": 99.8,   # Top 0.2% → ~20 per 10K → same-day review
        "HIGH":     99.0,   # Top 1%   → ~80 per 10K → 72hr review
        "MEDIUM":   97.0,   # Top 3%   → ~300 per 10K → 7-day review
        "LOW":      90.0,   # Top 10%  → ~600 per 10K → 30-day monitoring
    })

    # ── Rule-based Threshold Config ──
    TIER_SCORE_THRESHOLDS: Dict[str, float] = field(default_factory=lambda: {
        "CRITICAL": 0.95,
        "HIGH":     0.75,
        "MEDIUM":   0.60,
        "LOW":      0.45,
    })

    # ── Tiered Vote Thresholds (% of methods agreeing) ──
    TIER_VOTE_PCTS: Dict[str, float] = field(default_factory=lambda: {
        "CRITICAL": 0.90,   # ≥90% methods flagged
        "HIGH":     0.70,   # ≥70%
        "MEDIUM":   0.50,   # ≥50%
        "LOW":      0.25,   # ≥25%
    })

    # ── Borda Consensus Config ──
    BORDA_MIN_FAMILIES: int = 3     # Must be top 0.5% in ≥3 families
    BORDA_TOP_PERCENTILE: float = 0.5  # Top 0.5% threshold within family

    # ── Flag threshold for binary voting ──
    FLAG_THRESHOLD: float = 0.5

    # ── Investigation capacity ──
    INVESTIGATION_CAPACITY: int = 1000


# =============================================================================
# V30: ALGORITHM EXECUTION CONFIG — L11 Detection (20 Algorithms, 8 Families)
# =============================================================================
@dataclass
class AlgoExecutionConfig:
    """V30: Algorithm Execution Pipeline configuration (L11 — Detection)."""
    DEFAULT_MODE: str = "auto"              # manual | auto | full
    CONTAMINATION: float = 0.05             # Expected anomaly % (0.01–0.30)
    SUOD_MIN_ALGOS: int = 3                 # Internal threshold to trigger SUOD
    TIMEOUT_PER_ALGO_S: int = 300           # Max seconds per single algorithm
    N_JOBS: int = -1                        # Parallelism (-1 = all cores)
    RANDOM_SEED: int = 42                   # Reproducibility seed
    PRIMARY_SCALER: str = "StandardScaler"  # Default scaler for routing
    # Output sub-dirs
    OUTPUT_ALGO_EXECUTION: str = "algo_execution"    # User-facing scores
    OUTPUT_ALGO_DETAILS: str = "algo_details"         # Per-algo detail CSVs
    OUTPUT_INTERNAL: str = "_internal"                # SUOD debug (never shown)
    OUTPUT_READY_FUSION: str = "ready_for_fusion"     # Input for L13 Ensemble


# =============================================================================
# V30: DQ PIPELINE CONFIGURATION — L02, L06–L10
# =============================================================================
@dataclass
class DQPipelineConfig:
    """V30: DQ → Encode → Transform → Scale → Reduce pipeline config (L06–L10)."""
    # L02: DQ Validation Gate
    DQ_PASS_THRESHOLD: float = 0.95       # ≥95% to proceed
    DQ_ALLOW_OVERRIDE: bool = True        # Allow user to override DQ gate with warning
    DQ_WEIGHTS: Dict[str, float] = field(default_factory=lambda: {
        "completeness": 0.25,
        "validity": 0.25,
        "consistency": 0.20,
        "timeliness": 0.15,
        "uniqueness": 0.15,
    })

    # L06: DQ Processing
    PII_PATTERNS: List[str] = field(default_factory=lambda: [
        "*phone*", "*email*", "*ssn*", "*name*", "*address*", "*dob*",
        "*birth*", "*passport*", "*license*",
    ])
    ID_PATTERNS: List[str] = field(default_factory=lambda: [
        "*_id", "*_key",
    ])
    HIGH_NULL_THRESHOLD: float = 0.95     # Drop columns with >95% nulls
    HIGH_CARDINALITY_LIMIT: int = 20      # Drop categorical with >20 unique
    CONSTANT_DROP: bool = True            # Drop zero-variance columns

    # L07: Encoding (Preprocessing)
    MISSING_DEFAULT: str = "ZERO"         # Default: replace with zero
    SKEW_THRESHOLD: float = 2.0           # LOG transform if skew > 2

    # L09: Scaling — 6 scaler types (must match scaling_engine.py constants)
    SCALER_TYPES: List[str] = field(default_factory=lambda: [
        "StandardScaler", "MinMaxScaler", "RobustScaler", "MaxAbsScaler", "PowerTransformer", "Original",
    ])

    # L08: Transformation — Conditional Transform Engine
    TRANSFORM_MODES: List[str] = field(default_factory=lambda: [
        "auto", "log", "power", "none",
    ])
    TRANSFORM_DEFAULT: str = "auto"        # Default: auto-detect via skewness

    # L10: Reduction — 9 paths (V28: added agent_decide)
    REDUCTION_PATHS: List[str] = field(default_factory=lambda: [
        "none", "mixed_pca", "famd", "umap_mixed", "umap_full",
        "sdae", "agent_quick", "agent_think", "agent_decide",
    ])
    FAMD_DEFAULT_DIMS: int = 50           # Default FAMD components
    UMAP_DEFAULT_DIMS: int = 30           # Default UMAP components
    SDAE_DEFAULT_DIMS: int = 50           # Default SDAE bottleneck
    PCA_VARIANCE_RATIO: float = 0.95      # Mixed PCA: 95% variance explained

    # Output paths (relative to DATA_VAULT)
    OUTPUT_DQ_VALIDATION: str = "dq_validation"
    OUTPUT_DQ_QUALITY: str = "quality"
    OUTPUT_PREPROCESSED: str = "preprocessed"
    OUTPUT_SCALED: str = "scaled"
    OUTPUT_REDUCED: str = "reduced"
    OUTPUT_PREMASTER: str = "premaster"


# =============================================================================
# INSTANTIATE CONFIGS
# =============================================================================
PATHS = PathConfig()
THEME = ThemeConfig()
PII = PIIConfig()
RESOURCES = ResourceConfig()
LAYERS = LayerConfig()
AUDIT = AuditConfig()
APP = AppConfig()
DATA_SOURCES = DataSourceConfig()
COLUMNS = ColumnRoleConfig()
DB = DatabaseConfig()
AUTH = AuthConfig()
TASKS = TaskConfig()
CRYPTO = CryptoConfig()
SCHEDULER = SchedulerConfig()
ALERTS = AlertConfig()
REPORTS = ReportConfig()
DRIFT = DriftConfig()
WAITRESS = WaitressConfig()
WATCHDOG = WatchdogConfig()
LOGGING = LoggingConfig()
HEALTH = HealthConfig()
PROFILING = ProfilingConfig()
CIRCUIT_BREAKER = CircuitBreakerConfig()
ALGO_EXECUTION = AlgoExecutionConfig()
DQ_PIPELINE = DQPipelineConfig()
SCORING = ScoringConfig()


# =============================================================================
# V14: TOML CONFIG OVERRIDE — config.toml overrides defaults
# Python 3.11 has built-in tomllib (no external dependency)
# =============================================================================
def _apply_toml_overrides():
    """Load config.toml if present and override dataclass defaults."""
    toml_path = PATHS.BASE / "config.toml"
    if not toml_path.exists():
        return
    try:
        import tomllib
        with open(toml_path, "rb") as f:
            overrides = tomllib.load(f)
        # Map TOML sections to config instances
        _config_map = {
            "app": APP, "database": DB, "auth": AUTH, "resources": RESOURCES,
            "audit": AUDIT, "crypto": CRYPTO, "scheduler": SCHEDULER,
            "alerts": ALERTS, "reports": REPORTS, "drift": DRIFT,
            "waitress": WAITRESS, "watchdog": WATCHDOG, "logging": LOGGING,
            "health": HEALTH, "profiling": PROFILING, "circuit_breaker": CIRCUIT_BREAKER,
            "pii": PII, "theme": THEME, "paths": PATHS, "tasks": TASKS,
            "columns": COLUMNS, "algo_execution": ALGO_EXECUTION,
            "scoring": SCORING,
        }
        for section, cfg_instance in _config_map.items():
            if section in overrides:
                for key, value in overrides[section].items():
                    attr_name = key.upper()
                    if hasattr(cfg_instance, attr_name):
                        setattr(cfg_instance, attr_name, value)
        import logging as _log
        _log.getLogger("apurbadas.config").info(f"TOML overrides applied from {toml_path}")
    except Exception as exc:
        import logging as _log
        _log.getLogger("apurbadas.config").warning(f"TOML override failed: {type(exc).__name__}")

_apply_toml_overrides()
