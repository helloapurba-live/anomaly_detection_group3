"""
Project Vanguard 7-Layer Edition - Main Pipeline
=================================================
Orchestrates all 7 layers for end-to-end AML detection.

Author: Project Vanguard Team
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
from dataclasses import dataclass
from datetime import datetime
import json
import sys

sys.path.insert(0, str(Path(__file__).parent))

from config import PATHS, LAYERS, APP
from layers.l1_l2_ingestion import IngestPipeline, DataQualityReport
from layers.l3_feature_engineering import Layer3FeatureEngineering
from layers.l4_preprocessing import Layer4Preprocessing
from layers.l5_detection import Layer5Detection
from layers.l6_ensemble import Layer6Ensemble, EnsembleResult
from layers.l7_output import Layer7Output


@dataclass
class PipelineResult:
    """Complete pipeline execution result."""
    success: bool
    timestamp: str
    records_processed: int
    dq_score: float
    features_generated: int
    methods_run: int
    alerts_generated: int
    tier_distribution: Dict[str, int]
    execution_time_ms: float
    df_scored: Optional[pd.DataFrame]
    ensemble_result: Optional[EnsembleResult]


class VanguardPipeline:
    """
    Main 7-Layer Pipeline Orchestrator.
    
    Executes the full AML detection pipeline:
    Layer 1-2: Ingest + DQ
    Layer 3: Feature Engineering
    Layer 4: Preprocessing
    Layer 5: Detection (26 methods)
    Layer 6: Ensemble Fusion
    Layer 7: Output/Investigation
    """
    
    def __init__(self):
        # Initialize layers
        self.ingest = IngestPipeline()
        self.features = Layer3FeatureEngineering()
        self.preprocess = Layer4Preprocessing()
        self.detection = Layer5Detection()
        self.ensemble = Layer6Ensemble()
        self.output = Layer7Output()
        
        # State
        self.last_result: Optional[PipelineResult] = None
        self.df_processed: Optional[pd.DataFrame] = None
    
    def run(
        self,
        sources: Dict[str, pd.DataFrame],
        detection_methods: List[str] = None,
        ensemble_method: str = "weighted_average",
        id_columns: List[str] = None,
        customer_col: str = "customer_id",
        amount_col: str = "amount",
        timestamp_col: str = "timestamp"
    ) -> PipelineResult:
        """
        Execute full 7-layer pipeline.
        
        Args:
            sources: Dict of source_name -> DataFrame
            detection_methods: Methods to run (None = all 26)
            ensemble_method: Fusion method
            id_columns: Columns to exclude from analysis
            customer_col: Customer identifier column
            amount_col: Amount column
            timestamp_col: Timestamp column
            
        Returns:
            PipelineResult with scores and alerts
        """
        start_time = datetime.now()
        id_columns = id_columns or []
        
        try:
            # ============== LAYER 1-2: INGEST + DQ ==============
            print("[L1-2] Ingestion & Data Quality...")
            df, dq_report = self.ingest.run(sources)
            
            # ============== LAYER 3: FEATURE ENGINEERING ==============
            print("[L3] Feature Engineering...")
            df = self.features.engineer_features(
                df, 
                customer_col=customer_col,
                amount_col=amount_col,
                timestamp_col=timestamp_col
            )
            
            # ============== LAYER 4: PREPROCESSING ==============
            print("[L4] Preprocessing...")
            all_id_cols = id_columns + ['_source'] if '_source' in df.columns else id_columns
            matrices = self.preprocess.preprocess(df, id_columns=all_id_cols)
            
            # Use scaled matrix for detection
            X = matrices.get('scaled', matrices.get('raw'))
            
            # ============== LAYER 5: DETECTION ==============
            print(f"[L5] Detection ({len(detection_methods or LAYERS.DETECTION_METHODS.keys())} methods)...")
            if detection_methods is None:
                detection_methods = []
                for methods in LAYERS.DETECTION_METHODS.values():
                    detection_methods.extend(methods)
            
            results = self.detection.detect_all(X, methods=detection_methods)
            score_matrix, method_names = self.detection.get_score_matrix()
            
            # ============== LAYER 6: ENSEMBLE ==============
            print("[L6] Ensemble Fusion...")
            self.ensemble.method = ensemble_method
            ensemble_result = self.ensemble.fuse(score_matrix, method_names)
            
            # ============== LAYER 7: OUTPUT ==============
            print("[L7] Output Generation...")
            output_summary = self.output.process(
                df,
                ensemble_result.final_scores,
                ensemble_result.risk_tiers,
                score_matrix,
                method_names
            )
            
            # ============== CREATE SCORED DATAFRAME ==============
            df_scored = df.copy()
            df_scored['anomaly_score'] = ensemble_result.final_scores
            df_scored['risk_tier'] = ensemble_result.risk_tiers
            
            # Add individual method scores
            for i, method in enumerate(method_names):
                df_scored[f'score_{method}'] = score_matrix[:, i]
            
            self.df_processed = df_scored
            
            # Calculate execution time
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            # Create result
            self.last_result = PipelineResult(
                success=True,
                timestamp=start_time.isoformat(),
                records_processed=len(df),
                dq_score=dq_report.overall_score,
                features_generated=len(self.features.feature_columns),
                methods_run=len(method_names),
                alerts_generated=output_summary['alerts_generated'],
                tier_distribution=ensemble_result.tier_counts,
                execution_time_ms=execution_time,
                df_scored=df_scored,
                ensemble_result=ensemble_result
            )
            
            print(f"\n✅ Pipeline complete in {execution_time:.0f}ms")
            print(f"   Records: {len(df):,}")
            print(f"   Alerts: {output_summary['alerts_generated']:,}")
            
            return self.last_result
            
        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            return PipelineResult(
                success=False,
                timestamp=start_time.isoformat(),
                records_processed=0,
                dq_score=0.0,
                features_generated=0,
                methods_run=0,
                alerts_generated=0,
                tier_distribution={},
                execution_time_ms=execution_time,
                df_scored=None,
                ensemble_result=None
            )
    
    def run_single_source(
        self,
        df: pd.DataFrame,
        source_name: str = "transactions",
        **kwargs
    ) -> PipelineResult:
        """Convenience method for single source."""
        return self.run({source_name: df}, **kwargs)
    
    def get_alerts(
        self, 
        tier: str = None, 
        limit: int = 100
    ) -> List[Dict]:
        """Get generated alerts."""
        alerts = self.output.queue.get_queue(tier=tier)[:limit]
        return [
            {
                "alert_id": a.alert_id,
                "record_index": a.record_index,
                "risk_score": a.risk_score,
                "risk_tier": a.risk_tier,
                "status": a.status,
                "narrative": a.narrative
            }
            for a in alerts
        ]
    
    def get_layer_summaries(self) -> Dict:
        """Get summary from each layer."""
        return {
            "layer_1_2": self.ingest.ingestion.get_summary() if hasattr(self.ingest, 'ingestion') else {},
            "layer_3": self.features.get_feature_summary(),
            "layer_4": self.preprocess.get_summary(),
            "layer_5": self.detection.get_summary(),
            "layer_6": self.ensemble.get_summary(self.last_result.ensemble_result) if self.last_result else {},
            "layer_7": {
                "queue": self.output.queue.get_summary(),
                "audit": self.output.audit.get_summary()
            }
        }
    
    def save_results(self, path: Path = None):
        """Save scored results to parquet."""
        if self.df_processed is None:
            return None
        
        path = path or PATHS.DATA_VAULT / "scored.parquet"
        self.df_processed.to_parquet(path, index=False)
        return path
    
    def export_alerts_excel(self, path: Path = None):
        """Export alerts to Excel."""
        if not self.output.queue.alerts:
            return None
        
        path = path or PATHS.EXPORTS / f"alerts_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        
        alerts_data = []
        for a in self.output.queue.alerts.values():
            alerts_data.append({
                "Alert ID": a.alert_id,
                "Record Index": a.record_index,
                "Risk Score": a.risk_score,
                "Risk Tier": a.risk_tier,
                "Status": a.status,
                "Created": a.created_at,
                "Top Method 1": a.top_contributors[0]['method'] if a.top_contributors else "",
                "Top Method 1 Score": a.top_contributors[0]['score'] if a.top_contributors else 0
            })
        
        df_alerts = pd.DataFrame(alerts_data)
        df_alerts.to_excel(path, index=False)
        
        return path


# Quick run function
def run_pipeline(df: pd.DataFrame, **kwargs) -> PipelineResult:
    """Quick run of the full pipeline."""
    pipeline = VanguardPipeline()
    return pipeline.run_single_source(df, **kwargs)
