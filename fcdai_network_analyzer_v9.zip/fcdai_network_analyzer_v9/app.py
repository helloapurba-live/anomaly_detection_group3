"""
FCDAI Network Analyzer v9 — Main Application
================================================
Business Logic: Premium multi-page Dash application for AML network analytics.
v9: Memory-efficient (gc.collect, float32), 10 customers default,
    Generate Sample Data button, professional family names, 5-theme switcher.
    Integrated pipeline control, live progress, 17 pages. Port 8079.
"""

import dash
from dash import html, dcc, page_registry, page_container, Input, Output, callback, clientside_callback
import dash_mantine_components as dmc
import dash_bootstrap_components as dbc
from dash_iconify import DashIconify
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent))
from config import APP, THEME, PATHS


# =============================================================================
# DASH APPLICATION
# =============================================================================
app = dash.Dash(
    __name__,
    use_pages=True,
    pages_folder="pages",
    suppress_callback_exceptions=True,
    assets_folder="assets",
    serve_locally=True,
    title=APP.TITLE,
    update_title=None,
    external_stylesheets=[dbc.themes.DARKLY],
)


def nav_link(icon, label, href, color=None):
    return dmc.NavLink(
        label=label, href=href,
        leftSection=DashIconify(icon=icon, width=20, color=color),
        active="exact",
        style={"borderRadius": "6px", "marginBottom": "2px"},
        variant="light",
    )


# =============================================================================
# THEME SWITCHER DATA
# =============================================================================
THEMES = [
    {"value": "midnight", "label": "🌊 Midnight Ocean"},
    {"value": "emerald",  "label": "🌿 Emerald Matrix"},
    {"value": "ember",    "label": "🔥 Ember Glow"},
    {"value": "amethyst", "label": "💎 Royal Amethyst"},
    {"value": "arctic",   "label": "🧊 Arctic Frost"},
]


# =============================================================================
# SIDEBAR
# =============================================================================
sidebar = dmc.Paper(
    [
        # Logo
        dmc.Group([
            dmc.ThemeIcon(
                DashIconify(icon="mdi:shield-search", width=30),
                size="xl", radius="md", variant="gradient",
                gradient={"from": "cyan", "to": "indigo"},
            ),
            dmc.Stack([
                dmc.Text("FCDAI", size="lg", fw=800, c="white",
                         style={"letterSpacing": "1px"}),
                dmc.Text("Network Analyzer v9", size="xs", c="dimmed",
                         style={"letterSpacing": "0.5px"}),
            ], gap=0),
        ], gap="sm", px="md", py="lg"),

        dmc.Divider(color=THEME.DARK_BORDER),

        # Operations
        dmc.Stack([
            dmc.Text("OPERATIONS", size="xs", c="dimmed", fw=600, px="md", pt="md",
                     style={"letterSpacing": "1px", "fontSize": "10px"}),
            nav_link("mdi:view-dashboard-outline", "Dashboard", "/"),
            nav_link("mdi:database-import-outline", "Port Authority", "/port-authority",
                     color=THEME.INFO),
            nav_link("mdi:radar", "The Radar", "/radar", color=THEME.SUCCESS),
            nav_link("mdi:chart-box-outline", "Visualization", "/visualization",
                     color="#E040FB"),
            nav_link("mdi:safe-square-outline", "The Vault", "/vault",
                     color=THEME.SECONDARY),
            nav_link("mdi:shield-alert-outline", "Command Center", "/command-center",
                     color=THEME.DANGER),
        ], gap=2, px="sm"),

        dmc.Divider(color=THEME.DARK_BORDER, my="xs"),

        # Intelligence
        dmc.Stack([
            dmc.Text("INTELLIGENCE", size="xs", c="dimmed", fw=600, px="md",
                     style={"letterSpacing": "1px", "fontSize": "10px"}),
            nav_link("mdi:graph", "Network Intelligence", "/network-intelligence",
                     color="#00D4FF"),
            nav_link("mdi:account-group-outline", "Lobby Analysis", "/lobby-analysis",
                     color="#FF1744"),
        ], gap=2, px="sm"),

        dmc.Divider(color=THEME.DARK_BORDER, my="xs"),

        # v9: Professional Analytics Family Names
        dmc.Stack([
            dmc.Text("ANALYTICS ENGINE", size="xs", c="dimmed", fw=600, px="md",
                     style={"letterSpacing": "1px", "fontSize": "10px"}),
            nav_link("mdi:star-four-points", "Network Influence Hub",
                     "/analytics/centrality", color="#00D4FF"),
            nav_link("mdi:account-group", "Topological Cluster Engine",
                     "/analytics/community", color="#9D4EDD"),
            nav_link("mdi:transit-connection-variant", "Laundering Traceability",
                     "/analytics/pathflow", color="#FF6B6B"),
            nav_link("mdi:link-variant", "Hidden Association Predictor",
                     "/analytics/link-prediction", color="#FFD600"),
            nav_link("mdi:alert-decagram", "Topological Outlier Detector",
                     "/analytics/anomaly", color="#FF9800"),
            nav_link("mdi:clock-fast", "Dynamic Velocity Analyzer",
                     "/analytics/temporal", color="#00E676"),
            nav_link("mdi:layers-triple", "Multi-Layer Module",
                     "/analytics/multi-layer", color="#2196F3"),
        ], gap=2, px="sm"),

        dmc.Divider(color=THEME.DARK_BORDER, my="xs"),

        # Data & History
        dmc.Stack([
            dmc.Text("DATA & HISTORY", size="xs", c="dimmed", fw=600, px="md",
                     style={"letterSpacing": "1px", "fontSize": "10px"}),
            nav_link("mdi:history", "Pipeline Runs", "/pipeline-runs",
                     color="#26C6DA"),
            nav_link("mdi:database-search-outline", "Database", "/database",
                     color="#AB47BC"),
        ], gap=2, px="sm"),

        # Spacer
        dmc.Space(style={"flex": "1"}),

        # v9: Theme Switcher
        dmc.Paper([
            dmc.Stack([
                dmc.Text("THEME", size="xs", c="dimmed", fw=600,
                         style={"letterSpacing": "1px", "fontSize": "10px"}),
                dmc.Select(
                    id="theme-selector",
                    data=THEMES,
                    value="midnight",
                    size="xs",
                    allowDeselect=False,
                    styles={
                        "input": {
                            "backgroundColor": "rgba(0,0,0,0.3)",
                            "border": "1px solid rgba(255,255,255,0.1)",
                            "color": "white",
                            "fontSize": "12px",
                        },
                        "dropdown": {
                            "backgroundColor": "#111827",
                            "border": "1px solid rgba(255,255,255,0.1)",
                        },
                        "option": {
                            "color": "white",
                            "fontSize": "12px",
                        },
                    },
                ),
            ], gap=4),
        ], p="sm", mx="sm", mb="xs", radius="md",
           className="theme-selector",
           style={"backgroundColor": "rgba(0,0,0,0.2)",
                  "border": "1px solid rgba(255,255,255,0.05)"}),

        # Version only
        dmc.Text(f"v{APP.VERSION}", size="xs", c="dimmed", ta="center", mb="sm"),
    ],
    style={
        "width": "260px", "height": "100vh", "position": "fixed",
        "top": 0, "left": 0,
        "background": f"linear-gradient(180deg, {THEME.DARK_BG} 0%, {THEME.DARK_BG_CARD} 100%)",
        "borderRight": f"1px solid {THEME.DARK_BORDER}",
        "overflowY": "auto", "display": "flex", "flexDirection": "column",
        "zIndex": 100,
    },
    radius=0, className="sidebar",
)


# =============================================================================
# MAIN LAYOUT
# =============================================================================
app.layout = dmc.MantineProvider(
    [
        # Shared stores
        dcc.Store(id="pipeline-state", storage_type="session"),
        dcc.Store(id="upload-state", storage_type="session"),
        dcc.Store(id="data-readiness-state", storage_type="session"),
        dcc.Store(id="theme-store", storage_type="local", data="midnight"),
        dmc.Box([
            sidebar,
            dmc.Box(
                [page_container],
                style={
                    "marginLeft": "260px", "padding": "24px",
                    "minHeight": "100vh", "backgroundColor": THEME.DARK_BG,
                },
                className="main-content",
            ),
        ]),
    ],
    forceColorScheme="dark",
)

server = app.server


# =============================================================================
# v9: THEME SWITCHER — Clientside callback (instant, no server round-trip)
# =============================================================================
clientside_callback(
    """
    function(theme) {
        if (theme) {
            document.body.setAttribute('data-theme', theme);
        }
        return theme;
    }
    """,
    Output("theme-store", "data"),
    Input("theme-selector", "value"),
)

# Apply saved theme on page load
clientside_callback(
    """
    function(savedTheme) {
        if (savedTheme) {
            document.body.setAttribute('data-theme', savedTheme);
            // Also set the selector to the saved theme
            var selector = document.getElementById('theme-selector');
            if (selector) {
                // Mantine handles this via the value prop
            }
        }
        return savedTheme || 'midnight';
    }
    """,
    Output("theme-selector", "value"),
    Input("theme-store", "data"),
)


# =============================================================================
# STARTUP
# =============================================================================
def _startup():
    from engine import get_pipeline
    pipeline = get_pipeline()

    loaded = pipeline.load_last_run()
    if loaded and pipeline.has_data():
        meta = pipeline.last_run_meta
        print(f"  Loaded run #{meta.get('run_id', '?')}: "
              f"{meta.get('customers', 0)} customers")
        return

    # No auto-run — user controls pipeline from Dashboard
    print("  No previous run found. Use Dashboard to start pipeline.")
    print("  Default: 10 customers (adjustable in Dashboard config)")


if __name__ == "__main__":
    print("")
    print("=" * 60)
    print("  FCDAI NETWORK ANALYZER v9 — MEMORY EFFICIENT")
    print("  Financial Crime Detection & AI")
    print("  gc.collect | float32 | MinHash LSH | 5 Themes")
    print("=" * 60)
    print(f"  Server: http://{APP.HOST}:{APP.PORT}")
    print(f"  Database: {PATHS.DB_PATH}")
    print("=" * 60)
    print("")

    _startup()

    print("")
    print(f"  Ready at http://{APP.HOST}:{APP.PORT}")
    print("  Press Ctrl+C to stop")
    print("")

    app.run(debug=APP.DEBUG, host=APP.HOST, port=APP.PORT)
