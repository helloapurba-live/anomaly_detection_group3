"""
Layer 2: Customer-Level Aggregation — V9 BULLETPROOF
=====================================
v9: Handles missing columns, empty tables, 0-row DataFrames.
Skips any column that doesn't exist instead of crashing.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PIPELINE
from utils.logger import log_audit, log_data_transform
from utils.persistence import store_or_load


class AggregateLayer:
    """v9: Fully defensive aggregation. Skips missing columns, handles empty tables."""

    def __init__(self):
        self.customer_features: Optional[pd.DataFrame] = None
        self.edges: Optional[pd.DataFrame] = None
        self.account_map: Dict[str, str] = {}

    def run(self, tables: Dict[str, pd.DataFrame]) -> Tuple[pd.DataFrame, pd.DataFrame]:
        log_audit("AGGREGATE_START", f"Aggregating {len(tables)} tables")

        self._build_account_map(tables)
        self.customer_features = self._aggregate_customer_features(tables)
        self.edges = self._extract_edges(tables)

        try:
            store_or_load("stage2_customer_features", self.customer_features)
            store_or_load("stage2_edges", self.edges)
        except Exception:
            pass  # v9: never crash on persistence

        log_audit("AGGREGATE_COMPLETE",
                  f"Customers: {len(self.customer_features)}, Edges: {len(self.edges)}")
        return self.customer_features, self.edges

    def _build_account_map(self, tables: Dict[str, pd.DataFrame]):
        if "account" in tables and tables["account"] is not None:
            acct_df = tables["account"]
            if "account_id" in acct_df.columns and "customer_id" in acct_df.columns:
                try:
                    self.account_map = dict(zip(
                        acct_df["account_id"].astype(str),
                        acct_df["customer_id"].astype(str)
                    ))
                except Exception:
                    pass

    def _aggregate_customer_features(self, tables: Dict[str, pd.DataFrame]) -> pd.DataFrame:
        # Start with customer base
        if "customer" in tables and tables["customer"] is not None and len(tables["customer"]) > 0:
            base = tables["customer"].copy()
        else:
            # Infer customer list from any table that has customer_id
            all_custs = set()
            for name, df in tables.items():
                if df is not None and "customer_id" in df.columns:
                    all_custs.update(df["customer_id"].dropna().unique())
            if not all_custs:
                return pd.DataFrame({"customer_id": []})
            base = pd.DataFrame({"customer_id": list(all_custs)})

        cid = PIPELINE.CUSTOMER_ID_COL

        # v9: Ensure cid column exists
        if cid not in base.columns:
            return base

        # Merge KYC features (v9: skip if missing columns)
        if "kyc" in tables and tables["kyc"] is not None and len(tables["kyc"]) > 0:
            try:
                kyc = tables["kyc"]
                if cid in kyc.columns:
                    kyc_cols = [c for c in kyc.columns if c != cid]
                    kyc_dedup = kyc.drop_duplicates(subset=[cid], keep="last")
                    base = base.merge(kyc_dedup[[cid] + kyc_cols], on=cid, how="left")
            except Exception:
                pass

        # Aggregate transaction features (v9: check every column before using)
        if "transaction" in tables and tables["transaction"] is not None and len(tables["transaction"]) > 0:
            try:
                txn = tables["transaction"]
                if cid in txn.columns:
                    agg_dict = {}
                    # Count transactions
                    first_col = txn.columns[0]
                    agg_dict["txn_count"] = (first_col, "count")

                    if PIPELINE.AMOUNT_COL in txn.columns:
                        agg_dict["txn_total_amount"] = (PIPELINE.AMOUNT_COL, "sum")
                        agg_dict["txn_avg_amount"] = (PIPELINE.AMOUNT_COL, "mean")
                        agg_dict["txn_max_amount"] = (PIPELINE.AMOUNT_COL, "max")
                        agg_dict["txn_std_amount"] = (PIPELINE.AMOUNT_COL, "std")

                    txn_agg = txn.groupby(cid).agg(**agg_dict).reset_index()
                    if "txn_std_amount" in txn_agg.columns:
                        txn_agg["txn_std_amount"] = txn_agg["txn_std_amount"].fillna(0)

                    # Count unique counterparties (v9: only if column exists)
                    if "counterparty_id" in txn.columns:
                        try:
                            cp_count = txn.groupby(cid)["counterparty_id"].nunique().reset_index()
                            cp_count.columns = [cid, "unique_counterparties"]
                            txn_agg = txn_agg.merge(cp_count, on=cid, how="left")
                        except Exception:
                            pass

                    # Count international txns (v9: only if column exists)
                    if "is_international" in txn.columns:
                        try:
                            intl = txn.groupby(cid)["is_international"].sum().reset_index()
                            intl.columns = [cid, "intl_txn_count"]
                            txn_agg = txn_agg.merge(intl, on=cid, how="left")
                        except Exception:
                            pass

                    base = base.merge(txn_agg, on=cid, how="left")
            except Exception:
                pass

        # Aggregate alert features (v9: defensive)
        if "alert" in tables and tables["alert"] is not None and len(tables["alert"]) > 0:
            try:
                alerts = tables["alert"]
                if cid in alerts.columns:
                    first_col = alerts.columns[0]
                    alert_agg = alerts.groupby(cid).agg(
                        alert_count=(first_col, "count")
                    ).reset_index()
                    if "severity" in alerts.columns:
                        try:
                            sev = alerts.groupby(cid)["severity"].apply(
                                lambda x: (x.isin(["high", "critical"])).sum()
                            ).reset_index()
                            sev.columns = [cid, "high_severity_alerts"]
                            alert_agg = alert_agg.merge(sev, on=cid, how="left")
                        except Exception:
                            pass
                    base = base.merge(alert_agg, on=cid, how="left")
            except Exception:
                pass

        # Aggregate historical features (v9: defensive)
        if "historical" in tables and tables["historical"] is not None and len(tables["historical"]) > 0:
            try:
                hist = tables["historical"]
                if cid in hist.columns:
                    first_col = hist.columns[0]
                    hist_agg = hist.groupby(cid).agg(
                        historical_events=(first_col, "count")
                    ).reset_index()
                    if "outcome" in hist.columns:
                        try:
                            tp = hist.groupby(cid)["outcome"].apply(
                                lambda x: (x == "TP").sum()
                            ).reset_index()
                            tp.columns = [cid, "true_positive_history"]
                            hist_agg = hist_agg.merge(tp, on=cid, how="left")
                        except Exception:
                            pass
                    base = base.merge(hist_agg, on=cid, how="left")
            except Exception:
                pass

        # Fill NaN aggregates with 0
        try:
            numeric_cols = base.select_dtypes(include=[np.number]).columns
            base[numeric_cols] = base[numeric_cols].fillna(0)
        except Exception:
            pass

        log_data_transform("CUSTOMER_AGGREGATE",
                          (sum(len(df) for df in tables.values() if df is not None),
                           sum(len(df.columns) for df in tables.values() if df is not None)),
                          base.shape)
        return base

    def _extract_edges(self, tables: Dict[str, pd.DataFrame]) -> pd.DataFrame:
        edges = []
        cid = PIPELINE.CUSTOMER_ID_COL

        # Transaction edges (v9: check every column)
        if "transaction" in tables and tables["transaction"] is not None and len(tables["transaction"]) > 0:
            try:
                txn = tables["transaction"]
                if cid in txn.columns and "counterparty_id" in txn.columns:
                    amount_col = PIPELINE.AMOUNT_COL if PIPELINE.AMOUNT_COL in txn.columns else None
                    if amount_col:
                        txn_edges = txn.groupby([cid, "counterparty_id"]).agg(
                            weight=(amount_col, "sum"),
                            txn_count=(amount_col, "count"),
                        ).reset_index()
                    else:
                        txn_edges = txn.groupby([cid, "counterparty_id"]).size().reset_index(name="weight")
                        txn_edges["txn_count"] = txn_edges["weight"]

                    txn_edges = txn_edges.rename(columns={cid: "source", "counterparty_id": "target"})
                    txn_edges["edge_type"] = "transaction"
                    edges.append(txn_edges)
            except Exception:
                pass

        # Relationship edges (v9: defensive)
        if "relationship" in tables and tables["relationship"] is not None and len(tables["relationship"]) > 0:
            try:
                rel = tables["relationship"]
                if "source_id" in rel.columns and "target_id" in rel.columns:
                    rel_edges = rel.rename(columns={
                        "source_id": "source", "target_id": "target",
                        "strength": "weight"
                    })
                    if "weight" not in rel_edges.columns:
                        rel_edges["weight"] = 1.0
                    rel_edges["edge_type"] = rel_edges.get("relationship_type", "relationship")
                    rel_edges["txn_count"] = 0
                    edges.append(rel_edges[["source", "target", "weight", "txn_count", "edge_type"]])
            except Exception:
                pass

        if edges:
            try:
                all_edges = pd.concat(edges, ignore_index=True)
                all_edges = all_edges[all_edges["source"] != all_edges["target"]]
                log_audit("AGGREGATE_EDGES", f"{len(all_edges)} edges extracted")
                return all_edges
            except Exception:
                pass

        return pd.DataFrame(columns=["source", "target", "weight", "txn_count", "edge_type"])

    def get_summary(self) -> Dict:
        return {
            "customers": len(self.customer_features) if self.customer_features is not None else 0,
            "edges": len(self.edges) if self.edges is not None else 0,
            "features": len(self.customer_features.columns) if self.customer_features is not None else 0,
            "account_map_size": len(self.account_map),
        }
