"""
Layer 6: Risk Scoring — V9 BULLETPROOF
======================
v9: Handles empty analytics, float32/int32, missing families, 0-node results.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PIPELINE
from utils.logger import log_audit, log_data_transform
from utils.persistence import store_or_load


class ScoringLayer:
    """v9: Fully defensive scoring. Handles empty analytics, missing families, float32."""

    def __init__(self):
        self.weights = PIPELINE.RISK_WEIGHTS
        self.tiers = PIPELINE.RISK_TIERS
        self.scored_df: Optional[pd.DataFrame] = None

    def score(
        self,
        analytics_results: Dict[str, pd.DataFrame],
        weights: Dict[str, float] = None
    ) -> pd.DataFrame:
        weights = weights or self.weights
        log_audit("SCORING_START", f"Using weights: {weights}")

        # v9: Handle empty analytics
        if not analytics_results:
            log_audit("SCORING_SKIP", "No analytics results — returning empty")
            return pd.DataFrame(columns=["node_id", "risk_score", "risk_tier"])

        # Get common node list (v9: try all families until we find one with nodes)
        nodes = None
        for df in analytics_results.values():
            if df is not None and "node_id" in df.columns and len(df) > 0:
                nodes = df["node_id"].tolist()
                break

        if not nodes:
            return pd.DataFrame(columns=["node_id", "risk_score", "risk_tier"])

        result = pd.DataFrame({"node_id": nodes})

        # Compute family-level aggregate scores
        family_scores = {}
        for family_name, df in analytics_results.items():
            try:
                if df is None or "node_id" not in df.columns or len(df) == 0:
                    continue

                # v9: Accept float32, float64, int32, int64
                numeric_cols = [c for c in df.columns
                               if c != "node_id" and df[c].dtype in [
                                   np.float64, np.float32, np.int64, np.int32, float, int]]

                if not numeric_cols:
                    continue

                vals = df[numeric_cols].values.astype(float)
                vals = np.nan_to_num(vals, nan=0)

                # Normalize each column to [0, 1]
                for i in range(vals.shape[1]):
                    col_min = vals[:, i].min()
                    col_max = vals[:, i].max()
                    if col_max - col_min > 0:
                        vals[:, i] = (vals[:, i] - col_min) / (col_max - col_min)

                family_score = vals.mean(axis=1)
                family_scores[family_name] = family_score
                result[f"score_{family_name}"] = family_score
            except Exception:
                continue  # v9: skip broken families

        # Weighted combination
        if family_scores:
            total_weight = 0
            weighted_sum = np.zeros(len(nodes))

            for family_name, scores in family_scores.items():
                w = weights.get(family_name, 0.1)
                weighted_sum += scores * w
                total_weight += w

            if total_weight > 0:
                raw_score = weighted_sum / total_weight
            else:
                raw_score = weighted_sum

            result["risk_score"] = np.clip(raw_score * 100, 0, 100).round(1)
        else:
            result["risk_score"] = 0.0

        # Assign risk tiers
        result["risk_tier"] = result["risk_score"].apply(self._assign_tier)

        # Tier counts
        try:
            tier_counts = result["risk_tier"].value_counts().to_dict()
            log_audit("SCORING_COMPLETE",
                      f"Scored {len(result)} nodes | Tiers: {tier_counts}")
        except Exception:
            log_audit("SCORING_COMPLETE", f"Scored {len(result)} nodes")

        self.scored_df = result
        try:
            store_or_load("stage6_scored", result)
        except Exception:
            pass

        return result

    def _assign_tier(self, score: float) -> str:
        try:
            for tier, bounds in self.tiers.items():
                low, high = bounds
                if low <= score <= high:
                    return tier
        except Exception:
            pass
        return "P4"

    def get_tier_distribution(self) -> Dict[str, int]:
        if self.scored_df is None:
            return {}
        try:
            return self.scored_df["risk_tier"].value_counts().to_dict()
        except Exception:
            return {}

    def get_high_risk_customers(self, tiers: List[str] = None) -> pd.DataFrame:
        if self.scored_df is None:
            return pd.DataFrame()
        tiers = tiers or ["P1", "P2"]
        try:
            return self.scored_df[self.scored_df["risk_tier"].isin(tiers)].copy()
        except Exception:
            return pd.DataFrame()

    def get_summary(self) -> Dict:
        if self.scored_df is None or len(self.scored_df) == 0:
            return {"status": "Not scored", "total_scored": 0}
        try:
            return {
                "total_scored": len(self.scored_df),
                "avg_score": float(self.scored_df["risk_score"].mean()),
                "max_score": float(self.scored_df["risk_score"].max()),
                "tier_distribution": self.get_tier_distribution(),
            }
        except Exception:
            return {"total_scored": len(self.scored_df)}
