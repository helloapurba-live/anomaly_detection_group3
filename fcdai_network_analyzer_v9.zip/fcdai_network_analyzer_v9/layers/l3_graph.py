"""
Layer 3: Graph Construction — V9 BULLETPROOF
=============================
v9: Handles 0 nodes, 0 edges, tiny graphs without crashing.
"""

import pandas as pd
import numpy as np
import networkx as nx
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import sys
import json

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PIPELINE
from utils.logger import log_audit, log_error
from utils.persistence import store_or_load


class GraphConstructionLayer:
    """v9: Fully defensive graph construction. Handles 0-node/0-edge case."""

    def __init__(self):
        self.graph: Optional[nx.DiGraph] = None
        self.node_count: int = 0
        self.edge_count: int = 0

    def build(
        self,
        customer_features: pd.DataFrame,
        edges: pd.DataFrame
    ) -> nx.DiGraph:
        log_audit("GRAPH_BUILD_START",
                  f"Nodes: {len(customer_features)}, Edges: {len(edges)}")

        G = nx.DiGraph()

        # v9: Handle empty customer features
        if customer_features is None or customer_features.empty:
            self.graph = G
            self.node_count = 0
            self.edge_count = 0
            log_audit("GRAPH_BUILD_COMPLETE", "Empty graph (no customers)")
            return G

        cid = PIPELINE.CUSTOMER_ID_COL
        if cid not in customer_features.columns:
            self.graph = G
            log_audit("GRAPH_BUILD_COMPLETE", f"No {cid} column found")
            return G

        # Add nodes with attributes
        for _, row in customer_features.iterrows():
            try:
                node_id = str(row[cid])
                attrs = {}
                for col in customer_features.columns:
                    if col != cid:
                        val = row[col]
                        if isinstance(val, (np.integer,)):
                            val = int(val)
                        elif isinstance(val, (np.floating,)):
                            val = float(val)
                        elif pd.isna(val):
                            val = None
                        attrs[col] = val
                G.add_node(node_id, **attrs)
            except Exception:
                continue  # v9: skip bad rows

        # Add edges (v9: handle empty/None edges)
        if edges is not None and not edges.empty:
            for _, row in edges.iterrows():
                try:
                    src = str(row.get("source", ""))
                    tgt = str(row.get("target", ""))
                    if not src or not tgt:
                        continue
                    if src in G.nodes and tgt in G.nodes:
                        weight = float(row.get("weight", 1.0)) if pd.notna(row.get("weight")) else 1.0
                        edge_type = str(row.get("edge_type", "transaction"))
                        txn_count = int(row.get("txn_count", 0)) if pd.notna(row.get("txn_count")) else 0

                        if G.has_edge(src, tgt):
                            G[src][tgt]["weight"] += weight
                            G[src][tgt]["txn_count"] += txn_count
                        else:
                            G.add_edge(src, tgt, weight=weight,
                                       edge_type=edge_type, txn_count=txn_count)
                except Exception:
                    continue

        # Limit to max nodes if needed
        max_nodes = PIPELINE.GRAPH_MAX_NODES
        if G.number_of_nodes() > max_nodes:
            try:
                degrees = sorted(G.degree(), key=lambda x: x[1], reverse=True)
                keep = set(n for n, d in degrees[:max_nodes])
                remove = set(G.nodes()) - keep
                G.remove_nodes_from(remove)
            except Exception:
                pass

        self.graph = G
        self.node_count = G.number_of_nodes()
        self.edge_count = G.number_of_edges()

        # Extract basic graph features
        if self.node_count > 0:
            self._add_basic_graph_features()

        log_audit("GRAPH_BUILD_COMPLETE",
                  f"Graph: {self.node_count} nodes, {self.edge_count} edges")

        return G

    def _add_basic_graph_features(self):
        G = self.graph
        if G is None or G.number_of_nodes() == 0:
            return

        for node in G.nodes():
            try:
                G.nodes[node]["in_degree"] = G.in_degree(node)
                G.nodes[node]["out_degree"] = G.out_degree(node)
                G.nodes[node]["total_degree"] = G.in_degree(node) + G.out_degree(node)
            except Exception:
                pass

        for node in G.nodes():
            try:
                in_flow = sum(G[u][node].get("weight", 0) for u in G.predecessors(node))
                out_flow = sum(G[node][v].get("weight", 0) for v in G.successors(node))
                G.nodes[node]["in_flow"] = in_flow
                G.nodes[node]["out_flow"] = out_flow
                G.nodes[node]["net_flow"] = in_flow - out_flow if isinstance(in_flow, (int, float)) else 0
            except Exception:
                G.nodes[node]["in_flow"] = 0
                G.nodes[node]["out_flow"] = 0
                G.nodes[node]["net_flow"] = 0

    def to_cytoscape_elements(self, max_nodes: int = 1000) -> List[Dict]:
        G = self.graph
        if G is None or G.number_of_nodes() == 0:
            return []

        elements = []

        try:
            if G.number_of_nodes() > max_nodes:
                degrees = sorted(G.degree(), key=lambda x: x[1], reverse=True)
                visible_nodes = set(n for n, d in degrees[:max_nodes])
            else:
                visible_nodes = set(G.nodes())

            for node in visible_nodes:
                try:
                    attrs = dict(G.nodes[node])
                    risk_score = attrs.get("risk_score", 0)
                    if risk_score is None or (isinstance(risk_score, float) and np.isnan(risk_score)):
                        risk_score = 0

                    if risk_score >= 80:
                        tier = "P1"
                    elif risk_score >= 60:
                        tier = "P2"
                    elif risk_score >= 40:
                        tier = "P3"
                    else:
                        tier = "P4"

                    elements.append({
                        "data": {
                            "id": node,
                            "label": attrs.get("name", node),
                            "risk_score": risk_score,
                            "tier": tier,
                            "degree": G.degree(node),
                            **{k: v for k, v in attrs.items()
                               if isinstance(v, (int, float, str, bool)) and v is not None}
                        },
                        "classes": tier,
                    })
                except Exception:
                    continue

            for src, tgt, data in G.edges(data=True):
                if src in visible_nodes and tgt in visible_nodes:
                    elements.append({
                        "data": {
                            "source": src, "target": tgt,
                            "weight": data.get("weight", 1),
                            "edge_type": data.get("edge_type", "transaction"),
                        }
                    })
        except Exception:
            pass

        return elements

    def get_node_details(self, node_id: str) -> Dict[str, Any]:
        G = self.graph
        if G is None or node_id not in G.nodes:
            return {"error": f"Node {node_id} not found"}
        try:
            attrs = dict(G.nodes[node_id])
            neighbors = list(G.predecessors(node_id)) + list(G.successors(node_id))
            return {
                "node_id": node_id,
                "attributes": {k: v for k, v in attrs.items() if v is not None},
                "in_degree": G.in_degree(node_id),
                "out_degree": G.out_degree(node_id),
                "total_degree": G.in_degree(node_id) + G.out_degree(node_id),
                "neighbor_count": len(set(neighbors)),
                "in_flow": attrs.get("in_flow", 0),
                "out_flow": attrs.get("out_flow", 0),
                "net_flow": attrs.get("net_flow", 0),
                "risk_score": attrs.get("risk_score", None),
            }
        except Exception:
            return {"error": f"Error reading node {node_id}"}

    def get_summary(self) -> Dict:
        G = self.graph
        if G is None or G.number_of_nodes() == 0:
            return {"status": "No graph built", "nodes": 0, "edges": 0}
        try:
            return {
                "nodes": G.number_of_nodes(),
                "edges": G.number_of_edges(),
                "density": nx.density(G),
                "avg_degree": np.mean([d for _, d in G.degree()]) if G.number_of_nodes() > 0 else 0,
                "components": nx.number_weakly_connected_components(G),
            }
        except Exception:
            return {"nodes": G.number_of_nodes(), "edges": G.number_of_edges()}
