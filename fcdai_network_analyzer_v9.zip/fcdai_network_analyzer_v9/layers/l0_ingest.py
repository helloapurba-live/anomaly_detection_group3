"""
Layer 0: Data Ingestion
========================
Business Logic: Loads data from 7 CSV/Parquet sources. Supports drag-and-drop
uploads via the Port Authority page or loading from the data/samples/ directory.
Uses the "store-or-load" pattern: new data is stored locally; if no new data
is provided, the last stored version is used.

Technical Implementation: Reads CSV/Parquet files into DataFrames. Validates
against Pydantic schemas. Logs every ingestion event to audit trail.
"""

import pandas as pd
from pathlib import Path
from typing import Dict, Optional, List, Tuple
from datetime import datetime
import sys
import io
import base64

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PATHS, PIPELINE
from utils.logger import log_audit, log_error, log_data_transform
from utils.persistence import store_or_load


class IngestLayer:
    """
    Business Logic: Stage 0 — Load and validate 7 DB tables. If user uploads
    new data, store it and use it. Otherwise, load sample or previously stored data.

    Technical Implementation: Handles CSV, Parquet, and base64-encoded uploads
    from Dash file upload component.
    """

    def __init__(self):
        self.tables: Dict[str, pd.DataFrame] = {}
        self.load_log: List[Dict] = []

    def load_from_directory(self, directory: Path = None) -> Dict[str, pd.DataFrame]:
        """
        Business Logic: Load all available CSVs from a directory.

        Args:
            directory: Path to directory containing CSV files. Defaults to data/samples/.

        Returns:
            Dict mapping table name to DataFrame.
        """
        directory = directory or PATHS.SAMPLES
        if not directory.exists():
            log_error(f"Data directory not found: {directory}")
            return {}

        for table_name in PIPELINE.EXPECTED_TABLES:
            csv_path = directory / f"{table_name}.csv"
            parquet_path = directory / f"{table_name}.parquet"

            if csv_path.exists():
                df = pd.read_csv(csv_path)
                self.tables[table_name] = df
                self._log_load(table_name, csv_path, df)
            elif parquet_path.exists():
                df = pd.read_parquet(parquet_path, engine="pyarrow")
                self.tables[table_name] = df
                self._log_load(table_name, parquet_path, df)

        # Store all loaded tables for future use
        for name, df in self.tables.items():
            store_or_load(f"raw_{name}", df)

        return self.tables

    def load_from_upload(self, filename: str, content: str) -> Tuple[str, pd.DataFrame]:
        """
        Business Logic: Process a file uploaded via the Port Authority page.

        Args:
            filename: Original filename
            content: Base64-encoded file content from Dash upload

        Returns:
            Tuple of (table_name, DataFrame)
        """
        # Decode base64 content
        content_type, content_string = content.split(",")
        decoded = base64.b64decode(content_string)

        # Determine table name from filename
        stem = Path(filename).stem.lower()
        table_name = stem
        for expected in PIPELINE.EXPECTED_TABLES:
            if expected in stem:
                table_name = expected
                break

        # Read based on extension
        if filename.endswith(".csv"):
            df = pd.read_csv(io.StringIO(decoded.decode("utf-8")))
        elif filename.endswith((".parquet", ".pq")):
            df = pd.read_parquet(io.BytesIO(decoded), engine="pyarrow")
        elif filename.endswith((".xlsx", ".xls")):
            df = pd.read_excel(io.BytesIO(decoded), engine="openpyxl")
        else:
            raise ValueError(f"Unsupported file type: {filename}")

        self.tables[table_name] = df
        store_or_load(f"raw_{table_name}", df)
        self._log_load(table_name, Path(filename), df)

        return table_name, df

    def load_or_generate(self) -> Dict[str, pd.DataFrame]:
        """
        Business Logic: Try to load from vault first, then from samples,
        then generate new sample data if nothing exists.

        Returns:
            Dict of table name -> DataFrame
        """
        # Try vault first
        all_found = True
        for table_name in PIPELINE.EXPECTED_TABLES:
            df = store_or_load(f"raw_{table_name}")
            if df is not None:
                self.tables[table_name] = df
            else:
                all_found = False

        if all_found and len(self.tables) >= 5:
            log_audit("INGEST", "Loaded all tables from vault")
            return self.tables

        # Try samples directory
        if (PATHS.SAMPLES / "customer.csv").exists():
            return self.load_from_directory(PATHS.SAMPLES)

        # Generate fresh sample data
        log_audit("INGEST", "No existing data found — generating samples")
        from utils.sample_data import generate_all_samples
        self.tables = generate_all_samples()

        for name, df in self.tables.items():
            store_or_load(f"raw_{name}", df)

        return self.tables

    def _log_load(self, name: str, path: Path, df: pd.DataFrame):
        """Log a data load event."""
        info = {
            "table": name,
            "source": str(path),
            "rows": len(df),
            "columns": len(df.columns),
            "timestamp": datetime.now().isoformat()
        }
        self.load_log.append(info)
        log_audit("INGEST_LOAD", f"{name}: {len(df)}r×{len(df.columns)}c from {path.name}")

    def get_summary(self) -> Dict:
        """Get ingestion summary."""
        return {
            "tables_loaded": len(self.tables),
            "total_rows": sum(len(df) for df in self.tables.values()),
            "details": {name: {"rows": len(df), "columns": len(df.columns)}
                        for name, df in self.tables.items()},
            "load_log": self.load_log,
        }
