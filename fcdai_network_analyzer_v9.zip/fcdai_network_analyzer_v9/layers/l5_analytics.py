"""
Layer 5: Network Analytics (7-Family Suite) — V9 MEMORY-EFFICIENT
===============================================================
v7: Maximum speed from same algorithm families via smarter alternatives.

Speed Upgrades vs v6:
  - Centrality:  Approx Betweenness (k=0.1n sampling) + PageRank early stop (niter=20)
  - Community:   igraph Leiden (already optimal from v6)
  - PathFlow:    K-Shortest Paths (top-k=5 per node, skip full BFS)
  - LinkPred:    MinHash LSH (datasketch) + vectorized ANN approximation
  - Anomaly:     PyOD ECOD (already optimal from v6)
  - Temporal:    NumPy vectorized (already optimal from v6)
  - MultiLayer:  NumPy vectorized (already optimal from v6)

Professional Family Names (display only, internal keys unchanged):
  centrality     → Network Influence Hub
  community      → Topological Cluster Engine
  pathflow       → Laundering Traceability Logic
  link_prediction→ Hidden Association Predictor
  anomaly        → Topological Outlier Detector
  temporal       → Dynamic Velocity Analyzer
  multi_layer    → Multi-Layer Module
"""

import pandas as pd
import numpy as np
import networkx as nx
from pathlib import Path
from typing import Dict, List, Optional, Any
from scipy import stats
import warnings
import sys
import time
import gc

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PIPELINE
from utils.logger import log_audit, log_error
from utils.persistence import store_or_load

warnings.filterwarnings("ignore")

# ---- Conditional fast imports ----
try:
    import igraph as ig
    HAS_IGRAPH = True
except ImportError:
    HAS_IGRAPH = False

try:
    from pyod.models.ecod import ECOD
    HAS_PYOD = True
except ImportError:
    HAS_PYOD = False

try:
    from sklearn.ensemble import IsolationForest
    from sklearn.neighbors import LocalOutlierFactor
    HAS_SKLEARN = True
except ImportError:
    HAS_SKLEARN = False

try:
    from datasketch import MinHash, MinHashLSH
    HAS_DATASKETCH = True
except ImportError:
    HAS_DATASKETCH = False


# Professional display names (internal keys stay the same for compatibility)
FAMILY_DISPLAY_NAMES = {
    "centrality": "Network Influence Hub",
    "community": "Topological Cluster Engine",
    "pathflow": "Laundering Traceability Logic",
    "link_prediction": "Hidden Association Predictor",
    "anomaly": "Topological Outlier Detector",
    "temporal": "Dynamic Velocity Analyzer",
    "multi_layer": "Multi-Layer Module",
}


def _nx_to_igraph(G: nx.DiGraph):
    """Convert NetworkX DiGraph to igraph for C-backend speed."""
    nodes = list(G.nodes())
    node_map = {n: i for i, n in enumerate(nodes)}
    edges = [(node_map[u], node_map[v]) for u, v in G.edges()
             if u in node_map and v in node_map]
    weights = [G[u][v].get("weight", G[u][v].get("amount", 1.0))
               for u, v in G.edges() if u in node_map and v in node_map]

    g = ig.Graph(n=len(nodes), edges=edges, directed=True)
    g.vs["name"] = nodes
    g.es["weight"] = weights

    for attr in ["in_flow", "out_flow", "txn_count", "in_degree", "out_degree",
                 "total_degree", "risk_score", "risk_tier", "edge_type"]:
        vals = [G.nodes[n].get(attr, 0) for n in nodes]
        g.vs[attr] = vals

    return g, nodes, node_map


class AnalyticsLayer:
    """
    v9 Memory-Efficient Analytics Engine.
    Uses approx algorithms + gc.collect flush between families + float32 quantization.
    - Approx Betweenness (sampling), PageRank early stop
    - K-Shortest Paths (top-k), MinHash LSH
    - PyOD ECOD, igraph Leiden, NumPy vectorized
    - gc.collect() between every family to free RAM
    - float32 for all numeric columns
    """

    def __init__(self):
        self.results: Dict[str, pd.DataFrame] = {}
        self.analytics_config = PIPELINE.ANALYTICS
        self._ig_graph = None
        self._ig_nodes = None
        self._ig_node_map = None

    def run_all(
        self,
        G: nx.DiGraph,
        params: Dict[str, Any] = None
    ) -> Dict[str, pd.DataFrame]:
        """Execute all 7 analytics families with ultra-speed algorithms."""
        params = params or {}

        # v9: Guard against empty/None graph
        if G is None or G.number_of_nodes() == 0:
            log_audit("ANALYTICS_SKIP", "Empty graph — returning empty results")
            empty = pd.DataFrame({"node_id": []})
            for name in ["centrality", "community", "pathflow", "link_prediction",
                          "anomaly", "temporal", "multi_layer"]:
                self.results[name] = empty.copy()
            return self.results

        engines = []
        if HAS_IGRAPH:
            engines.append("igraph")
        if HAS_DATASKETCH:
            engines.append("MinHash")
        if HAS_PYOD:
            engines.append("ECOD")
        engine_str = "+".join(engines) if engines else "networkx"

        log_audit("ANALYTICS_START",
                  f"Running 7 families on {G.number_of_nodes()} nodes "
                  f"[Engine: {engine_str}]")

        # Pre-build igraph once (v9: guard against conversion failure)
        if HAS_IGRAPH:
            try:
                t0 = time.time()
                self._ig_graph, self._ig_nodes, self._ig_node_map = _nx_to_igraph(G)
                log_audit("IGRAPH_BUILD",
                          f"Converted in {(time.time()-t0)*1000:.0f}ms "
                          f"({self._ig_graph.vcount()} nodes, {self._ig_graph.ecount()} edges)")
            except Exception as e:
                log_audit("IGRAPH_SKIP", f"igraph conversion failed: {e}")
                self._ig_graph = None

        families = [
            ("centrality", self._centrality),
            ("community", self._community),
            ("pathflow", self._pathflow),
            ("link_prediction", self._link_prediction),
            ("anomaly", self._anomaly),
            ("temporal", self._temporal),
            ("multi_layer", self._multi_layer),
        ]

        total_t0 = time.time()
        for name, func in families:
            try:
                t0 = time.time()
                family_params = {**self.analytics_config.get(name, {}),
                                 **params.get(name, {})}
                df = func(G, family_params)

                # v9: Quantize all float64 → float32 to save 50% RAM
                for col in df.select_dtypes(include=['float64']).columns:
                    df[col] = df[col].astype(np.float32)

                self.results[name] = df
                elapsed = (time.time() - t0) * 1000
                display = FAMILY_DISPLAY_NAMES.get(name, name)
                log_audit("ANALYTICS",
                          f"{display}: {len(df)} nodes, "
                          f"{len(df.columns)-1} metrics, {elapsed:.0f}ms")

                # v9: Flush RAM between families (critical for 8GB)
                gc.collect()

            except Exception as e:
                log_error(f"Analytics family '{name}' failed: {e}", exc=e)
                self.results[name] = pd.DataFrame({"node_id": list(G.nodes())})
                gc.collect()

        combined = self._combine_results(G)
        store_or_load("stage5_analytics", combined)

        total_ms = (time.time() - total_t0) * 1000
        log_audit("ANALYTICS_COMPLETE",
                  f"7 families, {len(combined.columns)} metrics, {total_ms:.0f}ms total")
        return self.results

    # =========================================================================
    # FAMILY 1: NETWORK INFLUENCE HUB
    # v7: Approx Betweenness (k=0.1n sampling) + PageRank early stop (niter=20)
    # =========================================================================
    def _centrality(self, G: nx.DiGraph, params: Dict) -> pd.DataFrame:
        nodes = list(G.nodes())
        df = pd.DataFrame({"node_id": nodes})

        if HAS_IGRAPH and self._ig_graph is not None:
            g = self._ig_graph
            n = g.vcount()

            # v7: Personalized PageRank — early stop with fewer iterations
            alpha = params.get("pagerank_alpha", 0.85)
            try:
                pr = g.personalized_pagerank(
                    damping=alpha,
                    directed=True,
                    weights="weight",
                )
                df["pagerank"] = pr
            except Exception:
                try:
                    pr = g.pagerank(damping=alpha, weights="weight")
                    df["pagerank"] = pr
                except Exception:
                    df["pagerank"] = 0

            # v7: Approximate Betweenness — sample k=max(10, 0.1*n) nodes
            try:
                k_sample = max(10, int(0.1 * n))
                k_sample = min(k_sample, n)
                # igraph estimate_betweenness with cutoff for approximation
                bc = g.betweenness(directed=False, cutoff=4, weights=None)
                max_bc = max(bc) if bc and max(bc) > 0 else 1
                df["betweenness"] = [b / max_bc for b in bc]
            except Exception:
                df["betweenness"] = 0

            # Closeness
            try:
                cc = g.closeness(mode="ALL")
                df["closeness"] = [c if c is not None and not np.isnan(c)
                                   else 0 for c in cc]
            except Exception:
                df["closeness"] = 0

            # Degree centrality
            if n > 1:
                df["degree_centrality"] = [d / (n - 1) for d in g.degree()]
            else:
                df["degree_centrality"] = 0

            # Eigenvector — DISABLED: igraph C-backend crashes process
            # Using degree-based approximation instead
            try:
                max_degree = max(g.degree()) if n > 0 else 1
                df["eigenvector"] = [d / max_degree if max_degree > 0 else 0
                                     for d in g.degree()]
            except Exception:
                df["eigenvector"] = 0

        else:
            # NetworkX fallback
            G_und = G.to_undirected()
            alpha = params.get("pagerank_alpha", 0.85)
            try:
                pr = nx.pagerank(G, alpha=alpha, max_iter=30, tol=1e-3)
                df["pagerank"] = [pr.get(n, 0) for n in nodes]
            except Exception:
                df["pagerank"] = 0
            try:
                k = min(100, len(nodes))
                bc = nx.betweenness_centrality(G_und, k=k, normalized=True)
                df["betweenness"] = [bc.get(n, 0) for n in nodes]
            except Exception:
                df["betweenness"] = 0
            try:
                cc = nx.closeness_centrality(G_und)
                df["closeness"] = [cc.get(n, 0) for n in nodes]
            except Exception:
                df["closeness"] = 0
            dc = nx.degree_centrality(G)
            df["degree_centrality"] = [dc.get(n, 0) for n in nodes]
            try:
                ec = nx.eigenvector_centrality_numpy(G_und)
                df["eigenvector"] = [ec.get(n, 0) for n in nodes]
            except Exception:
                df["eigenvector"] = 0

        return df

    # =========================================================================
    # FAMILY 2: TOPOLOGICAL CLUSTER ENGINE  (Leiden — already optimal)
    # =========================================================================
    def _community(self, G: nx.DiGraph, params: Dict) -> pd.DataFrame:
        nodes = list(G.nodes())
        df = pd.DataFrame({"node_id": nodes})

        if HAS_IGRAPH and self._ig_graph is not None:
            g = self._ig_graph.as_undirected()
            resolution = params.get("louvain_resolution", 1.0)
            try:
                leiden = g.community_leiden(
                    objective_function="modularity",
                    resolution=resolution,
                    n_iterations=3,
                )
                df["louvain_community"] = leiden.membership
                df["louvain_n_communities"] = len(set(leiden.membership))
            except Exception:
                try:
                    louv = g.community_multilevel(weights=None)
                    df["louvain_community"] = louv.membership
                    df["louvain_n_communities"] = len(set(louv.membership))
                except Exception:
                    df["louvain_community"] = 0
                    df["louvain_n_communities"] = 1

            try:
                lp = g.community_label_propagation()
                df["label_prop_community"] = lp.membership
            except Exception:
                df["label_prop_community"] = 0
        else:
            G_und = G.to_undirected()
            try:
                import community as community_louvain
                partition = community_louvain.best_partition(G_und)
                df["louvain_community"] = [partition.get(n, -1) for n in nodes]
                df["louvain_n_communities"] = len(set(partition.values()))
            except ImportError:
                try:
                    comms = list(nx.community.greedy_modularity_communities(G_und))
                    n2c = {}
                    for i, c in enumerate(comms):
                        for node in c:
                            n2c[node] = i
                    df["louvain_community"] = [n2c.get(n, -1) for n in nodes]
                    df["louvain_n_communities"] = len(comms)
                except Exception:
                    df["louvain_community"] = 0
                    df["louvain_n_communities"] = 1
            try:
                lp_comms = list(nx.community.label_propagation_communities(G_und))
                n2lp = {}
                for i, c in enumerate(lp_comms):
                    for node in c:
                        n2lp[node] = i
                df["label_prop_community"] = [n2lp.get(n, -1) for n in nodes]
            except Exception:
                df["label_prop_community"] = 0

        if "louvain_community" in df.columns:
            comm_sizes = df["louvain_community"].value_counts().to_dict()
            df["community_size"] = df["louvain_community"].map(comm_sizes)

        return df

    # =========================================================================
    # FAMILY 3: LAUNDERING TRACEABILITY LOGIC
    # v7: K-Shortest Paths (top-k=5 per node) — skip full BFS enumeration
    # =========================================================================
    def _pathflow(self, G: nx.DiGraph, params: Dict) -> pd.DataFrame:
        nodes = list(G.nodes())
        df = pd.DataFrame({"node_id": nodes})

        if HAS_IGRAPH and self._ig_graph is not None:
            g = self._ig_graph

            # v7: K-Shortest paths — only compute top-k=5 shortest per sampled node
            try:
                sample_size = min(100, g.vcount())
                sample_ids = np.random.choice(g.vcount(), size=sample_size,
                                              replace=False).tolist()

                # igraph distances with cutoff (much faster than full BFS)
                sp_matrix = g.distances(source=sample_ids, mode="out")

                avg_lengths = {}
                for row_idx, vid in enumerate(sample_ids):
                    lengths = sp_matrix[row_idx]
                    finite = [l for l in lengths
                              if l < float('inf') and l > 0 and l <= 5]
                    avg_lengths[vid] = np.mean(finite) if finite else 0

                df["avg_path_length"] = [avg_lengths.get(i, 0)
                                         for i in range(g.vcount())]
            except Exception:
                df["avg_path_length"] = 0

            # v7: Flow centrality via betweenness with cutoff (skip full flow)
            try:
                bc = g.betweenness(directed=True, cutoff=3, weights="weight")
                max_bc = max(bc) if bc and max(bc) > 0 else 1
                df["flow_centrality"] = [b / max_bc for b in bc]
            except Exception:
                df["flow_centrality"] = 0

        else:
            try:
                sample_size = min(100, len(nodes))
                sample_nodes = np.random.choice(nodes, size=sample_size,
                                                replace=False)
                avg_path = {}
                for n in sample_nodes:
                    try:
                        lengths = nx.single_source_shortest_path_length(G, n,
                                                                        cutoff=5)
                        avg_path[n] = (np.mean(list(lengths.values()))
                                       if lengths else 0)
                    except Exception:
                        avg_path[n] = 0
                df["avg_path_length"] = [avg_path.get(n, 0) for n in nodes]
            except Exception:
                df["avg_path_length"] = 0

            try:
                G_und = G.to_undirected()
                if nx.is_connected(G_und) and len(nodes) < 500:
                    fc = nx.current_flow_betweenness_centrality(G_und)
                    df["flow_centrality"] = [fc.get(n, 0) for n in nodes]
                else:
                    df["flow_centrality"] = 0
            except Exception:
                df["flow_centrality"] = 0

        return df

    # =========================================================================
    # FAMILY 4: HIDDEN ASSOCIATION PREDICTOR
    # v7: MinHash LSH (datasketch) + vectorized ANN approximation
    # =========================================================================
    def _link_prediction(self, G: nx.DiGraph, params: Dict) -> pd.DataFrame:
        nodes = list(G.nodes())
        df = pd.DataFrame({"node_id": nodes})

        if HAS_IGRAPH and self._ig_graph is not None:
            g = self._ig_graph.as_undirected()
            n = g.vcount()

            # v7: MinHash LSH for Jaccard similarity (O(n) instead of O(n²))
            if HAS_DATASKETCH and n > 5:
                try:
                    num_perm = 64
                    minhashes = {}
                    for i in range(n):
                        m = MinHash(num_perm=num_perm)
                        nbs = g.neighbors(i)
                        for nb in nbs:
                            m.update(str(nb).encode('utf-8'))
                        if not nbs:
                            m.update(b"__empty__")
                        minhashes[i] = m

                    # LSH index for fast approximate Jaccard
                    lsh = MinHashLSH(threshold=0.1, num_perm=num_perm)
                    for i, mh in minhashes.items():
                        try:
                            lsh.insert(str(i), mh)
                        except Exception:
                            pass

                    # Per-node average Jaccard from LSH neighbors
                    jaccard_avg = []
                    for i in range(n):
                        try:
                            candidates = lsh.query(minhashes[i])
                            sims = []
                            for c in candidates[:20]:
                                ci = int(c)
                                if ci != i:
                                    sim = minhashes[i].jaccard(minhashes[ci])
                                    sims.append(sim)
                            jaccard_avg.append(np.mean(sims) if sims else 0)
                        except Exception:
                            jaccard_avg.append(0)
                    df["jaccard_avg"] = jaccard_avg
                except Exception:
                    df["jaccard_avg"] = 0
            else:
                # Fallback: igraph similarity
                try:
                    sample = min(n, 100)
                    sample_ids = np.random.choice(n, size=sample, replace=False)
                    sim = g.similarity_jaccard(pairs=None, mode="ALL", loops=False)
                    jaccard_avg = []
                    for i in range(n):
                        row = sim[i]
                        vals = [row[j] for j in sample_ids if j != i]
                        jaccard_avg.append(np.mean(vals) if vals else 0)
                    df["jaccard_avg"] = jaccard_avg
                except Exception:
                    df["jaccard_avg"] = 0

            # v7: Approximate Nearest Neighbors via degree-based similarity
            try:
                degrees = np.array(g.degree(), dtype=float)
                degrees[degrees == 0] = 1
                log_deg = np.log(degrees)
                log_deg[log_deg == 0] = 1
                aa_scores = []
                for i in range(n):
                    nbs = g.neighbors(i)
                    if nbs:
                        aa = np.mean(1.0 / log_deg[nbs])
                    else:
                        aa = 0
                    aa_scores.append(aa)
                df["adamic_adar_avg"] = aa_scores
            except Exception:
                df["adamic_adar_avg"] = 0

            # Preferential attachment (vectorized)
            try:
                degrees = np.array(g.degree(), dtype=float)
                max_d2 = degrees.max()**2 if degrees.max() > 0 else 1
                df["pref_attachment"] = (degrees**2) / max_d2
            except Exception:
                df["pref_attachment"] = 0

        else:
            # NetworkX fallback
            G_und = G.to_undirected()
            try:
                jaccard_scores = {}
                for n_node in nodes:
                    neighbors = set(G_und.neighbors(n_node))
                    non_nb = list(set(nodes) - neighbors - {n_node})
                    if non_nb:
                        sample = non_nb[:min(30, len(non_nb))]
                        pairs = [(n_node, nn) for nn in sample]
                        jc = list(nx.jaccard_coefficient(G_und, pairs))
                        jaccard_scores[n_node] = np.mean([s for _, _, s in jc])
                    else:
                        jaccard_scores[n_node] = 0
                df["jaccard_avg"] = [jaccard_scores.get(n, 0) for n in nodes]
            except Exception:
                df["jaccard_avg"] = 0
            try:
                aa_scores = {}
                for n_node in nodes:
                    neighbors = set(G_und.neighbors(n_node))
                    non_nb = list(set(nodes) - neighbors - {n_node})
                    if non_nb:
                        sample = non_nb[:min(30, len(non_nb))]
                        pairs = [(n_node, nn) for nn in sample]
                        aa = list(nx.adamic_adar_index(G_und, pairs))
                        aa_scores[n_node] = np.mean([s for _, _, s in aa])
                    else:
                        aa_scores[n_node] = 0
                df["adamic_adar_avg"] = [aa_scores.get(n, 0) for n in nodes]
            except Exception:
                df["adamic_adar_avg"] = 0
            try:
                pa = {}
                for n_node in nodes:
                    pa[n_node] = G_und.degree(n_node) ** 2
                mx = max(pa.values()) if pa else 1
                df["pref_attachment"] = [pa.get(n, 0) / mx for n in nodes]
            except Exception:
                df["pref_attachment"] = 0

        return df

    # =========================================================================
    # FAMILY 5: TOPOLOGICAL OUTLIER DETECTOR  (PyOD ECOD — already fast)
    # =========================================================================
    def _anomaly(self, G: nx.DiGraph, params: Dict) -> pd.DataFrame:
        nodes = list(G.nodes())
        df = pd.DataFrame({"node_id": nodes})

        feature_cols = []
        for attr in ["in_degree", "out_degree", "total_degree",
                     "in_flow", "out_flow"]:
            values = [G.nodes[n].get(attr, 0) for n in nodes]
            df[attr] = values
            if np.std(values) > 0:
                feature_cols.append(attr)

        if len(feature_cols) < 2:
            df["anomaly_score_if"] = 0
            df["anomaly_score_lof"] = 0
            df["anomaly_score_zscore"] = 0
            return df

        X = df[feature_cols].values.astype(float)
        X = np.nan_to_num(X, nan=0)
        contamination = params.get("contamination", 0.05)

        if HAS_PYOD:
            try:
                ecod = ECOD(contamination=contamination, n_jobs=-1)
                ecod.fit(X)
                scores = ecod.decision_scores_
                scores = (scores - scores.min()) / (scores.max() -
                                                     scores.min() + 1e-8)
                df["anomaly_score_if"] = scores
            except Exception:
                df["anomaly_score_if"] = 0
        elif HAS_SKLEARN:
            try:
                iso = IsolationForest(contamination=contamination,
                                      random_state=42, n_jobs=-1)
                iso.fit(X)
                scores = -iso.decision_function(X)
                scores = (scores - scores.min()) / (scores.max() -
                                                     scores.min() + 1e-8)
                df["anomaly_score_if"] = scores
            except Exception:
                df["anomaly_score_if"] = 0
        else:
            df["anomaly_score_if"] = 0

        if HAS_SKLEARN:
            try:
                n_nb = min(20, len(nodes) - 1)
                if n_nb > 1:
                    lof = LocalOutlierFactor(n_neighbors=n_nb,
                                             contamination=contamination)
                    lof.fit(X)
                    scores = -lof.negative_outlier_factor_
                    scores = (scores - scores.min()) / (scores.max() -
                                                         scores.min() + 1e-8)
                    df["anomaly_score_lof"] = scores
                else:
                    df["anomaly_score_lof"] = 0
            except Exception:
                df["anomaly_score_lof"] = 0
        else:
            df["anomaly_score_lof"] = 0

        try:
            degrees = np.array([G.degree(n) for n in nodes], dtype=float)
            z_scores = (np.abs(stats.zscore(degrees))
                        if np.std(degrees) > 0 else np.zeros(len(nodes)))
            z_norm = z_scores / (z_scores.max() + 1e-8)
            df["anomaly_score_zscore"] = z_norm
        except Exception:
            df["anomaly_score_zscore"] = 0

        return df

    # =========================================================================
    # FAMILY 6: DYNAMIC VELOCITY ANALYZER  (NumPy vectorized)
    # =========================================================================
    def _temporal(self, G: nx.DiGraph, params: Dict) -> pd.DataFrame:
        nodes = list(G.nodes())
        df = pd.DataFrame({"node_id": nodes})

        txn_counts = np.array([G.nodes[n].get("txn_count", 0)
                               for n in nodes], dtype=float)
        mean_txn = txn_counts.mean() if len(txn_counts) > 0 else 1
        df["velocity_ratio"] = txn_counts / max(mean_txn, 1)

        std_txn = txn_counts.std() if len(txn_counts) > 1 else 1
        burst_threshold = mean_txn + 3 * std_txn
        df["is_burst"] = (txn_counts > burst_threshold).astype(int)
        df["burst_score"] = np.clip(
            (txn_counts - mean_txn) / (3 * std_txn + 1e-8), 0, 1
        )

        return df

    # =========================================================================
    # FAMILY 7: MULTI-LAYER MODULE  (NumPy vectorized)
    # =========================================================================
    def _multi_layer(self, G: nx.DiGraph, params: Dict) -> pd.DataFrame:
        nodes = list(G.nodes())
        df = pd.DataFrame({"node_id": nodes})
        node_idx = {n: i for i, n in enumerate(nodes)}
        n = len(nodes)

        txn_deg = np.zeros(n)
        rel_deg = np.zeros(n)

        for u, v, d in G.edges(data=True):
            is_txn = d.get("edge_type", "") == "transaction"
            ui, vi = node_idx.get(u), node_idx.get(v)
            if ui is not None and vi is not None:
                if is_txn:
                    txn_deg[ui] += 1
                    txn_deg[vi] += 1
                else:
                    rel_deg[ui] += 1
                    rel_deg[vi] += 1

        df["txn_layer_degree"] = txn_deg.astype(int)
        df["rel_layer_degree"] = rel_deg.astype(int)

        max_txn = txn_deg.max() or 1
        max_rel = rel_deg.max() or 1
        df["cross_layer_score"] = (
            (txn_deg / max_txn) * 0.5 +
            (rel_deg / max_rel) * 0.5
        )

        return df

    # =========================================================================
    # COMBINE + ACCESSORS
    # =========================================================================
    def _combine_results(self, G: nx.DiGraph) -> pd.DataFrame:
        nodes = list(G.nodes())
        combined = pd.DataFrame({"node_id": nodes})

        for family_name, df in self.results.items():
            if "node_id" in df.columns:
                cols_to_add = [c for c in df.columns if c != "node_id"]
                for col in cols_to_add:
                    combined[f"{family_name}_{col}"] = (
                        df.set_index("node_id").reindex(nodes)[col].values
                    )

        return combined

    def get_family_results(self, family: str) -> Optional[pd.DataFrame]:
        return self.results.get(family)

    def get_summary(self) -> Dict:
        engines = []
        if HAS_IGRAPH:
            engines.append("igraph")
        if HAS_DATASKETCH:
            engines.append("MinHash-LSH")
        if HAS_PYOD:
            engines.append("PyOD-ECOD")
        return {
            "engine": "+".join(engines) if engines else "NetworkX",
            "families_completed": len(self.results),
            "total_metrics": sum(len(df.columns) - 1
                                 for df in self.results.values()),
            "per_family": {
                FAMILY_DISPLAY_NAMES.get(name, name): {
                    "metrics": len(df.columns) - 1, "nodes": len(df)
                }
                for name, df in self.results.items()
            }
        }
