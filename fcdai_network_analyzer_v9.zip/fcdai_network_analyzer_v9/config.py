"""
FCDAI Network Analyzer - Configuration Loader
===============================================
Business Logic: Centralized configuration management. All parameters are
loaded from config.yaml so that analysts can tune thresholds, weights, and
UI settings without touching code.

Technical Implementation: Reads YAML into Pydantic-validated dataclasses.
Creates required directory structure on import. Thread-safe singleton pattern.
"""

import yaml
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional


# =============================================================================
# BASE DIRECTORY
# =============================================================================
BASE_DIR = Path(__file__).parent


def _load_yaml() -> dict:
    """Load config.yaml from project root."""
    config_path = BASE_DIR / "config.yaml"
    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    return {}


_CFG = _load_yaml()


# =============================================================================
# PATH CONFIGURATION
# =============================================================================
@dataclass
class PathConfig:
    """
    Business Logic: File system paths for data storage, exports, and logs.
    Technical Implementation: Creates directories on initialization.
    """
    BASE: Path = BASE_DIR
    DATA: Path = field(default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("data", "data"))
    SAMPLES: Path = field(default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("samples", "data/samples"))
    VAULT: Path = field(default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("vault", "data/vault"))
    EXPORTS: Path = field(default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("exports", "data/exports"))
    UPLOADS: Path = field(default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("uploads", "data/uploads"))
    LOGS: Path = field(default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("logs", "logs"))
    CACHE: Path = field(default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("cache", "cache"))
    MODELS: Path = field(default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("models", "models"))
    ASSETS: Path = field(default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("assets", "assets"))
    DB_PATH: Path = field(default_factory=lambda: BASE_DIR / _CFG.get("paths", {}).get("db_path", "data/fcdai.db"))

    def __post_init__(self):
        """Create directories if they don't exist."""
        for p in [self.DATA, self.SAMPLES, self.VAULT, self.EXPORTS,
                  self.UPLOADS, self.LOGS, self.CACHE, self.MODELS, self.ASSETS]:
            p.mkdir(parents=True, exist_ok=True)


# =============================================================================
# THEME CONFIGURATION
# =============================================================================
@dataclass
class ThemeConfig:
    """
    Business Logic: Premium dark theme with glassmorphism and gradient accents.
    Technical Implementation: Color tokens consumed by Dash Mantine and CSS.
    """
    PRIMARY: str = field(default_factory=lambda: _CFG.get("theme", {}).get("primary", "#00D4FF"))
    SECONDARY: str = field(default_factory=lambda: _CFG.get("theme", {}).get("secondary", "#9D4EDD"))
    ACCENT: str = field(default_factory=lambda: _CFG.get("theme", {}).get("accent", "#FF6B6B"))
    SUCCESS: str = field(default_factory=lambda: _CFG.get("theme", {}).get("success", "#00E676"))
    WARNING: str = field(default_factory=lambda: _CFG.get("theme", {}).get("warning", "#FFD600"))
    DANGER: str = field(default_factory=lambda: _CFG.get("theme", {}).get("danger", "#FF1744"))
    INFO: str = field(default_factory=lambda: _CFG.get("theme", {}).get("info", "#2196F3"))
    DARK_BG: str = field(default_factory=lambda: _CFG.get("theme", {}).get("dark_bg", "#0A0E17"))
    DARK_BG_CARD: str = field(default_factory=lambda: _CFG.get("theme", {}).get("dark_bg_card", "#111827"))
    DARK_BG_ELEVATED: str = field(default_factory=lambda: _CFG.get("theme", {}).get("dark_bg_elevated", "#1A2332"))
    DARK_BORDER: str = field(default_factory=lambda: _CFG.get("theme", {}).get("dark_border", "#1E293B"))
    GLASS_BG: str = field(default_factory=lambda: _CFG.get("theme", {}).get("glass_bg", "rgba(17, 24, 39, 0.7)"))
    GLASS_BORDER: str = field(default_factory=lambda: _CFG.get("theme", {}).get("glass_border", "rgba(255, 255, 255, 0.08)"))
    TEXT_PRIMARY: str = field(default_factory=lambda: _CFG.get("theme", {}).get("text_primary", "#E2E8F0"))
    TEXT_SECONDARY: str = field(default_factory=lambda: _CFG.get("theme", {}).get("text_secondary", "#94A3B8"))
    TEXT_MUTED: str = field(default_factory=lambda: _CFG.get("theme", {}).get("text_muted", "#64748B"))


# =============================================================================
# PIPELINE CONFIGURATION
# =============================================================================
@dataclass
class PipelineConfig:
    """
    Business Logic: All pipeline stage parameters — thresholds, weights, methods.
    Technical Implementation: Loaded from config.yaml 'pipeline' section.
    """
    _raw: Dict = field(default_factory=lambda: _CFG.get("pipeline", {}))

    # Stage 0-1: Ingest & Validate
    EXPECTED_TABLES: List[str] = field(default_factory=lambda: _CFG.get("pipeline", {}).get(
        "expected_tables", ["customer", "account", "kyc", "transaction", "historical", "alert", "relationship"]))
    DQ_THRESHOLDS: Dict[str, float] = field(default_factory=lambda: _CFG.get("pipeline", {}).get(
        "dq_thresholds", {"completeness": 0.90, "consistency": 0.85, "validity": 0.80}))

    # Stage 2: Aggregation
    CUSTOMER_ID_COL: str = field(default_factory=lambda: _CFG.get("pipeline", {}).get("customer_id_column", "customer_id"))
    ACCOUNT_ID_COL: str = field(default_factory=lambda: _CFG.get("pipeline", {}).get("account_id_column", "account_id"))
    AMOUNT_COL: str = field(default_factory=lambda: _CFG.get("pipeline", {}).get("amount_column", "amount"))
    TIMESTAMP_COL: str = field(default_factory=lambda: _CFG.get("pipeline", {}).get("timestamp_column", "timestamp"))

    # Stage 3-4: Graph
    GRAPH_MAX_NODES: int = field(default_factory=lambda: _CFG.get("pipeline", {}).get("graph", {}).get("max_nodes", 10000))
    GRAPH_LAYOUT: str = field(default_factory=lambda: _CFG.get("pipeline", {}).get("graph", {}).get("layout", "cose-bilkent"))
    SIMILARITY_THRESHOLD: float = field(default_factory=lambda: _CFG.get("pipeline", {}).get("graph", {}).get("similarity_threshold", 0.7))

    # Stage 5: Analytics families
    ANALYTICS: Dict[str, Any] = field(default_factory=lambda: _CFG.get("pipeline", {}).get("analytics", {}))

    # Stage 6-8: Scoring
    RISK_WEIGHTS: Dict[str, float] = field(default_factory=lambda: _CFG.get("pipeline", {}).get(
        "scoring", {}).get("risk_formula_weights", {}))
    RISK_TIERS: Dict[str, List] = field(default_factory=lambda: _CFG.get("pipeline", {}).get(
        "scoring", {}).get("risk_tiers", {"P1": [80, 100], "P2": [60, 80], "P3": [40, 60], "P4": [0, 40]}))

    INVESTIGATION_CAPACITY: int = field(default_factory=lambda: _CFG.get("pipeline", {}).get("investigation_capacity", 1000))


# =============================================================================
# APPLICATION CONFIGURATION
# =============================================================================
@dataclass
class AppConfig:
    """
    Business Logic: Application-level settings — title, port, debug mode.
    Technical Implementation: Controls Dash server initialization parameters.
    """
    TITLE: str = field(default_factory=lambda: _CFG.get("app", {}).get("title", "FCDAI Network Analyzer"))
    VERSION: str = field(default_factory=lambda: _CFG.get("app", {}).get("version", "1.0.0"))
    HOST: str = field(default_factory=lambda: _CFG.get("app", {}).get("host", "127.0.0.1"))
    PORT: int = field(default_factory=lambda: _CFG.get("app", {}).get("port", 8075))
    DEBUG: bool = field(default_factory=lambda: _CFG.get("app", {}).get("debug", False))
    SERVE_LOCALLY: bool = field(default_factory=lambda: _CFG.get("app", {}).get("serve_locally", True))
    PLOTLY_CONFIG: Dict = field(default_factory=lambda: _CFG.get("plotly", {
        "displaylogo": False,
        "modeBarButtonsToRemove": ["sendDataToCloud", "lasso2d", "select2d"],
        "toImageButtonOptions": {"format": "png", "scale": 2}
    }))


# =============================================================================
# INSTANTIATE CONFIGS (Singleton pattern)
# =============================================================================
PATHS = PathConfig()
THEME = ThemeConfig()
PIPELINE = PipelineConfig()
APP = AppConfig()
