"""
FCDAI Network Analyzer - Synthetic Sample Data Generator
==========================================================
Business Logic: Generates realistic AML data across 7 CSV tables with
10,000 customers, controllable anomaly injection, and diverse data types
(numeric, categorical, binary, ordinal, nominal, mixed). This sample data
is used until the user uploads their own data.

Technical Implementation: NumPy-based generation with Pydantic validation
on output. Saves to data/samples/ as CSV. Supports parameterized generation
for testing different scenarios.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, Optional, Tuple
import sys
import json

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PATHS
from utils.logger import log_audit, log_error


# =============================================================================
# CONFIGURATION
# =============================================================================
COUNTRIES = ["US", "GB", "DE", "FR", "CH", "SG", "HK", "AE", "KY", "BZ", "OTHER"]
COUNTRY_WEIGHTS = [0.30, 0.12, 0.10, 0.08, 0.05, 0.05, 0.04, 0.04, 0.03, 0.02, 0.17]
HIGH_RISK_COUNTRIES = {"HK", "AE", "KY", "BZ", "OTHER"}

TXN_TYPES = ["WIRE", "ACH", "CASH", "CHECK", "CARD", "RTGS", "SWIFT"]
TXN_TYPE_WEIGHTS = [0.18, 0.25, 0.12, 0.10, 0.20, 0.08, 0.07]

CHANNELS = ["branch", "online", "mobile", "atm", "telephone"]
CHANNEL_WEIGHTS = [0.15, 0.35, 0.30, 0.10, 0.10]

OCCUPATIONS = [
    "engineer", "doctor", "lawyer", "teacher", "business_owner",
    "retired", "student", "finance", "government", "self_employed",
    "unemployed", "other"
]
SEGMENTS = ["retail", "commercial", "private_banking", "wealth", "sme"]
STATUSES_CUSTOMER = ["active", "dormant", "suspended", "closed"]
STATUSES_ACCOUNT = ["active", "frozen", "closed", "under_review"]
ACCOUNT_TYPES = ["checking", "savings", "investment", "loan", "credit_card"]
CURRENCIES = ["USD", "EUR", "GBP", "CHF", "SGD", "HKD"]

ALERT_TYPES = ["TM", "SAR", "MAN", "EDD", "PEP", "SANCTIONS"]
ALERT_SEVERITY = ["low", "medium", "high", "critical"]
EVENT_TYPES = ["SAR_filed", "STR_filed", "EDD_review", "alert_closed", "case_opened"]
RELATIONSHIP_TYPES = [
    "shared_address", "shared_phone", "beneficial_owner",
    "corporate_link", "family", "power_of_attorney", "same_employer"
]


# =============================================================================
# GENERATORS
# =============================================================================
def generate_customers(n: int = 10000, seed: int = 42) -> pd.DataFrame:
    """
    Business Logic: Generate customer master data. Each customer has a unique
    ID, demographics, and a risk rating. Some customers are flagged as
    high-risk based on country, PEP status, or unusual attributes.
    """
    rng = np.random.default_rng(seed)

    customer_ids = [f"CUST{i:06d}" for i in range(1, n + 1)]

    df = pd.DataFrame({
        "customer_id": customer_ids,
        "name": [f"Customer_{i}" for i in range(1, n + 1)],
        "customer_type": rng.choice(
            ["individual", "corporate", "trust", "joint"],
            size=n, p=[0.60, 0.25, 0.08, 0.07]
        ),
        "country": rng.choice(COUNTRIES, size=n, p=COUNTRY_WEIGHTS),
        "registration_date": [
            (datetime.now() - timedelta(days=int(rng.integers(30, 3650)))).strftime("%Y-%m-%d")
            for _ in range(n)
        ],
        "risk_rating": rng.choice([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], size=n,
                                  p=[0.15, 0.15, 0.15, 0.12, 0.10, 0.08, 0.08, 0.07, 0.05, 0.05]),
        "status": rng.choice(STATUSES_CUSTOMER, size=n, p=[0.75, 0.10, 0.05, 0.10]),
        "segment": rng.choice(SEGMENTS, size=n, p=[0.40, 0.20, 0.15, 0.10, 0.15]),
        "annual_income": np.abs(rng.lognormal(mean=11.0, sigma=1.0, size=n)).round(2),
        "occupation": rng.choice(OCCUPATIONS, size=n),
    })

    log_audit("SAMPLE_GEN", f"customers: {n} records")
    return df


def generate_accounts(n_customers: int = 10000, seed: int = 42) -> pd.DataFrame:
    """
    Business Logic: Generate bank accounts. Each customer has 1-4 accounts.
    Accounts link to customers via customer_id.
    """
    rng = np.random.default_rng(seed + 1)

    records = []
    acct_id = 1
    for i in range(1, n_customers + 1):
        n_accounts = int(rng.choice([1, 2, 3, 4], p=[0.50, 0.30, 0.15, 0.05]))
        for _ in range(n_accounts):
            records.append({
                "account_id": f"ACCT{acct_id:07d}",
                "customer_id": f"CUST{i:06d}",
                "account_type": rng.choice(ACCOUNT_TYPES),
                "currency": rng.choice(CURRENCIES),
                "balance": round(float(np.abs(rng.lognormal(mean=9.0, sigma=2.0))), 2),
                "open_date": (datetime.now() - timedelta(
                    days=int(rng.integers(1, 3650)))).strftime("%Y-%m-%d"),
                "status": rng.choice(STATUSES_ACCOUNT, p=[0.80, 0.05, 0.05, 0.10]),
                "branch": f"BR{int(rng.integers(1, 50)):03d}",
            })
            acct_id += 1

    df = pd.DataFrame(records)
    log_audit("SAMPLE_GEN", f"accounts: {len(df)} records for {n_customers} customers")
    return df


def generate_kyc(n_customers: int = 10000, seed: int = 42) -> pd.DataFrame:
    """
    Business Logic: KYC (Know-Your-Customer) data for each customer.
    Includes PEP status, sanctions hits, ID verification, and source of funds.
    """
    rng = np.random.default_rng(seed + 2)

    df = pd.DataFrame({
        "customer_id": [f"CUST{i:06d}" for i in range(1, n_customers + 1)],
        "kyc_date": [
            (datetime.now() - timedelta(days=int(rng.integers(0, 365)))).strftime("%Y-%m-%d")
            for _ in range(n_customers)
        ],
        "kyc_score": rng.uniform(0.3, 1.0, size=n_customers).round(3),
        "pep_status": rng.choice([0, 1], size=n_customers, p=[0.95, 0.05]),
        "sanctions_hit": rng.choice([0, 1], size=n_customers, p=[0.98, 0.02]),
        "id_verified": rng.choice([0, 1], size=n_customers, p=[0.10, 0.90]),
        "source_of_funds": rng.choice(
            ["employment", "business", "investment", "inheritance", "unknown"],
            size=n_customers, p=[0.40, 0.25, 0.15, 0.10, 0.10]
        ),
        "risk_category": rng.choice(
            ["low", "medium", "high", "critical"],
            size=n_customers, p=[0.50, 0.30, 0.15, 0.05]
        ),
    })

    log_audit("SAMPLE_GEN", f"kyc: {n_customers} records")
    return df


def generate_transactions(
    n_records: int = 50000,
    n_customers: int = 10000,
    anomaly_rate: float = 0.03,
    seed: int = 42
) -> pd.DataFrame:
    """
    Business Logic: Financial transactions — the primary data source for
    graph construction. Each transaction connects accounts through money flow.
    Anomalies are injected at a configurable rate.
    """
    rng = np.random.default_rng(seed + 3)

    # Generate account IDs (distribute across customers)
    # Approximate: each customer gets ~1.5 accounts on avg
    all_accounts = []
    for i in range(1, n_customers + 1):
        n_acct = max(1, int(rng.choice([1, 2, 3], p=[0.50, 0.35, 0.15])))
        for j in range(n_acct):
            all_accounts.append((f"CUST{i:06d}", f"ACCT{len(all_accounts)+1:07d}"))

    # Assign transactions to random accounts
    chosen = rng.choice(len(all_accounts), size=n_records)
    cust_ids = [all_accounts[c][0] for c in chosen]
    acct_ids = [all_accounts[c][1] for c in chosen]

    # Counterparties (other customers)
    counterparty_ids = [f"CUST{int(rng.integers(1, n_customers+1)):06d}" for _ in range(n_records)]

    df = pd.DataFrame({
        "txn_id": [f"TXN{i:08d}" for i in range(1, n_records + 1)],
        "account_id": acct_ids,
        "customer_id": cust_ids,
        "timestamp": [
            (datetime.now() - timedelta(
                days=int(rng.integers(0, 365)),
                hours=int(rng.integers(0, 24)),
                minutes=int(rng.integers(0, 60))
            )).strftime("%Y-%m-%d %H:%M:%S")
            for _ in range(n_records)
        ],
        "amount": np.abs(rng.lognormal(mean=6.0, sigma=1.5, size=n_records)).round(2),
        "currency": rng.choice(CURRENCIES, size=n_records, p=[0.40, 0.20, 0.15, 0.10, 0.08, 0.07]),
        "transaction_type": rng.choice(TXN_TYPES, size=n_records, p=TXN_TYPE_WEIGHTS),
        "counterparty_id": counterparty_ids,
        "counterparty_country": rng.choice(COUNTRIES, size=n_records, p=COUNTRY_WEIGHTS),
        "channel": rng.choice(CHANNELS, size=n_records, p=CHANNEL_WEIGHTS),
        "description": [f"Transaction {i}" for i in range(1, n_records + 1)],
        "is_international": rng.choice([0, 1], size=n_records, p=[0.70, 0.30]),
    })

    # Inject anomalies
    n_anomalies = int(n_records * anomaly_rate)
    anomaly_idx = rng.choice(n_records, size=n_anomalies, replace=False)

    for idx in anomaly_idx:
        anom_type = rng.choice(["amount", "velocity", "pattern", "structuring", "mixed"])

        if anom_type == "amount":
            df.loc[idx, "amount"] = float(rng.uniform(100000, 2000000))
        elif anom_type == "velocity":
            # Same customer, many txns in short window — handled by temporal analytics
            df.loc[idx, "amount"] = float(rng.uniform(5000, 20000))
        elif anom_type == "pattern":
            df.loc[idx, "amount"] = float(rng.choice([9999, 9998, 9997, 4999]))
            df.loc[idx, "counterparty_country"] = rng.choice(list(HIGH_RISK_COUNTRIES))
        elif anom_type == "structuring":
            df.loc[idx, "amount"] = float(rng.choice([9500, 9800, 9900, 9950]))
            df.loc[idx, "transaction_type"] = "CASH"
        else:
            df.loc[idx, "amount"] = float(rng.uniform(500000, 5000000))
            df.loc[idx, "counterparty_country"] = "OTHER"
            df.loc[idx, "is_international"] = 1

    log_audit("SAMPLE_GEN", f"transactions: {n_records} records, {n_anomalies} anomalies injected")
    return df


def generate_historical(n_customers: int = 10000, seed: int = 42) -> pd.DataFrame:
    """
    Business Logic: Historical alerts, SARs, and investigation records.
    ~20% of customers have some history; repeat offenders have multiple entries.
    """
    rng = np.random.default_rng(seed + 4)

    records = []
    rec_id = 1
    for i in range(1, n_customers + 1):
        # 20% of customers have historical events
        if rng.random() < 0.20:
            n_events = int(rng.choice([1, 2, 3, 4], p=[0.50, 0.30, 0.15, 0.05]))
            for _ in range(n_events):
                records.append({
                    "record_id": f"HIST{rec_id:06d}",
                    "customer_id": f"CUST{i:06d}",
                    "event_type": rng.choice(EVENT_TYPES),
                    "event_date": (datetime.now() - timedelta(
                        days=int(rng.integers(30, 730)))).strftime("%Y-%m-%d"),
                    "outcome": rng.choice(["TP", "FP", "pending"], p=[0.30, 0.50, 0.20]),
                    "risk_score_at_time": round(float(rng.uniform(30, 95)), 1),
                    "narrative": f"Historical event for customer CUST{i:06d}",
                    "filed_by": f"analyst_{int(rng.integers(1, 20)):02d}",
                })
                rec_id += 1

    df = pd.DataFrame(records) if records else pd.DataFrame(columns=[
        "record_id", "customer_id", "event_type", "event_date",
        "outcome", "risk_score_at_time", "narrative", "filed_by"
    ])
    log_audit("SAMPLE_GEN", f"historical: {len(df)} records")
    return df


def generate_alerts(n_customers: int = 10000, seed: int = 42) -> pd.DataFrame:
    """
    Business Logic: Current alerts for investigation. ~10% of customers
    have active alerts.
    """
    rng = np.random.default_rng(seed + 5)

    records = []
    alert_id = 1
    for i in range(1, n_customers + 1):
        if rng.random() < 0.10:
            n_alerts = int(rng.choice([1, 2, 3], p=[0.60, 0.30, 0.10]))
            for _ in range(n_alerts):
                records.append({
                    "alert_id": f"ALT{alert_id:06d}",
                    "customer_id": f"CUST{i:06d}",
                    "alert_date": (datetime.now() - timedelta(
                        days=int(rng.integers(0, 90)))).strftime("%Y-%m-%d"),
                    "alert_type": rng.choice(ALERT_TYPES),
                    "severity": rng.choice(ALERT_SEVERITY, p=[0.30, 0.35, 0.25, 0.10]),
                    "status": rng.choice(["open", "closed", "escalated"], p=[0.40, 0.40, 0.20]),
                    "score": round(float(rng.uniform(0.3, 1.0)), 3),
                    "rule_triggered": f"RULE_{int(rng.integers(1, 50)):03d}",
                    "assigned_to": f"analyst_{int(rng.integers(1, 20)):02d}",
                })
                alert_id += 1

    df = pd.DataFrame(records) if records else pd.DataFrame(columns=[
        "alert_id", "customer_id", "alert_date", "alert_type", "severity",
        "status", "score", "rule_triggered", "assigned_to"
    ])
    log_audit("SAMPLE_GEN", f"alerts: {len(df)} records")
    return df


def generate_relationships(n_customers: int = 10000, seed: int = 42) -> pd.DataFrame:
    """
    Business Logic: Explicit relationships between customers — shared addresses,
    beneficial ownership, corporate links. These become similarity edges in
    the graph (Stage 3-4).
    """
    rng = np.random.default_rng(seed + 6)

    records = []
    for i in range(1, n_customers + 1):
        # ~15% of customers have explicit relationships
        if rng.random() < 0.15:
            n_rels = int(rng.choice([1, 2, 3], p=[0.60, 0.30, 0.10]))
            for _ in range(n_rels):
                target = rng.integers(1, n_customers + 1)
                if target == i:
                    continue
                records.append({
                    "source_id": f"CUST{i:06d}",
                    "target_id": f"CUST{target:06d}",
                    "relationship_type": rng.choice(RELATIONSHIP_TYPES),
                    "strength": round(float(rng.uniform(0.3, 1.0)), 3),
                    "start_date": (datetime.now() - timedelta(
                        days=int(rng.integers(0, 1825)))).strftime("%Y-%m-%d"),
                    "end_date": None,
                })

    df = pd.DataFrame(records) if records else pd.DataFrame(columns=[
        "source_id", "target_id", "relationship_type", "strength",
        "start_date", "end_date"
    ])
    log_audit("SAMPLE_GEN", f"relationships: {len(df)} records")
    return df


# =============================================================================
# MASTER GENERATOR
# =============================================================================
def generate_all_samples(
    n_customers: int = 10000,
    n_transactions: int = 50000,
    anomaly_rate: float = 0.03,
    seed: int = 42,
    output_dir: Path = None
) -> Dict[str, pd.DataFrame]:
    """
    Business Logic: Generate all 7 sample CSV tables. This is the entry
    point for creating the initial dataset.

    Technical Implementation: Generates each table, validates shapes,
    saves to data/samples/ as CSV, and returns dict of DataFrames.
    """
    output_dir = output_dir or PATHS.SAMPLES
    output_dir.mkdir(parents=True, exist_ok=True)

    log_audit("SAMPLE_GEN_START", f"Generating {n_customers} customers, {n_transactions} transactions")

    tables = {
        "customer": generate_customers(n_customers, seed),
        "account": generate_accounts(n_customers, seed),
        "kyc": generate_kyc(n_customers, seed),
        "transaction": generate_transactions(n_transactions, n_customers, anomaly_rate, seed),
        "historical": generate_historical(n_customers, seed),
        "alert": generate_alerts(n_customers, seed),
        "relationship": generate_relationships(n_customers, seed),
    }

    # Save to CSV
    for name, df in tables.items():
        filepath = output_dir / f"{name}.csv"
        df.to_csv(filepath, index=False)
        log_audit("SAMPLE_SAVE", f"{name}.csv: {len(df)} rows, {len(df.columns)} cols")

    # Write metadata
    metadata = {
        "generated_at": datetime.now().isoformat(),
        "seed": seed,
        "n_customers": n_customers,
        "n_transactions": n_transactions,
        "anomaly_rate": anomaly_rate,
        "tables": {name: {"rows": len(df), "columns": len(df.columns)}
                   for name, df in tables.items()}
    }
    with open(output_dir / "metadata.json", "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)

    log_audit("SAMPLE_GEN_COMPLETE", f"7 tables generated to {output_dir}")
    return tables


# =============================================================================
# CLI ENTRY POINT
# =============================================================================
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Generate FCDAI sample data")
    parser.add_argument("--customers", type=int, default=10000, help="Number of customers")
    parser.add_argument("--transactions", type=int, default=50000, help="Number of transactions")
    parser.add_argument("--anomaly-rate", type=float, default=0.03, help="Anomaly injection rate")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    args = parser.parse_args()

    tables = generate_all_samples(
        n_customers=args.customers,
        n_transactions=args.transactions,
        anomaly_rate=args.anomaly_rate,
        seed=args.seed,
    )

    print("\n=== FCDAI Sample Data Generated ===")
    for name, df in tables.items():
        print(f"  {name:15s}: {len(df):>8,} rows × {len(df.columns):>3} columns")
    print(f"  {'':15s}  --------")
    total = sum(len(df) for df in tables.values())
    print(f"  {'TOTAL':15s}: {total:>8,} rows")
