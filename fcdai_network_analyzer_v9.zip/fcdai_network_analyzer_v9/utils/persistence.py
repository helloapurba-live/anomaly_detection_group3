"""
FCDAI Network Analyzer - Parquet Persistence Layer
====================================================
Business Logic: All intermediate pipeline states are persisted to Parquet
files in data/vault/. When new data is uploaded, the app stores it locally.
If no new data is provided, the last-stored data is used as default.
This ensures the pipeline can be re-run without re-uploading.

Technical Implementation: Parquet read/write with PyArrow. Files are
timestamped. A manifest.json tracks what's stored.
"""

import pandas as pd
import json
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, List, Any
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import PATHS
from utils.logger import log_audit, log_error, log_data_transform


# =============================================================================
# VAULT MANAGER
# =============================================================================
class VaultManager:
    """
    Business Logic: Manages persistent storage of pipeline intermediates.
    Each stage writes its output here. If data exists from a previous run,
    it can be reloaded without re-processing.

    Technical Implementation: Parquet files in data/vault/ with a manifest.json
    tracking metadata.
    """

    def __init__(self, vault_path: Path = None):
        self.vault_path = vault_path or PATHS.VAULT
        self.vault_path.mkdir(parents=True, exist_ok=True)
        self.manifest_path = self.vault_path / "manifest.json"
        self._manifest = self._load_manifest()

    def _load_manifest(self) -> Dict[str, Any]:
        """Load or create manifest."""
        if self.manifest_path.exists():
            with open(self.manifest_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {"files": {}, "last_updated": None}

    def _save_manifest(self):
        """Persist manifest to disk."""
        self._manifest["last_updated"] = datetime.now().isoformat()
        with open(self.manifest_path, "w", encoding="utf-8") as f:
            json.dump(self._manifest, f, indent=2, default=str)

    def store(self, name: str, df: pd.DataFrame, metadata: Dict = None) -> Path:
        """
        Business Logic: Store a DataFrame as Parquet in the vault.

        Args:
            name: Logical name (e.g., "stage_2_aggregated")
            df: DataFrame to persist
            metadata: Optional metadata dict

        Returns:
            Path to the stored Parquet file
        """
        filename = f"{name}.parquet"
        filepath = self.vault_path / filename

        input_shape = df.shape
        df.to_parquet(filepath, engine="pyarrow", index=False)

        # Update manifest
        self._manifest["files"][name] = {
            "filename": filename,
            "rows": len(df),
            "columns": len(df.columns),
            "size_bytes": filepath.stat().st_size,
            "stored_at": datetime.now().isoformat(),
            "metadata": metadata or {}
        }
        self._save_manifest()

        log_audit("VAULT_STORE", f"{name}: {input_shape[0]}r×{input_shape[1]}c → {filepath}")
        return filepath

    def load(self, name: str) -> Optional[pd.DataFrame]:
        """
        Business Logic: Load a previously stored DataFrame from the vault.
        Returns None if not found.
        """
        if name not in self._manifest["files"]:
            return None

        filepath = self.vault_path / self._manifest["files"][name]["filename"]
        if not filepath.exists():
            return None

        df = pd.read_parquet(filepath, engine="pyarrow")
        log_audit("VAULT_LOAD", f"{name}: {df.shape[0]}r×{df.shape[1]}c from {filepath}")
        return df

    def exists(self, name: str) -> bool:
        """Check if a named dataset exists in the vault."""
        if name not in self._manifest["files"]:
            return False
        filepath = self.vault_path / self._manifest["files"][name]["filename"]
        return filepath.exists()

    def list_stored(self) -> Dict[str, Dict]:
        """List all stored datasets with metadata."""
        return self._manifest["files"]

    def delete(self, name: str) -> bool:
        """Remove a stored dataset."""
        if name in self._manifest["files"]:
            filepath = self.vault_path / self._manifest["files"][name]["filename"]
            if filepath.exists():
                filepath.unlink()
            del self._manifest["files"][name]
            self._save_manifest()
            log_audit("VAULT_DELETE", f"Removed {name}")
            return True
        return False

    def clear(self):
        """Clear all vault contents."""
        for name in list(self._manifest["files"].keys()):
            self.delete(name)
        log_audit("VAULT_CLEAR", "All vault contents removed")


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================
_vault = None


def get_vault() -> VaultManager:
    """Singleton accessor for vault manager."""
    global _vault
    if _vault is None:
        _vault = VaultManager()
    return _vault


def store_dataframe(name: str, df: pd.DataFrame, **kwargs) -> Path:
    """Quick store a DataFrame to vault."""
    return get_vault().store(name, df, **kwargs)


def load_dataframe(name: str) -> Optional[pd.DataFrame]:
    """Quick load a DataFrame from vault."""
    return get_vault().load(name)


def store_or_load(name: str, df: Optional[pd.DataFrame] = None) -> Optional[pd.DataFrame]:
    """
    Business Logic: If df is provided, store it. If not, load the last stored version.
    This implements the spec's "store it and use as default until new data provided" pattern.
    """
    vault = get_vault()
    if df is not None:
        vault.store(name, df)
        return df
    return vault.load(name)
