"""
FCDAI Network Analyzer - Global Logger & Exception Handler
============================================================
Business Logic: Every callback, data transformation, and pipeline stage
must be logged for auditability. Bank regulators require a complete trail
of all operations performed on customer data.

Technical Implementation: Dual-logger writing to audit_trail.log (user
actions, pipeline events) and debug.log (errors, stack traces). The
GlobalExceptionHandler wraps Dash callbacks to catch and log all errors
without crashing the UI.
"""

import logging
import traceback
import functools
from pathlib import Path
from datetime import datetime
from typing import Callable, Any
import sys
import os

# Determine log directory
_BASE = Path(__file__).parent.parent
_LOG_DIR = _BASE / "logs"
_LOG_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# AUDIT TRAIL LOGGER
# =============================================================================
def _create_logger(name: str, filename: str, level: int = logging.INFO) -> logging.Logger:
    """Create a file logger with timestamp formatting."""
    logger = logging.getLogger(name)
    logger.setLevel(level)

    # Avoid duplicate handlers on re-import
    if logger.handlers:
        return logger

    fh = logging.FileHandler(_LOG_DIR / filename, encoding="utf-8")
    fh.setLevel(level)

    formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    # Also log to console for debug
    if level <= logging.DEBUG:
        ch = logging.StreamHandler(sys.stderr)
        ch.setLevel(logging.WARNING)
        ch.setFormatter(formatter)
        logger.addHandler(ch)

    return logger


# Primary loggers
audit_logger = _create_logger("fcdai.audit", "audit_trail.log", logging.INFO)
debug_logger = _create_logger("fcdai.debug", "debug.log", logging.DEBUG)


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================
def log_audit(action: str, details: str = "", user: str = "system"):
    """
    Business Logic: Record an auditable event — user action, data loading,
    pipeline stage completion, export, etc.

    Technical Implementation: Writes to audit_trail.log with timestamp + user.
    """
    msg = f"[{user}] {action}"
    if details:
        msg += f" | {details}"
    audit_logger.info(msg)


def log_debug(message: str, exc_info: bool = False):
    """
    Technical Implementation: Write to debug.log. Pass exc_info=True to
    include full stack trace.
    """
    debug_logger.debug(message, exc_info=exc_info)


def log_error(message: str, exc: Exception = None):
    """
    Technical Implementation: Write error to both audit and debug logs.
    """
    audit_logger.error(f"ERROR: {message}")
    if exc:
        debug_logger.error(f"{message}: {exc}", exc_info=True)
    else:
        debug_logger.error(message)


def log_data_transform(operation: str, input_shape: tuple, output_shape: tuple,
                       params: dict = None):
    """
    Business Logic: Every data transformation must be logged for
    referential integrity. Records what changed, how many rows/cols
    before and after.
    """
    msg = (f"TRANSFORM: {operation} | "
           f"in={input_shape[0]}r×{input_shape[1]}c → "
           f"out={output_shape[0]}r×{output_shape[1]}c")
    if params:
        msg += f" | params={params}"
    audit_logger.info(msg)
    debug_logger.debug(msg)


# =============================================================================
# GLOBAL EXCEPTION HANDLER (Dash Callback Wrapper)
# =============================================================================
class GlobalExceptionHandler:
    """
    Business Logic: Wraps all Dash callbacks to ensure errors are logged
    and the UI never shows a generic crash screen.

    Technical Implementation: Decorator that catches exceptions, logs the
    full stack trace to debug.log, and returns a safe fallback value.

    Usage:
        @app.callback(...)
        @GlobalExceptionHandler.wrap(fallback=html.Div("Error"))
        def my_callback(...):
            ...
    """

    @staticmethod
    def wrap(fallback: Any = None):
        """
        Decorator factory for wrapping Dash callbacks.

        Args:
            fallback: Value to return if the callback raises an exception.
        """
        def decorator(func: Callable) -> Callable:
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    error_id = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
                    log_error(
                        f"Callback error [{error_id}] in {func.__name__}: {e}",
                        exc=e
                    )
                    if fallback is not None:
                        return fallback
                    # Re-raise if no fallback specified
                    raise
            return wrapper
        return decorator


# =============================================================================
# STARTUP LOG
# =============================================================================
log_audit("SYSTEM_START", f"FCDAI Network Analyzer initialized | PID={os.getpid()}")
