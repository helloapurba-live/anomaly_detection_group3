"""
FCDAI Network Analyzer - Pydantic Data Schemas
================================================
Business Logic: Defines the shape of every data table in the AML pipeline.
Uses flexible field definitions so users can map any CSV column to any role
(numeric, categorical, binary, ordinal, nominal) via the Mapping Interface.

Technical Implementation: Pydantic v2 BaseModel classes with Optional fields
to support partial uploads. ColumnMapping and MappingRegistry allow dynamic
re-typing of columns at runtime without code changes.
"""

from pydantic import BaseModel, Field, field_validator
from typing import Optional, Dict, List, Any, Literal
from datetime import datetime
from enum import Enum


# =============================================================================
# COLUMN DATA TYPE ENUMS
# =============================================================================
class ColumnDataType(str, Enum):
    """
    Business Logic: Classifies column data types for the Mapping Interface.
    Users pick from these types when assigning roles to uploaded CSV columns.
    """
    NUMERIC = "numeric"
    CONTINUOUS = "continuous"
    BINARY = "binary"
    CATEGORICAL = "categorical"
    ORDINAL = "ordinal"
    NOMINAL = "nominal"
    KEY = "key"              # Primary/foreign key
    TIMESTAMP = "timestamp"
    TEXT = "text"
    MIXED = "mixed"


class ColumnRole(str, Enum):
    """
    Business Logic: Semantic role of a column in the AML pipeline.
    """
    CUSTOMER_ID = "customer_id"
    ACCOUNT_ID = "account_id"
    TRANSACTION_ID = "transaction_id"
    AMOUNT = "amount"
    TIMESTAMP = "timestamp"
    RISK_SCORE = "risk_score"
    CATEGORY = "category"
    FLAG = "flag"
    NAME = "name"
    COUNTRY = "country"
    FEATURE = "feature"
    LABEL = "label"
    OTHER = "other"


# =============================================================================
# COLUMN MAPPING (Dynamic Schema)
# =============================================================================
class ColumnMapping(BaseModel):
    """
    Business Logic: Maps a CSV column name to a data type and semantic role.
    This is the core of the "Mapping Interface" — users define how each
    column in their data should be treated by the pipeline.

    Technical Implementation: Stored as JSON alongside uploaded data.
    """
    column_name: str = Field(..., description="Original column name from CSV")
    display_name: Optional[str] = Field(None, description="User-friendly display name")
    data_type: ColumnDataType = Field(ColumnDataType.MIXED, description="Data type classification")
    role: ColumnRole = Field(ColumnRole.OTHER, description="Semantic role in pipeline")
    is_key: bool = Field(False, description="Whether this is a primary/foreign key")
    is_feature: bool = Field(True, description="Whether to include in feature engineering")
    description: Optional[str] = Field(None, description="User annotation")


class MappingRegistry(BaseModel):
    """
    Business Logic: Registry of all column mappings for a data source.
    Allows complete customization of how uploaded data is interpreted.

    Technical Implementation: Serialized to JSON and stored alongside data.
    """
    source_name: str
    mappings: List[ColumnMapping] = Field(default_factory=list)
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    updated_at: Optional[str] = None

    def get_columns_by_role(self, role: ColumnRole) -> List[str]:
        """Get column names matching a role."""
        return [m.column_name for m in self.mappings if m.role == role]

    def get_columns_by_type(self, dtype: ColumnDataType) -> List[str]:
        """Get column names matching a data type."""
        return [m.column_name for m in self.mappings if m.data_type == dtype]

    def get_key_columns(self) -> List[str]:
        """Get all key columns."""
        return [m.column_name for m in self.mappings if m.is_key]

    def get_feature_columns(self) -> List[str]:
        """Get all columns marked as features."""
        return [m.column_name for m in self.mappings if m.is_feature and not m.is_key]

    def to_dict(self) -> Dict[str, ColumnMapping]:
        """Return mapping as column_name -> ColumnMapping dict."""
        return {m.column_name: m for m in self.mappings}


# =============================================================================
# TABLE SCHEMAS
# =============================================================================
class CustomerRecord(BaseModel):
    """
    Business Logic: Core customer entity. Every node in the graph is a customer.
    Technical Implementation: Flexible — only customer_id is truly required.
    """
    customer_id: str
    name: Optional[str] = None
    customer_type: Optional[str] = None  # individual, corporate, etc.
    country: Optional[str] = None
    registration_date: Optional[str] = None
    risk_rating: Optional[int] = None
    status: Optional[str] = None
    segment: Optional[str] = None
    annual_income: Optional[float] = None
    occupation: Optional[str] = None

    @field_validator("risk_rating", mode="before")
    @classmethod
    def validate_risk_rating(cls, v):
        if v is not None:
            v = int(v)
            if not (0 <= v <= 10):
                v = min(max(v, 0), 10)
        return v


class AccountRecord(BaseModel):
    """
    Business Logic: Bank account linked to a customer. One customer may have
    multiple accounts. Stage 2 aggregates accounts to customer level.
    """
    account_id: str
    customer_id: str
    account_type: Optional[str] = None  # checking, savings, etc.
    currency: Optional[str] = None
    balance: Optional[float] = None
    open_date: Optional[str] = None
    status: Optional[str] = None
    branch: Optional[str] = None


class KYCRecord(BaseModel):
    """
    Business Logic: Know-Your-Customer data. PEP status, sanctions screening,
    identity verification. Critical for risk scoring.
    """
    customer_id: str
    kyc_date: Optional[str] = None
    kyc_score: Optional[float] = None
    pep_status: Optional[int] = None  # 0=no, 1=yes
    sanctions_hit: Optional[int] = None
    id_verified: Optional[int] = None
    source_of_funds: Optional[str] = None
    risk_category: Optional[str] = None


class TransactionRecord(BaseModel):
    """
    Business Logic: Financial transaction — the primary edge type in the graph.
    Connects accounts (and by extension, customers) through money flow.
    """
    txn_id: Optional[str] = None
    account_id: Optional[str] = None
    customer_id: Optional[str] = None
    timestamp: Optional[str] = None
    amount: Optional[float] = None
    currency: Optional[str] = None
    transaction_type: Optional[str] = None  # WIRE, ACH, CASH, etc.
    counterparty_id: Optional[str] = None
    counterparty_country: Optional[str] = None
    channel: Optional[str] = None
    description: Optional[str] = None
    is_international: Optional[int] = None


class HistoricalRecord(BaseModel):
    """
    Business Logic: Past alerts, SARs, and investigation outcomes.
    Used for temporal pattern analysis and repeat-offender detection.
    """
    record_id: Optional[str] = None
    customer_id: str
    event_type: Optional[str] = None  # SAR, STR, EDD, alert, case
    event_date: Optional[str] = None
    outcome: Optional[str] = None  # TP, FP, pending
    risk_score_at_time: Optional[float] = None
    narrative: Optional[str] = None
    filed_by: Optional[str] = None


class AlertRecord(BaseModel):
    """
    Business Logic: System-generated or manual alerts flagging suspicious
    activity. Feeds into the investigation queue and SAR decisions.
    """
    alert_id: Optional[str] = None
    customer_id: str
    alert_date: Optional[str] = None
    alert_type: Optional[str] = None  # TM, SAR, MAN
    severity: Optional[str] = None
    status: Optional[str] = None  # Open, Closed, Escalated
    score: Optional[float] = None
    rule_triggered: Optional[str] = None
    assigned_to: Optional[str] = None


class RelationshipRecord(BaseModel):
    """
    Business Logic: Explicit relationships between entities, e.g., shared
    addresses, beneficial ownership, corporate links. Used in Stage 3-4
    to build similarity edges in the graph.
    """
    source_id: str
    target_id: str
    relationship_type: Optional[str] = None  # shared_address, beneficial_owner, etc.
    strength: Optional[float] = Field(None, ge=0.0, le=1.0)
    start_date: Optional[str] = None
    end_date: Optional[str] = None


# =============================================================================
# DATA QUALITY REPORT
# =============================================================================
class DataQualityReport(BaseModel):
    """
    Business Logic: Output of Stage 1 validation — scores data completeness,
    consistency, and validity. Displayed on the Port Authority page.
    """
    source_name: str
    total_rows: int
    total_columns: int
    completeness: float = Field(..., ge=0.0, le=1.0)
    consistency: float = Field(..., ge=0.0, le=1.0)
    validity: float = Field(..., ge=0.0, le=1.0)
    overall_score: float = Field(..., ge=0.0, le=1.0)
    issues: List[str] = Field(default_factory=list)
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
    column_stats: Dict[str, Dict[str, Any]] = Field(default_factory=dict)


# =============================================================================
# PIPELINE RESULT
# =============================================================================
class PipelineStageResult(BaseModel):
    """
    Business Logic: Result of a single pipeline stage execution.
    Technical Implementation: Logged to audit trail + stored in vault.
    """
    stage: int
    name: str
    success: bool
    duration_ms: float
    records_in: int
    records_out: int
    summary: Dict[str, Any] = Field(default_factory=dict)
    errors: List[str] = Field(default_factory=list)
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())


class PipelineResult(BaseModel):
    """
    Business Logic: Complete pipeline execution result across all 8 stages.
    """
    success: bool
    total_duration_ms: float
    stages: List[PipelineStageResult] = Field(default_factory=list)
    customers_processed: int = 0
    alerts_generated: int = 0
    tier_distribution: Dict[str, int] = Field(default_factory=dict)
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())


# =============================================================================
# SCHEMA REGISTRY (maps table names to model classes)
# =============================================================================
TABLE_SCHEMAS = {
    "customer": CustomerRecord,
    "account": AccountRecord,
    "kyc": KYCRecord,
    "transaction": TransactionRecord,
    "historical": HistoricalRecord,
    "alert": AlertRecord,
    "relationship": RelationshipRecord,
}
