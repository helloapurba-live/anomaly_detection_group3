"""
FCDAI Network Analyzer v9 - Memory-Efficient Pipeline Engine
==============================================================
Business Logic: Orchestrates the 8-stage AML detection pipeline with
SQLite-backed persistence, live progress tracking, cycle/ring detection,
lobby analysis, and config file override support.

v9: Memory-efficient architecture for 8GB RAM. GC flush between stages,
float32 quantization, approx algorithms, MinHash LSH, K-Shortest Paths.
Port 8079. Auto-generate 10 customers sample data.
"""

import pandas as pd
import numpy as np
import networkx as nx
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
import time
import json
import sys
import gc
import threading

sys.path.insert(0, str(Path(__file__).parent))
from config import PATHS, PIPELINE, APP
from layers.l0_ingest import IngestLayer
from layers.l1_validate import ValidateLayer
from layers.l2_aggregate import AggregateLayer
from layers.l3_graph import GraphConstructionLayer
from layers.l5_analytics import AnalyticsLayer
from layers.l6_scoring import ScoringLayer
from layers.l7_reporting import ReportingLayer
from models.schemas import PipelineStageResult, PipelineResult
from utils.logger import log_audit, log_error
from utils.persistence import store_or_load, get_vault
from database import get_db


# =============================================================================
# PIPELINE PROGRESS TRACKER
# =============================================================================
class PipelineProgress:
    """Thread-safe pipeline progress tracker for live dashboard updates."""

    STAGES = [
        {"id": 0, "name": "Ingest & Validate", "weight": 15},
        {"id": 1, "name": "Aggregation", "weight": 10},
        {"id": 2, "name": "Graph Construction", "weight": 15},
        {"id": 3, "name": "Analytics (7-Family)", "weight": 35},
        {"id": 4, "name": "Risk Scoring", "weight": 15},
        {"id": 5, "name": "Reporting & Persist", "weight": 10},
    ]

    def __init__(self):
        self._lock = threading.Lock()
        self.reset()

    def reset(self):
        with self._lock:
            self._running = False
            self._current_stage = -1
            self._stage_status = {}
            self._overall_pct = 0
            self._message = "Idle"
            self._start_time = None
            self._stage_times = {}
            self.stop_requested = False

    def start(self):
        with self._lock:
            self._running = True
            self._current_stage = 0
            self._overall_pct = 0
            self._message = "Starting pipeline..."
            self._start_time = time.time()
            self._stage_status = {s["id"]: "pending" for s in self.STAGES}
            self._stage_times = {}

    def update_stage(self, stage_id: int, status: str, message: str = ""):
        with self._lock:
            self._current_stage = stage_id
            self._stage_status[stage_id] = status
            self._message = message or f"Running {self.STAGES[stage_id]['name']}..."
            if status == "running":
                self._stage_times[stage_id] = {"start": time.time()}
            elif status == "done":
                if stage_id in self._stage_times:
                    self._stage_times[stage_id]["end"] = time.time()
                # Calculate overall percentage
                done_weight = sum(s["weight"] for s in self.STAGES
                                  if self._stage_status.get(s["id"]) == "done")
                self._overall_pct = min(done_weight, 100)

    def finish(self, success: bool = True):
        with self._lock:
            self._running = False
            self._overall_pct = 100 if success else self._overall_pct
            self._message = "Pipeline complete!" if success else "Pipeline failed"

    def get_status(self) -> Dict:
        with self._lock:
            elapsed = (time.time() - self._start_time) if self._start_time else 0
            return {
                "running": self._running,
                "current_stage": self._current_stage,
                "overall_pct": self._overall_pct,
                "message": self._message,
                "elapsed_sec": round(elapsed, 1),
                "stages": [
                    {
                        "id": s["id"],
                        "name": s["name"],
                        "status": self._stage_status.get(s["id"], "pending"),
                        "duration": round(
                            self._stage_times.get(s["id"], {}).get("end", time.time()) -
                            self._stage_times.get(s["id"], {}).get("start", time.time()), 1
                        ) if s["id"] in self._stage_times else 0,
                    }
                    for s in self.STAGES
                ],
            }


# ---- Optional igraph for fast cycle/node detection ----
try:
    import igraph as ig
    _HAS_IGRAPH = True
except ImportError:
    _HAS_IGRAPH = False


class FCDAIPipeline:
    """
    Business Logic: Main 8-stage pipeline orchestrator.
    v9: Memory-efficient with gc.collect flush between stages, float32, 8GB RAM safe.
    """

    def __init__(self):
        """Initialize all pipeline layers."""
        self.ingest = IngestLayer()
        self.validate = ValidateLayer()
        self.aggregate = AggregateLayer()
        self.graph = GraphConstructionLayer()
        self.analytics = AnalyticsLayer()
        self.scoring = ScoringLayer()
        self.reporting = ReportingLayer()

        # Pipeline state
        self.tables: Dict[str, pd.DataFrame] = {}
        self.customer_features: Optional[pd.DataFrame] = None
        self.edges: Optional[pd.DataFrame] = None
        self.G: Optional[nx.DiGraph] = None
        self.analytics_results: Dict[str, pd.DataFrame] = {}
        self.scored_df: Optional[pd.DataFrame] = None
        self.reports: Dict[str, Any] = {}
        self.stage_results: List[PipelineStageResult] = []
        self.last_run_meta: Dict[str, Any] = {}
        self._current_run_id: Optional[int] = None

        # v5: Progress tracker
        self.progress = PipelineProgress()

        # v5: Cycle/Ring cache
        self._cycles_cache: Optional[List] = None
        self._lobbies_cache: Optional[List] = None
        self._important_nodes_cache: Optional[pd.DataFrame] = None

        # v5: Run version counter (incremented on each successful run)
        self.run_version: int = 0

    # =========================================================================
    # CONFIG FILE OVERRIDE (v5)
    # =========================================================================
    def load_config_overrides(self) -> Dict:
        """Load runtime overrides from pipeline_config.json if it exists."""
        config_path = PATHS.BASE / "pipeline_config.json"
        if config_path.exists():
            try:
                with open(config_path, "r") as f:
                    overrides = json.load(f)
                log_audit("CONFIG_OVERRIDE", f"Loaded overrides: {list(overrides.keys())}")
                return overrides
            except Exception as e:
                log_error(f"Failed to load config overrides: {e}")
        return {}

    def save_config(self, config: Dict):
        """Save current config to pipeline_config.json."""
        config_path = PATHS.BASE / "pipeline_config.json"
        try:
            with open(config_path, "w") as f:
                json.dump(config, f, indent=2)
            log_audit("CONFIG_SAVE", f"Saved config: {list(config.keys())}")
        except Exception as e:
            log_error(f"Failed to save config: {e}")

    # =========================================================================
    # PERSISTENCE — Save / Load via SQLite
    # =========================================================================
    def save_last_run(self):
        """Save current pipeline state to SQLite for persistence across restarts."""
        try:
            db = get_db()
            if self._current_run_id is None:
                self._current_run_id = db.start_run(
                    self.last_run_meta.get("max_customers", 500)
                )

            customers = len(self.scored_df) if self.scored_df is not None else 0
            nodes = self.G.number_of_nodes() if self.G is not None else 0
            edges = self.G.number_of_edges() if self.G is not None else 0
            duration = self.last_run_meta.get("duration_sec", 0)

            db.finish_run(
                self._current_run_id, duration, customers, nodes, edges,
                status="success", meta=self.last_run_meta,
            )
            if self.tables:
                db.save_raw_tables(self._current_run_id, self.tables)
            if self.scored_df is not None:
                db.save_scored(self._current_run_id, self.scored_df)
            if self.analytics_results:
                db.save_analytics(self._current_run_id, self.analytics_results)
            if self.G is not None:
                db.save_graph(self._current_run_id, self.G)
            if self.reports:
                db.save_reports(self._current_run_id, self.reports)

            log_audit("PERSIST_SAVE", f"Run {self._current_run_id} saved to SQLite: "
                      f"{customers} customers, {nodes} nodes")
        except Exception as e:
            log_error(f"Failed to save run: {e}", exc=e)

    def load_last_run(self) -> bool:
        """Load last run from SQLite. Returns True if data was loaded."""
        try:
            db = get_db()
            data = db.load_latest_run()
            if not data:
                return False

            run_info = data["run_info"]
            self.last_run_meta = {
                "saved_at": run_info.get("finished_at", ""),
                "customers": run_info.get("customers", 0),
                "graph_nodes": run_info.get("nodes", 0),
                "graph_edges": run_info.get("edges", 0),
                "run_id": run_info.get("run_id"),
                "families": list(data.get("analytics", {}).keys()),
            }

            if data.get("scored_df") is not None:
                self.scored_df = data["scored_df"]
            if data.get("graph") is not None:
                self.G = data["graph"]
                self.graph.graph = self.G
                self.graph.node_count = self.G.number_of_nodes()
                self.graph.edge_count = self.G.number_of_edges()
            if data.get("analytics"):
                self.analytics_results = data["analytics"]
                self.analytics.results = self.analytics_results
            if data.get("raw_tables"):
                self.tables = data["raw_tables"]
            if data.get("reports"):
                self.reports = data["reports"]

            # Invalidate detection caches
            self._cycles_cache = None
            self._lobbies_cache = None
            self._important_nodes_cache = None

            log_audit("PERSIST_LOAD",
                      f"Loaded run {run_info.get('run_id')}: "
                      f"{run_info.get('customers', 0)} customers")
            return True
        except Exception as e:
            log_error(f"Failed to load last run: {e}", exc=e)
            return False

    # =========================================================================
    # PIPELINE RUN (v5: with progress tracking)
    # =========================================================================
    def run(
        self,
        sources: Dict[str, pd.DataFrame] = None,
        analytics_params: Dict[str, Any] = None,
        scoring_weights: Dict[str, float] = None,
        start_stage: int = 0,
        max_customers: int = 10,
    ) -> PipelineResult:
        """Execute the full pipeline with progress tracking and memory flush."""
        log_audit("PIPELINE_START",
                  f"Stage {start_stage} | Max customers: {max_customers}")
        start_time = time.time()
        self.stage_results = []
        # v5: Start progress tracking
        self.progress.start()

        # Load config overrides
        overrides = self.load_config_overrides()
        if overrides.get("scoring_weights"):
            scoring_weights = overrides["scoring_weights"]
        if overrides.get("max_customers"):
            max_customers = overrides["max_customers"]

        # Create a new run in SQLite
        db = get_db()
        self._current_run_id = db.start_run(max_customers)

        success = True  # v9: assume success, set False on critical failure

        # v9: Each stage wrapped individually — one failure doesn't block the rest
        if start_stage <= 1:
            try:
                self.progress.update_stage(0, "running", "Ingesting & validating data...")
                self._run_stage_01(sources, max_customers)
                self.progress.update_stage(0, "done")
            except Exception as e:
                log_error(f"Stage 0-1 failed: {e}", exc=e)
                success = False
            gc.collect()

        if success and start_stage <= 2:
            try:
                self.progress.update_stage(1, "running", "Aggregating features...")
                self._run_stage_2()
                self.progress.update_stage(1, "done")
            except Exception as e:
                log_error(f"Stage 2 failed: {e}", exc=e)
                success = False
            gc.collect()

        if success and start_stage <= 4:
            try:
                self.progress.update_stage(2, "running", "Building transaction graph...")
                self._run_stage_34()
                self.progress.update_stage(2, "done")
            except Exception as e:
                log_error(f"Stage 3-4 failed: {e}", exc=e)
                success = False
            gc.collect()

        if success and start_stage <= 5:
            try:
                self.progress.update_stage(3, "running", "Running 7-family analytics...")
                self._run_stage_5(analytics_params)
                self.progress.update_stage(3, "done")
            except Exception as e:
                log_error(f"Stage 5 failed: {e}", exc=e)
                success = False
            gc.collect()

        if success and start_stage <= 6:
            try:
                self.progress.update_stage(4, "running", "Scoring risk...")
                self._run_stage_68(scoring_weights)
                self.progress.update_stage(4, "done")
            except Exception as e:
                log_error(f"Stage 6-8 failed: {e}", exc=e)
                success = False
            gc.collect()

        # v5: Persist stage
        self.progress.update_stage(5, "running", "Saving results...")

        total_time = (time.time() - start_time) * 1000
        duration_sec = (time.time() - start_time)

        tier_dist = self.scoring.get_tier_distribution() if self.scored_df is not None else {}
        result = PipelineResult(
            success=success,
            total_duration_ms=round(total_time, 1),
            stages=self.stage_results,
            customers_processed=len(self.scored_df) if self.scored_df is not None else 0,
            alerts_generated=len(self.reports.get("narratives", {})) if self.reports else 0,
            tier_distribution=tier_dist,
        )

        if success:
            self.last_run_meta.update({
                "max_customers": max_customers,
                "duration_sec": round(duration_sec, 2),
                "tier_distribution": tier_dist,
                "saved_at": datetime.now().isoformat(),
                "customers": len(self.scored_df) if self.scored_df is not None else 0,
            })
            self.save_last_run()
            self.run_version += 1  # v5: increment run version

            # v5: Invalidate detection caches
            self._cycles_cache = None
            self._lobbies_cache = None
            self._important_nodes_cache = None

        else:
            db.finish_run(self._current_run_id, duration_sec, 0, 0, 0, status="failed")

        self.progress.update_stage(5, "done")
        self.progress.finish(success)

        log_audit("PIPELINE_COMPLETE",
                  f"Success={success} | Duration={total_time:.0f}ms | "
                  f"Customers={result.customers_processed} | Tiers={tier_dist}")
        return result

    def _run_stage_01(self, sources=None, max_customers: int = 10):
        """Stage 0-1: Ingest & Validate with customer limit. v9: default 10."""
        t0 = time.time()
        if sources:
            self.tables = sources
        else:
            from utils.sample_data import generate_all_samples
            self.tables = generate_all_samples(
                n_customers=max_customers,
                n_transactions=max_customers * 5,
            )

        records_in = sum(len(df) for df in self.tables.values())
        dq_reports = self.validate.assess_all(self.tables)
        for name in list(self.tables.keys()):
            self.tables[name] = self.validate.cleanse(self.tables[name])
        records_out = sum(len(df) for df in self.tables.values())

        self.stage_results.append(PipelineStageResult(
            stage=1, name="Ingest & Validate", success=True,
            duration_ms=round((time.time() - t0) * 1000, 1),
            records_in=records_in, records_out=records_out,
            summary={"tables": len(self.tables),
                     "overall_dq": self.validate.get_overall_report().get("overall_score", 0)}
        ))

    def _run_stage_2(self):
        """Stage 2: Aggregation."""
        t0 = time.time()
        records_in = sum(len(df) for df in self.tables.values())
        self.customer_features, self.edges = self.aggregate.run(self.tables)
        self.stage_results.append(PipelineStageResult(
            stage=2, name="Aggregation", success=True,
            duration_ms=round((time.time() - t0) * 1000, 1),
            records_in=records_in, records_out=len(self.customer_features),
            summary=self.aggregate.get_summary()
        ))

    def _run_stage_34(self):
        """Stage 3-4: Graph Construction. v9: handles empty data."""
        t0 = time.time()
        # v9: Create empty graph if no data (don't crash)
        if self.customer_features is None:
            self.customer_features = pd.DataFrame({"customer_id": []})
        if self.edges is None:
            self.edges = pd.DataFrame(columns=["source", "target", "weight", "txn_count", "edge_type"])
        self.G = self.graph.build(self.customer_features, self.edges)
        self.stage_results.append(PipelineStageResult(
            stage=4, name="Graph Construction", success=True,
            duration_ms=round((time.time() - t0) * 1000, 1),
            records_in=len(self.customer_features),
            records_out=self.graph.node_count,
            summary=self.graph.get_summary()
        ))

    def _run_stage_5(self, params=None):
        """Stage 5: Analytics. v9: handles empty graph."""
        t0 = time.time()
        if self.G is None:
            self.G = nx.DiGraph()  # v9: empty graph, don't crash
        self.analytics_results = self.analytics.run_all(self.G, params)
        self.stage_results.append(PipelineStageResult(
            stage=5, name="Analytics (7-Family)", success=True,
            duration_ms=round((time.time() - t0) * 1000, 1),
            records_in=self.G.number_of_nodes(),
            records_out=self.G.number_of_nodes(),
            summary=self.analytics.get_summary()
        ))

    def run_single_family(self, family_name: str, params: Dict = None) -> pd.DataFrame:
        """Run a single analytics family and update results."""
        if self.G is None:
            raise ValueError("Pipeline must be run first to build the graph")
        family_map = {
            "centrality": self.analytics._centrality,
            "community": self.analytics._community,
            "pathflow": self.analytics._pathflow,
            "link_prediction": self.analytics._link_prediction,
            "anomaly": self.analytics._anomaly,
            "temporal": self.analytics._temporal,
            "multi_layer": self.analytics._multi_layer,
        }
        func = family_map.get(family_name)
        if func is None:
            raise ValueError(f"Unknown family: {family_name}")
        family_params = {**self.analytics.analytics_config.get(family_name, {}),
                        **(params or {})}
        df = func(self.G, family_params)
        self.analytics_results[family_name] = df
        self.analytics.results[family_name] = df
        try:
            if self._current_run_id or self.last_run_meta.get("run_id"):
                db = get_db()
                run_id = self._current_run_id or self.last_run_meta.get("run_id")
                db.save_analytics(run_id, {family_name: df})
        except Exception:
            pass
        return df

    def _run_stage_68(self, weights=None):
        """Stage 6-8: Scoring & Reporting."""
        t0 = time.time()
        self.scored_df = self.scoring.score(self.analytics_results, weights)
        if self.G is not None and self.scored_df is not None:
            for _, row in self.scored_df.iterrows():
                nid = row["node_id"]
                if nid in self.G.nodes:
                    self.G.nodes[nid]["risk_score"] = row["risk_score"]
                    self.G.nodes[nid]["risk_tier"] = row["risk_tier"]
        self.reports = self.reporting.generate_reports(
            self.scored_df, self.G, self.analytics_results)
        self.stage_results.append(PipelineStageResult(
            stage=8, name="Scoring & Reporting", success=True,
            duration_ms=round((time.time() - t0) * 1000, 1),
            records_in=len(self.scored_df) if self.scored_df is not None else 0,
            records_out=len(self.reports.get("narratives", {})) if self.reports else 0,
            summary=self.scoring.get_summary()
        ))

    # =========================================================================
    # v5: CYCLE DETECTION
    # =========================================================================
    def detect_cycles(self, max_length: int = 6, max_results: int = 50) -> List[Dict]:
        """
        v6: Detect transaction cycles using igraph C-backend (100x faster).
        Falls back to NetworkX if igraph unavailable.
        """
        if self._cycles_cache is not None:
            return self._cycles_cache

        if self.G is None or self.G.number_of_nodes() == 0:
            return []

        try:
            raw_cycles = []

            if _HAS_IGRAPH:
                # igraph C-backend cycle detection
                nodes_list = list(self.G.nodes())
                node_map = {n: i for i, n in enumerate(nodes_list)}
                edges = [(node_map[u], node_map[v]) for u, v in self.G.edges()
                         if u in node_map and v in node_map]
                g = ig.Graph(n=len(nodes_list), edges=edges, directed=True)
                g.vs["name"] = nodes_list

                # Use igraph subgraph_edges + DFS for small cycles
                for v_id in range(min(g.vcount(), 500)):
                    if len(raw_cycles) >= max_results * 3:
                        break
                    # BFS neighborhood
                    nbs = g.neighborhood(v_id, order=max_length, mode="out")
                    if len(nbs) < 3:
                        continue
                    sub = g.subgraph(nbs)
                    # Find cycles in subgraph using igraph
                    try:
                        for edge in sub.es:
                            s, t = edge.source, edge.target
                            try:
                                paths = sub.get_all_shortest_paths(t, to=s, mode="out")
                                for p in paths:
                                    if len(p) >= 2 and len(p) + 1 <= max_length:
                                        cycle_ids = [sub.vs[i]["name"] for i in p]
                                        if len(set(cycle_ids)) >= 3:
                                            raw_cycles.append(cycle_ids)
                                            if len(raw_cycles) >= max_results * 3:
                                                break
                            except Exception:
                                continue
                    except Exception:
                        continue
            else:
                # NetworkX fallback
                for cycle in nx.simple_cycles(self.G, length_bound=max_length):
                    if len(raw_cycles) >= max_results * 3:
                        break
                    if len(cycle) >= 3:
                        raw_cycles.append(cycle)

            # Deduplicate and build results
            seen = set()
            cycles = []
            count = 0
            for cycle in raw_cycles:
                key = tuple(sorted(cycle))
                if key in seen:
                    continue
                seen.add(key)
                if count >= max_results:
                    break

                total_amount = 0
                risk_sum = 0
                edges_info = []
                for i in range(len(cycle)):
                    src = cycle[i]
                    dst = cycle[(i + 1) % len(cycle)]
                    edge_data = self.G.get_edge_data(src, dst, default={})
                    amt = edge_data.get("weight", edge_data.get("amount", 0))
                    total_amount += amt
                    risk = self.G.nodes.get(src, {}).get("risk_score", 0) or 0
                    risk_sum += risk
                    edges_info.append({"from": src, "to": dst, "amount": amt})

                avg_risk = risk_sum / len(cycle) if cycle else 0
                cycles.append({
                    "cycle_id": count + 1,
                    "nodes": cycle,
                    "length": len(cycle),
                    "total_amount": round(total_amount, 2),
                    "avg_risk": round(avg_risk, 2),
                    "risk_sum": round(risk_sum, 2),
                    "edges": edges_info,
                    "initiator": cycle[0],
                })
                count += 1

            cycles.sort(key=lambda x: x["risk_sum"], reverse=True)
            self._cycles_cache = cycles
            return cycles
        except Exception as e:
            log_error(f"Cycle detection failed: {e}", exc=e)
            return []

    # =========================================================================
    # v5: LOBBY / RING DETECTION
    # =========================================================================
    def detect_lobbies(self, max_rings: int = 30) -> List[Dict]:
        """
        Detect lobby structures — rings of customers passing money in circles.
        A lobby is a cycle where money flows back to the originator through intermediaries.
        """
        if self._lobbies_cache is not None:
            return self._lobbies_cache

        cycles = self.detect_cycles(max_length=8, max_results=100)
        if not cycles:
            return []

        lobbies = []
        for i, cyc in enumerate(cycles[:max_rings]):
            nodes = cyc["nodes"]
            # Determine initiator (highest out-degree in cycle)
            initiator = nodes[0]
            max_out = 0
            conduit = nodes[1] if len(nodes) > 1 else nodes[0]

            members = []
            for node in nodes:
                attrs = self.G.nodes.get(node, {})
                out_deg = self.G.out_degree(node) if node in self.G else 0
                in_deg = self.G.in_degree(node) if node in self.G else 0
                if out_deg > max_out:
                    max_out = out_deg
                    initiator = node

                members.append({
                    "node_id": node,
                    "risk_score": attrs.get("risk_score", 0) or 0,
                    "risk_tier": attrs.get("risk_tier", "P4"),
                    "in_degree": in_deg,
                    "out_degree": out_deg,
                    "in_flow": attrs.get("in_flow", 0),
                    "out_flow": attrs.get("out_flow", 0),
                })

            # Conduit = node with highest betweenness in cycle
            conduit = max(members, key=lambda m: m["in_degree"] + m["out_degree"])["node_id"]

            total_flow = sum(m["in_flow"] + m["out_flow"] for m in members)

            lobbies.append({
                "ring_id": i + 1,
                "ring_name": f"Ring {i + 1}",
                "size": len(nodes),
                "nodes": nodes,
                "members": members,
                "initiator": initiator,
                "conduit": conduit,
                "total_amount": cyc["total_amount"],
                "total_flow": round(total_flow, 2),
                "avg_risk": cyc["avg_risk"],
                "risk_sum": cyc["risk_sum"],
                "edges": cyc["edges"],
            })

        self._lobbies_cache = lobbies
        return lobbies

    # =========================================================================
    # v5: IMPORTANT NODES
    # =========================================================================
    def get_important_nodes(self, top_n: int = 50) -> pd.DataFrame:
        """
        v6: Get important nodes using igraph C-backend for PageRank + Betweenness.
        100x faster than NetworkX on large graphs.
        """
        if self._important_nodes_cache is not None:
            return self._important_nodes_cache

        if self.G is None or self.G.number_of_nodes() == 0:
            return pd.DataFrame()

        try:
            nodes = list(self.G.nodes())

            if _HAS_IGRAPH:
                # Build igraph for fast centrality
                node_map = {n: i for i, n in enumerate(nodes)}
                edges = [(node_map[u], node_map[v]) for u, v in self.G.edges()
                         if u in node_map and v in node_map]
                g = ig.Graph(n=len(nodes), edges=edges, directed=True)
                g.vs["name"] = nodes

                pr_vals = g.pagerank(damping=0.85)
                bc_vals = g.betweenness(directed=True)
                max_bc = max(bc_vals) if bc_vals and max(bc_vals) > 0 else 1
                bc_norm = [b / max_bc for b in bc_vals]

                pr = dict(zip(nodes, pr_vals))
                bc = dict(zip(nodes, bc_norm))
            else:
                pr = nx.pagerank(self.G, alpha=0.85)
                bc = nx.betweenness_centrality(self.G)

            rows = []
            for node in nodes:
                attrs = self.G.nodes[node]
                in_flow = attrs.get("in_flow", 0)
                out_flow = attrs.get("out_flow", 0)
                flow_ratio = (out_flow / in_flow) if in_flow > 0 else 0
                risk = attrs.get("risk_score", 0) or 0

                composite = (
                    pr.get(node, 0) * 30 +
                    bc.get(node, 0) * 25 +
                    min(flow_ratio, 5) * 5 +
                    (risk / 100) * 40
                )

                rows.append({
                    "node_id": node,
                    "pagerank": round(pr.get(node, 0), 6),
                    "betweenness": round(bc.get(node, 0), 6),
                    "in_degree": self.G.in_degree(node),
                    "out_degree": self.G.out_degree(node),
                    "in_flow": round(in_flow, 2),
                    "out_flow": round(out_flow, 2),
                    "flow_ratio": round(flow_ratio, 3),
                    "risk_score": round(risk, 2),
                    "risk_tier": attrs.get("risk_tier", "P4"),
                    "composite_importance": round(composite, 4),
                })

            df = pd.DataFrame(rows)
            df = df.sort_values("composite_importance", ascending=False).head(top_n)
            df = df.reset_index(drop=True)
            self._important_nodes_cache = df
            return df
        except Exception as e:
            log_error(f"Important nodes failed: {e}", exc=e)
            return pd.DataFrame()

    # =========================================================================
    # v5: NETWORK STATS
    # =========================================================================
    def get_network_stats(self) -> Dict:
        """Get comprehensive network statistics."""
        if self.G is None:
            return {}
        try:
            return {
                "nodes": self.G.number_of_nodes(),
                "edges": self.G.number_of_edges(),
                "density": round(nx.density(self.G), 6),
                "avg_in_degree": round(sum(d for _, d in self.G.in_degree()) / max(self.G.number_of_nodes(), 1), 2),
                "avg_out_degree": round(sum(d for _, d in self.G.out_degree()) / max(self.G.number_of_nodes(), 1), 2),
                "components": nx.number_weakly_connected_components(self.G),
                "is_dag": nx.is_directed_acyclic_graph(self.G),
            }
        except Exception:
            return {"nodes": self.G.number_of_nodes(), "edges": self.G.number_of_edges()}

    # =========================================================================
    # ACCESSOR METHODS
    # =========================================================================
    def get_cytoscape_elements(self, max_nodes=1000):
        return self.graph.to_cytoscape_elements(max_nodes)

    def get_node_details(self, node_id):
        return self.graph.get_node_details(node_id)

    def get_scored_df(self):
        return self.scored_df

    def get_investigation_queue(self):
        return self.reports.get("investigation_queue")

    def get_narrative(self, node_id):
        return self.reporting.get_narrative(node_id)

    def get_risk_matrix(self):
        return self.reports.get("risk_matrix", {})

    def get_analytics_results(self):
        return self.analytics_results

    def get_family_results(self, family: str):
        return self.analytics_results.get(family)

    def get_dq_reports(self):
        return self.validate.get_overall_report()

    def get_pipeline_summary(self):
        return {
            "stages": [r.model_dump() for r in self.stage_results],
            "tables_loaded": len(self.tables),
            "customers": len(self.scored_df) if self.scored_df is not None else 0,
            "graph_nodes": self.G.number_of_nodes() if self.G is not None else 0,
            "graph_edges": self.G.number_of_edges() if self.G is not None else 0,
            "narratives": len(self.reports.get("narratives", {})) if self.reports else 0,
        }

    def get_run_history(self) -> pd.DataFrame:
        return get_db().get_run_history()

    def has_data(self) -> bool:
        return self.scored_df is not None and len(self.scored_df) > 0


# =============================================================================
# SINGLETON
# =============================================================================
_pipeline: Optional[FCDAIPipeline] = None


def get_pipeline() -> FCDAIPipeline:
    global _pipeline
    if _pipeline is None:
        _pipeline = FCDAIPipeline()
    return _pipeline


def run_pipeline(**kwargs) -> PipelineResult:
    return get_pipeline().run(**kwargs)
