"""
Page: Lobby Analysis (v5 NEW)
================================
Business Logic: Ring/lobby detection for AML investigations.
Identifies groups of customers passing money in circles (lobbying patterns).
Shows per-ring detail: initiator, conduit, members, amounts, money trail.

Export: CSV metrics, PNG graph download.
Filters: Customer ID/Name, Ring number, Node.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update, dash_table
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import math
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME
from engine import get_pipeline

dash.register_page(__name__, path="/lobby-analysis", name="Lobby Analysis",
                   title="FCDAI v5 | Lobby Analysis")

TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}
RING_COLORS = ["#FF1744", "#9D4EDD", "#00D4FF", "#FF9800", "#00E676",
               "#FFD600", "#E040FB", "#2196F3", "#26C6DA", "#AB47BC"]


def empty_fig(msg="Run pipeline first"):
    fig = go.Figure()
    fig.add_annotation(text=msg, showarrow=False, font=dict(color="#64748B", size=14))
    fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      margin=dict(l=20, r=20, t=20, b=20))
    return fig


def ring_card(lobby, idx):
    """Create a detail card for a single ring/lobby."""
    color = RING_COLORS[idx % len(RING_COLORS)]
    members = lobby["members"]

    member_rows = []
    for m in members:
        is_initiator = m["node_id"] == lobby["initiator"]
        is_conduit = m["node_id"] == lobby["conduit"]
        role = "🔴 Initiator" if is_initiator else ("🔵 Conduit" if is_conduit else "Member")
        member_rows.append({
            "Node": m["node_id"],
            "Role": role,
            "Risk": f"{m['risk_score']:.1f}",
            "Tier": m["risk_tier"],
            "In-Flow": f"${m['in_flow']:,.0f}",
            "Out-Flow": f"${m['out_flow']:,.0f}",
            "In°": m["in_degree"],
            "Out°": m["out_degree"],
        })

    edge_rows = [
        {"From": e["from"], "To": e["to"], "Amount": f"${e['amount']:,.0f}"}
        for e in lobby["edges"]
    ]

    return dmc.Paper([
        # Ring header
        dmc.Group([
            dmc.ThemeIcon(
                DashIconify(icon="mdi:circle-double", width=20),
                color=color, variant="light", size="lg", radius="md",
            ),
            dmc.Stack([
                dmc.Text(lobby["ring_name"], fw=700, c="white", size="md"),
                dmc.Text(f"{lobby['size']} members · ${lobby['total_amount']:,.0f} total",
                         size="xs", c="dimmed"),
            ], gap=0),
            dmc.Stack([
                dmc.Badge(f"Avg Risk: {lobby['avg_risk']:.1f}",
                          color="red" if lobby["avg_risk"] > 50 else "orange",
                          variant="light", size="sm"),
                dmc.Badge(f"Flow: ${lobby['total_flow']:,.0f}", color="cyan",
                          variant="light", size="sm"),
            ], gap=2),
        ], gap="sm", mb="md"),

        # Key actors
        dmc.Group([
            dmc.Paper([
                dmc.Text("Initiator", size="xs", c="dimmed"),
                dmc.Text(lobby["initiator"], size="sm", fw=600, c="#FF1744"),
            ], p="xs", radius="md", style={"backgroundColor": "rgba(255,23,68,0.08)",
                                            "border": "1px solid rgba(255,23,68,0.2)"}),
            dmc.Paper([
                dmc.Text("Conduit", size="xs", c="dimmed"),
                dmc.Text(lobby["conduit"], size="sm", fw=600, c="#00D4FF"),
            ], p="xs", radius="md", style={"backgroundColor": "rgba(0,212,255,0.08)",
                                            "border": "1px solid rgba(0,212,255,0.2)"}),
            dmc.Paper([
                dmc.Text("Path", size="xs", c="dimmed"),
                dmc.Text(" → ".join(lobby["nodes"][:6]) + (" →..." if len(lobby["nodes"]) > 6 else " → ⟲"),
                         size="xs", fw=500, c="#FFD600"),
            ], p="xs", radius="md", style={"backgroundColor": "rgba(255,214,0,0.08)",
                                            "border": "1px solid rgba(255,214,0,0.2)",
                                            "flex": "1"}),
        ], gap="sm", mb="md"),

        # Members + Edges tables
        dmc.SimpleGrid(cols={"base": 1, "md": 2}, spacing="md", children=[
            dmc.Stack([
                dmc.Text("Members", fw=600, c="white", size="xs"),
                dash_table.DataTable(
                    columns=[{"name": k, "id": k} for k in member_rows[0].keys()],
                    data=member_rows,
                    style_header={"backgroundColor": "#111827", "color": "#94A3B8",
                                  "fontWeight": "600", "border": "1px solid #1E293B",
                                  "fontSize": "10px"},
                    style_cell={"backgroundColor": "#0A0E17", "color": "#E2E8F0",
                                "border": "1px solid #1E293B", "fontSize": "10px",
                                "padding": "4px 6px"},
                    style_data_conditional=[
                        {"if": {"filter_query": '{Role} contains "Initiator"'},
                         "color": "#FF1744", "fontWeight": "bold"},
                        {"if": {"filter_query": '{Role} contains "Conduit"'},
                         "color": "#00D4FF", "fontWeight": "bold"},
                        {"if": {"column_id": "Tier", "filter_query": '{Tier} = "P1"'},
                         "color": "#FF1744"},
                    ],
                ),
            ], gap=4),
            dmc.Stack([
                dmc.Text("Money Flow Edges", fw=600, c="white", size="xs"),
                dash_table.DataTable(
                    columns=[{"name": k, "id": k} for k in edge_rows[0].keys()] if edge_rows else [],
                    data=edge_rows,
                    style_header={"backgroundColor": "#111827", "color": "#94A3B8",
                                  "fontWeight": "600", "border": "1px solid #1E293B",
                                  "fontSize": "10px"},
                    style_cell={"backgroundColor": "#0A0E17", "color": "#E2E8F0",
                                "border": "1px solid #1E293B", "fontSize": "10px",
                                "padding": "4px 6px"},
                ),
            ], gap=4),
        ]),
    ], p="lg", radius="lg", className="glass-card ring-card", mb="md",
       style={"borderLeft": f"4px solid {color}"})


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Box([
    dcc.Interval(id="la-init", interval=1000, max_intervals=1),
    dcc.Download(id="la-download"),

    # Header
    dmc.Group([
        dmc.Stack([
            dmc.Title("Lobby Analysis", order=2, c="white"),
            dmc.Text("Ring Detection · Money Trail · Initiator Analysis", c="dimmed", size="sm"),
        ], gap=2),
        dmc.Group([
            dcc.Link(dmc.Button("← Dashboard", size="xs", variant="subtle", color="gray"),
                     href="/", style={"textDecoration": "none"}),
            dcc.Link(dmc.Button("Network Intel →", size="xs", variant="light", color="cyan"),
                     href="/network-intelligence", style={"textDecoration": "none"}),
        ], gap="sm"),
    ], justify="space-between", mb="lg"),

    # =================== FILTERS ===================
    dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:filter-outline", width=18, color=THEME.PRIMARY),
            dmc.Text("Filters", fw=600, c="white", size="sm"),
        ], gap="sm", mb="sm"),
        dmc.SimpleGrid(cols={"base": 1, "md": 5}, spacing="sm", children=[
            dmc.TextInput(id="la-filter-custid", placeholder="Customer ID / Name...",
                          leftSection=DashIconify(icon="mdi:magnify", width=16),
                          styles={"input": {"backgroundColor": THEME.DARK_BG,
                                           "color": "white", "border": f"1px solid {THEME.DARK_BORDER}"}}),
            dmc.NumberInput(id="la-filter-ring", placeholder="Ring #", min=1, max=100,
                           leftSection=DashIconify(icon="mdi:circle-outline", width=16),
                           styles={"input": {"backgroundColor": THEME.DARK_BG,
                                            "color": "white", "border": f"1px solid {THEME.DARK_BORDER}"}}),
            dmc.TextInput(id="la-filter-node", placeholder="Node ID...",
                          leftSection=DashIconify(icon="mdi:graph", width=16),
                          styles={"input": {"backgroundColor": THEME.DARK_BG,
                                           "color": "white", "border": f"1px solid {THEME.DARK_BORDER}"}}),
            dmc.Button("Apply", id="la-apply-filters", color="cyan", variant="light",
                       leftSection=DashIconify(icon="mdi:filter-check", width=16)),
            dmc.Group([
                dmc.Button("⬇ CSV", id="la-export-csv", size="xs", variant="light", color="green",
                           leftSection=DashIconify(icon="mdi:download", width=14)),
                dmc.Button("⬇ PNG", id="la-export-png", size="xs", variant="light", color="blue",
                           leftSection=DashIconify(icon="mdi:image", width=14)),
            ], gap="xs"),
        ]),
    ], p="lg", radius="lg", className="glass-card", mb="md"),

    # =================== SUMMARY STATS ===================
    dmc.SimpleGrid(cols={"base": 2, "md": 4}, spacing="md", mb="md", id="la-summary-stats",
                   children=[]),

    # =================== LOBBY RING GRAPH ===================
    dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:graph", width=20, color="#E040FB"),
            dmc.Text("Ring Network Visualization", fw=600, c="white"),
        ], gap="sm", mb="sm"),
        dcc.Graph(id="la-ring-graph", config={"displayModeBar": True,
                                               "toImageButtonOptions": {"format": "png", "scale": 2}},
                  style={"height": "450px"}),
    ], p="lg", radius="lg", className="glass-card", mb="md"),

    # =================== RING DETAIL CARDS ===================
    html.Div(id="la-ring-cards"),
])


# =============================================================================
# CALLBACKS
# =============================================================================

@callback(
    Output("la-summary-stats", "children"),
    Output("la-ring-graph", "figure"),
    Output("la-ring-cards", "children"),
    Input("la-init", "n_intervals"),
    Input("pipeline-state", "data"),
    Input("la-apply-filters", "n_clicks"),
    State("la-filter-custid", "value"),
    State("la-filter-ring", "value"),
    State("la-filter-node", "value"),
)
def update_lobby_page(_, pipeline_state, __, filter_cust, filter_ring, filter_node):
    pipeline = get_pipeline()
    if not pipeline.has_data():
        empty = dmc.Text("Run pipeline to detect lobbies", c="dimmed", size="sm")
        return [], empty_fig(), empty

    lobbies = pipeline.detect_lobbies()

    # Apply filters
    if filter_ring:
        lobbies = [lb for lb in lobbies if lb["ring_id"] == filter_ring]
    if filter_cust:
        lobbies = [lb for lb in lobbies
                   if any(filter_cust.lower() in n.lower() for n in lb["nodes"])]
    if filter_node:
        lobbies = [lb for lb in lobbies if filter_node in lb["nodes"]]

    # ── SUMMARY STATS ──
    total_rings = len(lobbies)
    total_members = sum(lb["size"] for lb in lobbies)
    total_flow = sum(lb["total_flow"] for lb in lobbies)
    avg_risk = sum(lb["avg_risk"] for lb in lobbies) / max(total_rings, 1)

    stats = [
        ("Rings Detected", f"{total_rings}", "mdi:circle-double", "#FF1744"),
        ("Total Members", f"{total_members}", "mdi:account-group", "#9D4EDD"),
        ("Total Flow", f"${total_flow:,.0f}", "mdi:cash-multiple", "#00E676"),
        ("Avg Ring Risk", f"{avg_risk:.1f}", "mdi:alert-circle", "#FF9800"),
    ]
    stat_cards = [
        dmc.Paper([
            dmc.Group([
                DashIconify(icon=icon, width=24, color=color),
                dmc.Stack([
                    dmc.Text(label, size="xs", c="dimmed"),
                    dmc.Text(value, size="lg", fw=700, c="white"),
                ], gap=0),
            ], gap="sm"),
        ], p="md", radius="lg", className="stat-card glass-card")
        for label, value, icon, color in stats
    ]

    # ── RING NETWORK GRAPH ──
    if lobbies:
        fig = go.Figure()

        for i, lobby in enumerate(lobbies[:10]):  # Show max 10 rings
            color = RING_COLORS[i % len(RING_COLORS)]
            nodes = lobby["nodes"]
            n = len(nodes)

            # Position nodes in a circle
            cx = (i % 5) * 3
            cy = (i // 5) * 3
            radius = 0.8

            pos = {}
            for j, node in enumerate(nodes):
                angle = 2 * math.pi * j / n
                pos[node] = (cx + radius * math.cos(angle), cy + radius * math.sin(angle))

            # Edges
            for e in lobby["edges"]:
                x0, y0 = pos.get(e["from"], (0, 0))
                x1, y1 = pos.get(e["to"], (0, 0))
                fig.add_trace(go.Scatter(
                    x=[x0, x1], y=[y0, y1], mode="lines",
                    line=dict(color=color, width=1.5, dash="dot" if e["amount"] < 10000 else "solid"),
                    hoverinfo="skip", showlegend=False,
                ))
                # Arrow (midpoint marker)
                mx, my = (x0 + x1) / 2, (y0 + y1) / 2
                fig.add_trace(go.Scatter(
                    x=[mx], y=[my], mode="markers",
                    marker=dict(symbol="triangle-right", size=6, color=color),
                    hovertemplate=f"${e['amount']:,.0f}<extra></extra>",
                    showlegend=False,
                ))

            # Nodes
            node_x = [pos[n][0] for n in nodes]
            node_y = [pos[n][1] for n in nodes]
            node_sizes = [12 if n == lobby["initiator"] else (10 if n == lobby["conduit"] else 7)
                          for n in nodes]
            node_symbols = ["diamond" if n == lobby["initiator"]
                           else ("square" if n == lobby["conduit"] else "circle")
                           for n in nodes]

            fig.add_trace(go.Scatter(
                x=node_x, y=node_y, mode="markers+text",
                marker=dict(color=color, size=node_sizes, symbol=node_symbols,
                            line=dict(color="white", width=1)),
                text=[n.split("_")[-1] if "_" in n else n[:8] for n in nodes],
                textposition="top center", textfont=dict(size=8, color=color),
                name=lobby["ring_name"],
                hovertemplate=[
                    f"<b>{n}</b><br>{'🔴 Initiator' if n == lobby['initiator'] else '🔵 Conduit' if n == lobby['conduit'] else 'Member'}<extra></extra>"
                    for n in nodes
                ],
            ))

        fig.update_layout(
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#94A3B8", size=11),
            margin=dict(l=20, r=20, t=30, b=20),
            xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            legend=dict(font=dict(color="#94A3B8", size=10)),
            showlegend=True,
        )
    else:
        fig = empty_fig("No lobbies detected")

    # ── RING DETAIL CARDS ──
    cards = [ring_card(lobby, i) for i, lobby in enumerate(lobbies[:15])]
    if not cards:
        cards = [dmc.Text("No lobbies match filters", c="dimmed", size="sm")]

    return stat_cards, fig, cards


@callback(
    Output("la-download", "data"),
    Input("la-export-csv", "n_clicks"),
    prevent_initial_call=True,
)
def export_lobby_csv(_):
    pipeline = get_pipeline()
    lobbies = pipeline.detect_lobbies()
    if not lobbies:
        return no_update

    import pandas as pd
    rows = []
    for lb in lobbies:
        for m in lb["members"]:
            rows.append({
                "ring_id": lb["ring_id"], "ring_name": lb["ring_name"],
                "node_id": m["node_id"],
                "role": "Initiator" if m["node_id"] == lb["initiator"]
                        else ("Conduit" if m["node_id"] == lb["conduit"] else "Member"),
                "risk_score": m["risk_score"], "risk_tier": m["risk_tier"],
                "in_flow": m["in_flow"], "out_flow": m["out_flow"],
                "ring_total_amount": lb["total_amount"],
                "ring_avg_risk": lb["avg_risk"],
            })
    df = pd.DataFrame(rows)
    return dcc.send_data_frame(df.to_csv, "lobby_analysis.csv", index=False)
