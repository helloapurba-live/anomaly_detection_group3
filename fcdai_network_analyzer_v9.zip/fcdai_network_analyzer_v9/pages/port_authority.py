"""
Page: Port Authority (v9) — Data Generation Hub
=================================================
Business Logic: Central hub for generating sample AML data or uploading
CSV files. Shows premium AG Grid previews of all tables. Generates data
that feeds into the Dashboard pipeline. All changes sync via pipeline-state.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
import dash_ag_grid as dag
from dash_iconify import DashIconify
import pandas as pd
from pathlib import Path
import sys, time

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME
from engine import get_pipeline
from utils.sample_data import generate_all_samples
from utils.logger import GlobalExceptionHandler

dash.register_page(__name__, path="/port-authority", name="Port Authority",
                   title="FCDAI | Port Authority — Data Hub")


# =============================================================================
# AG GRID THEME (dark, compact, premium)
# =============================================================================
AG_GRID_STYLE = {
    "--ag-background-color": "#0D1117",
    "--ag-header-background-color": "#161B22",
    "--ag-odd-row-background-color": "#0D1117",
    "--ag-row-hover-color": "#1C2333",
    "--ag-header-foreground-color": "#58A6FF",
    "--ag-foreground-color": "#C9D1D9",
    "--ag-border-color": "#21262D",
    "--ag-row-border-color": "#21262D",
    "--ag-font-size": "12px",
    "--ag-grid-size": "4px",
}

TABLE_INFO = [
    ("customer",    "mdi:account-group",    "#00D4FF", "Core customer profiles"),
    ("account",     "mdi:bank",             "#9D4EDD", "Customer bank accounts"),
    ("transaction", "mdi:swap-horizontal",  "#00E676", "Financial transactions"),
    ("kyc",         "mdi:file-document",    "#FFD600", "KYC compliance records"),
    ("alert",       "mdi:alert-circle",     "#FF1744", "Suspicious activity alerts"),
    ("historical",  "mdi:history",          "#FF9800", "Historical risk data"),
    ("relationship","mdi:link-variant",     "#2196F3", "Customer relationships"),
]


def make_ag_grid(df, table_name):
    """Create premium AG Grid from DataFrame."""
    if df is None or len(df) == 0:
        return dmc.Center(
            dmc.Text("No data", c="dimmed", size="sm"),
            style={"minHeight": "100px"})

    preview = df.head(5)
    columns = [{"field": col, "headerName": col.replace("_", " ").title(),
                "sortable": True, "filter": True, "resizable": True,
                "minWidth": 100} for col in preview.columns]

    return dag.AgGrid(
        rowData=preview.to_dict("records"),
        columnDefs=columns,
        defaultColDef={"flex": 1, "minWidth": 80},
        dashGridOptions={
            "animateRows": True,
            "pagination": False,
            "domLayout": "autoHeight",
        },
        style={"height": None, **AG_GRID_STYLE},
        className="ag-theme-alpine-dark",
    )


def make_table_card(name, icon, color, description, rows=0, df=None):
    """Create a premium card with AG Grid preview."""
    grid = make_ag_grid(df, name) if df is not None else dmc.Center(
        dmc.Text("Generate data to preview", c="dimmed", size="xs"),
        style={"minHeight": "80px"})

    return dmc.Paper([
        dmc.Group([
            dmc.Group([
                DashIconify(icon=icon, width=20, color=color),
                dmc.Text(name.replace("_", " ").title(), fw=600, c="white", size="sm"),
            ], gap="xs"),
            dmc.Group([
                dmc.Badge(f"{rows:,} rows", color="cyan", variant="light", size="xs")
                    if rows > 0 else dmc.Badge("empty", color="gray", variant="light", size="xs"),
                dmc.Text(description, size="xs", c="dimmed"),
            ], gap="xs"),
        ], justify="space-between", mb="sm"),
        grid,
    ], p="md", radius="lg", className="glass-card", mb="md")


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Box([
    # Header
    dmc.Group([
        dmc.Stack([
            dmc.Title("Port Authority", order=2, c="white"),
            dmc.Text("Data Generation Hub — generate or upload data for pipeline",
                     c="dimmed", size="sm"),
        ], gap=2),
        dmc.Group([
            dcc.Link(dmc.Button("← Dashboard", size="xs", variant="subtle", color="gray"),
                     href="/", style={"textDecoration": "none"}),
        ], gap="sm"),
    ], justify="space-between", mb="lg"),

    # =================== GENERATION CONTROLS ===================
    dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:database-plus", width=24, color="#00D4FF"),
            dmc.Text("Generate Sample AML Data", fw=700, c="white", size="md"),
        ], gap="sm", mb="md"),

        dmc.SimpleGrid(cols={"base": 1, "md": 3}, spacing="md", children=[
            # Customer count
            dmc.Stack([
                dmc.Text("Number of Customers", size="sm", c="dimmed", fw=500),
                dmc.NumberInput(
                    id="pa-customer-count", value=10, min=5, max=50000, step=5,
                    leftSection=DashIconify(icon="mdi:account-multiple", width=18),
                    styles={"input": {
                        "backgroundColor": THEME.DARK_BG,
                        "color": "white",
                        "border": f"1px solid {THEME.DARK_BORDER}",
                        "fontSize": "14px",
                    }},
                ),
                dmc.Text("Range: 5 – 50,000 customers", size="xs", c="dimmed"),
            ], gap=4),

            # Generate button
            dmc.Stack([
                dmc.Text("Action", size="sm", c="dimmed", fw=500),
                dmc.Button(
                    "⚡ Generate Sample Data",
                    id="pa-gen-btn",
                    size="lg",
                    variant="gradient",
                    gradient={"from": "cyan", "to": "indigo"},
                    leftSection=DashIconify(icon="mdi:database-plus", width=22),
                    fullWidth=True,
                    loading=False,
                ),
                dmc.Text("Creates all 7 tables automatically", size="xs", c="dimmed"),
            ], gap=4),

            # Status
            dmc.Stack([
                dmc.Text("Status", size="sm", c="dimmed", fw=500),
                dmc.Paper([
                    dmc.Text(id="pa-gen-status", size="sm", c="white",
                             children="Ready to generate"),
                    dmc.Text(id="pa-total-rows", size="xs", c="dimmed",
                             children="No data generated yet"),
                ], p="md", radius="md",
                    style={"backgroundColor": "rgba(0,0,0,0.3)",
                           "border": f"1px solid {THEME.DARK_BORDER}"}),
            ], gap=4),
        ]),
    ], p="lg", radius="lg", className="glass-card", mb="md"),

    # =================== DATA PREVIEW (AG Grids) ===================
    dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:table-eye", width=22, color="#00E676"),
            dmc.Text("Data Preview", fw=700, c="white", size="md"),
            dmc.Badge("Top 5 rows per table", color="green", variant="light", size="sm"),
        ], gap="sm", mb="md"),

        html.Div(id="pa-data-preview", children=[
            dmc.Center(
                dmc.Stack([
                    DashIconify(icon="mdi:database-off-outline", width=48,
                               color=THEME.TEXT_MUTED),
                    dmc.Text("No data yet — click Generate to create sample tables",
                             c="dimmed", size="sm"),
                ], align="center", gap="sm"),
                style={"minHeight": "200px"}),
        ]),
    ], p="lg", radius="lg", className="glass-card", mb="md"),

    # =================== MANUAL UPLOAD ===================
    dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:upload", width=20, color="#FFD600"),
            dmc.Text("Manual CSV Upload", fw=600, c="white", size="sm"),
            dmc.Badge("Advanced", color="yellow", variant="light", size="xs"),
        ], gap="sm", mb="md"),

        dmc.Text("Upload your own CSV files for any of the 5 core tables:",
                 size="xs", c="dimmed", mb="sm"),

        dmc.SimpleGrid(cols={"base": 2, "md": 5}, spacing="sm", children=[
            dcc.Upload(
                dmc.Button(name.title(), variant="outline", color=color,
                           size="xs", fullWidth=True,
                           leftSection=DashIconify(icon=icon, width=14)),
                id=f"upload-{name}",
                style={"width": "100%"},
            )
            for name, icon, color, _ in TABLE_INFO[:5]
        ]),
        dmc.Text(id="pa-upload-status", size="xs", c="dimmed", mt="sm"),
    ], p="lg", radius="lg", className="glass-card", mb="md"),

    # =================== NAVIGATION ===================
    dmc.Paper([
        dmc.Group([
            dmc.Text("Quick Links", size="xs", fw=600, c="dimmed"),
            dcc.Link(dmc.Badge("Dashboard →", color="cyan", variant="light"),
                     href="/", style={"textDecoration": "none"}),
            dcc.Link(dmc.Badge("Radar →", color="green", variant="light"),
                     href="/radar", style={"textDecoration": "none"}),
            dcc.Link(dmc.Badge("Visualization →", color="grape", variant="light"),
                     href="/visualization", style={"textDecoration": "none"}),
            dcc.Link(dmc.Badge("Vault →", color="orange", variant="light"),
                     href="/vault", style={"textDecoration": "none"}),
        ], gap="sm"),
    ], p="sm", radius="md",
        style={"backgroundColor": "rgba(0,0,0,0.3)",
               "border": f"1px solid {THEME.GLASS_BORDER}"}),
])


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("pa-gen-status", "children"),
    Output("pa-data-preview", "children"),
    Output("pa-total-rows", "children"),
    Output("pipeline-state", "data", allow_duplicate=True),
    Input("pa-gen-btn", "n_clicks"),
    State("pa-customer-count", "value"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback=("Error generating data", no_update, no_update, no_update))
def generate_sample_data(n_clicks, n_customers):
    """Generate sample data for all 7 tables and show AG Grid previews."""
    if not n_clicks:
        return no_update, no_update, no_update, no_update

    n_customers = n_customers or 10
    start = time.time()

    # Generate data
    tables = generate_all_samples(
        n_customers=n_customers,
        n_transactions=n_customers * 5,
    )

    # Store in pipeline singleton
    pipeline = get_pipeline()
    pipeline.tables = tables

    # Build AG Grid preview cards
    preview_cards = []
    total_rows = 0
    for name, icon, color, desc in TABLE_INFO:
        df = tables.get(name)
        rows = len(df) if df is not None else 0
        total_rows += rows
        preview_cards.append(make_table_card(name, icon, color, desc, rows, df))

    elapsed = time.time() - start
    status_text = f"✓ Generated {n_customers} customers — {total_rows:,} total rows in {elapsed:.1f}s"

    state = {
        "data_generated": True,
        "customers": n_customers,
        "total_rows": total_rows,
    }

    return status_text, preview_cards, f"{total_rows:,} rows across 7 tables", state


# Upload handler
@callback(
    Output("pa-upload-status", "children"),
    Output("pa-data-preview", "children", allow_duplicate=True),
    Output("pipeline-state", "data", allow_duplicate=True),
    [Input(f"upload-{name}", "contents") for name, _, _, _ in TABLE_INFO[:5]],
    [State(f"upload-{name}", "filename") for name, _, _, _ in TABLE_INFO[:5]],
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback=("Upload error", no_update, no_update))
def upload_csv(*args):
    """Handle manual CSV uploads."""
    n = 5  # number of upload slots
    contents = args[:n]
    filenames = args[n:]

    pipeline = get_pipeline()
    uploaded = []

    for i, (content, filename) in enumerate(zip(contents, filenames)):
        if content is None:
            continue
        import base64, io
        _, content_string = content.split(',')
        decoded = base64.b64decode(content_string)
        df = pd.read_csv(io.StringIO(decoded.decode('utf-8')))
        table_name = TABLE_INFO[i][0]
        pipeline.tables[table_name] = df
        uploaded.append(f"{table_name} ({len(df)} rows)")

    if not uploaded:
        return no_update, no_update, no_update

    # Build preview
    preview_cards = []
    total_rows = 0
    for name, icon, color, desc in TABLE_INFO:
        df = pipeline.tables.get(name)
        rows = len(df) if df is not None else 0
        total_rows += rows
        preview_cards.append(make_table_card(name, icon, color, desc, rows, df))

    state = {"data_generated": True, "total_rows": total_rows}
    return f"✓ Uploaded: {', '.join(uploaded)}", preview_cards, state
