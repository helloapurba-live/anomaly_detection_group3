"""
Page: Vault (v9) — Analytics Deep Dive
========================================
Business Logic: Browse analytics results per family with AG Grid tables,
distribution charts, and top-N visualizations, all linked to the
Dashboard pipeline-state for auto-refresh.

Professional Family Names:
  centrality      → Network Influence Hub
  community       → Cluster Engine
  pathflow        → Laundering Traceability
  link_prediction → Hidden Association
  anomaly         → Topological Outlier
  temporal        → Dynamic Velocity
  multi_layer     → Multi-Layer Module
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
import dash_ag_grid as dag
from dash_iconify import DashIconify
import plotly.graph_objects as go
import numpy as np
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME
from engine import get_pipeline
from utils.logger import GlobalExceptionHandler

dash.register_page(__name__, path="/vault", name="Vault",
                   title="FCDAI | Vault — Analytics Deep Dive")

# =============================================================================
# FAMILY NAME MAPPING
# =============================================================================
FAMILY_MAP = {
    "centrality":      "Network Influence Hub",
    "community":       "Cluster Engine",
    "pathflow":        "Laundering Traceability",
    "link_prediction": "Hidden Association",
    "anomaly":         "Topological Outlier",
    "temporal":        "Dynamic Velocity",
    "multi_layer":     "Multi-Layer Module",
}

FAMILY_ICONS = {
    "centrality":      ("mdi:hub-outline",        "#00D4FF"),
    "community":       ("mdi:graph",              "#9D4EDD"),
    "pathflow":        ("mdi:routes",             "#00E676"),
    "link_prediction": ("mdi:link-variant",       "#FFD600"),
    "anomaly":         ("mdi:alert-decagram",     "#FF1744"),
    "temporal":        ("mdi:clock-fast",         "#FF9800"),
    "multi_layer":     ("mdi:layers-triple",      "#2196F3"),
}

AG_GRID_STYLE = {
    "--ag-background-color": "#0D1117",
    "--ag-header-background-color": "#161B22",
    "--ag-odd-row-background-color": "#0D1117",
    "--ag-row-hover-color": "#1C2333",
    "--ag-header-foreground-color": "#58A6FF",
    "--ag-foreground-color": "#C9D1D9",
    "--ag-border-color": "#21262D",
    "--ag-row-border-color": "#21262D",
    "--ag-font-size": "12px",
    "--ag-grid-size": "4px",
}


def _customer_label(node_id):
    """Show customer name + last 4 digits of ID."""
    if not node_id or not isinstance(node_id, str):
        return str(node_id or "")
    pipeline = get_pipeline()
    cust_df = pipeline.tables.get("customer")
    if cust_df is not None and len(cust_df) > 0 and "customer_id" in cust_df.columns:
        match = cust_df[cust_df["customer_id"] == node_id]
        if len(match) > 0:
            name = match.iloc[0].get("customer_name", "") or match.iloc[0].get("name", "")
            if name:
                return f"{name} (...{node_id[-4:]})"
    return f"...{node_id[-4:]}" if len(node_id) > 8 else node_id


def _is_numeric(series):
    """Check if a pandas Series is numeric (covers float32, float64, int32, int64, etc.)."""
    return pd.api.types.is_numeric_dtype(series)


def _empty_fig(msg="Run pipeline first"):
    fig = go.Figure()
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=20, r=20, t=20, b=20),
    )
    fig.add_annotation(text=msg, showarrow=False, font=dict(color="#64748B", size=14))
    return fig


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Box([
    # Header
    dmc.Group([
        dmc.Stack([
            dmc.Title("Vault", order=2, c="white"),
            dmc.Text("Analytics Deep Dive — explore all 7 detection families",
                     c="dimmed", size="sm"),
        ], gap=2),
        dmc.Group([
            dmc.Select(
                id="vault-family-select",
                data=[{"value": k, "label": v} for k, v in FAMILY_MAP.items()],
                value="centrality", w=250, size="sm",
                leftSection=DashIconify(icon="mdi:filter", width=16),
                styles={"input": {
                    "backgroundColor": THEME.DARK_BG,
                    "color": "white",
                    "border": f"1px solid {THEME.DARK_BORDER}",
                }},
            ),
            dmc.Button("Export CSV",
                       leftSection=DashIconify(icon="mdi:download"),
                       id="btn-vault-export", variant="outline", color="cyan", size="sm"),
            dcc.Link(dmc.Button("← Dashboard", size="xs", variant="subtle", color="gray"),
                     href="/", style={"textDecoration": "none"}),
        ], gap="sm"),
    ], justify="space-between", mb="lg"),

    # Family Summary Cards
    dmc.SimpleGrid(
        cols={"base": 2, "sm": 4, "lg": 7}, spacing="sm", mb="lg",
        children=[
            dmc.Paper([
                dmc.Group([
                    DashIconify(icon=FAMILY_ICONS[k][0], width=16,
                               color=FAMILY_ICONS[k][1]),
                    dmc.Text(v, size="xs", c="dimmed", fw=600),
                ], gap=4),
                dmc.Text("—", id=f"vault-{k}-count", size="lg", fw=700, c="white"),
            ], p="sm", radius="md", className="stat-card", ta="center")
            for k, v in FAMILY_MAP.items()
        ],
    ),

    # Charts Row
    dmc.SimpleGrid(cols={"base": 1, "lg": 2}, spacing="md", mb="lg", children=[
        dmc.Paper([
            dmc.Text("Score Distribution", size="sm", fw=600, c="white", mb="sm"),
            dcc.Graph(id="vault-distribution-chart",
                      config={"displayModeBar": False},
                      style={"height": "300px"}),
        ], p="lg", radius="lg", className="glass-card"),

        dmc.Paper([
            dmc.Text("Top 20 Nodes", size="sm", fw=600, c="white", mb="sm"),
            dcc.Graph(id="vault-topn-chart",
                      config={"displayModeBar": False},
                      style={"height": "300px"}),
        ], p="lg", radius="lg", className="glass-card"),
    ]),

    # AG Grid Results Table
    dmc.Paper([
        dmc.Group([
            dmc.Text("Analytics Results", size="sm", fw=600, c="white"),
            dmc.Badge(id="vault-table-badge", color="cyan", variant="light", size="sm"),
        ], gap="sm", mb="md"),
        html.Div(id="vault-results-table"),
    ], p="lg", radius="lg", className="glass-card"),

    # Download + Loading
    dcc.Download(id="vault-download"),
])


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("vault-distribution-chart", "figure"),
    Output("vault-topn-chart", "figure"),
    Output("vault-results-table", "children"),
    Output("vault-table-badge", "children"),
    *[Output(f"vault-{k}-count", "children") for k in FAMILY_MAP],
    Input("vault-family-select", "value"),
    Input("pipeline-state", "data"),
)
@GlobalExceptionHandler.wrap(fallback=(
    _empty_fig(), _empty_fig(),
    dmc.Text("No data", c="dimmed"),
    "", *["—"] * 7,
))
def update_vault(family, _pipeline_state):
    """Update vault display for selected analytics family."""
    pipeline = get_pipeline()
    results = pipeline.get_analytics_results()

    # Default counts
    counts = []
    for k in FAMILY_MAP:
        df = results.get(k) if results else None
        counts.append(f"{len(df):,}" if df is not None else "—")

    # Handle reset
    if isinstance(_pipeline_state, dict) and _pipeline_state.get("reset"):
        e = _empty_fig("Data was reset — generate data and run pipeline")
        return (e, e,
                dmc.Center(dmc.Text("Data was reset", c="dimmed"), style={"minHeight": "200px"}),
                "", *["—"] * 7)

    if not results or family not in results:
        e = _empty_fig("Run pipeline first")
        return (e, e,
                dmc.Center(dmc.Text("Run pipeline to see analytics", c="dimmed"),
                           style={"minHeight": "200px"}),
                "", *counts)

    df = results[family]
    if df is None or len(df) == 0:
        e = _empty_fig("No data for this family")
        return (e, e, dmc.Text("No data", c="dimmed"), "", *counts)

    # Use pd.api.types.is_numeric_dtype to catch float32, float64, int32, int64
    numeric_cols = [c for c in df.columns if c != "node_id" and _is_numeric(df[c])]

    if not numeric_cols:
        e = _empty_fig("No numeric metrics")
        return (e, e, dmc.Text("No numeric metrics in this family", c="dimmed"),
                f"{len(df)} rows", *counts)

    # ── Distribution Histogram ──
    fig1 = go.Figure()
    colors = ["#00D4FF", "#9D4EDD", "#FF6B6B", "#00E676", "#FFD600"]
    for i, col in enumerate(numeric_cols[:4]):
        fig1.add_trace(go.Histogram(
            x=df[col].values.astype(float), name=col.replace("_", " ").title(),
            opacity=0.7, nbinsx=40,
            marker_color=colors[i % len(colors)],
        ))
    fig1.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=40, r=20, t=20, b=40),
        legend=dict(font=dict(color="#94A3B8", size=10)),
        xaxis=dict(gridcolor="rgba(255,255,255,0.05)", color="#94A3B8"),
        yaxis=dict(gridcolor="rgba(255,255,255,0.05)", color="#94A3B8"),
        barmode="overlay", font=dict(color="#94A3B8", size=11),
    )

    # ── Top-N Bar Chart ──
    main_col = numeric_cols[0]
    top_n = df.nlargest(20, main_col)
    labels = [_customer_label(nid) for nid in top_n["node_id"].values]
    fig2 = go.Figure(go.Bar(
        y=labels[::-1], x=top_n[main_col].values[::-1].astype(float),
        orientation="h",
        marker=dict(
            color=top_n[main_col].values[::-1].astype(float),
            colorscale=[[0, "#1A2332"], [0.5, "#00D4FF"], [1, "#9D4EDD"]],
        ),
        hovertemplate="<b>%{y}</b><br>Score: %{x:.4f}<extra></extra>",
    ))
    fig2.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=140, r=20, t=20, b=40),
        xaxis=dict(gridcolor="rgba(255,255,255,0.05)", color="#94A3B8"),
        yaxis=dict(gridcolor="rgba(255,255,255,0.05)", color="#94A3B8"),
        font=dict(color="#94A3B8", size=11),
    )

    # ── AG Grid Table ──
    show_df = df.head(100).copy()
    # Convert float32 to float64 for JSON serialization
    for col in show_df.columns:
        if show_df[col].dtype == np.float32:
            show_df[col] = show_df[col].astype(float)

    grid_cols = []
    for col in show_df.columns:
        col_def = {"field": col, "headerName": col.replace("_", " ").title(),
                   "sortable": True, "filter": True, "resizable": True}
        if col == "node_id":
            col_def["pinned"] = "left"
            col_def["width"] = 160
        else:
            col_def["valueFormatter"] = {"function": "d3.format('.4f')(params.value)"}
        grid_cols.append(col_def)

    grid = dag.AgGrid(
        rowData=show_df.to_dict("records"),
        columnDefs=grid_cols,
        defaultColDef={"flex": 1, "minWidth": 100},
        dashGridOptions={"animateRows": True, "pagination": True, "paginationPageSize": 20,
                         "domLayout": "autoHeight"},
        style={"height": None, **AG_GRID_STYLE},
        className="ag-theme-alpine-dark",
    )

    badge = f"{FAMILY_MAP.get(family, family)} — {len(df)} rows, {len(numeric_cols)} metrics"
    return (fig1, fig2, grid, badge, *counts)


@callback(
    Output("vault-download", "data"),
    Input("btn-vault-export", "n_clicks"),
    State("vault-family-select", "value"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback=None)
def export_vault_csv(n_clicks, family):
    if not n_clicks:
        return None
    pipeline = get_pipeline()
    results = pipeline.get_analytics_results()
    if results and family in results:
        return dcc.send_data_frame(results[family].to_csv,
                                   f"analytics_{family}.csv", index=False)
    return None
