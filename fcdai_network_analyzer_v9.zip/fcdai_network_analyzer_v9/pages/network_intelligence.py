"""
Page: Network Intelligence (v5 NEW)
=====================================
Business Logic: Comprehensive network analysis with two views:
  View1: Important cycles, important nodes, network graph, full metrics table
  View2: Selected cycle detail, cycles <90 days, complete network, plot download

Filters: Customer ID/Name, Ring number, Node selector
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update, dash_table
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import pandas as pd
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME
from engine import get_pipeline

dash.register_page(__name__, path="/network-intelligence", name="Network Intelligence",
                   title="FCDAI v5 | Network Intelligence")

TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}
DARK_TEMPLATE = dict(
    paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
    font=dict(color="#94A3B8", size=11),
    margin=dict(l=40, r=20, t=30, b=40),
    xaxis=dict(gridcolor="rgba(255,255,255,0.05)"),
    yaxis=dict(gridcolor="rgba(255,255,255,0.05)"),
)


def empty_fig(msg="Run pipeline first"):
    fig = go.Figure()
    fig.add_annotation(text=msg, showarrow=False, font=dict(color="#64748B", size=14))
    fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      margin=dict(l=20, r=20, t=20, b=20))
    return fig


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Box([
    dcc.Interval(id="ni-init", interval=1000, max_intervals=1),

    # Header
    dmc.Group([
        dmc.Stack([
            dmc.Title("Network Intelligence", order=2, c="white"),
            dmc.Text("Cycles · Nodes · Full Network · Metrics", c="dimmed", size="sm"),
        ], gap=2),
        dmc.Group([
            dcc.Link(dmc.Button("← Dashboard", size="xs", variant="subtle", color="gray"),
                     href="/", style={"textDecoration": "none"}),
            dcc.Link(dmc.Button("Lobby Analysis →", size="xs", variant="light", color="red"),
                     href="/lobby-analysis", style={"textDecoration": "none"}),
        ], gap="sm"),
    ], justify="space-between", mb="lg"),

    # =================== FILTERS ===================
    dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:filter-outline", width=18, color=THEME.PRIMARY),
            dmc.Text("Filters", fw=600, c="white", size="sm"),
        ], gap="sm", mb="sm"),
        dmc.SimpleGrid(cols={"base": 1, "md": 4}, spacing="sm", children=[
            dmc.TextInput(id="ni-filter-custid", placeholder="Customer ID / Name...",
                          leftSection=DashIconify(icon="mdi:magnify", width=16),
                          styles={"input": {"backgroundColor": THEME.DARK_BG,
                                           "color": "white", "border": f"1px solid {THEME.DARK_BORDER}"}}),
            dmc.NumberInput(id="ni-filter-ring", placeholder="Ring #", min=1, max=100,
                           leftSection=DashIconify(icon="mdi:circle-outline", width=16),
                           styles={"input": {"backgroundColor": THEME.DARK_BG,
                                            "color": "white", "border": f"1px solid {THEME.DARK_BORDER}"}}),
            dmc.TextInput(id="ni-filter-node", placeholder="Node ID...",
                          leftSection=DashIconify(icon="mdi:graph", width=16),
                          styles={"input": {"backgroundColor": THEME.DARK_BG,
                                           "color": "white", "border": f"1px solid {THEME.DARK_BORDER}"}}),
            dmc.Button("Apply Filters", id="ni-apply-filters", color="cyan", variant="light",
                       leftSection=DashIconify(icon="mdi:filter-check", width=16)),
        ]),
    ], p="lg", radius="lg", className="glass-card", mb="md"),

    # =================== VIEW TABS ===================
    dmc.Tabs([
        dmc.TabsList([
            dmc.TabsTab("View 1 — Overview", value="view1",
                        leftSection=DashIconify(icon="mdi:view-dashboard", width=16)),
            dmc.TabsTab("View 2 — Deep Dive", value="view2",
                        leftSection=DashIconify(icon="mdi:chart-scatter-plot", width=16)),
        ], mb="md"),

        # ---- VIEW 1 ----
        dmc.TabsPanel([
            # Important Cycles
            dmc.Paper([
                dmc.Group([
                    DashIconify(icon="mdi:refresh", width=20, color="#FF6B6B"),
                    dmc.Text("Important Cycles", fw=600, c="white"),
                    dmc.Badge(id="ni-cycle-count", color="red", variant="light", size="sm"),
                ], gap="sm", mb="sm"),
                html.Div(id="ni-cycles-table"),
            ], p="lg", radius="lg", className="glass-card", mb="md"),

            # Important Nodes
            dmc.Paper([
                dmc.Group([
                    DashIconify(icon="mdi:star-four-points", width=20, color="#00D4FF"),
                    dmc.Text("Important Nodes (Top 50)", fw=600, c="white"),
                ], gap="sm", mb="sm"),
                html.Div(id="ni-nodes-table"),
            ], p="lg", radius="lg", className="glass-card", mb="md"),

            # Network Overview + Full Metrics
            dmc.SimpleGrid(cols={"base": 1, "lg": 2}, spacing="md", children=[
                dmc.Paper([
                    dmc.Group([
                        DashIconify(icon="mdi:graph", width=20, color="#00E676"),
                        dmc.Text("Network Overview", fw=600, c="white"),
                    ], gap="sm", mb="sm"),
                    dcc.Graph(id="ni-network-graph", config={"displayModeBar": False},
                              style={"height": "400px"}),
                ], p="lg", radius="lg", className="glass-card"),

                dmc.Paper([
                    dmc.Group([
                        DashIconify(icon="mdi:table-large", width=20, color="#FFD600"),
                        dmc.Text("Network Statistics", fw=600, c="white"),
                    ], gap="sm", mb="sm"),
                    html.Div(id="ni-network-stats"),
                ], p="lg", radius="lg", className="glass-card"),
            ]),
        ], value="view1"),

        # ---- VIEW 2 ----
        dmc.TabsPanel([
            # Selected Cycle Detail
            dmc.Paper([
                dmc.Group([
                    DashIconify(icon="mdi:details", width=20, color="#9D4EDD"),
                    dmc.Text("Selected Cycle Detail", fw=600, c="white"),
                    dmc.NumberInput(id="ni-cycle-selector", placeholder="Cycle #",
                                   value=1, min=1, max=50, w=100,
                                   styles={"input": {"backgroundColor": THEME.DARK_BG,
                                                    "color": "white", "fontSize": "12px",
                                                    "border": f"1px solid {THEME.DARK_BORDER}"}}),
                ], gap="sm", mb="sm"),
                html.Div(id="ni-cycle-detail"),
            ], p="lg", radius="lg", className="glass-card", mb="md"),

            # Complete Network with All Metrics
            dmc.Paper([
                dmc.Group([
                    DashIconify(icon="mdi:table-check", width=20, color="#2196F3"),
                    dmc.Text("Complete Network — All Metrics", fw=600, c="white"),
                    dmc.Button("⬇ Export CSV", id="ni-export-csv", size="xs",
                               variant="light", color="cyan",
                               leftSection=DashIconify(icon="mdi:download", width=14)),
                    dmc.Button("⬇ Export PNG", id="ni-export-png", size="xs",
                               variant="light", color="green",
                               leftSection=DashIconify(icon="mdi:image-outline", width=14)),
                ], gap="sm", mb="sm"),
                dcc.Download(id="ni-download"),
                html.Div(id="ni-full-metrics-table"),
            ], p="lg", radius="lg", className="glass-card"),
        ], value="view2"),
    ], value="view1", color="cyan",
       styles={"tab": {"color": "#94A3B8", "&[data-active]": {"color": "white"}}}),
])


# =============================================================================
# CALLBACKS
# =============================================================================

@callback(
    Output("ni-cycles-table", "children"),
    Output("ni-cycle-count", "children"),
    Output("ni-nodes-table", "children"),
    Output("ni-network-graph", "figure"),
    Output("ni-network-stats", "children"),
    Input("ni-init", "n_intervals"),
    Input("pipeline-state", "data"),
    Input("ni-apply-filters", "n_clicks"),
    State("ni-filter-custid", "value"),
    State("ni-filter-ring", "value"),
    State("ni-filter-node", "value"),
)
def update_view1(_, pipeline_state, __, filter_cust, filter_ring, filter_node):
    pipeline = get_pipeline()
    if not pipeline.has_data():
        empty = dmc.Text("Run pipeline first", c="dimmed", size="sm")
        return empty, "0", empty, empty_fig(), empty

    # ── CYCLES ──
    cycles = pipeline.detect_cycles()
    if filter_ring:
        cycles = [c for c in cycles if c["cycle_id"] == filter_ring]
    if filter_cust:
        cycles = [c for c in cycles if any(filter_cust.lower() in n.lower() for n in c["nodes"])]
    if filter_node:
        cycles = [c for c in cycles if filter_node in c["nodes"]]

    cycle_count = f"{len(cycles)} found"

    if cycles:
        cycle_data = [
            {"ID": c["cycle_id"], "Length": c["length"],
             "Initiator": c["initiator"], "Total $": f"${c['total_amount']:,.0f}",
             "Avg Risk": f"{c['avg_risk']:.1f}", "Risk Sum": f"{c['risk_sum']:.1f}",
             "Nodes": " → ".join(c["nodes"][:5]) + ("..." if len(c["nodes"]) > 5 else "")}
            for c in cycles
        ]
        cycles_table = dash_table.DataTable(
            columns=[{"name": k, "id": k} for k in cycle_data[0].keys()],
            data=cycle_data, page_size=10,
            style_header={"backgroundColor": "#111827", "color": "#94A3B8",
                          "fontWeight": "600", "border": "1px solid #1E293B"},
            style_cell={"backgroundColor": "#0A0E17", "color": "#E2E8F0",
                        "border": "1px solid #1E293B", "fontSize": "11px", "padding": "6px"},
            style_data_conditional=[
                {"if": {"filter_query": '{Avg Risk} > 50'}, "color": "#FF1744"},
                {"if": {"filter_query": '{Avg Risk} > 30'}, "color": "#FF9800"},
            ],
            sort_action="native", filter_action="native",
        )
    else:
        cycles_table = dmc.Text("No cycles detected", c="dimmed", size="sm")

    # ── IMPORTANT NODES ──
    imp_nodes = pipeline.get_important_nodes()
    if filter_cust and len(imp_nodes) > 0:
        imp_nodes = imp_nodes[imp_nodes["node_id"].str.contains(filter_cust, case=False, na=False)]
    if filter_node and len(imp_nodes) > 0:
        imp_nodes = imp_nodes[imp_nodes["node_id"].str.contains(filter_node, case=False, na=False)]

    if len(imp_nodes) > 0:
        nodes_table = dash_table.DataTable(
            columns=[{"name": c.replace("_", " ").title(), "id": c}
                     for c in ["node_id", "composite_importance", "pagerank", "betweenness",
                               "risk_score", "risk_tier", "in_flow", "out_flow", "flow_ratio"]],
            data=imp_nodes.round(4).to_dict("records"), page_size=15,
            style_header={"backgroundColor": "#111827", "color": "#94A3B8",
                          "fontWeight": "600", "border": "1px solid #1E293B"},
            style_cell={"backgroundColor": "#0A0E17", "color": "#E2E8F0",
                        "border": "1px solid #1E293B", "fontSize": "11px", "padding": "6px"},
            style_data_conditional=[
                {"if": {"column_id": "risk_tier", "filter_query": '{risk_tier} = "P1"'},
                 "color": "#FF1744", "fontWeight": "bold"},
                {"if": {"column_id": "risk_tier", "filter_query": '{risk_tier} = "P2"'},
                 "color": "#FF9800"},
            ],
            sort_action="native", filter_action="native",
        )
    else:
        nodes_table = dmc.Text("No important nodes found", c="dimmed", size="sm")

    # ── NETWORK GRAPH (mini) ──
    G = pipeline.G
    if G and G.number_of_nodes() > 0:
        scored = pipeline.get_scored_df()
        # Show top-100 highest risk nodes
        if scored is not None and len(scored) > 0:
            top_nodes = scored.nlargest(100, "risk_score")["node_id"].tolist()
        else:
            top_nodes = list(G.nodes())[:100]

        subG = G.subgraph(top_nodes)
        pos = {}
        import math
        for i, node in enumerate(subG.nodes()):
            angle = 2 * math.pi * i / max(len(subG.nodes()), 1)
            pos[node] = (math.cos(angle), math.sin(angle))

        edge_x, edge_y = [], []
        for u, v in subG.edges():
            x0, y0 = pos.get(u, (0, 0))
            x1, y1 = pos.get(v, (0, 0))
            edge_x.extend([x0, x1, None])
            edge_y.extend([y0, y1, None])

        node_x = [pos.get(n, (0, 0))[0] for n in subG.nodes()]
        node_y = [pos.get(n, (0, 0))[1] for n in subG.nodes()]
        node_colors = [TIER_COLORS.get(G.nodes[n].get("risk_tier", "P4"), "#00E676")
                       for n in subG.nodes()]
        node_text = [f"{n}<br>Risk: {G.nodes[n].get('risk_score', 0):.1f}"
                     for n in subG.nodes()]

        fig_net = go.Figure()
        fig_net.add_trace(go.Scatter(
            x=edge_x, y=edge_y, mode="lines",
            line=dict(color="rgba(255,255,255,0.08)", width=0.5),
            hoverinfo="skip",
        ))
        fig_net.add_trace(go.Scatter(
            x=node_x, y=node_y, mode="markers",
            marker=dict(color=node_colors, size=6, opacity=0.8,
                        line=dict(color="rgba(255,255,255,0.2)", width=0.5)),
            text=node_text, hovertemplate="%{text}<extra></extra>",
        ))
        fig_net.update_layout(**DARK_TEMPLATE, showlegend=False,
                              xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                              yaxis=dict(showgrid=False, zeroline=False, showticklabels=False))
    else:
        fig_net = empty_fig("No graph data")

    # ── NETWORK STATS ──
    stats = pipeline.get_network_stats()
    if stats:
        stats_items = [
            dmc.Group([
                dmc.Text(k.replace("_", " ").title(), size="sm", c="dimmed"),
                dmc.Text(str(v), size="sm", fw=600, c="white"),
            ], justify="space-between", mb="xs")
            for k, v in stats.items()
        ]
        stats_panel = dmc.Stack(stats_items, gap=2)
    else:
        stats_panel = dmc.Text("No stats", c="dimmed", size="sm")

    return cycles_table, cycle_count, nodes_table, fig_net, stats_panel


@callback(
    Output("ni-cycle-detail", "children"),
    Output("ni-full-metrics-table", "children"),
    Input("ni-cycle-selector", "value"),
    Input("ni-init", "n_intervals"),
    Input("pipeline-state", "data"),
)
def update_view2(cycle_id, _, __):
    pipeline = get_pipeline()
    if not pipeline.has_data():
        empty = dmc.Text("Run pipeline first", c="dimmed", size="sm")
        return empty, empty

    # ── SELECTED CYCLE DETAIL ──
    cycles = pipeline.detect_cycles()
    cycle_detail = dmc.Text("Select a cycle", c="dimmed", size="sm")
    if cycles and cycle_id and cycle_id <= len(cycles):
        cyc = cycles[cycle_id - 1]
        edges_data = [
            {"From": e["from"], "To": e["to"], "Amount": f"${e['amount']:,.0f}"}
            for e in cyc["edges"]
        ]
        members_data = []
        G = pipeline.G
        for node in cyc["nodes"]:
            attrs = G.nodes.get(node, {}) if G else {}
            members_data.append({
                "Node": node,
                "Risk Score": f"{attrs.get('risk_score', 0):.1f}",
                "Risk Tier": attrs.get("risk_tier", "P4"),
                "In-Flow": f"${attrs.get('in_flow', 0):,.0f}",
                "Out-Flow": f"${attrs.get('out_flow', 0):,.0f}",
            })

        cycle_detail = dmc.Stack([
            dmc.Group([
                dmc.Badge(f"Cycle #{cyc['cycle_id']}", color="red", size="lg"),
                dmc.Badge(f"{cyc['length']} nodes", color="cyan", variant="light"),
                dmc.Badge(f"Initiator: {cyc['initiator']}", color="orange", variant="light"),
                dmc.Badge(f"Total: ${cyc['total_amount']:,.0f}", color="green", variant="light"),
                dmc.Badge(f"Avg Risk: {cyc['avg_risk']:.1f}", color="yellow", variant="light"),
            ], gap="xs", mb="sm"),
            dmc.Text("Cycle Path: " + " → ".join(cyc["nodes"]) + " → " + cyc["nodes"][0],
                     size="sm", c="#00D4FF", mb="sm"),

            dmc.SimpleGrid(cols={"base": 1, "md": 2}, spacing="md", children=[
                dmc.Stack([
                    dmc.Text("Members", fw=600, c="white", size="sm"),
                    dash_table.DataTable(
                        columns=[{"name": k, "id": k} for k in members_data[0].keys()],
                        data=members_data,
                        style_header={"backgroundColor": "#111827", "color": "#94A3B8",
                                      "fontWeight": "600", "border": "1px solid #1E293B"},
                        style_cell={"backgroundColor": "#0A0E17", "color": "#E2E8F0",
                                    "border": "1px solid #1E293B", "fontSize": "11px", "padding": "6px"},
                    ),
                ], gap="xs"),
                dmc.Stack([
                    dmc.Text("Money Flow Edges", fw=600, c="white", size="sm"),
                    dash_table.DataTable(
                        columns=[{"name": k, "id": k} for k in edges_data[0].keys()],
                        data=edges_data,
                        style_header={"backgroundColor": "#111827", "color": "#94A3B8",
                                      "fontWeight": "600", "border": "1px solid #1E293B"},
                        style_cell={"backgroundColor": "#0A0E17", "color": "#E2E8F0",
                                    "border": "1px solid #1E293B", "fontSize": "11px", "padding": "6px"},
                    ),
                ], gap="xs"),
            ]),
        ])

    # ── FULL METRICS TABLE ──
    scored = pipeline.get_scored_df()
    if scored is not None and len(scored) > 0:
        display_cols = [c for c in scored.columns if c not in ["__index_level_0__"]][:15]
        full_table = dash_table.DataTable(
            columns=[{"name": c.replace("_", " ").title(), "id": c} for c in display_cols],
            data=scored[display_cols].round(4).head(200).to_dict("records"),
            page_size=20,
            style_header={"backgroundColor": "#111827", "color": "#94A3B8",
                          "fontWeight": "600", "border": "1px solid #1E293B"},
            style_cell={"backgroundColor": "#0A0E17", "color": "#E2E8F0",
                        "border": "1px solid #1E293B", "fontSize": "11px",
                        "padding": "6px", "maxWidth": "120px", "overflow": "hidden",
                        "textOverflow": "ellipsis"},
            sort_action="native", filter_action="native",
            export_format="csv",
        )
    else:
        full_table = dmc.Text("No scored data", c="dimmed", size="sm")

    return cycle_detail, full_table


@callback(
    Output("ni-download", "data"),
    Input("ni-export-csv", "n_clicks"),
    prevent_initial_call=True,
)
def export_csv(_):
    pipeline = get_pipeline()
    scored = pipeline.get_scored_df()
    if scored is not None:
        return dcc.send_data_frame(scored.to_csv, "network_metrics.csv", index=False)
    return no_update
