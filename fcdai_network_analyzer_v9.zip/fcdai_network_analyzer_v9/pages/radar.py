"""
Page: The Radar (v9)
==================
Business Logic: Interactive graph visualization using Dash Cytoscape. Nodes
are color-coded by risk tier (P1=red, P2=orange, P3=yellow, P4=green).
Auto-loads graph when pipeline state changes. Shows customer name + last 4 ID.
"""

import dash
from dash import html, dcc, callback, Input, Output, State
import dash_mantine_components as dmc
import dash_cytoscape as cyto
from dash_iconify import DashIconify
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME
from engine import get_pipeline
from utils.logger import GlobalExceptionHandler

dash.register_page(__name__, path="/radar", name="The Radar",
                   title="FCDAI | The Radar")


# =============================================================================
# CYTOSCAPE STYLESHEET
# =============================================================================
cyto_stylesheet = [
    # Default nodes
    {"selector": "node", "style": {
        "label": "data(label)",
        "font-size": "8px",
        "color": "#94A3B8",
        "text-valign": "bottom",
        "text-halign": "center",
        "background-color": "#00E676",
        "width": "mapData(degree, 0, 100, 10, 40)",
        "height": "mapData(degree, 0, 100, 10, 40)",
        "border-width": "1px",
        "border-color": "rgba(255,255,255,0.2)",
    }},
    # Risk tier colors
    {"selector": ".P1", "style": {
        "background-color": "#FF1744",
        "border-color": "#FF6B6B",
        "border-width": "2px",
    }},
    {"selector": ".P2", "style": {
        "background-color": "#FF9800",
        "border-color": "#FFB74D",
        "border-width": "1.5px",
    }},
    {"selector": ".P3", "style": {
        "background-color": "#FFD600",
        "border-color": "#FFF176",
    }},
    {"selector": ".P4", "style": {
        "background-color": "#00E676",
        "border-color": "#69F0AE",
    }},
    # Edges
    {"selector": "edge", "style": {
        "curve-style": "bezier",
        "target-arrow-shape": "triangle",
        "target-arrow-color": "rgba(0, 212, 255, 0.3)",
        "line-color": "rgba(0, 212, 255, 0.15)",
        "width": "1px",
        "opacity": 0.6,
    }},
    # Selected node
    {"selector": ":selected", "style": {
        "border-width": "3px",
        "border-color": "#00D4FF",
        "background-color": "#00D4FF",
    }},
]


def _customer_label(node_id):
    """Show customer name + last 4 digits of ID for readable labels."""
    if not node_id or not isinstance(node_id, str):
        return str(node_id or "Unknown")
    pipeline = get_pipeline()
    tables = pipeline.tables
    cust_df = tables.get("customer")
    if cust_df is not None and len(cust_df) > 0:
        match = cust_df[cust_df["customer_id"] == node_id] if "customer_id" in cust_df.columns else None
        if match is not None and len(match) > 0:
            row = match.iloc[0]
            name = row.get("customer_name", "") or row.get("name", "")
            if name:
                short_id = node_id[-4:] if len(node_id) >= 4 else node_id
                return f"{name} (...{short_id})"
    # Fallback: just last 4 digits
    if len(node_id) > 8:
        return f"...{node_id[-4:]}"
    return node_id


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Box([
    # Header
    dmc.Group([
        dmc.Stack([
            dmc.Title("The Radar", order=2, c="white"),
            dmc.Text("Interactive Network Graph — auto-refreshes with pipeline", c="dimmed", size="sm"),
        ], gap=2),
        dmc.Group([
            dmc.NumberInput(id="radar-max-nodes", value=500, min=50, max=5000,
                           step=50, w=100, size="xs", label="Max Nodes"),
            dmc.Button("Reload", id="btn-load-graph",
                       leftSection=DashIconify(icon="mdi:radar"),
                       variant="gradient", gradient={"from": "cyan", "to": "indigo"},
                       size="sm"),
            dcc.Link(dmc.Button("← Dashboard", size="xs", variant="subtle", color="gray"),
                     href="/", style={"textDecoration": "none"}),
        ], gap="sm"),
    ], justify="space-between", mb="md"),

    # Main Content: Graph + Side Panel
    dmc.Group([
        # Cytoscape Graph
        dmc.Paper([
            cyto.Cytoscape(
                id="cytoscape-graph",
                elements=[],
                stylesheet=cyto_stylesheet,
                layout={"name": "cose", "animate": False, "padding": 30,
                        "nodeRepulsion": 4000, "idealEdgeLength": 80},
                style={"width": "100%", "height": "65vh"},
                responsive=True,
            ),
        ], p="sm", radius="lg", className="glass-card",
            style={"flex": 3, "minWidth": "0"}),

        # Node Investigation Panel
        dmc.Paper([
            dmc.Text("Node Investigation", size="sm", fw=600, c="white", mb="md"),
            dmc.Stack(id="node-details-panel", gap="xs", children=[
                dmc.Center([
                    dmc.Stack([
                        DashIconify(icon="mdi:cursor-default-click-outline",
                                   width=32, color=THEME.TEXT_MUTED),
                        dmc.Text("Click a node to investigate", c="dimmed", size="sm"),
                    ], align="center", gap="xs"),
                ], style={"minHeight": "200px"}),
            ]),
        ], p="lg", radius="lg", className="glass-card",
            style={"flex": 1, "minWidth": "280px", "maxHeight": "75vh", "overflowY": "auto"}),
    ], gap="md", align="flex-start", grow=True,
       style={"display": "flex", "flexWrap": "nowrap"}),

    # Legend
    dmc.Paper([
        dmc.Group([
            dmc.Text("Legend:", size="xs", c="dimmed", fw=600),
            dmc.Badge("P1 Freeze", color="red", variant="filled", size="xs"),
            dmc.Badge("P2 EDD", color="orange", variant="filled", size="xs"),
            dmc.Badge("P3 Monitor", color="yellow", variant="filled", size="xs"),
            dmc.Badge("P4 Low", color="green", variant="filled", size="xs"),
        ], gap="xs"),
    ], p="sm", mt="md", radius="md",
        style={"backgroundColor": "rgba(0,0,0,0.3)", "border": f"1px solid {THEME.GLASS_BORDER}"}),

    # Loading
    dcc.Loading(html.Div(id="radar-loading"), type="circle", color=THEME.PRIMARY),
])


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("cytoscape-graph", "elements"),
    Output("radar-loading", "children"),
    Input("btn-load-graph", "n_clicks"),
    Input("pipeline-state", "data"),
    State("radar-max-nodes", "value"),
)
@GlobalExceptionHandler.wrap(fallback=([], ""))
def load_graph(n_clicks, pipeline_state, max_nodes):
    """Auto-load graph when pipeline state changes or manual reload."""
    pipeline = get_pipeline()

    # On reset, clear graph
    if isinstance(pipeline_state, dict) and pipeline_state.get("reset"):
        return [], ""

    if pipeline.G is None:
        return [], ""

    max_nodes = max_nodes or 500
    elements = pipeline.get_cytoscape_elements(max_nodes=max_nodes)

    # Relabel nodes with customer names
    for el in elements:
        if "source" not in el.get("data", {}):  # It's a node
            node_id = el.get("data", {}).get("id", "")
            el["data"]["label"] = _customer_label(node_id)

    return elements, ""


@callback(
    Output("node-details-panel", "children"),
    Input("cytoscape-graph", "tapNodeData"),
)
@GlobalExceptionHandler.wrap(fallback=[dmc.Text("Error loading details", c="red")])
def show_node_details(node_data):
    """Show details for clicked node with customer name + last 4 ID."""
    if not node_data:
        return [dmc.Center([
            dmc.Stack([
                DashIconify(icon="mdi:cursor-default-click-outline",
                           width=32, color=THEME.TEXT_MUTED),
                dmc.Text("Click a node to investigate", c="dimmed", size="sm"),
            ], align="center", gap="xs"),
        ], style={"minHeight": "200px"})]

    node_id = node_data.get("id", "Unknown")
    pipeline = get_pipeline()
    details = pipeline.get_node_details(node_id)

    items = []

    # Header — customer name + last 4
    display_name = _customer_label(node_id)
    tier = node_data.get("tier", "P4")
    tier_color = {"P1": "red", "P2": "orange", "P3": "yellow", "P4": "green"}.get(tier, "gray")
    items.append(dmc.Group([
        dmc.Text(display_name, fw=700, c="white", size="md"),
        dmc.Badge(tier, color=tier_color, variant="filled"),
    ], justify="space-between"))

    items.append(dmc.Divider(my="xs", color=THEME.DARK_BORDER))

    # Risk score
    risk_score = details.get("risk_score", 0) or 0
    items.append(dmc.Group([
        dmc.Text("Risk Score", size="xs", c="dimmed"),
        dmc.Text(f"{risk_score:.1f}/100", fw=700, c="white"),
    ], justify="space-between"))

    items.append(dmc.Progress(value=risk_score, color=tier_color, size="sm", my="xs"))

    # Network stats
    items.append(dmc.Text("Network Stats", size="xs", fw=600, c=THEME.PRIMARY, mt="sm"))
    for key in ["in_degree", "out_degree", "total_degree", "neighbor_count"]:
        val = details.get(key, 0)
        label = key.replace("_", " ").title()
        items.append(dmc.Group([
            dmc.Text(label, size="xs", c="dimmed"),
            dmc.Text(str(val), size="xs", c="white", fw=600),
        ], justify="space-between"))

    # Flow
    items.append(dmc.Text("Money Flow", size="xs", fw=600, c=THEME.PRIMARY, mt="sm"))
    for key in ["in_flow", "out_flow", "net_flow"]:
        val = details.get(key, 0)
        label = key.replace("_", " ").title()
        items.append(dmc.Group([
            dmc.Text(label, size="xs", c="dimmed"),
            dmc.Text(f"${val:,.2f}" if isinstance(val, (int, float)) else str(val),
                     size="xs", c="white", fw=600),
        ], justify="space-between"))

    # Additional attributes
    attrs = details.get("attributes", {})
    show_attrs = ["customer_type", "country", "segment", "occupation", "status"]
    found_attrs = {k: v for k, v in attrs.items() if k in show_attrs and v is not None}
    if found_attrs:
        items.append(dmc.Text("Profile", size="xs", fw=600, c=THEME.PRIMARY, mt="sm"))
        for key, val in found_attrs.items():
            label = key.replace("_", " ").title()
            items.append(dmc.Group([
                dmc.Text(label, size="xs", c="dimmed"),
                dmc.Text(str(val), size="xs", c="white"),
            ], justify="space-between"))

    return items
