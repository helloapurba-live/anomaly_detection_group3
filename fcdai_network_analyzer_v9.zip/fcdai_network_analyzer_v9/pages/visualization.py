"""
Page 5: Visualization (v4)
===========================
Business Logic: Comprehensive visualization hub with architecture reference
accordion, 10 interactive charts, chart filter controls, and cross-page
navigation links to relevant analytics pages.
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import plotly.express as px
import numpy as np
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME
from engine import get_pipeline
from utils.logger import GlobalExceptionHandler

dash.register_page(__name__, path="/visualization", name="Visualization",
                   title="FCDAI | Visualization")


def _customer_label(node_id):
    """Show customer name + last 4 digits of ID."""
    if not node_id or not isinstance(node_id, str):
        return str(node_id or "")
    pipeline = get_pipeline()
    cust_df = pipeline.tables.get("customer")
    if cust_df is not None and len(cust_df) > 0 and "customer_id" in cust_df.columns:
        match = cust_df[cust_df["customer_id"] == node_id]
        if len(match) > 0:
            name = match.iloc[0].get("customer_name", "") or match.iloc[0].get("name", "")
            if name:
                return f"{name} (...{node_id[-4:]})"
    return f"...{node_id[-4:]}" if len(node_id) > 8 else node_id


# =============================================================================
# CONSTANTS
# =============================================================================
TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}
CHART_COLORS = ["#00D4FF", "#9D4EDD", "#FF6B6B", "#00E676", "#FFD600",
                "#FF9800", "#2196F3", "#E040FB", "#26C6DA", "#AB47BC"]
DARK_TEMPLATE = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(color="#94A3B8", size=11),
    margin=dict(l=50, r=20, t=30, b=40),
    xaxis=dict(gridcolor="rgba(255,255,255,0.05)", zerolinecolor="rgba(255,255,255,0.08)"),
    yaxis=dict(gridcolor="rgba(255,255,255,0.05)", zerolinecolor="rgba(255,255,255,0.08)"),
    legend=dict(font=dict(color="#94A3B8", size=10)),
)


def empty_fig(msg: str = "Run pipeline to see results") -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(text=msg, showarrow=False, font=dict(color="#64748B", size=14))
    tmpl = {k: v for k, v in DARK_TEMPLATE.items()}
    tmpl["margin"] = dict(l=20, r=20, t=20, b=20)
    fig.update_layout(**tmpl)
    return fig


# =============================================================================
# ARCHITECTURE REFERENCE DATA
# =============================================================================
ARCH_LAYERS = [
    ("Layer 0: Raw Data Sources", "#FF6B6B",
     "5 data sources: Transaction (Wire/RTGS/NEFT/IMPS/Cash), Customer, Account, KYC, Alert. "
     "No device/phone data. CSV/SQL ingestion → Raw DataFrames."),
    ("Layer 1: Data Ingestion & Validation", "#FF9800",
     "Load raw data → Schema validation (required columns, types, ranges) → "
     "Data cleaning (nulls, formats, dedup) → Data quality report."),
    ("Layer 2: Data Aggregation & Enrichment", "#FFD600",
     "Account→Customer mapping → Transaction aggregation (SUM, COUNT, LIST channels) → "
     "Node feature engineering → Similarity computation (address)."),
    ("Layer 3: Graph Construction", "#00E676",
     "Build G_TXN (DiGraph, weighted) → G_TEMPORAL (timestamps) → "
     "Multi-layer fusion → Graph stats validation."),
    ("Layer 4: Graph Analytics Engine", "#00D4FF",
     "7 analytics families: Centrality (PageRank, Betweenness, HITS) · "
     "Community (Louvain, K-Core) · PathFlow (shortest paths, cycles) · "
     "Link Prediction (Jaccard, Adamic-Adar) · Anomaly (ego-net, PTR, source/sink) · "
     "Temporal (burstiness, inter-event) · Multi-Layer (cross-layer correlation)."),
    ("Layer 5: Risk Scoring Engine", "#9D4EDD",
     "Score aggregation → Weighted composite risk (0-100) → "
     "Priority classification: P1≥70 FREEZE, P2 50-69 EDD, P3 30-49 MONITOR, P4<30 CLEAR."),
    ("Layer 6: Visualization Engine", "#E040FB",
     "Network graph (color by risk, size by PageRank) → Risk dashboard → "
     "Money trail (Sankey) → Community view → Temporal timeline."),
    ("Layer 7: Web Application (Dash)", "#2196F3",
     "Multi-page Dash app: Dashboard, Port Authority, Radar, Visualization, "
     "Vault, Command Center, 7 Analytics subpages, Pipeline Runs, Database Browser."),
]


def chart_card(title, chart_id, icon, color, link_href=None, link_text=None):
    """Create a chart card with optional cross-page link."""
    footer = []
    if link_href and link_text:
        footer = [
            dmc.Divider(my="xs", color="rgba(255,255,255,0.05)"),
            dcc.Link(
                dmc.Group([
                    dmc.Text(link_text, size="xs", c=color),
                    DashIconify(icon="mdi:arrow-right", width=14, color=color),
                ], gap=4),
                href=link_href, style={"textDecoration": "none"},
            ),
        ]

    return dmc.Paper([
        dmc.Group([
            dmc.Text(title, size="sm", fw=600, c="white"),
            DashIconify(icon=icon, width=18, color=color),
        ], justify="space-between", mb="xs"),
        dcc.Graph(id=chart_id, config={"displayModeBar": False},
                  style={"height": "320px"}),
        *footer,
    ], p="lg", radius="lg", className="glass-card")


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Box([
    # Header
    dmc.Group([
        dmc.Stack([
            dmc.Title("Visualization Hub", order=2, c="white"),
            dmc.Text("Comprehensive Analytics Charts & Architecture Reference", c="dimmed", size="sm"),
        ], gap=2),
        dmc.Group([
            dmc.Badge("10 Charts", color="cyan", variant="filled", size="lg"),
            dcc.Link(dmc.Button("← Dashboard", size="xs", variant="subtle", color="gray"),
                     href="/", style={"textDecoration": "none"}),
        ], gap="sm"),
    ], justify="space-between", mb="lg"),

    # =================== ARCHITECTURE REFERENCE ===================
    dmc.Accordion([
        dmc.AccordionItem([
            dmc.AccordionControl(
                dmc.Group([
                    DashIconify(icon="mdi:layers-outline", width=20, color=THEME.PRIMARY),
                    dmc.Text("Architecture Reference — Layer 0 to Layer 7",
                             fw=600, c="white", size="sm"),
                    dmc.Badge("8 Layers", color="cyan", variant="light", size="xs"),
                ], gap="sm"),
            ),
            dmc.AccordionPanel(
                dmc.SimpleGrid(
                    cols={"base": 1, "md": 2, "xl": 4},
                    spacing="sm",
                    children=[
                        dmc.Paper([
                            dmc.Group([
                                dmc.Box(
                                    style={"width": "4px", "height": "36px",
                                           "borderRadius": "2px",
                                           "backgroundColor": color},
                                ),
                                dmc.Stack([
                                    dmc.Text(name, fw=600, size="xs", c="white"),
                                    dmc.Text(desc, size="xs", c="dimmed",
                                             style={"lineHeight": "1.4"}),
                                ], gap=2),
                            ], gap="sm", align="flex-start"),
                        ], p="sm", radius="md",
                           style={"backgroundColor": "rgba(0,0,0,0.3)",
                                  "border": f"1px solid {color}20"})
                        for name, color, desc in ARCH_LAYERS
                    ],
                ),
            ),
        ], value="arch-ref"),
    ], variant="separated", radius="lg", mb="lg",
       styles={"control": {"backgroundColor": THEME.DARK_BG_CARD,
                            "border": f"1px solid {THEME.DARK_BORDER}",
                            "borderRadius": "12px"},
               "panel": {"backgroundColor": THEME.DARK_BG_CARD,
                          "border": f"1px solid {THEME.DARK_BORDER}"},
               "item": {"border": "none"}}),

    # Hidden interval for initial load
    dcc.Interval(id="viz-init-trigger", interval=1000, max_intervals=1),

    # =================== ROW 1: Risk Overview ===================
    dmc.SimpleGrid(cols={"base": 1, "lg": 2}, spacing="md", mb="md", children=[
        chart_card("Risk Score Distribution", "viz-risk-histogram",
                   "mdi:chart-histogram", "#00D4FF",
                   "/command-center", "Explore in Command Center →"),
        chart_card("Risk Tier Breakdown", "viz-tier-donut",
                   "mdi:chart-donut", "#9D4EDD"),
    ]),

    # =================== ROW 2: Network ===================
    dmc.SimpleGrid(cols={"base": 1, "lg": 2}, spacing="md", mb="md", children=[
        chart_card("Network Degree Distribution", "viz-degree-dist",
                   "mdi:scatter-plot", "#FF6B6B",
                   "/analytics/centrality", "Explore Centrality →"),
        chart_card("Top 20 Highest Risk Nodes", "viz-top-risk",
                   "mdi:sort-descending", "#FF1744",
                   "/radar", "View in Radar →"),
    ]),

    # =================== ROW 3: Flow & Community ===================
    dmc.SimpleGrid(cols={"base": 1, "lg": 2}, spacing="md", mb="md", children=[
        chart_card("Money Flow Analysis", "viz-money-flow",
                   "mdi:swap-horizontal", "#00E676",
                   "/analytics/pathflow", "Explore PathFlow →"),
        chart_card("Community Size Distribution", "viz-community",
                   "mdi:account-group", "#FFD600",
                   "/analytics/community", "Explore Community →"),
    ]),

    # =================== ROW 4: Radar & Transactions ===================
    dmc.SimpleGrid(cols={"base": 1, "lg": 2}, spacing="md", mb="md", children=[
        chart_card("Analytics Family Coverage", "viz-analytics-radar",
                   "mdi:radar", "#E040FB",
                   "/vault", "View in Vault →"),
        chart_card("Transaction Type Distribution", "viz-txn-types",
                   "mdi:chart-pie", "#2196F3",
                   "/port-authority", "Manage in Port Authority →"),
    ]),

    # =================== ROW 5: NEW Charts ===================
    dmc.SimpleGrid(cols={"base": 1, "lg": 2}, spacing="md", children=[
        chart_card("Alert Distribution by Type", "viz-alert-dist",
                   "mdi:alert-circle-outline", "#FF1744",
                   "/analytics/anomaly", "Explore Anomaly →"),
        chart_card("KYC Risk Rating Heatmap", "viz-kyc-heatmap",
                   "mdi:file-document-check", "#FFD600"),
    ]),
])


# =============================================================================
# CALLBACKS — ALL 10 CHARTS
# =============================================================================
@callback(
    Output("viz-risk-histogram", "figure"),
    Output("viz-tier-donut", "figure"),
    Output("viz-degree-dist", "figure"),
    Output("viz-top-risk", "figure"),
    Output("viz-money-flow", "figure"),
    Output("viz-community", "figure"),
    Output("viz-analytics-radar", "figure"),
    Output("viz-txn-types", "figure"),
    Output("viz-alert-dist", "figure"),
    Output("viz-kyc-heatmap", "figure"),
    Input("viz-init-trigger", "n_intervals"),
    Input("pipeline-state", "data"),
)
@GlobalExceptionHandler.wrap(fallback=(
    empty_fig(), empty_fig(), empty_fig(), empty_fig(), empty_fig(),
    empty_fig(), empty_fig(), empty_fig(), empty_fig(), empty_fig(),
))
def update_all_charts(_, __):
    """Build all 10 visualization charts from pipeline results."""
    pipeline = get_pipeline()
    scored = pipeline.get_scored_df()
    G = pipeline.G
    analytics = pipeline.get_analytics_results()
    tables = pipeline.tables

    if scored is None or len(scored) == 0:
        e = empty_fig()
        return e, e, e, e, e, e, e, e, e, e

    # Check for reset
    if isinstance(__, dict) and __.get("reset"):
        e = empty_fig("Data was reset — generate data and run pipeline")
        return e, e, e, e, e, e, e, e, e, e

    # ── CHART 1: Risk Score Histogram ──
    fig1 = go.Figure()
    for tier in ["P4", "P3", "P2", "P1"]:
        tier_data = scored[scored["risk_tier"] == tier]
        if len(tier_data) > 0:
            fig1.add_trace(go.Histogram(
                x=tier_data["risk_score"].values, name=tier,
                marker_color=TIER_COLORS.get(tier, "#64748B"),
                opacity=0.85, nbinsx=40,
            ))
    fig1.update_layout(**DARK_TEMPLATE, barmode="stack",
                       xaxis_title="Risk Score", yaxis_title="Count")

    # ── CHART 2: Tier Donut ──
    tier_counts = scored["risk_tier"].value_counts()
    fig2 = go.Figure(go.Pie(
        labels=tier_counts.index.tolist(), values=tier_counts.values.tolist(),
        hole=0.6,
        marker=dict(colors=[TIER_COLORS.get(t, "#64748B") for t in tier_counts.index],
                    line=dict(color="rgba(10,14,23,0.8)", width=2)),
        textfont=dict(color="white", size=12), textinfo="label+percent",
        hovertemplate="<b>%{label}</b><br>Count: %{value}<br>%{percent}<extra></extra>",
    ))
    fig2.update_layout(**DARK_TEMPLATE,
                       annotations=[dict(text=f"{len(scored):,}<br>Total",
                                        x=0.5, y=0.5, font=dict(size=18, color="white"),
                                        showarrow=False)])

    # ── CHART 3: Degree Distribution ──
    if G is not None and G.number_of_nodes() > 0:
        degrees = [d for _, d in G.degree()]
        degree_counts = pd.Series(degrees).value_counts().sort_index()
        fig3 = go.Figure(go.Scatter(
            x=degree_counts.index.tolist(), y=degree_counts.values.tolist(),
            mode="markers",
            marker=dict(color="#00D4FF", size=6, opacity=0.7,
                        line=dict(color="#00D4FF", width=1)),
            hovertemplate="Degree: %{x}<br>Nodes: %{y}<extra></extra>",
        ))
        fig3.update_layout(**DARK_TEMPLATE, xaxis_title="Degree (log)",
                           yaxis_title="Count (log)", xaxis_type="log", yaxis_type="log")
    else:
        fig3 = empty_fig("No graph data")

    # ── CHART 4: Top 20 Risk Nodes ──
    top20 = scored.nlargest(20, "risk_score")
    top20_labels = [_customer_label(nid) for nid in top20["node_id"].values[::-1]]
    fig4 = go.Figure(go.Bar(
        y=top20_labels, x=top20["risk_score"].values[::-1],
        orientation="h",
        marker=dict(color=top20["risk_score"].values[::-1],
                    colorscale=[[0, "#FFD600"], [0.5, "#FF9800"], [1, "#FF1744"]],
                    line=dict(color="rgba(255,255,255,0.1)", width=1)),
        hovertemplate="<b>%{y}</b><br>Score: %{x:.1f}<extra></extra>",
    ))
    fig4.update_layout(
        **{k: v for k, v in DARK_TEMPLATE.items() if k != "margin"},
        xaxis_title="Risk Score",
        margin=dict(l=140, r=20, t=20, b=40))

    # ── CHART 5: Money Flow ──
    if G is not None and G.number_of_nodes() > 0:
        flow_data = []
        for node in G.nodes():
            attrs = G.nodes[node]
            flow_data.append({
                "node": node,
                "in_flow": attrs.get("in_flow", 0),
                "out_flow": attrs.get("out_flow", 0),
                "tier": attrs.get("risk_tier", "P4"),
            })
        flow_df = pd.DataFrame(flow_data)
        flow_df["total_flow"] = flow_df["in_flow"] + flow_df["out_flow"]
        flow_df = flow_df.nlargest(500, "total_flow")

        fig5 = go.Figure()
        for tier, color in TIER_COLORS.items():
            sub = flow_df[flow_df["tier"] == tier]
            if len(sub) > 0:
                fig5.add_trace(go.Scatter(
                    x=sub["in_flow"].values, y=sub["out_flow"].values,
                    mode="markers", name=tier,
                    marker=dict(color=color, size=6, opacity=0.6),
                    hovertemplate="<b>%{text}</b><br>In: $%{x:,.0f}<br>Out: $%{y:,.0f}<extra></extra>",
                    text=sub["node"].values,
                ))
        max_val = max(flow_df["in_flow"].max(), flow_df["out_flow"].max()) if len(flow_df) > 0 else 1
        fig5.add_trace(go.Scatter(
            x=[0, max_val], y=[0, max_val], mode="lines",
            line=dict(color="rgba(255,255,255,0.15)", dash="dash"),
            showlegend=False, hoverinfo="skip",
        ))
        fig5.update_layout(**DARK_TEMPLATE, xaxis_title="In-Flow ($)", yaxis_title="Out-Flow ($)")
    else:
        fig5 = empty_fig("No flow data")

    # ── CHART 6: Community Sizes ──
    community_df = analytics.get("community")
    if community_df is not None and "community_louvain" in community_df.columns:
        comm_sizes = community_df["community_louvain"].value_counts().sort_values(ascending=False)
        fig6 = go.Figure(go.Bar(
            x=[f"C{i}" for i in range(len(comm_sizes))], y=comm_sizes.values,
            marker=dict(color=comm_sizes.values,
                        colorscale=[[0, "#1A2332"], [0.5, "#9D4EDD"], [1, "#00D4FF"]]),
            hovertemplate="Community %{x}<br>%{y} members<extra></extra>",
        ))
        fig6.update_layout(**DARK_TEMPLATE, xaxis_title="Community", yaxis_title="Members")
    else:
        fig6 = empty_fig("No community data")

    # ── CHART 7: Analytics Radar ──
    FAMILY_LABELS = {
        "centrality": "Network Influence Hub",
        "community": "Cluster Engine",
        "pathflow": "Laundering Traceability",
        "link_prediction": "Hidden Association",
        "anomaly": "Topological Outlier",
        "temporal": "Dynamic Velocity",
        "multi_layer": "Multi-Layer Module",
    }
    families = list(analytics.keys()) if analytics else []
    if families:
        values, labels = [], []
        for fam in families:
            df = analytics[fam]
            num_cols = [c for c in df.columns if c != "node_id" and
                        pd.api.types.is_numeric_dtype(df[c])]
            if num_cols:
                mean_val = float(df[num_cols[0]].mean())
                max_val = float(df[num_cols[0]].max())
                norm = (mean_val / max_val) if max_val > 0 else 0
                values.append(round(norm, 3))
            else:
                values.append(0)
            labels.append(FAMILY_LABELS.get(fam, fam.replace("_", " ").title()))

        values_closed = values + [values[0]]
        labels_closed = labels + [labels[0]]

        fig7 = go.Figure(go.Scatterpolar(
            r=values_closed, theta=labels_closed, fill="toself",
            fillcolor="rgba(0, 212, 255, 0.15)",
            line=dict(color="#00D4FF", width=2),
            marker=dict(size=6, color="#00D4FF"),
        ))
        fig7.update_layout(
            **{k: v for k, v in DARK_TEMPLATE.items() if k not in ["xaxis", "yaxis"]},
            polar=dict(
                bgcolor="rgba(0,0,0,0)",
                radialaxis=dict(visible=True, gridcolor="rgba(255,255,255,0.08)", color="#64748B"),
                angularaxis=dict(gridcolor="rgba(255,255,255,0.08)", color="#94A3B8"),
            ),
        )
    else:
        fig7 = empty_fig("No analytics data")

    # ── CHART 8: Transaction Types ──
    txn_df = tables.get("transaction")
    if txn_df is not None and "transaction_type" in txn_df.columns:
        type_counts = txn_df["transaction_type"].value_counts()
        fig8 = go.Figure(go.Pie(
            labels=type_counts.index.tolist(), values=type_counts.values.tolist(),
            hole=0.45,
            marker=dict(colors=CHART_COLORS[:len(type_counts)],
                        line=dict(color="rgba(10,14,23,0.8)", width=1.5)),
            textfont=dict(color="white", size=11), textinfo="label+percent",
            hovertemplate="<b>%{label}</b><br>Count: %{value:,}<br>%{percent}<extra></extra>",
        ))
        fig8.update_layout(**DARK_TEMPLATE)
    else:
        fig8 = empty_fig("No transaction data")

    # ── CHART 9: Alert Distribution ──
    alert_df = tables.get("alert")
    if alert_df is not None and "alert_type" in alert_df.columns:
        alert_counts = alert_df["alert_type"].value_counts()
        fig9 = go.Figure(go.Bar(
            x=alert_counts.index.tolist(), y=alert_counts.values.tolist(),
            marker=dict(
                color=alert_counts.values.tolist(),
                colorscale=[[0, "#FF9800"], [1, "#FF1744"]],
            ),
            hovertemplate="<b>%{x}</b><br>Count: %{y}<extra></extra>",
        ))
        fig9.update_layout(**DARK_TEMPLATE, xaxis_title="Alert Type", yaxis_title="Count")
    else:
        fig9 = empty_fig("No alert data")

    # ── CHART 10: KYC Risk Heatmap ──
    kyc_df = tables.get("kyc")
    if kyc_df is not None and "risk_rating" in kyc_df.columns:
        if "kyc_status" in kyc_df.columns:
            # Cross-tabulate risk_rating vs kyc_status
            ct = pd.crosstab(kyc_df["risk_rating"], kyc_df["kyc_status"])
            fig10 = go.Figure(go.Heatmap(
                z=ct.values, x=ct.columns.tolist(), y=ct.index.tolist(),
                colorscale=[[0, "#0A0E17"], [0.5, "#9D4EDD"], [1, "#FF1744"]],
                hovertemplate="Status: %{x}<br>Rating: %{y}<br>Count: %{z}<extra></extra>",
            ))
            fig10.update_layout(**DARK_TEMPLATE, xaxis_title="KYC Status",
                                yaxis_title="Risk Rating")
        else:
            rating_counts = kyc_df["risk_rating"].value_counts().sort_index()
            fig10 = go.Figure(go.Bar(
                x=rating_counts.index.tolist(), y=rating_counts.values.tolist(),
                marker=dict(color=CHART_COLORS[:len(rating_counts)]),
                hovertemplate="<b>%{x}</b><br>Count: %{y}<extra></extra>",
            ))
            fig10.update_layout(**DARK_TEMPLATE, xaxis_title="Risk Rating", yaxis_title="Count")
    else:
        fig10 = empty_fig("No KYC data")

    return fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8, fig9, fig10
