"""
Page: Pipeline Runs History
=============================
Business Logic: Shows all previous pipeline runs stored in SQLite.
Users can view run history, compare metrics, and clear old runs.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME
from engine import get_pipeline
from database import get_db

dash.register_page(__name__, path="/pipeline-runs",
                   name="Pipeline Runs", title="FCDAI | Pipeline Runs")


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Box([
    # Header
    dmc.Group([
        dmc.ThemeIcon(
            DashIconify(icon="mdi:history", width=28),
            size="xl", radius="md", variant="gradient",
            gradient={"from": "#26C6DA", "to": "indigo"},
        ),
        dmc.Stack([
            dmc.Title("Pipeline Runs", order=2, c="white"),
            dmc.Text("Run history, metrics comparison & database statistics",
                     c="dimmed", size="sm"),
        ], gap=2),
    ], gap="md", mb="lg"),

    # Controls
    dmc.Paper([
        dmc.Group([
            dmc.Button("Refresh", id="btn-pr-refresh",
                       leftSection=DashIconify(icon="mdi:refresh"),
                       color="cyan", variant="gradient",
                       gradient={"from": "cyan", "to": "indigo"}, size="sm"),
            dmc.Button("Clear All Runs", id="btn-pr-clear",
                       leftSection=DashIconify(icon="mdi:delete-sweep"),
                       color="red", variant="outline", size="sm"),
            html.Div(id="pr-db-stats",
                     children=dmc.Badge("Loading...", color="gray", variant="light")),
        ], gap="md"),
    ], p="md", radius="lg", className="glass-card", mb="md"),

    # Stats Cards
    dmc.SimpleGrid(
        cols={"base": 1, "sm": 2, "lg": 4},
        spacing="md", mb="lg",
        id="pr-stat-cards",
        children=[],
    ),

    # Charts Row
    dmc.SimpleGrid(
        cols={"base": 1, "lg": 2},
        spacing="md", mb="lg",
        children=[
            dmc.Paper([
                dmc.Text("Customers Processed per Run", size="sm", fw=600,
                         c="white", mb="sm"),
                dcc.Graph(id="pr-chart-customers",
                          config={"displayModeBar": True},
                          style={"height": "300px"}),
            ], p="lg", radius="lg", className="glass-card"),
            dmc.Paper([
                dmc.Text("Run Duration (seconds)", size="sm", fw=600,
                         c="white", mb="sm"),
                dcc.Graph(id="pr-chart-duration",
                          config={"displayModeBar": True},
                          style={"height": "300px"}),
            ], p="lg", radius="lg", className="glass-card"),
        ],
    ),

    # History Table
    dmc.Paper([
        dmc.Group([
            dmc.Text("Run History", size="sm", fw=600, c="white"),
            dmc.Badge(id="pr-row-count", children="0 runs",
                     color="cyan", variant="light", size="sm"),
        ], justify="space-between", mb="sm"),
        html.Div(id="pr-history-table",
                 style={"maxHeight": "500px", "overflowY": "auto",
                        "overflowX": "auto"}),
    ], p="lg", radius="lg", className="glass-card"),
])


CHART_BG = "rgba(0,0,0,0)"
CHART_TEXT = "#94A3B8"
CHART_GRID = "rgba(148,163,184,0.1)"


def empty_fig(msg="No data"):
    fig = go.Figure()
    fig.add_annotation(text=msg, showarrow=False,
                       font=dict(color="#64748B", size=14))
    fig.update_layout(paper_bgcolor=CHART_BG, plot_bgcolor=CHART_BG,
                      margin=dict(l=30, r=30, t=30, b=30))
    return fig


def styled_layout(fig):
    fig.update_layout(
        paper_bgcolor=CHART_BG, plot_bgcolor=CHART_BG,
        font=dict(color=CHART_TEXT),
        xaxis=dict(gridcolor=CHART_GRID, zerolinecolor=CHART_GRID),
        yaxis=dict(gridcolor=CHART_GRID, zerolinecolor=CHART_GRID),
        margin=dict(l=40, r=30, t=40, b=40),
    )
    return fig


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("pr-stat-cards", "children"),
    Output("pr-chart-customers", "figure"),
    Output("pr-chart-duration", "figure"),
    Output("pr-history-table", "children"),
    Output("pr-row-count", "children"),
    Output("pr-db-stats", "children"),
    Input("btn-pr-refresh", "n_clicks"),
    Input("pipeline-state", "data"),
    prevent_initial_call=False,
)
def update_pipeline_runs(n_clicks, _pipeline_state):
    db = get_db()
    history = db.get_run_history(limit=100)
    stats = db.get_db_stats()

    # Stats badge
    stats_badge = dmc.Group([
        dmc.Badge(f"DB: {stats['size_mb']} MB", color="teal", variant="light", size="sm"),
        dmc.Badge(f"{stats['total_runs']} runs", color="indigo", variant="light", size="sm"),
    ], gap="xs")

    if len(history) == 0:
        return (
            [_stat_card("Total Runs", "0", "No runs yet", "mdi:counter", "gray")],
            empty_fig("No runs yet"),
            empty_fig("No runs yet"),
            dmc.Text("No pipeline runs recorded yet", c="dimmed", size="sm"),
            "0 runs",
            stats_badge,
        )

    # Stat cards
    total_runs = len(history)
    success_runs = len(history[history["status"] == "success"])
    avg_duration = history["duration_sec"].mean() if "duration_sec" in history.columns else 0
    avg_customers = history["customers"].mean() if "customers" in history.columns else 0

    cards = [
        _stat_card("Total Runs", str(total_runs), "All time", "mdi:counter", "cyan"),
        _stat_card("Successful", str(success_runs), f"{success_runs/total_runs*100:.0f}%",
                   "mdi:check-circle", "green"),
        _stat_card("Avg Duration", f"{avg_duration:.1f}s", "Per run",
                   "mdi:timer", "orange"),
        _stat_card("Avg Customers", f"{avg_customers:.0f}", "Per run",
                   "mdi:account-group", "grape"),
    ]

    # Customers chart
    fig1 = go.Figure()
    fig1.add_trace(go.Bar(
        x=[f"Run #{r}" for r in history["run_id"]],
        y=history["customers"],
        marker=dict(color=history["customers"],
                    colorscale="Viridis", showscale=False),
    ))
    styled_layout(fig1)

    # Duration chart
    fig2 = go.Figure()
    fig2.add_trace(go.Scatter(
        x=[f"Run #{r}" for r in history["run_id"]],
        y=history["duration_sec"],
        mode="lines+markers",
        marker=dict(size=8, color="#26C6DA"),
        line=dict(color="#26C6DA", width=2),
    ))
    styled_layout(fig2)

    # History table
    table = _make_history_table(history)

    return cards, fig1, fig2, table, f"{total_runs} runs", stats_badge


@callback(
    Output("btn-pr-refresh", "n_clicks"),
    Input("btn-pr-clear", "n_clicks"),
    prevent_initial_call=True,
)
def clear_runs(n_clicks):
    if n_clicks:
        db = get_db()
        db.clear_runs()
    return (n_clicks or 0) + 1  # Trigger refresh


def _stat_card(title, value, subtitle, icon, color):
    return dmc.Paper([
        dmc.Group([
            dmc.ThemeIcon(
                DashIconify(icon=icon, width=24),
                size="lg", radius="md", variant="light", color=color,
            ),
            dmc.Stack([
                dmc.Text(title, size="xs", c="dimmed", fw=500),
                dmc.Text(value, size="xl", fw=700, c="white"),
                dmc.Text(subtitle, size="xs", c="dimmed"),
            ], gap=0),
        ], gap="md"),
    ], p="lg", radius="lg", className="stat-card")


def _make_history_table(df):
    if df is None or len(df) == 0:
        return dmc.Text("No data", c="dimmed")

    header = html.Thead(html.Tr([
        html.Th(col, style={
            "padding": "10px 14px", "color": THEME.TEXT_PRIMARY,
            "borderBottom": f"2px solid {THEME.DARK_BORDER}",
            "fontSize": "11px", "fontWeight": 600,
            "textTransform": "uppercase", "letterSpacing": "0.5px",
        }) for col in df.columns
    ]))

    rows = []
    for _, row in df.iterrows():
        cells = []
        for col in df.columns:
            val = row[col]
            style = {
                "padding": "8px 14px", "color": "#CBD5E1",
                "borderBottom": "1px solid rgba(255,255,255,0.05)",
                "fontSize": "12px",
            }
            if col == "status":
                color = "#00E676" if val == "success" else "#FF1744"
                cells.append(html.Td(
                    dmc.Badge(str(val), color="green" if val == "success" else "red",
                             variant="light", size="sm"),
                    style=style,
                ))
            elif col == "duration_sec" and val is not None:
                cells.append(html.Td(f"{val:.1f}s", style=style))
            elif col == "run_id":
                cells.append(html.Td(
                    dmc.Badge(f"#{val}", color="cyan", variant="light", size="sm"),
                    style=style,
                ))
            else:
                cells.append(html.Td(str(val)[:30] if val else "—", style=style))
        rows.append(html.Tr(cells, style={"transition": "background 0.15s"}))

    return html.Table(
        [header, html.Tbody(rows)],
        style={"width": "100%", "borderCollapse": "collapse",
               "backgroundColor": "rgba(0,0,0,0.2)", "borderRadius": "8px"},
    )
