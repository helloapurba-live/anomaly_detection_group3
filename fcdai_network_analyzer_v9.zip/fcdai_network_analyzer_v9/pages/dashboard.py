"""
Page 1: Dashboard (v9)
==========================
Business Logic: Full control center with live pipeline progress bar,
pipeline config file support, data readiness, risk weight sliders,
cross-page refresh via run_version, stage results table.
v9: Memory-efficient (gc.collect, float32), 10 customers default,
    Generate Sample Data button, port 8079.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update, dash_table
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME
from engine import get_pipeline

dash.register_page(__name__, path="/", name="Dashboard",
                   title="FCDAI v9 | Dashboard")

TIER_COLORS = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}


def status_badge(label, loaded, color):
    return dmc.Badge(
        f"✓ {label}" if loaded else f"✗ {label}",
        color=color if loaded else "gray",
        variant="filled" if loaded else "outline", size="sm",
    )


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Box([
    # Intervals for live updates
    dcc.Interval(id="dash-init", interval=1000, max_intervals=1),
    dcc.Interval(id="progress-poll", interval=800, max_intervals=0, disabled=True),

    # Header
    dmc.Group([
        dmc.Stack([
            dmc.Title("FCDAI Dashboard", order=2, c="white"),
            dmc.Text("Pipeline Control Center — v9 Memory-Efficient", c="dimmed", size="sm"),
        ], gap=2),
        dmc.Group([
            dmc.Badge("v9.0", color="cyan", variant="filled", size="lg"),
            dmc.Badge(id="dash-run-version", color="grape", variant="light", size="sm"),
        ], gap="sm"),
    ], justify="space-between", mb="lg"),

    # =================== PIPELINE PROGRESS BAR (v5) ===================
    dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:rocket-launch", width=22, color=THEME.PRIMARY),
            dmc.Text("Pipeline Progress", fw=700, c="white", size="md"),
            dmc.Badge(id="progress-status-badge", color="gray", variant="light", size="sm"),
        ], gap="sm", mb="sm"),

        # Progress bar
        dmc.Progress(id="pipeline-progress-bar", value=0, size="lg",
                     color="cyan", radius="md", striped=True, animated=True,
                     style={"marginBottom": "8px"}),

        dmc.Text(id="progress-message", size="xs", c="dimmed", mb="xs"),

        # Stage indicators
        dmc.SimpleGrid(cols={"base": 3, "md": 6}, spacing="xs", id="stage-indicators",
                       children=[]),

    ], p="lg", radius="lg", className="glass-card", mb="md"),

    # =================== CONTROLS ROW ===================
    dmc.SimpleGrid(cols={"base": 1, "md": 3}, spacing="md", mb="md", children=[
        # Pipeline Controls
        dmc.Paper([
            dmc.Group([
                DashIconify(icon="mdi:play-circle", width=20, color=THEME.SUCCESS),
                dmc.Text("Pipeline Controls", fw=600, c="white", size="sm"),
            ], gap="sm", mb="md"),

            dmc.NumberInput(id="dash-max-customers", label="Max Customers",
                           value=10, min=5, max=50000, step=5,
                           styles={"input": {"backgroundColor": THEME.DARK_BG,
                                            "color": "white", "border": f"1px solid {THEME.DARK_BORDER}"}},
                           mb="sm"),

            dmc.Group([
                dmc.Button("▶ Start Pipeline", id="dash-run-btn",
                           color="cyan", variant="gradient",
                           gradient={"from": "cyan", "to": "indigo"},
                           leftSection=DashIconify(icon="mdi:play", width=18),
                           style={"flex": 1}),
                dmc.Button("■ Stop", id="dash-stop-btn",
                           color="red", variant="outline",
                           leftSection=DashIconify(icon="mdi:stop", width=18)),
            ], gap="sm", grow=True),

            # v9: Link to Port Authority for data generation
            dcc.Link(
                dmc.Button("📦 Generate Data → Port Authority", id="dash-gen-sample-btn",
                           color="teal", variant="light", fullWidth=True, mt="sm",
                           leftSection=DashIconify(icon="mdi:database-plus", width=18)),
                href="/port-authority", style={"textDecoration": "none"}),
            dmc.Text(id="dash-gen-sample-status", size="xs", c="dimmed", mt="xs",
                     children="Set customer count & generate on Port Authority page"),

            # v9: Reset All Data button
            dmc.Button("🗑️ Reset All Data", id="dash-reset-btn",
                       color="red", variant="light", fullWidth=True, mt="xs",
                       leftSection=DashIconify(icon="mdi:delete-sweep", width=18)),
            dmc.Text(id="dash-reset-status", size="xs", c="dimmed", mt="xs"),

            dmc.Text(id="dash-last-run", size="xs", c="dimmed", mt="sm"),
        ], p="lg", radius="lg", className="glass-card"),

        # Data Readiness
        dmc.Paper([
            dmc.Group([
                DashIconify(icon="mdi:database-check", width=20, color=THEME.INFO),
                dmc.Text("Data Readiness", fw=600, c="white", size="sm"),
            ], gap="sm", mb="md"),
            dmc.Stack(id="dash-data-readiness", gap="xs"),
        ], p="lg", radius="lg", className="glass-card"),

        # Config File Control (v5)
        dmc.Paper([
            dmc.Group([
                DashIconify(icon="mdi:cog-outline", width=20, color="#FFD600"),
                dmc.Text("Config File", fw=600, c="white", size="sm"),
            ], gap="sm", mb="md"),

            dmc.Text("pipeline_config.json", size="xs", c="dimmed", mb="xs"),
            dmc.Textarea(id="config-file-content", minRows=4, maxRows=6,
                         placeholder='{"max_customers": 500, "scoring_weights": {...}}',
                         styles={"input": {"backgroundColor": THEME.DARK_BG,
                                          "color": "#00D4FF", "fontFamily": "monospace",
                                          "fontSize": "11px",
                                          "border": f"1px solid {THEME.DARK_BORDER}"}}),
            dmc.Group([
                dmc.Button("Load", id="config-load-btn", size="xs", variant="light", color="yellow"),
                dmc.Button("Save", id="config-save-btn", size="xs", variant="filled", color="yellow"),
            ], gap="xs", mt="xs"),
            dmc.Text(id="config-status", size="xs", c="dimmed", mt="xs"),
        ], p="lg", radius="lg", className="glass-card"),
    ]),

    # =================== RISK WEIGHTS ===================
    dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:tune-vertical", width=20, color=THEME.SECONDARY),
            dmc.Text("Risk Scoring Weights", fw=600, c="white", size="sm"),
            dmc.Badge("7 Families", color="grape", variant="light", size="xs"),
        ], gap="sm", mb="md"),
        dmc.SimpleGrid(cols={"base": 1, "md": 4}, spacing="md", children=[
            dmc.Stack([
                dmc.Text(name, size="xs", c="dimmed"),
                dmc.Slider(id=f"w-{key}", value=val, min=0, max=1, step=0.05,
                           marks=[{"value": 0}, {"value": 0.5}, {"value": 1}],
                           color=col, size="sm",
                           styles={"markLabel": {"color": "#64748B"}}),
            ], gap=2)
            for key, name, val, col in [
                ("centrality", "Network Influence Hub", 0.20, "cyan"),
                ("community", "Topological Cluster Engine", 0.15, "grape"),
                ("pathflow", "Laundering Traceability", 0.15, "red"),
                ("link_pred", "Hidden Association Predictor", 0.10, "yellow"),
                ("anomaly", "Topological Outlier Detector", 0.20, "orange"),
                ("temporal", "Dynamic Velocity Analyzer", 0.10, "green"),
                ("multi_layer", "Multi-Layer Module", 0.10, "blue"),
            ]
        ]),
    ], p="lg", radius="lg", className="glass-card", mb="md"),

    # =================== KPI ROW ===================
    dmc.SimpleGrid(cols={"base": 2, "md": 5}, spacing="md", mb="md", id="dash-kpi-row",
                   children=[]),

    # =================== STAGE RESULTS TABLE (v5) ===================
    dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:table-check", width=20, color="#26C6DA"),
            dmc.Text("Stage Results", fw=600, c="white", size="sm"),
        ], gap="sm", mb="sm"),
        html.Div(id="stage-results-table"),
    ], p="lg", radius="lg", className="glass-card", mb="md"),

    # =================== NAVIGATION GRID ===================
    dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:apps", width=20, color=THEME.INFO),
            dmc.Text("Quick Navigation", fw=600, c="white", size="sm"),
            dmc.Badge("17 Pages", color="indigo", variant="light", size="xs"),
        ], gap="sm", mb="md"),
        dmc.SimpleGrid(cols={"base": 2, "md": 4, "xl": 6}, spacing="sm", children=[
            dcc.Link(
                dmc.Paper([
                    dmc.Group([
                        DashIconify(icon=icon, width=20, color=color),
                        dmc.Text(name, size="xs", fw=500, c="white"),
                    ], gap="xs"),
                ], p="sm", radius="md", className="nav-card",
                   style={"backgroundColor": "rgba(0,0,0,0.3)",
                          "border": f"1px solid {color}20", "cursor": "pointer"}),
                href=href, style={"textDecoration": "none"},
            )
            for icon, name, href, color in [
                ("mdi:database-import", "Port Authority", "/port-authority", "#00D4FF"),
                ("mdi:radar", "Radar", "/radar", "#00E676"),
                ("mdi:chart-box", "Visualization", "/visualization", "#E040FB"),
                ("mdi:safe-square", "Vault", "/vault", "#9D4EDD"),
                ("mdi:shield-alert", "Command Center", "/command-center", "#FF1744"),
                ("mdi:graph", "Network Intel", "/network-intelligence", "#00D4FF"),
                ("mdi:account-group", "Lobby Analysis", "/lobby-analysis", "#FF6B6B"),
                ("mdi:star-four-points", "Influence Hub", "/analytics/centrality", "#00D4FF"),
                ("mdi:account-group", "Cluster Engine", "/analytics/community", "#9D4EDD"),
                ("mdi:transit-connection", "Traceability", "/analytics/pathflow", "#FF6B6B"),
                ("mdi:link-variant", "Assoc. Predictor", "/analytics/link-prediction", "#FFD600"),
                ("mdi:alert-decagram", "Outlier Detector", "/analytics/anomaly", "#FF9800"),
                ("mdi:clock-fast", "Velocity Analyzer", "/analytics/temporal", "#00E676"),
                ("mdi:layers-triple", "Multi-Layer", "/analytics/multi-layer", "#2196F3"),
                ("mdi:history", "Pipeline Runs", "/pipeline-runs", "#26C6DA"),
                ("mdi:database-search", "Database", "/database", "#AB47BC"),
            ]
        ]),
    ], p="lg", radius="lg", className="glass-card", mb="md"),

    # =================== ALGORITHM RUN SUMMARY ===================
    dmc.Paper([
        dmc.Group([
            DashIconify(icon="mdi:brain", width=22, color="#9D4EDD"),
            dmc.Text("Algorithm Run Summary", fw=700, c="white", size="md"),
            dmc.Badge("7 Families", color="grape", variant="light", size="sm"),
        ], gap="sm", mb="md"),
        html.Div(id="dash-algo-summary", children=[
            dmc.Center(
                dmc.Text("Run pipeline to see algorithm performance", c="dimmed", size="sm"),
                style={"minHeight": "100px"}),
        ]),
    ], p="lg", radius="lg", className="glass-card"),
])


# =============================================================================
# CALLBACKS
# =============================================================================

@callback(
    Output("dash-data-readiness", "children"),
    Output("dash-kpi-row", "children"),
    Output("dash-last-run", "children"),
    Output("dash-run-version", "children"),
    Output("stage-results-table", "children"),
    Output("config-file-content", "value"),
    Input("dash-init", "n_intervals"),
    Input("pipeline-state", "data"),
)
def init_dashboard(_, pipeline_state):
    pipeline = get_pipeline()
    tables = pipeline.tables

    # Data readiness
    table_names = ["transaction", "customer", "account", "kyc", "alert"]
    table_colors = ["cyan", "grape", "green", "yellow", "red"]
    readiness = [
        status_badge(n.title(), n in tables and len(tables[n]) > 0, c)
        for n, c in zip(table_names, table_colors)
    ]

    # KPIs — including total time (#8)
    scored = pipeline.get_scored_df()
    meta = pipeline.last_run_meta
    total_ms = sum(r.duration_ms for r in pipeline.stage_results) if pipeline.stage_results else 0
    total_secs = total_ms / 1000
    time_str = f"{total_secs:.1f}s" if total_secs < 60 else f"{total_secs/60:.1f}m"
    kpis = [
        ("Customers", f"{meta.get('customers', 0):,}", "mdi:account-multiple", THEME.PRIMARY),
        ("Graph Nodes", f"{meta.get('graph_nodes', 0):,}", "mdi:graph", THEME.SUCCESS),
        ("Graph Edges", f"{meta.get('graph_edges', 0):,}", "mdi:swap-horizontal", THEME.INFO),
        ("Total Time", time_str if total_ms > 0 else "—", "mdi:timer-outline", "#FFD600"),
        ("Run Version", f"#{pipeline.run_version}", "mdi:counter", "#E040FB"),
    ]
    kpi_cards = [
        dmc.Paper([
            dmc.Group([
                DashIconify(icon=icon, width=24, color=color),
                dmc.Stack([
                    dmc.Text(label, size="xs", c="dimmed"),
                    dmc.Text(value, size="lg", fw=700, c="white"),
                ], gap=0),
            ], gap="sm"),
        ], p="md", radius="lg", className="stat-card glass-card")
        for label, value, icon, color in kpis
    ]

    # Last run
    last_run = f"Last run: {meta.get('saved_at', 'Never')}" if meta else "No previous run"

    # Run version badge
    rv_text = f"Run #{pipeline.run_version}"

    # Stage results table
    stage_table = dmc.Text("Run pipeline to see stage results", c="dimmed", size="sm")
    if pipeline.stage_results:
        stage_table = dash_table.DataTable(
            columns=[
                {"name": "Stage", "id": "stage"},
                {"name": "Name", "id": "name"},
                {"name": "Duration (ms)", "id": "duration_ms"},
                {"name": "Records In", "id": "records_in"},
                {"name": "Records Out", "id": "records_out"},
                {"name": "Status", "id": "status"},
            ],
            data=[
                {
                    "stage": r.stage, "name": r.name,
                    "duration_ms": f"{r.duration_ms:.0f}",
                    "records_in": f"{r.records_in:,}",
                    "records_out": f"{r.records_out:,}",
                    "status": "✓" if r.success else "✗",
                }
                for r in pipeline.stage_results
            ],
            style_table={"overflowX": "auto"},
            style_header={"backgroundColor": "#111827", "color": "#94A3B8",
                          "fontWeight": "600", "border": "1px solid #1E293B"},
            style_cell={"backgroundColor": "#0A0E17", "color": "#E2E8F0",
                        "border": "1px solid #1E293B", "fontSize": "12px",
                        "padding": "8px"},
        )

    # Config file
    config_content = ""
    try:
        overrides = pipeline.load_config_overrides()
        if overrides:
            config_content = json.dumps(overrides, indent=2)
    except Exception:
        pass

    return readiness, kpi_cards, last_run, rv_text, stage_table, config_content


@callback(
    Output("pipeline-state", "data"),
    Output("progress-poll", "disabled"),
    Output("progress-poll", "max_intervals"),
    Output("pipeline-progress-bar", "value", allow_duplicate=True),
    Output("progress-message", "children", allow_duplicate=True),
    Output("progress-status-badge", "children", allow_duplicate=True),
    Output("progress-status-badge", "color", allow_duplicate=True),
    Output("stage-indicators", "children", allow_duplicate=True),
    Output("dash-algo-summary", "children", allow_duplicate=True),
    Input("dash-run-btn", "n_clicks"),
    State("dash-max-customers", "value"),
    State("w-centrality", "value"),
    State("w-community", "value"),
    State("w-pathflow", "value"),
    State("w-link_pred", "value"),
    State("w-anomaly", "value"),
    State("w-temporal", "value"),
    State("w-multi_layer", "value"),
    prevent_initial_call=True,
)
def run_pipeline(n_clicks, max_cust, w_c, w_co, w_pf, w_lp, w_an, w_te, w_ml):
    if not n_clicks:
        return (no_update,) * 9

    FAMILY_MAP = {
        "centrality":      ("Network Influence Hub",     "mdi:hub-outline",     "#00D4FF"),
        "community":       ("Cluster Engine",            "mdi:graph",           "#9D4EDD"),
        "pathflow":        ("Laundering Traceability",   "mdi:routes",          "#00E676"),
        "link_prediction": ("Hidden Association",        "mdi:link-variant",    "#FFD600"),
        "anomaly":         ("Topological Outlier",       "mdi:alert-decagram",  "#FF1744"),
        "temporal":        ("Dynamic Velocity",          "mdi:clock-fast",      "#FF9800"),
        "multi_layer":     ("Multi-Layer Module",        "mdi:layers-triple",   "#2196F3"),
    }

    weights = {
        "centrality": w_c or 0.2, "community": w_co or 0.15,
        "pathflow": w_pf or 0.15, "link_prediction": w_lp or 0.1,
        "anomaly": w_an or 0.2, "temporal": w_te or 0.1,
        "multi_layer": w_ml or 0.1,
    }

    pipeline = get_pipeline()
    result = pipeline.run(max_customers=max_cust or 10, scoring_weights=weights)

    state = {
        "run_version": pipeline.run_version,
        "success": result.success,
        "customers": result.customers_processed,
        "timestamp": str(pipeline.last_run_meta.get("saved_at", "")),
        "duration_ms": result.total_duration_ms,
    }

    # Build final progress bar state directly
    total_secs = result.total_duration_ms / 1000
    time_str = f"{total_secs:.1f}s" if total_secs < 60 else f"{total_secs/60:.1f}m"
    msg = f"✓ Pipeline complete — {result.customers_processed} customers, {time_str}"
    badge = "Complete" if result.success else "Failed"
    badge_color = "green" if result.success else "red"

    # Build stage chips with timing
    status = pipeline.progress.get_status()
    stage_chips = []
    for s in status["stages"]:
        st = s["status"]
        if st == "done":
            icon, color = "mdi:check-circle", "green"
        elif st == "running":
            icon, color = "mdi:loading", "cyan"
        else:
            icon, color = "mdi:circle-outline", "gray"
        stage_chips.append(
            dmc.Group([
                DashIconify(icon=icon, width=14, color=color),
                dmc.Text(s["name"], size="xs", c=color),
                dmc.Text(f"{s['duration']:.1f}s" if s["duration"] > 0 else "",
                         size="xs", c="dimmed"),
            ], gap=4)
        )

    # Build algorithm run summary
    import pandas as pd
    analytics = pipeline.get_analytics_results()
    algo_cards = []
    for key, (label, icon, color) in FAMILY_MAP.items():
        df = analytics.get(key) if analytics else None
        has_data = df is not None and len(df) > 0
        num_metrics = len([c for c in df.columns if c != "node_id" and
                          pd.api.types.is_numeric_dtype(df[c])]) if has_data else 0
        rows = len(df) if has_data else 0
        weight_pct = int(weights.get(key, 0) * 100)

        algo_cards.append(
            dmc.Paper([
                dmc.Group([
                    DashIconify(icon=icon, width=20, color=color),
                    dmc.Text(label, size="sm", fw=600, c="white"),
                ], gap="xs", mb="xs"),
                dmc.SimpleGrid(cols=3, spacing=4, children=[
                    dmc.Stack([
                        dmc.Text("Nodes", size="xs", c="dimmed"),
                        dmc.Text(f"{rows:,}", size="sm", fw=700,
                                 c="white" if has_data else "dimmed"),
                    ], gap=0, align="center"),
                    dmc.Stack([
                        dmc.Text("Metrics", size="xs", c="dimmed"),
                        dmc.Text(str(num_metrics), size="sm", fw=700,
                                 c="white" if has_data else "dimmed"),
                    ], gap=0, align="center"),
                    dmc.Stack([
                        dmc.Text("Weight", size="xs", c="dimmed"),
                        dmc.Text(f"{weight_pct}%", size="sm", fw=700, c=color),
                    ], gap=0, align="center"),
                ]),
                dmc.Badge(
                    "✓ Computed" if has_data else "✗ No data",
                    color="green" if has_data else "red",
                    variant="light", size="xs", mt="xs", fullWidth=True),
            ], p="sm", radius="md",
                style={"backgroundColor": "rgba(0,0,0,0.3)",
                       "border": f"1px solid {color}30"}),
        )

    algo_summary = dmc.SimpleGrid(
        cols={"base": 1, "sm": 2, "md": 3, "lg": 4, "xl": 7},
        spacing="sm", children=algo_cards)

    return state, True, 0, 100, msg, badge, badge_color, stage_chips, algo_summary


@callback(
    Output("pipeline-progress-bar", "value"),
    Output("progress-message", "children"),
    Output("progress-status-badge", "children"),
    Output("progress-status-badge", "color"),
    Output("stage-indicators", "children"),
    Input("progress-poll", "n_intervals"),
    Input("dash-init", "n_intervals"),
)
def update_progress(_, __):
    pipeline = get_pipeline()
    status = pipeline.progress.get_status()

    pct = status["overall_pct"]
    msg = status["message"]
    running = status["running"]

    badge_text = "Running..." if running else ("Complete" if pct >= 100 else "Idle")
    badge_color = "cyan" if running else ("green" if pct >= 100 else "gray")

    stage_chips = []
    for s in status["stages"]:
        st = s["status"]
        if st == "done":
            icon, color = "mdi:check-circle", "green"
        elif st == "running":
            icon, color = "mdi:loading", "cyan"
        else:
            icon, color = "mdi:circle-outline", "gray"
        stage_chips.append(
            dmc.Group([
                DashIconify(icon=icon, width=14, color=color),
                dmc.Text(s["name"], size="xs", c=color),
                dmc.Text(f"{s['duration']:.1f}s" if s["duration"] > 0 else "",
                         size="xs", c="dimmed"),
            ], gap=4)
        )

    return pct, msg, badge_text, badge_color, stage_chips


@callback(
    Output("config-status", "children"),
    Input("config-load-btn", "n_clicks"),
    prevent_initial_call=True,
)
def load_config(_):
    pipeline = get_pipeline()
    overrides = pipeline.load_config_overrides()
    if overrides:
        return f"Loaded {len(overrides)} settings"
    return "No config file found"


@callback(
    Output("config-status", "children", allow_duplicate=True),
    Input("config-save-btn", "n_clicks"),
    State("config-file-content", "value"),
    prevent_initial_call=True,
)
def save_config(_, content):
    if not content:
        return "No content to save"
    try:
        data = json.loads(content)
        pipeline = get_pipeline()
        pipeline.save_config(data)
        return f"Saved {len(data)} settings ✓"
    except json.JSONDecodeError:
        return "Invalid JSON!"


@callback(
    Output("progress-status-badge", "children", allow_duplicate=True),
    Output("progress-status-badge", "color", allow_duplicate=True),
    Output("pipeline-progress-bar", "value", allow_duplicate=True),
    Output("progress-message", "children", allow_duplicate=True),
    Input("dash-stop-btn", "n_clicks"),
    prevent_initial_call=True,
)
def stop_pipeline(n_clicks):
    """Stop the running pipeline."""
    if not n_clicks:
        return no_update, no_update, no_update, no_update
    pipeline = get_pipeline()
    pipeline.progress.stop_requested = True
    return "Stopped", "red", 0, "Pipeline stopped by user"


# =============================================================================
# v9: GENERATE SAMPLE — now on Port Authority, this is a no-op
# =============================================================================
@callback(
    Output("dash-gen-sample-status", "children", allow_duplicate=True),
    Input("dash-gen-sample-btn", "n_clicks"),
    prevent_initial_call=True,
)
def generate_sample_data(n_clicks):
    return "Navigate to Port Authority to generate data"


# =============================================================================
# v9: RESET ALL DATA CALLBACK
# =============================================================================
@callback(
    Output("dash-reset-status", "children"),
    Output("dash-data-readiness", "children", allow_duplicate=True),
    Output("dash-kpi-row", "children", allow_duplicate=True),
    Output("pipeline-state", "data", allow_duplicate=True),
    Output("stage-results-table", "children", allow_duplicate=True),
    Input("dash-reset-btn", "n_clicks"),
    prevent_initial_call=True,
)
def reset_all_data(n_clicks):
    """v9: Delete DB, vault, samples, logs and reset pipeline state."""
    if not n_clicks:
        return no_update, no_update, no_update, no_update, no_update

    import shutil
    from config import PATHS

    removed = []
    try:
        # 1. Remove database
        db_path = PATHS.DATA / "fcdai.db"
        if db_path.exists():
            try:
                db_path.unlink()
                removed.append("DB")
            except Exception:
                pass

        # 2. Clear vault
        vault_dir = PATHS.VAULT
        if vault_dir.exists():
            try:
                shutil.rmtree(vault_dir)
                vault_dir.mkdir(parents=True, exist_ok=True)
                removed.append("Vault")
            except Exception:
                pass

        # 3. Clear samples
        sample_dir = PATHS.DATA / "samples"
        if sample_dir.exists():
            try:
                shutil.rmtree(sample_dir)
                sample_dir.mkdir(parents=True, exist_ok=True)
                removed.append("Samples")
            except Exception:
                pass

        # 4. Clear logs
        log_dir = PATHS.LOG_DIR
        if log_dir.exists():
            try:
                shutil.rmtree(log_dir)
                log_dir.mkdir(parents=True, exist_ok=True)
                removed.append("Logs")
            except Exception:
                pass

        # 5. Reset pipeline state
        pipeline = get_pipeline()
        pipeline.tables = {}
        pipeline.customer_features = None
        pipeline.edges = None
        pipeline.G = None
        pipeline.analytics_results = {}
        pipeline.scored_df = None
        pipeline.reports = {}
        pipeline.stage_results = []
        pipeline.last_run_meta = {}
        pipeline._cycles_cache = None
        pipeline._lobbies_cache = None
        pipeline._important_nodes_cache = None
        pipeline.run_version = 0
        pipeline.progress.reset()
        removed.append("State")

        # Empty readiness & KPI
        table_names = ["transaction", "customer", "account", "kyc", "alert"]
        table_colors = ["cyan", "grape", "green", "yellow", "red"]
        readiness = [
            status_badge(n.title(), False, c)
            for n, c in zip(table_names, table_colors)
        ]

        kpi_cards = [
            dmc.Paper([
                dmc.Group([
                    DashIconify(icon=icon, width=24, color=color),
                    dmc.Stack([
                        dmc.Text(label, size="xs", c="dimmed"),
                        dmc.Text("0", size="lg", fw=700, c="white"),
                    ], gap=0),
                ], gap="sm"),
            ], p="md", radius="lg", className="stat-card glass-card")
            for label, icon, color in [
                ("Customers", "mdi:account-multiple", THEME.PRIMARY),
                ("Graph Nodes", "mdi:graph", THEME.SUCCESS),
                ("Graph Edges", "mdi:swap-horizontal", THEME.INFO),
                ("Total Time", "mdi:timer-outline", "#FFD600"),
                ("Run Version", "mdi:counter", "#E040FB"),
            ]
        ]

        # Trigger all pages to clear via pipeline-state
        reset_state = {"reset": True, "run_version": 0}
        empty_stage = dmc.Text("Run pipeline to see stage results", c="dimmed", size="sm")

        return f"✓ Reset: {', '.join(removed)}", readiness, kpi_cards, reset_state, empty_stage
    except Exception as e:
        return f"✗ Error: {str(e)[:80]}", no_update, no_update, no_update, no_update
