"""
Page: Database Browser
========================
Business Logic: Lightweight SQLite table explorer. Lists all tables,
shows schema info, previews data with pagination, and runs SQL queries.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME, PATHS
from database import get_db

dash.register_page(__name__, path="/database",
                   name="Database", title="FCDAI | Database Browser")


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Box([
    # Header
    dmc.Group([
        dmc.ThemeIcon(
            DashIconify(icon="mdi:database-search-outline", width=28),
            size="xl", radius="md", variant="gradient",
            gradient={"from": "#AB47BC", "to": "indigo"},
        ),
        dmc.Stack([
            dmc.Title("Database Browser", order=2, c="white"),
            dmc.Text("Explore SQLite tables, schema, and run queries",
                     c="dimmed", size="sm"),
        ], gap=2),
    ], gap="md", mb="lg"),

    # DB Info Card
    dmc.Paper([
        dmc.Group([
            dmc.ThemeIcon(
                DashIconify(icon="mdi:database", width=20),
                size="md", radius="md", variant="light", color="grape",
            ),
            html.Div(id="db-info-text"),
            dmc.Button("Refresh", id="btn-db-refresh",
                       leftSection=DashIconify(icon="mdi:refresh"),
                       color="grape", variant="outline", size="xs"),
        ], gap="md"),
    ], p="md", radius="lg", className="glass-card", mb="md"),

    # Two-column: Tables List + Preview
    dmc.SimpleGrid(
        cols={"base": 1, "lg": 2},
        spacing="md", mb="lg",
        children=[
            # Tables List
            dmc.Paper([
                dmc.Text("Tables", size="sm", fw=600, c="white", mb="md"),
                html.Div(id="db-tables-list"),
            ], p="lg", radius="lg", className="glass-card",
                style={"minHeight": "300px"}),

            # Table Preview
            dmc.Paper([
                dmc.Group([
                    dmc.Text("Table Preview", size="sm", fw=600, c="white"),
                    dmc.Select(id="db-preview-select", data=[],
                               placeholder="Select table", clearable=False,
                               w=200, size="xs"),
                ], justify="space-between", mb="md"),
                html.Div(id="db-preview-table",
                         style={"maxHeight": "400px", "overflowY": "auto",
                                "overflowX": "auto"}),
            ], p="lg", radius="lg", className="glass-card",
                style={"minHeight": "300px"}),
        ],
    ),

    # SQL Query Runner
    dmc.Paper([
        dmc.Text("SQL Query Runner", size="sm", fw=600, c="white", mb="md"),
        dmc.Textarea(
            id="db-sql-input",
            placeholder="SELECT * FROM pipeline_runs ORDER BY run_id DESC LIMIT 10",
            minRows=3, maxRows=6,
            style={"fontFamily": "monospace", "fontSize": "13px"},
        ),
        dmc.Space(h="sm"),
        dmc.Group([
            dmc.Button("Run Query", id="btn-db-run-query",
                       leftSection=DashIconify(icon="mdi:play"),
                       color="grape", variant="gradient",
                       gradient={"from": "#AB47BC", "to": "indigo"}, size="sm"),
            dmc.Button("Export CSV", id="btn-db-export",
                       leftSection=DashIconify(icon="mdi:download"),
                       color="green", variant="outline", size="sm"),
            dcc.Download(id="db-download"),
            html.Div(id="db-query-status"),
        ], gap="md"),
        dmc.Space(h="md"),
        html.Div(id="db-query-results",
                 style={"maxHeight": "400px", "overflowY": "auto",
                        "overflowX": "auto"}),
    ], p="lg", radius="lg", className="glass-card"),
])


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("db-info-text", "children"),
    Output("db-tables-list", "children"),
    Output("db-preview-select", "data"),
    Input("btn-db-refresh", "n_clicks"),
    prevent_initial_call=False,
)
def load_db_info(n_clicks):
    db = get_db()
    stats = db.get_db_stats()
    tables = db.get_table_list()

    # Info text
    info = dmc.Group([
        dmc.Text(f"Path: {stats['db_path']}", size="xs", c="dimmed",
                 style={"fontFamily": "monospace"}),
        dmc.Badge(f"{stats['size_mb']} MB", color="teal", variant="light", size="sm"),
        dmc.Badge(f"{stats['total_runs']} runs", color="indigo", variant="light", size="sm"),
    ], gap="sm")

    # Tables list
    table_cards = []
    select_options = []
    for t in tables:
        select_options.append({"label": f"{t['table']} ({t['rows']} rows)", "value": t['table']})
        table_cards.append(
            dmc.Paper([
                dmc.Group([
                    dmc.ThemeIcon(
                        DashIconify(icon="mdi:table", width=18),
                        size="sm", radius="sm", variant="light", color="grape",
                    ),
                    dmc.Stack([
                        dmc.Text(t["table"], size="sm", fw=600, c="white"),
                        dmc.Group([
                            dmc.Badge(f"{t['rows']} rows", color="cyan",
                                     variant="light", size="xs"),
                            dmc.Badge(f"{t['columns']} cols", color="grape",
                                     variant="light", size="xs"),
                        ], gap="xs"),
                    ], gap=2),
                ], gap="sm"),
                dmc.Text(", ".join(t["col_names"][:6]) +
                         ("..." if len(t["col_names"]) > 6 else ""),
                         size="xs", c="dimmed", mt="xs",
                         style={"fontFamily": "monospace", "fontSize": "10px"}),
            ], p="sm", mb="xs", radius="md",
                style={"backgroundColor": "rgba(0,0,0,0.3)",
                       "border": "1px solid rgba(255,255,255,0.05)",
                       "transition": "all 0.15s ease"},
            )
        )

    return info, table_cards or dmc.Text("No tables found", c="dimmed"), select_options


@callback(
    Output("db-preview-table", "children"),
    Input("db-preview-select", "value"),
    prevent_initial_call=True,
)
def preview_table(table_name):
    if not table_name:
        return no_update
    db = get_db()
    df = db.preview_table(table_name, limit=100)
    if len(df) == 0:
        return dmc.Text("Table is empty", c="dimmed", size="sm")
    return _make_table(df)


@callback(
    Output("db-query-results", "children"),
    Output("db-query-status", "children"),
    Input("btn-db-run-query", "n_clicks"),
    State("db-sql-input", "value"),
    prevent_initial_call=True,
)
def run_query(n_clicks, sql):
    if not sql or not sql.strip():
        return no_update, dmc.Badge("Enter a query", color="yellow", variant="light")

    db = get_db()
    df = db.run_query(sql)

    if "error" in df.columns:
        return (
            dmc.Alert(str(df["error"].iloc[0]), color="red", title="Query Error"),
            dmc.Badge("Error", color="red", variant="light"),
        )

    status = dmc.Badge(f"{len(df)} rows returned", color="green", variant="light")
    return _make_table(df), status


@callback(
    Output("db-download", "data"),
    Input("btn-db-export", "n_clicks"),
    State("db-sql-input", "value"),
    prevent_initial_call=True,
)
def export_query(n_clicks, sql):
    if not sql or not sql.strip():
        return no_update
    db = get_db()
    df = db.run_query(sql)
    if "error" not in df.columns:
        return dcc.send_data_frame(df.to_csv, "query_results.csv", index=False)
    return no_update


def _make_table(df, max_rows=200):
    """Build a styled HTML table."""
    if df is None or len(df) == 0:
        return dmc.Text("No data", c="dimmed", size="sm")

    display_df = df.head(max_rows)
    for col in display_df.select_dtypes(include=["float64", "float32"]).columns:
        display_df = display_df.copy()
        display_df[col] = display_df[col].round(4)

    header = html.Thead(html.Tr([
        html.Th(col, style={
            "padding": "8px 12px", "color": THEME.TEXT_PRIMARY,
            "borderBottom": f"2px solid {THEME.DARK_BORDER}",
            "fontSize": "11px", "fontWeight": 600,
            "textTransform": "uppercase", "letterSpacing": "0.5px",
            "whiteSpace": "nowrap",
        }) for col in display_df.columns
    ]))

    rows = []
    for _, row in display_df.iterrows():
        cells = [html.Td(
            str(val)[:60] if val is not None else "—",
            style={
                "padding": "6px 12px", "color": "#CBD5E1",
                "borderBottom": "1px solid rgba(255,255,255,0.05)",
                "fontSize": "12px", "whiteSpace": "nowrap",
                "fontFamily": "monospace" if isinstance(val, (int, float)) else "inherit",
            }
        ) for val in row]
        rows.append(html.Tr(cells))

    return html.Table(
        [header, html.Tbody(rows)],
        style={"width": "100%", "borderCollapse": "collapse",
               "backgroundColor": "rgba(0,0,0,0.2)", "borderRadius": "8px"},
    )
