"""
Shared helper module for analytics family subpages.
Provides reusable layout components for all 7 analytics family pages.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import io
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME
from engine import get_pipeline


# =============================================================================
# SHARED THEME
# =============================================================================
CHART_BG = "rgba(0,0,0,0)"
CHART_TEXT = "#94A3B8"
CHART_GRID = "rgba(148,163,184,0.1)"


def empty_fig(msg="No data available — run the pipeline first"):
    fig = go.Figure()
    fig.add_annotation(text=msg, showarrow=False,
                       font=dict(color="#64748B", size=14))
    fig.update_layout(paper_bgcolor=CHART_BG, plot_bgcolor=CHART_BG,
                      margin=dict(l=30, r=30, t=30, b=30))
    return fig


def styled_layout(fig):
    """Apply dark theme to a plotly figure."""
    fig.update_layout(
        paper_bgcolor=CHART_BG,
        plot_bgcolor=CHART_BG,
        font=dict(color=CHART_TEXT),
        xaxis=dict(gridcolor=CHART_GRID, zerolinecolor=CHART_GRID),
        yaxis=dict(gridcolor=CHART_GRID, zerolinecolor=CHART_GRID),
        margin=dict(l=40, r=30, t=40, b=40),
        legend=dict(font=dict(color=CHART_TEXT)),
    )
    return fig


def make_family_layout(family_key, family_title, family_icon, family_color,
                       description, chart_ids, chart_labels):
    """Generate a standard layout for an analytics family page."""
    charts = []
    for i, (chart_id, label) in enumerate(zip(chart_ids, chart_labels)):
        charts.append(
            dmc.Paper([
                dmc.Text(label, size="sm", fw=600, c="white", mb="sm"),
                dcc.Graph(id=chart_id, config={"displayModeBar": True,
                          "toImageButtonOptions": {"format": "png", "scale": 2}},
                          style={"height": "350px"}),
            ], p="lg", radius="lg", className="glass-card")
        )

    return dmc.Box([
        # Header
        dmc.Group([
            dmc.ThemeIcon(DashIconify(icon=family_icon, width=28), size="xl",
                         radius="md", variant="gradient",
                         gradient={"from": family_color, "to": "indigo"}),
            dmc.Stack([
                dmc.Title(family_title, order=2, c="white"),
                dmc.Text(description, c="dimmed", size="sm"),
            ], gap=2),
        ], gap="md", mb="lg"),

        # Controls Row
        dmc.Paper([
            dmc.Group([
                dmc.Button(f"Re-run {family_title}", id=f"btn-run-{family_key}",
                          leftSection=DashIconify(icon="mdi:play-circle"),
                          color="cyan", variant="gradient",
                          gradient={"from": "cyan", "to": "indigo"}, size="sm"),
                dmc.Button("Export CSV", id=f"btn-export-{family_key}",
                          leftSection=DashIconify(icon="mdi:download"),
                          color="green", variant="outline", size="sm"),
                dcc.Download(id=f"download-{family_key}"),
                html.Div(id=f"status-{family_key}",
                         children=dmc.Badge("Ready", color="gray", variant="light")),
            ], gap="md"),
        ], p="md", radius="lg", className="glass-card", mb="md"),

        # Charts
        dmc.SimpleGrid(
            cols={"base": 1, "lg": 2}, spacing="md",
            children=charts,
        ),

        dmc.Space(h="md"),

        # Data Table
        dmc.Paper([
            dmc.Group([
                dmc.Text("Raw Data Table", size="sm", fw=600, c="white"),
                dmc.Badge(id=f"rows-{family_key}", children="0 rows",
                         color="cyan", variant="light", size="sm"),
            ], justify="space-between", mb="sm"),
            html.Div(id=f"table-{family_key}",
                     style={"maxHeight": "400px", "overflowY": "auto",
                            "overflowX": "auto"}),
        ], p="lg", radius="lg", className="glass-card"),
    ])


def make_data_table(df, max_rows=200):
    """Create an HTML table from a DataFrame."""
    if df is None or len(df) == 0:
        return dmc.Text("No data available", c="dimmed", size="sm")

    display_df = df.head(max_rows)
    # Round numeric columns
    for col in display_df.select_dtypes(include=["float64", "float32"]).columns:
        display_df = display_df.copy()
        display_df[col] = display_df[col].round(6)

    header = html.Thead(html.Tr(
        [html.Th(col, style={"padding": "8px 12px", "color": THEME.TEXT_PRIMARY,
                              "borderBottom": f"1px solid {THEME.DARK_BORDER}",
                              "fontSize": "12px", "whiteSpace": "nowrap"})
         for col in display_df.columns]
    ))
    rows = []
    for _, row in display_df.iterrows():
        cells = []
        for val in row:
            cells.append(html.Td(str(val)[:50], style={
                "padding": "6px 12px", "color": "#CBD5E1",
                "borderBottom": "1px solid rgba(255,255,255,0.05)",
                "fontSize": "12px", "whiteSpace": "nowrap",
            }))
        rows.append(html.Tr(cells))
    body = html.Tbody(rows)

    return html.Table(
        [header, body],
        style={"width": "100%", "borderCollapse": "collapse",
               "backgroundColor": "rgba(0,0,0,0.2)", "borderRadius": "8px"},
    )
