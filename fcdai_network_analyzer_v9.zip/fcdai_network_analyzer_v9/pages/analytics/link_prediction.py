"""
Analytics Subpage: Hidden Association Predictor (Link Prediction)
==================================================================
Metrics: MinHash LSH Jaccard, Adamic-Adar, Preferential Attachment
v7: MinHash LSH for O(n) Jaccard, vectorized ANN approximation
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
import plotly.graph_objects as go
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import THEME
from engine import get_pipeline
from utils.logger import GlobalExceptionHandler
from pages.analytics import (empty_fig, styled_layout, make_family_layout,
                              make_data_table)

dash.register_page(__name__, path="/analytics/link-prediction",
                   name="Hidden Association Predictor", title="FCDAI | Hidden Association Predictor")

layout = make_family_layout(
    family_key="link_prediction",
    family_title="Hidden Association Predictor",
    family_icon="mdi:link-variant",
    family_color="#FFD600",
    description="MinHash LSH Jaccard, Adamic-Adar index & Preferential Attachment — O(n) speed",
    chart_ids=["chart-lp-jaccard", "chart-lp-scatter",
               "chart-lp-top20", "chart-lp-pref"],
    chart_labels=["Jaccard Score Distribution",
                  "Jaccard vs Adamic-Adar",
                  "Top 20 by Adamic-Adar",
                  "Preferential Attachment Distribution"],
)


@callback(
    Output("chart-lp-jaccard", "figure"),
    Output("chart-lp-scatter", "figure"),
    Output("chart-lp-top20", "figure"),
    Output("chart-lp-pref", "figure"),
    Output("table-link_prediction", "children"),
    Output("rows-link_prediction", "children"),
    Output("status-link_prediction", "children"),
    Input("btn-run-link_prediction", "n_clicks"),
    Input("pipeline-state", "data"),
    prevent_initial_call=False,
)
@GlobalExceptionHandler.wrap(fallback=(empty_fig(), empty_fig(), empty_fig(), empty_fig(),
                                       "No data", "0 rows",
                                       dmc.Badge("Error", color="red", variant="light")))
def update_link_prediction(n_clicks, _ps):
    pipeline = get_pipeline()
    if n_clicks:
        try:
            pipeline.run_single_family("link_prediction")
        except Exception:
            pass

    df = pipeline.get_family_results("link_prediction")
    if df is None or len(df) == 0:
        return (empty_fig(), empty_fig(), empty_fig(), empty_fig(),
                "No data", "0 rows",
                dmc.Badge("No data", color="yellow", variant="light"))

    # 1. Jaccard distribution
    fig1 = go.Figure()
    if "jaccard_avg" in df.columns:
        fig1.add_trace(go.Histogram(x=df["jaccard_avg"], nbinsx=40,
                                     marker=dict(color="#FFD600")))
    styled_layout(fig1)
    fig1.update_layout(xaxis_title="Jaccard Avg Score", yaxis_title="Count")

    # 2. Jaccard vs Adamic-Adar
    fig2 = go.Figure()
    if "jaccard_avg" in df.columns and "adamic_adar_avg" in df.columns:
        fig2.add_trace(go.Scatter(
            x=df["jaccard_avg"], y=df["adamic_adar_avg"], mode="markers",
            marker=dict(size=4, color="#FFD600", opacity=0.5),
            text=df["node_id"],
            hovertemplate="<b>%{text}</b><br>Jaccard: %{x:.4f}<br>AA: %{y:.4f}<extra></extra>",
        ))
    styled_layout(fig2)
    fig2.update_layout(xaxis_title="Jaccard Avg", yaxis_title="Adamic-Adar Avg")

    # 3. Top 20 by AA
    fig3 = go.Figure()
    if "adamic_adar_avg" in df.columns:
        top = df.nlargest(20, "adamic_adar_avg")
        fig3.add_trace(go.Bar(
            x=top["adamic_adar_avg"], y=top["node_id"], orientation="h",
            marker=dict(color=top["adamic_adar_avg"], colorscale="YlOrRd"),
        ))
    styled_layout(fig3)
    fig3.update_layout(yaxis=dict(autorange="reversed"), xaxis_title="Adamic-Adar Score")

    # 4. Pref attachment
    fig4 = go.Figure()
    if "pref_attachment" in df.columns:
        fig4.add_trace(go.Histogram(x=df["pref_attachment"], nbinsx=40,
                                     marker=dict(color="#FF9800")))
    styled_layout(fig4)
    fig4.update_layout(xaxis_title="Preferential Attachment", yaxis_title="Count")

    table = make_data_table(df)
    status = dmc.Badge(f"{len(df):,} nodes analyzed", color="green", variant="light")
    return fig1, fig2, fig3, fig4, table, f"{len(df):,} rows", status


@callback(
    Output("download-link_prediction", "data"),
    Input("btn-export-link_prediction", "n_clicks"),
    prevent_initial_call=True,
)
def export_lp(n):
    df = get_pipeline().get_family_results("link_prediction")
    if df is not None:
        return dcc.send_data_frame(df.to_csv, "link_prediction_analysis.csv", index=False)
