"""
Analytics Subpage: Topological Cluster Engine (Community)
=========================================================
Metrics: Leiden/Louvain, Label Propagation, Community Size
v7: igraph Leiden C++ multi-core
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
import plotly.graph_objects as go
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import THEME
from engine import get_pipeline
from utils.logger import GlobalExceptionHandler
from pages.analytics import (empty_fig, styled_layout, make_family_layout,
                              make_data_table, CHART_BG, CHART_TEXT)

dash.register_page(__name__, path="/analytics/community",
                   name="Topological Cluster Engine", title="FCDAI | Topological Cluster Engine")

layout = make_family_layout(
    family_key="community",
    family_title="Topological Cluster Engine",
    family_icon="mdi:account-group",
    family_color="#9D4EDD",
    description="Leiden clustering, Label Propagation & community size — igraph C++ multi-core",
    chart_ids=["chart-comm-sizes", "chart-comm-scatter",
               "chart-comm-lp", "chart-comm-dist"],
    chart_labels=["Community Size Distribution (Louvain)",
                  "Node Community Assignment",
                  "Label Propagation vs Louvain",
                  "Community Membership Histogram"],
)


@callback(
    Output("chart-comm-sizes", "figure"),
    Output("chart-comm-scatter", "figure"),
    Output("chart-comm-lp", "figure"),
    Output("chart-comm-dist", "figure"),
    Output("table-community", "children"),
    Output("rows-community", "children"),
    Output("status-community", "children"),
    Input("btn-run-community", "n_clicks"),
    Input("pipeline-state", "data"),
    prevent_initial_call=False,
)
@GlobalExceptionHandler.wrap(fallback=(empty_fig(), empty_fig(), empty_fig(), empty_fig(),
                                       "No data", "0 rows",
                                       dmc.Badge("Error", color="red", variant="light")))
def update_community(n_clicks, _ps):
    pipeline = get_pipeline()
    if n_clicks:
        try:
            pipeline.run_single_family("community")
        except Exception:
            pass

    df = pipeline.get_family_results("community")
    if df is None or len(df) == 0:
        return (empty_fig(), empty_fig(), empty_fig(), empty_fig(),
                "No data", "0 rows",
                dmc.Badge("No data", color="yellow", variant="light"))

    # 1. Community size bar chart
    fig1 = go.Figure()
    if "louvain_community" in df.columns:
        comm_sizes = df["louvain_community"].value_counts().sort_values(ascending=False).head(30)
        fig1.add_trace(go.Bar(
            x=[f"C{c}" for c in comm_sizes.index],
            y=comm_sizes.values,
            marker=dict(color=comm_sizes.values, colorscale="Viridis"),
        ))
    styled_layout(fig1)
    fig1.update_layout(xaxis_title="Community ID", yaxis_title="Members")

    # 2. Node scatter by community
    fig2 = go.Figure()
    if "louvain_community" in df.columns and "community_size" in df.columns:
        fig2.add_trace(go.Scatter(
            x=df.index, y=df["community_size"], mode="markers",
            marker=dict(size=4, color=df["louvain_community"],
                       colorscale="Rainbow", showscale=True,
                       colorbar=dict(title="Comm")),
            text=df["node_id"],
            hovertemplate="<b>%{text}</b><br>Community: %{marker.color}<br>Size: %{y}<extra></extra>",
        ))
    styled_layout(fig2)
    fig2.update_layout(xaxis_title="Node Index", yaxis_title="Community Size")

    # 3. LP vs Louvain comparison
    fig3 = go.Figure()
    if "louvain_community" in df.columns and "label_prop_community" in df.columns:
        fig3.add_trace(go.Scatter(
            x=df["louvain_community"], y=df["label_prop_community"],
            mode="markers", marker=dict(size=3, color="#9D4EDD", opacity=0.5),
        ))
    styled_layout(fig3)
    fig3.update_layout(xaxis_title="Louvain Community", yaxis_title="Label Prop Community")

    # 4. Community membership histogram
    fig4 = go.Figure()
    if "community_size" in df.columns:
        fig4.add_trace(go.Histogram(
            x=df["community_size"], nbinsx=30,
            marker=dict(color="#9D4EDD"),
        ))
    styled_layout(fig4)
    fig4.update_layout(xaxis_title="Community Size", yaxis_title="Count")

    n_comms = df["louvain_community"].nunique() if "louvain_community" in df.columns else 0
    table = make_data_table(df)
    status = dmc.Badge(f"{n_comms} communities found", color="green", variant="light")
    return fig1, fig2, fig3, fig4, table, f"{len(df):,} rows", status


@callback(
    Output("download-community", "data"),
    Input("btn-export-community", "n_clicks"),
    prevent_initial_call=True,
)
def export_community(n):
    df = get_pipeline().get_family_results("community")
    if df is not None:
        return dcc.send_data_frame(df.to_csv, "community_analysis.csv", index=False)
