"""
Analytics Subpage: Topological Outlier Detector (Anomaly)
==========================================================
Metrics: ECOD/Isolation Forest, LOF, Z-Score
v7: PyOD ECOD (parameter-free, instant)
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
import plotly.graph_objects as go
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import THEME
from engine import get_pipeline
from utils.logger import GlobalExceptionHandler
from pages.analytics import (empty_fig, styled_layout, make_family_layout,
                              make_data_table)

dash.register_page(__name__, path="/analytics/anomaly",
                   name="Topological Outlier Detector", title="FCDAI | Topological Outlier Detector")

layout = make_family_layout(
    family_key="anomaly",
    family_title="Topological Outlier Detector",
    family_icon="mdi:alert-decagram",
    family_color="#FF9800",
    description="ECOD/Isolation Forest, Local Outlier Factor & Z-Score anomaly scoring",
    chart_ids=["chart-anom-if", "chart-anom-scatter",
               "chart-anom-top20", "chart-anom-compare"],
    chart_labels=["Isolation Forest Score Distribution",
                  "IF Score vs LOF Score",
                  "Top 20 Anomalous Nodes",
                  "All Three Methods Comparison (Box)"],
)


@callback(
    Output("chart-anom-if", "figure"),
    Output("chart-anom-scatter", "figure"),
    Output("chart-anom-top20", "figure"),
    Output("chart-anom-compare", "figure"),
    Output("table-anomaly", "children"),
    Output("rows-anomaly", "children"),
    Output("status-anomaly", "children"),
    Input("btn-run-anomaly", "n_clicks"),
    Input("pipeline-state", "data"),
    prevent_initial_call=False,
)
@GlobalExceptionHandler.wrap(fallback=(empty_fig(), empty_fig(), empty_fig(), empty_fig(),
                                       "No data", "0 rows",
                                       dmc.Badge("Error", color="red", variant="light")))
def update_anomaly(n_clicks, _ps):
    pipeline = get_pipeline()
    if n_clicks:
        try:
            pipeline.run_single_family("anomaly")
        except Exception:
            pass

    df = pipeline.get_family_results("anomaly")
    if df is None or len(df) == 0:
        return (empty_fig(), empty_fig(), empty_fig(), empty_fig(),
                "No data", "0 rows",
                dmc.Badge("No data", color="yellow", variant="light"))

    # 1. IF score distribution
    fig1 = go.Figure()
    if "anomaly_score_if" in df.columns:
        fig1.add_trace(go.Histogram(x=df["anomaly_score_if"], nbinsx=50,
                                     marker=dict(color="#FF9800")))
    styled_layout(fig1)
    fig1.update_layout(xaxis_title="Isolation Forest Score", yaxis_title="Count")

    # 2. IF vs LOF scatter
    fig2 = go.Figure()
    if "anomaly_score_if" in df.columns and "anomaly_score_lof" in df.columns:
        fig2.add_trace(go.Scatter(
            x=df["anomaly_score_if"], y=df["anomaly_score_lof"], mode="markers",
            marker=dict(size=4, color=df.get("anomaly_score_zscore", df["anomaly_score_if"]),
                       colorscale="YlOrRd", showscale=True,
                       colorbar=dict(title="Z-Score")),
            text=df["node_id"],
            hovertemplate="<b>%{text}</b><br>IF: %{x:.4f}<br>LOF: %{y:.4f}<extra></extra>",
        ))
    styled_layout(fig2)
    fig2.update_layout(xaxis_title="Isolation Forest", yaxis_title="LOF Score")

    # 3. Top 20 anomalous
    fig3 = go.Figure()
    if "anomaly_score_if" in df.columns:
        df_sorted = df.copy()
        score_cols = ["anomaly_score_if", "anomaly_score_lof", "anomaly_score_zscore"]
        existing = [c for c in score_cols if c in df_sorted.columns]
        if existing:
            df_sorted["combined"] = df_sorted[existing].mean(axis=1)
            top = df_sorted.nlargest(20, "combined")
            fig3.add_trace(go.Bar(
                x=top["combined"], y=top["node_id"], orientation="h",
                marker=dict(color=top["combined"], colorscale="YlOrRd"),
            ))
    styled_layout(fig3)
    fig3.update_layout(yaxis=dict(autorange="reversed"), xaxis_title="Combined Anomaly Score")

    # 4. Box comparison
    fig4 = go.Figure()
    for col, color in [("anomaly_score_if", "#FF9800"),
                        ("anomaly_score_lof", "#FF5722"),
                        ("anomaly_score_zscore", "#E91E63")]:
        if col in df.columns:
            fig4.add_trace(go.Box(y=df[col], name=col.replace("anomaly_score_", "").upper(),
                                  marker_color=color))
    styled_layout(fig4)

    table = make_data_table(df)
    status = dmc.Badge(f"{len(df):,} nodes scored", color="green", variant="light")
    return fig1, fig2, fig3, fig4, table, f"{len(df):,} rows", status


@callback(
    Output("download-anomaly", "data"),
    Input("btn-export-anomaly", "n_clicks"),
    prevent_initial_call=True,
)
def export_anomaly(n):
    df = get_pipeline().get_family_results("anomaly")
    if df is not None:
        return dcc.send_data_frame(df.to_csv, "anomaly_analysis.csv", index=False)
