"""
Analytics Subpage: Network Influence Hub (Centrality)
======================================================
Metrics: PageRank, Betweenness, Closeness, Degree, Eigenvector
v7: Approx Betweenness (cutoff=4), Personalized PageRank
"""

import dash
from dash import html, dcc, callback, Input, Output, State
import dash_mantine_components as dmc
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import THEME
from engine import get_pipeline
from utils.logger import GlobalExceptionHandler
from pages.analytics import (empty_fig, styled_layout, make_family_layout,
                              make_data_table, CHART_BG, CHART_TEXT, CHART_GRID)

dash.register_page(__name__, path="/analytics/centrality",
                   name="Network Influence Hub", title="FCDAI | Network Influence Hub")

layout = make_family_layout(
    family_key="centrality",
    family_title="Network Influence Hub",
    family_icon="mdi:star-four-points",
    family_color="#00D4FF",
    description="PageRank, Approx Betweenness, Closeness, Degree & Eigenvector — igraph C-backend",
    chart_ids=["chart-centrality-dist", "chart-centrality-scatter",
               "chart-centrality-top20", "chart-centrality-correlation"],
    chart_labels=["Centrality Distribution (All Metrics)",
                  "PageRank vs Betweenness",
                  "Top 20 by PageRank",
                  "Centrality Correlation Heatmap"],
)


@callback(
    Output("chart-centrality-dist", "figure"),
    Output("chart-centrality-scatter", "figure"),
    Output("chart-centrality-top20", "figure"),
    Output("chart-centrality-correlation", "figure"),
    Output("table-centrality", "children"),
    Output("rows-centrality", "children"),
    Output("status-centrality", "children"),
    Input("btn-run-centrality", "n_clicks"),
    Input("pipeline-state", "data"),
    prevent_initial_call=False,
)
@GlobalExceptionHandler.wrap(fallback=(empty_fig(), empty_fig(), empty_fig(), empty_fig(),
                                       "No data", "0 rows",
                                       dmc.Badge("Error", color="red", variant="light")))
def update_centrality(n_clicks, _ps):
    pipeline = get_pipeline()

    if n_clicks:
        try:
            pipeline.run_single_family("centrality")
        except Exception:
            pass

    df = pipeline.get_family_results("centrality")
    if df is None or len(df) == 0:
        return (empty_fig(), empty_fig(), empty_fig(), empty_fig(),
                "No data", "0 rows",
                dmc.Badge("No data", color="yellow", variant="light"))

    metrics = [c for c in df.columns if c != "node_id"]

    # 1. Distribution box plot
    fig1 = go.Figure()
    for m in metrics:
        fig1.add_trace(go.Box(y=df[m], name=m.replace("_", " ").title(),
                              marker_color="#00D4FF"))
    styled_layout(fig1)
    fig1.update_layout(title_text="", showlegend=False)

    # 2. PageRank vs Betweenness scatter
    fig2 = go.Figure()
    if "pagerank" in df.columns and "betweenness" in df.columns:
        fig2.add_trace(go.Scatter(
            x=df["pagerank"], y=df["betweenness"], mode="markers",
            marker=dict(size=5, color=df.get("degree_centrality", df["pagerank"]),
                       colorscale="Viridis", showscale=True,
                       colorbar=dict(title="Degree")),
            text=df["node_id"],
            hovertemplate="<b>%{text}</b><br>PR: %{x:.4f}<br>BC: %{y:.4f}<extra></extra>",
        ))
    styled_layout(fig2)
    fig2.update_layout(xaxis_title="PageRank", yaxis_title="Betweenness")

    # 3. Top 20 by PageRank
    fig3 = go.Figure()
    if "pagerank" in df.columns:
        top = df.nlargest(20, "pagerank")
        fig3.add_trace(go.Bar(
            x=top["pagerank"], y=top["node_id"], orientation="h",
            marker=dict(color=top["pagerank"], colorscale="Cividis"),
        ))
    styled_layout(fig3)
    fig3.update_layout(yaxis=dict(autorange="reversed"),
                       xaxis_title="PageRank Score")

    # 4. Correlation heatmap
    fig4 = go.Figure()
    if len(metrics) > 1:
        corr = df[metrics].corr()
        fig4.add_trace(go.Heatmap(
            z=corr.values, x=corr.columns, y=corr.columns,
            colorscale="RdBu_r", zmin=-1, zmax=1,
            text=corr.values.round(2), texttemplate="%{text}",
        ))
    styled_layout(fig4)

    table = make_data_table(df)
    status = dmc.Badge(f"{len(df):,} nodes analyzed",
                       color="green", variant="light")
    return fig1, fig2, fig3, fig4, table, f"{len(df):,} rows", status


@callback(
    Output("download-centrality", "data"),
    Input("btn-export-centrality", "n_clicks"),
    prevent_initial_call=True,
)
def export_centrality(n):
    df = get_pipeline().get_family_results("centrality")
    if df is not None:
        return dcc.send_data_frame(df.to_csv, "centrality_analysis.csv", index=False)
