"""
Analytics Subpage: Multi-Layer Module
=======================================
Metrics: Transaction layer degree, Relationship layer degree, Cross-layer score
v7: NumPy vectorized edge classification
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
import plotly.graph_objects as go
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import THEME
from engine import get_pipeline
from utils.logger import GlobalExceptionHandler
from pages.analytics import (empty_fig, styled_layout, make_family_layout,
                              make_data_table)

dash.register_page(__name__, path="/analytics/multi-layer",
                   name="Multi-Layer Module", title="FCDAI | Multi-Layer Module")

layout = make_family_layout(
    family_key="multi_layer",
    family_title="Multi-Layer Module",
    family_icon="mdi:layers-triple",
    family_color="#2196F3",
    description="Cross-layer degree correlation between transaction and relationship networks — vectorized",
    chart_ids=["chart-ml-scatter", "chart-ml-cross",
               "chart-ml-top20", "chart-ml-hist"],
    chart_labels=["Transaction vs Relationship Degree",
                  "Cross-Layer Score Distribution",
                  "Top 20 by Cross-Layer Score",
                  "Layer Degree Comparison (Box)"],
)


@callback(
    Output("chart-ml-scatter", "figure"),
    Output("chart-ml-cross", "figure"),
    Output("chart-ml-top20", "figure"),
    Output("chart-ml-hist", "figure"),
    Output("table-multi_layer", "children"),
    Output("rows-multi_layer", "children"),
    Output("status-multi_layer", "children"),
    Input("btn-run-multi_layer", "n_clicks"),
    Input("pipeline-state", "data"),
    prevent_initial_call=False,
)
@GlobalExceptionHandler.wrap(fallback=(empty_fig(), empty_fig(), empty_fig(), empty_fig(),
                                       "No data", "0 rows",
                                       dmc.Badge("Error", color="red", variant="light")))
def update_multi_layer(n_clicks, _ps):
    pipeline = get_pipeline()
    if n_clicks:
        try:
            pipeline.run_single_family("multi_layer")
        except Exception:
            pass

    df = pipeline.get_family_results("multi_layer")
    if df is None or len(df) == 0:
        return (empty_fig(), empty_fig(), empty_fig(), empty_fig(),
                "No data", "0 rows",
                dmc.Badge("No data", color="yellow", variant="light"))

    # 1. Txn vs Rel degree scatter
    fig1 = go.Figure()
    if "txn_layer_degree" in df.columns and "rel_layer_degree" in df.columns:
        fig1.add_trace(go.Scatter(
            x=df["txn_layer_degree"], y=df["rel_layer_degree"], mode="markers",
            marker=dict(size=5, color=df.get("cross_layer_score", df["txn_layer_degree"]),
                       colorscale="Viridis", showscale=True,
                       colorbar=dict(title="XL Score")),
            text=df["node_id"],
            hovertemplate="<b>%{text}</b><br>Txn: %{x}<br>Rel: %{y}<extra></extra>",
        ))
    styled_layout(fig1)
    fig1.update_layout(xaxis_title="Transaction Layer Degree",
                       yaxis_title="Relationship Layer Degree")

    # 2. Cross-layer score histogram
    fig2 = go.Figure()
    if "cross_layer_score" in df.columns:
        fig2.add_trace(go.Histogram(x=df["cross_layer_score"], nbinsx=50,
                                     marker=dict(color="#2196F3")))
    styled_layout(fig2)
    fig2.update_layout(xaxis_title="Cross-Layer Score", yaxis_title="Count")

    # 3. Top 20
    fig3 = go.Figure()
    if "cross_layer_score" in df.columns:
        top = df.nlargest(20, "cross_layer_score")
        fig3.add_trace(go.Bar(
            x=top["cross_layer_score"], y=top["node_id"], orientation="h",
            marker=dict(color=top["cross_layer_score"], colorscale="Blues"),
        ))
    styled_layout(fig3)
    fig3.update_layout(yaxis=dict(autorange="reversed"),
                       xaxis_title="Cross-Layer Score")

    # 4. Box comparison
    fig4 = go.Figure()
    for col, name, color in [("txn_layer_degree", "Transaction", "#00BCD4"),
                              ("rel_layer_degree", "Relationship", "#4CAF50"),
                              ("cross_layer_score", "Cross-Layer", "#2196F3")]:
        if col in df.columns:
            fig4.add_trace(go.Box(y=df[col], name=name, marker_color=color))
    styled_layout(fig4)

    table = make_data_table(df)
    status = dmc.Badge(f"{len(df):,} nodes analyzed", color="green", variant="light")
    return fig1, fig2, fig3, fig4, table, f"{len(df):,} rows", status


@callback(
    Output("download-multi_layer", "data"),
    Input("btn-export-multi_layer", "n_clicks"),
    prevent_initial_call=True,
)
def export_multi_layer(n):
    df = get_pipeline().get_family_results("multi_layer")
    if df is not None:
        return dcc.send_data_frame(df.to_csv, "multi_layer_analysis.csv", index=False)
