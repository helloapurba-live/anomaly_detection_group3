"""
Analytics Subpage: Dynamic Velocity Analyzer (Temporal)
========================================================
Metrics: Velocity Ratio, Burst Detection, Burst Score
v7: NumPy vectorized (zero-loop)
"""

import dash
from dash import html, dcc, callback, Input, Output
import dash_mantine_components as dmc
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from config import THEME
from engine import get_pipeline
from utils.logger import GlobalExceptionHandler
from pages.analytics import (empty_fig, styled_layout, make_family_layout,
                              make_data_table)

dash.register_page(__name__, path="/analytics/temporal",
                   name="Dynamic Velocity Analyzer", title="FCDAI | Dynamic Velocity Analyzer")

layout = make_family_layout(
    family_key="temporal",
    family_title="Dynamic Velocity Analyzer",
    family_icon="mdi:clock-fast",
    family_color="#00E676",
    description="Velocity ratio, burst detection & activity spike analysis — NumPy vectorized",
    chart_ids=["chart-temp-velocity", "chart-temp-burst",
               "chart-temp-scatter", "chart-temp-pie"],
    chart_labels=["Velocity Ratio Distribution",
                  "Burst Score Distribution",
                  "Velocity vs Burst Score",
                  "Burst Flag Breakdown"],
)


@callback(
    Output("chart-temp-velocity", "figure"),
    Output("chart-temp-burst", "figure"),
    Output("chart-temp-scatter", "figure"),
    Output("chart-temp-pie", "figure"),
    Output("table-temporal", "children"),
    Output("rows-temporal", "children"),
    Output("status-temporal", "children"),
    Input("btn-run-temporal", "n_clicks"),
    Input("pipeline-state", "data"),
    prevent_initial_call=False,
)
@GlobalExceptionHandler.wrap(fallback=(empty_fig(), empty_fig(), empty_fig(), empty_fig(),
                                       "No data", "0 rows",
                                       dmc.Badge("Error", color="red", variant="light")))
def update_temporal(n_clicks, _ps):
    pipeline = get_pipeline()
    if n_clicks:
        try:
            pipeline.run_single_family("temporal")
        except Exception:
            pass

    df = pipeline.get_family_results("temporal")
    if df is None or len(df) == 0:
        return (empty_fig(), empty_fig(), empty_fig(), empty_fig(),
                "No data", "0 rows",
                dmc.Badge("No data", color="yellow", variant="light"))

    # 1. Velocity distribution
    fig1 = go.Figure()
    if "velocity_ratio" in df.columns:
        fig1.add_trace(go.Histogram(
            x=df["velocity_ratio"], nbinsx=50,
            marker=dict(color="#00E676"),
        ))
    styled_layout(fig1)
    fig1.update_layout(xaxis_title="Velocity Ratio", yaxis_title="Count")

    # 2. Burst score distribution
    fig2 = go.Figure()
    if "burst_score" in df.columns:
        fig2.add_trace(go.Histogram(
            x=df["burst_score"], nbinsx=50,
            marker=dict(color="#76FF03"),
        ))
    styled_layout(fig2)
    fig2.update_layout(xaxis_title="Burst Score", yaxis_title="Count")

    # 3. Velocity vs Burst scatter
    fig3 = go.Figure()
    if "velocity_ratio" in df.columns and "burst_score" in df.columns:
        colors = df.get("is_burst", pd.Series([0]*len(df)))
        fig3.add_trace(go.Scatter(
            x=df["velocity_ratio"], y=df["burst_score"], mode="markers",
            marker=dict(size=5, color=["#FF1744" if b else "#00E676" for b in colors],
                       opacity=0.6),
            text=df["node_id"],
            hovertemplate="<b>%{text}</b><br>Velocity: %{x:.2f}<br>Burst: %{y:.4f}<extra></extra>",
        ))
    styled_layout(fig3)
    fig3.update_layout(xaxis_title="Velocity Ratio", yaxis_title="Burst Score")

    # 4. Burst flag pie
    fig4 = go.Figure()
    if "is_burst" in df.columns:
        burst_counts = df["is_burst"].value_counts()
        labels = ["Normal" if k == 0 else "Burst Detected" for k in burst_counts.index]
        fig4.add_trace(go.Pie(
            labels=labels, values=burst_counts.values,
            hole=0.5,
            marker=dict(colors=["#00E676", "#FF1744"]),
            textfont=dict(color="white"),
        ))
    styled_layout(fig4)

    burst_count = df["is_burst"].sum() if "is_burst" in df.columns else 0
    table = make_data_table(df)
    status = dmc.Badge(f"{burst_count} bursts detected", color="orange", variant="light")
    return fig1, fig2, fig3, fig4, table, f"{len(df):,} rows", status


@callback(
    Output("download-temporal", "data"),
    Input("btn-export-temporal", "n_clicks"),
    prevent_initial_call=True,
)
def export_temporal(n):
    df = get_pipeline().get_family_results("temporal")
    if df is not None:
        return dcc.send_data_frame(df.to_csv, "temporal_analysis.csv", index=False)
