"""
Page 4: Command Center
=======================
Business Logic: Risk oversight and SAR management hub. Shows risk matrix,
investigation queue filtered by P1/P2, auto-generated SAR narratives, and
export functionality.
"""

import dash
from dash import html, dcc, callback, Input, Output, State, dash_table
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.graph_objects as go
import pandas as pd
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import THEME
from engine import get_pipeline
from utils.logger import GlobalExceptionHandler

dash.register_page(__name__, path="/command-center", name="Command Center",
                   title="FCDAI | Command Center")


# =============================================================================
# LAYOUT
# =============================================================================
layout = dmc.Box([
    # Header
    dmc.Group([
        dmc.Stack([
            dmc.Title("Command Center", order=2, c="white"),
            dmc.Text("Risk Matrix, Investigation Queue & SAR Generation", c="dimmed", size="sm"),
        ], gap=2),
        dmc.Group([
            dmc.MultiSelect(id="cc-tier-filter",
                            data=[
                                {"value": "P1", "label": "P1 — Freeze"},
                                {"value": "P2", "label": "P2 — EDD"},
                                {"value": "P3", "label": "P3 — Monitor"},
                                {"value": "P4", "label": "P4 — Low Risk"},
                            ],
                            value=["P1", "P2"],
                            w=300, size="sm",
                            placeholder="Filter by tier"),
            dmc.Button("Export Report",
                       leftSection=DashIconify(icon="mdi:file-export"),
                       id="btn-cc-export", variant="gradient",
                       gradient={"from": "red", "to": "orange"}),
        ], gap="sm"),
    ], justify="space-between", mb="lg"),

    # Risk Matrix Summary Cards
    dmc.SimpleGrid(
        cols={"base": 1, "sm": 2, "lg": 4},
        spacing="md",
        mb="lg",
        id="cc-tier-cards",
        children=[
            dmc.Paper([
                dmc.Group([
                    dmc.Badge(tier, color=color, variant="filled", size="sm"),
                    dmc.Text("—", id=f"cc-{tier}-count", size="xl", fw=800, c="white"),
                ], justify="space-between"),
                dmc.Text(desc, size="xs", c="dimmed", mt="xs"),
            ], p="lg", radius="lg", className="stat-card")
            for tier, color, desc in [
                ("P1", "red", "Immediate freeze & investigation"),
                ("P2", "orange", "Enhanced due diligence required"),
                ("P3", "yellow", "Ongoing monitoring schedule"),
                ("P4", "green", "Standard operating procedures"),
            ]
        ],
    ),

    # Score Distribution & Investigation Queue
    dmc.SimpleGrid(
        cols={"base": 1, "lg": 2},
        spacing="md",
        mb="lg",
        children=[
            # Risk Score Histogram
            dmc.Paper([
                dmc.Text("Risk Score Distribution", size="sm", fw=600, c="white", mb="sm"),
                dcc.Graph(id="cc-score-histogram",
                          config={"displayModeBar": False},
                          style={"height": "300px"}),
            ], p="lg", radius="lg", className="glass-card"),

            # Risk Matrix Heatmap
            dmc.Paper([
                dmc.Text("Risk Matrix", size="sm", fw=600, c="white", mb="sm"),
                dcc.Graph(id="cc-risk-matrix",
                          config={"displayModeBar": False},
                          style={"height": "300px"}),
            ], p="lg", radius="lg", className="glass-card"),
        ],
    ),

    # Investigation Queue Table
    dmc.Paper([
        dmc.Group([
            dmc.Text("Investigation Queue", size="sm", fw=600, c="white"),
            dmc.Badge(id="cc-queue-count", color="red", variant="light", size="sm",
                      children="0 items"),
        ], justify="space-between", mb="md"),
        html.Div(id="cc-investigation-table"),
    ], p="lg", radius="lg", className="glass-card", mb="lg"),

    # SAR Narrative Panel
    dmc.Paper([
        dmc.Group([
            dmc.Text("SAR Narrative Generator", size="sm", fw=600, c="white"),
            dmc.Select(id="cc-sar-node-select", data=[], placeholder="Select customer",
                       clearable=True, searchable=True, w=250, size="sm"),
        ], justify="space-between", mb="md"),
        dmc.Paper(
            id="cc-sar-narrative",
            p="lg", radius="md",
            style={
                "backgroundColor": THEME.DARK_BG,
                "border": f"1px solid {THEME.DARK_BORDER}",
                "fontFamily": "monospace",
                "whiteSpace": "pre-wrap",
                "minHeight": "200px",
                "maxHeight": "500px",
                "overflowY": "auto",
            },
            children=dmc.Center(
                dmc.Text("Select a customer to generate SAR narrative",
                         c="dimmed", size="sm"),
                style={"minHeight": "200px"},
            ),
        ),
    ], p="lg", radius="lg", className="glass-card"),

    # Download component
    dcc.Download(id="cc-download"),
    dcc.Loading(html.Div(id="cc-loading"), type="circle", color=THEME.PRIMARY),
])


# =============================================================================
# CALLBACKS
# =============================================================================
@callback(
    Output("cc-score-histogram", "figure"),
    Output("cc-risk-matrix", "figure"),
    Output("cc-investigation-table", "children"),
    Output("cc-queue-count", "children"),
    Output("cc-sar-node-select", "data"),
    Input("cc-tier-filter", "value"),
    Input("pipeline-state", "data"),
)
@GlobalExceptionHandler.wrap(fallback=(go.Figure(), go.Figure(), dmc.Text("No data", c="dimmed"), "0", []))
def update_command_center(tiers, _pipeline_state):
    """Update command center display."""
    pipeline = get_pipeline()
    scored = pipeline.get_scored_df()

    empty_fig = go.Figure()
    empty_fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=20, r=20, t=20, b=20),
    )
    empty_fig.add_annotation(text="Run pipeline first", showarrow=False,
                            font=dict(color="#64748B", size=14))

    if scored is None or len(scored) == 0:
        return empty_fig, empty_fig, \
            dmc.Center(dmc.Text("Run pipeline to populate", c="dimmed"), style={"minHeight": "100px"}), \
            "0 items", []

    tiers = tiers or ["P1", "P2"]

    # Score histogram
    colors = {"P1": "#FF1744", "P2": "#FF9800", "P3": "#FFD600", "P4": "#00E676"}
    fig1 = go.Figure()
    for tier in ["P1", "P2", "P3", "P4"]:
        tier_data = scored[scored["risk_tier"] == tier]
        if len(tier_data) > 0:
            fig1.add_trace(go.Histogram(
                x=tier_data["risk_score"].values,
                name=tier, marker_color=colors.get(tier, "#64748B"),
                opacity=0.8, nbinsx=30,
            ))
    fig1.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=40, r=20, t=20, b=40),
        barmode="stack",
        legend=dict(font=dict(color="#94A3B8", size=10)),
        xaxis=dict(title="Risk Score", gridcolor="rgba(255,255,255,0.05)",
                   color="#94A3B8"),
        yaxis=dict(title="Count", gridcolor="rgba(255,255,255,0.05)",
                   color="#94A3B8"),
    )

    # Risk matrix heatmap
    matrix = pipeline.get_risk_matrix()
    dist = matrix.get("score_distribution", {})
    if dist:
        fig2 = go.Figure(go.Bar(
            x=list(dist.keys()),
            y=list(dist.values()),
            marker_color=["#00E676", "#00E676", "#FFD600", "#FF9800", "#FF1744"],
            opacity=0.85,
        ))
        fig2.update_layout(
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            margin=dict(l=40, r=20, t=20, b=40),
            xaxis=dict(title="Score Range", color="#94A3B8"),
            yaxis=dict(title="Count", gridcolor="rgba(255,255,255,0.05)",
                       color="#94A3B8"),
        )
    else:
        fig2 = empty_fig

    # Investigation queue (filtered by selected tiers)
    filtered = scored[scored["risk_tier"].isin(tiers)].sort_values("risk_score", ascending=False)
    filtered_display = filtered.head(200)

    # Columns to show
    show_cols = [c for c in ["node_id", "risk_score", "risk_tier"] + \
                [c for c in filtered_display.columns if c.startswith("score_")]
                if c in filtered_display.columns][:8]

    table = dash_table.DataTable(
        data=filtered_display[show_cols].to_dict("records") if len(show_cols) > 0 else [],
        columns=[{"name": c.replace("_", " ").title(), "id": c} for c in show_cols],
        page_size=15,
        sort_action="native",
        style_header={
            "backgroundColor": THEME.DARK_BG_ELEVATED,
            "color": THEME.PRIMARY,
            "fontWeight": "600",
            "fontSize": "11px",
            "textTransform": "uppercase",
            "border": f"1px solid {THEME.DARK_BORDER}",
        },
        style_cell={
            "backgroundColor": THEME.DARK_BG_CARD,
            "color": THEME.TEXT_PRIMARY,
            "border": f"1px solid {THEME.DARK_BORDER}",
            "fontSize": "12px",
        },
        style_data_conditional=[
            {"if": {"row_index": "odd"}, "backgroundColor": THEME.DARK_BG_ELEVATED},
            {"if": {"filter_query": "{risk_tier} = P1"},
             "backgroundColor": "rgba(255, 23, 68, 0.1)"},
            {"if": {"filter_query": "{risk_tier} = P2"},
             "backgroundColor": "rgba(255, 152, 0, 0.08)"},
        ],
    )

    queue_count = f"{len(filtered):,} items"

    # SAR select options
    p1p2 = scored[scored["risk_tier"].isin(["P1", "P2"])].sort_values("risk_score", ascending=False)
    sar_options = [{"value": row["node_id"],
                    "label": f'{row["node_id"]} ({row["risk_tier"]} — {row["risk_score"]:.0f})'}
                   for _, row in p1p2.head(100).iterrows()]

    return fig1, fig2, table, queue_count, sar_options


@callback(
    Output("cc-sar-narrative", "children"),
    Input("cc-sar-node-select", "value"),
)
@GlobalExceptionHandler.wrap(fallback=dmc.Text("Error generating narrative", c="red"))
def show_sar_narrative(node_id):
    """Display SAR narrative for selected customer."""
    if not node_id:
        return dmc.Center(
            dmc.Text("Select a customer to generate SAR narrative", c="dimmed", size="sm"),
            style={"minHeight": "200px"},
        )

    pipeline = get_pipeline()
    narrative = pipeline.get_narrative(node_id)
    return dmc.Text(narrative, size="sm", c=THEME.TEXT_PRIMARY,
                    style={"fontFamily": "monospace", "whiteSpace": "pre-wrap"})


@callback(
    Output("cc-download", "data"),
    Input("btn-cc-export", "n_clicks"),
    prevent_initial_call=True,
)
@GlobalExceptionHandler.wrap(fallback=None)
def export_report(n_clicks):
    """Export investigation report to CSV."""
    if not n_clicks:
        return None
    pipeline = get_pipeline()
    scored = pipeline.get_scored_df()
    if scored is not None:
        return dcc.send_data_frame(scored.to_csv, "fcdai_investigation_report.csv", index=False)
    return None
