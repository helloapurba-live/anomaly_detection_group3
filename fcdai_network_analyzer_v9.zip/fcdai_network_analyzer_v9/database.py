"""
FCDAI Network Analyzer v3 — SQLite Database Manager
=====================================================
Business Logic: Provides persistent local storage for all pipeline inputs,
outputs, scored results, analytics, and run history. Results are stored
until the pipeline is re-run.

Technical Implementation: Uses Python's built-in sqlite3 module. DataFrames
are serialized as JSON text. Graphs/analytics stored as pickle blobs.
Thread-safe with check_same_thread=False.
"""

import sqlite3
import json
import pickle
import time
from pathlib import Path
from typing import Any, Dict, List, Optional
from datetime import datetime
import pandas as pd
import numpy as np


class DatabaseManager:
    """
    Business Logic: Manages all pipeline data persistence via SQLite.
    Stores run history, raw tables, scored results, analytics, and metadata.
    """

    def __init__(self, db_path: Path):
        """Initialize the database connection and create tables."""
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(
            str(self.db_path),
            check_same_thread=False,
            detect_types=sqlite3.PARSE_DECLTYPES,
        )
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._create_tables()

    def _create_tables(self):
        """Create all required tables if they don't exist."""
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS pipeline_runs (
                run_id       INTEGER PRIMARY KEY AUTOINCREMENT,
                started_at   TEXT NOT NULL,
                finished_at  TEXT,
                duration_sec REAL,
                customers    INTEGER DEFAULT 0,
                nodes        INTEGER DEFAULT 0,
                edges        INTEGER DEFAULT 0,
                status       TEXT DEFAULT 'running',
                metadata     TEXT DEFAULT '{}'
            );

            CREATE TABLE IF NOT EXISTS raw_tables (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id   INTEGER NOT NULL,
                name     TEXT NOT NULL,
                data     TEXT NOT NULL,
                rows     INTEGER DEFAULT 0,
                cols     INTEGER DEFAULT 0,
                FOREIGN KEY (run_id) REFERENCES pipeline_runs(run_id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS scored_results (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id   INTEGER NOT NULL,
                data     TEXT NOT NULL,
                rows     INTEGER DEFAULT 0,
                FOREIGN KEY (run_id) REFERENCES pipeline_runs(run_id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS analytics_results (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id      INTEGER NOT NULL,
                family      TEXT NOT NULL,
                data        TEXT NOT NULL,
                rows        INTEGER DEFAULT 0,
                FOREIGN KEY (run_id) REFERENCES pipeline_runs(run_id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS graph_data (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id   INTEGER NOT NULL,
                graph    BLOB NOT NULL,
                FOREIGN KEY (run_id) REFERENCES pipeline_runs(run_id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS reports_data (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id   INTEGER NOT NULL,
                reports  BLOB NOT NULL,
                FOREIGN KEY (run_id) REFERENCES pipeline_runs(run_id) ON DELETE CASCADE
            );
        """)
        self._conn.commit()

    # =========================================================================
    # SAVE OPERATIONS
    # =========================================================================
    def start_run(self, max_customers: int = 500) -> int:
        """Create a new pipeline run record. Returns run_id."""
        now = datetime.now().isoformat()
        cur = self._conn.execute(
            "INSERT INTO pipeline_runs (started_at, customers, status, metadata) "
            "VALUES (?, ?, 'running', ?)",
            (now, max_customers, json.dumps({"max_customers": max_customers})),
        )
        self._conn.commit()
        return cur.lastrowid

    def finish_run(self, run_id: int, duration: float,
                   customers: int, nodes: int, edges: int,
                   status: str = "success", meta: Dict = None):
        """Mark a run as complete with final stats."""
        now = datetime.now().isoformat()
        self._conn.execute(
            "UPDATE pipeline_runs SET finished_at=?, duration_sec=?, "
            "customers=?, nodes=?, edges=?, status=?, metadata=? WHERE run_id=?",
            (now, round(duration, 2), customers, nodes, edges, status,
             json.dumps(meta or {}), run_id),
        )
        self._conn.commit()

    def save_raw_tables(self, run_id: int, tables: Dict[str, pd.DataFrame]):
        """Save raw input DataFrames for a run."""
        for name, df in tables.items():
            data_json = df.to_json(orient="split", date_format="iso", default_handler=str)
            self._conn.execute(
                "INSERT INTO raw_tables (run_id, name, data, rows, cols) VALUES (?,?,?,?,?)",
                (run_id, name, data_json, len(df), len(df.columns)),
            )
        self._conn.commit()

    def save_scored(self, run_id: int, scored_df: pd.DataFrame):
        """Save scored results DataFrame for a run."""
        if scored_df is not None and len(scored_df) > 0:
            data_json = scored_df.to_json(orient="split", date_format="iso",
                                          default_handler=str)
            self._conn.execute(
                "INSERT INTO scored_results (run_id, data, rows) VALUES (?,?,?)",
                (run_id, data_json, len(scored_df)),
            )
            self._conn.commit()

    def save_analytics(self, run_id: int, analytics: Dict[str, pd.DataFrame]):
        """Save analytics results by family."""
        for family, df in analytics.items():
            if df is not None and isinstance(df, pd.DataFrame) and len(df) > 0:
                data_json = df.to_json(orient="split", date_format="iso",
                                       default_handler=str)
                self._conn.execute(
                    "INSERT INTO analytics_results (run_id, family, data, rows) "
                    "VALUES (?,?,?,?)",
                    (run_id, family, data_json, len(df)),
                )
        self._conn.commit()

    def save_graph(self, run_id: int, graph):
        """Save networkx graph as pickle blob."""
        if graph is not None:
            blob = pickle.dumps(graph)
            self._conn.execute(
                "INSERT INTO graph_data (run_id, graph) VALUES (?,?)",
                (run_id, blob),
            )
            self._conn.commit()

    def save_reports(self, run_id: int, reports: Dict):
        """Save reports dictionary as pickle blob."""
        if reports is not None:
            blob = pickle.dumps(reports)
            self._conn.execute(
                "INSERT INTO reports_data (run_id, reports) VALUES (?,?)",
                (run_id, blob),
            )
            self._conn.commit()

    # =========================================================================
    # LOAD OPERATIONS
    # =========================================================================
    def load_latest_run(self) -> Optional[Dict[str, Any]]:
        """
        Load the most recent successful run data.
        Returns dict with: run_info, scored_df, analytics, graph, raw_tables, reports
        """
        row = self._conn.execute(
            "SELECT run_id, started_at, finished_at, duration_sec, customers, "
            "nodes, edges, status, metadata "
            "FROM pipeline_runs WHERE status='success' "
            "ORDER BY run_id DESC LIMIT 1"
        ).fetchone()

        if not row:
            return None

        run_id = row[0]
        run_info = {
            "run_id": run_id,
            "started_at": row[1],
            "finished_at": row[2],
            "duration_sec": row[3],
            "customers": row[4],
            "nodes": row[5],
            "edges": row[6],
            "status": row[7],
            "metadata": json.loads(row[8] or "{}"),
        }

        result = {"run_info": run_info}

        # Scored results
        scored_row = self._conn.execute(
            "SELECT data FROM scored_results WHERE run_id=? ORDER BY id DESC LIMIT 1",
            (run_id,),
        ).fetchone()
        result["scored_df"] = (
            pd.read_json(scored_row[0], orient="split") if scored_row else None
        )

        # Analytics
        analytics = {}
        for arow in self._conn.execute(
            "SELECT family, data FROM analytics_results WHERE run_id=?", (run_id,)
        ).fetchall():
            analytics[arow[0]] = pd.read_json(arow[1], orient="split")
        result["analytics"] = analytics

        # Graph
        graph_row = self._conn.execute(
            "SELECT graph FROM graph_data WHERE run_id=? ORDER BY id DESC LIMIT 1",
            (run_id,),
        ).fetchone()
        result["graph"] = pickle.loads(graph_row[0]) if graph_row else None

        # Raw tables
        raw_tables = {}
        for trow in self._conn.execute(
            "SELECT name, data FROM raw_tables WHERE run_id=?", (run_id,)
        ).fetchall():
            raw_tables[trow[0]] = pd.read_json(trow[1], orient="split")
        result["raw_tables"] = raw_tables

        # Reports
        reports_row = self._conn.execute(
            "SELECT reports FROM reports_data WHERE run_id=? ORDER BY id DESC LIMIT 1",
            (run_id,),
        ).fetchone()
        result["reports"] = pickle.loads(reports_row[0]) if reports_row else None

        return result

    # =========================================================================
    # HISTORY & QUERY OPERATIONS
    # =========================================================================
    def get_run_history(self, limit: int = 50) -> pd.DataFrame:
        """Get all pipeline runs as a DataFrame."""
        rows = self._conn.execute(
            "SELECT run_id, started_at, finished_at, duration_sec, customers, "
            "nodes, edges, status FROM pipeline_runs "
            "ORDER BY run_id DESC LIMIT ?",
            (limit,),
        ).fetchall()

        if not rows:
            return pd.DataFrame(columns=[
                "run_id", "started_at", "finished_at", "duration_sec",
                "customers", "nodes", "edges", "status"
            ])

        return pd.DataFrame(rows, columns=[
            "run_id", "started_at", "finished_at", "duration_sec",
            "customers", "nodes", "edges", "status"
        ])

    def get_run_scored(self, run_id: int) -> Optional[pd.DataFrame]:
        """Get scored results for a specific run."""
        row = self._conn.execute(
            "SELECT data FROM scored_results WHERE run_id=?", (run_id,)
        ).fetchone()
        return pd.read_json(row[0], orient="split") if row else None

    def get_table_list(self) -> List[Dict]:
        """List all SQLite tables with row/column counts."""
        tables = []
        for row in self._conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        ).fetchall():
            name = row[0]
            count = self._conn.execute(f"SELECT COUNT(*) FROM [{name}]").fetchone()[0]
            # Get column info
            cols = self._conn.execute(f"PRAGMA table_info([{name}])").fetchall()
            tables.append({
                "table": name,
                "rows": count,
                "columns": len(cols),
                "col_names": [c[1] for c in cols],
            })
        return tables

    def preview_table(self, table_name: str, limit: int = 100) -> pd.DataFrame:
        """Preview any SQLite table."""
        try:
            df = pd.read_sql_query(
                f"SELECT * FROM [{table_name}] LIMIT ?",
                self._conn, params=(limit,)
            )
            return df
        except Exception:
            return pd.DataFrame()

    def run_query(self, sql: str, limit: int = 500) -> pd.DataFrame:
        """Execute arbitrary SELECT query. Read-only."""
        sql_stripped = sql.strip().upper()
        if not sql_stripped.startswith("SELECT"):
            return pd.DataFrame({"error": ["Only SELECT queries are allowed"]})
        try:
            df = pd.read_sql_query(sql, self._conn)
            return df.head(limit)
        except Exception as e:
            return pd.DataFrame({"error": [str(e)]})

    def clear_runs(self):
        """Delete all pipeline run data."""
        for table in ["reports_data", "graph_data", "analytics_results",
                       "scored_results", "raw_tables", "pipeline_runs"]:
            self._conn.execute(f"DELETE FROM [{table}]")
        self._conn.execute("VACUUM")
        self._conn.commit()

    def get_db_stats(self) -> Dict:
        """Get database statistics."""
        size_bytes = self.db_path.stat().st_size if self.db_path.exists() else 0
        runs = self._conn.execute("SELECT COUNT(*) FROM pipeline_runs").fetchone()[0]
        return {
            "size_mb": round(size_bytes / (1024 * 1024), 2),
            "total_runs": runs,
            "db_path": str(self.db_path),
        }

    def close(self):
        """Close the database connection."""
        self._conn.close()


# =============================================================================
# SINGLETON
# =============================================================================
_db: Optional[DatabaseManager] = None


def get_db() -> DatabaseManager:
    """Get or create the singleton DatabaseManager."""
    global _db
    if _db is None:
        from config import PATHS
        _db = DatabaseManager(PATHS.DB_PATH)
    return _db
